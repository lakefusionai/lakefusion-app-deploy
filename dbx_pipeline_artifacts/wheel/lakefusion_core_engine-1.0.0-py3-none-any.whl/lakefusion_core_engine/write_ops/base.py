from abc import ABC, abstractmethod
from enum import Enum
from typing import Dict, List, Optional


class WriteMode(str, Enum):
    DELTA = "delta"
    LAKEBASE = "lakebase"


class WriteOperations(ABC):
    """
    Abstract base for storage write operations.

    Both DeltaWriteOps and LakebaseWriteOps implement this interface.
    Notebooks call these methods with a Spark DataFrame — the implementation
    handles the rest (Delta saveAsTable vs JDBC write).
    """

    @abstractmethod
    def create_table(self, df, table_name: str, enable_cdf: bool = False) -> None:
        """Drop and recreate table from DataFrame schema."""
        ...

    @abstractmethod
    def overwrite(self, df, table_name: str) -> None:
        """Replace all data in the table with the DataFrame contents."""
        ...

    @abstractmethod
    def append(self, df, table_name: str) -> None:
        """Append DataFrame rows to the table."""
        ...

    @abstractmethod
    def merge(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        when_matched: Optional[Dict] = None,
        when_not_matched: str = "insert",
    ) -> None:
        """
        Upsert: insert new rows, update existing rows matched by merge_keys.

        Args:
            df: Source DataFrame
            table_name: Target table (UC path for Delta, resolved for Lakebase)
            merge_keys: Columns to match on (e.g. ["lakefusion_id"])
            when_matched: Dict of {col: expr} for UPDATE SET. None = update all.
            when_not_matched: "insert" (default) or "skip"
        """
        ...

    @abstractmethod
    def merge_with_delete(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        delete_condition: str,
    ) -> None:
        """Merge with conditional delete for rows not in source."""
        ...

    @abstractmethod
    def sql_merge(
        self,
        sql_string: str,
        table_name: str,
        source_df=None,
        merge_keys: Optional[List[str]] = None,
    ) -> None:
        """
        Execute a raw MERGE INTO statement.

        For Delta: runs sql_string directly via spark.sql().
        For Lakebase: writes source_df to staging table, translates to
                      INSERT ... ON CONFLICT using merge_keys.
        """
        ...

    @abstractmethod
    def table_exists(self, table_name: str) -> bool:
        """Check if the target table exists."""
        ...

    @abstractmethod
    def optimize(self, table_name: str) -> None:
        """Optimize table storage. No-op for Lakebase."""
        ...

    @abstractmethod
    def enable_cdf(self, table_name: str) -> None:
        """Enable Change Data Feed. No-op for Lakebase."""
        ...

    def begin_transaction(self) -> None:
        """Begin a write transaction. No-op for Delta."""
        pass

    def commit_transaction(self) -> None:
        """Commit current transaction. No-op for Delta."""
        pass

    def rollback_transaction(self) -> None:
        """Rollback current transaction. No-op for Delta."""
        pass