import logging
from typing import Dict, List, Optional

from delta.tables import DeltaTable

from .base import WriteOperations

logger = logging.getLogger("WriteOps.Delta")


class DeltaWriteOps(WriteOperations):
    """
    Delta table write operations — thin wrapper around existing Spark/Delta calls.

    This is a 1:1 mapping of current notebook write patterns. Using write_mode=delta
    with this class produces identical behavior to the original direct calls.
    """

    def __init__(self, spark):
        self._spark = spark

    def create_table(self, df, table_name: str, enable_cdf: bool = False) -> None:
        self._spark.sql(f"DROP TABLE IF EXISTS {table_name}")
        writer = df.write.format("delta").mode("overwrite")
        if enable_cdf:
            writer = writer.option("delta.enableChangeDataFeed", "true")
        writer.saveAsTable(table_name)
        logger.info(f"Created table {table_name} (CDF={enable_cdf})")

    def overwrite(self, df, table_name: str) -> None:
        df.write.format("delta") \
            .mode("overwrite") \
            .option("mergeSchema", "true") \
            .saveAsTable(table_name)
        logger.info(f"Overwrote {table_name}")

    def append(self, df, table_name: str) -> None:
        df.write.format("delta").mode("append").saveAsTable(table_name)
        logger.info(f"Appended to {table_name}")

    def merge(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        when_matched: Optional[Dict] = None,
        when_not_matched: str = "insert",
    ) -> None:
        delta_table = DeltaTable.forName(self._spark, table_name)
        condition = " AND ".join(
            f"target.{k} = source.{k}" for k in merge_keys
        )
        merger = delta_table.alias("target").merge(df.alias("source"), condition)

        if when_matched is not None:
            merger = merger.whenMatchedUpdate(set=when_matched)
        else:
            merger = merger.whenMatchedUpdateAll()

        if when_not_matched == "insert":
            merger = merger.whenNotMatchedInsertAll()

        merger.execute()
        logger.info(f"Merged into {table_name} on {merge_keys}")

    def merge_with_delete(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        delete_condition: str,
    ) -> None:
        delta_table = DeltaTable.forName(self._spark, table_name)
        condition = " AND ".join(
            f"target.{k} = source.{k}" for k in merge_keys
        )
        delta_table.alias("target").merge(
            df.alias("source"), condition
        ).whenMatchedUpdateAll() \
         .whenNotMatchedInsertAll() \
         .whenNotMatchedBySourceDelete(delete_condition) \
         .execute()
        logger.info(f"Merge+delete into {table_name} on {merge_keys}")

    def sql_merge(
        self,
        sql_string: str,
        table_name: str,
        source_df=None,
        merge_keys: Optional[List[str]] = None,
    ) -> None:
        self._spark.sql(sql_string)
        logger.info(f"SQL merge into {table_name}")

    def table_exists(self, table_name: str) -> bool:
        return self._spark.catalog.tableExists(table_name)

    def optimize(self, table_name: str) -> None:
        self._spark.sql(f"OPTIMIZE {table_name}")
        logger.info(f"Optimized {table_name}")

    def enable_cdf(self, table_name: str) -> None:
        self._spark.sql(
            f"ALTER TABLE {table_name} SET TBLPROPERTIES "
            f"(delta.enableChangeDataFeed = true)"
        )
        logger.info(f"Enabled CDF on {table_name}")