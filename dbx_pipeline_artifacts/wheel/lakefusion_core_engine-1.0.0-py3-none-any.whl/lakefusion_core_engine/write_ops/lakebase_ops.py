import logging
import time
from typing import Dict, List, Optional

from .base import WriteOperations
from .table_name_resolver import resolve_table_name, resolve_staging_table, to_pg_qualified

logger = logging.getLogger("WriteOps.Lakebase")


class LakebaseWriteOps(WriteOperations):
    """
    Lakebase Autoscale (PostgreSQL) write operations.

    Connects via OAuth token from the Databricks SDK (w.postgres.generate_database_credential).
    Tokens expire after 1 hour — automatic refresh on connection failure.

    All data movement uses df.write.format("jdbc") — distributed, parallel.
    Lightweight DDL and upsert SQL use psycopg.
    """

    def __init__(self, spark, params: dict):
        self._spark = spark
        self._entity = params.get("entity", "")
        self._instance_id = params.get("lakebase_instance_id", "")
        self._branch_id = params.get("lakebase_branch_id", "production")
        self._database = params.get("lakebase_database", "databricks_postgres")

        # Resolve endpoint and credentials
        self._host = None
        self._user = None
        self._token = None
        self._token_expiry = 0
        self._endpoint_name = None
        self._pg_conn = None

        self._init_connection()

    def _init_connection(self):
        """Discover endpoint host and generate initial OAuth token."""
        from databricks.sdk import WorkspaceClient
        self._ws = WorkspaceClient()
        self._user = self._ws.current_user.me().user_name

        # Get the primary endpoint for the branch
        self._endpoint_name = f"projects/{self._instance_id}/branches/{self._branch_id}/endpoints/ep-primary"

        try:
            endpoint = self._ws.postgres.get_endpoint(name=self._endpoint_name)
            self._host = endpoint.status.hosts.host
            logger.info(f"Lakebase endpoint resolved: {self._host}")
        except Exception as e:
            logger.error(f"Failed to get Lakebase endpoint: {e}")
            # Fallback: try REST API
            self._host = self._resolve_host_via_rest()

        self._refresh_token()
        logger.info(f"Lakebase connection initialized: {self._instance_id}/{self._branch_id}/{self._database}")

    def _resolve_host_via_rest(self) -> str:
        """Fallback: resolve endpoint host via REST API."""
        import os, requests
        host = os.environ.get("DATABRICKS_HOST", "")
        token = os.environ.get("DATABRICKS_TOKEN", "")
        try:
            resp = requests.get(
                f"{host}/api/2.0/postgres/{self._endpoint_name}",
                headers={"Authorization": f"Bearer {token}"},
                timeout=30,
            )
            resp.raise_for_status()
            data = resp.json()
            return data.get("status", {}).get("hosts", {}).get("host", "")
        except Exception as e:
            logger.error(f"REST fallback failed for endpoint resolution: {e}")
            raise RuntimeError(f"Cannot resolve Lakebase endpoint for {self._instance_id}/{self._branch_id}")

    def _refresh_token(self):
        """Generate a fresh OAuth token (valid for 1 hour)."""
        try:
            cred = self._ws.postgres.generate_database_credential(
                endpoint=self._endpoint_name
            )
            self._token = cred.token
            self._token_expiry = time.time() + 3500  # Refresh 100s before expiry
            logger.info("Lakebase OAuth token refreshed")
        except Exception as e:
            logger.error(f"Failed to generate Lakebase credential: {e}")
            raise

    def _ensure_token_fresh(self):
        """Refresh token if expired or about to expire."""
        if time.time() >= self._token_expiry:
            self._refresh_token()
            # Close existing pg connection so it reconnects with new token
            if self._pg_conn and not self._pg_conn.closed:
                self._pg_conn.close()
                self._pg_conn = None

    @property
    def _jdbc_url(self) -> str:
        return f"jdbc:postgresql://{self._host}:5432/{self._database}?sslmode=require"

    @property
    def _jdbc_props(self) -> dict:
        self._ensure_token_fresh()
        return {
            "user": self._user,
            "password": self._token,
            "driver": "org.postgresql.Driver",
            "batchsize": "10000",
            "numPartitions": "8",
            "ssl": "true",
            "sslmode": "require",
        }

    def _get_pg_connection(self):
        """Get or create a psycopg connection for DDL/upsert SQL."""
        self._ensure_token_fresh()
        if self._pg_conn is None or self._pg_conn.closed:
            import psycopg
            self._pg_conn = psycopg.connect(
                host=self._host,
                port=5432,
                dbname=self._database,
                user=self._user,
                password=self._token,
                sslmode="require",
                autocommit=False,
            )
        return self._pg_conn

    def _execute_sql(self, sql: str) -> None:
        """Execute a SQL statement via psycopg."""
        conn = self._get_pg_connection()
        with conn.cursor() as cur:
            cur.execute(sql)
        conn.commit()

    def _ensure_schema(self) -> None:
        """Create the entity schema if it doesn't exist."""
        self._execute_sql(f'CREATE SCHEMA IF NOT EXISTS "{self._entity}"')

    def _resolve(self, uc_table_name: str) -> str:
        """Resolve UC table name to qualified PostgreSQL name."""
        schema, table = resolve_table_name(uc_table_name, self._entity)
        return to_pg_qualified(schema, table)

    def _resolve_staging(self, uc_table_name: str) -> str:
        """Resolve UC table name to qualified PostgreSQL staging table name."""
        schema, table = resolve_staging_table(uc_table_name, self._entity)
        return to_pg_qualified(schema, table)

    # ---- WriteOperations implementation ----

    def create_table(self, df, table_name: str, enable_cdf: bool = False) -> None:
        self._ensure_schema()
        pg_table = self._resolve(table_name)
        self._execute_sql(f"DROP TABLE IF EXISTS {pg_table} CASCADE")

        df.write.format("jdbc") \
            .option("url", self._jdbc_url) \
            .option("dbtable", pg_table) \
            .options(**self._jdbc_props) \
            .mode("overwrite") \
            .save()

        logger.info(f"Created table {pg_table} (CDF=N/A for Lakebase)")

    def overwrite(self, df, table_name: str) -> None:
        self._ensure_schema()
        pg_table = self._resolve(table_name)

        df.write.format("jdbc") \
            .option("url", self._jdbc_url) \
            .option("dbtable", pg_table) \
            .options(**self._jdbc_props) \
            .mode("overwrite") \
            .save()

        logger.info(f"Overwrote {pg_table}")

    def append(self, df, table_name: str) -> None:
        self._ensure_schema()
        pg_table = self._resolve(table_name)

        df.write.format("jdbc") \
            .option("url", self._jdbc_url) \
            .option("dbtable", pg_table) \
            .options(**self._jdbc_props) \
            .mode("append") \
            .save()

        logger.info(f"Appended to {pg_table}")

    def merge(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        when_matched: Optional[Dict] = None,
        when_not_matched: str = "insert",
    ) -> None:
        self._ensure_schema()
        pg_table = self._resolve(table_name)
        stg_table = self._resolve_staging(table_name)

        # Step 1: Write source df to staging table via Spark JDBC (distributed)
        df.write.format("jdbc") \
            .option("url", self._jdbc_url) \
            .option("dbtable", stg_table) \
            .options(**self._jdbc_props) \
            .mode("overwrite") \
            .save()

        # Step 2: Upsert from staging → target via INSERT ON CONFLICT (server-side)
        columns = [f.name for f in df.schema.fields]
        col_list = ", ".join(f'"{c}"' for c in columns)
        conflict_keys = ", ".join(f'"{k}"' for k in merge_keys)

        if when_matched is not None:
            update_cols = [f'"{c}" = EXCLUDED."{c}"' for c in when_matched.keys()]
        else:
            non_key_cols = [c for c in columns if c not in merge_keys]
            update_cols = [f'"{c}" = EXCLUDED."{c}"' for c in non_key_cols]

        update_set = ", ".join(update_cols)

        upsert_sql = f"""
            INSERT INTO {pg_table} ({col_list})
            SELECT {col_list} FROM {stg_table}
            ON CONFLICT ({conflict_keys}) DO UPDATE SET {update_set}
        """
        self._execute_sql(upsert_sql)

        # Step 3: Cleanup staging
        self._execute_sql(f"DROP TABLE IF EXISTS {stg_table}")

        logger.info(f"Merged into {pg_table} on {merge_keys}")

    def merge_with_delete(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        delete_condition: str,
    ) -> None:
        self.merge(df, table_name, merge_keys)
        pg_table = self._resolve(table_name)
        self._execute_sql(f"DELETE FROM {pg_table} WHERE {delete_condition}")
        logger.info(f"Merge+delete into {pg_table} on {merge_keys}")

    def sql_merge(
        self,
        sql_string: str,
        table_name: str,
        source_df=None,
        merge_keys: Optional[List[str]] = None,
    ) -> None:
        if source_df is not None and merge_keys:
            self.merge(source_df, table_name, merge_keys)
        else:
            logger.warning(
                f"sql_merge called without source_df/merge_keys for {table_name}. "
                f"Cannot translate Delta SQL to PostgreSQL. Skipping."
            )

    def table_exists(self, table_name: str) -> bool:
        schema, table = resolve_table_name(table_name, self._entity)
        conn = self._get_pg_connection()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT EXISTS(SELECT 1 FROM information_schema.tables "
                "WHERE table_schema = %s AND table_name = %s)",
                (schema, table),
            )
            result = cur.fetchone()[0]
        return result

    def optimize(self, table_name: str) -> None:
        pg_table = self._resolve(table_name)
        self._execute_sql(f"ANALYZE {pg_table}")
        logger.info(f"Analyzed {pg_table} (optimize is no-op for Lakebase)")

    def enable_cdf(self, table_name: str) -> None:
        logger.info(f"CDF is not applicable for Lakebase — skipped for {table_name}")

    def begin_transaction(self) -> None:
        conn = self._get_pg_connection()
        conn.autocommit = False
        logger.info("Lakebase transaction started")

    def commit_transaction(self) -> None:
        if self._pg_conn and not self._pg_conn.closed:
            self._pg_conn.commit()
            logger.info("Lakebase transaction committed")

    def rollback_transaction(self) -> None:
        if self._pg_conn and not self._pg_conn.closed:
            self._pg_conn.rollback()
            logger.info("Lakebase transaction rolled back")