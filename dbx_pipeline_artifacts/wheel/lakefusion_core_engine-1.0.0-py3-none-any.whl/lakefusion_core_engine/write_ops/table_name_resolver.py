"""
Resolves Unity Catalog 3-level table names to Lakebase (PostgreSQL) 2-level names.

One schema per entity:
  catalog.gold.acme_master_prod           → schema="acme", table="master_prod"
  catalog.silver.acme_unified_prod        → schema="acme", table="unified_prod"
  catalog.gold.acme_master_prod_dnb_duns  → schema="acme", table="master_prod_dnb_duns"
"""


def resolve_table_name(uc_table_name: str, entity: str) -> tuple:
    """
    Convert a Unity Catalog table path to (pg_schema, pg_table).

    Args:
        uc_table_name: Full UC path, e.g. "lakefusion_ai_staging.gold.acme_master_prod"
        entity: Entity name, e.g. "acme"

    Returns:
        Tuple of (schema_name, table_name) for PostgreSQL.
    """
    parts = uc_table_name.split(".")
    if len(parts) != 3:
        raise ValueError(
            f"Expected 3-part UC table name (catalog.schema.table), got: {uc_table_name}"
        )

    full_table_name = parts[2]

    # Strip entity prefix + underscore from the table name
    prefix = f"{entity}_"
    if full_table_name.startswith(prefix):
        pg_table = full_table_name[len(prefix):]
    else:
        pg_table = full_table_name

    return (entity, pg_table)


def resolve_staging_table(uc_table_name: str, entity: str) -> tuple:
    """
    Get staging table name for merge operations.

    Args:
        uc_table_name: Full UC path
        entity: Entity name

    Returns:
        Tuple of (schema_name, staging_table_name)
    """
    schema, table = resolve_table_name(uc_table_name, entity)
    return (schema, f"_stg_{table}")


def to_pg_qualified(schema: str, table: str) -> str:
    """Build a fully qualified PostgreSQL table reference."""
    return f'"{schema}"."{table}"'