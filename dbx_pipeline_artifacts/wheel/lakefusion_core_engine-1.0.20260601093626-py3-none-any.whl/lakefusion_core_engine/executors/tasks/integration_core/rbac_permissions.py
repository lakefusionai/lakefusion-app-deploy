"""
RBAC Permissions Executor for integration core.

Applies RBAC permissions to Databricks resources during pipeline runs by iterating
the flat grant rows produced by `rbac_config_loader.load_grants()`. This is the
idempotent re-grant pass: entity-create-time provisioning handles schemas/volumes
(see `RBACProvisioningService`), and this executor re-applies all grants that
require resources only created during pipeline execution (prod/experiment tables,
indexes, jobs, endpoints, UC models).

The loader's flat-row shape is the same tuple the executor consumes here, so a
future Delta-backed loader requires no change to this file.

Dispatch by resource_type:
    schema / table / index   → w.grants.update (UC)
    volume                   → w.grants.update (UC, SecurableType.VOLUME)
    job                      → set_job_permissions_with_owner (sentinel: current job_id)
    endpoint                 → grant_serving_endpoint_permissions
    uc_model                 → grant_uc_model_privileges (SQL)
"""

from collections import defaultdict
from typing import Any, Dict, List

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import catalog
from databricks.sdk.service.catalog import Privilege
from databricks.sdk.errors import NotFound

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, ValidationResult

from lakefusion_core_engine.config.rbac_config_loader import (
    load_grants,
    resolve_group_name,
    entity_group_names,
    GrantRow,
    JOB_SENTINEL,
    MODEL_ENDPOINT_SENTINEL,
    VECTOR_ENDPOINT_SENTINEL,
)
from lakefusion_core_engine.utils.databricks_groups import (
    ensure_account_group,
    get_job_owner_id,
    grant_uc_object_permissions,
    set_job_permissions_with_owner,
    grant_serving_endpoint_permissions,
    grant_vector_search_endpoint_permissions,
    grant_uc_model_privileges,
    add_group_members_by_email,
)


_VIEW_WRITE_PRIVILEGES = {"UPDATE", "INSERT", "DELETE", "MERGE", "MODIFY"}

_RESOURCE_TYPE_TO_SECURABLE = {
    "catalog": catalog.SecurableType.CATALOG,
    "schema": catalog.SecurableType.SCHEMA,
    "table": catalog.SecurableType.TABLE,
    "index": catalog.SecurableType.TABLE,
    "volume": catalog.SecurableType.VOLUME,
}


class RBACPermissionsExecutor(BaseStepTask):
    """Re-grants RBAC permissions across Databricks resources for a pipeline run."""

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.w = None
        self.api = None
        self.job_id = None
        self.owner_user_id = None

    @property
    def entity(self):
        return self.context.entity

    @property
    def experiment_id(self):
        return self.context.experiment_id or ''

    @property
    def catalog_name(self):
        return self.context.catalog_name

    @property
    def pipeline_type(self) -> str:
        return self.context.params.get("pipeline_type", "integration")

    @property
    def llm_model(self):
        return self.context.params.get("llm_model_parsed")

    @property
    def embedding_model(self):
        return self.context.params.get("embedding_model_parsed")

    @property
    def vs_endpoint(self):
        return self.context.params.get("vs_endpoint")

    def pre_execute(self) -> None:
        print("=" * 80)
        print("RBAC PERMISSIONS")
        print("=" * 80)
        print(f"  Entity: {self.entity}")
        print(f"  Experiment ID: {self.experiment_id or 'prod'}")
        print(f"  Catalog: {self.catalog_name}")
        print(f"  Pipeline type: {self.pipeline_type}")
        print("=" * 80)

        self.w = WorkspaceClient()
        self.api = self.w.api_client

        if self.context.dbutils:
            ctx = (
                self.context.dbutils.notebook.entry_point
                .getDbutils().notebook().getContext()
            )
            self.job_id = (
                ctx.jobId().get() if ctx.jobId().isDefined() else None
            )
            print(f"  Job ID: {self.job_id}")

    def _group_exists(self, group_name):
        resp = self.api.do(
            "GET",
            "/api/2.0/account/scim/v2/Groups",
            query={"filter": f'displayName eq "{group_name}"'},
        )
        return bool(resp.get("Resources"))

    def _check_uc_grants_for_principal(self, full_name, securable_type, principal, required_privileges):
        try:
            grants = self.w.grants.get(full_name=full_name, securable_type=securable_type)
            for assignment in (grants.privilege_assignments or []):
                if assignment.principal == principal:
                    existing = {p.privilege.value for p in (assignment.privileges or [])}
                    if set(required_privileges).issubset(existing):
                        return True
            return False
        except Exception:
            return False

    def _pre_flight_check(self, grants_by_resource):
        """Short-circuit when per-entity groups exist, creators are members, and a
        representative schema grant is already in place."""
        groups = entity_group_names(self.entity)
        dev_group = groups["developer"]
        steward_group = groups["data_steward"]

        if not self._group_exists(dev_group):
            print(f"  Pre-flight: Group '{dev_group}' does not exist — will create")
            return False
        if not self._group_exists(steward_group):
            print(f"  Pre-flight: Group '{steward_group}' does not exist — will create")
            return False
        print(f"  Pre-flight: Both entity groups already exist")

        creator_emails = self.context.params.get('creator_emails', [])
        if creator_emails:
            resp = self.api.do(
                "GET",
                "/api/2.0/account/scim/v2/Groups",
                query={"filter": f'displayName eq "{dev_group}"'},
            )
            resources = resp.get("Resources", [])
            member_count = len(resources[0].get("members", [])) if resources else 0
            if member_count == 0:
                print(f"  Pre-flight: Group '{dev_group}' has no members — will add creators")
                return False

        # Sample one schema grant as a cheap liveness probe.
        schema_rows = grants_by_resource.get("schema", [])
        if schema_rows:
            probe = schema_rows[0]
            if not self._check_uc_grants_for_principal(
                probe.full_name, catalog.SecurableType.SCHEMA,
                probe.group_name, probe.privileges
            ):
                print(f"  Pre-flight: Schema permissions not yet granted — will apply")
                return False

        print(f"  Pre-flight: All RBAC permissions already in place")
        return True

    # ── Step 1 ───────────────────────────────────────────────────────────

    @step(order=1, name="Ensure Entity Groups",
          returns="dict — created group IDs")
    def step_ensure_entity_groups(self) -> Dict[str, Any]:
        """Create/verify per-entity dev/steward groups. Admin group is bootstrapped
        out-of-band (via migration), not here."""
        owner_user_id = None
        if self.job_id:
            owner_user_id, owner_name = get_job_owner_id(self.w, self.job_id)
            if owner_user_id:
                print(f"  Job owner: {owner_name} (id={owner_user_id})")
        self.owner_user_id = owner_user_id

        groups = entity_group_names(self.entity)
        created_groups = {}
        for grp_name in groups.values():
            group_id = ensure_account_group(self.api, grp_name, owner_user_id=owner_user_id)
            created_groups[grp_name] = group_id

        creator_emails = self.context.params.get('creator_emails', [])
        if creator_emails:
            print(f"  Adding creator emails to groups: {creator_emails}")
            for grp_name in groups.values():
                add_group_members_by_email(self.api, self.w, grp_name, creator_emails)

        return created_groups

    # ── Step 2 ───────────────────────────────────────────────────────────

    @step(order=2, name="Apply UC Grants (schema/table/index/volume)",
          returns="dict — grant counts by resource type")
    def step_apply_uc_grants(self, grants_by_resource) -> Dict[str, Any]:
        """Iterate flat grant rows and apply Unity Catalog grants per resource."""
        counts = defaultdict(lambda: {"granted": 0, "skipped": 0})

        for resource_type in ("schema", "table", "index", "volume"):
            rows: List[GrantRow] = grants_by_resource.get(resource_type, [])
            securable = _RESOURCE_TYPE_TO_SECURABLE[resource_type]

            for row in rows:
                privileges = self._effective_privileges(row)
                result = grant_uc_object_permissions(
                    self.w, row.full_name, securable,
                    {row.group_name: privileges},
                )
                counts[resource_type]["granted"] += len(result["results"])
                counts[resource_type]["skipped"] += len(result["skipped"])

            print(
                f"  {resource_type}: {counts[resource_type]['granted']} granted, "
                f"{counts[resource_type]['skipped']} skipped"
            )

        return dict(counts)

    def _effective_privileges(self, row: GrantRow) -> List[str]:
        """Drop write privileges on rows that target views (best-effort; views can't
        hold MODIFY/INSERT/UPDATE/DELETE/MERGE). Only applies if `w.tables.get` confirms
        the object is a VIEW — otherwise passes through unchanged."""
        if row.resource_type != "table":
            return row.privileges
        try:
            info = self.w.tables.get(row.full_name)
            if getattr(info, "table_type", None) and str(info.table_type).upper().endswith("VIEW"):
                return [p for p in row.privileges if p not in _VIEW_WRITE_PRIVILEGES]
        except Exception:
            pass
        return row.privileges

    # ── Step 3 ───────────────────────────────────────────────────────────

    @step(order=3, name="Grant Job Permissions",
          returns="dict — job permission results")
    def step_grant_job_permissions(self, grants_by_resource) -> Dict[str, Any]:
        rows: List[GrantRow] = grants_by_resource.get("job", [])
        if not self.job_id or not rows:
            print("  No job_id or job rows — skipping")
            return {'skipped': True}

        # Collapse rows to {group_name: [privileges...]} for the helper.
        group_perms: Dict[str, List[str]] = {}
        for row in rows:
            if row.full_name != JOB_SENTINEL:
                continue
            group_perms.setdefault(row.group_name, []).extend(row.privileges)

        if not group_perms:
            return {'skipped': True}

        set_job_permissions_with_owner(self.w, self.job_id, group_perms)
        return {'job_id': self.job_id, 'groups': list(group_perms.keys())}

    # ── Step 4 ───────────────────────────────────────────────────────────

    @step(order=4, name="Grant Endpoint Permissions",
          returns="dict — endpoint permission results")
    def step_grant_endpoint_permissions(self, grants_by_resource) -> Dict[str, Any]:
        rows: List[GrantRow] = grants_by_resource.get("endpoint", [])
        if not rows:
            return {'skipped': True}

        # Endpoint rows use MODEL_ENDPOINT_SENTINEL — the concrete endpoint name is the
        # parsed model name at runtime.
        group_perms: Dict[str, List[str]] = {}
        for row in rows:
            if row.full_name != MODEL_ENDPOINT_SENTINEL:
                continue
            group_perms.setdefault(row.group_name, []).extend(row.privileges)

        model_names = [m for m in (self.llm_model, self.embedding_model) if m]
        for model_name in model_names:
            grant_serving_endpoint_permissions(self.w, model_name, group_perms)

        return {'endpoints_processed': model_names}

    # ── Step 4b ──────────────────────────────────────────────────────────

    @step(order=45, name="Grant Vector Endpoint Permissions",
          returns="dict — vector endpoint permission results")
    def step_grant_vector_endpoint_permissions(self, grants_by_resource) -> Dict[str, Any]:
        rows: List[GrantRow] = grants_by_resource.get("vector_endpoint", [])
        if not rows or not self.vs_endpoint:
            return {'skipped': True}

        group_perms: Dict[str, List[str]] = {}
        for row in rows:
            if row.full_name != VECTOR_ENDPOINT_SENTINEL:
                continue
            group_perms.setdefault(row.group_name, []).extend(row.privileges)

        if not group_perms:
            return {'skipped': True}

        grant_vector_search_endpoint_permissions(self.w, self.vs_endpoint, group_perms)
        return {'vector_endpoint': self.vs_endpoint, 'groups': list(group_perms.keys())}

    # ── Step 5 ───────────────────────────────────────────────────────────

    @step(order=5, name="Grant UC Model Permissions",
          returns="dict — UC model permission results")
    def step_grant_uc_model_permissions(self, grants_by_resource) -> Dict[str, Any]:
        rows: List[GrantRow] = grants_by_resource.get("uc_model", [])
        if not rows:
            return {'skipped': True}

        processed = []
        for row in rows:
            # Model is baked into row.full_name at load time.
            grant_uc_model_privileges(
                self.spark, row.full_name, row.group_name, row.privileges
            )
            processed.append(row.full_name)

        return {'models_processed': processed}

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def _load_grants_grouped(self) -> Dict[str, List[GrantRow]]:
        """Load all grants that apply to the current pipeline run and group by
        resource_type. `applies_to` spans always+prod+experiment so the pipeline re-grants
        every resource it owns."""
        rows = load_grants(
            entity=self.entity,
            experiment_id=self.experiment_id,
            catalog=self.catalog_name,
            pipeline_type=self.pipeline_type,
            applies_to={"always", "prod", "experiment"},
            llm_model=self.llm_model,
            embedding_model=self.embedding_model,
        )

        # Honour experiment scoping: `prod` rows only fire when experiment_id == 'prod';
        # `experiment` rows only fire when experiment_id != 'prod'.
        is_prod = (self.experiment_id or "prod") == "prod"
        filtered = []
        for r in rows:
            if r.applies_to == "prod" and not is_prod:
                continue
            if r.applies_to == "experiment" and is_prod:
                continue
            filtered.append(r)

        grouped: Dict[str, List[GrantRow]] = defaultdict(list)
        for r in filtered:
            grouped[r.resource_type].append(r)
        return dict(grouped)

    def execute(self) -> TaskResult:
        grants_by_resource = self._load_grants_grouped()

        if self._pre_flight_check(grants_by_resource):
            print("\n  All RBAC groups and permissions already in place — nothing to do.")
            return TaskResult.success(
                message=f"RBAC permissions already in place for entity '{self.entity}'",
                task_name=self.context.task_name,
                metrics={
                    'entity': self.entity,
                    'experiment_id': self.experiment_id,
                    'steps_completed': 0,
                    'already_in_place': True,
                },
            )

        self.step_ensure_entity_groups()
        self.step_apply_uc_grants(grants_by_resource)
        self.step_grant_job_permissions(grants_by_resource)
        self.step_grant_endpoint_permissions(grants_by_resource)
        self.step_grant_vector_endpoint_permissions(grants_by_resource)
        self.step_grant_uc_model_permissions(grants_by_resource)

        return TaskResult.success(
            message=f"RBAC permissions granted for entity '{self.entity}'",
            task_name=self.context.task_name,
            metrics={
                'entity': self.entity,
                'experiment_id': self.experiment_id,
                'steps_completed': len(self.get_completed_steps()),
            },
        )

    def validate(self, result: TaskResult) -> TaskResult:
        if result.is_failed:
            return result
        result.add_validation(ValidationResult(
            passed=True,
            message="RBAC permissions granted successfully",
            actual=self.entity,
        ))
        return result

    def post_execute(self, result: TaskResult) -> None:
        print("\n" + "=" * 80)
        print("RBAC PERMISSIONS — COMPLETE")
        print("=" * 80)
        if result.is_success:
            metrics = result.metrics
            print(f"  Entity: {metrics.get('entity')}")
            print(f"  Experiment ID: {metrics.get('experiment_id', 'prod')}")
            print(f"  Steps completed: {metrics.get('steps_completed')}")

    def on_failure(self, result: TaskResult, error=None) -> None:
        print(f"RBAC permissions failed: {result.message}")
        if result.errors:
            for err in result.errors:
                print(f"  Error: {err}")
