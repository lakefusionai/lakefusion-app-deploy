import logging
import time

from .base import ReadOperations

logger = logging.getLogger("ReadOps.Lakebase")


class LakebaseReadOps(ReadOperations):
    """
    Read operations against Lakebase Postgres synced tables.

    Synced tables (created by LakebaseWriteOps.create_table) mirror UC Delta
    tables into Postgres. This class reads those Postgres tables directly via
    JDBC for low-latency UI / API access.

    UC → PG name mapping (Lakebase synced table convention):
        catalog.schema.table  →  "schema"."table_synced"
    """

    def __init__(self, spark, params: dict):
        self._spark = spark
        self._instance_id = params.get("lakebase_instance_id", "")
        self._branch_id = params.get("lakebase_branch_id", "production")
        self._database = params.get("lakebase_database", "databricks_postgres")

        # Connection state — lazily initialized on first read
        self._host = None
        self._user = None
        self._token = None
        self._token_expiry = 0
        self._endpoint_name = None
        self._ws = None
        self._dbx_host = None

    # ---- Connection setup --------------------------------------------------

    def _init_connection(self):
        from databricks.sdk import WorkspaceClient

        self._ws = WorkspaceClient()
        self._user = self._ws.current_user.me().user_name
        self._dbx_host = self._ws.config.host.rstrip("/")

        endpoints_data = self._api_get(
            f"projects/{self._instance_id}/branches/{self._branch_id}/endpoints"
        )
        primary_ep = None
        for ep in endpoints_data.get("endpoints", []):
            if ep.get("status", {}).get("endpoint_type", "") == "ENDPOINT_TYPE_READ_WRITE":
                primary_ep = ep
                break
        if not primary_ep and endpoints_data.get("endpoints"):
            primary_ep = endpoints_data["endpoints"][0]
        if not primary_ep:
            raise RuntimeError(f"No endpoints found for {self._instance_id}/{self._branch_id}")

        self._endpoint_name = primary_ep.get("name", "")
        self._host = primary_ep.get("status", {}).get("hosts", {}).get("host", "")
        if not self._host:
            raise RuntimeError(f"Cannot resolve Lakebase endpoint host for {self._endpoint_name}")

        self._refresh_token()
        logger.info(f"Lakebase read connection initialized: {self._host}/{self._database}")

    def _get_dbx_token(self) -> str:
        header = self._ws.config.authenticate()
        return header.get("Authorization", "").replace("Bearer ", "")

    def _api_get(self, path: str) -> dict:
        import requests
        resp = requests.get(
            f"{self._dbx_host}/api/2.0/postgres/{path}",
            headers={"Authorization": f"Bearer {self._get_dbx_token()}"},
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()

    def _api_post(self, path: str, body: dict = None) -> dict:
        import requests
        resp = requests.post(
            f"{self._dbx_host}/api/2.0/postgres/{path}",
            headers={"Authorization": f"Bearer {self._get_dbx_token()}"},
            json=body or {},
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()

    def _refresh_token(self):
        data = self._api_post("credentials", {"endpoint": self._endpoint_name})
        self._token = data.get("token", "")
        self._token_expiry = time.time() + 3500  # refresh 100s before 1h expiry

    def _ensure_connection(self):
        if self._host is None:
            self._init_connection()
        elif time.time() >= self._token_expiry:
            self._refresh_token()

    @property
    def _jdbc_url(self) -> str:
        return f"jdbc:postgresql://{self._host}:5432/{self._database}?sslmode=require"

    @property
    def _jdbc_props(self) -> dict:
        self._ensure_connection()
        return {
            "user": self._user,
            "password": self._token,
            "driver": "org.postgresql.Driver",
            "ssl": "true",
            "sslmode": "require",
        }

    # ---- Name resolution ---------------------------------------------------

    def _to_pg_table(self, uc_table_name: str) -> str:
        """UC `catalog.schema.table` → PG `"schema"."table_synced"`."""
        parts = uc_table_name.split(".")
        if len(parts) != 3:
            raise ValueError(
                f"Expected 3-part UC table name (catalog.schema.table), got: {uc_table_name}"
            )
        _, schema, table = parts
        return f'"{schema}"."{table}_synced"'

    # ---- ReadOperations interface ------------------------------------------

    def read(self, table_name: str):
        """Read the Postgres synced table via JDBC and return a DataFrame."""
        self._ensure_connection()
        pg_table = self._to_pg_table(table_name)
        return self._spark.read.format("jdbc") \
            .option("url", self._jdbc_url) \
            .option("dbtable", pg_table) \
            .options(**self._jdbc_props) \
            .load()