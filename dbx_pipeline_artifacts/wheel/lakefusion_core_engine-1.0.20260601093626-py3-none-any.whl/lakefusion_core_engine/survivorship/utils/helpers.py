"""
Helper utilities for survivorship engine.
Includes type checking functions and common utilities.
"""

from typing import Any
from datetime import datetime, date
import math


def is_numeric_type(datatype: str) -> bool:
    """
    Check if the given datatype string represents a numeric type.
    
    Args:
        datatype: String representation of data type
        
    Returns:
        True if numeric type, False otherwise
    """
    numeric_types = [
        'int', 'integer', 'long', 'bigint', 'float', 'double', 'decimal', 
        'numeric', 'smallint', 'tinyint', 'real', 'double precision'
    ]
    datatype_lower = datatype.lower()
    return any(numeric_type in datatype_lower for numeric_type in numeric_types)


def is_integer_type(datatype: str) -> bool:
    """
    Check if the given datatype string represents an integer type (not float/decimal).
    
    Args:
        datatype: String representation of data type
        
    Returns:
        True if integer type, False otherwise
    """
    integer_types = ['int', 'integer', 'long', 'bigint', 'smallint', 'tinyint']
    float_types = ['float', 'double', 'decimal', 'numeric', 'real', 'precision']
    datatype_lower = datatype.lower()
    
    # Check if it's a float type first (to exclude "double precision", etc.)
    if any(float_type in datatype_lower for float_type in float_types):
        return False
    
    return any(int_type in datatype_lower for int_type in integer_types)


def is_string_type(datatype: str) -> bool:
    """
    Check if the given datatype string represents a string type.
    
    Args:
        datatype: String representation of data type
        
    Returns:
        True if string type, False otherwise
    """
    string_types = ['string', 'varchar', 'char', 'text', 'nvarchar', 'nchar']
    return any(string_type in datatype.lower() for string_type in string_types)


def is_timestamp_type(datatype: str) -> bool:
    """
    Check if the given datatype string represents a timestamp/date type.
    
    Args:
        datatype: String representation of data type
        
    Returns:
        True if timestamp/date type, False otherwise
    """
    timestamp_types = ['timestamp', 'date', 'datetime']
    return any(timestamp_type in datatype.lower() for timestamp_type in timestamp_types)


def is_null_or_empty(value: Any) -> bool:
    """
    Check if a value is None, empty string, or whitespace-only string.
    
    Args:
        value: Value to check
        
    Returns:
        True if None, empty string, or whitespace-only string, False otherwise
        
    Note:
        - Numeric zero (0, 0.0) is NOT considered null/empty
        - Boolean False is NOT considered null/empty
    """
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip() == ""
    return False

def safe_str(value: Any) -> str:
    """
    Safely convert a value to string, handling None and special types.
    
    Handles datetime/date objects properly by converting to ISO format.
    
    Args:
        value: Value to convert
        
    Returns:
        String representation or empty string if None
    """
    if value is None:
        return ""
    
    # Handle datetime and date objects
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    elif isinstance(value, date):
        return value.strftime("%Y-%m-%d")
    
    # Handle objects with isoformat method (like pandas Timestamp)
    if hasattr(value, 'isoformat'):
        try:
            iso_str = value.isoformat()
            # Replace 'T' with space for consistency
            return iso_str.replace('T', ' ').split('.')[0]  # Remove microseconds
        except:
            pass
    
    # Default string conversion
    return str(value)


def convert_to_native_type(value: Any, datatype: str) -> Any:
    """
    Convert a value to its native Python type based on the datatype.
    
    This is used to ensure values are returned in their proper type
    rather than always as strings.
    
    Args:
        value: The value to convert
        datatype: The target datatype string
        
    Returns:
        The value converted to the appropriate Python type
    """
    if value is None:
        return None
    
    # If value is already the correct type, return as-is
    if is_numeric_type(datatype):
        if isinstance(value, (int, float)):
            # For integer types, ensure we return an integer if possible
            if is_integer_type(datatype):
                try:
                    # Check if it's a whole number
                    if isinstance(value, float) and value.is_integer():
                        return int(value)
                    elif isinstance(value, int):
                        return value
                    else:
                        # Has decimal portion - return as float, let caller handle
                        return value
                except (ValueError, TypeError, OverflowError):
                    return value
            return value
        
        # Try to convert string to number
        if isinstance(value, str):
            try:
                if is_integer_type(datatype):
                    # Try float first to handle "35.5" then convert to int
                    float_val = float(value)
                    if float_val.is_integer():
                        return int(float_val)
                    # Has decimal portion - this is a data issue, return the float
                    return float_val
                else:
                    return float(value)
            except (ValueError, TypeError):
                return value
    
    elif is_timestamp_type(datatype):
        # Return datetime objects as-is, or parse strings
        if isinstance(value, (datetime, date)):
            return value
        if isinstance(value, str):
            # Try to parse common formats
            for fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"]:
                try:
                    return datetime.strptime(value, fmt)
                except ValueError:
                    continue
            # Return original string if can't parse
            return value
    
    # For strings and other types, return as-is
    return value


def round_if_integer_type(value: Any, datatype: str) -> Any:
    """
    Round a numeric value to integer if the target datatype is an integer type.
    
    This handles the case where aggregation produces averages like 35.5 for
    integer columns - we round to the nearest integer.
    
    Args:
        value: The numeric value
        datatype: The target datatype string
        
    Returns:
        Rounded integer if integer type, original value otherwise
    """
    if value is None:
        return None
    
    if is_integer_type(datatype) and isinstance(value, (int, float)):
        try:
            # Round to nearest integer
            return int(round(value))
        except (ValueError, TypeError, OverflowError):
            return value
    
    return value

def is_boolean_type(datatype: str) -> bool:
    """
    Check if datatype is a boolean type.
    
    Args:
        datatype: Data type string (e.g., "BOOLEAN", "BOOL")
        
    Returns:
        True if boolean type, False otherwise
    """
    if not datatype:
        return False
    
    boolean_types = {
        'boolean', 'bool'
    }
    
    return datatype.lower().strip() in boolean_types