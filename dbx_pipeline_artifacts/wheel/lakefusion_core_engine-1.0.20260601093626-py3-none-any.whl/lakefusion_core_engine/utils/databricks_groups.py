"""
Shared utility functions for Databricks group management and permission grants.

This module is the **source of truth** for both backend-safe SCIM/UC helpers
(``ensure_account_group``, ``grant_uc_object_permissions``,
``add_group_members_by_email``) and pipeline-only helpers
(``set_job_permissions_with_owner``, ``grant_serving_endpoint_permissions``,
``grant_vector_search_endpoint_permissions``, ``grant_uc_model_privileges``,
``get_job_owner_id``). Backend services import the same names through
``lakefusion_utility.utils.databricks_groups`` (a thin re-export shim) so that
``lakefusion_core_engine`` has no inbound dependency on ``lakefusion_utility``
and can be installed standalone in notebooks.
"""

from databricks.sdk.service import catalog, jobs
from databricks.sdk.service.catalog import Privilege
from databricks.sdk.service.jobs import JobPermissionLevel
from databricks.sdk.errors import NotFound, DatabricksError
from databricks.sdk.service.iam import AccessControlRequest, PermissionLevel


def ensure_account_group(api, group_display_name, owner_user_id=None):
    """Create an account-level group via workspace-proxied account SCIM API
    if it doesn't exist, assign it to the workspace, and optionally add
    the owner as initial member. Idempotent — safe to call on every run.

    Args:
        api: WorkspaceClient.api_client instance
        group_display_name: Name of the group to create
        owner_user_id: Optional user/SPN ID to add as initial member

    Returns:
        group_id: The ID of the created/existing group
    """
    resp = api.do(
        "GET",
        "/api/2.0/account/scim/v2/Groups",
        query={"filter": f'displayName eq "{group_display_name}"'},
    )
    resources = resp.get("Resources", [])

    if resources:
        group_id = resources[0]["id"]
        print(f"  Account group '{group_display_name}' already exists (id={group_id})")
    else:
        created = api.do(
            "POST",
            "/api/2.0/account/scim/v2/Groups",
            body={"displayName": group_display_name},
        )
        group_id = created["id"]
        print(f"  Created account group '{group_display_name}' (id={group_id})")

    api.do(
        "PUT",
        f"/api/2.0/preview/permissionassignments/principals/{group_id}",
        body={"permissions": ["USER"]},
    )
    print(f"  Assigned '{group_display_name}' to workspace")

    if owner_user_id:
        fresh = api.do(
            "GET",
            "/api/2.0/account/scim/v2/Groups",
            query={"filter": f'displayName eq "{group_display_name}"'},
        )
        fresh_resources = fresh.get("Resources", [])
        existing_member_ids = {
            str(m.get("value"))
            for m in (fresh_resources[0].get("members", []) if fresh_resources else [])
        }

        if str(owner_user_id) not in existing_member_ids:
            api.do(
                "PATCH",
                f"/api/2.0/account/scim/v2/Groups/{group_id}",
                body={
                    "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
                    "Operations": [
                        {
                            "op": "add",
                            "path": "members",
                            "value": [{"value": str(owner_user_id)}],
                        }
                    ],
                },
            )
            print(f"  Added owner (id={owner_user_id}) to '{group_display_name}'")
        else:
            print(f"  Owner already a member of '{group_display_name}'")

    return group_id


def grant_uc_object_permissions(w, full_name, securable_type, group_permissions):
    """Grant UC permissions on a securable object to multiple groups.

    Handles both regular tables and views — for views, MODIFY and other
    write privileges are automatically filtered out.

    Args:
        w: WorkspaceClient instance
        full_name: Fully qualified object name (e.g. catalog.schema.table)
        securable_type: catalog.SecurableType enum value
        group_permissions: Dict mapping group_name to list of privilege strings
            e.g. {"LAKEFUSION_ADMIN": ["ALL_PRIVILEGES"],
                   "DEVELOPER_entity": ["MODIFY", "SELECT"]}

    Returns:
        Dict with 'results' and 'skipped' lists
    """
    results, skipped = [], []

    for grp, permission_list in group_permissions.items():
        try:
            if permission_list == ["ALL_PRIVILEGES"]:
                add_privs = [catalog.Privilege.ALL_PRIVILEGES]
            else:
                add_privs = [catalog.Privilege[p] for p in permission_list]

            w.grants.update(
                full_name=full_name,
                securable_type=securable_type,
                changes=[
                    catalog.PermissionsChange(
                        add=add_privs,
                        principal=grp,
                    )
                ],
            )
            results.append({full_name: grp})
        except NotFound:
            skipped.append(full_name)
        except Exception as e:
            skipped.append(full_name)
            print(f"  Failed to grant permissions on {full_name} to {grp}: {e}")

    return {'results': results, 'skipped': skipped}


def add_group_members_by_email(api, w, group_name, emails):
    """Add users to a group by their email addresses.

    Looks up each email via the SCIM Users API to get the user ID,
    then adds them to the group if not already a member.

    Args:
        api: WorkspaceClient.api_client instance
        w: WorkspaceClient instance
        group_name: Name of the group to add members to
        emails: List of email addresses to add

    Returns:
        Dict with 'added' and 'already_member' lists
    """
    if not emails:
        return {'added': [], 'already_member': []}

    resp = api.do(
        "GET",
        "/api/2.0/account/scim/v2/Groups",
        query={"filter": f'displayName eq "{group_name}"'},
    )
    resources = resp.get("Resources", [])
    if not resources:
        print(f"  Group '{group_name}' not found — cannot add members")
        return {'added': [], 'already_member': [], 'error': 'group_not_found'}

    group_id = resources[0]["id"]
    existing_member_ids = {
        str(m.get("value"))
        for m in resources[0].get("members", [])
    }

    added, already_member = [], []

    for email in emails:
        if not email:
            continue
        try:
            users = list(w.users.list(filter=f'userName eq "{email}"'))
            if not users:
                print(f"  User '{email}' not found in workspace — skipping")
                continue
            user_id = str(users[0].id)
        except Exception as e:
            print(f"  Failed to look up user '{email}': {e}")
            continue

        if user_id in existing_member_ids:
            already_member.append(email)
            print(f"  '{email}' already a member of '{group_name}'")
            continue

        try:
            api.do(
                "PATCH",
                f"/api/2.0/account/scim/v2/Groups/{group_id}",
                body={
                    "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
                    "Operations": [
                        {
                            "op": "add",
                            "path": "members",
                            "value": [{"value": user_id}],
                        }
                    ],
                },
            )
            added.append(email)
            existing_member_ids.add(user_id)
            print(f"  Added '{email}' to '{group_name}'")
        except Exception as e:
            print(f"  Failed to add '{email}' to '{group_name}': {e}")

    return {'added': added, 'already_member': already_member}


def get_job_owner_id(w, job_id):
    """Get the Databricks user/SPN ID of the job owner from job ACL.

    Args:
        w: WorkspaceClient instance
        job_id: The job ID to look up

    Returns:
        Tuple of (owner_id, owner_name) or (None, None) if not found
    """
    current_perms = w.jobs.get_permissions(job_id=job_id)
    for acl_entry in (current_perms.access_control_list or []):
        for p in acl_entry.all_permissions:
            if p.permission_level == jobs.JobPermissionLevel.IS_OWNER:
                if acl_entry.user_name:
                    users = list(w.users.list(
                        filter=f'userName eq "{acl_entry.user_name}"'
                    ))
                    if users:
                        return users[0].id, acl_entry.user_name
                elif acl_entry.service_principal_name:
                    sps = list(w.service_principals.list(
                        filter=f'displayName eq "{acl_entry.service_principal_name}"'
                    ))
                    if sps:
                        return sps[0].id, acl_entry.service_principal_name
                return None, None
    return None, None


def set_job_permissions_with_owner(w, job_id, group_permissions):
    """Set job-level permissions preserving the existing owner and deduplicating ACLs.

    Contains the owner extraction, ACL rebuild, dedupe, and apply logic.

    Args:
        w: WorkspaceClient instance
        job_id: The job ID to set permissions on
        group_permissions: Dict mapping group_name to list of permission level strings
            e.g. {"LAKEFUSION_ADMIN": ["CAN_MANAGE"],
                   "DEVELOPER_entity": ["CAN_MANAGE_RUN"]}

    Raises:
        ValueError: If job has no owner
        DatabricksError: If permission update fails
    """
    # Get current permissions
    current = w.jobs.get_permissions(job_id=job_id)
    acl = current.access_control_list or []

    # 1. Find EXACTLY ONE owner
    owner_resp = None
    for a in acl:
        for p in a.all_permissions:
            if p.permission_level == jobs.JobPermissionLevel.IS_OWNER:
                owner_resp = a
                break
        if owner_resp:
            break

    if not owner_resp:
        raise ValueError("Job has no owner — cannot update permissions")

    # 2. Find permissions other than owner
    others_resp = []
    for a in acl:
        for p in a.all_permissions:
            if p.permission_level != jobs.JobPermissionLevel.IS_OWNER:
                others_resp.append(a)
                break

    # 3. Rebuild owner as REQUEST
    if owner_resp.user_name:
        owner_req = jobs.JobAccessControlRequest(
            user_name=owner_resp.user_name,
            permission_level=jobs.JobPermissionLevel.IS_OWNER
        )
    elif owner_resp.group_name:
        owner_req = jobs.JobAccessControlRequest(
            group_name=owner_resp.group_name,
            permission_level=jobs.JobPermissionLevel.IS_OWNER
        )
    elif owner_resp.service_principal_name:
        owner_req = jobs.JobAccessControlRequest(
            service_principal_name=owner_resp.service_principal_name,
            permission_level=jobs.JobPermissionLevel.IS_OWNER
        )
    else:
        raise ValueError("Owner type not supported")

    # 4. Rebuild others as REQUEST
    def _extract_permission(a):
        # Prefer non-inherited permission if available
        for p in a.all_permissions:
            if not p.inherited:
                return p.permission_level
        # Fallback to inherited
        return a.all_permissions[0].permission_level

    others_req = []
    for a in others_resp:
        perm_level = _extract_permission(a)
        if a.user_name:
            others_req.append(jobs.JobAccessControlRequest(
                user_name=a.user_name, permission_level=perm_level
            ))
        elif a.group_name:
            others_req.append(jobs.JobAccessControlRequest(
                group_name=a.group_name, permission_level=perm_level
            ))
        elif a.service_principal_name:
            others_req.append(jobs.JobAccessControlRequest(
                service_principal_name=a.service_principal_name,
                permission_level=perm_level
            ))

    # 5. Build final ACL
    new_acl = [owner_req] + others_req

    for grp, perms in group_permissions.items():
        new_acl.append(jobs.JobAccessControlRequest(
            group_name=grp,
            permission_level=jobs.JobPermissionLevel[perms[0]]
        ))

    # 6. Deduplicate — keep higher permissions per principal
    permission_order = [
        JobPermissionLevel.IS_OWNER,
        JobPermissionLevel.CAN_MANAGE,
        JobPermissionLevel.CAN_MANAGE_RUN,
        JobPermissionLevel.CAN_VIEW,
    ]

    def _higher_permission(p1, p2):
        return p1 if permission_order.index(p1) < permission_order.index(p2) else p2

    unique = {}
    for a in new_acl:
        key = (
            ("user", a.user_name) if a.user_name else
            ("group", a.group_name) if a.group_name else
            ("sp", a.service_principal_name)
        )
        if key not in unique:
            unique[key] = a
        else:
            existing = unique[key]
            better_perm = _higher_permission(
                existing.permission_level, a.permission_level
            )
            unique[key] = existing if better_perm == existing.permission_level else a

    distinct_acl = list(unique.values())

    # 7. Apply permissions
    try:
        w.jobs.set_permissions(
            job_id=job_id,
            access_control_list=distinct_acl
        )
        print("  Job permissions updated successfully")
    except DatabricksError as e:
        print(f"  Failed to update job permissions: {e}")
        if "exactly one owner" in str(e):
            print(
                "  Hint: The job must have exactly ONE IS_OWNER entry. "
                "Ensure your ACL list contains one (and only one) owner."
            )
        raise


def grant_serving_endpoint_permissions(w, endpoint_name, group_permissions):
    """Find a serving endpoint by name and apply permissions.

    Args:
        w: WorkspaceClient instance
        endpoint_name: Name of the serving endpoint
        group_permissions: Dict mapping group_name to list of permission level strings
            e.g. {"LAKEFUSION_ADMIN": ["CAN_MANAGE"],
                   "DEVELOPER_entity": ["CAN_QUERY"]}
    """
    endpoints = w.serving_endpoints.list()
    for ep in endpoints:
        if ep.name.upper() == endpoint_name.upper():
            endpoint_id = ep.id
            access_control_list = []
            for group, permissions in group_permissions.items():
                for permission in permissions:
                    access_control_list.append(
                        AccessControlRequest(
                            group_name=group,
                            permission_level=PermissionLevel[permission],
                        )
                    )
            try:
                w.permissions.update(
                    request_object_type="serving-endpoints",
                    request_object_id=endpoint_id,
                    access_control_list=access_control_list,
                )
                print(f"  Grant permission on endpoint '{endpoint_name}' completed")
            except DatabricksError as e:
                print(f"  Failed to update endpoint permissions for '{endpoint_name}': {e}")
            return

    print(f"  Endpoint '{endpoint_name}' not found — skipping")


def grant_vector_search_endpoint_permissions(w, endpoint_name, group_permissions):
    """Apply permissions to a Vector Search endpoint.

    Uses the vector-search-endpoints permissions API. Permission levels:
    CAN_USE, CAN_MANAGE, CAN_VIEW.

    Args:
        w: WorkspaceClient instance
        endpoint_name: Name of the vector search endpoint
        group_permissions: Dict mapping group_name -> list of permission level strings
    """
    try:
        resp = w.api_client.do(
            "GET", "/api/2.0/vector-search/endpoints"
        )
        endpoint_id = None
        for ep in (resp or {}).get("endpoints", []) or []:
            if ep.get("name", "").upper() == endpoint_name.upper():
                endpoint_id = ep.get("id") or ep.get("endpoint_id") or ep.get("name")
                break
        if not endpoint_id:
            print(f"  Vector endpoint '{endpoint_name}' not found — skipping")
            return

        access_control_list = []
        for group, permissions in group_permissions.items():
            for permission in permissions:
                access_control_list.append({
                    "group_name": group,
                    "permission_level": permission,
                })

        w.api_client.do(
            "PATCH",
            f"/api/2.0/permissions/vector-search-endpoints/{endpoint_id}",
            body={"access_control_list": access_control_list},
        )
        print(f"  Grant permission on vector endpoint '{endpoint_name}' completed")
    except DatabricksError as e:
        print(f"  Failed to update vector endpoint permissions for '{endpoint_name}': {e}")
    except Exception as e:
        print(f"  Error granting vector endpoint '{endpoint_name}': {e}")


def grant_uc_model_privileges(spark, model_full_name, principal, privileges):
    """Grant UC model privileges via SQL.

    Args:
        spark: SparkSession instance
        model_full_name: Full hierarchy name of the model
            (e.g. catalog.schema.`model-name`)
        principal: The principal to grant to (group name)
        privileges: List of privilege strings (e.g. ["EXECUTE", "MANAGE"])
    """
    for privilege in privileges:
        sql_privilege = privilege.replace("_", " ")
        sql = f"""
        GRANT {sql_privilege}
        ON FUNCTION {model_full_name}
        TO `{principal}`
        """
        try:
            spark.sql(sql)
            print(f"  Granted {sql_privilege} on {model_full_name} to {principal}")
        except Exception as grant_error:
            print(
                f"  Failed granting {sql_privilege} "
                f"on {model_full_name} to {principal}: {grant_error}"
            )
