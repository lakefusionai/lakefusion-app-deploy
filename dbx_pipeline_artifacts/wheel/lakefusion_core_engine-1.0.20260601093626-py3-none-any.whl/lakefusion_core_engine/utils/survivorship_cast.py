"""
Cast helpers for survivorship engine output.

The survivorship UDF returns ``MapType(StringType(), StringType())`` — every
value arrives as a string. Before writing the merged record back to the master
table we cast each attribute back to its declared Spark type. This module
centralises that cast logic so all notebooks and executors agree on the rules.

Why this exists
---------------
The naive ``string -> double -> long`` cast (used previously to handle decimal
strings like ``"28.0"``) silently truncates integers above 2^53 because IEEE-754
doubles only have a 52-bit mantissa. For ``bigint`` IDs in the 10^16 range the
gap between consecutive representable doubles is 8, so e.g.
``"60000000002028803"`` collapses to ``60000000002028800``. ``decimal(38,0)``
preserves the full precision and still accepts ``"28.0"`` (truncates the
fractional part).
"""

from pyspark.sql import Column
from pyspark.sql.functions import col


_INTEGER_TYPES = {"int", "integer", "long", "bigint", "smallint", "tinyint"}
_FLOAT_TYPES = {"float", "double", "decimal"}
_TIMESTAMP_TYPES = {"timestamp", "date", "datetime"}
_BOOLEAN_TYPES = {"boolean", "bool"}


def cast_merged_value(value_col: Column, target_type: str) -> Column:
    """Cast a stringified ``merged_record`` value to its target Spark type."""
    t = (target_type or "string").lower()

    if t in _TIMESTAMP_TYPES:
        return value_col.cast("timestamp")
    if t in _INTEGER_TYPES:
        # decimal(38,0) preserves bigint precision (double truncates above
        # 2^53) while still accepting decimal strings like "28.0".
        return value_col.cast("decimal(38,0)").cast("long")
    if t in _FLOAT_TYPES:
        return value_col.cast("double")
    if t in _BOOLEAN_TYPES:
        return value_col.cast("boolean")
    return value_col


def merged_record_column(attr: str, target_type: str) -> Column:
    """Convenience wrapper: produce a typed, aliased column for ``attr``.

    Equivalent to
    ``cast_merged_value(col(f"merged_record.{attr}"), target_type).alias(attr)``.
    """
    return cast_merged_value(col(f"merged_record.{attr}"), target_type).alias(attr)
