import logging
from typing import Dict, List, Optional

# delta.tables is imported lazily inside merge() / merge_with_delete() /
# update_by_keys() so that environments using only Lakebase (e.g. the
# middlelayer / cron-service) don't need delta-spark installed just to
# import this module.

from .base import WriteOperations

logger = logging.getLogger("WriteOps.Delta")


class DeltaWriteOps(WriteOperations):
    """
    Delta table write operations — thin wrapper around existing Spark/Delta calls.

    This is a 1:1 mapping of current notebook write patterns. Using write_mode=delta
    with this class produces identical behavior to the original direct calls.
    """

    def __init__(self, spark):
        self._spark = spark

    def create_table(
        self,
        df,
        table_name: str,
        enable_cdf: bool = False,
        primary_key: Optional[List[str]] = None,
        synced_table_id: Optional[str] = None,
    ) -> None:
        """Create-if-not-exists. Never drops/overwrites an existing table —
        use overwrite() / append() / merge() to change data.

        Signature mirrors LakebaseWriteOps.create_table so callers can use
        either implementation interchangeably. `synced_table_id` is accepted
        for signature parity and ignored (Delta has no synced table).
        """
        if self.table_exists(table_name):
            logger.info(f"Table {table_name} already exists; skipping create.")
            return
        writer = df.write.format("delta").mode("overwrite")
        if enable_cdf:
            writer = writer.option("delta.enableChangeDataFeed", "true")
        writer.saveAsTable(table_name)

        if primary_key:
            # Delta requires PK columns NOT NULL before the constraint.
            # Best-effort: the data is already written, so a failure here
            # is non-fatal (MERGE works without a declared PK).
            try:
                for col_name in primary_key:
                    self._spark.sql(
                        f"ALTER TABLE {table_name} ALTER COLUMN {col_name} SET NOT NULL"
                    )
                pk_list = ", ".join(primary_key)
                self._spark.sql(
                    f"ALTER TABLE {table_name} "
                    f"ADD CONSTRAINT pk_{table_name.split('.')[-1]} PRIMARY KEY ({pk_list})"
                )
                logger.info(f"Added PRIMARY KEY ({pk_list}) on {table_name}")
            except Exception as e:
                logger.warning(f"Could not add PRIMARY KEY on {table_name}: {e}")

        logger.info(f"Created table {table_name} (CDF={enable_cdf})")

    def overwrite(self, df, table_name: str) -> None:
        df.write.format("delta") \
            .mode("overwrite") \
            .option("mergeSchema", "true") \
            .saveAsTable(table_name)
        logger.info(f"Overwrote {table_name}")

    def append(self, df, table_name: str) -> None:
        df.write.format("delta").mode("append").saveAsTable(table_name)
        logger.info(f"Appended to {table_name}")

    def merge(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        when_matched: Optional[Dict] = None,
        when_not_matched: str = "insert",
    ) -> None:
        from delta.tables import DeltaTable
        delta_table = DeltaTable.forName(self._spark, table_name)
        condition = " AND ".join(
            f"target.{k} = source.{k}" for k in merge_keys
        )
        merger = delta_table.alias("target").merge(df.alias("source"), condition)

        if when_matched is not None:
            merger = merger.whenMatchedUpdate(set=when_matched)
        else:
            merger = merger.whenMatchedUpdateAll()

        if when_not_matched == "insert":
            merger = merger.whenNotMatchedInsertAll()

        merger.execute()
        logger.info(f"Merged into {table_name} on {merge_keys}")

    def merge_with_delete(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        delete_condition: str,
    ) -> None:
        from delta.tables import DeltaTable
        delta_table = DeltaTable.forName(self._spark, table_name)
        condition = " AND ".join(
            f"target.{k} = source.{k}" for k in merge_keys
        )
        delta_table.alias("target").merge(
            df.alias("source"), condition
        ).whenMatchedUpdateAll() \
         .whenNotMatchedInsertAll() \
         .whenNotMatchedBySourceDelete(delete_condition) \
         .execute()
        logger.info(f"Merge+delete into {table_name} on {merge_keys}")

    def sql_merge(
        self,
        sql_string: str,
        table_name: str,
        source_df=None,
        merge_keys: Optional[List[str]] = None,
    ) -> None:
        self._spark.sql(sql_string)
        logger.info(f"SQL merge into {table_name}")

    def table_exists(self, table_name: str) -> bool:
        return self._spark.catalog.tableExists(table_name)

    def optimize(self, table_name: str) -> None:
        self._spark.sql(f"OPTIMIZE {table_name}")
        logger.info(f"Optimized {table_name}")
    def update_by_keys(
        self,
        df,
        table_name: str,
        key_columns: List[str],
        set_expressions: Dict[str, str],
        extra_predicate: Optional[str] = None,
        ) -> None:
        """
        Update-only MERGE: rows in `table_name` whose `key_columns` match `df`
        get `set_expressions` applied. No inserts, no deletes.
    
        set_expressions values are SQL expression strings, e.g.
            {"status": "'INACTIVE'", "updated_at": "source.updated_at"}
        extra_predicate is appended to the match condition, e.g.
            "target.is_current = true"
        """
        from delta.tables import DeltaTable
        delta_table = DeltaTable.forName(self._spark, table_name)
        condition = " AND ".join(f"target.{k} = source.{k}" for k in key_columns)
        if extra_predicate:
            condition = f"({condition}) AND ({extra_predicate})"
    
        (
            delta_table.alias("target")
            .merge(df.alias("source"), condition)
            .whenMatchedUpdate(set=set_expressions)
            .execute()
        )
        logger.info(
            f"Updated {table_name} on {key_columns}"
            + (f" with predicate [{extra_predicate}]" if extra_predicate else "")
        )

    def enable_cdf(self, table_name: str) -> None:
        self._spark.sql(
            f"ALTER TABLE {table_name} SET TBLPROPERTIES "
            f"(delta.enableChangeDataFeed = true)"
        )
        logger.info(f"Enabled CDF on {table_name}")

    def delete_by_keys(
        self,
        df,
        table_name: str,
        key_columns: List[str],
    ) -> None:
        """DELETE rows from target whose `key_columns` match rows in `df`.

        Implemented as a MERGE with `whenMatchedDelete()` so the operation
        is atomic and observable in Delta history.
        """
        from delta.tables import DeltaTable
        delta_table = DeltaTable.forName(self._spark, table_name)
        condition = " AND ".join(f"target.{k} = source.{k}" for k in key_columns)
        (
            delta_table.alias("target")
            .merge(df.alias("source"), condition)
            .whenMatchedDelete()
            .execute()
        )
        logger.info(f"Deleted rows from {table_name} matched on {key_columns}")
