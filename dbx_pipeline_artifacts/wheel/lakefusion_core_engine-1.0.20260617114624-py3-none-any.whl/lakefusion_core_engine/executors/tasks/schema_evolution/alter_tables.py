"""
Alter Tables Executor for Schema Evolution.

Adds new columns to master, unified, and unified_deduplicate Delta tables
based on ADD_ATTRIBUTE edits from the schema evolution configuration.

Idempotent: checks column existence before ALTER TABLE ADD COLUMNS.

Workflow:
1. Parse edits and for each ADD_ATTRIBUTE:
   - Check if column exists in master/unified/unified_deduplicate table schema
   - ADD COLUMN if missing, skip if already present
"""

import json
from typing import Any, Dict, List, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult


# Supported type mapping for ALTER TABLE ADD COLUMNS
DTYPE_TO_SQL = {
    'BIGINT': 'BIGINT',
    'BOOLEAN': 'BOOLEAN',
    'DATE': 'DATE',
    'DOUBLE': 'DOUBLE',
    'FLOAT': 'FLOAT',
    'INT': 'INT',
    'SMALLINT': 'SMALLINT',
    'STRING': 'STRING',
    'TINYINT': 'TINYINT',
    'TIMESTAMP': 'TIMESTAMP',
}


class AlterTablesExecutor(BaseStepTask):
    """
    Executor for altering Delta tables to add new schema evolution columns.

    Adds columns to master, unified, and unified_deduplicate tables
    for each ADD_ATTRIBUTE edit. Idempotent — skips columns that already exist.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.logger = context.params.get("logger") or self.logger
        self.edits = []
        self.columns_added = []
        self.columns_skipped = []

    @property
    def entity_name(self) -> str:
        """Get entity name from params."""
        return self.context.params.get('entity_name', '') or self.context.entity

    @property
    def edits_json(self) -> str:
        """Get edits JSON string from params."""
        return self.context.params.get('edits', '[]')

    @property
    def master_table(self) -> str:
        """Get master table name from params."""
        return self.context.params.get('master_table', '')

    @property
    def unified_table(self) -> str:
        """Get unified table name from params."""
        return self.context.params.get('unified_table', '')

    def pre_execute(self) -> None:
        """Parse edits and log configuration."""
        edits_raw = self.edits_json
        self.edits = json.loads(edits_raw) if isinstance(edits_raw, str) else edits_raw

        self.logger.info("=" * 80)
        self.logger.info("SCHEMA EVOLUTION - ALTER TABLES")
        self.logger.info("=" * 80)
        self.logger.info(f"Master Table: {self.master_table}")
        self.logger.info(f"Unified Table: {self.unified_table}")
        self.logger.info(f"Edits count: {len(self.edits)}")
        self.logger.info("=" * 80)

    def _enable_column_mapping(self, table_name: str) -> None:
        """Enable Delta column mapping so future DROP COLUMN (rollback) is supported.
        Idempotent — safe to call on tables that already have it enabled."""
        try:
            self.spark.sql(f"""
                ALTER TABLE {table_name} SET TBLPROPERTIES (
                    'delta.columnMapping.mode' = 'name',
                    'delta.minReaderVersion' = '2',
                    'delta.minWriterVersion' = '5'
                )
            """)
            self.logger.info(f"  Enabled column mapping on {table_name}")
        except Exception as e:
            if "already enabled" in str(e).lower() or "already set" in str(e).lower():
                self.logger.info(f"  Column mapping already enabled on {table_name}")
            else:
                raise

    @step(order=1, name="Alter Tables", returns="dict - columns added/skipped summary")
    def step_alter_tables(self) -> Dict[str, Any]:
        """Add columns to master and unified tables for each ADD_ATTRIBUTE edit."""
        self.columns_added = []
        self.columns_skipped = []

        # Enable column mapping proactively so rollback (DROP COLUMN) will work
        self.logger.info("  Enabling column mapping on target tables...")
        self._enable_column_mapping(self.master_table)
        self._enable_column_mapping(self.unified_table)
        unified_dedup = self._get_unified_dedup_table()
        if unified_dedup and self.spark.catalog.tableExists(unified_dedup):
            self._enable_column_mapping(unified_dedup)

        for edit in self.edits:
            if edit.get('action_type') != 'ADD_ATTRIBUTE':
                continue

            attr_name = edit['attribute_name']
            sql_type = DTYPE_TO_SQL.get(edit['attribute_type'].upper(), 'STRING')

            # ── Master table ──
            master_cols = [f.name for f in self.spark.table(self.master_table).schema]
            if attr_name not in master_cols:
                self.spark.sql(f"ALTER TABLE {self.master_table} ADD COLUMNS (`{attr_name}` {sql_type})")
                self.logger.info(f"  Added column `{attr_name}` ({sql_type}) to master table")
                self.columns_added.append(f"master:{attr_name}")
            else:
                self.logger.info(f"  Column `{attr_name}` already exists in master table - skipping")
                self.columns_skipped.append(f"master:{attr_name}")

            # ── Unified table ──
            unified_cols = [f.name for f in self.spark.table(self.unified_table).schema]
            if attr_name not in unified_cols:
                self.spark.sql(f"ALTER TABLE {self.unified_table} ADD COLUMNS (`{attr_name}` {sql_type})")
                self.logger.info(f"  Added column `{attr_name}` ({sql_type}) to unified table")
                self.columns_added.append(f"unified:{attr_name}")
            else:
                self.logger.info(f"  Column `{attr_name}` already exists in unified table - skipping")
                self.columns_skipped.append(f"unified:{attr_name}")

            # ── Unified Deduplicate table (if exists) ──
            unified_dedup = self._get_unified_dedup_table()
            if unified_dedup and self.spark.catalog.tableExists(unified_dedup):
                dedup_cols = [f.name for f in self.spark.table(unified_dedup).schema]
                if attr_name not in dedup_cols:
                    self.spark.sql(f"ALTER TABLE {unified_dedup} ADD COLUMNS (`{attr_name}` {sql_type})")
                    self.logger.info(f"  Added column `{attr_name}` ({sql_type}) to unified_deduplicate table")
                    self.columns_added.append(f"unified_dedup:{attr_name}")
                else:
                    self.logger.info(f"  Column `{attr_name}` already exists in unified_deduplicate table - skipping")
                    self.columns_skipped.append(f"unified_dedup:{attr_name}")

        return {
            'columns_added': self.columns_added,
            'columns_skipped': self.columns_skipped,
        }

    def execute(self) -> TaskResult:
        """Execute the alter tables workflow."""
        result = self.step_alter_tables()

        return TaskResult.success(
            message=f"Alter tables completed: {len(self.columns_added)} added, {len(self.columns_skipped)} skipped",
            task_name=self.context.task_name,
            metrics={
                'columns_added': len(self.columns_added),
                'columns_skipped': len(self.columns_skipped),
            },
            artifacts={
                'columns_added': self.columns_added,
                'columns_skipped': self.columns_skipped,
            },
        )

    def _get_unified_dedup_table(self) -> str:
        """Build the unified_deduplicate table name if entity_name is available."""
        entity = self.entity_name
        if not entity:
            return ""
        catalog = self.context.catalog_name
        suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        return f"{catalog}.silver.{entity}_unified_deduplicate{suffix}"

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Alter tables failed: {result.message}")
        if result.errors:
            for err in result.errors:
                self.logger.error(f"  Error: {err}")
