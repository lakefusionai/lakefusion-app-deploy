"""
Backfill From Sources Executor for Schema Evolution.

Backfills newly added columns in the unified and master tables
by reading source data, merging into unified, then applying
survivorship resolution (SVR) and merging into master.

Workflow:
1. Pre-process edits: collect attributes, build SVR config, group sources
2. Backfill unified table: one MERGE per source table
3. Resolve SVR and update master: build UDF, apply SVR, single MERGE
"""

import json
from typing import Any, Dict, List, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult


class BackfillFromSourcesExecutor(BaseStepTask):
    """
    Executor for backfilling source data into unified and master tables
    after schema evolution ADD_ATTRIBUTE operations.

    Phase 1: Batched unified table backfill (one MERGE per source table)
    Phase 2: SVR resolution + single master table MERGE
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.logger = context.params.get("logger") or self.logger
        self.edits = []

        # Intermediate results
        self.add_edits = []
        self.all_attr_names = []
        self.all_attr_types = {}
        self.svr_config = []
        self.dataset_attrs = {}  # { dataset_path: { attr_name: info } }

    @property
    def edits_json(self) -> str:
        """Get edits JSON string from params."""
        return self.context.params.get('edits', '[]')

    @property
    def master_table(self) -> str:
        """Get master table name from params."""
        return self.context.params.get('master_table', '')

    @property
    def unified_table(self) -> str:
        """Get unified table name from params."""
        return self.context.params.get('unified_table', '')

    @property
    def id_key(self) -> str:
        """Get ID key from params."""
        return self.context.params.get('id_key', 'lakefusion_id')

    def pre_execute(self) -> None:
        """Parse edits and log configuration."""
        edits_raw = self.edits_json
        self.edits = json.loads(edits_raw) if isinstance(edits_raw, str) else edits_raw

        self.logger.info("=" * 80)
        self.logger.info("SCHEMA EVOLUTION - BACKFILL FROM SOURCES")
        self.logger.info("=" * 80)
        self.logger.info(f"Master Table: {self.master_table}")
        self.logger.info(f"Unified Table: {self.unified_table}")
        self.logger.info(f"ID Key: {self.id_key}")
        self.logger.info(f"Edits count: {len(self.edits)}")
        self.logger.info("=" * 80)

    @step(order=1, name="Pre-process Edits", returns="dict - preprocessing summary")
    def step_preprocess_edits(self) -> Dict[str, Any]:
        """Parse edits, collect attributes, build SVR config, group by source."""
        self.add_edits = [e for e in self.edits if e.get('action_type') == 'ADD_ATTRIBUTE']

        if not self.add_edits:
            self.logger.info("  No ADD_ATTRIBUTE edits to process. Skipping backfill.")
            return {'add_edits_count': 0, 'skipped': True}

        self.all_attr_names = []
        self.all_attr_types = {}
        self.svr_config = []
        self.dataset_attrs = {}

        for edit in self.add_edits:
            attr_name = edit['attribute_name']
            attr_type = edit['attribute_type'].upper()
            self.all_attr_names.append(attr_name)
            self.all_attr_types[attr_name] = attr_type

            survivorship_rule = edit.get('survivorship_rule')
            if survivorship_rule:
                self.svr_config.append({
                    "attribute": attr_name,
                    "strategy": survivorship_rule.get('strategy'),
                    "strategyRule": survivorship_rule.get('strategy_rule'),
                    "ignoreNull": survivorship_rule.get('ignore_null', False),
                })

        # Group ALL source_mappings by dataset_path across all edits
        for edit in self.add_edits:
            attr_name = edit['attribute_name']
            attr_type = edit['attribute_type'].upper()
            for mapping in edit.get('source_mappings', []):
                dp = mapping['dataset_path']
                self.dataset_attrs.setdefault(dp, {})[attr_name] = {
                    'dataset_attribute': mapping['dataset_attribute'],
                    'dataset_primary_key': mapping['dataset_primary_key'],
                    'attr_type': attr_type,
                }

        self.logger.info(f"  Attributes to backfill: {self.all_attr_names}")
        self.logger.info(f"  Unique source tables: {list(self.dataset_attrs.keys())}")
        self.logger.info(f"  SVR rules configured: {len(self.svr_config)}")

        return {
            'add_edits_count': len(self.add_edits),
            'attributes': self.all_attr_names,
            'source_tables': list(self.dataset_attrs.keys()),
            'svr_rules': len(self.svr_config),
            'skipped': False,
        }

    @step(order=2, name="Backfill Unified Table", returns="int - count of source merges")
    def step_backfill_unified(self) -> int:
        """Merge source data into unified table for each dataset path."""
        from pyspark.sql.functions import col
        from delta.tables import DeltaTable

        if not self.dataset_attrs:
            self.logger.info("  No source tables to process.")
            return 0

        self.logger.info(f"\n  PHASE 1: Backfilling unified table from {len(self.dataset_attrs)} source(s)")

        merge_count = 0
        for dataset_path, attrs_info in self.dataset_attrs.items():
            dataset_pk = next(iter(attrs_info.values()))['dataset_primary_key']
            attr_names_from_source = list(attrs_info.keys())

            self.logger.info(f"\n  Source: {dataset_path}")
            self.logger.info(f"  PK: {dataset_pk}")
            self.logger.info(f"  Attributes: {attr_names_from_source}")

            # Build select: PK + all attribute columns from this source
            select_cols = [col(dataset_pk).cast("string").alias("_source_id")]
            update_set = {}

            for attr_name, info in attrs_info.items():
                select_cols.append(
                    col(info['dataset_attribute']).cast(info['attr_type']).alias(attr_name)
                )
                update_set[attr_name] = f"s.{attr_name}"

            # Read source table ONCE, project all needed columns
            source_df = self.spark.read.table(dataset_path).select(*select_cols)

            # Single MERGE updates ALL attributes from this source
            DeltaTable.forName(self.spark, self.unified_table).alias("t").merge(
                source_df.alias("s"),
                f"t.source_path = '{dataset_path}' AND t.source_id = s._source_id"
            ).whenMatchedUpdate(set=update_set).execute()

            self.logger.info(f"  Merged {len(attr_names_from_source)} attribute(s) in single operation")
            merge_count += 1

        self.logger.info(f"\n  Phase 1 complete: {merge_count} source merge(s)")
        return merge_count

    @step(order=3, name="Resolve SVR and Update Master", returns="int - master update count")
    def step_resolve_svr_and_update_master(self) -> int:
        """Build SVR UDF, resolve attributes, and MERGE into master table."""
        from pyspark.sql.functions import col, collect_list, struct, udf
        from pyspark.sql.types import StructType, StructField, StringType
        from delta.tables import DeltaTable
        from lakefusion_core_engine.survivorship import SurvivorshipEngine

        if not self.all_attr_names:
            self.logger.info("  No attributes to resolve.")
            return 0

        self.logger.info(f"\n  PHASE 2: SVR resolution for {len(self.all_attr_names)} attribute(s) + master update")

        # UDF return type: one StringType field per attribute
        resolve_return_type = StructType([
            StructField(attr_name, StringType()) for attr_name in self.all_attr_names
        ])

        # Closure variables for UDF serialization (must be plain Python types)
        _svr_config = self.svr_config
        _all_attr_names = self.all_attr_names
        _all_attr_types = self.all_attr_types

        @udf(resolve_return_type)
        def resolve_svr_batch(contributors):
            """UDF: resolve ALL new attributes at once via SurvivorshipEngine."""
            engine = SurvivorshipEngine(
                survivorship_config=_svr_config,
                entity_attributes=_all_attr_names,
                entity_attributes_datatype=_all_attr_types,
                id_key="surrogate_key",
            )

            records = [row.asDict() for row in contributors]

            try:
                result = engine.apply_survivorship(unified_records=records)
                values = tuple(result.resultant_record.get(attr) for attr in _all_attr_names)
                # Return None if ALL values are None (no resolution happened)
                if all(v is None for v in values):
                    return None
                return values
            except Exception:
                return None

        # Query unified table for ALL new attribute columns at once
        attr_cols = ", ".join([f"`{a}`" for a in self.all_attr_names])
        or_clause = " OR ".join([f"`{a}` IS NOT NULL" for a in self.all_attr_names])

        contributors_df = self.spark.sql(f"""
            SELECT master_lakefusion_id, surrogate_key, source_path, {attr_cols}
            FROM {self.unified_table}
            WHERE master_lakefusion_id IS NOT NULL
            AND record_status = 'MERGED'
            AND ({or_clause})
        """)

        # Group by master, collect ALL contributor structs
        struct_cols = ["surrogate_key", "source_path"] + [col(f"`{a}`") for a in self.all_attr_names]

        resolved_df = (
            contributors_df
            .groupBy("master_lakefusion_id")
            .agg(collect_list(struct(*struct_cols)).alias("contributors"))
            .select(
                col("master_lakefusion_id").alias("lakefusion_id"),
                resolve_svr_batch(col("contributors")).alias("result"),
            )
            .filter(col("result").isNotNull())
        )

        # Flatten result struct into individual columns for the MERGE
        select_cols = [col("lakefusion_id")]
        update_set = {}
        for attr_name in self.all_attr_names:
            select_cols.append(col(f"result.{attr_name}").alias(attr_name))
            update_set[attr_name] = f"s.{attr_name}"

        merge_source = resolved_df.select(*select_cols)

        self.logger.info(f"  Resolving survivorship and updating master table...")

        # Single MERGE updates ALL resolved attributes at once
        DeltaTable.forName(self.spark, self.master_table).alias("t").merge(
            merge_source.alias("s"),
            "t.lakefusion_id = s.lakefusion_id"
        ).whenMatchedUpdate(set=update_set).execute()

        self.logger.info(f"  Updated {len(self.all_attr_names)} attribute(s) in single master MERGE")
        self.logger.info(f"\n  Phase 2 complete")

        return 1  # single master merge

    def execute(self) -> TaskResult:
        """Execute the backfill from sources workflow."""
        preprocess_result = self.step_preprocess_edits()

        # If no ADD_ATTRIBUTE edits, return early with SKIPPED
        if preprocess_result.get('skipped', False):
            return TaskResult.skipped(
                message="No ADD_ATTRIBUTE edits to process",
                task_name=self.context.task_name,
            )

        source_merge_count = self.step_backfill_unified()
        master_merge_count = self.step_resolve_svr_and_update_master()

        return TaskResult.success(
            message=f"Backfill completed: {len(self.all_attr_names)} attributes from {source_merge_count} sources",
            task_name=self.context.task_name,
            metrics={
                'attributes_processed': self.all_attr_names,
                'source_merges': source_merge_count,
                'master_merges': master_merge_count,
            },
        )

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Backfill from sources failed: {result.message}")
        if result.errors:
            for err in result.errors:
                self.logger.error(f"  Error: {err}")
