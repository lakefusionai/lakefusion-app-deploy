"""Lakebase change-log → Delta reverse-sync.

UI edits write the Lakebase Postgres tables; Postgres AFTER triggers capture each
change (full post-change row as JSON) into an app-managed change-log table
`gold."{entity}_change_log"`. A Databricks Workflow notebook reads the unprocessed
change-log rows and MERGEs them into the Delta source-of-truth, then marks them
processed. This replaces the prior Lakebase CDF (`lb_*_history`) approach — it's
fully app-controlled (no Preview/UI enablement) and race-safe (the log holds an
immutable row snapshot, so a forward Synced-Table refresh can't clobber a pending
edit).

Change-log row shape (one per captured change):
    seq          BIGINT  -- monotonic order / watermark
    source_table TEXT    -- the PG table that changed
    target_kind  TEXT    -- 'master' | 'audit' | 'conflict'
    operation    TEXT    -- 'INSERT' | 'UPDATE' | 'DELETE'
    row_data     JSONB   -- NEW row (INSERT/UPDATE) or OLD row (DELETE), full row
    changed_at   TIMESTAMPTZ
    processed    BOOLEAN
    processed_at TIMESTAMPTZ
    batch_id     TEXT

This module is pure-Spark (read change-log DataFrame in, MERGE to Delta out); the
notebook handles the JDBC read and the psycopg2 "mark processed" so this class has
no Postgres dependency and is unit-testable.
"""
import logging
from typing import Dict, List, Optional

from pyspark.sql import functions as F
from pyspark.sql.window import Window

from .delta_ops import DeltaWriteOps

logger = logging.getLogger("WriteOps.LakebaseChangeLog")

_UPSERT_OPS = ("INSERT", "UPDATE")
_DELETE_OP = "DELETE"


class LakebaseChangeLogReader:
    """Collapse Lakebase change-log rows to the net latest change per primary key
    and MERGE them into the Delta source-of-truth.

    Target-kind grains:
      - master   -> pk [ref_lakefusion_id];           upsert / delete
      - audit    -> pk [ref_lakefusion_id, version];  upsert (append-only SCD-2;
                    the is_current flip is itself a logged UPDATE row)
      - conflict -> pk [ref_lakefusion_id, conflict_id]; upsert
    """

    def __init__(self, spark):
        self._spark = spark
        self._delta = DeltaWriteOps(spark)

    def merge_to_delta(
        self,
        changelog_df,
        target_table: str,
        pk_cols: List[str],
        soft_delete_set: Optional[Dict[str, str]] = None,
    ) -> dict:
        """MERGE the (already target-kind-filtered) change-log rows into `target_table`.

        `changelog_df` columns: seq (BIGINT), operation (STRING), row_data (JSON STRING).
        `row_data` is parsed with the TARGET Delta schema, so complex (STRUCT/ARRAY)
        attributes rehydrate to their native types automatically.

        Returns: {target, skipped, upserts, deletes, max_seq}.
        """
        if not self._spark.catalog.tableExists(target_table):
            logger.warning(f"Target table {target_table} does not exist; skipping change-log merge.")
            return {"target": target_table, "skipped": True, "upserts": 0, "deletes": 0, "max_seq": None}

        if changelog_df.head(1) == []:
            return {"target": target_table, "skipped": False, "upserts": 0, "deletes": 0, "max_seq": None}

        target_schema = self._spark.table(target_table).schema
        max_seq = changelog_df.agg(F.max("seq").alias("m")).collect()[0]["m"]

        # Parse the JSON snapshot into the native target schema (rehydrates STRUCT/ARRAY).
        parsed = changelog_df.withColumn(
            "_row", F.from_json(F.col("row_data").cast("string"), target_schema)
        )
        for pk in pk_cols:
            parsed = parsed.withColumn(pk, F.col(f"_row.{pk}"))

        # Net latest change per key (change-log is append-only; order by seq).
        w = Window.partitionBy(*pk_cols).orderBy(F.col("seq").desc())
        latest = parsed.withColumn("_rn", F.row_number().over(w)).filter(F.col("_rn") == 1)

        upserts = latest.filter(F.col("operation").isin(*_UPSERT_OPS)).select("_row.*")
        deletes = latest.filter(F.col("operation") == F.lit(_DELETE_OP)).select(*pk_cols)

        n_up = upserts.count()
        if n_up:
            self._delta.merge(upserts, target_table, pk_cols)  # whenMatchedUpdateAll + whenNotMatchedInsertAll

        n_del = deletes.count()
        if n_del:
            if soft_delete_set:
                self._delta.update_by_keys(deletes, target_table, pk_cols, soft_delete_set)
            else:
                self._delta.delete_by_keys(deletes, target_table, pk_cols)

        logger.info(
            f"change-log -> {target_table}: {n_up} upserts, {n_del} deletes "
            f"(max_seq={max_seq})"
        )
        return {
            "target": target_table, "skipped": False,
            "upserts": n_up, "deletes": n_del, "max_seq": max_seq,
        }
