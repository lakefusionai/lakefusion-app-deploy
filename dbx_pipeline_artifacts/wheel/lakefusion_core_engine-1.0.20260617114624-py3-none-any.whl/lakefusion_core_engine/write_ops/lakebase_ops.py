import logging
from typing import Dict, List, Optional

from .base import WriteOperations
from .delta_ops import DeltaWriteOps

logger = logging.getLogger("WriteOps.Lakebase")


class LakebaseWriteOps(WriteOperations):
    """
    Lakebase write operations.

    Pattern: Delta is the source of truth. Every write goes to UC Delta via
    DeltaWriteOps; a Lakebase synced table mirrors the Delta table into
    PostgreSQL based on its scheduling policy (SNAPSHOT / TRIGGERED / CONTINUOUS).

    No direct JDBC writes to Postgres — the sync mechanism handles that.
    """

    def __init__(self, spark, params: dict):
        self._spark = spark
        self._instance_id = params.get("lakebase_instance_id", "")
        self._branch_id = params.get("lakebase_branch_id", "production")
        self._endpoint_id = params.get("lakebase_endpoint_id", "primary")
        self._database = params.get("lakebase_database", "databricks_postgres")
        self._scheduling_policy = params.get("lakebase_scheduling_policy", "SNAPSHOT")

        # All writes flow through Delta
        self._delta_ops = DeltaWriteOps(spark)

        # WorkspaceClient for synced table SDK calls (lazy — only needed in create_table)
        self._ws = None

    def _get_ws(self):
        if self._ws is None:
            from databricks.sdk import WorkspaceClient
            self._ws = WorkspaceClient()
        return self._ws

    def trigger_sync(self, table_name: str, synced_table_id: Optional[str] = None) -> None:
        """Kick off a refresh of the Lakebase synced table so PostgreSQL
        reflects the latest Delta state after a data change.

        TRIGGERED (and SNAPSHOT) synced tables do not auto-sync — the backing
        DLT pipeline must be started explicitly. CONTINUOUS streams on its
        own, so we skip it.

        Non-fatal: Delta is the source of truth, so a failed trigger leaves
        Postgres briefly stale but loses no data. We log and move on rather
        than failing the write; the next write (or a manual refresh) will
        re-trigger. start_update is non-blocking — it kicks the pipeline and
        returns without waiting for the sync to finish.
        """
        if self._scheduling_policy == "CONTINUOUS":
            return
        if synced_table_id is None:
            synced_table_id = f"{table_name}_synced"
        try:
            ws = self._get_ws()
            synced = ws.database.get_synced_database_table(name=synced_table_id)
            pipeline_id = getattr(
                getattr(synced, "data_synchronization_status", None),
                "pipeline_id",
                None,
            )
            if not pipeline_id:
                logger.warning(
                    f"No backing pipeline_id on synced table {synced_table_id}; "
                    f"cannot trigger sync."
                )
                return
            ws.pipelines.start_update(pipeline_id=pipeline_id)
            logger.info(
                f"Triggered sync for {synced_table_id} "
                f"(pipeline={pipeline_id}, policy={self._scheduling_policy})"
            )
        except Exception as e:
            logger.warning(f"Failed to trigger sync for {synced_table_id}: {e}")

    # ---- WriteOperations implementation ----

    def create_table(
        self,
        df,
        table_name: str,
        enable_cdf: bool = False,
        primary_key: Optional[List[str]] = None,
        synced_table_id: Optional[str] = None,
    ) -> None:
        """
        Create the Delta table and a Lakebase synced table on top of it.

        Signature matches DeltaWriteOps.create_table (and the base contract)
        so callers can use either implementation interchangeably.

        Args:
            df: Source DataFrame for the Delta table
            table_name: Fully-qualified UC table (e.g. "catalog.schema.table")
            enable_cdf: Enable CDF on the Delta table (required for TRIGGERED/CONTINUOUS sync)
            primary_key: PK columns. Required for Lakebase — the synced table
                         needs a primary key. Also applied to the Delta table.
            synced_table_id: Target synced table id in UC. Defaults to "{table_name}_synced"
        """
        if not primary_key:
            raise ValueError(
                "LakebaseWriteOps.create_table requires `primary_key` — "
                "a Lakebase synced table cannot be created without one."
            )

        # Step 1: Delta is source of truth
        self._delta_ops.create_table(
            df, table_name, enable_cdf=enable_cdf, primary_key=primary_key,
        )

        if synced_table_id is None:
            synced_table_id = f"{table_name}_synced"

        # Step 2: Lakebase synced table mirrors Delta. Supports both instance
        # kinds — standard `database` instances and legacy autoscaling
        # `postgres`/projects instances.
        from ..lakebase_client import _resolve_lakebase

        ws = self._get_ws()
        conn = _resolve_lakebase(
            ws, self._instance_id, self._branch_id, self._endpoint_id,
        )

        try:
            if conn["kind"] == "postgres":
                # Autoscaling instance — legacy projects/endpoints synced-table API.
                # This create path needs the SDK `postgres` service (>= ~0.110).
                # On older SDKs (e.g. serverless 0.67) it's absent; the synced
                # table is provisioned separately by the service
                # (_provision_lakebase_synced_tables), so skip with a warning
                # rather than crash — the Delta source-of-truth is already made.
                if not hasattr(ws, "postgres"):
                    logger.warning(
                        f"SDK has no `postgres` service; skipping synced-table create "
                        f"for {synced_table_id}. Ensure it's provisioned out-of-band "
                        f"(service-side) for autoscaling instance '{self._instance_id}'."
                    )
                    return
                from databricks.sdk.service.postgres import (
                    SyncedTable,
                    SyncedTableSyncedTableSpec,
                    SyncedTableSyncedTableSpecSyncedTableSchedulingPolicy as PgPolicy,
                )
                pg_policy = {
                    "SNAPSHOT": PgPolicy.SNAPSHOT,
                    "TRIGGERED": PgPolicy.TRIGGERED,
                    "CONTINUOUS": PgPolicy.CONTINUOUS,
                }
                # endpoint_name = "projects/<id>/branches/<branch>/endpoints/<ep>";
                # the spec's `branch` is the "projects/<id>/branches/<branch>" prefix.
                branch = conn["endpoint_name"].rsplit("/endpoints/", 1)[0]
                synced = ws.postgres.create_synced_table(
                    synced_table=SyncedTable(spec=SyncedTableSyncedTableSpec(
                        source_table_full_name=table_name,
                        branch=branch,
                        primary_key_columns=primary_key,
                        scheduling_policy=pg_policy[self._scheduling_policy],
                        postgres_database=self._database,
                        create_database_objects_if_missing=True,
                    )),
                    synced_table_id=synced_table_id,
                ).wait()
                logger.info(f"Synced table created (postgres): {synced.name} (policy={self._scheduling_policy})")
            else:
                # Standard database instance — new database synced-table API.
                from databricks.sdk.service.database import (
                    SyncedDatabaseTable,
                    SyncedTableSpec,
                    SyncedTableSchedulingPolicy,
                )
                db_policy = {
                    "SNAPSHOT": SyncedTableSchedulingPolicy.SNAPSHOT,
                    "TRIGGERED": SyncedTableSchedulingPolicy.TRIGGERED,
                    "CONTINUOUS": SyncedTableSchedulingPolicy.CONTINUOUS,
                }
                synced = ws.database.create_synced_database_table(
                    synced_table=SyncedDatabaseTable(
                        name=synced_table_id,                  # 3-part UC name
                        database_instance_name=conn["name"],   # Lakebase database instance
                        logical_database_name=self._database,  # target Postgres database
                        spec=SyncedTableSpec(
                            source_table_full_name=table_name,
                            primary_key_columns=primary_key,
                            scheduling_policy=db_policy[self._scheduling_policy],
                            create_database_objects_if_missing=True,
                        ),
                    )
                )
                logger.info(f"Synced table created (database): {synced.name} (policy={self._scheduling_policy})")
        except Exception as e:
            # Idempotent: a re-run of Create_Tables re-attempts an existing synced
            # table. Treat "already exists" as success; re-raise anything else.
            if "already exists" in str(e).lower() or "ALREADY_EXISTS" in str(e):
                logger.info(f"Synced table {synced_table_id} already exists; skipping create.")
            else:
                raise

    def overwrite(self, df, table_name: str) -> None:
        self._delta_ops.overwrite(df, table_name)
        self.trigger_sync(table_name)

    def append(self, df, table_name: str) -> None:
        self._delta_ops.append(df, table_name)
        self.trigger_sync(table_name)

    def merge(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        when_matched: Optional[Dict] = None,
        when_not_matched: str = "insert",
    ) -> None:
        self._delta_ops.merge(df, table_name, merge_keys, when_matched, when_not_matched)
        self.trigger_sync(table_name)

    def merge_with_delete(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        delete_condition: str,
    ) -> None:
        self._delta_ops.merge_with_delete(df, table_name, merge_keys, delete_condition)
        self.trigger_sync(table_name)

    def update_by_keys(
        self,
        df,
        table_name: str,
        key_columns: List[str],
        set_expressions: Dict[str, str],
        extra_predicate: Optional[str] = None,
    ) -> None:
        self._delta_ops.update_by_keys(
            df, table_name, key_columns, set_expressions, extra_predicate,
        )
        self.trigger_sync(table_name)

    def sql_merge(
        self,
        sql_string: str,
        table_name: str,
        source_df=None,
        merge_keys: Optional[List[str]] = None,
    ) -> None:
        self._delta_ops.sql_merge(sql_string, table_name, source_df, merge_keys)
        self.trigger_sync(table_name)

    def table_exists(self, table_name: str) -> bool:
        return self._delta_ops.table_exists(table_name)

    def optimize(self, table_name: str) -> None:
        self._delta_ops.optimize(table_name)

    def enable_cdf(self, table_name: str) -> None:
        self._delta_ops.enable_cdf(table_name)

    def delete_by_keys(
        self,
        df,
        table_name: str,
        key_columns: List[str],
    ) -> None:
        self._delta_ops.delete_by_keys(df, table_name, key_columns)
        self.trigger_sync(table_name)
