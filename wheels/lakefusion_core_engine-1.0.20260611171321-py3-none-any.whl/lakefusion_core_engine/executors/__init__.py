"""
Executors module for lakefusion_core_engine.

Provides base task infrastructure and concrete task implementations
for pipeline operations.

Task Import Patterns:
---------------------
Tasks are organized by folder structure mirroring notebook paths.
Use qualified imports to avoid naming conflicts:

    # Recommended - explicit path import
    from lakefusion_core_engine.executors.tasks.integration_core.normal_deduplication import VectorSearchExecutor
    from lakefusion_core_engine.executors.tasks.integration_core.normal_deduplication import LLMMatchingExecutor

    # Or use submodule access
    from lakefusion_core_engine.executors import tasks
    task = tasks.integration_core.normal_deduplication.VectorSearchExecutor

Task Registry Names:
--------------------
Tasks are registered with namespaced names to avoid conflicts:
    - 'integration_core.process_crosswalk'
    - 'integration_core.normal_deduplication.vector_search'
    - 'integration_core.normal_deduplication.llm_matching'
    - 'integration_core.golden_deduplication.vector_search' (future)
"""

# Import from models.py
from .models import (
    TaskContext,
    TaskResult,
    TaskStatus,
    ValidationResult,
    ExecutionPhase
)

from .base import BaseTask
from .step_task import BaseStepTask
from .decorators import step
from .registry import TaskRegistry, create_task_executor, register_task
from .override_loader import OverrideLoader

# Import task submodules (maintains folder structure)
from . import tasks
from .tasks import integration_core

# Import specific task classes with qualified names for convenience
from .tasks.integration_core.process_crosswalk import ProcessCrosswalkTask
from .tasks.integration_core.check_master_exists import CheckMasterExistsExecutor
from .tasks.integration_core.endpoints_mapping import EndpointsMappingExecutor
from .tasks.integration_core.entity_job_status import EntityJobStatusExecutor
from .tasks.integration_core.manual_update import ManualUpdateExecutor
from .tasks.integration_core.parse_entity_model_json import ParseEntityModelJsonExecutor
from .tasks.integration_core.normal_deduplication.entity_matching_vector_search import VectorSearchExecutor
from .tasks.integration_core.normal_deduplication.entity_matching_llm import LLMMatchingExecutor
from .tasks.integration_core.normal_deduplication.manual_merge import ManualMergeExecutor
from .tasks.integration_core.normal_deduplication.manual_not_match import ManualNotMatchExecutor
from .tasks.integration_core.normal_deduplication.manual_unmerge import ManualUnmergeExecutor
from .tasks.integration_core.normal_deduplication.process_deterministic import ProcessDeterministicExecutor
from .tasks.integration_core.normal_deduplication.process_auto_merge import ProcessAutoMergeExecutor
from .tasks.integration_core.normal_deduplication.process_potential_match import ProcessPotentialMatchExecutor
from .tasks.integration_core.normal_deduplication.process_unmatched_records import ProcessUnmatchedRecordsExecutor
from .tasks.integration_core.normal_deduplication.update_table_metadata import UpdateTableMetadataExecutor
from .tasks.integration_core.initial_load.validate_initial_load import ValidateInitialLoadExecutor
from .tasks.integration_core.initial_load.create_tables import CreateTablesExecutor
from .tasks.integration_core.initial_load.load_primary_source import LoadPrimarySourceExecutor
from .tasks.integration_core.initial_load.load_secondary_sources import LoadSecondarySourcesExecutor

# Incremental Load executors
from .tasks.integration_core.incremental_load.validate_incremental_load import ValidateIncrementalLoadExecutor

# Golden deduplication executors
from .tasks.integration_core.golden_deduplication.entity_matching_vector_search import GoldenVectorSearchExecutor
from .tasks.integration_core.golden_deduplication.entity_matching_llm import GoldenLLMMatchingExecutor
from .tasks.integration_core.golden_deduplication.manual_merge import GoldenManualMergeExecutor
from .tasks.integration_core.golden_deduplication.manual_not_match import GoldenManualNotMatchExecutor
from .tasks.integration_core.golden_deduplication.process_deterministic import GoldenProcessDeterministicExecutor
from .tasks.integration_core.golden_deduplication.process_auto_merge import GoldenProcessAutoMergeExecutor
from .tasks.integration_core.golden_deduplication.process_potential_match import GoldenProcessPotentialMatchExecutor
from .tasks.integration_core.golden_deduplication.process_unified_dedup_table import ProcessUnifiedDedupTableExecutor
from .tasks.integration_core.golden_deduplication.update_table_metadata import GoldenUpdateTableMetadataExecutor

# Register built-in tasks with namespaced names
# Format: 'folder_path.task_name' to avoid conflicts between folders
TaskRegistry.register('integration_core.process_crosswalk', ProcessCrosswalkTask)
TaskRegistry.register('integration_core.check_master_exists', CheckMasterExistsExecutor)
TaskRegistry.register('integration_core.endpoints_mapping', EndpointsMappingExecutor)
TaskRegistry.register('integration_core.entity_job_status', EntityJobStatusExecutor)
TaskRegistry.register('integration_core.manual_update', ManualUpdateExecutor)
TaskRegistry.register('integration_core.parse_entity_model_json', ParseEntityModelJsonExecutor)
TaskRegistry.register('integration_core.normal_deduplication.vector_search', VectorSearchExecutor)
TaskRegistry.register('integration_core.normal_deduplication.llm_matching', LLMMatchingExecutor)
TaskRegistry.register('integration_core.normal_deduplication.manual_merge', ManualMergeExecutor)
TaskRegistry.register('integration_core.normal_deduplication.manual_not_match', ManualNotMatchExecutor)
TaskRegistry.register('integration_core.normal_deduplication.manual_unmerge', ManualUnmergeExecutor)
TaskRegistry.register('integration_core.normal_deduplication.process_deterministic', ProcessDeterministicExecutor)
TaskRegistry.register('integration_core.normal_deduplication.process_auto_merge', ProcessAutoMergeExecutor)
TaskRegistry.register('integration_core.normal_deduplication.process_potential_match', ProcessPotentialMatchExecutor)
TaskRegistry.register('integration_core.normal_deduplication.process_unmatched_records', ProcessUnmatchedRecordsExecutor)
TaskRegistry.register('integration_core.normal_deduplication.update_table_metadata', UpdateTableMetadataExecutor)
TaskRegistry.register('integration_core.initial_load.validate_initial_load', ValidateInitialLoadExecutor)
TaskRegistry.register('integration_core.initial_load.create_tables', CreateTablesExecutor)
TaskRegistry.register('integration_core.initial_load.load_primary_source', LoadPrimarySourceExecutor)
TaskRegistry.register('integration_core.initial_load.load_secondary_sources', LoadSecondarySourcesExecutor)

# Incremental Load tasks
TaskRegistry.register('integration_core.incremental_load.validate_incremental_load', ValidateIncrementalLoadExecutor)

# Golden deduplication tasks
TaskRegistry.register('integration_core.golden_deduplication.vector_search', GoldenVectorSearchExecutor)
TaskRegistry.register('integration_core.golden_deduplication.llm_matching', GoldenLLMMatchingExecutor)
TaskRegistry.register('integration_core.golden_deduplication.manual_merge', GoldenManualMergeExecutor)
TaskRegistry.register('integration_core.golden_deduplication.manual_not_match', GoldenManualNotMatchExecutor)
TaskRegistry.register('integration_core.golden_deduplication.process_deterministic', GoldenProcessDeterministicExecutor)
TaskRegistry.register('integration_core.golden_deduplication.process_auto_merge', GoldenProcessAutoMergeExecutor)
TaskRegistry.register('integration_core.golden_deduplication.process_potential_match', GoldenProcessPotentialMatchExecutor)
TaskRegistry.register('integration_core.golden_deduplication.process_unified_dedup_table', ProcessUnifiedDedupTableExecutor)
TaskRegistry.register('integration_core.golden_deduplication.update_table_metadata', GoldenUpdateTableMetadataExecutor)

__all__ = [
    # Models
    'TaskContext',
    'TaskResult',
    'TaskStatus',
    'ValidationResult',
    'ExecutionPhase',
    # Base
    'BaseTask',
    # Step-based execution
    'BaseStepTask',
    'step',
    # Registry
    'TaskRegistry',
    'create_task_executor',
    'register_task',
    # Override loader
    'OverrideLoader',
    # Task submodules (recommended access pattern)
    'tasks',
    'integration_core',
    # Direct task classes (for backward compatibility)
    'ProcessCrosswalkTask',
    'CheckMasterExistsExecutor',
    'EndpointsMappingExecutor',
    'EntityJobStatusExecutor',
    'ManualUpdateExecutor',
    'ParseEntityModelJsonExecutor',
    'VectorSearchExecutor',
    'LLMMatchingExecutor',
    'LLMMatchingDeterministicExecutor',
    'ManualMergeExecutor',
    'ManualNotMatchExecutor',
    'ManualUnmergeExecutor',
    'ProcessDeterministicExecutor',
    'ProcessAutoMergeExecutor',
    'ProcessPotentialMatchExecutor',
    'ProcessUnmatchedRecordsExecutor',
    'UpdateTableMetadataExecutor',
    # Initial Load executors
    'ValidateInitialLoadExecutor',
    'CreateTablesExecutor',
    'LoadPrimarySourceExecutor',
    'LoadSecondarySourcesExecutor',
    # Incremental Load executors
    'ValidateIncrementalLoadExecutor',
    # Golden Deduplication executors
    'GoldenVectorSearchExecutor',
    'GoldenLLMMatchingExecutor',
    'GoldenLLMMatchingDeterministicExecutor',
    'GoldenManualMergeExecutor',
    'GoldenManualNotMatchExecutor',
    'GoldenProcessDeterministicExecutor',
    'GoldenProcessAutoMergeExecutor',
    'GoldenProcessPotentialMatchExecutor',
    'ProcessUnifiedDedupTableExecutor',
    'GoldenUpdateTableMetadataExecutor',
]
