"""
Manual Unmerge Executor for normal deduplication.

Handles manual unmerge operations where unified records are removed from a master
and created as new individual masters.

Workflow:
1. Validate master record exists
2. Fetch all contributors for the master
3. Validate unmerge operation
4. Separate remaining and unmerge contributors
5. Recalculate master with remaining contributors
6. Apply survivorship for updated master
7. Generate new lakefusion IDs for unmerge records
8. Prepare unmerge records for master insert
9. Update master table (atomic transaction)
10. Prepare attribute version sources
11. Update attribute version sources
12. Log merge activities (atomic transaction)
13. Update unified table
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql.functions import (
    col, lit, collect_list, struct,
    current_timestamp, udf, concat_ws, coalesce
)
from pyspark.sql.types import (
    StructType, StructField, StringType, MapType, ArrayType
)
from delta.tables import DeltaTable

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult
from lakefusion_core_engine.utils.steward_decisions import write_steward_decision

from lakefusion_core_engine.utils import merged_record_column


class ManualUnmergeExecutor(BaseStepTask):
    """
    Executor for manual unmerge operations.

    Removes unified records from a master and creates them as new individual masters.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.id_key = context.master_id_key
        self.unified_id_key = context.unified_id_key
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Will be set during execution
        self.unmerge_count = 0
        self.remaining_count = 0
        self.total_contributors = 0
        self.new_lakefusion_ids = {}
        self.new_master_version = 0
        self.activities_count = 0

        # Instance variables for intermediate results
        self.unmerge_surrogate_keys = []
        self.unmerge_dataset_ids = []
        self.all_contributors_df = None
        self.unmerge_contributors_df = None
        self.remaining_contributors_df = None
        self.remaining_contributors_data = None
        self.unmerge_contributors_data = None
        self.remaining_schema = None
        self.unmerge_schema = None
        self.updated_master_results = None
        self.unmerge_insert_df = None
        self.all_attr_sources = None
        self._survivorship_engine = None
        self.new_ids_df = None

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        unmerge_unified_dataset_ids = self.context.unified_dataset_ids
        unmerge_surrogate_keys = []
        unmerge_dataset_ids = []
        for item in unmerge_unified_dataset_ids:
            unmerge_surrogate_keys.append(item.get("id"))
            unmerge_dataset_ids.append(item.get("dataset_id"))

        self.logger.info("="*80)
        self.logger.info("MANUAL UNMERGE PROCESSING")
        self.logger.info("="*80)
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Master ID: {self.context.master_id}")
        self.logger.info(f"Master ID Key: {self.id_key}")
        self.logger.info(f"Unified ID Key: {self.unified_id_key}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id or 'None'}")
        self.logger.info(f"Unified Table: {self.context.unified_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Merge Activities Table: {self.context.merge_activities_table}")
        self.logger.info(f"Attribute Version Sources Table: {self.context.attribute_version_sources_table}")
        self.logger.info(f"Records to unmerge: {len(unmerge_surrogate_keys)}")
        self.logger.info(f"Surrogate keys: {unmerge_surrogate_keys}")
        self.logger.info(f"Dataset IDs: {unmerge_dataset_ids}")
        self.logger.info("="*80)

        # Store for use in execute
        self.context.state['unmerge_surrogate_keys'] = unmerge_surrogate_keys
        self.context.state['unmerge_dataset_ids'] = unmerge_dataset_ids
        self.unmerge_surrogate_keys = unmerge_surrogate_keys
        self.unmerge_dataset_ids = unmerge_dataset_ids

        # Capture record snapshots BEFORE any modifications
        try:
            spark = self.context.spark
            attr_cols = ", ".join(self.context.entity_attributes)
            master_row = spark.sql(
                f"SELECT {attr_cols} FROM {self.context.master_table} WHERE {self.id_key} = '{self.context.master_id}'"
            ).collect()
            self._sd_master_attrs = master_row[0].asDict() if master_row else {}
            match_id = unmerge_surrogate_keys[0] if unmerge_surrogate_keys else None
            if match_id:
                # Check if match_id is a surrogate_key (sk_ prefix) or a lakefusion_id
                if str(match_id).startswith("sk_"):
                    match_row = spark.sql(
                        f"SELECT {attr_cols}, source_path FROM {self.context.unified_table} WHERE {self.unified_id_key} = '{match_id}'"
                    ).collect()
                else:
                    match_row = spark.sql(
                        f"SELECT {attr_cols} FROM {self.context.master_table} WHERE {self.id_key} = '{match_id}'"
                    ).collect()
                self._sd_match_attrs = match_row[0].asDict() if match_row else {}
            else:
                self._sd_match_attrs = {}
        except Exception as e:
            self.logger.warning(f"Could not capture steward decision snapshots: {e}")
            self._sd_master_attrs = {}
            self._sd_match_attrs = {}

    @step(order=1, name="Validate Master Record Exists", returns="master_exists confirmation")
    def step_validate_master_record_exists(self) -> Dict[str, Any]:
        """Validate that the master record exists."""
        spark = self.context.spark
        master_id = self.context.master_id

        master_exists_query = f"""
        SELECT COUNT(*) as count
        FROM {self.context.master_table}
        WHERE {self.id_key} = '{master_id}'
        """

        master_exists = spark.sql(master_exists_query).collect()[0]['count']

        if master_exists == 0:
            error_msg = f"ERROR: Master record with {self.id_key} = '{master_id}' not found"
            self.logger.info(error_msg)
            raise ValueError(error_msg)

        self.logger.info(f"  Master record exists: {self.id_key} = {master_id}")

        return {
            'master_id': master_id,
            'master_exists': True
        }

    @step(order=2, name="Fetch All Contributors for Master", returns="all_contributors_df")
    def step_fetch_all_contributors(self) -> Dict[str, Any]:
        """Fetch all contributors for the master."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes
        master_id = self.context.master_id

        attribute_cols = ", ".join([f"u.{attr}" for attr in entity_attributes])

        all_contributors_query = f"""
        SELECT
            u.{self.unified_id_key},
            u.source_path,
            {attribute_cols}
        FROM {self.context.unified_table} u
        WHERE u.master_{self.id_key} = '{master_id}'
            AND u.record_status = 'MERGED'
        """

        self.all_contributors_df = spark.sql(all_contributors_query)
        self.total_contributors = self.all_contributors_df.count()

        self.logger.info(f"  Total contributors found: {self.total_contributors}")

        return {
            'total_contributors': self.total_contributors
        }

    @step(order=3, name="Validate Unmerge Operation", returns="validation results")
    def step_validate_unmerge_operation(self) -> Dict[str, Any]:
        """Validate the unmerge operation."""
        unmerge_surrogate_keys = self.context.state['unmerge_surrogate_keys']

        self.unmerge_contributors_df = self.all_contributors_df.filter(
            col(self.unified_id_key).isin(unmerge_surrogate_keys)
        )
        self.unmerge_count = self.unmerge_contributors_df.count()

        self.logger.info(f"  Records to unmerge found in contributors: {self.unmerge_count}")

        if self.unmerge_count == 0:
            error_msg = "ERROR: None of the specified records are contributors to this master"
            self.logger.info(error_msg)
            raise ValueError(error_msg)

        if self.unmerge_count != len(unmerge_surrogate_keys):
            missing_count = len(unmerge_surrogate_keys) - self.unmerge_count
            self.logger.info(f"  WARNING: {missing_count} requested records are not contributors to this master")

        remaining_contributors_count = self.total_contributors - self.unmerge_count

        if remaining_contributors_count == 0:
            error_msg = f"ERROR: Cannot unmerge - this is the only contributor to the master. Master would be left empty. (total_contributors={self.total_contributors}, attempting_to_unmerge={self.unmerge_count})"
            self.logger.info(error_msg)
            raise ValueError(error_msg)

        self.logger.info(f"  Validation passed")
        self.logger.info(f"  Total contributors: {self.total_contributors}")
        self.logger.info(f"  Unmerging: {self.unmerge_count}")
        self.logger.info(f"  Remaining: {remaining_contributors_count}")

        return {
            'unmerge_count': self.unmerge_count,
            'remaining_count': remaining_contributors_count,
            'validation_passed': True
        }

    @step(order=4, name="Separate Remaining and Unmerge Contributors", returns="materialized contributor data")
    def step_separate_contributors(self) -> Dict[str, Any]:
        """Separate remaining and unmerge contributors."""
        unmerge_surrogate_keys = self.context.state['unmerge_surrogate_keys']

        self.remaining_contributors_df = self.all_contributors_df.filter(
            ~col(self.unified_id_key).isin(unmerge_surrogate_keys)
        )

        self.remaining_count = self.remaining_contributors_df.count()

        self.logger.info(f"  Remaining contributors: {self.remaining_count}")
        self.logger.info(f"  Unmerge contributors: {self.unmerge_count}")

        # Capture schemas and materialize
        self.remaining_schema = self.remaining_contributors_df.schema
        self.unmerge_schema = self.unmerge_contributors_df.schema

        self.remaining_contributors_data = self.remaining_contributors_df.collect()
        self.unmerge_contributors_data = self.unmerge_contributors_df.collect()

        self.logger.info(f"  Materialized {len(self.remaining_contributors_data)} remaining contributors")
        self.logger.info(f"  Materialized {len(self.unmerge_contributors_data)} unmerge contributors")

        return {
            'remaining_count': self.remaining_count,
            'unmerge_count': self.unmerge_count,
            'remaining_contributors_materialized': len(self.remaining_contributors_data),
            'unmerge_contributors_materialized': len(self.unmerge_contributors_data)
        }

    @step(order=5, name="Recalculate Master with Remaining Contributors", returns="grouped_remaining DataFrame")
    def step_recalculate_master(self) -> Dict[str, Any]:
        """Recalculate master with remaining contributors."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes
        master_id = self.context.master_id

        remaining_contributors_df = spark.createDataFrame(
            self.remaining_contributors_data, schema=self.remaining_schema
        )

        self.grouped_remaining = (
            remaining_contributors_df
            .withColumn(self.id_key, lit(master_id))
            .groupBy(self.id_key)
            .agg(
                collect_list(
                    struct(
                        col(self.unified_id_key),
                        col("source_path"),
                        *[col(attr) for attr in entity_attributes]
                    )
                ).alias("unified_records")
            )
        )

        self.logger.info(f"  Grouped remaining contributors for survivorship")

        return {
            'grouped_remaining_created': True
        }

    @step(order=6, name="Apply Survivorship for Updated Master", returns="updated_master_results DataFrame")
    def step_apply_survivorship(self) -> Dict[str, Any]:
        """Apply survivorship for updated master."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes
        entity_attributes_datatype = self.context.entity_attributes_datatype
        default_survivorship_rules = self.context.default_survivorship_rules
        dataset_objects = self.context.dataset_objects

        # Initialize survivorship engine
        from lakefusion_core_engine.survivorship import SurvivorshipEngine

        self.logger.info(f"  Survivorship rules: {len(default_survivorship_rules)}")

        self._survivorship_engine = SurvivorshipEngine(
            survivorship_config=default_survivorship_rules,
            entity_attributes=entity_attributes,
            entity_attributes_datatype=entity_attributes_datatype,
            id_key=self.unified_id_key
        )

        self.logger.info(f"  Survivorship Engine initialized")

        # Define UDF wrapper
        engine = self._survivorship_engine

        def apply_survivorship_wrapper(unified_records):
            records_list = [r.asDict() for r in unified_records]
            result = engine.apply_survivorship(unified_records=records_list)
            return result.to_dict()

        udf_output_schema = StructType([
            StructField("resultant_record", MapType(StringType(), StringType())),
            StructField("resultant_master_attribute_source_mapping", ArrayType(StructType([
                StructField("attribute_name", StringType()),
                StructField("attribute_value", StringType()),
                StructField("source", StringType())
            ])))
        ])

        survivorship_udf = udf(apply_survivorship_wrapper, udf_output_schema)

        result_df = self.grouped_remaining.withColumn(
            "survivorship_result",
            survivorship_udf(col("unified_records"))
        )

        self.updated_master_results = result_df.select(
            col(self.id_key),
            col("survivorship_result.resultant_record").alias("merged_record"),
            col("survivorship_result.resultant_master_attribute_source_mapping").alias("attribute_sources")
        )

        self.logger.info(f"  Survivorship applied for updated master")

        return {
            'survivorship_applied': True
        }

    @step(order=7, name="Generate New LakeFusion IDs for Unmerge Records", returns="new_lakefusion_ids dict")
    def step_generate_new_lakefusion_ids(self) -> Dict[str, Any]:
        """Generate new lakefusion IDs for unmerge records."""
        from lakefusion_core_engine.identifiers import generate_lakefusion_id

        unmerge_unified_dataset_ids = self.context.unified_dataset_ids

        for item in unmerge_unified_dataset_ids:
            surrogate_key = item.get("id")
            new_lf_id = generate_lakefusion_id()
            self.new_lakefusion_ids[surrogate_key] = new_lf_id
            self.logger.info(f"  {surrogate_key} -> {new_lf_id}")

        self.logger.info(f"  Generated {len(self.new_lakefusion_ids)} new lakefusion IDs")

        return {
            'new_lakefusion_ids_count': len(self.new_lakefusion_ids),
            'new_lakefusion_ids': list(self.new_lakefusion_ids.values())
        }

    @step(order=8, name="Prepare Unmerge Records for Master Insert", returns="unmerge_insert_df DataFrame")
    def step_prepare_unmerge_records(self) -> Dict[str, Any]:
        """Prepare unmerge records for master insert."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes
        entity_attributes_datatype = self.context.entity_attributes_datatype
        match_attributes = self.context.match_attributes

        unmerge_contributors_df = spark.createDataFrame(
            self.unmerge_contributors_data, schema=self.unmerge_schema
        )

        new_ids_data = [{"surrogate_key": sk, "new_lakefusion_id": lf_id}
                        for sk, lf_id in self.new_lakefusion_ids.items()]
        self.new_ids_df = spark.createDataFrame(new_ids_data)

        unmerge_with_ids_df = unmerge_contributors_df.join(
            self.new_ids_df,
            on=self.unified_id_key,
            how="inner"
        )

        insert_cols = [col("new_lakefusion_id").alias(self.id_key)]

        for attr in entity_attributes:
            if attr == self.id_key:
                continue

            target_type = entity_attributes_datatype.get(attr, "string")

            if target_type.lower() in ["timestamp", "date", "datetime"]:
                insert_cols.append(col(attr).cast("timestamp").alias(attr))
            elif target_type.lower() in ["int", "integer", "long", "bigint"]:
                insert_cols.append(col(attr).cast("long").alias(attr))
            elif target_type.lower() in ["float", "double", "decimal"]:
                insert_cols.append(col(attr).cast("double").alias(attr))
            elif target_type.lower() in ["boolean", "bool"]:
                insert_cols.append(col(attr).cast("boolean").alias(attr))
            else:
                insert_cols.append(col(attr).alias(attr))

        # Add attributes_combined
        if match_attributes:
            concat_cols = []
            for attr in match_attributes:
                if attr in entity_attributes:
                    concat_cols.append(coalesce(col(attr).cast("string"), lit("")))

            if concat_cols:
                insert_cols.append(
                    concat_ws(" | ", *concat_cols).alias("attributes_combined")
                )
            else:
                insert_cols.append(lit("").alias("attributes_combined"))
        else:
            insert_cols.append(lit("").alias("attributes_combined"))

        self.unmerge_insert_df = unmerge_with_ids_df.select(*insert_cols)

        insert_count = self.unmerge_insert_df.count()
        self.logger.info(f"  Prepared {insert_count} records for master insert")

        return {
            'records_prepared': insert_count
        }

    @step(order=9, name="Update Master Table (Atomic Transaction)", returns="new_master_version")
    def step_update_master_table(self) -> Dict[str, Any]:
        """Update master table (atomic transaction)."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes
        entity_attributes_datatype = self.context.entity_attributes_datatype
        match_attributes = self.context.match_attributes

        self.logger.info(f"  Match attributes: {match_attributes}")

        master_update_cols = [col(self.id_key)]

        for attr in entity_attributes:
            if attr == self.id_key:
                continue

            target_type = entity_attributes_datatype.get(attr, "string")
            master_update_cols.append(merged_record_column(attr, target_type))

        if match_attributes:
            concat_cols = []
            for attr in match_attributes:
                if attr in entity_attributes:
                    concat_cols.append(coalesce(col(f"merged_record.{attr}").cast("string"), lit("")))

            if concat_cols:
                master_update_cols.append(
                    concat_ws(" | ", *concat_cols).alias("attributes_combined")
                )
                self.logger.info(f"  Generated attributes_combined from: {match_attributes}")
            else:
                master_update_cols.append(lit("").alias("attributes_combined"))
                self.logger.info("  Warning: No valid match attributes found, using empty string")
        else:
            master_update_cols.append(lit("").alias("attributes_combined"))
            self.logger.info("  Warning: No match attributes defined, using empty string")

        master_updates_df = self.updated_master_results.select(*master_update_cols)

        current_master_version = spark.sql(f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1").select("version").collect()[0][0]
        self.logger.info(f"  Current master version: {current_master_version}")

        master_delta_table = DeltaTable.forName(spark, self.context.master_table)

        update_dict = {attr: f"source.{attr}" for attr in entity_attributes if attr != self.id_key}
        update_dict["attributes_combined"] = "source.attributes_combined"

        combined_source = master_updates_df.union(self.unmerge_insert_df)

        master_delta_table.alias("target").merge(
            combined_source.alias("source"),
            f"target.{self.id_key} = source.{self.id_key}"
        ).whenMatchedUpdate(
            set=update_dict
        ).whenNotMatchedInsertAll().execute()

        self.new_master_version = spark.sql(f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1").select("version").collect()[0][0]

        self.logger.info(f"  Master table updated (atomic transaction)")
        self.logger.info(f"  New version: {self.new_master_version}")
        self.logger.info(f"  Updated existing master: 1")
        self.logger.info(f"  Inserted unmerged records: {self.unmerge_count}")

        return {
            'new_master_version': int(self.new_master_version),
            'updated_existing_master': 1,
            'inserted_unmerged_records': self.unmerge_count
        }

    @step(order=10, name="Prepare Attribute Version Sources", returns="all_attr_sources DataFrame")
    def step_prepare_attribute_version_sources(self) -> Dict[str, Any]:
        """Prepare attribute version sources."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes

        updated_master_attr_sources = self.updated_master_results.select(
            col(self.id_key),
            lit(self.new_master_version).alias("version"),
            col("attribute_sources").alias("attribute_source_mapping")
        )

        # Recreate for single contributor sources
        unmerge_contributors_df = spark.createDataFrame(
            self.unmerge_contributors_data, schema=self.unmerge_schema
        )
        unmerge_with_ids_df = unmerge_contributors_df.join(
            self.new_ids_df, on=self.unified_id_key, how="inner"
        )

        def create_single_contributor_sources(source_path, attributes, attribute_values_row):
            if hasattr(attribute_values_row, 'asDict'):
                attribute_values = attribute_values_row.asDict()
            else:
                attribute_values = attribute_values_row

            sources = []
            for attr in attributes:
                if attr != 'lakefusion_id':
                    value = attribute_values.get(attr)
                    sources.append({
                        "attribute_name": attr,
                        "attribute_value": str(value) if value is not None else None,
                        "source": source_path
                    })
            return sources

        single_contributor_udf = udf(
            lambda source_path, attr_row: create_single_contributor_sources(
                source_path,
                entity_attributes,
                attr_row
            ),
            ArrayType(StructType([
                StructField("attribute_name", StringType()),
                StructField("attribute_value", StringType()),
                StructField("source", StringType())
            ]))
        )

        attr_cols_struct = struct(*[col(attr).alias(attr) for attr in entity_attributes if attr != self.id_key])

        unmerged_attr_sources = unmerge_with_ids_df.select(
            col("new_lakefusion_id").alias(self.id_key),
            lit(self.new_master_version).alias("version"),
            single_contributor_udf(col("source_path"), attr_cols_struct).alias("attribute_source_mapping")
        )

        self.all_attr_sources = updated_master_attr_sources.union(unmerged_attr_sources)

        total_count = self.all_attr_sources.count()
        self.logger.info(f"  Prepared attribute version sources")
        self.logger.info(f"  Updated master: 1")
        self.logger.info(f"  Unmerged records: {self.unmerge_count}")
        self.logger.info(f"  Total: {total_count}")

        return {
            'updated_master_attr_sources': 1,
            'unmerged_attr_sources': self.unmerge_count,
            'total_attr_sources': total_count
        }

    @step(order=11, name="Update Attribute Version Sources", returns="records updated count")
    def step_update_attribute_version_sources(self) -> Dict[str, Any]:
        """Update attribute version sources."""
        spark = self.context.spark

        attr_sources_delta_table = DeltaTable.forName(spark, self.context.attribute_version_sources_table)

        attr_sources_delta_table.alias("target").merge(
            self.all_attr_sources.alias("source"),
            f"target.{self.id_key} = source.{self.id_key} AND target.version = source.version"
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

        records_count = self.all_attr_sources.count()
        self.logger.info(f"  Attribute version sources updated")
        self.logger.info(f"  Records updated/inserted: {records_count}")

        return {
            'records_updated_inserted': records_count
        }

    @step(order=12, name="Log Merge Activities (Atomic Transaction)", returns="activities_count")
    def step_log_merge_activities(self) -> Dict[str, Any]:
        """Log merge activities (atomic transaction)."""
        spark = self.context.spark
        master_id = self.context.master_id

        # Recreate for activities
        unmerge_contributors_df = spark.createDataFrame(
            self.unmerge_contributors_data, schema=self.unmerge_schema
        )
        unmerge_with_ids_df = unmerge_contributors_df.join(
            self.new_ids_df, on=self.unified_id_key, how="inner"
        )

        unmerge_activities = unmerge_with_ids_df.select(
            lit(master_id).alias("master_id"),
            col(self.unified_id_key).alias("match_id"),
            col("source_path").alias("source"),
            lit(self.new_master_version).alias("version"),
            lit("MANUAL_UNMERGE").alias("action_type"),
            current_timestamp().alias("created_at")
        )

        insert_activities = unmerge_with_ids_df.select(
            col("new_lakefusion_id").alias("master_id"),
            col(self.unified_id_key).alias("match_id"),
            col("source_path").alias("source"),
            lit(self.new_master_version).alias("version"),
            lit("JOB_INSERT").alias("action_type"),
            current_timestamp().alias("created_at")
        )

        all_activities = unmerge_activities.union(insert_activities)
        self.activities_count = all_activities.count()

        self.logger.info(f"  Prepared merge activities:")
        self.logger.info(f"    MANUAL_UNMERGE: {self.unmerge_count}")
        self.logger.info(f"    JOB_INSERT: {self.unmerge_count}")
        self.logger.info(f"    Total: {self.activities_count}")

        if self.activities_count > 0:
            merge_activities_delta_table = DeltaTable.forName(spark, self.context.merge_activities_table)

            merge_activities_delta_table.alias("target").merge(
                all_activities.alias("source"),
                f"""target.match_id = source.match_id
                    AND target.master_id = source.master_id
                    AND target.version = source.version
                    AND target.action_type = source.action_type"""
            ).whenNotMatchedInsertAll().execute()

            self.logger.info(f"  Merge activities logged (atomic transaction)")
        else:
            self.logger.info("  No merge activities to log")

        return {
            'manual_unmerge_activities': self.unmerge_count,
            'job_insert_activities': self.unmerge_count,
            'total_activities': self.activities_count
        }

    @step(order=13, name="Update Unified Table", returns="records updated count")
    def step_update_unified_table(self) -> Dict[str, Any]:
        """Update unified table."""
        spark = self.context.spark

        # Recreate for unified update
        unmerge_contributors_df = spark.createDataFrame(
            self.unmerge_contributors_data, schema=self.unmerge_schema
        )
        unmerge_with_ids_df = unmerge_contributors_df.join(
            self.new_ids_df, on=self.unified_id_key, how="inner"
        )

        unified_updates_df = unmerge_with_ids_df.select(
            col(self.unified_id_key),
            col("new_lakefusion_id").alias(f"master_{self.id_key}")
        )

        records_count = unified_updates_df.count()
        self.logger.info(f"  Prepared {records_count} records for unified table update")

        unified_delta_table = DeltaTable.forName(spark, self.context.unified_table)

        unified_delta_table.alias("target").merge(
            unified_updates_df.alias("source"),
            f"target.{self.unified_id_key} = source.{self.unified_id_key}"
        ).whenMatchedUpdate(set={
            f"master_{self.id_key}": f"source.master_{self.id_key}"
        }).execute()

        self.logger.info(f"  Unified table updated")
        self.logger.info(f"  Records updated: {records_count}")

        return {
            'records_updated': records_count
        }

    @step(order=14, name="Write Steward Decision", returns="decision_id")
    def step_write_steward_decision(self) -> Dict[str, Any]:
        """Write frozen record snapshots to steward_decisions Delta table."""
        sk = self.context.state.get('unmerge_surrogate_keys', [])
        master_attrs = getattr(self, '_sd_master_attrs', {})
        match_attrs = getattr(self, '_sd_match_attrs', {})
        match_source = match_attrs.get("source_path", "") if match_attrs else ""
        decision_id = write_steward_decision(
            spark=self.context.spark, catalog_name=self.context.catalog_name,
            entity_name=self.context.entity, entity_id=str(self.context.entity_id or ""),
            action_type="MANUAL_UNMERGE", master_id=self.context.master_id,
            match_id=sk[0] if sk else "", master_attrs=master_attrs, match_attrs=match_attrs,
            match_source=match_source, created_by=self.context.params.get("created_by", ""),
            logger=self.logger,
        )
        return {"decision_id": decision_id}

    def execute(self) -> TaskResult:
        """Execute the manual unmerge workflow."""
        master_id = self.context.master_id

        # Step 1: Validate master record exists
        self.step_validate_master_record_exists()

        # Step 2: Fetch all contributors for the master
        self.step_fetch_all_contributors()

        # Step 3: Validate unmerge operation
        self.step_validate_unmerge_operation()

        # Step 4: Separate remaining and unmerge contributors
        self.step_separate_contributors()

        # Step 5: Recalculate master with remaining contributors
        self.step_recalculate_master()

        # Step 6: Apply survivorship for updated master
        self.step_apply_survivorship()

        # Step 7: Generate new lakefusion IDs for unmerge records
        self.step_generate_new_lakefusion_ids()

        # Step 8: Prepare unmerge records for master insert
        self.step_prepare_unmerge_records()

        # Step 9: Update master table (atomic transaction)
        self.step_update_master_table()

        # Step 10: Prepare attribute version sources
        self.step_prepare_attribute_version_sources()

        # Step 11: Update attribute version sources
        self.step_update_attribute_version_sources()

        # Step 12: Log merge activities (atomic transaction)
        self.step_log_merge_activities()

        # Step 13: Update unified table
        self.step_update_unified_table()

        # Step 14: Write steward decision
        self.step_write_steward_decision()

        return TaskResult.success(
            message="Manual unmerge completed successfully",
            task_name=self.context.task_name,
            metrics={
                'original_master_id': master_id,
                'records_unmerged': self.unmerge_count,
                'remaining_contributors': self.remaining_count,
                'new_masters_created': self.unmerge_count,
                'new_lakefusion_ids': list(self.new_lakefusion_ids.values()),
                'master_version': int(self.new_master_version)
            },
            task_values={
                'manual_unmerge_complete': True,
                'records_unmerged': self.unmerge_count,
                'original_master_id': master_id,
                'new_lakefusion_ids': list(self.new_lakefusion_ids.values()),
                'master_version': int(self.new_master_version)
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=self.unmerge_count > 0,
            message="Records unmerged",
            expected="> 0",
            actual=self.unmerge_count
        ))

        result.add_validation(ValidationResult(
            passed=len(self.new_lakefusion_ids) == self.unmerge_count,
            message="New lakefusion IDs generated",
            expected=self.unmerge_count,
            actual=len(self.new_lakefusion_ids)
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*80)
        self.logger.info("MANUAL UNMERGE PROCESSING COMPLETE")
        self.logger.info("="*80)

        if result.is_success:
            metrics = result.metrics
            self.logger.info(f"\nSummary:")
            self.logger.info(f"  Original master ID: {metrics.get('original_master_id')}")
            self.logger.info(f"  Records unmerged: {metrics.get('records_unmerged')}")
            self.logger.info(f"  Remaining contributors to original master: {metrics.get('remaining_contributors')}")
            self.logger.info(f"  New individual masters created: {metrics.get('new_masters_created')}")
            self.logger.info(f"  Master table version: {metrics.get('master_version')}")
            self.logger.info(f"\n  New lakefusion IDs created:")
            for sk, lf_id in self.new_lakefusion_ids.items():
                self.logger.info(f"    {sk} -> {lf_id}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Manual unmerge failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.info(f"  Error: {error}")
