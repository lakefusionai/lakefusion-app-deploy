"""
Identifier generation utilities for MDM pipeline.

This module provides functions for generating and validating surrogate keys
and lakefusion IDs used throughout the MDM system.
"""

from .surrogate_key import (
    generate_surrogate_key,
    validate_surrogate_key,
    extract_source_info_from_key,
    batch_generate_surrogate_keys
)

from .lakefusion_id import (
    generate_lakefusion_id,
    generate_lakefusion_id_with_prefix,
    validate_lakefusion_id,
    format_lakefusion_id,
    batch_generate_lakefusion_ids,
    is_surrogate_key
)

__all__ = [
    # Surrogate Key
    "generate_surrogate_key",
    "validate_surrogate_key",
    "extract_source_info_from_key",
    "batch_generate_surrogate_keys",
    # Lakefusion ID
    "generate_lakefusion_id",
    "generate_lakefusion_id_with_prefix",
    "validate_lakefusion_id",
    "format_lakefusion_id",
    "batch_generate_lakefusion_ids",
    "is_surrogate_key",
]