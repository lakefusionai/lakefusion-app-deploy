"""
Surrogate Key Generation for MDM Pipeline.

Generates unique surrogate keys for source records that persist throughout
the entire lineage tracking system.
"""

import hashlib
from typing import Any


def generate_surrogate_key(source_path: str, source_id: str) -> str:
    """
    Generate a deterministic surrogate key for source records.
    
    Args:
        source_path: Source table path
        source_id: Source record ID
        
    Returns:
        surrogate_key with 'sk_' prefix
    """
    composite = f"{source_path}_{source_id}"
    hash_value = hashlib.md5(composite.encode()).hexdigest()
    return f"sk_{hash_value}"


def validate_surrogate_key(surrogate_key: str) -> bool:
    """
    Validate that a surrogate key has the correct format.
    
    Args:
        surrogate_key: The surrogate key to validate
        
    Returns:
        True if valid, False otherwise
        
    Examples:
        >>> validate_surrogate_key("sk_a7c829c674f54664a2c9dd7b1f2363fc")
        True
        
        >>> validate_surrogate_key("invalid_key")
        False
    """
    if not isinstance(surrogate_key, str):
        return False
    
    if not surrogate_key.startswith("sk_"):
        return False
    
    # Check if the hash part is a valid MD5 (32 hex characters)
    hash_part = surrogate_key[3:]  # Remove 'sk_' prefix
    
    if len(hash_part) != 32:
        return False
    
    try:
        # Verify it's a valid hexadecimal string
        int(hash_part, 16)
        return True
    except ValueError:
        return False


def extract_source_info_from_key(surrogate_key: str) -> dict[str, str]:
    """
    Extract metadata from a surrogate key.
    
    Note: This only validates the key format. The actual source_path and source_id
    cannot be retrieved from the hash (one-way function).
    
    Args:
        surrogate_key: The surrogate key to analyze
        
    Returns:
        Dictionary with metadata about the key
        
    Examples:
        >>> extract_source_info_from_key("sk_a7c829c674f54664a2c9dd7b1f2363fc")
        {'is_valid': True, 'hash': 'a7c829c674f54664a2c9dd7b1f2363fc', 'prefix': 'sk_'}
    """
    return {
        "is_valid": validate_surrogate_key(surrogate_key),
        "prefix": surrogate_key[:3] if len(surrogate_key) >= 3 else "",
        "hash": surrogate_key[3:] if len(surrogate_key) > 3 else "",
        "length": len(surrogate_key)
    }


def batch_generate_surrogate_keys(
    source_path: str,
    source_ids: list[str | Any]
) -> list[str]:
    """
    Generate surrogate keys for multiple source records efficiently.
    
    Args:
        source_path: Common source path for all records
        source_ids: List of source IDs
        
    Returns:
        List of surrogate keys in the same order as source_ids
        
    Examples:
        >>> batch_generate_surrogate_keys("dbfs:/data/customers.csv", ["CUST_001", "CUST_002"])
        ['sk_a7c829c674f54664a2c9dd7b1f2363fc', 'sk_b8d93ad785e65775b3dae8c8e3f2474d']
    """
    return [generate_surrogate_key(source_path, sid) for sid in source_ids]