"""
Main Survivorship Engine.
Orchestrates the application of survivorship rules across all attributes.
"""

from typing import List, Dict, Any, Optional

from .models.config import SurvivorshipConfig, RuleConfig
from .models.result import SurvivorshipResult, AttributeSourceMapping, StrategyContext
from .strategies import RecencyStrategy, SourceSystemStrategy, AggregationStrategy, FrequencyStrategy
from .strategies.base import BaseStrategy
from .utils.helpers import safe_str, is_null_or_empty, convert_to_native_type


class SurvivorshipEngine:
    """
    Main engine for applying survivorship rules to merge records.
    
    The engine takes survivorship configuration and applies the appropriate strategy
    for each attribute to determine which value should survive when merging records.
    
    Key Features:
    - Per-attribute ignoreNull and aggregateUniqueOnly settings
    - Comprehensive fallback mechanism that tries all available sources
    - Proper type handling for numeric aggregation (rounds integers)
    - Returns values in native types, converted to strings only in final output
    
    Supported Strategies:
    - Source System: Prioritize values based on source system hierarchy
    - Recency: Select value from most recently updated record
    - Aggregation: Combine values using configured function (sum, avg, min, max, etc.)
    - Frequency: Select most/least frequently occurring value
    
    Usage:
        engine = SurvivorshipEngine(
            survivorship_config=survivorship_rules,
            entity_attributes=entity_attributes,
            entity_attributes_datatype=entity_attributes_datatype,
            id_key="surrogate_key"
        )
        
        result = engine.apply_survivorship(
            unified_records=[...]  # All contributor records with surrogate_key and source_path
        )
    """
    
    # Strategy registry mapping strategy names to strategy classes
    STRATEGY_REGISTRY = {
        'Recency': RecencyStrategy,
        'Source System': SourceSystemStrategy,
        'Aggregation': AggregationStrategy,
        'Frequency': FrequencyStrategy
    }
    
    def __init__(self, survivorship_config: List[dict], entity_attributes: List[str],
                 entity_attributes_datatype: dict, id_key: str):
        """
        Initialize the survivorship engine.
        
        Args:
            survivorship_config: List of survivorship rule dictionaries from entity model
            entity_attributes: List of all entity attribute names
            entity_attributes_datatype: Dict mapping attribute names to data types
            id_key: Primary key attribute name (e.g., "surrogate_key" for unified table)
        """
        # Parse configuration
        self.config = SurvivorshipConfig.from_config(
            survivorship_rules=survivorship_config,
            entity_attributes=entity_attributes,
            entity_attributes_datatype=entity_attributes_datatype,
            id_key=id_key
        )
        
        # Initialize strategy instances
        self.strategies: Dict[str, BaseStrategy] = {
            strategy_name: strategy_class()
            for strategy_name, strategy_class in self.STRATEGY_REGISTRY.items()
        }
        
        # Collect ALL priority sources from configuration for comprehensive fallback
        self.all_priority_sources = self._collect_all_priority_sources()
        
        # Determine primary source (first in any Source System rule)
        self.primary_source = self._determine_primary_source()
    
    def apply_survivorship(
        self,
        unified_records: List[Dict[str, Any]]
    ) -> SurvivorshipResult:
        """
        Apply survivorship rules to unified records.
        
        Args:
            unified_records: List of ALL contributor records, each containing:
                - surrogate_key (required): Unique record identifier
                - source_path (required): Source table path (catalog.schema.table)
                - [business attributes]: All entity attributes
            
        Returns:
            SurvivorshipResult with merged record and attribute source mappings
            
        Raises:
            ValueError: If required fields are missing from records
        """
        # Validate required fields
        self._validate_records(unified_records)
        
        # Result containers
        resultant_record = {}
        resultant_mappings = []
        
        # Process each attribute
        for attribute_name in self.config.entity_attributes:
            # Skip the ID key
            if attribute_name == self.config.id_key:
                continue
            
            # Get the rule for this attribute
            rule = self.config.get_rule_for_attribute(attribute_name)
            
            if rule:
                # Apply the configured strategy
                value, source = self._apply_rule(
                    attribute_name=attribute_name,
                    rule=rule,
                    unified_records=unified_records
                )
            else:
                # No rule defined - use comprehensive fallback
                value, source = self._get_comprehensive_fallback(
                    attribute_name=attribute_name,
                    unified_records=unified_records,
                    ignore_null=False  # Default behavior: take first value found
                )
            
            # Store the result (convert to string for consistent Spark UDF output)
            resultant_record[attribute_name] = safe_str(value) if value is not None else None
            
            # Create attribute source mapping only if value exists
            if value is not None and source:
                resultant_mappings.append(
                    AttributeSourceMapping(
                        attribute_name=attribute_name,
                        attribute_value=safe_str(value),
                        source=source
                    )
                )
        
        return SurvivorshipResult(
            resultant_record=resultant_record,
            resultant_master_attribute_source_mapping=resultant_mappings
        )
    
    def _validate_records(self, unified_records: List[Dict[str, Any]]) -> None:
        """
        Validate that all records have required fields.
        
        Args:
            unified_records: List of unified records
            
        Raises:
            ValueError: If required fields are missing
        """
        if not unified_records:
            raise ValueError("unified_records cannot be empty")
        
        for i, record in enumerate(unified_records):
            if "surrogate_key" not in record:
                raise ValueError(f"Missing required field 'surrogate_key' in record at index {i}")
            if "source_path" not in record:
                raise ValueError(f"Missing required field 'source_path' in record at index {i}")
    
    def _collect_all_priority_sources(self) -> List[str]:
        """
        Collect all unique source paths from all Source System rules.
        
        This is used for comprehensive fallback - we try all known sources
        in order before giving up.
        
        Returns:
            List of unique source paths from all Source System rules
        """
        all_sources = []
        
        for rule in self.config.rules:
            if rule.strategy == "Source System" and rule.strategyRule:
                if isinstance(rule.strategyRule, list):
                    for source in rule.strategyRule:
                        if source is not None and source not in all_sources:
                            all_sources.append(source)
        
        return all_sources
    
    def _determine_primary_source(self) -> Optional[str]:
        """
        Determine primary source from configuration.
        Uses first valid table in any Source System strategy as the primary source.
        
        Returns:
            Primary source table path or None if not found
        """
        for rule in self.config.rules:
            if rule.strategy == "Source System" and rule.strategyRule:
                if isinstance(rule.strategyRule, list):
                    for source in rule.strategyRule:
                        if source is not None:
                            return source
        return None
    
    def _get_comprehensive_fallback(
        self, 
        attribute_name: str, 
        unified_records: List[Dict[str, Any]],
        ignore_null: bool = False
    ) -> tuple:
        """
        Get attribute value from any available source.
        
        This comprehensive fallback:
        1. First tries all priority sources in order
        2. Then tries any other sources present in the records
        
        This ensures we NEVER return None if there's a valid value anywhere.
        
        Args:
            attribute_name: Attribute name
            unified_records: List of unified records
            ignore_null: Whether to skip null values
            
        Returns:
            Tuple of (value, source) or (None, None) if no value found anywhere
        """
        checked_sources = set()
        
        # First, try all priority sources in order
        for source in self.all_priority_sources:
            if source is None:
                continue
            checked_sources.add(source)
            
            for record in unified_records:
                if record.get("source_path") == source:
                    value = record.get(attribute_name)
                    
                    if ignore_null and is_null_or_empty(value):
                        continue
                    
                    if value is not None:
                        return value, source
        
        # Second, try any remaining sources in the records
        for record in unified_records:
            source = record.get("source_path")
            
            if source in checked_sources:
                continue
            checked_sources.add(source)
            
            value = record.get(attribute_name)
            
            if ignore_null and is_null_or_empty(value):
                continue
            
            if value is not None:
                return value, source
        
        # No value found anywhere
        return None, None
    
    def _apply_rule(
        self,
        attribute_name: str,
        rule: RuleConfig,
        unified_records: List[Dict[str, Any]]
    ) -> tuple:
        """
        Apply a specific survivorship rule.
        
        Args:
            attribute_name: Attribute name
            rule: RuleConfig for this attribute
            unified_records: List of unified records
            
        Returns:
            Tuple of (value, source)
        """
        # Get the appropriate strategy
        strategy = self.strategies.get(rule.strategy)
        
        if not strategy:
            # Unknown strategy - fall back to comprehensive fallback
            return self._get_comprehensive_fallback(
                attribute_name=attribute_name,
                unified_records=unified_records,
                ignore_null=rule.ignoreNull
            )
        
        # Create context with all necessary information
        context = StrategyContext(
            attribute_name=attribute_name,
            unified_records=unified_records,
            entity_attributes_datatype=self.config.entity_attributes_datatype,
            rule_config=rule,
            primary_source=self.primary_source,
            all_priority_sources=self.all_priority_sources
        )
        
        # Apply the strategy
        try:
            value, source = strategy.apply(context)
            
            # If strategy returns None/None, try comprehensive fallback
            if value is None and source is None:
                return self._get_comprehensive_fallback(
                    attribute_name=attribute_name,
                    unified_records=unified_records,
                    ignore_null=rule.ignoreNull
                )
            
            return value, source
            
        except Exception as e:
            # If strategy fails, use comprehensive fallback
            return self._get_comprehensive_fallback(
                attribute_name=attribute_name,
                unified_records=unified_records,
                ignore_null=rule.ignoreNull
            )
    
    @classmethod
    def register_strategy(cls, strategy_name: str, strategy_class: type):
        """
        Register a custom strategy.
        
        This allows extending the engine with new strategies without modifying core code.
        
        Args:
            strategy_name: Name of the strategy (e.g., "Custom Strategy")
            strategy_class: Strategy class that extends BaseStrategy
            
        Raises:
            ValueError: If strategy_class doesn't extend BaseStrategy
        """
        if not issubclass(strategy_class, BaseStrategy):
            raise ValueError(f"Strategy class must extend BaseStrategy")
        
        cls.STRATEGY_REGISTRY[strategy_name] = strategy_class