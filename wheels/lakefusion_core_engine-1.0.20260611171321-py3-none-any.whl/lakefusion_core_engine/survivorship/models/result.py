"""
Result models for survivorship engine output.
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class AttributeSourceMapping:
    """
    Mapping of an attribute to its source after survivorship.
    
    Attributes:
        attribute_name: Name of the attribute
        attribute_value: String representation of the attribute value
        source: Source dataset path that won for this attribute
                (comma-separated for aggregated values)
    """
    attribute_name: str
    attribute_value: str
    source: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format."""
        return {
            'attribute_name': self.attribute_name,
            'attribute_value': self.attribute_value,
            'source': self.source
        }


@dataclass
class SurvivorshipResult:
    """
    Result of survivorship processing.
    
    Attributes:
        resultant_record: Dictionary containing the final merged record with survived values
        resultant_master_attribute_source_mapping: List of AttributeSourceMapping objects
                                                    tracking which source won for each attribute
    """
    resultant_record: Dict[str, Any]
    resultant_master_attribute_source_mapping: List[AttributeSourceMapping]
    
    def to_dict(self) -> dict:
        """
        Convert to dictionary format suitable for Spark UDF return.
        
        Returns:
            Dictionary with resultant_record and attribute source mappings
        """
        return {
            'resultant_record': self.resultant_record,
            'resultant_master_attribute_source_mapping': [
                mapping.to_dict() for mapping in self.resultant_master_attribute_source_mapping
            ]
        }


@dataclass
class StrategyContext:
    """
    Context object passed to strategies containing all necessary data.
    
    Attributes:
        attribute_name: The attribute being processed
        unified_records: List of unified record dictionaries, each containing:
                        - surrogate_key: Unique record identifier
                        - source_path: Source table path
                        - [business attributes]: All entity attributes
        entity_attributes_datatype: Dict mapping attribute names to data types
        rule_config: The rule configuration for this attribute
        primary_source: Primary source table path for fallback (optional)
        all_priority_sources: List of all source paths from Source System rules (for comprehensive fallback)
    """
    attribute_name: str
    unified_records: List[Dict[str, Any]]
    entity_attributes_datatype: Dict[str, str]
    rule_config: Any  # RuleConfig, using Any to avoid circular import
    primary_source: Optional[str] = None
    all_priority_sources: Optional[List[str]] = None
    
    def get_datatype(self) -> str:
        """
        Get the datatype for the current attribute.
        
        Returns:
            Datatype string, defaults to 'string' if not found
        """
        return self.entity_attributes_datatype.get(self.attribute_name, 'string')
    
    def get_available_sources(self) -> List[str]:
        """
        Get list of all available source paths from unified records.
        
        Returns:
            List of unique source paths present in unified records
        """
        sources = []
        for record in self.unified_records:
            source = record.get("source_path")
            if source and source not in sources:
                sources.append(source)
        return sources