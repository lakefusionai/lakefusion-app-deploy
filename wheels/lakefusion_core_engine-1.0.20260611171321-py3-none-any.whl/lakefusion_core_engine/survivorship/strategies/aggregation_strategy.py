"""
Aggregation Strategy Implementation.
Combines values from multiple sources based on configured aggregation function.
"""

from typing import Tuple, Any, List, Optional
from datetime import datetime

from .base import BaseStrategy
from ..models.result import StrategyContext
from ..utils.helpers import (
    is_null_or_empty, 
    is_numeric_type, 
    is_timestamp_type,
    is_integer_type,
    is_boolean_type,
)


class AggregationStrategy(BaseStrategy):
    """
    Aggregation strategy: Combine values from multiple sources using a configured function.
    
    Configuration:
        strategyRule: Object with aggregation function configuration
            - { "function": "sum" }     - Sum all numeric values
            - { "function": "avg" }     - Average of numeric values (default for numeric)
            - { "function": "min" }     - Minimum numeric value
            - { "function": "max" }     - Maximum numeric value
            - { "function": "count" }   - Count of non-null values
            - { "function": "concat" }  - Concatenate strings with separator (default for string)
            - { "function": "longest" } - Longest string value
            - { "function": "shortest" }- Shortest string value
            - { "function": "earliest" }- Earliest date/timestamp
            - { "function": "latest" }  - Latest date/timestamp
            - { "function": "any_true" }- Boolean OR (any value is true)
            - { "function": "all_true" }- Boolean AND (all values are true)
        ignoreNull: If True, skip null/empty values in aggregation (default: False)
        aggregateUniqueOnly: If True, only aggregate unique values (default: False)
    
    Example:
        {
            "attribute": "total_amount",
            "strategy": "Aggregation",
            "strategyRule": { "function": "sum" },
            "ignoreNull": True,
            "aggregateUniqueOnly": False
        }
    
    Legacy Support:
        If strategyRule is None or not in the new format, falls back to type-based defaults:
        - Numeric: avg
        - String: concat
        - Timestamp: latest
        - Boolean: any_true
    """
    
    # Default separator for string concatenation
    DEFAULT_SEPARATOR = " • "
    
    # Functions where NULL can be meaningfully included when ignoreNull=False
    NULL_INCLUDABLE_FUNCTIONS = {'concat', 'count'}
    
    def apply(self, context: StrategyContext) -> Tuple[Any, Optional[str]]:
        """
        Apply aggregation strategy to combine values.
        
        Args:
            context: StrategyContext with unified records
            
        Returns:
            Tuple of (aggregated_value, comma_separated_sources) or (None, None) if no values
        """
        # Get settings from this specific attribute's rule config
        ignore_null = context.rule_config.ignoreNull
        unique_only = context.rule_config.aggregateUniqueOnly
        attribute_name = context.attribute_name
        datatype = context.get_datatype()
        
        # Get the aggregation function from strategyRule
        agg_function = self._get_aggregation_function(context.rule_config.strategyRule, datatype)
        
        # Determine if this function can include NULL values
        can_include_nulls = agg_function in self.NULL_INCLUDABLE_FUNCTIONS
        
        # Collect values and sources
        values = []
        sources = []
        null_count = 0  # Track nulls separately for count function
        null_sources = []  # Track sources of null values
        
        for record in context.unified_records:
            value = record.get(attribute_name)
            source = record.get("source_path")
            
            # Handle NULL values
            if value is None or is_null_or_empty(value):
                if ignore_null:
                    # ignoreNull=True: Skip null values
                    continue
                else:
                    # ignoreNull=False: Include null for applicable functions
                    if can_include_nulls:
                        if agg_function == 'count':
                            # For count, track nulls separately
                            null_count += 1
                            if source:
                                null_sources.append(source)
                        elif agg_function == 'concat':
                            # For concat, add "None" string representation
                            if unique_only:
                                if "None" not in [str(v) for v in values]:
                                    values.append(None)  # Will be converted to "None" in concat
                                    sources.append(source)
                            else:
                                values.append(None)
                                sources.append(source)
                    # For other functions (sum, avg, etc.), skip NULL regardless
                    continue
            
            # Handle unique only flag
            if unique_only:
                value_exists = any(self._values_equal(value, existing_val) for existing_val in values)
                if not value_exists:
                    values.append(value)
                    sources.append(source)
            else:
                values.append(value)
                sources.append(source)
        
        # Special handling for count with ignoreNull=False
        if agg_function == 'count' and not ignore_null:
            total_count = len(values) + null_count
            all_sources = sources + null_sources
            if total_count == 0:
                return self._get_fallback_value(
                    attribute_name=attribute_name,
                    unified_records=context.unified_records,
                    priority_sources=context.all_priority_sources,
                    ignore_null=ignore_null
                )
            return total_count, ",".join(s for s in all_sources if s)
        
        if not values:
            # No values to aggregate - use fallback
            return self._get_fallback_value(
                attribute_name=attribute_name,
                unified_records=context.unified_records,
                priority_sources=context.all_priority_sources,
                ignore_null=ignore_null
            )
        
        # Apply the aggregation function
        aggregated_value = self._apply_aggregation_function(values, agg_function, datatype)
        aggregated_source = ",".join(s for s in sources if s)
        
        return aggregated_value, aggregated_source
    
    def _get_aggregation_function(self, strategy_rule: Any, datatype: str) -> str:
        """
        Extract aggregation function from strategyRule or determine default based on type.
        
        Args:
            strategy_rule: The strategyRule from config (new format: {"function": "..."})
            datatype: The attribute's data type
            
        Returns:
            Aggregation function name (e.g., "sum", "avg", "concat")
        """
        # New format: { "function": "sum" }
        if isinstance(strategy_rule, dict) and "function" in strategy_rule:
            return strategy_rule["function"]
        
        # Legacy format or missing - determine default based on type
        if is_numeric_type(datatype):
            return "avg"
        elif is_timestamp_type(datatype):
            return "latest"
        elif is_boolean_type(datatype):
            return "any_true"
        else:
            return "concat"
    
    def _apply_aggregation_function(self, values: List[Any], function: str, datatype: str) -> Any:
        """
        Apply the specified aggregation function to values.
        
        Args:
            values: List of values to aggregate
            function: Aggregation function name
            datatype: The attribute's data type
            
        Returns:
            Aggregated value
        """
        function_map = {
            # Numeric functions
            "sum": self._aggregate_sum,
            "avg": self._aggregate_avg,
            "min": self._aggregate_min,
            "max": self._aggregate_max,
            "count": self._aggregate_count,
            # String functions
            "concat": self._aggregate_concat,
            "longest": self._aggregate_longest,
            "shortest": self._aggregate_shortest,
            # Date/Timestamp functions
            "earliest": self._aggregate_earliest,
            "latest": self._aggregate_latest,
            # Boolean functions
            "any_true": self._aggregate_any_true,
            "all_true": self._aggregate_all_true,
        }
        
        handler = function_map.get(function)
        if handler:
            return handler(values, datatype)
        
        # Unknown function - fall back to concat
        return self._aggregate_concat(values, datatype)
    
    def _values_equal(self, val1: Any, val2: Any) -> bool:
        """
        Compare two values for equality, handling type differences.
        """
        if val1 == val2:
            return True
        # Handle None comparison
        if val1 is None or val2 is None:
            return val1 is None and val2 is None
        try:
            return str(val1).strip().lower() == str(val2).strip().lower()
        except:
            return False
    
    def _to_numeric(self, values: List[Any]) -> List[float]:
        """Convert values to numeric, skipping non-convertible values."""
        numeric_values = []
        for v in values:
            if v is None:
                continue
            try:
                numeric_values.append(float(v))
            except (ValueError, TypeError):
                continue
        return numeric_values
    
    # ========== Numeric Aggregation Functions ==========
    
    def _aggregate_sum(self, values: List[Any], datatype: str) -> Any:
        """Sum all numeric values."""
        numeric_values = self._to_numeric(values)
        if not numeric_values:
            return self._aggregate_concat(values, datatype)
        
        result = sum(numeric_values)
        return int(round(result)) if is_integer_type(datatype) else result
    
    def _aggregate_avg(self, values: List[Any], datatype: str) -> Any:
        """Calculate average of numeric values."""
        numeric_values = self._to_numeric(values)
        if not numeric_values:
            return self._aggregate_concat(values, datatype)
        
        result = sum(numeric_values) / len(numeric_values)
        return int(round(result)) if is_integer_type(datatype) else result
    
    def _aggregate_min(self, values: List[Any], datatype: str) -> Any:
        """Find minimum numeric value."""
        numeric_values = self._to_numeric(values)
        if not numeric_values:
            return self._aggregate_concat(values, datatype)
        
        result = min(numeric_values)
        return int(round(result)) if is_integer_type(datatype) else result
    
    def _aggregate_max(self, values: List[Any], datatype: str) -> Any:
        """Find maximum numeric value."""
        numeric_values = self._to_numeric(values)
        if not numeric_values:
            return self._aggregate_concat(values, datatype)
        
        result = max(numeric_values)
        return int(round(result)) if is_integer_type(datatype) else result
    
    def _aggregate_count(self, values: List[Any], datatype: str) -> int:
        """Count values (nulls already handled in apply method)."""
        return len(values)
    
    # ========== String Aggregation Functions ==========
    
    def _aggregate_concat(self, values: List[Any], datatype: str) -> str:
        """Concatenate all values with separator. None values become 'None' string."""
        string_values = []
        for v in values:
            if v is None:
                string_values.append("None")
            else:
                string_values.append(str(v))
        return self.DEFAULT_SEPARATOR.join(string_values)
    
    def _aggregate_longest(self, values: List[Any], datatype: str) -> Any:
        """Select the longest string value."""
        if not values:
            return None
        
        # Filter out None values for length comparison
        string_values = [(v, len(str(v))) for v in values if v is not None]
        if not string_values:
            return None
        
        return max(string_values, key=lambda x: x[1])[0]
    
    def _aggregate_shortest(self, values: List[Any], datatype: str) -> Any:
        """Select the shortest string value."""
        if not values:
            return None
        
        # Filter out None values for length comparison
        string_values = [(v, len(str(v))) for v in values if v is not None]
        if not string_values:
            return None
        
        return min(string_values, key=lambda x: x[1])[0]
    
    # ========== Date/Timestamp Aggregation Functions ==========
    
    def _parse_date(self, value: Any) -> Optional[datetime]:
        """Try to parse a value as datetime."""
        if value is None:
            return None
            
        if isinstance(value, datetime):
            return value
        
        from datetime import date
        if isinstance(value, date):
            return datetime.combine(value, datetime.min.time())
        
        if isinstance(value, str):
            formats = [
                "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%d %H:%M:%S.%f",
                "%Y-%m-%d",
                "%Y-%m-%dT%H:%M:%S",
                "%Y-%m-%dT%H:%M:%S.%f",
                "%Y-%m-%dT%H:%M:%SZ",
                "%Y-%m-%dT%H:%M:%S.%fZ",
            ]
            for fmt in formats:
                try:
                    return datetime.strptime(value, fmt)
                except ValueError:
                    continue
            
            # Try ISO format
            try:
                return datetime.fromisoformat(value.replace('Z', '+00:00'))
            except ValueError:
                pass
        
        return None
    
    def _aggregate_earliest(self, values: List[Any], datatype: str) -> Any:
        """Select the earliest date/timestamp."""
        parsed_dates = []
        for v in values:
            if v is None:
                continue
            parsed = self._parse_date(v)
            if parsed:
                parsed_dates.append((parsed, v))
        
        if not parsed_dates:
            return self._aggregate_concat(values, datatype)
        
        return min(parsed_dates, key=lambda x: x[0])[1]
    
    def _aggregate_latest(self, values: List[Any], datatype: str) -> Any:
        """Select the latest date/timestamp."""
        parsed_dates = []
        for v in values:
            if v is None:
                continue
            parsed = self._parse_date(v)
            if parsed:
                parsed_dates.append((parsed, v))
        
        if not parsed_dates:
            return self._aggregate_concat(values, datatype)
        
        return max(parsed_dates, key=lambda x: x[0])[1]
    
    # ========== Boolean Aggregation Functions ==========
    
    def _to_boolean(self, value: Any) -> Optional[bool]:
        """Convert a value to boolean."""
        if value is None:
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return bool(value)
        if isinstance(value, str):
            lower_val = value.lower().strip()
            if lower_val in ('true', '1', 'yes', 'y', 't'):
                return True
            if lower_val in ('false', '0', 'no', 'n', 'f'):
                return False
        return None
    
    def _aggregate_any_true(self, values: List[Any], datatype: str) -> bool:
        """Return True if any value is True (OR logic)."""
        for v in values:
            if v is None:
                continue
            bool_val = self._to_boolean(v)
            if bool_val is True:
                return True
        return False
    
    def _aggregate_all_true(self, values: List[Any], datatype: str) -> bool:
        """Return True if all values are True (AND logic)."""
        bool_values = []
        for v in values:
            if v is None:
                continue
            bool_val = self._to_boolean(v)
            if bool_val is not None:
                bool_values.append(bool_val)
        
        if not bool_values:
            return False
        
        return all(bool_values)