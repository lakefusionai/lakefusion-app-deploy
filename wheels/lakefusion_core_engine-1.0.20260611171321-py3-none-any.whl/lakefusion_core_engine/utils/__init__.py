"""
Utilities module for lakefusion_core_engine.

Provides common utility functions for model serving, logging, parsing, and constants.
"""

from .constants import Constants, LF_CREATED_AT_COL, LF_MODIFIED_AT_COL
from .model_serving import (
    MODEL_PATH_MAPPINGS,
    wait_until_serving_endpoint_ready,
    wait_until_vector_search_ready,
    sync_index_with_retry,
    warm_up_llm_endpoint,
    get_serving_endpoint_status,
    wait_for_serving_endpoint,
    create_serving_endpoint,
    create_serving_endpoint_foundational,
    create_and_sync_vector_index,
)
from .validation_functions_constant import (
    EMAIL_REGEX,
    validate_email,
    check_dob_suspicious,
    is_string_null_or_empty,
    is_contains_numbers,
)
from .parse_utils import (
    get_primary_dataset_path,
    get_dataset_tables,
    parse_attributes_mapping,
    parse_attributes_mapping_json,
    get_default_survivorship_rules,
    get_primary_attr_mapping,
    remove_primary_from_attr_mapping,
    get_spark_data_type,
    create_schema_fields,
    validation_function_exec,
    get_version_info,
    get_custom_tags,
    get_resource_tags,
    get_user_agent_header_sql,
    append_schema_tags,
    append_table_tags,
    apply_tags_to_uc_resource,
)
from .taskvalues_enum import TaskValueKey
from .survivorship_cast import cast_merged_value, merged_record_column

__all__ = [
    # Constants
    'Constants',
    'LF_CREATED_AT_COL',
    'LF_MODIFIED_AT_COL',
    # Model Serving
    'MODEL_PATH_MAPPINGS',
    'wait_until_serving_endpoint_ready',
    'wait_until_vector_search_ready',
    'sync_index_with_retry',
    'warm_up_llm_endpoint',
    'get_serving_endpoint_status',
    'wait_for_serving_endpoint',
    'create_serving_endpoint',
    'create_serving_endpoint_foundational',
    'create_and_sync_vector_index',
    # Parse Utilities
    'get_primary_dataset_path',
    'get_dataset_tables',
    'parse_attributes_mapping',
    'parse_attributes_mapping_json',
    'get_default_survivorship_rules',
    'get_primary_attr_mapping',
    'remove_primary_from_attr_mapping',
    'get_spark_data_type',
    'create_schema_fields',
    'validation_function_exec',
    'get_version_info',
    'get_custom_tags',
    'get_resource_tags',
    'get_user_agent_header_sql',
    'append_schema_tags',
    'append_table_tags',
    'apply_tags_to_uc_resource',
    # Validation Functions
    'EMAIL_REGEX',
    'validate_email',
    'check_dob_suspicious',
    'is_string_null_or_empty',
    'is_contains_numbers',
    # Task Value Keys
    'TaskValueKey',
    # Survivorship cast helpers
    'cast_merged_value',
    'merged_record_column',
]
