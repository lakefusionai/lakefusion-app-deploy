"""
Model Serving Utilities.

Provides functions for working with Databricks Model Serving endpoints,
including scale-from-zero handling with retry logic.
"""

import time
from typing import Any, Callable, Dict, List, Optional

from .parse_utils import get_resource_tags


# Model path mappings for Databricks foundation models
MODEL_PATH_MAPPINGS = {
    # Llama family
    "databricks-meta-llama-3-1-70b-instruct": "system.ai.meta_llama_v3_1_70b_instruct",
    "databricks-meta-llama-3-3-70b-instruct": "system.ai.llama_v3_3_70b_instruct",
    "databricks-meta-llama-3-1-405b-instruct": "system.ai.meta_llama_v3_1_405b_instruct_fp8",
    "databricks-meta-llama-3-1-8b-instruct": "system.ai.meta_llama_v3_1_8b_instruct",
    "databricks-llama-4-maverick": "system.ai.llama-4-maverick",

    # Claude family
    "databricks-claude-3-7-sonnet": "system.ai.claude_v3_7_sonnet",
    "databricks-claude-sonnet-4": "system.ai.claude_v4_sonnet",
    "databricks-claude-opus-4": "system.ai.claude_v4_opus",

    # GPT OSS family
    "databricks-gpt-oss-120b": "system.ai.gpt-oss-120b",
    "databricks-gpt-oss-20b": "system.ai.gpt-oss-20b",

    # Gemma family
    "databricks-gemma-3-12b": "system.ai.gemma-3-12b-it",

    # Embeddings
    "databricks-gte-large-en": "system.ai.gte_large_en_v1_5",
    "databricks-bge-large-en": "system.ai.bge_large_en_v1_5",

    # Others
    "databricks-dbrx-instruct": "system.ai.dbrx_instruct",
    "databricks-mixtral-8x7b-instruct": "system.ai.mixtral_8x7b_instruct_v0_1",
}


# Transient error keywords for scale-from-zero scenarios
TRANSIENT_ERROR_KEYWORDS = [
    "503", "service unavailable", "timeout", "temporarily unavailable",
    "scaling", "scale to zero", "endpoint is not ready", "connection",
    "rate limit", "throttl", "capacity", "overloaded", "starting"
]


def _is_transient_error(error_message: str) -> bool:
    """
    Check if an error message indicates a transient (retryable) error.

    Args:
        error_message: The error message to check

    Returns:
        True if the error is transient and should be retried
    """
    error_lower = error_message.lower()
    return any(keyword in error_lower for keyword in TRANSIENT_ERROR_KEYWORDS)


def _retry_with_backoff(
    execute_fn: Callable[[], Any],
    endpoint_name: str,
    endpoint_type: str = "endpoint",
    max_retries: int = 10,
    retry_interval_seconds: int = 60,
    timeout_minutes: int = 10
) -> Any:
    """
    Internal retry logic with backoff for scale-from-zero scenarios.

    Args:
        execute_fn: Function to execute (will be retried on transient errors)
        endpoint_name: Name of the endpoint (for logging)
        endpoint_type: Type of endpoint (for logging)
        max_retries: Maximum number of retry attempts
        retry_interval_seconds: Seconds to wait between retries
        timeout_minutes: Total timeout in minutes

    Returns:
        Result of execute_fn if successful

    Raises:
        Exception: If max retries exceeded or non-transient error occurs
    """
    print(f"Executing with retry for {endpoint_type} '{endpoint_name}' (scale-from-zero handling)")
    print(f"   Max retries: {max_retries}, Retry interval: {retry_interval_seconds}s, Timeout: {timeout_minutes} min")

    start_time = time.time()
    timeout_seconds = timeout_minutes * 60

    for attempt in range(1, max_retries + 1):
        # Check timeout
        elapsed = time.time() - start_time
        if elapsed > timeout_seconds:
            raise TimeoutError(
                f"{endpoint_type} '{endpoint_name}' did not respond within {timeout_minutes} minutes"
            )

        try:
            print(f"   Attempt {attempt}/{max_retries}: Executing...")
            result = execute_fn()
            print(f"Success! {endpoint_type} '{endpoint_name}' is ready.")
            return result

        except Exception as e:
            error_msg = str(e)

            if _is_transient_error(error_msg):
                print(f"   Transient error (attempt {attempt}/{max_retries}): {error_msg[:100]}...")

                if attempt < max_retries:
                    print(f"   Waiting {retry_interval_seconds}s before retry...")
                    time.sleep(retry_interval_seconds)
                else:
                    raise Exception(
                        f"{endpoint_type} '{endpoint_name}' did not respond after {max_retries} attempts. "
                        f"Last error: {error_msg}"
                    )
            else:
                # Non-transient error - fail immediately
                print(f"   Non-transient error: {error_msg}")
                raise


def wait_until_serving_endpoint_ready(
    endpoint_name: str,
    timeout_minutes: int = 20,
    check_interval_seconds: int = 10
) -> str:
    """
    Wait until a Databricks Model Serving endpoint is ready.

    Args:
        endpoint_name: Name of the serving endpoint
        timeout_minutes: Maximum time to wait in minutes
        check_interval_seconds: Time between status checks

    Returns:
        The endpoint state when ready

    Raises:
        TimeoutError: If endpoint doesn't become ready within timeout
    """
    from mlflow.deployments import get_deploy_client

    client = get_deploy_client("databricks")
    start_time = time.time()
    timeout_seconds = timeout_minutes * 60
    ready_state = "unknown"
    config_update = "unknown"

    print(f"Waiting for endpoint '{endpoint_name}' to become READY (timeout={timeout_minutes} min)...")

    while time.time() - start_time < timeout_seconds:
        try:
            endpoint = client.get_endpoint(endpoint=endpoint_name)
            state = endpoint.get("state", {})
            ready_state = state.get("ready", "")
            config_update = state.get("config_update", "")
            print(f"Endpoint '{endpoint_name}' state: ready={ready_state}, config_update={config_update}")

            if ready_state.upper() == "READY":
                print(f"Endpoint '{endpoint_name}' is READY!")
                return state

            if config_update.upper() in ("UPDATE_FAILED", "UPDATE_CANCELED"):
                # Extract failure reason from pending_config.served_entities
                failure_reasons = []
                pending_config = endpoint.get("pending_config", {})
                for entity in pending_config.get("served_entities", []):
                    entity_state = entity.get("state", {})
                    msg = entity_state.get("deployment_state_message", "")
                    deployment = entity_state.get("deployment", "")
                    if msg:
                        failure_reasons.append(msg)
                    elif deployment:
                        failure_reasons.append(f"deployment={deployment}")

                reason = "; ".join(failure_reasons) if failure_reasons else "unknown"
                raise RuntimeError(
                    f"Endpoint '{endpoint_name}' failed to deploy. "
                    f"Reason: {reason} "
                    f"(ready={ready_state}, config_update={config_update})"
                )

            print(f"Still waiting... next check in {check_interval_seconds} seconds.")
            time.sleep(check_interval_seconds)

        except RuntimeError:
            raise
        except Exception as e:
            print(f"Error checking endpoint status: {e}")
            print(f"Retrying in {check_interval_seconds} seconds...")
            time.sleep(check_interval_seconds)

    raise TimeoutError(
        f"Endpoint '{endpoint_name}' did not become READY within {timeout_minutes} minutes. "
        f"Last state: ready={ready_state}, config_update={config_update}"
    )


def wait_until_vector_search_ready(
    endpoint_name: str,
    client: Any = None,
    timeout_minutes: int = 20,
    interval_seconds: int = 10
) -> bool:
    """
    Wait until a Vector Search endpoint is online and ready.

    Args:
        endpoint_name: Name of the Vector Search endpoint
        client: Optional VectorSearchClient instance (creates one if not provided)
        timeout_minutes: Maximum time to wait in minutes
        interval_seconds: Time between status checks

    Returns:
        True when endpoint is ready

    Raises:
        TimeoutError: If endpoint doesn't become ready within timeout
        Exception: If endpoint does not exist
    """
    if client is None:
        from databricks.vector_search.client import VectorSearchClient
        client = VectorSearchClient()
    start_time = time.time()
    timeout = timeout_minutes * 60
    state = "unknown"
    message = ""

    while time.time() - start_time < timeout:
        try:
            ep = client.get_endpoint(endpoint_name)
            status = ep.get("endpoint_status", {})
            state = status.get("state", "unknown")
            message = status.get("message", "")
            print(f"VS endpoint '{endpoint_name}' state: {state}, message: {message}")

            if state == "ONLINE":
                print(f"Vector Search endpoint '{endpoint_name}' is ONLINE and ready.")
                return True

            if state == "OFFLINE":
                raise RuntimeError(
                    f"Vector Search endpoint '{endpoint_name}' is OFFLINE: {message}"
                )

        except RuntimeError:
            raise
        except Exception as e:
            if "does not exist" in str(e).lower():
                print(f"Endpoint '{endpoint_name}' does not exist. Please recreate it manually in Databricks.")
                raise
            else:
                print(f"Error checking VS endpoint status: {e}")

        time.sleep(interval_seconds)

    raise TimeoutError(
        f"Vector Search endpoint '{endpoint_name}' did not become READY within {timeout_minutes} minutes. "
        f"Last state: {state}, message: {message}"
    )


def similarity_search_with_retry(
    index: Any,
    query_text: str,
    columns: List[str],
    num_results: int,
    max_retries: int = 5,
    initial_delay: float = 1.0,
    max_delay: float = 30.0,
    backoff_factor: float = 2.0,
    jitter_factor: float = 0.5
) -> Dict[str, Any]:
    """
    Wrapper around index.similarity_search() with exponential backoff and jitter.

    Retries on transient errors (429 rate limits, 5xx server errors, timeouts,
    connection errors). Non-retriable errors are raised immediately.

    Args:
        index: VectorSearchIndex object
        query_text: Text to search for
        columns: Columns to return from the index
        num_results: Number of results to return
        max_retries: Maximum number of retry attempts (default 5)
        initial_delay: Initial delay in seconds before first retry (default 1.0)
        max_delay: Maximum delay cap in seconds (default 30.0)
        backoff_factor: Multiplier for exponential backoff (default 2.0)
        jitter_factor: Random jitter as fraction of delay, 0-1 (default 0.5)

    Returns:
        Search results from similarity_search

    Raises:
        Exception: If all retries exhausted or non-retriable error occurs
    """
    import random

    for attempt in range(max_retries + 1):
        try:
            return index.similarity_search(
                query_text=query_text, columns=columns, num_results=num_results
            )
        except Exception as e:
            error_str = str(e).lower()
            is_retriable = any(term in error_str for term in
                ['429', 'rate limit', '500', '502', '503', '504',
                 'timeout', 'unavailable', 'connection', 'temporary'])
            if not is_retriable or attempt == max_retries:
                raise
            delay = min(initial_delay * (backoff_factor ** attempt), max_delay)
            sleep_time = delay + delay * random.uniform(0, jitter_factor)
            print(f"[VS Retry] Attempt {attempt+1}/{max_retries+1} failed. "
                  f"Retrying in {sleep_time:.1f}s...")
            time.sleep(sleep_time)


def create_vs_client(
    dbutils: Any = None,
    spn_client_id: str = None,
    spn_client_secret: str = None,
    **kwargs
) -> Any:
    """
    Create VectorSearchClient with Service Principal OAuth if credentials are available.

    SP OAuth enables the network-optimized route for Vector Search, which provides
    isolated rate limits and avoids impacting other workspace users.

    Args:
        dbutils: Databricks dbutils (used to get secrets if spn_client_id/secret not provided)
        spn_client_id: Service Principal client ID (optional, will try to get from secrets)
        spn_client_secret: Service Principal client secret (optional, will try to get from secrets)
        **kwargs: Additional arguments passed to VectorSearchClient

    Returns:
        VectorSearchClient instance
    """
    from databricks.vector_search.client import VectorSearchClient

    # Try to get SPN credentials from secrets if not provided
    if dbutils and not spn_client_id:
        try:
            spn_client_id = dbutils.secrets.get(scope="lakefusion", key="lakefusion_spn")
            spn_client_secret = dbutils.secrets.get(scope="lakefusion", key="lakefusion_spn_secret")
            if spn_client_id and spn_client_secret:
                print("✓ Service Principal credentials loaded — using network-optimized route")
            else:
                spn_client_id = None
                spn_client_secret = None
                print("⚠️ Service Principal credentials empty — using default authentication")
        except Exception:
            print("⚠️ Service Principal credentials not configured — using default authentication")
            spn_client_id = None
            spn_client_secret = None

    if spn_client_id and spn_client_secret:
        # Get workspace URL from dbutils
        workspace_url = None
        if dbutils:
            try:
                workspace_url = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().getOrElse(None)
            except Exception:
                pass

        if workspace_url:
            print(f"[VS Client] Using SPN OAuth (network-optimized route) | workspace: {workspace_url}")
            client = VectorSearchClient(
                workspace_url=workspace_url,
                service_principal_client_id=spn_client_id,
                service_principal_client_secret=spn_client_secret,
                **kwargs
            )
            print(f"[VS Client] _is_notebook_pat: {client._is_notebook_pat} | _using_user_passed_credentials: {client._using_user_passed_credentials}")
            return client

    print("[VS Client] Using default PAT authentication (standard route)")
    return VectorSearchClient(**kwargs)


def sync_index_with_retry(
    index: Any,
    embedding_endpoint_name: str,
    max_retries: int = 10,
    retry_interval_seconds: int = 60,
    timeout_minutes: int = 10
) -> None:
    """
    Sync a Vector Search index with retry logic for scale-from-zero.

    The index.sync() call triggers the embedding endpoint to generate embeddings.
    If the endpoint is scaled to zero, this operation may fail with transient errors.
    This function wraps index.sync() with retry logic to handle these scenarios.

    Args:
        index: Vector Search index object (from VectorSearchClient.get_index())
        embedding_endpoint_name: Name of the embedding model endpoint
        max_retries: Maximum number of retry attempts
        retry_interval_seconds: Seconds to wait between retries
        timeout_minutes: Total timeout in minutes

    Raises:
        Exception: If sync fails after all retries or due to non-transient error
    """
    def execute_sync():
        index.sync()
        return True

    _retry_with_backoff(
        execute_fn=execute_sync,
        endpoint_name=embedding_endpoint_name,
        endpoint_type="embedding endpoint (via index.sync)",
        max_retries=max_retries,
        retry_interval_seconds=retry_interval_seconds,
        timeout_minutes=timeout_minutes
    )


def warm_up_llm_endpoint(
    spark: Any,
    endpoint_name: str,
    warmup_query: str,
    max_retries: int = 10,
    retry_interval_seconds: int = 60,
    timeout_minutes: int = 10
) -> None:
    """
    Warm up an LLM endpoint by executing a SQL query with ai_query().

    Uses collect() since warmup query should use LIMIT 1 for minimal data transfer.

    Args:
        spark: SparkSession
        endpoint_name: Name of the LLM endpoint
        warmup_query: SQL query that includes ai_query() call (should use LIMIT 1)
        max_retries: Maximum number of retry attempts
        retry_interval_seconds: Seconds to wait between retries
        timeout_minutes: Total timeout in minutes

    Raises:
        Exception: If warm-up fails after all retries or due to non-transient error
    """
    def execute_warmup():
        # Execute the warm-up query and collect result
        # Using collect() since LIMIT 1 ensures minimal data transfer
        # Note: foreach() doesn't work with Spark Connect
        df = spark.sql(warmup_query)
        df.collect()
        return True

    _retry_with_backoff(
        execute_fn=execute_warmup,
        endpoint_name=endpoint_name,
        endpoint_type="LLM endpoint",
        max_retries=max_retries,
        retry_interval_seconds=retry_interval_seconds,
        timeout_minutes=timeout_minutes
    )


def get_serving_endpoint_status(endpoint_name: str) -> bool:
    """
    Check if a serving endpoint is ready.

    Args:
        endpoint_name: Name of the serving endpoint

    Returns:
        True if endpoint is ready

    Raises:
        ValueError: If endpoint is not ready
    """
    from mlflow.deployments import get_deploy_client

    client = get_deploy_client("databricks")
    endpoint = client.get_endpoint(endpoint=endpoint_name)
    print(endpoint)

    if not endpoint.get("state", {}).get("ready") == "READY":
        raise ValueError("Endpoint is not ready.")

    return True


def wait_for_serving_endpoint(
    client: Any,
    endpoint_name: str,
    timeout: int = 600,
    interval: int = 10
) -> bool:
    """
    Wait until a Databricks serving endpoint is in 'READY' state.

    Args:
        client: MLflow deploy client
        endpoint_name: Name of the endpoint
        timeout: Maximum time to wait in seconds
        interval: Time between status checks in seconds

    Returns:
        True if endpoint becomes ready, False if timeout
    """
    print(f"Waiting for serving endpoint '{endpoint_name}' to become READY...")

    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            endpoint = client.get_endpoint(endpoint_name)
            status = endpoint.state.ready  # Returns True if READY, otherwise False

            if status == 'READY':
                print(f"Serving endpoint '{endpoint_name}' is READY!")
                return True
            else:
                print(f"Still waiting... Current state: {endpoint.state.config_update}")

        except Exception as err:
            print(f"Error checking endpoint status: {str(err)}")

        time.sleep(interval)

    print(f"Timeout: Serving endpoint '{endpoint_name}' did not become READY within {timeout} seconds.")
    return False


def is_endpoint_healthy(endpoint_name: str) -> bool:
    """
    Check if a serving endpoint exists and is not in a failed state.

    Returns:
        True if the endpoint exists and is not failed, False if it doesn't exist or is failed.
    """
    from mlflow.deployments import get_deploy_client

    try:
        client = get_deploy_client("databricks")
        endpoint = client.get_endpoint(endpoint_name)
    except Exception:
        return False

    state = endpoint.get("state", {})
    config_update = state.get("config_update", "")
    return config_update not in ("UPDATE_FAILED", "UPDATE_CANCELED")


def check_and_cleanup_failed_endpoint(endpoint_name: str) -> bool:
    """
    Check if a serving endpoint exists and determine if it needs creation.

    - If the endpoint doesn't exist → return True (needs creation).
    - If the endpoint exists and is READY → return False (skip creation).
    - If the endpoint exists and is IN_PROGRESS → wait for it to become ready,
      then return False.
    - If the endpoint exists but is FAILED → delete it and return True (needs creation).

    Returns:
        True if the endpoint was deleted (or didn't exist) — needs creation.
        False if it exists and is ready — skip creation.
    """
    from mlflow.deployments import get_deploy_client

    try:
        client = get_deploy_client("databricks")
        endpoint = client.get_endpoint(endpoint_name)
    except Exception:
        # Endpoint doesn't exist at all
        return True

    state = endpoint.get("state", {})
    ready_state = state.get("ready", "")
    config_update = state.get("config_update", "")

    # Endpoint is fully ready
    if ready_state.upper() == "READY":
        print(f"Endpoint '{endpoint_name}' is healthy and READY — skipping recreation")
        return False

    # Endpoint is still deploying — wait for it to finish
    if config_update.upper() in ("IN_PROGRESS", "NOT_UPDATING") and ready_state.upper() != "READY":
        print(f"Endpoint '{endpoint_name}' exists but is still deploying (ready={ready_state}, config_update={config_update}) — waiting...")
        wait_until_serving_endpoint_ready(endpoint_name)
        print(f"Endpoint '{endpoint_name}' is now READY")
        return False

    # Endpoint is in a failed state — delete for retry
    if config_update.upper() in ("UPDATE_FAILED", "UPDATE_CANCELED"):
        print(f"Endpoint '{endpoint_name}' is in a failed state — deleting for retry")
        try:
            from databricks.sdk import WorkspaceClient
            w = WorkspaceClient()
            w.serving_endpoints.delete(endpoint_name)
            time.sleep(5)  # Brief wait for deletion to propagate
            print(f"Deleted failed endpoint '{endpoint_name}'")
            return True
        except Exception as e:
            print(f"Failed to delete endpoint '{endpoint_name}': {e}")
            return False

    # Unknown state — treat as needing check, wait for it
    print(f"Endpoint '{endpoint_name}' in unexpected state (ready={ready_state}, config_update={config_update}) — waiting...")
    wait_until_serving_endpoint_ready(endpoint_name)
    return False


def resolve_entity_name(model_name: str) -> str:
    """
    Resolve a model display name to its UC entity name using the Databricks SDK.

    If the model_name is already a UC path (e.g., system.ai.xxx), returns it as-is.
    Otherwise, looks up the serving endpoint to get the entity name from served_entities.

    Args:
        model_name: Model display/endpoint name (e.g., 'databricks-gte-large-en')
                    or UC entity name (e.g., 'system.ai.gte_large_en_v1_5')

    Returns:
        UC entity name (e.g., 'system.ai.gte_large_en_v1_5')
    """
    if not model_name:
        return model_name

    # Already a UC entity name
    if '.' in model_name:
        return model_name

    # Look up the serving endpoint to get the entity name
    from databricks.sdk import WorkspaceClient
    try:
        w = WorkspaceClient()
        endpoint = w.serving_endpoints.get(model_name)
        if endpoint and endpoint.config and endpoint.config.served_entities:
            served = endpoint.config.served_entities[0]
            # Try entity_name first (custom models), then foundation_model.name
            if served.entity_name:
                return served.entity_name
            elif served.foundation_model and served.foundation_model.name:
                entity_name = served.foundation_model.name
                print(f"Resolved '{model_name}' -> '{entity_name}'")
                return entity_name
    except Exception as e:
        print(f"Could not resolve entity name for '{model_name}': {e}")

    # Fallback: return as-is
    return model_name


def create_serving_endpoint(
    endpoint_name: str,
    entity_name: str,
    entity_version: int = 1,
    workload_size: str = "Small",
    workload_type: str = "CPU",
    scale_to_zero_enabled: bool = True
) -> Dict:
    """
    Create a Databricks serving endpoint.

    Args:
        endpoint_name: Name of the serving endpoint
        entity_name: Name of the entity being served
        entity_version: Version of the entity (default: 1)
        workload_size: Size of the workload (default: "Small")
        workload_type: Type of the workload (default: "CPU")
        scale_to_zero_enabled: Whether to enable scale to zero (default: True)

    Returns:
        dict: Details of the created endpoint
    """
    from mlflow.deployments import get_deploy_client

    resource_tags = get_resource_tags(as_list=True) or []

    client = get_deploy_client("databricks")
    endpoint = client.create_endpoint(
        name=endpoint_name,
        config={
            "served_entities": [
                {
                    "entity_name": entity_name,
                    "entity_version": entity_version,
                    "workload_size": workload_size,
                    "workload_type": workload_type,
                    "scale_to_zero_enabled": scale_to_zero_enabled
                }
            ],
            "tags": resource_tags
        }
    )
    wait_until_serving_endpoint_ready(endpoint_name)
    return endpoint


def create_serving_endpoint_foundational(
    endpoint_name: str,
    serving_entity: str,
    entity_version: int = 1,
    pt_config: dict = None,
) -> dict:
    """
    Create a Databricks serving endpoint for foundation models.

    Modes:
      - pt_type="model_units" -> SDK create_provisioned_throughput_endpoint + poll
      - pt_type="legacy"      -> SDK create + poll
      - None                  -> Raises RuntimeError (pt_config required)

    Args:
        endpoint_name: Name of the serving endpoint
        serving_entity: Name of the entity being served
        entity_version: Version of the entity (default: 1)
        pt_config: Provisioned throughput configuration dict (optional)

    Returns:
        dict with endpoint details

    Raises:
        RuntimeError: If endpoint creation fails
    """
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.serving import EndpointTag

    w = WorkspaceClient()

    # Convert resource_tags to EndpointTag objects
    resource_tags = get_resource_tags(as_list=True) or []
    tags = None
    if resource_tags:
        tags = [
            EndpointTag(key=t.get("key", ""), value=t.get("value", ""))
            for t in resource_tags
            if t.get("key") and t.get("value")
        ]
        if not tags:
            tags = None

    pt_type = pt_config.get("pt_type") if pt_config else None
    # Use entity_version from pt_config if available
    version = pt_config.get("entity_version", entity_version) if pt_config else entity_version

    if pt_type == "model_units":
        from databricks.sdk.service.serving import PtEndpointCoreConfig, PtServedModel

        chunk_size = pt_config["chunk_size"]
        units = pt_config.get("provisioned_model_units", chunk_size)
        print(f"Creating model_units PT endpoint '{endpoint_name}': {units} units for {serving_entity} v{version}")

        try:
            w.serving_endpoints.create_provisioned_throughput_endpoint(
                name=endpoint_name,
                config=PtEndpointCoreConfig(
                    served_entities=[
                        PtServedModel(
                            entity_name=serving_entity,
                            entity_version=version,
                            provisioned_model_units=units
                        )
                    ]
                ),
                tags=tags,
            )
            wait_until_serving_endpoint_ready(endpoint_name)
            print(f"Model units PT endpoint '{endpoint_name}' ready")
            return {"name": endpoint_name}
        except Exception as e:
            raise RuntimeError(
                f"Model units PT endpoint '{endpoint_name}' creation failed: {e}"
            ) from e

    elif pt_type == "legacy":
        from databricks.sdk.service.serving import EndpointCoreConfigInput, ServedEntityInput

        chunk_size = pt_config["chunk_size"]
        min_tp = pt_config.get("min_provisioned_throughput", 0)
        max_tp = pt_config.get("max_provisioned_throughput", chunk_size * 2)
        print(f"Creating legacy PT endpoint '{endpoint_name}': {min_tp}-{max_tp} tokens/sec for {serving_entity} v{version}")

        try:
            w.serving_endpoints.create(
                name=endpoint_name,
                config=EndpointCoreConfigInput(
                    name=endpoint_name,
                    served_entities=[
                        ServedEntityInput(
                            entity_name=serving_entity,
                            entity_version=version,
                            min_provisioned_throughput=min_tp,
                            max_provisioned_throughput=max_tp
                        )
                    ]
                ),
                tags=tags,
            )
            wait_until_serving_endpoint_ready(endpoint_name)
            print(f"Legacy PT endpoint '{endpoint_name}' ready")
            return {"name": endpoint_name}
        except Exception as e:
            raise RuntimeError(
                f"Legacy PT endpoint '{endpoint_name}' creation failed: {e}"
            ) from e

    else:
        raise RuntimeError(
            f"No PT config found for '{serving_entity}'. "
            f"Cannot create endpoint '{endpoint_name}' without provisioned throughput configuration."
        )


def create_and_sync_vector_index(
    client,
    vs_endpoint: str,
    source_table: str,
    index_name: str,
    primary_key: str,
    embedding_source_column: str,
    embedding_endpoint: str,
    pipeline_type: str = "TRIGGERED",
    registration_timeout: int = 3600,
    ready_timeout: int = 900,
    sync_timeout: int = 3600,
    poll_interval: int = 20,
):
    """
    Create (or attach to) a Databricks Vector Search index and wait
    until it is fully synced and ready for queries.

    Args:
        client: VectorSearchClient instance
        vs_endpoint: Vector Search endpoint name
        source_table: Source Delta table name
        index_name: Name for the vector index
        primary_key: Primary key column name
        embedding_source_column: Column to embed
        embedding_endpoint: Embedding model endpoint name
        pipeline_type: Pipeline type (TRIGGERED or CONTINUOUS)
        registration_timeout: Max seconds to wait for index registration
        ready_timeout: Max seconds to wait for index to be ready
        sync_timeout: Max seconds to wait for sync completion
        poll_interval: Seconds between status checks

    Returns:
        VectorSearchIndex: The created/synced index
    """
    index = None

    # --------------------------------------------------------------
    # 1. CREATE INDEX (ASYNC-SAFE)
    # --------------------------------------------------------------
    try:
        index = client.create_delta_sync_index(
            endpoint_name=vs_endpoint,
            source_table_name=source_table,
            index_name=index_name,
            pipeline_type=pipeline_type,
            primary_key=primary_key,
            embedding_source_column=embedding_source_column,
            embedding_model_endpoint_name=embedding_endpoint,
        )
        print(f"✓ Create request submitted for index: {index_name}")

    except Exception as e:
        msg = str(e)

        if "TEMPORARILY_UNAVAILABLE" in msg or "504" in msg:
            print("⚠️ Create request timed out — creation may still be in progress")
        elif "RESOURCE_ALREADY_EXISTS" in msg:
            print("ℹ️ Index already exists")
        else:
            raise RuntimeError(f"Index creation failed unexpectedly: {e}")

    # --------------------------------------------------------------
    # 2. WAIT FOR REGISTRATION
    # --------------------------------------------------------------
    print("⏳ Waiting for index registration...")

    start = time.time()
    while index is None:
        if time.time() - start > registration_timeout:
            raise TimeoutError(
                f"Index '{index_name}' not registered within {registration_timeout}s"
            )

        try:
            index = client.get_index(
                endpoint_name=vs_endpoint,
                index_name=index_name,
            )
            print("✓ Index registered")
            break

        except Exception as e:
            if "RESOURCE_DOES_NOT_EXIST" in str(e):
                time.sleep(poll_interval)
            else:
                raise RuntimeError(f"Unexpected registration error: {e}")

    # --------------------------------------------------------------
    # 3. WAIT UNTIL INDEX IS READY FOR SYNC
    # --------------------------------------------------------------
    print("⏳ Waiting for index to become ready for sync...")

    start = time.time()
    while True:
        if time.time() - start > ready_timeout:
            raise TimeoutError("Index did not become ready for sync in time")

        try:
            state = index.describe()["status"]["detailed_state"]
            print(f"  Lifecycle state: {state}")

            if state in (
                "ONLINE_NO_PENDING_UPDATE",
                "ONLINE_PENDING_UPDATE",
                "ONLINE_TRIGGERED_UPDATE",
            ):
                print("✓ Index ready for sync")
                break

            if "FAILED" in state:
                raise RuntimeError(f"Index entered FAILED state: {state}")

        except Exception as e:
            print(f"  ⚠️ Error checking readiness: {e}")

        time.sleep(poll_interval)

    # --------------------------------------------------------------
    # 4. TRIGGER SYNC
    # --------------------------------------------------------------
    print("🔄 Triggering index sync...")
    index.sync()
    time.sleep(poll_interval)

    # --------------------------------------------------------------
    # 5. WAIT FOR SYNC COMPLETION
    # --------------------------------------------------------------
    print("⏳ Waiting for index to fully sync...")

    start = time.time()
    consecutive_errors = 0

    while True:
        if time.time() - start > sync_timeout:
            raise TimeoutError("Index sync exceeded maximum wait time")

        try:
            info = index.describe()
            state = info["status"]["detailed_state"]
            msg = info["status"].get("message", "")

            print(f"  Index state: {state}")
            if msg:
                print(f"    Message: {msg}")

            consecutive_errors = 0

            if state == "ONLINE_NO_PENDING_UPDATE":
                print("✓ Index fully synced and ready")
                return index

            if "FAILED" in state:
                raise RuntimeError(
                    f"Index sync failed: {state}. Message: {msg}"
                )

        except Exception as e:
            consecutive_errors += 1
            print(
                f"  ⚠️ Backend error while polling "
                f"({consecutive_errors}/10): {e}"
            )
            if consecutive_errors >= 10:
                raise RuntimeError("Vector Search backend unstable")

        time.sleep(poll_interval)
