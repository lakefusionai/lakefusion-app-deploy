"""
RBAC Config Loader — resolves flat grant rows from rbac_permissions.json.

The JSON is a list of (role, resource_type, name_template, privileges, applies_to, pipeline_type?)
records. This module loads them, substitutes `{catalog}`, `{entity}`, `{entity_upper}`,
`{experiment_id}`, `{llm_model}`, `{embedding_model}` placeholders, and filters by
pipeline_type / applies_to.

The same tuple shape is the target Delta schema — a future migration can write these rows
to `lakefusion_ai.metadata.rbac_grants` and `load_grants()` will gain a `source='delta'`
switch without changing its return type.

This module is the **source of truth**. The backend-side
``lakefusion_utility.config.rbac_config_loader`` is a re-export shim that
imports from here, so notebooks can install only ``lakefusion_core_engine``.

Usage:
    from lakefusion_core_engine.config.rbac_config_loader import load_grants

    rows = load_grants(
        entity="customer",
        experiment_id="prod",
        catalog="lakefusion_local",
        pipeline_type="integration",
        llm_model="lakefusion-gpt-4",
        embedding_model="lakefusion-embed",
    )
    for r in rows:
        apply(r.group_name, r.resource_type, r.full_name, r.privileges)
"""

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


_CONFIG_PATH = Path(__file__).parent / "rbac_permissions.json"
_cached_config: Optional[Dict[str, Any]] = None

# Sentinel name_templates — the executor resolves these at runtime (job_id, endpoint name).
JOB_SENTINEL = "__current_job__"
MODEL_ENDPOINT_SENTINEL = "__model_endpoint__"
VECTOR_ENDPOINT_SENTINEL = "__vector_endpoint__"


@dataclass(frozen=True)
class GrantRow:
    role: str                  # "admin" | "developer" | "data_steward"
    group_name: str            # resolved SCIM group name
    resource_type: str         # "schema" | "table" | "volume" | "index" | "job" | "endpoint" | "uc_model"
    full_name: str             # resolved fully-qualified name (or sentinel)
    privileges: List[str]      # SDK Privilege enum names or permission-level strings
    applies_to: str            # "always" | "prod" | "experiment"
    pipeline_type: Optional[str]  # None (all) | "integration" | "match_maven"


def load_config() -> Dict[str, Any]:
    global _cached_config
    if _cached_config is None:
        with open(_CONFIG_PATH, "r") as f:
            _cached_config = json.load(f)
    return _cached_config


def resolve_group_name(role: str, entity: Optional[str] = None) -> str:
    """Resolve a role's SCIM group name. Admin ignores entity."""
    cfg = load_config()
    template = cfg["roles"][role]["group_template"]
    return template.format(entity_upper=(entity or "").upper())


def load_grants(
    entity: str,
    experiment_id: str,
    catalog: str,
    pipeline_type: Optional[str] = None,
    applies_to: Optional[Iterable[str]] = None,
    llm_model: Optional[str] = None,
    embedding_model: Optional[str] = None,
    roles: Optional[Iterable[str]] = None,
) -> List[GrantRow]:
    """Return flat grant rows with placeholders resolved.

    Filters:
      * `pipeline_type`: only return rows with matching pipeline_type (rows with
        no pipeline_type apply to all pipelines).
      * `applies_to`: restrict to the given scope set (e.g. `{"always","prod"}`
        for entity-create-time provisioning).
      * `roles`: restrict to specific role names.

    Rows whose name_template requires an unset placeholder (llm_model /
    embedding_model) are dropped.
    """
    cfg = load_config()
    roles_def = cfg["roles"]
    applies_filter = set(applies_to) if applies_to is not None else None
    roles_filter = set(roles) if roles is not None else None

    placeholders = {
        "catalog": catalog,
        "entity": entity,
        "entity_upper": (entity or "").upper(),
        "experiment_id": experiment_id or "",
        "llm_model": llm_model or "",
        "embedding_model": embedding_model or "",
    }

    out: List[GrantRow] = []
    for row in cfg["grants"]:
        role = row["role"]
        if roles_filter is not None and role not in roles_filter:
            continue

        row_pipeline = row.get("pipeline_type")
        if pipeline_type is not None and row_pipeline not in (None, "all", pipeline_type):
            continue

        if applies_filter is not None and row["applies_to"] not in applies_filter:
            continue

        name_template = row["name_template"]

        if row["resource_type"] == "uc_model":
            if "{llm_model}" in name_template and not llm_model:
                continue
            if "{embedding_model}" in name_template and not embedding_model:
                continue

        # Sentinels pass through; executor resolves at runtime.
        if name_template in (JOB_SENTINEL, MODEL_ENDPOINT_SENTINEL, VECTOR_ENDPOINT_SENTINEL):
            full_name = name_template
        else:
            try:
                full_name = name_template.format(**placeholders)
            except KeyError:
                continue

        group_name = roles_def[role]["group_template"].format(**placeholders)

        out.append(GrantRow(
            role=role,
            group_name=group_name,
            resource_type=row["resource_type"],
            full_name=full_name,
            privileges=list(row["privileges"]),
            applies_to=row["applies_to"],
            pipeline_type=row_pipeline,
        ))

    return out


def entity_group_names(entity: str) -> Dict[str, str]:
    """Return {'developer': '...', 'data_steward': '...'} for an entity."""
    return {
        "developer": resolve_group_name("developer", entity),
        "data_steward": resolve_group_name("data_steward", entity),
    }


def build_params(
    pipeline_type: str,
    entity: str,
    experiment_id: str,
    catalog_name: str,
    llm_model_parsed: Optional[str] = None,
    embedding_model_parsed: Optional[str] = None,
    creator_emails: Optional[List[str]] = None,
    workspace_id: Optional[str] = None,  # unused; admin is no longer workspace-id-suffixed
) -> Dict[str, Any]:
    """Backwards-compatible shim for notebook wrappers.

    The new RBACPermissionsExecutor reads grants directly via load_grants(); the only
    extra context the executor needs is the list of creator emails and the parsed
    model names. Keeping this signature avoids touching every notebook wrapper.
    """
    return {
        "pipeline_type": pipeline_type,
        "creator_emails": creator_emails or [],
        "llm_model_parsed": llm_model_parsed,
        "embedding_model_parsed": embedding_model_parsed,
    }
