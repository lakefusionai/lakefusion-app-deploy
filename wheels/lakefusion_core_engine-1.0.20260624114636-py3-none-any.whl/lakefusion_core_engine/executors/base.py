"""
Base task class for executor tasks.

All task implementations must inherit from BaseTask.

External Override Support:
    Users can provide override classes (e.g., ProcessCrosswalkExtended) that
    customize pre_execute() and post_execute() without modifying core logic.
    The execute() method is protected and cannot be overridden externally.

    Override Discovery:
        Overrides are auto-discovered from external/overrides/ directory.
        The path is automatically inferred from the executor class's module location,
        so NO changes to notebooks are required.

        Auto-inference examples:
            Executor module: ...executors.tasks.integration_core.process_crosswalk
            Override file:   external/overrides/integration_core/process_crosswalk_override.py
            Override class:  ProcessCrosswalkExtended

            Executor module: ...executors.tasks.integration_core.normal_deduplication.vector_search
            Override file:   external/overrides/integration_core/normal_deduplication/vector_search_override.py
            Override class:  VectorSearchExtended

    Override Modes:
        - Replace (default): Override methods run INSTEAD of default task methods
        - Extend (opt-in): Default methods run FIRST, then override methods run

    Override class example (Replace mode - default):
        class ProcessCrosswalkExtended:
            def pre_execute(self, context):
                # Runs INSTEAD of default pre_execute
                return context

            def post_execute(self, context, result):
                # Runs INSTEAD of default post_execute
                return result

    Override class example (Extend mode - opt-in):
        class ProcessCrosswalkExtended:
            extend_pre_execute = True   # Default runs first, then this
            extend_post_execute = True  # Default runs first, then this

            def pre_execute(self, context):
                # Runs AFTER default pre_execute
                return context

            def post_execute(self, context, result):
                # Runs AFTER default post_execute
                return result
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, Optional

from .models import TaskContext, TaskResult, TaskStatus, ValidationResult, ExecutionPhase
from .override_loader import OverrideLoader


class BaseTask(ABC):
    """
    Abstract base class for all executor tasks.

    Provides a standard lifecycle for task execution with hooks for
    pre-processing, main execution, validation, and post-processing.

    Lifecycle with external overrides:
        1. pre_execute() - Uses override.pre_execute() if available
        2. execute() - Core logic (NOT overridable externally)
        3. validate() - Validation
        4. post_execute() - Uses override.post_execute() if available
        5. on_success() / on_failure() - Callbacks

    Subclasses must implement:
        - execute(): Main task logic

    Subclasses may override:
        - pre_execute(): Setup before main execution
        - validate(): Validation after execution
        - post_execute(): Cleanup after execution
        - on_success(): Called on successful completion
        - on_failure(): Called on failure
    """

    def __init__(self, context: TaskContext, override_instance: Any = None, auto_load_override: bool = True):
        """
        Initialize the task with context and optional external override.

        Args:
            context: TaskContext containing all dependencies and configuration
            override_instance: Optional user-provided override class instance
                              that can customize pre_execute and post_execute.
                              If provided, auto-discovery is skipped.
            auto_load_override: If True (default), automatically discover and load
                               override from external/overrides/ directory when
                               override_instance is not provided.
        """
        self.context = context
        self._result: Optional[TaskResult] = None

        # Initialize logger with fallback chain:
        # 1. params["logger"] (passed from notebook)
        # 2. context.logger (set on TaskContext directly)
        # 3. stdlib logging (safe fallback for interactive/no-pipeline mode)
        self.logger = (
            (context.params.get("logger") if context.params else None)
            or context.logger
            or logging.getLogger(self.__class__.__name__)
        )

        # Use provided override or auto-discover from external/overrides/
        if override_instance is not None:
            self._override = override_instance
        elif auto_load_override:
            # Auto-infer override path from class module location
            override_task_path = self._infer_override_path()
            if override_task_path:
                self._override = OverrideLoader.load_override(override_task_path)
            else:
                self._override = None
        else:
            self._override = None

    def _infer_override_path(self) -> Optional[str]:
        """
        Infer the override path from the executor class's module location.

        This allows automatic override discovery based on where the executor
        class is defined, without requiring changes to notebooks.

        Examples:
            Module: lakefusion_core_engine.executors.tasks.integration_core.process_crosswalk
            Returns: "integration_core/process_crosswalk"

            Module: lakefusion_core_engine.executors.tasks.integration_core.normal_deduplication.entity_matching_vector_search
            Returns: "integration_core/normal_deduplication/entity_matching_vector_search"

        Returns:
            Override path string, or None if path cannot be inferred
        """
        try:
            module_name = self.__class__.__module__

            # Look for 'tasks.' in the module path
            if '.tasks.' in module_name:
                # Extract everything after 'tasks.'
                # e.g., "...executors.tasks.integration_core.process_crosswalk"
                #       -> "integration_core.process_crosswalk"
                task_path = module_name.split('.tasks.', 1)[1]

                # Convert dots to forward slashes for path
                # e.g., "integration_core.process_crosswalk"
                #       -> "integration_core/process_crosswalk"
                override_path = task_path.replace('.', '/')

                return override_path

            # Fallback to context.task_name if available
            if self.context.task_name:
                return self.context.task_name

            return None

        except Exception:
            # If inference fails, fall back to context.task_name
            if self.context.task_name:
                return self.context.task_name
            return None

    @property
    def spark(self):
        """Get SparkSession from context."""
        return self.context.spark

    @property
    def dbutils(self):
        """Get DBUtils from context."""
        return self.context.dbutils

    @abstractmethod
    def execute(self) -> TaskResult:
        """
        Main task execution logic.

        This method must be implemented by subclasses to perform
        the actual task work.

        Returns:
            TaskResult with status, metrics, and any artifacts
        """
        pass

    def pre_execute(self) -> None:
        """
        Hook called before execute().

        Override to perform setup, logging, or validation before
        the main task runs. Raise an exception to abort execution.
        """
        pass

    def validate(self, result: TaskResult) -> TaskResult:
        """
        Hook called after execute() to validate results.

        Override to add validation logic. Can modify the result
        status based on validation outcomes.

        Args:
            result: The TaskResult from execute()

        Returns:
            TaskResult, potentially modified with validation results
        """
        return result

    def post_execute(self, result: TaskResult) -> None:
        """
        Hook called after validate().

        Override to perform cleanup, logging, or notification
        after the task completes.

        Args:
            result: The final TaskResult
        """
        pass

    def on_success(self, result: TaskResult) -> None:
        """
        Hook called when task completes successfully.

        Override to perform success-specific actions like
        setting task values or sending notifications.

        Args:
            result: The successful TaskResult
        """
        pass

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """
        Hook called when task fails.

        Override to perform failure-specific actions like
        logging errors or sending alerts.

        Args:
            result: The failed TaskResult (includes error details in
                    result.message, result.errors, result.error_type,
                    and result.traceback)
            error: Optional exception that caused the failure
        """
        pass

    def run(self) -> TaskResult:
        """
        Execute the task with full lifecycle.

        Runs the task through its complete lifecycle:
        1. pre_execute() - Setup (uses override if available)
        2. execute() - Main logic (NOT overridable)
        3. validate() - Validation
        4. post_execute() - Cleanup (uses override if available)
        5. on_success() or on_failure() - Callbacks

        Returns:
            TaskResult from the execution
        """
        try:
            # Pre-execution hook (delegate to override if available)
            self._run_pre_execute()

            # Main execution (core logic - never delegated to override)
            result = self.execute()

            # Validation hook
            result = self.validate(result)

            # Post-execution hook (delegate to override if available)
            result = self._run_post_execute(result)

            # Success/failure callbacks
            # Use is_failed to ensure SKIPPED and WARNING also trigger on_success
            # (task values need to be set even when no changes are found)
            if not result.is_failed:
                self.on_success(result)
            else:
                self.on_failure(result)

            self._result = result
            return result

        except Exception as e:
            # Create failure result
            result = TaskResult.failed(
                message=f"Task failed with error: {str(e)}",
                errors=[str(e)]
            )
            self._result = result

            # Failure callback with exception
            self.on_failure(result, error=e)

            # Re-raise to propagate exception to notebook (matches production behavior)
            raise

    def _run_pre_execute(self) -> None:
        """
        Run pre-execute phase with override delegation.

        Override Modes:
            - Replace (default): Only override's pre_execute() runs
            - Extend (opt-in): Default pre_execute() runs FIRST, then override's

        To enable extend mode, set `extend_pre_execute = True` on the override class.
        """
        has_override = OverrideLoader.has_pre_execute(self._override)

        if has_override:
            extend_mode = OverrideLoader.should_extend_pre_execute(self._override)

            if extend_mode:
                # Extend mode: run default first, then override
                print("Running pre_execute in EXTEND mode (default + override)")
                self.pre_execute()
                self._override.pre_execute(self.context)
            else:
                # Replace mode (default): only override runs
                print("Running pre_execute in REPLACE mode (override only)")
                self._override.pre_execute(self.context)
        else:
            # No override, run default
            self.pre_execute()

    def _run_post_execute(self, result: TaskResult) -> TaskResult:
        """
        Run post-execute phase with override delegation.

        Override Modes:
            - Replace (default): Only override's post_execute() runs
            - Extend (opt-in): Default post_execute() runs FIRST, then override's

        To enable extend mode, set `extend_post_execute = True` on the override class.

        Args:
            result: TaskResult from execute/validate phase

        Returns:
            TaskResult, potentially modified by override
        """
        has_override = OverrideLoader.has_post_execute(self._override)

        if has_override:
            extend_mode = OverrideLoader.should_extend_post_execute(self._override)

            if extend_mode:
                # Extend mode: run default first, then override
                print("Running post_execute in EXTEND mode (default + override)")
                self.post_execute(result)
                return self._override.post_execute(self.context, result) or result
            else:
                # Replace mode (default): only override runs
                print("Running post_execute in REPLACE mode (override only)")
                return self._override.post_execute(self.context, result) or result
        else:
            # No override, run default
            self.post_execute(result)
            return result

    @property
    def has_override(self) -> bool:
        """Check if an external override instance is configured."""
        return self._override is not None

    def print_header(self, title: str, char: str = "=", width: int = 80) -> None:
        """
        Print a formatted section header.

        Args:
            title: Title text to display
            char: Character to use for the border
            width: Width of the header line
        """
        print(f"\n{char * width}")
        print(title)
        print(char * width)

    def print_summary(self, result: TaskResult) -> None:
        """
        Print a formatted summary of the task result.

        Args:
            result: TaskResult to summarize
        """
        self.print_header("TASK SUMMARY")
        print(f"Status: {result.status}")
        print(f"Message: {result.message}")

        if result.metrics:
            print("\nMetrics:")
            for key, value in result.metrics.items():
                print(f"  {key}: {value}")

        if result.validations:
            print("\nValidations:")
            for v in result.validations:
                status = "PASSED" if v.passed else "FAILED"
                print(f"  [{status}] {v.message}")

        if result.artifacts:
            print("\nArtifacts:")
            for key, value in result.artifacts.items():
                print(f"  {key}: {value}")

        if result.errors:
            print("\nErrors:")
            for error in result.errors:
                print(f"  - {error}")
