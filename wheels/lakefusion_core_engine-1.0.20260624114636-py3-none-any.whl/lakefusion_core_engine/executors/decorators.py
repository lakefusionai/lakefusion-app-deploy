"""
Step decorator for marking methods as executable steps.

The @step decorator enables step-based execution with interactive debugging support.
Methods decorated with @step can be executed individually or as part of a full run.

Usage:
    @step(order=1, name="Load Data", returns="DataFrame - loaded records")
    def step_load_data(self):
        df = self.spark.table("source_table")
        self.df_loaded = df
        return df

Features:
    - Automatic result caching in context.state
    - Step completion tracking
    - Formatted output with step headers
    - Support for both production and interactive execution modes
"""

from functools import wraps
from typing import Any, Callable, Optional


def step(order: int, name: str = None, returns: str = None) -> Callable:
    """
    Decorator to mark a method as an execution step.

    Steps are executed in order during production mode (via execute()),
    or can be run individually in interactive mode (via run_step()).

    Args:
        order: Execution order (1, 2, 3, ...). Must be unique within a task.
        name: Human-readable step name for display. Defaults to method name.
        returns: Description of what this step returns (for documentation).

    Returns:
        Decorated method with step metadata.

    Example:
        @step(order=1, name="Load Data", returns="DataFrame - raw records")
        def step_load(self):
            df = self.spark.table(self.source_table)
            self.df_loaded = df
            return {"rows": df.count()}

        @step(order=2, name="Transform", returns="DataFrame - transformed")
        def step_transform(self):
            df = self.df_loaded.filter(col("status") == "active")
            self.df_transformed = df
            return {"rows": df.count()}
    """
    def decorator(func: Callable) -> Callable:
        # Store step metadata on the function
        func._is_step = True
        func._step_order = order
        func._step_name = name or func.__name__
        func._step_returns = returns

        @wraps(func)
        def wrapper(self, *args, **kwargs) -> Any:
            step_name = func._step_name
            step_order = func._step_order

            # Print step header
            print(f"\n{'='*60}")
            print(f"  STEP {step_order}: {step_name}")
            print(f"{'='*60}")

            # Execute the step
            result = func(self, *args, **kwargs)

            # Auto-save result to context.state for caching
            if hasattr(self, 'context') and hasattr(self.context, 'state'):
                self.context.state[f'_step_{step_order}_result'] = result
                self.context.state[f'_step_{step_order}_completed'] = True

            print(f"  ✓ Step {step_order} completed")

            return result

        # Copy step metadata to wrapper
        wrapper._is_step = True
        wrapper._step_order = order
        wrapper._step_name = name or func.__name__
        wrapper._step_returns = returns

        return wrapper

    return decorator
