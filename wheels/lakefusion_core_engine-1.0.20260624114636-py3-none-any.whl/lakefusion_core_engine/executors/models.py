"""
Core models for the Task Executor Framework.

Contains all data classes and enums used throughout the executor system:
- TaskStatus: Execution status enum
- ExecutionPhase: Phase tracking enum
- TaskContext: Execution context passed through phases
- TaskResult: Structured result with task values
- ValidationResult: Individual validation check result
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class TaskStatus(Enum):
    """Status of task execution."""
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    WARNING = "WARNING"
    SKIPPED = "SKIPPED"

    def __str__(self) -> str:
        return self.value


class ExecutionPhase(Enum):
    """Current phase of task execution."""
    PRE = "PRE"
    EXECUTE = "EXECUTE"
    POST = "POST"

    def __str__(self) -> str:
        return self.value


@dataclass
class TaskContext:
    """
    Context object passed through pre/execute/post phases.
    Contains all inputs, state, and configuration needed for task execution.

    Attributes:
        task_name: Name of the task being executed
        entity: Entity name being processed
        entity_id: Optional entity ID
        run_id: Databricks run ID
        experiment_id: Optional experiment ID for A/B testing
        catalog_name: Unity Catalog name

        entity_json: Entity configuration JSON
        model_json: Model configuration JSON
        dataset_objects: Dictionary of dataset configurations
        params: Additional parameters for the task

        spark: SparkSession instance
        dbutils: Databricks utilities

        state: Mutable state passed between phases
        parameters: Additional parameters (alias for params for compatibility)

        logger: Logger reference
        start_time: Execution start time
        current_phase: Current execution phase
    """
    # Core identifiers
    task_name: str = ""
    entity: str = ""
    entity_id: Optional[str] = None
    run_id: Optional[str] = None
    experiment_id: Optional[str] = None
    catalog_name: str = "lakefusion_ai"

    # Input data
    entity_json: Optional[Dict[str, Any]] = None
    model_json: Optional[Dict[str, Any]] = None
    dataset_objects: Dict[str, Any] = field(default_factory=dict)
    params: Dict[str, Any] = field(default_factory=dict)

    # Spark/Databricks context (set at runtime)
    spark: Any = None
    dbutils: Any = None

    # State passed between phases (mutable - use this to pass data)
    state: Dict[str, Any] = field(default_factory=dict)
    parameters: Dict[str, Any] = field(default_factory=dict)

    # Logger reference
    logger: Any = None

    # Metadata
    start_time: Optional[datetime] = None
    current_phase: ExecutionPhase = ExecutionPhase.PRE

    # Relationship-pipeline fields (Story 2). Populated only when running a
    # relationship sync task. Kept optional so existing entity tasks ignore them.
    relationship_name: Optional[str] = None
    integration_hub_relationship_id: Optional[str] = None
    relationship_config: Optional[Dict[str, Any]] = None  # Snapshot of relationship + attrs + mappings

    # Relationship-edge table names
    @property
    def relationship_edges_table(self) -> str:
        """Get the production edges Delta table for the current relationship.

        Schema follows the LakeGraph contract: src_node_id, dst_node_id,
        src_node_type, dst_node_type, edge_type, [attrs], start_date, end_date,
        status, contributing_sources, origin, audit columns.
        """
        if not self.relationship_name:
            raise ValueError("relationship_name is required on TaskContext")
        base = f"{self.catalog_name}.gold.{self.relationship_name}_edges"
        if self.experiment_id:
            base += f"_{self.experiment_id}"
        return base

    @property
    def relationship_edges_dlq_table(self) -> str:
        """Get the dead-letter Delta table for failed-resolution and conflict rows."""
        if not self.relationship_name:
            raise ValueError("relationship_name is required on TaskContext")
        base = f"{self.catalog_name}.gold.{self.relationship_name}_edges_dlq"
        if self.experiment_id:
            base += f"_{self.experiment_id}"
        return base

    # Computed table/view names
    @property
    def unified_table(self) -> str:
        """Get the unified table name with optional experiment suffix."""
        base = f"{self.catalog_name}.silver.{self.entity}_unified"
        if self.experiment_id:
            base += f"_{self.experiment_id}"
        return base

    @property
    def unified_deduplicate_table(self) -> str:
        """Get the unified table name with optional experiment suffix."""
        base = f"{self.catalog_name}.silver.{self.entity}_unified_deduplicate"
        if self.experiment_id:
            base += f"_{self.experiment_id}"
        return base

    @property
    def master_table(self) -> str:
        """Get the master table name with optional experiment suffix."""
        base = f"{self.catalog_name}.gold.{self.entity}_master"
        if self.experiment_id:
            base += f"_{self.experiment_id}"
        return base

    @property
    def crosswalk_view(self) -> str:
        """Get the crosswalk view name with optional experiment suffix."""
        base = f"{self.catalog_name}.gold.{self.entity}_crosswalk"
        if self.experiment_id:
            base += f"_{self.experiment_id}"
        return base

    @property
    def merge_activities_table(self) -> str:
        """Get the merge activities table name."""
        return f"{self.master_table}_merge_activities"

    @property
    def processed_unified_table(self) -> str:
        """Get the processed unified table name with optional experiment suffix."""
        base = f"{self.catalog_name}.silver.{self.entity}_processed_unified"
        if self.experiment_id:
            base += f"_{self.experiment_id}"
        return base

    @property
    def unified_deterministic_table(self) -> str:
        """Get the unified deterministic table name with optional experiment suffix."""
        base = f"{self.catalog_name}.silver.{self.entity}_unified_deterministic"
        if self.experiment_id:
            base += f"_{self.experiment_id}"
        return base

    @property
    def unified_deterministic_deduplicate_table(self) -> str:
        """Get the unified deterministic table name with optional experiment suffix."""
        base = f"{self.catalog_name}.silver.{self.entity}_unified_deterministic_deduplicate"
        if self.experiment_id:
            base += f"_{self.experiment_id}"
        return base

    # LLM Matching properties - retrieved from params or model_json
    @property
    def llm_endpoint(self) -> str:
        """Get LLM endpoint name from params."""
        return self.params.get('llm_endpoint', '')

    @property
    def max_potential_matches(self) -> int:
        """Get max potential matches from params."""
        return int(self.params.get('max_potential_matches', 3))

    @property
    def attributes(self) -> List[str]:
        """Get match attributes from params."""
        attrs = self.params.get('attributes', [])
        if isinstance(attrs, str):
            import json
            return json.loads(attrs)
        return attrs

    @property
    def additional_instructions(self) -> str:
        """Get additional LLM instructions from params."""
        return self.params.get('additional_instructions', '')

    @property
    def base_prompt(self) -> str:
        """Get base prompt for LLM from params."""
        return self.params.get('base_prompt', '')

    @property
    def config_thresholds(self) -> Dict[str, List[float]]:
        """Get match thresholds configuration from params."""
        thresholds = self.params.get('config_thresholds', {})
        if isinstance(thresholds, str):
            import json
            return json.loads(thresholds)
        return thresholds

    @property
    def merge_min(self) -> float:
        """Get merge threshold minimum."""
        return self.config_thresholds.get('merge', [0.9, 1.0])[0]

    @property
    def merge_max(self) -> float:
        """Get merge threshold maximum."""
        return self.config_thresholds.get('merge', [0.9, 1.0])[1]

    @property
    def matches_min(self) -> float:
        """Get potential match threshold minimum."""
        return self.config_thresholds.get('matches', [0.7, 0.89])[0]

    @property
    def matches_max(self) -> float:
        """Get potential match threshold maximum."""
        return self.config_thresholds.get('matches', [0.7, 0.89])[1]

    @property
    def not_match_min(self) -> float:
        """Get no match threshold minimum."""
        return self.config_thresholds.get('not_match', [0.0, 0.69])[0]

    @property
    def not_match_max(self) -> float:
        """Get no match threshold maximum."""
        return self.config_thresholds.get('not_match', [0.0, 0.69])[1]

    @property
    def unified_id_key(self) -> str:
        """Get unified table ID key."""
        return self.params.get('unified_id_key', 'surrogate_key')

    @property
    def master_id_key(self) -> str:
        """Get master table ID key."""
        return self.params.get('master_id_key', 'lakefusion_id')

    @property
    def merged_desc_column(self) -> str:
        """Get merged description column name."""
        return self.params.get('merged_desc_column', 'attributes_combined')

    @property
    def attribute_version_sources_table(self) -> str:
        """Get the attribute version sources table name."""
        return f"{self.master_table}_attribute_version_sources"

    # Manual Merge properties
    @property
    def entity_attributes(self) -> List[str]:
        """Get entity attributes list from params."""
        attrs = self.params.get('entity_attributes', [])
        if isinstance(attrs, str):
            import json
            return json.loads(attrs)
        return attrs

    @property
    def entity_attributes_datatype(self) -> Dict[str, str]:
        """Get entity attributes datatype mapping from params."""
        datatypes = self.params.get('entity_attributes_datatype', {})
        if isinstance(datatypes, str):
            import json
            return json.loads(datatypes)
        return datatypes

    @property
    def default_survivorship_rules(self) -> List[Dict[str, Any]]:
        """Get default survivorship rules from params."""
        rules = self.params.get('default_survivorship_rules', [])
        if isinstance(rules, str):
            import json
            return json.loads(rules)
        return rules

    @property
    def match_attributes(self) -> List[str]:
        """Get match attributes list from params."""
        attrs = self.params.get('match_attributes', [])
        if isinstance(attrs, str):
            import json
            return json.loads(attrs)
        return attrs

    @property
    def master_id(self) -> str:
        """Get the master record ID for merge operations."""
        return self.params.get('master_id', '')

    @property
    def unified_dataset_ids(self) -> List[Dict[str, str]]:
        """Get unified record IDs with dataset IDs for merge operations."""
        ids = self.params.get('unified_dataset_ids', [])
        if isinstance(ids, str):
            import json
            return json.loads(ids)
        return ids

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format."""
        return {
            'task_name': self.task_name,
            'entity': self.entity,
            'entity_id': self.entity_id,
            'run_id': self.run_id,
            'experiment_id': self.experiment_id,
            'catalog_name': self.catalog_name,
            'dataset_objects': self.dataset_objects,
            'params': self.params,
            'parameters': self.parameters,
            'unified_table': self.unified_table,
            'master_table': self.master_table,
            'crosswalk_view': self.crosswalk_view,
            'merge_activities_table': self.merge_activities_table,
            'processed_unified_table': self.processed_unified_table,
            'llm_endpoint': self.llm_endpoint,
            'max_potential_matches': self.max_potential_matches,
            'current_phase': str(self.current_phase)
        }


@dataclass
class ValidationResult:
    """
    Result of a validation check.

    Attributes:
        passed: Whether the validation passed
        message: Description of the validation result
        expected: Expected value (for comparison validations)
        actual: Actual value found
    """
    passed: bool
    message: str
    expected: Optional[Any] = None
    actual: Optional[Any] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format."""
        return {
            'passed': self.passed,
            'message': self.message,
            'expected': self.expected,
            'actual': self.actual
        }


@dataclass
class TaskResult:
    """
    Result returned from task execution.
    Provides structured output with metadata.

    Attributes:
        status: Overall task status
        task_name: Name of the task
        message: Summary message describing the result
        phase: Execution phase when result was created

        data: Output data dictionary
        task_values: Values to pass to next task via dbutils.jobs.taskValues
        metrics: Dictionary of metrics collected during execution
        validations: List of validation results
        artifacts: Dictionary of output artifacts (table names, view names, etc.)
        errors: List of error messages if any occurred

        start_time: Execution start time
        end_time: Execution end time
        duration_seconds: Total execution duration

        error: Error message if failed
        error_type: Type of error
        traceback: Full traceback if failed

        messages: Audit trail of messages
    """
    status: TaskStatus
    task_name: str = ""
    message: str = ""
    phase: ExecutionPhase = ExecutionPhase.EXECUTE

    # Output data
    data: Dict[str, Any] = field(default_factory=dict)
    task_values: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, Any] = field(default_factory=dict)
    validations: List[ValidationResult] = field(default_factory=list)
    artifacts: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)

    # Execution metadata
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    duration_seconds: Optional[float] = None

    # Error info (if failed)
    error: Optional[str] = None
    error_type: Optional[str] = None
    traceback: Optional[str] = None

    # Audit trail
    messages: List[str] = field(default_factory=list)

    @property
    def is_success(self) -> bool:
        """Check if task completed successfully."""
        return self.status == TaskStatus.SUCCESS

    @property
    def is_failed(self) -> bool:
        """Check if task failed."""
        return self.status == TaskStatus.FAILED

    @property
    def validation_passed(self) -> bool:
        """Check if all validations passed."""
        return all(v.passed for v in self.validations)

    def add_message(self, message: str) -> None:
        """Add a message to the audit trail with timestamp."""
        self.messages.append(f"[{datetime.utcnow().isoformat()}] {message}")

    def add_validation(self, validation: ValidationResult) -> None:
        """Add a validation result."""
        self.validations.append(validation)

    def add_error(self, error: str) -> None:
        """Add an error message."""
        self.errors.append(error)

    def set_task_value(self, key: str, value: Any) -> None:
        """Set a value to be passed to the next task via dbutils.jobs.taskValues."""
        self.task_values[key] = value

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary for serialization."""
        return {
            'status': str(self.status),
            'task_name': self.task_name,
            'message': self.message,
            'phase': str(self.phase),
            'data': self.data,
            'task_values': self.task_values,
            'metrics': self.metrics,
            'validations': [v.to_dict() for v in self.validations],
            'artifacts': self.artifacts,
            'errors': self.errors,
            'duration_seconds': self.duration_seconds,
            'error': self.error,
            'error_type': self.error_type,
            'messages': self.messages
        }

    @classmethod
    def success(cls, message: str, task_name: str = "", **kwargs) -> 'TaskResult':
        """Create a successful result."""
        return cls(status=TaskStatus.SUCCESS, message=message, task_name=task_name, **kwargs)

    @classmethod
    def failed(cls, message: str, task_name: str = "", errors: Optional[List[str]] = None, **kwargs) -> 'TaskResult':
        """Create a failed result."""
        return cls(
            status=TaskStatus.FAILED,
            message=message,
            task_name=task_name,
            errors=errors or [],
            **kwargs
        )

    @classmethod
    def warning(cls, message: str, task_name: str = "", **kwargs) -> 'TaskResult':
        """Create a warning result."""
        return cls(status=TaskStatus.WARNING, message=message, task_name=task_name, **kwargs)

    @classmethod
    def skipped(cls, message: str, task_name: str = "", **kwargs) -> 'TaskResult':
        """Create a skipped result."""
        return cls(status=TaskStatus.SKIPPED, message=message, task_name=task_name, **kwargs)
