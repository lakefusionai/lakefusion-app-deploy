"""
Override loader utility for LakeFusion task executors.

Provides centralized logic for discovering and loading external override classes
that customize pre_execute() and post_execute() phases of task executors.

Override Discovery:
    Supports mirrored folder structure matching executors/tasks/ layout.

    Task name format: "folder/subfolder/task_name" or "task_name"
    File naming: {override_path}/{folder}/{subfolder}/{task_name}_override.py
    Class naming: {TaskNamePascalCase}Extended (based on last part of task_name)

    Examples:
        task_name = "integration_core/process_crosswalk"
        file = external/overrides/integration_core/process_crosswalk_override.py
        class = ProcessCrosswalkExtended

        task_name = "integration_core/normal_deduplication/vector_search"
        file = external/overrides/integration_core/normal_deduplication/vector_search_override.py
        class = VectorSearchExtended

Override Modes:
    - Replace (default): Override methods run INSTEAD of default task methods
    - Extend (opt-in): Default methods run FIRST, then override methods run

To enable extend mode, set class attributes:
    class MyTaskExtended:
        extend_pre_execute = True   # Run default pre_execute, then this
        extend_post_execute = True  # Run default post_execute, then this

Deployment Notes:
    - .py.example files are templates shipped with releases (never loaded)
    - .py files are actual customer overrides (loaded by the system)
    - New releases should only add/update .example files, never touch .py files
"""

import importlib.util
import os
from typing import Any, Dict, Optional


class OverrideLoader:
    """
    Utility class for loading external override classes.

    Handles discovery, loading, and caching of override classes from the
    external/overrides directory.
    """

    _override_path: str = "external/overrides"
    _cache: Dict[str, Any] = {}  # Cache for loaded override instances

    @classmethod
    def set_override_path(cls, path: str) -> None:
        """
        Set the path where external override classes are located.

        Args:
            path: Absolute or relative path to overrides directory
                  (e.g., "/Workspace/.../external/overrides")
        """
        cls._override_path = path
        # Clear cache when path changes
        cls._cache.clear()

    @classmethod
    def get_override_path(cls) -> str:
        """Get the current override path."""
        return cls._override_path

    @classmethod
    def clear_cache(cls) -> None:
        """Clear the loaded overrides cache."""
        cls._cache.clear()

    @classmethod
    def _to_snake_case(cls, name: str) -> str:
        """Convert task name to snake_case for filename."""
        return name.lower().replace(" ", "_").replace("-", "_")

    @classmethod
    def _to_pascal_case(cls, name: str) -> str:
        """Convert task name to PascalCase for class name."""
        words = name.replace("_", " ").replace("-", " ").split()
        return "".join(word.capitalize() for word in words)

    @classmethod
    def _parse_task_path(cls, task_name: str) -> tuple:
        """
        Parse task name into folder path and base task name.

        Supports both flat and nested task names:
            "process_crosswalk" -> ("", "process_crosswalk")
            "integration_core/process_crosswalk" -> ("integration_core", "process_crosswalk")
            "integration_core/normal_deduplication/vector_search" ->
                ("integration_core/normal_deduplication", "vector_search")

        Args:
            task_name: Full task name, optionally with folder path

        Returns:
            Tuple of (folder_path, base_task_name)
        """
        # Normalize separators (support both / and .)
        normalized = task_name.replace(".", "/")

        if "/" in normalized:
            parts = normalized.rsplit("/", 1)
            return (parts[0], parts[1])
        else:
            return ("", task_name)

    @classmethod
    def load_override(cls, task_name: str) -> Optional[Any]:
        """
        Load user override class for a task from external/overrides/ directory.

        Supports mirrored folder structure:
            task_name = "integration_core/process_crosswalk"
            file = external/overrides/integration_core/process_crosswalk_override.py
            class = ProcessCrosswalkExtended

            task_name = "integration_core/normal_deduplication/vector_search"
            file = external/overrides/integration_core/normal_deduplication/vector_search_override.py
            class = VectorSearchExtended

        Also supports flat task names for backward compatibility:
            task_name = "process_crosswalk"
            file = external/overrides/process_crosswalk_override.py
            class = ProcessCrosswalkExtended

        Args:
            task_name: Name of the task, optionally with folder path
                       (e.g., "integration_core/process_crosswalk")

        Returns:
            Instance of override class, or None if not found
        """
        # Check cache first
        if task_name in cls._cache:
            return cls._cache[task_name]

        # Parse task name into folder path and base name
        folder_path, base_name = cls._parse_task_path(task_name)

        # Convert base task name to snake_case for filename
        snake_name = cls._to_snake_case(base_name)

        # Build override file path with folder structure
        if folder_path:
            override_file = os.path.join(
                cls._override_path,
                folder_path,
                f"{snake_name}_override.py"
            )
        else:
            override_file = os.path.join(
                cls._override_path,
                f"{snake_name}_override.py"
            )

        # Convert base task name to PascalCase for class name
        # Only use the base name, not the full path
        pascal_name = cls._to_pascal_case(base_name)
        class_name = f"{pascal_name}Extended"

        try:
            # Check if file exists
            if not os.path.exists(override_file):
                cls._cache[task_name] = None
                return None

            # Load module dynamically
            module_name = f"{snake_name}_override"
            if folder_path:
                # Include folder path in module name to avoid conflicts
                module_name = f"{folder_path.replace('/', '_')}_{snake_name}_override"

            spec = importlib.util.spec_from_file_location(
                module_name,
                override_file
            )
            if spec is None or spec.loader is None:
                cls._cache[task_name] = None
                return None

            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Get the Extended class
            if hasattr(module, class_name):
                override_class = getattr(module, class_name)
                instance = override_class()  # Return instance
                cls._cache[task_name] = instance
                print(f"Loaded override for '{task_name}' from {override_file}")
                return instance

            # Class not found in module
            print(f"Warning: Override file found but class '{class_name}' not found in {override_file}")
            cls._cache[task_name] = None
            return None

        except Exception as e:
            print(f"Warning: Failed to load override for {task_name}: {e}")
            cls._cache[task_name] = None
            return None

    @classmethod
    def should_extend_pre_execute(cls, override_instance: Any) -> bool:
        """
        Check if pre_execute should run in extend mode.

        Args:
            override_instance: The override class instance

        Returns:
            True if extend mode (run default then override), False for replace mode
        """
        if override_instance is None:
            return False
        return getattr(override_instance, 'extend_pre_execute', False)

    @classmethod
    def should_extend_post_execute(cls, override_instance: Any) -> bool:
        """
        Check if post_execute should run in extend mode.

        Args:
            override_instance: The override class instance

        Returns:
            True if extend mode (run default then override), False for replace mode
        """
        if override_instance is None:
            return False
        return getattr(override_instance, 'extend_post_execute', False)

    @classmethod
    def has_pre_execute(cls, override_instance: Any) -> bool:
        """Check if override instance has pre_execute method."""
        return override_instance is not None and hasattr(override_instance, 'pre_execute')

    @classmethod
    def has_post_execute(cls, override_instance: Any) -> bool:
        """Check if override instance has post_execute method."""
        return override_instance is not None and hasattr(override_instance, 'post_execute')
