"""
Task registry for executor tasks.

Provides registration, discovery, and instantiation of task executors
with support for external overrides.

External Override Discovery:
    Override classes are loaded from external/overrides/ directory.
    File naming: {task_name_snake_case}_override.py
    Class naming: {TaskNamePascalCase}Extended

    Example:
        task_name = "Process_Crosswalk"
        file = external/overrides/process_crosswalk_override.py
        class = ProcessCrosswalkExtended

Override Modes:
    - Replace (default): Override methods run INSTEAD of default task methods
    - Extend (opt-in): Default methods run FIRST, then override methods run

    To enable extend mode, set class attributes on the override:
        class ProcessCrosswalkExtended:
            extend_pre_execute = True
            extend_post_execute = True
"""

from typing import Any, Callable, Dict, Optional, Type

from .base import BaseTask
from .models import TaskContext
from .override_loader import OverrideLoader


class TaskRegistry:
    """
    Registry for task executor classes.

    Allows registration of task classes by name and supports
    loading external override classes that extend base implementations.

    Override Discovery:
        1. Programmatic: TaskRegistry.register_override(name, class)
        2. File-based: Auto-discovery from external/overrides/ directory

    Example:
        # Register a task
        TaskRegistry.register('process_crosswalk', ProcessCrosswalkTask)

        # Create an instance (auto-loads external override if exists)
        task = TaskRegistry.create('process_crosswalk', context, load_overrides=True)

        # Or programmatically register override
        TaskRegistry.register_override('process_crosswalk', ProcessCrosswalkExtended)
        task = TaskRegistry.create('process_crosswalk', context)
    """

    _tasks: Dict[str, Type[BaseTask]] = {}
    _overrides: Dict[str, Type[BaseTask]] = {}

    @classmethod
    def register(cls, name: str, task_class: Type[BaseTask]) -> None:
        """
        Register a task class by name.

        Args:
            name: Unique identifier for the task
            task_class: Task class (must extend BaseTask)
        """
        if not issubclass(task_class, BaseTask):
            raise TypeError(f"Task class must extend BaseTask: {task_class}")
        cls._tasks[name] = task_class

    @classmethod
    def register_override(cls, name: str, override_class: Type[BaseTask]) -> None:
        """
        Register an override class for a task programmatically.

        The override class will be used instead of the base task
        when creating instances.

        Args:
            name: Task name to override
            override_class: Override class (must extend BaseTask)
        """
        if not issubclass(override_class, BaseTask):
            raise TypeError(f"Override class must extend BaseTask: {override_class}")
        cls._overrides[name] = override_class

    @classmethod
    def set_override_path(cls, path: str) -> None:
        """
        Set the path where external override classes are located.

        Args:
            path: Absolute or relative path to overrides directory
                  (e.g., "/Workspace/.../external/overrides")
        """
        OverrideLoader.set_override_path(path)

    @classmethod
    def get_override_path(cls) -> str:
        """Get the current override path."""
        return OverrideLoader.get_override_path()

    @classmethod
    def load_override_class(cls, task_name: str) -> Optional[Any]:
        """
        Load user override class for a task from external/overrides/ directory.

        Looks for: {override_path}/{task_name_snake}_override.py
        Class name: {TaskNamePascalCase}Extended

        Example:
            task_name = "Process_Crosswalk"
            file = external/overrides/process_crosswalk_override.py
            class = ProcessCrosswalkExtended

        Args:
            task_name: Name of the task to load override for

        Returns:
            Instance of override class, or None if not found
        """
        return OverrideLoader.load_override(task_name)

    @classmethod
    def create(
        cls,
        name: str,
        context: TaskContext,
        load_overrides: bool = False
    ) -> BaseTask:
        """
        Create a task instance by name.

        Priority order for override resolution:
        1. Programmatically registered override (register_override)
        2. External file-based override (if load_overrides=True)
        3. Base registered task class

        Args:
            name: Registered task name
            context: TaskContext for the task
            load_overrides: If True, attempt to load external override from file

        Returns:
            Instance of the task class (with override_instance if found)

        Raises:
            KeyError: If task name is not registered
        """
        # Get base task class
        task_class = cls._tasks.get(name)
        if task_class is None:
            available = list(cls._tasks.keys())
            raise KeyError(f"Task not found: '{name}'. Available: {available}")

        # Check for programmatic override first
        if name in cls._overrides:
            override_class = cls._overrides[name]
            return override_class(context)

        # Check for external file-based override
        override_instance = None
        if load_overrides:
            override_instance = cls.load_override_class(name)

        # Create task with optional override instance
        return task_class(context, override_instance=override_instance)

    @classmethod
    def get_task_class(cls, name: str, use_override: bool = True) -> Type[BaseTask]:
        """
        Get the task class by name.

        Args:
            name: Registered task name
            use_override: If True, return override class if available

        Returns:
            Task class

        Raises:
            KeyError: If task name is not registered
        """
        if use_override and name in cls._overrides:
            return cls._overrides[name]
        if name in cls._tasks:
            return cls._tasks[name]
        available = list(cls._tasks.keys())
        raise KeyError(f"Task not found: '{name}'. Available: {available}")

    @classmethod
    def has_task(cls, name: str) -> bool:
        """Check if a task is registered."""
        return name in cls._tasks

    @classmethod
    def has_override(cls, name: str) -> bool:
        """Check if an override is registered for a task."""
        return name in cls._overrides

    @classmethod
    def list_tasks(cls) -> Dict[str, Dict[str, Any]]:
        """
        List all registered tasks with their override status.

        Returns:
            Dictionary mapping task names to their metadata
        """
        result = {}
        for name, task_class in cls._tasks.items():
            override_class = cls._overrides.get(name)
            result[name] = {
                'class': task_class.__name__,
                'module': task_class.__module__,
                'has_programmatic_override': name in cls._overrides,
                'override_class': override_class.__name__ if override_class else None,
                'has_external_override': name in OverrideLoader._cache
                    and OverrideLoader._cache[name] is not None
            }
        return result

    @classmethod
    def clear(cls) -> None:
        """Clear all registered tasks and overrides."""
        cls._tasks.clear()
        cls._overrides.clear()

    @classmethod
    def clear_overrides(cls) -> None:
        """Clear only overrides, keeping base registrations."""
        cls._overrides.clear()


def create_task_executor(
    task_name: str,
    context: TaskContext,
    override_class: Optional[Type[BaseTask]] = None,
    load_overrides: bool = True,
    override_path: Optional[str] = None
) -> BaseTask:
    """
    Factory function to create a task executor.

    Convenience function that wraps TaskRegistry.create() with
    support for passing an override class directly or loading
    from external/overrides/ directory.

    Args:
        task_name: Registered task name
        context: TaskContext for the task
        override_class: Optional override class to use (highest priority)
        load_overrides: If True, look for external override files (default: True)
        override_path: Optional custom path to overrides directory

    Returns:
        Instance of the task executor

    Example:
        # Basic usage (with external override discovery)
        task = create_task_executor('process_crosswalk', context)

        # Without external overrides
        task = create_task_executor('process_crosswalk', context, load_overrides=False)

        # With inline override class (highest priority)
        task = create_task_executor('process_crosswalk', context,
                                    override_class=MyCustomTask)

        # With custom override path
        task = create_task_executor('process_crosswalk', context,
                                    override_path='/Workspace/.../external/overrides')
    """
    # Set custom override path if provided
    if override_path:
        TaskRegistry.set_override_path(override_path)

    # Inline override class takes highest priority
    if override_class is not None:
        return override_class(context)

    return TaskRegistry.create(task_name, context, load_overrides=load_overrides)


# Task registration decorator
def register_task(name: str) -> Callable[[Type[BaseTask]], Type[BaseTask]]:
    """
    Decorator to register a task class.

    Example:
        @register_task('my_task')
        class MyTask(BaseTask):
            def execute(self) -> TaskResult:
                ...
    """
    def decorator(cls: Type[BaseTask]) -> Type[BaseTask]:
        TaskRegistry.register(name, cls)
        return cls
    return decorator
