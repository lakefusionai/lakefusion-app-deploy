"""
Base Step Task class with interactive step-by-step execution support.

BaseStepTask extends BaseTask to add step-based execution capabilities,
enabling both production (full run) and interactive (step-by-step) modes.

Usage:
    class MyTask(BaseStepTask):
        def __init__(self, context):
            super().__init__(context)
            # Instance variables for intermediate results
            self.df_loaded = None
            self.df_transformed = None

        @step(order=1, name="Load Data")
        def step_load(self):
            self.df_loaded = self.spark.table("source")
            return {"rows": self.df_loaded.count()}

        @step(order=2, name="Transform")
        def step_transform(self):
            self.df_transformed = self.df_loaded.filter(...)
            return {"rows": self.df_transformed.count()}

        def execute(self) -> TaskResult:
            self.step_load()
            self.step_transform()
            return TaskResult.success(...)

Production Mode:
    executor = MyTask(context)
    result = executor.run()  # Runs pre_execute -> execute -> validate -> post_execute

Interactive Mode:
    executor = MyTask(context)
    executor.interactive()
    executor.print_steps()
    executor.pre_execute()  # Setup

    # Run steps individually
    executor.run_step(1)
    print(executor.df_loaded.count())  # Inspect

    executor.run_step(2)
    display(executor.df_transformed)  # Debug in Databricks
"""

from typing import Any, Dict, List, Optional, Tuple

from .base import BaseTask
from .models import TaskContext, TaskResult


class BaseStepTask(BaseTask):
    """
    Base class with interactive step-by-step execution support.

    Extends BaseTask to add:
    - @step decorator support for marking methods as steps
    - Interactive mode for debugging
    - Step execution methods (run_step, execute_from_to_step)
    - Step result caching and retrieval

    Attributes:
        _interactive_mode: Whether interactive mode is enabled
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the step task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._interactive_mode = False

    def interactive(self) -> 'BaseStepTask':
        """
        Enable interactive mode for step-by-step debugging.

        In interactive mode, you can:
        - Run individual steps with run_step(n)
        - Run step ranges with execute_from_to_step(from, to)
        - Inspect intermediate results via instance variables
        - Re-run steps with modified parameters

        Returns:
            self for method chaining

        Example:
            executor.interactive().print_steps()
        """
        self._interactive_mode = True
        print("\n" + "=" * 60)
        print("  INTERACTIVE MODE ENABLED")
        print("=" * 60)
        print("  Use executor.print_steps() to see available steps")
        print("  Use executor.run_step(n) to run a specific step")
        print("  Use executor.execute_from_to_step(from, to) for ranges")
        print("=" * 60)
        return self

    def get_steps(self) -> List[Dict[str, Any]]:
        """
        Get metadata for all registered steps.

        Returns:
            List of step metadata dictionaries, sorted by order.
            Each dict contains: order, name, method_name, returns, completed

        Example:
            steps = executor.get_steps()
            for s in steps:
                print(f"Step {s['order']}: {s['name']}")
        """
        steps = []
        for name in dir(self):
            try:
                method = getattr(self, name)
                if callable(method) and getattr(method, '_is_step', False):
                    step_order = method._step_order
                    steps.append({
                        'order': step_order,
                        'name': method._step_name,
                        'method_name': name,
                        'returns': getattr(method, '_step_returns', None),
                        'completed': self.context.state.get(
                            f'_step_{step_order}_completed', False
                        )
                    })
            except Exception:
                continue
        return sorted(steps, key=lambda x: x['order'])

    def print_steps(self) -> None:
        """
        Pretty print all available steps with their status.

        Shows each step's:
        - Completion status (✓ completed, ○ pending)
        - Step number and name
        - Method name for direct calling
        - Return type description

        Example output:
            Available Steps:
            ------------------------------------------------------------
              ○ Step 1: Load Data
                   Method:  executor.step_load()
                   Returns: DataFrame - raw records
              ✓ Step 2: Transform
                   Method:  executor.step_transform()
                   Returns: DataFrame - transformed records
            ------------------------------------------------------------
        """
        steps = self.get_steps()

        print("\nAvailable Steps:")
        print("-" * 60)

        if not steps:
            print("  No steps defined. Use @step decorator on methods.")
            print("-" * 60)
            return

        for s in steps:
            status = "✓" if s['completed'] else "○"
            print(f"  {status} Step {s['order']}: {s['name']}")
            print(f"       Method:  executor.{s['method_name']}()")
            if s['returns']:
                print(f"       Returns: {s['returns']}")

        print("-" * 60)

    def run_step(self, step_number: int, *args, **kwargs) -> Any:
        """
        Run a specific step by its order number.

        Args:
            step_number: The step order number to execute
            *args: Additional positional arguments to pass to the step
            **kwargs: Additional keyword arguments to pass to the step

        Returns:
            The return value of the step method

        Raises:
            ValueError: If no step exists with the given order number

        Example:
            # Run step 1
            result = executor.run_step(1)

            # Inspect instance variable set by step
            print(executor.df_loaded.count())
        """
        for name in dir(self):
            try:
                method = getattr(self, name)
                if callable(method) and getattr(method, '_is_step', False):
                    if method._step_order == step_number:
                        return method(*args, **kwargs)
            except Exception:
                continue

        raise ValueError(f"No step with order {step_number}")

    def execute_from_to_step(self, from_step: int, to_step: int) -> Tuple:
        """
        Execute a range of steps (inclusive).

        Runs steps sequentially from from_step to to_step.
        Results are returned as a tuple for easy unpacking.

        Args:
            from_step: Starting step number (inclusive)
            to_step: Ending step number (inclusive)

        Returns:
            Tuple of results from each step in the range

        Raises:
            ValueError: If from_step > to_step or range is invalid

        Example:
            # Run steps 2, 3, 4
            r2, r3, r4 = executor.execute_from_to_step(2, 4)

            # Inspect results
            print(f"Step 2 processed {r2['rows']} rows")
        """
        if from_step > to_step:
            raise ValueError(
                f"from_step ({from_step}) must be <= to_step ({to_step})"
            )

        steps = self.get_steps()
        if not steps:
            raise ValueError("No steps defined in this task")

        step_orders = [s['order'] for s in steps]
        min_order = min(step_orders)
        max_order = max(step_orders)

        if from_step < min_order or to_step > max_order:
            raise ValueError(
                f"Step range must be between {min_order} and {max_order}"
            )

        print(f"\n{'=' * 60}")
        print(f"  EXECUTING STEPS {from_step} TO {to_step}")
        print(f"{'=' * 60}")

        results = []

        for s in steps:
            if from_step <= s['order'] <= to_step:
                method = getattr(self, s['method_name'])
                result = method()
                results.append(result)

        print(f"\n{'=' * 60}")
        print(f"  COMPLETED STEPS {from_step} TO {to_step}")
        print(f"{'=' * 60}\n")

        return tuple(results)

    def get_step_result(self, step_number: int) -> Any:
        """
        Get the cached result from a previously executed step.

        Results are automatically cached when steps are executed.
        This method retrieves the cached result without re-executing.

        Args:
            step_number: The step order number

        Returns:
            The cached result, or None if step hasn't been executed

        Example:
            # Run step 1
            executor.run_step(1)

            # Later, get the cached result
            result = executor.get_step_result(1)
        """
        return self.context.state.get(f'_step_{step_number}_result')

    def is_step_completed(self, step_number: int) -> bool:
        """
        Check if a step has been completed.

        Args:
            step_number: The step order number

        Returns:
            True if step has been executed, False otherwise
        """
        return self.context.state.get(f'_step_{step_number}_completed', False)

    def reset_step(self, step_number: int) -> None:
        """
        Reset a step's completion status and cached result.

        Use this to re-run a step with different parameters or
        after fixing an issue.

        Args:
            step_number: The step order number to reset

        Example:
            executor.run_step(2)  # Run step 2
            # Oops, need to change params
            executor.context.params['threshold'] = 50
            executor.reset_step(2)  # Clear cached result
            executor.run_step(2)  # Re-run with new params
        """
        self.context.state.pop(f'_step_{step_number}_result', None)
        self.context.state.pop(f'_step_{step_number}_completed', None)
        print(f"  Reset step {step_number}")

    def reset_from_step(self, step_number: int) -> None:
        """
        Reset all steps from step_number onwards.

        Useful for resuming from a failed step after fixing the issue.

        Args:
            step_number: Starting step number to reset (inclusive)

        Example:
            # Steps 1-3 completed, step 4 failed
            executor.reset_from_step(4)  # Reset 4 and onwards
            # Fix the issue
            executor.execute_from_to_step(4, 6)  # Resume
        """
        steps = self.get_steps()
        for s in steps:
            if s['order'] >= step_number:
                self.reset_step(s['order'])

    def reset_all_steps(self) -> None:
        """
        Reset all steps' completion status and cached results.

        Use this for a clean re-run of the entire task.
        """
        steps = self.get_steps()
        for s in steps:
            self.reset_step(s['order'])
        print("  All steps reset")

    def get_completed_steps(self) -> List[int]:
        """
        Get list of completed step numbers.

        Returns:
            List of step order numbers that have been completed
        """
        steps = self.get_steps()
        return [s['order'] for s in steps if s['completed']]

    def get_pending_steps(self) -> List[int]:
        """
        Get list of pending (not yet completed) step numbers.

        Returns:
            List of step order numbers that haven't been executed
        """
        steps = self.get_steps()
        return [s['order'] for s in steps if not s['completed']]

    def print_status(self) -> None:
        """
        Print current execution status summary.

        Shows completed vs pending steps and any cached results.
        """
        steps = self.get_steps()
        completed = self.get_completed_steps()
        pending = self.get_pending_steps()

        print("\n" + "=" * 60)
        print("  EXECUTION STATUS")
        print("=" * 60)
        print(f"  Total steps: {len(steps)}")
        print(f"  Completed:   {len(completed)} {completed}")
        print(f"  Pending:     {len(pending)} {pending}")

        if completed:
            print("\n  Cached Results:")
            for step_num in completed:
                result = self.get_step_result(step_num)
                result_type = type(result).__name__
                # Truncate long results
                result_str = str(result)
                if len(result_str) > 50:
                    result_str = result_str[:50] + "..."
                print(f"    Step {step_num}: {result_type} = {result_str}")

        print("=" * 60)
