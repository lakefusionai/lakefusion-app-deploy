"""
Executor tasks module.

Contains concrete task implementations for pipeline operations.
Tasks are organized in submodules mirroring the notebook folder structure.

Usage:
------
    # Import specific task classes
    from lakefusion_core_engine.executors.tasks.integration_core.normal_deduplication import VectorSearchExecutor

    # Or access via submodules
    from lakefusion_core_engine.executors import tasks
    executor_class = tasks.integration_core.normal_deduplication.VectorSearchExecutor
"""

# Import submodules to make them accessible via dot notation
from . import integration_core
from . import maven_core
from . import dnb_integration
from . import schema_evolution

# Re-export task classes for backward compatibility
# Note: Prefer qualified imports to avoid naming conflicts
from .integration_core.process_crosswalk import ProcessCrosswalkTask
from .integration_core.check_master_exists import CheckMasterExistsExecutor
from .integration_core.endpoints_mapping import EndpointsMappingExecutor
from .integration_core.entity_job_status import EntityJobStatusExecutor
from .integration_core.manual_update import ManualUpdateExecutor
from .integration_core.parse_entity_model_json import ParseEntityModelJsonExecutor
from .integration_core.normal_deduplication.entity_matching_vector_search import VectorSearchExecutor
from .integration_core.normal_deduplication.entity_matching_llm import LLMMatchingExecutor
from .integration_core.normal_deduplication.manual_merge import ManualMergeExecutor
from .integration_core.normal_deduplication.manual_not_match import ManualNotMatchExecutor
from .integration_core.normal_deduplication.manual_unmerge import ManualUnmergeExecutor
from .integration_core.normal_deduplication.process_deterministic import ProcessDeterministicExecutor
from .integration_core.normal_deduplication.process_auto_merge import ProcessAutoMergeExecutor
from .integration_core.normal_deduplication.process_potential_match import ProcessPotentialMatchExecutor
from .integration_core.normal_deduplication.process_unmatched_records import ProcessUnmatchedRecordsExecutor
from .integration_core.normal_deduplication.update_table_metadata import UpdateTableMetadataExecutor

# Maven Core task exports
from .maven_core.embedding_foundational import EmbeddingFoundationalExecutor
from .maven_core.embedding_hugging_face import EmbeddingHuggingFaceExecutor
from .maven_core.llm_foundational import LLMFoundationalExecutor
from .maven_core.llm_hugging_face import LLMHuggingFaceExecutor
from .maven_core.endpoints_mapping import MavenEndpointsMappingExecutor
from .maven_core.resource_tagging import ResourceTaggingExecutor
from .maven_core.send_email_notification import SendEmailNotificationExecutor
from .maven_core.process_warning_records import ProcessWarningRecordsExecutor

# D&B Integration task exports
from .dnb_integration.dnb_match_monitoring import DNBMatchMonitoringExecutor
from .dnb_integration.dnb_manual_merge import DNBManualMergeExecutor

# Schema Evolution task exports
from .schema_evolution.parse_schema_evolution_json import ParseSchemaEvolutionJsonExecutor
from .schema_evolution.alter_tables import AlterTablesExecutor
from .schema_evolution.backfill_from_sources import BackfillFromSourcesExecutor
from .schema_evolution.sync_derived_tables import SyncDerivedTablesExecutor
from .schema_evolution.update_match_config import UpdateMatchConfigExecutor
from .schema_evolution.validate_schema_evolution import ValidateSchemaEvolutionExecutor
from .schema_evolution.rollback_schema_evolution import RollbackSchemaEvolutionExecutor

__all__ = [
    # Submodules (recommended access pattern)
    'integration_core',
    'maven_core',
    'dnb_integration',
    # Direct task classes (backward compatibility)
    'ProcessCrosswalkTask',
    'CheckMasterExistsExecutor',
    'EndpointsMappingExecutor',
    'EntityJobStatusExecutor',
    'ManualUpdateExecutor',
    'ParseEntityModelJsonExecutor',
    'VectorSearchExecutor',
    'LLMMatchingExecutor',
    'LLMMatchingDeterministicExecutor',
    'ManualMergeExecutor',
    'ManualNotMatchExecutor',
    'ManualUnmergeExecutor',
    'ProcessDeterministicExecutor',
    'ProcessAutoMergeExecutor',
    'ProcessPotentialMatchExecutor',
    'ProcessUnmatchedRecordsExecutor',
    'UpdateTableMetadataExecutor',
    # Maven Core tasks
    'EmbeddingFoundationalExecutor',
    'EmbeddingHuggingFaceExecutor',
    'LLMFoundationalExecutor',
    'LLMHuggingFaceExecutor',
    'MavenEndpointsMappingExecutor',
    'ResourceTaggingExecutor',
    'SendEmailNotificationExecutor',
    'ProcessWarningRecordsExecutor',
    # D&B Integration tasks
    'DNBMatchMonitoringExecutor',
    'DNBManualMergeExecutor',
    # Schema Evolution tasks
    'schema_evolution',
    'ParseSchemaEvolutionJsonExecutor',
    'AlterTablesExecutor',
    'BackfillFromSourcesExecutor',
    'SyncDerivedTablesExecutor',
    'UpdateMatchConfigExecutor',
    'ValidateSchemaEvolutionExecutor',
    'RollbackSchemaEvolutionExecutor',
]
