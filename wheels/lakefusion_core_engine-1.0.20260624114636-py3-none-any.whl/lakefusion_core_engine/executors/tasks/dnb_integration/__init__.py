"""
D&B Integration tasks module.

Contains task executors for Dun & Bradstreet integration operations:
    - DNBMatchMonitoringExecutor - Company match and monitoring accelerator
    - DNBManualMergeExecutor - Manual merge of D&B matches

Usage:
------
    from lakefusion_core_engine.executors.tasks.dnb_integration import DNBMatchMonitoringExecutor
    executor = DNBMatchMonitoringExecutor(context)

    from lakefusion_core_engine.executors.tasks.dnb_integration import DNBManualMergeExecutor
    executor = DNBManualMergeExecutor(context)
"""

from .dnb_match_monitoring import DNBMatchMonitoringExecutor
from .dnb_manual_merge import DNBManualMergeExecutor

__all__ = [
    'DNBMatchMonitoringExecutor',
    'DNBManualMergeExecutor',
]
