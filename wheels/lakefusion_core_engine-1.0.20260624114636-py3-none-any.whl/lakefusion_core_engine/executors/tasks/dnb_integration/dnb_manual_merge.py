"""
D&B Manual Merge Executor for D&B integration.

Allows manual selection and merging of D&B match results when
automatic merge is not possible due to multiple high-confidence matches.

Workflow:
1. Update merge_status in dnb_duns table
2. Optionally add selected D-U-N-S to monitoring
3. Verify the update
"""

import json
import base64
import requests
from typing import Any, Dict, Optional

from pyspark.sql import DataFrame

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class DbApiClient:
    """Minimal D&B API Client for monitoring operations."""

    def __init__(self, key: str, secret: str):
        self.key = key
        self.secret = secret
        self.api_auth_url = "https://plus.dnb.com/v2/token"
        self.api_url = "https://plus.dnb.com/v1"
        self.session_token = None

        try:
            auth_token = base64.b64encode(f"{key}:{secret}".encode("ascii")).decode("ascii")
            payload = {"grant_type": "client_credentials"}
            headers = {"Authorization": f"Basic {auth_token}"}
            response = requests.request("POST", self.api_auth_url, headers=headers, json=payload)
            self.session_token = response.json()['access_token']
            print('Successfully authenticated to the D&B API.')
        except Exception as error:
            print('Authentication Error:\nWe could not authenticate to the D&B API. Please check your credentials.')
            raise

    def add_to_monitoring(self, input_df: DataFrame, registration_id: str) -> Dict:
        """Add D-U-N-S numbers to monitoring registration."""
        already_registered_count = 0
        successfully_added_count = 0

        for row in input_df.collect():
            duns = row["dnb_duns"]
            endpoint = f"{self.api_url}/monitoring/registrations/{registration_id}/duns/{duns}"
            headers = {"Authorization": f"Bearer {self.session_token}"}

            response = requests.request("POST", endpoint, headers=headers)
            json_resp = response.json()

            if 'error' in json_resp and json_resp['error'].get('errorCode') == '21012':
                already_registered_count += 1
            elif 'information' in json_resp and json_resp['information'].get('code') == '21113':
                successfully_added_count += 1

        message = (
            f"Processed {already_registered_count + successfully_added_count} records.\n"
            f"{already_registered_count} were already registered.\n"
            f"{successfully_added_count} were successfully added to monitoring."
        )
        print(message)

        return {
            'already_registered': already_registered_count,
            'successfully_added': successfully_added_count
        }


class DNBManualMergeExecutor(BaseStepTask):
    """
    Executor for manual D&B merge operations.

    Allows users to manually select and merge D&B match results
    when automatic merge is not possible.
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        super().__init__(context, override_instance=override_instance)
        self.entity_name = context.params.get('entity_name', context.entity)
        self.id_value = context.params.get('id_value', '')
        self.dnb_duns_value = context.params.get('dnb_duns_value', '')
        self.api_key = context.params.get('api_key', '')
        self.api_secret = context.params.get('api_secret', '')
        self.registration_id = context.params.get('registration_id', None)
        self.add_to_monitoring_flag = context.params.get('add_to_monitoring', False)

        # Instance variables for intermediate results
        self._update_result: Dict = None
        self._monitoring_result: Dict = None
        self._verify_df: DataFrame = None

    @property
    def master_table(self) -> str:
        """Get the master table name."""
        return f"{self.context.catalog_name}.gold.{self.entity_name}_master_prod"

    @property
    def dnb_duns_table(self) -> str:
        """Get the DNB DUNS table name."""
        return f"{self.master_table}_dnb_duns"

    def pre_execute(self) -> None:
        """Validate inputs and display configuration."""
        print("="*80)
        print("D&B MANUAL MERGE")
        print("="*80)
        print(f"Entity: {self.entity_name}")
        print(f"Catalog: {self.context.catalog_name}")
        print(f"ID Value: {self.id_value}")
        print(f"D-U-N-S Value: {self.dnb_duns_value}")
        print(f"Master DNB Table: {self.dnb_duns_table}")
        print("="*80)

        if not self.id_value:
            raise ValueError("id_value is required for manual merge")
        if not self.dnb_duns_value:
            raise ValueError("dnb_duns_value is required for manual merge")

    @step(order=1, name="Update Merge Status", returns="update result with affected rows")
    def step_update_merge_status(self) -> Dict[str, Any]:
        """Update the merge_status in DNB DUNS table for the selected record."""
        spark = self.context.spark

        # Update the selected record to MANUAL_MERGE and others to NOT_APPLICABLE
        update_query = f"""
            UPDATE {self.dnb_duns_table}
            SET merge_status = CASE
                WHEN dnb_duns = '{self.dnb_duns_value}' THEN 'MANUAL_MERGE'
                ELSE 'NOT_APPLICABLE'
            END
            WHERE lakefusion_id = '{self.id_value}'
        """

        spark.sql(update_query)
        print(f"Updated merge_status for lakefusion_id: {self.id_value}")
        print(f"Selected D-U-N-S: {self.dnb_duns_value} -> MANUAL_MERGE")
        print(f"Other matches -> NOT_APPLICABLE")

        self._update_result = {
            'id_value': self.id_value,
            'dnb_duns_value': self.dnb_duns_value,
            'status_updated': True
        }

        return self._update_result

    @step(order=2, name="Add to Monitoring (Optional)", returns="monitoring registration result")
    def step_add_to_monitoring(self) -> Dict[str, Any]:
        """Add selected D-U-N-S to monitoring if requested."""
        spark = self.context.spark

        if not self.add_to_monitoring_flag or not self.registration_id:
            print("Skipping monitoring registration")
            return {'skipped': True, 'reason': 'add_to_monitoring_flag or registration_id not set'}

        if not self.api_key or not self.api_secret:
            print("Warning: API credentials not provided, skipping monitoring")
            return {'skipped': True, 'reason': 'API credentials not provided'}

        try:
            dnb_api = DbApiClient(self.api_key, self.api_secret)

            # Get the selected record
            input_df = spark.sql(f"""
                SELECT * FROM {self.dnb_duns_table}
                WHERE dnb_duns = '{self.dnb_duns_value}'
            """)

            self._monitoring_result = dnb_api.add_to_monitoring(input_df, self.registration_id)
            print(f"Added {self._monitoring_result['successfully_added']} record(s) to monitoring")

            return {
                'skipped': False,
                'successfully_added': self._monitoring_result['successfully_added'],
                'already_registered': self._monitoring_result['already_registered']
            }
        except Exception as e:
            print(f"Warning: Failed to add to monitoring: {str(e)}")
            return {'skipped': True, 'reason': f'Error: {str(e)}'}

    @step(order=3, name="Verify Update", returns="DataFrame with updated records")
    def step_verify_update(self) -> Dict[str, Any]:
        """Verify the update was successful by querying the table."""
        spark = self.context.spark

        self._verify_df = spark.sql(f"""
            SELECT lakefusion_id, dnb_duns, dnb_name, dnb_confidenceCode, merge_status
            FROM {self.dnb_duns_table}
            WHERE lakefusion_id = '{self.id_value}'
        """)

        print("Updated records:")
        self._verify_df.show(truncate=False)

        record_count = self._verify_df.count()
        manual_merge_count = self._verify_df.filter("merge_status = 'MANUAL_MERGE'").count()

        return {
            'total_records': record_count,
            'manual_merge_count': manual_merge_count,
            'verification_complete': True
        }

    def execute(self) -> TaskResult:
        """Execute the manual merge workflow."""
        # Step 1: Update merge status
        self.step_update_merge_status()

        # Step 2: Add to monitoring (optional)
        self.step_add_to_monitoring()

        # Step 3: Verify update
        self.step_verify_update()

        return TaskResult.success(
            message=f"Manual merge completed for {self.id_value}",
            task_name=self.context.task_name,
            metrics={
                'id_value': self.id_value,
                'dnb_duns_value': self.dnb_duns_value,
                'merge_status': 'MANUAL_MERGE'
            },
            task_values={
                'manual_merge_complete': True,
                'id_value': self.id_value,
                'dnb_duns_value': self.dnb_duns_value
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message=f"Manual merge completed for {self.id_value}",
            actual=self.dnb_duns_value
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        print("\n" + "="*80)
        print("D&B MANUAL MERGE COMPLETE")
        print("="*80)
        print(f"Input Source ID: {self.id_value}")
        print(f"Selected D-U-N-S: {self.dnb_duns_value}")
        print(f"Merge Status: MANUAL_MERGE")
        print("="*80)

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        print(f"Manual merge failed: {result.message}")
        if result.errors:
            for error in result.errors:
                print(f"  Error: {error}")
