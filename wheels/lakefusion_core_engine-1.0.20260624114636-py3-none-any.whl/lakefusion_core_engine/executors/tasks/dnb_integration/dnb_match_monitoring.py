"""
D&B Match and Monitoring Executor for D&B integration.

Integrates with Dun & Bradstreet Company Match API to match company data
and register for monitoring updates.

Workflow:
1. Read master table and apply attribute mapping (incremental - skip already processed)
2. Authenticate to D&B API
3. Match records using distributed mapInPandas (throttled to ~4 TPS)
4. Handle HTTP 401/429+00050 errors gracefully (save what we have, then exit)
5. Process and score match results (AUTO_MERGED, IN_REVIEW, NOT_A_MATCH)
6. Persist results to silver table, then MERGE INTO gold table (dedup on lakefusion_id + dnb_duns)
7. Write errors to separate error table
8. Optionally enrich with hierarchy data
"""

import json
import base64
import urllib
import time
import requests
import pandas as pd
from datetime import date, datetime
from typing import Any, Dict, List, Optional, Iterator

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, BooleanType, DateType,
    DoubleType, LongType, ArrayType, MapType, TimestampType
)

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class DbApi:
    """D&B API Client class for authentication and API calls."""

    DEFAULT_MIN_CONFIDENCE = 8
    threshold = 9

    # Schema includes lakefusion_id for incremental processing and deduplication
    schema = StructType([
        StructField('lakefusion_id', StringType(), True),
        StructField('update_date', DateType(), True),
        StructField('accepted', BooleanType(), True),
        StructField('input_source_id', StringType(), True),
        StructField('input_name', StringType(), True),
        StructField('input_streetaddress', StringType(), True),
        StructField('input_city', StringType(), True),
        StructField('input_country', StringType(), True),
        StructField('input_state', StringType(), True),
        StructField('input_postal_code', StringType(), True),
        StructField('dnb_duns', StringType(), True),
        StructField('dnb_name', StringType(), True),
        StructField('dnb_nameMatchScore', DoubleType(), True),
        StructField('dnb_status', StringType(), True),
        StructField('dnb_streetaddress', StringType(), True),
        StructField('dnb_city', StringType(), True),
        StructField('dnb_country', StringType(), True),
        StructField('dnb_state', StringType(), True),
        StructField('dnb_postal_code', StringType(), True),
        StructField('dnb_confidenceCode', LongType(), True),
        StructField('dnb_matchDataProfileComponents', ArrayType(MapType(StringType(), StringType(), True), True), True),
        StructField('dnb_matchgradeComponents', ArrayType(MapType(StringType(), StringType(), True), True), True)
    ])

    # Schema for hierarchy enrichment
    enrichment_schema = StructType([
        StructField("lakefusion_id", StringType(), True),
        StructField("dnb_duns", StringType(), True),
        StructField("enrichment_type", StringType(), True),
        StructField("enrichment_data", StringType(), True),
        StructField("enriched_at", TimestampType(), True),
    ])

    def __init__(self, key: str, secret: str, spark):
        self.key = key
        self.secret = secret
        self.spark = spark
        self.api_auth_url = "https://plus.dnb.com/v2/token"
        self.api_url = "https://plus.dnb.com/v1"
        self.auth_token = self._define_auth_token()
        self.matched_records = None
        self.session_token = None

        try:
            self.session_token = self._auth_proc()['access_token']
            print('Successfully authenticated to the D&B API.')
        except Exception as error:
            print('Authentication Error:\nWe could not authenticate to the D&B API. Please check your credentials.')
            raise

    def _define_auth_token(self) -> str:
        """Generate base64 encoded authentication token."""
        key_sec = f"{self.key}:{self.secret}"
        encoded_creds = base64.b64encode(str(key_sec).encode("ascii")).decode("ascii")
        return encoded_creds

    def _auth_proc(self) -> Dict:
        """Create session token for API calls."""
        payload = {"grant_type": "client_credentials"}
        headers = {
            "Authorization": f"Basic {self.auth_token}",
        }
        response = requests.request("POST", self.api_auth_url, headers=headers, json=payload)
        return response.json()

    def match_d_and_b(self, record: Dict, candidate_max_quantity: int = 3) -> Dict:
        """Execute D&B Match API call for a single record."""
        endpoint = f"{self.api_url}/match/cleanseMatch?"
        params = {
            "candidateMaximumQuantity": candidate_max_quantity,
            "name": record["name"],
            "streetAddressLine1": record["streetaddress"],
            "street&addressLocality": record["city"],
            "addressRegion": record["state"],
            "postalCode": record["postal_code"],
            "countryISOAlpha2Code": record["country"],
        }

        headers = {
            "Authorization": f"Bearer {self.session_token}",
        }
        params_encoded = urllib.parse.urlencode(params)
        url = endpoint + params_encoded

        response = requests.request("GET", url, headers=headers, data={})
        return response.json()

    def match_and_cleanse(
        self,
        input_df: DataFrame,
        minimum_confidence: int = DEFAULT_MIN_CONFIDENCE,
        candidate_max_quantity: int = 3
    ) -> DataFrame:
        """
        Process all records through D&B Match API.

        Returns DataFrame with match results including accepted flag based on confidence.
        """
        if minimum_confidence > 10:
            raise ValueError("The minimum confidence needs to be a number between 1 and 10")

        matched_records_list = []
        data_collect = input_df.collect()

        for row in data_collect:
            results = self.match_d_and_b(row, candidate_max_quantity)
            print(results)

            match_candidates = results.get("matchCandidates")
            if match_candidates:
                for match in match_candidates:
                    t = match["organization"]
                    accepted = match["matchQualityInformation"]["confidenceCode"] >= minimum_confidence

                    matched_cos = {
                        "update_date": date.today(),
                        "input_source_id": row["source_id"],
                        "input_name": row["name"],
                        "input_streetaddress": row["streetaddress"],
                        "input_city": row["city"],
                        "input_country": row["country"],
                        "input_postal_code": row["postal_code"],
                        "input_state": row["state"],
                        "dnb_duns": t["duns"],
                        "dnb_name": t["primaryName"],
                        "dnb_streetaddress": t["primaryAddress"]["streetAddress"].get("line1", None),
                        "dnb_city": t["primaryAddress"]["addressLocality"].get("name", None),
                        "dnb_country": t["primaryAddress"]["addressCountry"].get("isoAlpha2Code", None),
                        "dnb_state": t["primaryAddress"]["addressRegion"].get("abbreviatedName", None),
                        "dnb_postal_code": t["primaryAddress"]["postalCode"],
                        "dnb_status": t["dunsControlStatus"]["operatingStatus"]["description"],
                        "dnb_confidenceCode": match["matchQualityInformation"]["confidenceCode"],
                        "accepted": accepted,
                        "dnb_nameMatchScore": match["matchQualityInformation"]["nameMatchScore"],
                        "dnb_matchgradeComponents": match["matchQualityInformation"]["matchGradeComponents"],
                        "dnb_matchDataProfileComponents": match["matchQualityInformation"]["matchDataProfileComponents"],
                    }
                    matched_records_list.append(matched_cos)
            else:
                print("No matchCandidates found for:", row)

        self.matched_records = self.spark.createDataFrame(matched_records_list, schema=self.schema)

        print(f"All records have been processed.\nThe result set is {len(matched_records_list)} records")
        return self.matched_records

    def add_to_monitoring(self, input_df: DataFrame, registration_id: str) -> Dict:
        """Add D-U-N-S numbers to monitoring registration."""
        already_registered_count = 0
        successfully_added_count = 0

        for row in input_df.collect():
            duns = row["dnb_duns"]
            endpoint = f"{self.api_url}/monitoring/registrations/{registration_id}/duns/{duns}"
            headers = {"Authorization": f"Bearer {self.session_token}"}

            response = requests.request("POST", endpoint, headers=headers)
            json_resp = response.json()

            if 'error' in json_resp and json_resp['error'].get('errorCode') == '21012':
                already_registered_count += 1
            elif 'information' in json_resp and json_resp['information'].get('code') == '21113':
                successfully_added_count += 1

        message = (
            f"Processed {already_registered_count + successfully_added_count} records.\n"
            f"{already_registered_count} were already registered.\n"
            f"{successfully_added_count} were successfully added to monitoring."
        )
        print(message)

        return {
            'already_registered': already_registered_count,
            'successfully_added': successfully_added_count
        }

    def delete_from_monitoring(self, input_df: DataFrame, registration_id: str) -> None:
        """Remove D-U-N-S numbers from monitoring registration."""
        for row in input_df.collect():
            duns = row["dnb_duns"]
            endpoint = f"{self.api_url}/monitoring/registrations/{registration_id}/duns/{duns}"
            headers = {"Authorization": f"Bearer {self.session_token}"}
            requests.request("DELETE", endpoint, headers=headers)

    def export_monitoring_registrations(self, registration_id: str) -> Dict:
        """Export monitoring registrations to trigger DUNS table population."""
        endpoint = f"{self.api_url}/monitoring/registrations/{registration_id}/subjects"
        headers = {"Authorization": f"Bearer {self.session_token}"}
        response = requests.request("GET", endpoint, headers=headers)
        return response.json()


class DNBMatchMonitoringExecutor(BaseStepTask):
    """
    Executor for D&B Company Match and Monitoring.

    Matches company records against D&B database and registers
    for monitoring updates.

    Features:
    - Incremental processing (skips already processed records)
    - Distributed API calls via mapInPandas (throttled to ~4 TPS)
    - Graceful handling of HTTP 401/429+00050 errors
    - MERGE INTO for deduplication on lakefusion_id + dnb_duns
    - Silver table for intermediate results
    - Error table for failed API calls
    - Optional hierarchy enrichment
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        super().__init__(context, override_instance=override_instance)
        self.entity_dnb_settings = context.params.get('entity_dnb_settings', {})
        self.api_key = context.params.get('api_key', '')
        self.api_secret = context.params.get('api_secret', '')
        self.limit_records = context.params.get('limit_records', None)  # None = process all
        self.registration_id = context.params.get('registration_id', None)
        self.matched_count = 0
        self.auto_merged_count = 0

        # Parse entity_dnb_settings if it's a string
        if isinstance(self.entity_dnb_settings, str):
            self.entity_dnb_settings = json.loads(self.entity_dnb_settings)

        # Instance variables for intermediate results
        self._df_master: DataFrame = None
        self._df_master_new: DataFrame = None  # Only unprocessed records
        self._dnb_api: DbApi = None
        self._matched_records: DataFrame = None
        self._df_merge_score: DataFrame = None
        self._in_review_count: int = 0
        self._not_a_match_count: int = 0
        self._monitoring_result: Dict = None
        self._session_token: str = None
        self._error_count: int = 0
        self._match_api_blocked: bool = False
        self._match_auth_failed: bool = False
        self._match_quota_exhausted: bool = False
        self._dnb_table_exists: bool = False

    @property
    def attributes_mapping(self) -> Dict:
        """Get attribute mapping from DNB settings."""
        return self.entity_dnb_settings.get("attributesmapping", {})

    @property
    def threshold(self) -> int:
        """Get threshold from DNB settings."""
        return self.entity_dnb_settings.get("threshold", 9)

    @property
    def minimum_confidence(self) -> int:
        """Get minimum confidence from DNB settings."""
        return self.entity_dnb_settings.get("minimumconfidence", 7)

    @property
    def candidate_max_quantity(self) -> int:
        """Get candidate maximum quantity from DNB settings."""
        return self.entity_dnb_settings.get("candidatemaximumquantity", 3)

    @property
    def enrichment_policies(self) -> Dict:
        """Get enrichment policies from DNB settings."""
        return self.entity_dnb_settings.get("enrichment_policies", {})

    @property
    def hierarchy_enabled(self) -> bool:
        """Check if hierarchy enrichment is enabled."""
        return self.enrichment_policies.get("hierarchy", {}).get("enabled", False)

    @property
    def source_id_column(self) -> str:
        """Get the source_id column name from mapping or default to lakefusion_id."""
        return self.attributes_mapping.get("source_id") or "lakefusion_id"

    @property
    def id_key(self) -> str:
        """Primary key for incremental processing."""
        return "lakefusion_id"

    @property
    def master_table(self) -> str:
        """Get the master table name."""
        return f"{self.context.catalog_name}.gold.{self.context.entity}_master_prod"

    @property
    def dnb_duns_table(self) -> str:
        """Get the DNB DUNS table name (gold layer)."""
        return f"{self.master_table}_dnb_duns"

    @property
    def dnb_silver_table(self) -> str:
        """Get the DNB silver table name (intermediate results)."""
        return f"{self.context.catalog_name}.silver.{self.context.entity}_master_prod_dnb_results"

    @property
    def dnb_error_table(self) -> str:
        """Get the DNB error table name."""
        return f"{self.context.catalog_name}.gold.{self.context.entity}_master_prod_dnb_duns_error"

    @property
    def dnb_enrichment_table(self) -> str:
        """Get the DNB enrichment table name."""
        return f"{self.context.catalog_name}.gold.{self.context.entity}_master_prod_dnb_enrichment"

    @property
    def dnb_enrichment_silver_table(self) -> str:
        """Get the DNB enrichment silver table name."""
        return f"{self.context.catalog_name}.silver.{self.context.entity}_master_prod_dnb_enrichment_results"

    @property
    def dnb_enrichment_error_table(self) -> str:
        """Get the DNB enrichment error table name."""
        return f"{self.context.catalog_name}.gold.{self.context.entity}_master_prod_dnb_enrichment_error"

    def pre_execute(self) -> None:
        """Validate inputs and display configuration."""
        print("="*80)
        print("D&B MATCH AND MONITORING ACCELERATOR (SDK v4.2.0)")
        print("="*80)
        print(f"Entity: {self.context.entity}")
        print(f"Catalog: {self.context.catalog_name}")
        print("-"*80)
        print("TABLE CONFIGURATION:")
        print(f"  Master Table: {self.master_table}")
        print(f"  DNB DUNS Table (gold): {self.dnb_duns_table}")
        print(f"  DNB Silver Table: {self.dnb_silver_table}")
        print(f"  DNB Error Table: {self.dnb_error_table}")
        if self.hierarchy_enabled:
            print(f"  DNB Enrichment Table: {self.dnb_enrichment_table}")
        print("-"*80)
        print("MATCHING CONFIGURATION:")
        print(f"  Threshold: {self.threshold}")
        print(f"  Minimum Confidence: {self.minimum_confidence}")
        print(f"  Candidate Max Quantity: {self.candidate_max_quantity}")
        print(f"  Limit Records: {self.limit_records if self.limit_records else 'All'}")
        print("-"*80)
        print("FEATURES:")
        print(f"  Incremental Processing: Enabled")
        print(f"  Distributed API Calls: mapInPandas (2 partitions, ~4 TPS)")
        print(f"  Error Handling: HTTP 401/429+00050 with graceful exit")
        print(f"  Deduplication: MERGE INTO on lakefusion_id + dnb_duns")
        print(f"  Hierarchy Enrichment: {'Enabled' if self.hierarchy_enabled else 'Disabled'}")
        print("="*80)

    @step(order=1, name="Read and Transform Master Data", returns="DataFrame - transformed master records")
    def step_read_and_transform_master_data(self) -> Dict[str, Any]:
        """Read master table and apply attribute mapping. Filters to unprocessed records only."""
        spark = self.context.spark

        df_master_full = spark.read.table(self.master_table)
        total_count = df_master_full.count()
        print(f"Read {total_count} total records from master table")

        # Check if _dnb_duns table already exists for incremental processing
        self._dnb_table_exists = spark.catalog.tableExists(self.dnb_duns_table)

        if self._dnb_table_exists:
            df_existing = spark.read.table(self.dnb_duns_table)
            # Skip lakefusion_ids that have at least one active DUNS candidate
            # (ACCEPTED, AUTO_MERGED, MANUAL_MERGE, or IN_REVIEW)
            active_ids = df_existing.filter(
                F.col("merge_status").isin("ACCEPTED", "AUTO_MERGED", "MANUAL_MERGE", "IN_REVIEW")
            ).select(self.id_key).distinct()
            self._df_master_new = df_master_full.join(
                active_ids,
                on=self.id_key,
                how="left_anti"
            )
            new_count = self._df_master_new.count()
            print(f"Found {new_count} new records out of {total_count} total master records to process")
        else:
            self._df_master_new = df_master_full
            print(f"Table {self.dnb_duns_table} does not exist — processing all {total_count} master records")

        # Apply attribute mapping
        updated_data = {k: (None if v == "__none__" else v) for k, v in self.attributes_mapping.items()}

        columns_expr = [
            F.col(v).alias(k) if v is not None else F.lit("US").alias(k)
            for k, v in updated_data.items()
        ]

        # Ensure source_id column is present for D&B result tracking
        if "source_id" not in updated_data:
            columns_expr.append(F.col(self.source_id_column).cast("string").alias("source_id"))

        # Always include lakefusion_id for incremental tracking
        columns_expr.append(F.col(self.id_key).cast("string").alias(self.id_key))

        # Apply to DataFrame — use only new/unprocessed records
        self._df_master = self._df_master_new.select(*columns_expr)

        # Apply limit if specified (useful for testing)
        if self.limit_records is not None:
            self._df_master = self._df_master.limit(self.limit_records)
            print(f"Limited to {self.limit_records} records for processing")

        final_count = self._df_master.count()
        print(f"Applied attribute mapping. Final record count: {final_count}")
        print(f"Columns: {self._df_master.columns}")

        return {'total_records': total_count, 'records_to_process': final_count, 'columns': self._df_master.columns}

    def _create_match_partition_func(self, session_token: str, min_confidence: int, candidate_max_qty: int):
        """Create the mapInPandas partition function with closure variables."""

        def match_partition(pdf_iterator: Iterator[pd.DataFrame]) -> Iterator[pd.DataFrame]:
            """Process each partition against D&B CleanseMatch API.
            Throttled to ~2 TPS per partition (2 partitions = ~4 TPS total, under 5 TPS D&B limit).

            HTTP 401 and 429+00050 errors are captured as special error rows to ensure
            all successful API calls are persisted before the notebook exits gracefully.
            """
            _api_url = "https://plus.dnb.com/v1"

            for pdf in pdf_iterator:
                rows = []
                stop_processing = False  # Flag to stop processing after quota/auth failure

                for _, record in pdf.iterrows():
                    # If we hit a fatal error (quota/auth), skip remaining records
                    if stop_processing:
                        break

                    endpoint = f"{_api_url}/match/cleanseMatch?"
                    params = {
                        "confidenceLowerLevelThresholdValue": min_confidence,
                        "candidateMaximumQuantity": candidate_max_qty,
                        "name": str(record.get("name", "")),
                        "streetAddressLine1": str(record.get("streetaddress", "")),
                        "addressLocality": str(record.get("city", "")),
                        "addressRegion": str(record.get("state", "")),
                        "postalCode": str(record.get("postal_code", "")),
                        "countryISOAlpha2Code": str(record.get("country", "")),
                    }
                    headers = {"Authorization": f"Bearer {session_token}"}
                    url = endpoint + urllib.parse.urlencode(params)

                    try:
                        resp = requests.get(url, headers=headers, timeout=30)

                        # --- Check 1: Non-200 HTTP status ---
                        if resp.status_code != 200:
                            # HTTP 401: Authentication failed - stop processing
                            if resp.status_code == 401:
                                rows.append({
                                    "lakefusion_id": str(record.get("lakefusion_id", "")),
                                    "update_date": date.today(),
                                    "accepted": False,
                                    "input_source_id": str(record.get("source_id", "")),
                                    "input_name": str(record.get("name", "")),
                                    "input_streetaddress": str(record.get("streetaddress", "")),
                                    "input_city": str(record.get("city", "")),
                                    "input_country": str(record.get("country", "")),
                                    "input_state": str(record.get("state", "")),
                                    "input_postal_code": str(record.get("postal_code", "")),
                                    "dnb_duns": None,
                                    "dnb_name": None,
                                    "dnb_nameMatchScore": None,
                                    "dnb_status": "AUTH_FAILED:401|Token invalid or expired",
                                    "dnb_streetaddress": None,
                                    "dnb_city": None,
                                    "dnb_country": None,
                                    "dnb_state": None,
                                    "dnb_postal_code": None,
                                    "dnb_confidenceCode": None,
                                    "dnb_matchDataProfileComponents": None,
                                    "dnb_matchgradeComponents": None,
                                })
                                stop_processing = True
                                continue

                            # HTTP 429: Check if quota error (00050)
                            if resp.status_code == 429:
                                try:
                                    body = resp.json()
                                    if body.get("error", {}).get("errorCode") == "00050":
                                        rows.append({
                                            "lakefusion_id": str(record.get("lakefusion_id", "")),
                                            "update_date": date.today(),
                                            "accepted": False,
                                            "input_source_id": str(record.get("source_id", "")),
                                            "input_name": str(record.get("name", "")),
                                            "input_streetaddress": str(record.get("streetaddress", "")),
                                            "input_city": str(record.get("city", "")),
                                            "input_country": str(record.get("country", "")),
                                            "input_state": str(record.get("state", "")),
                                            "input_postal_code": str(record.get("postal_code", "")),
                                            "dnb_duns": None,
                                            "dnb_name": None,
                                            "dnb_nameMatchScore": None,
                                            "dnb_status": f"QUOTA_EXHAUSTED:00050|{body['error'].get('errorMessage', '')}",
                                            "dnb_streetaddress": None,
                                            "dnb_city": None,
                                            "dnb_country": None,
                                            "dnb_state": None,
                                            "dnb_postal_code": None,
                                            "dnb_confidenceCode": None,
                                            "dnb_matchDataProfileComponents": None,
                                            "dnb_matchgradeComponents": None,
                                        })
                                        stop_processing = True
                                        continue
                                except ValueError:
                                    pass

                            # Other non-200 errors — capture as error row but continue
                            rows.append({
                                "lakefusion_id": str(record.get("lakefusion_id", "")),
                                "update_date": date.today(),
                                "accepted": False,
                                "input_source_id": str(record.get("source_id", "")),
                                "input_name": str(record.get("name", "")),
                                "input_streetaddress": str(record.get("streetaddress", "")),
                                "input_city": str(record.get("city", "")),
                                "input_country": str(record.get("country", "")),
                                "input_state": str(record.get("state", "")),
                                "input_postal_code": str(record.get("postal_code", "")),
                                "dnb_duns": None,
                                "dnb_name": None,
                                "dnb_nameMatchScore": None,
                                "dnb_status": f"ERROR:HTTP_{resp.status_code}|{resp.text[:500]}",
                                "dnb_streetaddress": None,
                                "dnb_city": None,
                                "dnb_country": None,
                                "dnb_state": None,
                                "dnb_postal_code": None,
                                "dnb_confidenceCode": None,
                                "dnb_matchDataProfileComponents": None,
                                "dnb_matchgradeComponents": None,
                            })
                            continue

                        json_resp = resp.json()

                        # --- Check 2: HTTP 200 but error in body ---
                        if "error" in json_resp:
                            err = json_resp["error"]
                            error_code = str(err.get("errorCode", ""))
                            if error_code == "00050":
                                rows.append({
                                    "lakefusion_id": str(record.get("lakefusion_id", "")),
                                    "update_date": date.today(),
                                    "accepted": False,
                                    "input_source_id": str(record.get("source_id", "")),
                                    "input_name": str(record.get("name", "")),
                                    "input_streetaddress": str(record.get("streetaddress", "")),
                                    "input_city": str(record.get("city", "")),
                                    "input_country": str(record.get("country", "")),
                                    "input_state": str(record.get("state", "")),
                                    "input_postal_code": str(record.get("postal_code", "")),
                                    "dnb_duns": None,
                                    "dnb_name": None,
                                    "dnb_nameMatchScore": None,
                                    "dnb_status": f"QUOTA_EXHAUSTED:00050|{err.get('errorMessage', '')}",
                                    "dnb_streetaddress": None,
                                    "dnb_city": None,
                                    "dnb_country": None,
                                    "dnb_state": None,
                                    "dnb_postal_code": None,
                                    "dnb_confidenceCode": None,
                                    "dnb_matchDataProfileComponents": None,
                                    "dnb_matchgradeComponents": None,
                                })
                                stop_processing = True
                                continue

                            # Other API errors — capture as error row
                            rows.append({
                                "lakefusion_id": str(record.get("lakefusion_id", "")),
                                "update_date": date.today(),
                                "accepted": False,
                                "input_source_id": str(record.get("source_id", "")),
                                "input_name": str(record.get("name", "")),
                                "input_streetaddress": str(record.get("streetaddress", "")),
                                "input_city": str(record.get("city", "")),
                                "input_country": str(record.get("country", "")),
                                "input_state": str(record.get("state", "")),
                                "input_postal_code": str(record.get("postal_code", "")),
                                "dnb_duns": None,
                                "dnb_name": None,
                                "dnb_nameMatchScore": None,
                                "dnb_status": f"ERROR:{error_code}|{err.get('errorMessage', '')}",
                                "dnb_streetaddress": None,
                                "dnb_city": None,
                                "dnb_country": None,
                                "dnb_state": None,
                                "dnb_postal_code": None,
                                "dnb_confidenceCode": None,
                                "dnb_matchDataProfileComponents": None,
                                "dnb_matchgradeComponents": None,
                            })
                            continue

                        # --- Check 3: HTTP 200, no error = successful call ---
                        match_candidates = json_resp.get("matchCandidates", [])
                        if match_candidates:
                            for match in match_candidates:
                                org = match["organization"]
                                confidence = match["matchQualityInformation"]["confidenceCode"]
                                rows.append({
                                    "lakefusion_id": str(record.get("lakefusion_id", "")),
                                    "update_date": date.today(),
                                    "accepted": confidence >= min_confidence,
                                    "input_source_id": str(record.get("source_id", "")),
                                    "input_name": str(record.get("name", "")),
                                    "input_streetaddress": str(record.get("streetaddress", "")),
                                    "input_city": str(record.get("city", "")),
                                    "input_country": str(record.get("country", "")),
                                    "input_state": str(record.get("state", "")),
                                    "input_postal_code": str(record.get("postal_code", "")),
                                    "dnb_duns": org["duns"],
                                    "dnb_name": org["primaryName"],
                                    "dnb_nameMatchScore": float(match["matchQualityInformation"].get("nameMatchScore", 0.0)),
                                    "dnb_status": org.get("dunsControlStatus", {}).get("operatingStatus", {}).get("description"),
                                    "dnb_streetaddress": org.get("primaryAddress", {}).get("streetAddress", {}).get("line1"),
                                    "dnb_city": org.get("primaryAddress", {}).get("addressLocality", {}).get("name"),
                                    "dnb_country": org.get("primaryAddress", {}).get("addressCountry", {}).get("isoAlpha2Code"),
                                    "dnb_state": org.get("primaryAddress", {}).get("addressRegion", {}).get("abbreviatedName"),
                                    "dnb_postal_code": org.get("primaryAddress", {}).get("postalCode"),
                                    "dnb_confidenceCode": int(confidence),
                                    "dnb_matchDataProfileComponents": match["matchQualityInformation"].get("matchDataProfileComponents", []),
                                    "dnb_matchgradeComponents": match["matchQualityInformation"].get("matchGradeComponents", []),
                                })
                        # No candidates = valid response, not an error

                    except Exception as e:
                        # Capture exception as error row (no re-raising)
                        rows.append({
                            "lakefusion_id": str(record.get("lakefusion_id", "")),
                            "update_date": date.today(),
                            "accepted": False,
                            "input_source_id": str(record.get("source_id", "")),
                            "input_name": str(record.get("name", "")),
                            "input_streetaddress": str(record.get("streetaddress", "")),
                            "input_city": str(record.get("city", "")),
                            "input_country": str(record.get("country", "")),
                            "input_state": str(record.get("state", "")),
                            "input_postal_code": str(record.get("postal_code", "")),
                            "dnb_duns": None,
                            "dnb_name": None,
                            "dnb_nameMatchScore": None,
                            "dnb_status": f"EXCEPTION:{str(e)}",
                            "dnb_streetaddress": None,
                            "dnb_city": None,
                            "dnb_country": None,
                            "dnb_state": None,
                            "dnb_postal_code": None,
                            "dnb_confidenceCode": None,
                            "dnb_matchDataProfileComponents": None,
                            "dnb_matchgradeComponents": None,
                        })

                    # Throttle: 2 partitions × ~2 TPS each = ~4 TPS total (under 5 TPS limit)
                    time.sleep(0.5)

                if rows:
                    yield pd.DataFrame(rows)
                else:
                    yield pd.DataFrame(columns=[
                        "lakefusion_id", "update_date", "accepted", "input_source_id", "input_name",
                        "input_streetaddress", "input_city", "input_country", "input_state",
                        "input_postal_code", "dnb_duns", "dnb_name", "dnb_nameMatchScore",
                        "dnb_status", "dnb_streetaddress", "dnb_city", "dnb_country",
                        "dnb_state", "dnb_postal_code", "dnb_confidenceCode",
                        "dnb_matchDataProfileComponents", "dnb_matchgradeComponents",
                    ])

        return match_partition

    @step(order=2, name="Authenticate and Match Records", returns="DataFrame - matched records in silver table")
    def step_authenticate_and_match(self) -> Dict[str, Any]:
        """Authenticate to D&B API and match records using distributed mapInPandas."""
        spark = self.context.spark

        # Check if there are records to process
        records_to_process = self._df_master.count()
        if records_to_process == 0:
            print("No new records to process — skipping D&B matching")
            return {'skipped': True, 'reason': 'no new records to process'}

        if not self.api_key or not self.api_secret:
            raise ValueError("API credentials not provided - api_key and api_secret are required in params")

        # Authenticate to D&B API
        self._dnb_api = DbApi(self.api_key, self.api_secret, spark)
        self._session_token = self._dnb_api.session_token

        print(f"Matching {records_to_process} records using distributed mapInPandas...")

        # Create the partition function with closure variables
        match_func = self._create_match_partition_func(
            self._session_token,
            self.minimum_confidence,
            self.candidate_max_quantity
        )

        # 2 partitions: each throttled to ~2 TPS = ~4 TPS total, safely under D&B 5 TPS limit
        # Write ALL results (matches + errors) to silver layer
        self._df_master.repartition(2).mapInPandas(match_func, schema=DbApi.schema) \
            .write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(self.dnb_silver_table)

        print(f"D&B CleanseMatch complete — all results written to {self.dnb_silver_table}")

        # Check for fatal errors (quota/auth) AFTER successful write
        df_silver_check = spark.read.table(self.dnb_silver_table)
        self._match_quota_exhausted = df_silver_check.filter(F.col("dnb_status").startswith("QUOTA_EXHAUSTED:")).count() > 0
        self._match_auth_failed = df_silver_check.filter(F.col("dnb_status").startswith("AUTH_FAILED:")).count() > 0
        self._match_api_blocked = self._match_quota_exhausted or self._match_auth_failed

        total_processed = df_silver_check.count()

        if self._match_api_blocked:
            successful_matches = df_silver_check.filter(
                ~(F.col("dnb_status").startswith("ERROR:") |
                  F.col("dnb_status").startswith("EXCEPTION:") |
                  F.col("dnb_status").startswith("QUOTA_EXHAUSTED:") |
                  F.col("dnb_status").startswith("AUTH_FAILED:")) |
                F.col("dnb_status").isNull()
            ).count()
            print("=" * 70)
            if self._match_auth_failed:
                print("D&B API AUTHENTICATION FAILED (HTTP 401)")
                print("The API token is invalid or has expired.")
            else:
                print("D&B API QUOTA EXHAUSTED")
                print("The API token has reached its transaction limit.")
            print("=" * 70)
            print(f"Successfully processed and SAVED: {successful_matches} match results")
            print(f"Total records written to silver: {total_processed}")
            print("All successful results have been persisted. Request a new API token and rerun.")
            print("Hierarchy enrichment will be SKIPPED.")
            print("=" * 70)

        return {
            'skipped': False,
            'total_processed': total_processed,
            'api_blocked': self._match_api_blocked,
            'auth_failed': self._match_auth_failed,
            'quota_exhausted': self._match_quota_exhausted
        }

    @step(order=3, name="Score and Persist Results", returns="counts for auto-merged, in-review, and not-a-match records")
    def step_score_and_persist_results(self) -> Dict[str, Any]:
        """
        Read from silver, split errors to error table, score matches and write to gold table.

        Scoring logic:
        - If unique max score >= threshold → AUTO_MERGED, others → NOT_A_MATCH
        - If multiple records share max score >= threshold → IN_REVIEW, others → NOT_A_MATCH
        - If NO records >= threshold, but records >= minimumconfidence → IN_REVIEW
        """
        spark = self.context.spark

        # Read from silver table
        df_silver = spark.read.table(self.dnb_silver_table)

        # --- Write error rows to gold._duns_error ---
        df_errors = df_silver.filter(
            F.col("dnb_status").startswith("ERROR:") |
            F.col("dnb_status").startswith("EXCEPTION:") |
            F.col("dnb_status").startswith("QUOTA_EXHAUSTED:") |
            F.col("dnb_status").startswith("AUTH_FAILED:")
        )
        self._error_count = df_errors.count()

        if self._error_count > 0:
            error_table_exists = spark.catalog.tableExists(self.dnb_error_table)
            if error_table_exists:
                temp_view = f"_tmp_dnb_errors_{self.context.entity}"
                df_errors.createOrReplaceTempView(temp_view)
                spark.sql(f"""
                    MERGE INTO {self.dnb_error_table} AS target
                    USING {temp_view} AS source
                    ON target.lakefusion_id = source.lakefusion_id
                    WHEN MATCHED THEN UPDATE SET *
                    WHEN NOT MATCHED THEN INSERT *
                """)
                print(f"Merged {self._error_count} error records into {self.dnb_error_table}")
            else:
                df_errors.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(self.dnb_error_table)
                print(f"Created {self.dnb_error_table} with {self._error_count} error records")
        else:
            print("No D&B API failures recorded")

        # --- Score and write successful matches ---
        df_matched = df_silver.filter(
            ~(F.col("dnb_status").startswith("ERROR:") |
              F.col("dnb_status").startswith("EXCEPTION:") |
              F.col("dnb_status").startswith("QUOTA_EXHAUSTED:") |
              F.col("dnb_status").startswith("AUTH_FAILED:")) |
            F.col("dnb_status").isNull()
        )
        self.matched_count = df_matched.count()
        print(f"Match rows: {self.matched_count} | Error rows: {self._error_count}")

        if self.matched_count == 0:
            print("No successful D&B matches to score and persist")
            return {
                'auto_merged_count': 0,
                'in_review_count': 0,
                'not_a_match_count': 0,
                'error_count': self._error_count,
                'table_name': self.dnb_duns_table
            }

        # Create temp view for SQL processing
        df_matched.createOrReplaceTempView("dnb_new_matches")

        # Score and assign merge status using the corrected logic
        self._df_merge_score = spark.sql(f"""
            WITH max_scores AS (
                SELECT
                    input_source_id,
                    MAX(dnb_confidenceCode) AS max_score
                FROM dnb_new_matches
                WHERE dnb_confidenceCode >= {self.threshold}
                GROUP BY input_source_id
            ),
            score_counts AS (
                SELECT
                    m.input_source_id,
                    m.dnb_confidenceCode,
                    COUNT(*) AS score_level_count
                FROM dnb_new_matches m
                LEFT JOIN max_scores ms
                  ON m.input_source_id = ms.input_source_id
                 AND m.dnb_confidenceCode = ms.max_score
                GROUP BY m.input_source_id, m.dnb_confidenceCode
            ),
            final_decision AS (
                SELECT
                    m.*,
                    CASE
                        WHEN sc.score_level_count = 1 AND m.dnb_confidenceCode = ms.max_score THEN 'AUTO_MERGED'
                        WHEN sc.score_level_count > 1 AND m.dnb_confidenceCode = ms.max_score THEN 'IN_REVIEW'
                        WHEN ms.max_score IS NULL AND m.dnb_confidenceCode >= {self.minimum_confidence} THEN 'IN_REVIEW'
                        ELSE 'NOT_A_MATCH'
                    END AS merge_status
                FROM dnb_new_matches m
                LEFT JOIN max_scores ms
                  ON m.input_source_id = ms.input_source_id
                LEFT JOIN score_counts sc
                  ON m.input_source_id = sc.input_source_id AND m.dnb_confidenceCode = sc.dnb_confidenceCode
            )
            SELECT * FROM final_decision
        """)

        # Write to _dnb_duns table (dedup on lakefusion_id + dnb_duns) using MERGE INTO
        match_count = self._df_merge_score.count()
        if match_count > 0:
            if self._dnb_table_exists:
                # Check if table has data
                try:
                    is_empty = spark.table(self.dnb_duns_table).isEmpty()
                except:
                    is_empty = True

                if not is_empty:
                    temp_view = f"_tmp_dnb_duns_{self.context.entity}"
                    self._df_merge_score.createOrReplaceTempView(temp_view)
                    spark.sql(f"""
                        MERGE INTO {self.dnb_duns_table} AS target
                        USING {temp_view} AS source
                        ON target.lakefusion_id = source.lakefusion_id AND target.dnb_duns = source.dnb_duns
                        WHEN MATCHED THEN UPDATE SET *
                        WHEN NOT MATCHED THEN INSERT *
                    """)
                    print(f"Merged {match_count} D&B match records into {self.dnb_duns_table}")
                else:
                    self._df_merge_score.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(self.dnb_duns_table)
                    print(f"Created {self.dnb_duns_table} with {match_count} D&B match records")
            else:
                self._df_merge_score.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(self.dnb_duns_table)
                print(f"Created {self.dnb_duns_table} with {match_count} D&B match records")
        else:
            print("No successful D&B matches to write to DUNS table")

        # Get counts
        self.auto_merged_count = spark.sql(f"""
            SELECT COUNT(*) as cnt FROM {self.dnb_duns_table} WHERE merge_status = 'AUTO_MERGED'
        """).collect()[0]['cnt']

        self._in_review_count = spark.sql(f"""
            SELECT COUNT(*) as cnt FROM {self.dnb_duns_table} WHERE merge_status = 'IN_REVIEW'
        """).collect()[0]['cnt']

        self._not_a_match_count = spark.sql(f"""
            SELECT COUNT(*) as cnt FROM {self.dnb_duns_table} WHERE merge_status = 'NOT_A_MATCH'
        """).collect()[0]['cnt']

        print(f"Auto-merged: {self.auto_merged_count}")
        print(f"In review: {self._in_review_count}")
        print(f"Not a match: {self._not_a_match_count}")

        return {
            'auto_merged_count': self.auto_merged_count,
            'in_review_count': self._in_review_count,
            'not_a_match_count': self._not_a_match_count,
            'error_count': self._error_count,
            'table_name': self.dnb_duns_table
        }

    def _create_hierarchy_enrichment_func(self, session_token: str):
        """Create the mapInPandas partition function for hierarchy enrichment."""

        def enrich_hierarchy_partition(pdf_iterator: Iterator[pd.DataFrame]) -> Iterator[pd.DataFrame]:
            """Fetch hierarchy data from D&B for each DUNS.
            HTTP 401 and 429+00050 stop processing and save what we have.
            """
            _api_url = "https://plus.dnb.com/v1"

            for pdf in pdf_iterator:
                rows = []
                stop_processing = False

                for _, record in pdf.iterrows():
                    if stop_processing:
                        break

                    duns = str(record["dnb_duns"])
                    lf_id = str(record["lakefusion_id"])
                    url = f"{_api_url}/data/duns/{duns}?blockIDs=hierarchyconnections_L1_v1"
                    headers = {"Authorization": f"Bearer {session_token}"}

                    try:
                        resp = requests.get(url, headers=headers, timeout=30)

                        if resp.status_code != 200:
                            # HTTP 401 - Auth failed, stop
                            if resp.status_code == 401:
                                rows.append({
                                    "lakefusion_id": lf_id,
                                    "dnb_duns": duns,
                                    "enrichment_type": "hierarchy",
                                    "enrichment_data": "AUTH_FAILED:401|Token invalid or expired",
                                    "enriched_at": datetime.utcnow(),
                                })
                                stop_processing = True
                                continue

                            # HTTP 429 - Check for quota
                            if resp.status_code == 429:
                                try:
                                    body = resp.json()
                                    if body.get("error", {}).get("errorCode") == "00050":
                                        rows.append({
                                            "lakefusion_id": lf_id,
                                            "dnb_duns": duns,
                                            "enrichment_type": "hierarchy",
                                            "enrichment_data": f"QUOTA_EXHAUSTED:00050|{body['error'].get('errorMessage', '')}",
                                            "enriched_at": datetime.utcnow(),
                                        })
                                        stop_processing = True
                                        continue
                                except ValueError:
                                    pass

                            # Other errors - capture and continue
                            rows.append({
                                "lakefusion_id": lf_id,
                                "dnb_duns": duns,
                                "enrichment_type": "hierarchy",
                                "enrichment_data": f"ERROR:HTTP_{resp.status_code}|{resp.text[:500]}",
                                "enriched_at": datetime.utcnow(),
                            })
                            time.sleep(0.5)
                            continue

                        json_resp = resp.json()

                        if "error" in json_resp:
                            err = json_resp["error"]
                            error_code = str(err.get("errorCode", ""))
                            if error_code == "00050":
                                rows.append({
                                    "lakefusion_id": lf_id,
                                    "dnb_duns": duns,
                                    "enrichment_type": "hierarchy",
                                    "enrichment_data": f"QUOTA_EXHAUSTED:00050|{err.get('errorMessage', '')}",
                                    "enriched_at": datetime.utcnow(),
                                })
                                stop_processing = True
                                continue

                            rows.append({
                                "lakefusion_id": lf_id,
                                "dnb_duns": duns,
                                "enrichment_type": "hierarchy",
                                "enrichment_data": f"ERROR:{error_code}|{err.get('errorMessage', '')}",
                                "enriched_at": datetime.utcnow(),
                            })
                            time.sleep(0.5)
                            continue

                        # Success - extract hierarchy
                        org = json_resp.get("organization", {})
                        linkage = org.get("corporateLinkage", {})
                        hierarchy = {
                            "hierarchyLevel": linkage.get("hierarchyLevel"),
                            "familytreeRolesPlayed": linkage.get("familytreeRolesPlayed", []),
                            "globalUltimateFamilyTreeMembersCount": linkage.get("globalUltimateFamilyTreeMembersCount"),
                            "branchesCount": linkage.get("branchesCount"),
                            "globalUltimate": linkage.get("globalUltimate", {}),
                            "domesticUltimate": linkage.get("domesticUltimate", {}),
                            "parent": linkage.get("parent", {}),
                            "headQuarter": linkage.get("headQuarter", {}),
                            "branches": linkage.get("branches", []),
                        }
                        rows.append({
                            "lakefusion_id": lf_id,
                            "dnb_duns": duns,
                            "enrichment_type": "hierarchy",
                            "enrichment_data": json.dumps(hierarchy),
                            "enriched_at": datetime.utcnow(),
                        })

                    except Exception as e:
                        rows.append({
                            "lakefusion_id": lf_id,
                            "dnb_duns": duns,
                            "enrichment_type": "hierarchy",
                            "enrichment_data": f"EXCEPTION:{str(e)}",
                            "enriched_at": datetime.utcnow(),
                        })

                    time.sleep(0.5)

                if rows:
                    yield pd.DataFrame(rows)
                else:
                    yield pd.DataFrame(columns=["lakefusion_id", "dnb_duns", "enrichment_type", "enrichment_data", "enriched_at"])

        return enrich_hierarchy_partition

    @step(order=4, name="Hierarchy Enrichment (Optional)", returns="hierarchy enrichment result")
    def step_hierarchy_enrichment(self) -> Dict[str, Any]:
        """Fetch corporate hierarchy from D&B for confirmed matches (AUTO_MERGED / ACCEPTED / MANUAL_MERGE)."""
        spark = self.context.spark

        # Skip if API was blocked during matching
        if self._match_api_blocked:
            print("=" * 70)
            print("SKIPPING HIERARCHY ENRICHMENT")
            print("=" * 70)
            if self._match_auth_failed:
                print("Authentication failed during the matching phase (HTTP 401).")
            else:
                print("Quota was exhausted during the matching phase.")
            print("Hierarchy enrichment will be skipped to avoid wasting API calls.")
            print("Once you have a new API token, rerun the notebook.")
            print("=" * 70)
            return {'skipped': True, 'reason': 'API blocked during matching'}

        # Skip if hierarchy enrichment is not enabled
        if not self.hierarchy_enabled:
            print("Hierarchy enrichment is not enabled in settings")
            return {'skipped': True, 'reason': 'hierarchy enrichment not enabled'}

        # Load DUNS needing hierarchy enrichment
        enrichment_table_exists = spark.catalog.tableExists(self.dnb_enrichment_table)
        df_confirmed = spark.sql(f"""
            SELECT DISTINCT lakefusion_id, dnb_duns
            FROM {self.dnb_duns_table}
            WHERE merge_status IN ('AUTO_MERGED', 'ACCEPTED', 'MANUAL_MERGE')
        """)

        if enrichment_table_exists:
            df_already_enriched = spark.sql(f"""
                SELECT dnb_duns FROM {self.dnb_enrichment_table}
                WHERE enrichment_type = 'hierarchy'
            """)
            df_to_enrich = df_confirmed.join(df_already_enriched, on="dnb_duns", how="left_anti")
        else:
            df_to_enrich = df_confirmed

        enrich_count = df_to_enrich.count()
        if enrich_count == 0:
            print("No new DUNS to enrich with hierarchy data")
            return {'skipped': True, 'reason': 'no new DUNS to enrich'}

        print(f"Enriching {enrich_count} DUNS with hierarchy data...")

        # Create the enrichment function
        enrich_func = self._create_hierarchy_enrichment_func(self._session_token)

        # Run enrichment with mapInPandas
        df_to_enrich.repartition(2).mapInPandas(
            enrich_func, schema=DbApi.enrichment_schema
        ).write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(self.dnb_enrichment_silver_table)

        print(f"Enrichment results written to {self.dnb_enrichment_silver_table}")

        # Check for fatal errors
        df_enrichment_silver = spark.read.table(self.dnb_enrichment_silver_table)
        enrichment_api_blocked = df_enrichment_silver.filter(
            F.col("enrichment_data").startswith("QUOTA_EXHAUSTED:") |
            F.col("enrichment_data").startswith("AUTH_FAILED:")
        ).count() > 0

        if enrichment_api_blocked:
            successful_enrichments = df_enrichment_silver.filter(
                ~(F.col("enrichment_data").startswith("ERROR:") |
                  F.col("enrichment_data").startswith("EXCEPTION:") |
                  F.col("enrichment_data").startswith("QUOTA_EXHAUSTED:") |
                  F.col("enrichment_data").startswith("AUTH_FAILED:"))
            ).count()
            print("=" * 70)
            print("D&B API BLOCKED (during enrichment)")
            print(f"Successfully enriched and SAVED: {successful_enrichments} records")
            print("All successful results have been persisted. Request a new API token and rerun for remaining records.")
            print("=" * 70)

        # Split errors and successes
        df_enrichment_errors = df_enrichment_silver.filter(
            F.col("enrichment_data").startswith("ERROR:") |
            F.col("enrichment_data").startswith("EXCEPTION:") |
            F.col("enrichment_data").startswith("QUOTA_EXHAUSTED:") |
            F.col("enrichment_data").startswith("AUTH_FAILED:")
        )
        enrichment_error_count = df_enrichment_errors.count()

        if enrichment_error_count > 0:
            enrichment_error_table_exists = spark.catalog.tableExists(self.dnb_enrichment_error_table)
            if enrichment_error_table_exists:
                temp_view = f"_tmp_dnb_enrichment_errors_{self.context.entity}"
                df_enrichment_errors.createOrReplaceTempView(temp_view)
                spark.sql(f"""
                    MERGE INTO {self.dnb_enrichment_error_table} AS target
                    USING {temp_view} AS source
                    ON target.lakefusion_id = source.lakefusion_id AND target.dnb_duns = source.dnb_duns
                    WHEN MATCHED THEN UPDATE SET *
                    WHEN NOT MATCHED THEN INSERT *
                """)
                print(f"Merged {enrichment_error_count} enrichment error records into {self.dnb_enrichment_error_table}")
            else:
                df_enrichment_errors.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(self.dnb_enrichment_error_table)
                print(f"Created {self.dnb_enrichment_error_table} with {enrichment_error_count} enrichment error records")
        else:
            print("No enrichment API failures recorded")

        # Write successful enrichments
        df_enrichment_success = df_enrichment_silver.filter(
            ~(F.col("enrichment_data").startswith("ERROR:") |
              F.col("enrichment_data").startswith("EXCEPTION:") |
              F.col("enrichment_data").startswith("QUOTA_EXHAUSTED:") |
              F.col("enrichment_data").startswith("AUTH_FAILED:"))
        )
        success_count = df_enrichment_success.count()
        print(f"Enrichment — Success: {success_count} | Errors: {enrichment_error_count}")

        if success_count > 0:
            if enrichment_table_exists:
                temp_view = f"_tmp_dnb_enrichment_{self.context.entity}"
                df_enrichment_success.createOrReplaceTempView(temp_view)
                spark.sql(f"""
                    MERGE INTO {self.dnb_enrichment_table} AS target
                    USING {temp_view} AS source
                    ON target.lakefusion_id = source.lakefusion_id AND target.dnb_duns = source.dnb_duns AND target.enrichment_type = source.enrichment_type
                    WHEN MATCHED THEN UPDATE SET *
                    WHEN NOT MATCHED THEN INSERT *
                """)
                print(f"Merged enrichment records into {self.dnb_enrichment_table}")
            else:
                df_enrichment_success.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(self.dnb_enrichment_table)
                print(f"Created {self.dnb_enrichment_table} with enrichment records")

        return {
            'skipped': False,
            'enriched_count': success_count,
            'error_count': enrichment_error_count,
            'api_blocked': enrichment_api_blocked
        }

    @step(order=5, name="Add to Monitoring (Optional)", returns="monitoring registration result")
    def step_add_to_monitoring(self) -> Dict[str, Any]:
        """Add auto-merged records to D&B monitoring if registration_id is provided."""
        spark = self.context.spark

        if not self.registration_id:
            print("Skipping monitoring registration (no registration_id provided)")
            return {'skipped': True, 'reason': 'no registration_id provided'}

        if self._match_api_blocked:
            print("Skipping monitoring registration (API was blocked during matching)")
            return {'skipped': True, 'reason': 'API blocked during matching'}

        df_auto_merged = spark.sql(f"""
            SELECT * FROM {self.dnb_duns_table} WHERE merge_status = 'AUTO_MERGED'
        """)

        auto_merged_count = df_auto_merged.count()
        if auto_merged_count == 0:
            print("No auto-merged records to add to monitoring")
            return {'skipped': True, 'reason': 'no auto-merged records'}

        self._monitoring_result = self._dnb_api.add_to_monitoring(df_auto_merged, self.registration_id)
        print(f"Added {self._monitoring_result['successfully_added']} records to monitoring")

        return {
            'skipped': False,
            'successfully_added': self._monitoring_result['successfully_added'],
            'already_registered': self._monitoring_result['already_registered']
        }

    def execute(self) -> TaskResult:
        """Execute the D&B match and monitoring workflow."""
        # Step 1: Read and transform master data
        step1_result = self.step_read_and_transform_master_data()

        # Step 2: Authenticate and match records
        try:
            step2_result = self.step_authenticate_and_match()
            if step2_result.get('skipped'):
                return TaskResult.success(
                    message="No new records to process - skipping D&B matching",
                    task_name=self.context.task_name,
                    metrics={'skipped': True, 'reason': step2_result.get('reason')},
                    task_values={'dnb_match_complete': True, 'skipped': True}
                )
        except ValueError as e:
            return TaskResult.failed(
                message="API credentials not provided",
                task_name=self.context.task_name,
                error=str(e)
            )
        except Exception as e:
            return TaskResult.failed(
                message="Failed to authenticate to D&B API",
                task_name=self.context.task_name,
                error=str(e)
            )

        # Step 3: Score and persist results
        step3_result = self.step_score_and_persist_results()

        # Step 4: Hierarchy enrichment (optional)
        step4_result = self.step_hierarchy_enrichment()

        # Step 5: Add to monitoring (optional)
        step5_result = self.step_add_to_monitoring()

        # Determine final status based on API blocking
        if self._match_api_blocked:
            return TaskResult.success(
                message=f"D&B matching partially completed (API blocked). Matched {self.matched_count} records before blocking.",
                task_name=self.context.task_name,
                metrics={
                    'matched_count': self.matched_count,
                    'auto_merged_count': self.auto_merged_count,
                    'in_review_count': self._in_review_count,
                    'not_a_match_count': self._not_a_match_count,
                    'error_count': self._error_count,
                    'threshold': self.threshold,
                    'minimum_confidence': self.minimum_confidence,
                    'api_blocked': True,
                    'auth_failed': self._match_auth_failed,
                    'quota_exhausted': self._match_quota_exhausted
                },
                task_values={
                    'dnb_match_complete': False,
                    'api_blocked': True,
                    'matched_count': self.matched_count,
                    'auto_merged_count': self.auto_merged_count
                }
            )

        return TaskResult.success(
            message=f"D&B matching completed. Matched {self.matched_count} records.",
            task_name=self.context.task_name,
            metrics={
                'matched_count': self.matched_count,
                'auto_merged_count': self.auto_merged_count,
                'in_review_count': self._in_review_count,
                'not_a_match_count': self._not_a_match_count,
                'error_count': self._error_count,
                'threshold': self.threshold,
                'minimum_confidence': self.minimum_confidence
            },
            task_values={
                'dnb_match_complete': True,
                'matched_count': self.matched_count,
                'auto_merged_count': self.auto_merged_count,
                'in_review_count': self._in_review_count,
                'not_a_match_count': self._not_a_match_count
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        # Add validation for API blocking
        if self._match_api_blocked:
            result.add_validation(ValidationResult(
                passed=True,
                message=f"D&B matching partially completed (API blocked). {self.matched_count} matches saved before blocking.",
                actual=self.matched_count
            ))
        else:
            result.add_validation(ValidationResult(
                passed=True,
                message=f"D&B matching completed with {self.matched_count} matches",
                actual=self.matched_count
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        print("\n" + "="*80)
        print("D&B MATCH AND MONITORING COMPLETE")
        print("="*80)
        print(f"Matched Records: {self.matched_count}")
        print(f"Auto-merged: {self.auto_merged_count}")
        print(f"In Review: {self._in_review_count}")
        print(f"Not a Match: {self._not_a_match_count}")
        print(f"Errors: {self._error_count}")
        print(f"DNB DUNS Table: {self.dnb_duns_table}")
        print(f"DNB Silver Table: {self.dnb_silver_table}")
        if self._error_count > 0:
            print(f"DNB Error Table: {self.dnb_error_table}")
        if self.hierarchy_enabled and not self._match_api_blocked:
            print(f"DNB Enrichment Table: {self.dnb_enrichment_table}")
        if self._match_api_blocked:
            print("-"*80)
            print("WARNING: API was blocked during execution")
            if self._match_auth_failed:
                print("  - Authentication failed (HTTP 401)")
            if self._match_quota_exhausted:
                print("  - Quota exhausted (error code 00050)")
            print("All successful results have been saved. Request a new API token and rerun.")
        print("="*80)

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        print(f"D&B matching failed: {result.message}")
        if result.errors:
            for err in result.errors:
                print(f"  Error: {err}")
