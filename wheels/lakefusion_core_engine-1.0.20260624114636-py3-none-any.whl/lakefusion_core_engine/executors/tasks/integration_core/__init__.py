"""
Integration Core tasks module.

Contains task executors for core integration pipeline operations.
Submodules mirror the notebook folder structure:
    - initial_load/          - Initial load tasks (table creation, data loading)
    - normal_deduplication/  - Normal deduplication tasks (unified-to-master matching)
    - golden_deduplication/  - Golden record deduplication tasks (master-to-master matching)
    - match_maven/           - Match Maven experiment tasks
    - incremental_load/      - Incremental load tasks (CDC-based INSERT/UPDATE/DELETE processing)

Usage:
------
    from lakefusion_core_engine.executors.tasks.integration_core import initial_load
    executor = initial_load.ValidateInitialLoadExecutor(context)

    from lakefusion_core_engine.executors.tasks.integration_core import normal_deduplication
    executor = normal_deduplication.VectorSearchExecutor(context)

    from lakefusion_core_engine.executors.tasks.integration_core import golden_deduplication
    executor = golden_deduplication.GoldenVectorSearchExecutor(context)

    from lakefusion_core_engine.executors.tasks.integration_core import match_maven
    executor = match_maven.CreateTablesExperimentExecutor(context)

    from lakefusion_core_engine.executors.tasks.integration_core import incremental_load
    executor = incremental_load.CheckIncrementExistsExecutor(context)
"""

# Import submodules
from . import initial_load
from . import normal_deduplication
from . import golden_deduplication
from . import match_maven
from . import incremental_load

# Direct task imports for this level
from .process_crosswalk import ProcessCrosswalkTask
from .check_master_exists import CheckMasterExistsExecutor
from .endpoints_mapping import EndpointsMappingExecutor
from .entity_job_status import EntityJobStatusExecutor
from .manual_update import ManualUpdateExecutor
from .parse_entity_model_json import ParseEntityModelJsonExecutor
from .rbac_permissions import RBACPermissionsExecutor

__all__ = [
    # Submodules
    'initial_load',
    'normal_deduplication',
    'golden_deduplication',
    'match_maven',
    'incremental_load',
    # Direct tasks at this level
    'ProcessCrosswalkTask',
    'CheckMasterExistsExecutor',
    'EndpointsMappingExecutor',
    'EntityJobStatusExecutor',
    'ManualUpdateExecutor',
    'ParseEntityModelJsonExecutor',
    'RBACPermissionsExecutor',
]
