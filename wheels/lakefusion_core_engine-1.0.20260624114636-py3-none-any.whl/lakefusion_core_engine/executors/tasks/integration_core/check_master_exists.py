"""
Check Master Exists Executor for integration core.

Checks if master and unified tables exist to determine if this is an
initial load or incremental load.

Workflow:
1. Check if master table exists
2. Check if unified table exists
3. Validate consistency (both should exist or neither)
4. Set is_initial_load flag for downstream tasks
"""

from typing import Any, Dict, Optional

from ...base import BaseTask
from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class CheckMasterExistsExecutor(BaseStepTask):
    """
    Executor for checking master table existence.

    Determines if this is an initial load (tables don't exist)
    or an incremental load (tables exist).
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.master_exists = False
        self.unified_exists = False
        self.is_initial_load = True
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    @property
    def master_table(self) -> str:
        """Get the master table name."""
        return self.context.master_table

    @property
    def unified_table(self) -> str:
        """Get the unified table name."""
        return self.context.unified_table

    @property
    def merge_activities_table(self) -> str:
        """Get the merge activities table name."""
        return self.context.merge_activities_table

    @property
    def attribute_version_sources_table(self) -> str:
        """Get the attribute version sources table name."""
        return self.context.attribute_version_sources_table

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*60)
        self.logger.info("CHECK MASTER EXISTS")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id if self.context.experiment_id else 'prod'}")
        self.logger.info("="*60)
        self.logger.info(f"\nTable Names:")
        self.logger.info(f"  Master: {self.master_table}")
        self.logger.info(f"  Unified: {self.unified_table}")
        self.logger.info(f"  Merge Activities: {self.merge_activities_table}")
        self.logger.info(f"  Attribute Version Sources: {self.attribute_version_sources_table}")

    def _table_exists(self, table_name: str) -> bool:
        """
        Check if a table exists in the catalog.

        Args:
            table_name: Fully qualified table name (catalog.schema.table)

        Returns:
            True if table exists, False otherwise
        """
        try:
            self.context.spark.sql(f"DESCRIBE TABLE {table_name}")
            return True
        except Exception as e:
            if "TABLE_OR_VIEW_NOT_FOUND" in str(e) or "does not exist" in str(e).lower():
                return False
            else:
                raise e

    @step(order=1, name="Check Table Existence", returns="master_exists and unified_exists flags")
    def step_check_table_existence(self) -> Dict[str, Any]:
        """Check if master and unified tables exist."""
        self.logger.info("\n" + "="*60)
        self.logger.info("CHECKING TABLE EXISTENCE")
        self.logger.info("="*60)

        # Check if tables exist
        self.master_exists = self._table_exists(self.master_table)
        self.unified_exists = self._table_exists(self.unified_table)

        self.logger.info(f"\nTable Existence Check:")
        self.logger.info(f"  Master Table Exists: {self.master_exists}")
        self.logger.info(f"  Unified Table Exists: {self.unified_exists}")

        return {
            'master_exists': self.master_exists,
            'unified_exists': self.unified_exists
        }

    @step(order=2, name="Determine Load Type", returns="is_initial_load flag")
    def step_determine_load_type(self) -> Dict[str, Any]:
        """Determine if this is an initial load or incremental load."""
        # Determine if this is initial load
        self.is_initial_load = not self.master_exists

        return {
            'is_initial_load': self.is_initial_load
        }

    @step(order=3, name="Validate Table Consistency", returns="validation status")
    def step_validate_consistency(self) -> Dict[str, Any]:
        """Validate that master and unified tables are in a consistent state."""
        # Validation: If master exists, unified should also exist (for prod)
        if self.master_exists and not self.unified_exists and self.context.experiment_id == 'prod':
            raise ValueError(
                f"Inconsistent state: Master table exists but Unified table does not! "
                f"Master: {self.master_table} (exists), Unified: {self.unified_table} (missing). "
                f"This indicates a corrupted setup. Please investigate."
            )

        # Validation: If unified exists, master should also exist
        if self.unified_exists and not self.master_exists:
            raise ValueError(
                f"Inconsistent state: Unified table exists but Master table does not! "
                f"Unified: {self.unified_table} (exists), Master: {self.master_table} (missing). "
                f"This indicates a corrupted setup. Please investigate."
            )

        return {
            'consistency_valid': True
        }

    def execute(self) -> TaskResult:
        """Execute the check master exists workflow."""
        # Step 1: Check table existence
        self.step_check_table_existence()

        # Step 2: Determine load type
        self.step_determine_load_type()

        # Step 3: Validate consistency
        self.step_validate_consistency()

        return TaskResult.success(
            message=f"{'INITIAL LOAD' if self.is_initial_load else 'INCREMENTAL LOAD'} determined",
            task_name=self.context.task_name,
            metrics={
                'master_exists': self.master_exists,
                'unified_exists': self.unified_exists,
                'is_initial_load': self.is_initial_load
            },
            task_values={
                'is_initial_load': self.is_initial_load
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Table existence check completed",
            actual={'master_exists': self.master_exists, 'unified_exists': self.unified_exists}
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*60)
        self.logger.info("LOAD TYPE DETERMINATION")
        self.logger.info("="*60)

        if result.is_success:
            if self.is_initial_load:
                self.logger.info("  INITIAL LOAD")
                self.logger.info("     Master table does not exist")
                self.logger.info("     Will create all tables")
                self.logger.info("     Will load primary and secondary sources")
                self.logger.info("     Proceeding to table creation...")
            else:
                self.logger.info("  INCREMENTAL LOAD")
                self.logger.info("     Master table exists")
                self.logger.info("     Will skip table creation")
                self.logger.info("     Will process incremental changes")
                self.logger.info("     Exiting initial load pipeline...")

        self.logger.info("\n" + "="*60)
        self.logger.info("CHECK MASTER EXISTS - COMPLETE")
        self.logger.info("="*60)
        self.logger.info(f"Result: {'INITIAL LOAD' if self.is_initial_load else 'INCREMENTAL LOAD'}")
        self.logger.info(f"Next Step: {'Create Tables' if self.is_initial_load else 'Incremental Pipeline'}")
        self.logger.info("="*60)

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Check master exists failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.error(f"  Error: {error}")
