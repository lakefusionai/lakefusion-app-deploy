"""
Entity Job Status Executor for integration core.

Simple status indicator task that marks job completion.
"""

from typing import Any, Dict, Optional

from ...base import BaseTask
from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class EntityJobStatusExecutor(BaseStepTask):
    """
    Executor for entity job status reporting.

    A simple task that indicates the entity job has completed successfully.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        # Instance variables for intermediate results
        self.job_status: str = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*60)
        self.logger.info("ENTITY JOB STATUS")
        self.logger.info("="*60)

    @step(order=1, name="Report Job Status", returns="dict - job status information")
    def step_report_status(self) -> Dict[str, Any]:
        """Report the entity job status."""
        self.logger.info("Entity Job Succeeded")
        self.job_status = 'succeeded'
        return {
            'status': self.job_status
        }

    def execute(self) -> TaskResult:
        """Execute the job status workflow."""
        # Execute steps in sequence
        status_result = self.step_report_status()

        return TaskResult.success(
            message="Entity Job Succeeded",
            task_name=self.context.task_name,
            metrics={
                'status': status_result['status']
            },
            task_values={
                'job_status': status_result['status']
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Job status reported",
            actual="succeeded"
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("="*60)
        self.logger.info("ENTITY JOB STATUS - COMPLETE")
        self.logger.info("="*60)

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Entity job status failed: {result.message}")
