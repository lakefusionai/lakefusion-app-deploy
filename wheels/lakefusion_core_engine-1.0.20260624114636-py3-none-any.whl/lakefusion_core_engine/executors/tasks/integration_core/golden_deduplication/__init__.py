"""
Golden Deduplication tasks module.

Contains task executors for golden deduplication pipeline operations.
Golden deduplication operates on master-to-master matching, unlike normal
deduplication which operates on unified record-to-master matching.

Key Differences from Normal Deduplication:
    - Uses unified_deduplicate table instead of unified table
    - No record_status column - filtering by search_results/scoring_results
    - Matches masters against themselves (excluding self-matches)
    - Uses action types: MASTER_JOB_MERGE, MASTER_MANUAL_MERGE, MASTER_FORCE_MERGE

Available Tasks:
    - GoldenVectorSearchExecutor: Vector search for master-to-master matching
    - GoldenLLMMatchingExecutor: LLM-based master matching classification
    - GoldenLLMMatchingDeterministicExecutor: LLM-based deterministic master matching
    - GoldenManualMergeExecutor: Manual merge operations for masters
    - GoldenManualNotMatchExecutor: Manual not-a-match operations for masters
    - GoldenProcessDeterministicExecutor: Process deterministic matches
    - GoldenProcessAutoMergeExecutor: Auto-merge high confidence matches
    - GoldenProcessPotentialMatchExecutor: Build potential match table for dedup
    - ProcessUnifiedDedupTableExecutor: Sync unified_deduplicate table with master
    - GoldenUpdateTableMetadataExecutor: Update table metadata versions

Usage:
------
    from lakefusion_core_engine.executors.tasks.integration_core.golden_deduplication import (
        GoldenVectorSearchExecutor,
        GoldenLLMMatchingExecutor,
        GoldenManualMergeExecutor
    )
"""

from .entity_matching_vector_search import GoldenVectorSearchExecutor
from .entity_matching_llm import GoldenLLMMatchingExecutor
from .manual_merge import GoldenManualMergeExecutor
from .manual_not_match import GoldenManualNotMatchExecutor
from .process_deterministic import GoldenProcessDeterministicExecutor
from .process_auto_merge import GoldenProcessAutoMergeExecutor
from .process_potential_match import GoldenProcessPotentialMatchExecutor
from .process_unified_dedup_table import ProcessUnifiedDedupTableExecutor
from .update_table_metadata import GoldenUpdateTableMetadataExecutor

__all__ = [
    'GoldenVectorSearchExecutor',
    'GoldenLLMMatchingExecutor',
    'GoldenManualMergeExecutor',
    'GoldenManualNotMatchExecutor',
    'GoldenProcessDeterministicExecutor',
    'GoldenProcessAutoMergeExecutor',
    'GoldenProcessPotentialMatchExecutor',
    'ProcessUnifiedDedupTableExecutor',
    'GoldenUpdateTableMetadataExecutor',
]
