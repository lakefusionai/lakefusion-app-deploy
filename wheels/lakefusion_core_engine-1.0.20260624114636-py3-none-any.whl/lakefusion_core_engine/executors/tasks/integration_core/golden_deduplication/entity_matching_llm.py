"""
Golden Deduplication LLM Matching Executor.

Uses LLM to classify potential matches between master records
as MATCH, NOT_A_MATCH, or POTENTIAL_MATCH for golden deduplication.

Key Differences from Normal Deduplication:
    - Uses unified_deduplicate table instead of unified table
    - Uses processed_unified_deduplicate table
    - No record_status column - filtering by search_results/scoring_results
    - Filter uses LEFT ANTI JOIN against deterministic table when it exists
    - union_clause folds deterministic results into 'er' CTE when applicable
    - Priority dedup: deterministic reason rows win per exploded_result.lakefusion_id
    - Processed table rebuilt via full OVERWRITE (LATERAL VIEW EXPLODE) — not MERGE
    - OPTIMIZE uses CLUSTER BY (query_lakefusion_id, match_lakefusion_id)
"""

import json
from typing import Any, Dict, Optional

from pyspark.sql.types import StructType, StructField, StringType, DoubleType

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class GoldenLLMMatchingExecutor(BaseStepTask):
    """
    Executor for Golden Deduplication LLM Matching operations.

    Contains core business logic migrated from golden_deduplication/Entity_Matching_LLM notebook.
    Uses an LLM endpoint to classify potential matches between master records
    found by vector search.

    Key Differences from Normal LLMMatchingExecutor:
        - Uses unified_deduplicate table (not unified table)
        - Uses processed_unified_deduplicate table
        - No record_status filtering — uses search_results/scoring_results only
        - Filter applies LEFT ANTI JOIN against deterministic table when it exists
        - union_clause folds deterministic matches into the 'er' CTE
        - Priority dedup: deterministic reason rows win per match_lakefusion_id
        - Processed table rebuilt via full OVERWRITE from LATERAL VIEW EXPLODE
        - OPTIMIZE uses CLUSTER BY not ZORDER

    External Override Support:
        Users can provide a GoldenLLMMatchingExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        1. Validate LLM endpoint
        2. Filter records (LEFT ANTI JOIN deterministic table if exists)
        3. Execute LLM query with union_clause
        4. Priority dedup + rank filter + match classification
        5. Merge scoring results to unified_deduplicate table
        6. Rebuild processed_unified_deduplicate (full OVERWRITE)
        7. Optimize processed table (CLUSTER BY)
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the golden dedup LLM matching task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self.logger = context.params.get("logger") or self.logger

        # Table name holders — built in pre_execute
        self._unified_dedup_table: Optional[str] = None
        self._processed_unified_dedup_table: Optional[str] = None
        self._unified_deterministic_dedup_table: Optional[str] = None

        # Deterministic table existence — drives filter and union_clause
        self._deterministic_table_exists: bool = False

        # Param holders
        self._scoring_endpoint: Optional[str] = None
        self._match_attributes: list = []
        self._master_id_key: str = 'lakefusion_id'
        self._max_potential_matches: int = 3
        self._additional_instructions: str = ''
        self._base_prompt: str = ''
        self._merge_min: float = 0.9
        self._merge_max: float = 1.0
        self._matches_min: float = 0.7
        self._matches_max: float = 0.89
        self._not_match_min: float = 0.0
        self._not_match_max: float = 0.69
        self._llm_temperature: float = 0.0

        # Step intermediate results
        self._df_pending = None
        self._pending_count: int = 0
        self._df_scored = None

    def pre_execute(self) -> None:
        """
        PRE phase: Validate inputs and setup.

        Can be overridden by GoldenLLMMatchingExtended.pre_execute()
        """
        self.print_header("GOLDEN DEDUP - LLM MATCHING")
        self.logger.info(f"Entity:     {self.context.entity}")
        self.logger.info(f"Catalog:    {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id or 'prod'}")

        # Build table names — always uses _deduplicate suffix for golden dedup
        suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._unified_dedup_table = (
            f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate{suffix}"
        )
        self._processed_unified_dedup_table = (
            f"{self.context.catalog_name}.silver.{self.context.entity}_processed_unified_deduplicate{suffix}"
        )
        self._unified_deterministic_dedup_table = (
            f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deterministic_deduplicate{suffix}"
        )

        # Check whether deterministic table exists — drives filter and union_clause
        self._deterministic_table_exists = self.spark.catalog.tableExists(
            self._unified_deterministic_dedup_table
        )

        self.logger.info(f"Unified Dedup Table:              {self._unified_dedup_table}")
        self.logger.info(f"Processed Unified Dedup Table:    {self._processed_unified_dedup_table}")
        self.logger.info(f"Unified Deterministic Dedup Table:{self._unified_deterministic_dedup_table}")
        self.logger.info(f"Deterministic Table Exists:       {self._deterministic_table_exists}")
        self.logger.info(f"Master Table:                     {self.context.master_table}")

        # Get params
        params = self.context.params
        self._scoring_endpoint = params.get('scoring_endpoint') or params.get('llm_endpoint')
        self._match_attributes = params.get('match_attributes', [])
        self._master_id_key = params.get('master_id_key', 'lakefusion_id')
        self._max_potential_matches = int(params.get('max_potential_matches', 3))
        self._additional_instructions = params.get('additional_instructions', '')
        self._base_prompt = params.get('base_prompt', '')
        llm_temp = params.get('llm_temperature', 0.0)
        self._llm_temperature = float(llm_temp) if llm_temp else 0.0

        # Parse match thresholds
        config_thresholds = params.get('config_thresholds', {})
        if isinstance(config_thresholds, str):
            config_thresholds = json.loads(config_thresholds)

        merge_thresholds     = config_thresholds.get('merge',     [0.9, 1.0])
        matches_thresholds   = config_thresholds.get('matches',   [0.7, 0.89])
        not_match_thresholds = config_thresholds.get('not_match', [0.0, 0.69])

        self._merge_min,     self._merge_max     = merge_thresholds[0],     merge_thresholds[1]
        self._matches_min,   self._matches_max   = matches_thresholds[0],   matches_thresholds[1]
        self._not_match_min, self._not_match_max = not_match_thresholds[0], not_match_thresholds[1]

        if isinstance(self._match_attributes, str):
            self._match_attributes = json.loads(self._match_attributes)

        self.logger.info(f"LLM Endpoint:          {self._scoring_endpoint}")
        self.logger.info(f"Match Attributes:      {self._match_attributes}")
        self.logger.info(f"Max Potential Matches: {self._max_potential_matches}")
        self.logger.info(f"Match Thresholds:")
        self.logger.info(f"  MERGE:          [{self._merge_min}-{self._merge_max}]")
        self.logger.info(f"  POTENTIAL_MATCH:[{self._matches_min}-{self._matches_max}]")
        self.logger.info(f"  NO_MATCH:       [{self._not_match_min}-{self._not_match_max}]")

        if not self._scoring_endpoint:
            raise ValueError("scoring_endpoint or llm_endpoint is required in params")

    # ─────────────────────────────────────────────────────────────
    # Steps
    # ─────────────────────────────────────────────────────────────

    @step(order=1, name="Validate LLM Endpoint", returns="None")
    def step_validate_llm_endpoint(self) -> None:
        """Step 1: Validate LLM scoring endpoint is ready."""
        from lakefusion_core_engine.utils.model_serving import wait_until_serving_endpoint_ready

        wait_until_serving_endpoint_ready(
            endpoint_name=self._scoring_endpoint, timeout_minutes=5
        )
        self.logger.info(f"  LLM endpoint '{self._scoring_endpoint}' is ready")

    @step(order=2, name="Warm Up LLM Endpoint", returns="None")
    def step_warmup_llm_endpoint(self) -> None:
        """Step 2: Warm up LLM endpoint to handle scale-from-zero scenarios.

        The original notebook had a dedicated warm-up step that sends a simple
        ai_query to wake the endpoint before the full batch query. Without this,
        scale-from-zero endpoints can timeout or return empty results on the main query.
        """
        from lakefusion_core_engine.utils.model_serving import warm_up_llm_endpoint

        warmup_query = f"""
        SELECT ai_query('{self._scoring_endpoint}', 'Say hello and confirm you are ready.')
        FROM {self._unified_dedup_table}
        WHERE search_results IS NOT NULL AND search_results != ''
        LIMIT 1
        """

        try:
            warm_up_llm_endpoint(
                spark=self.spark,
                endpoint_name=self._scoring_endpoint,
                warmup_query=warmup_query,
                max_retries=10,
                retry_interval_seconds=60,
                timeout_minutes=10
            )
            self.logger.info(f"LLM endpoint '{self._scoring_endpoint}' is warmed up and ready")
        except Exception as e:
            error_msg = f"ERROR: LLM endpoint warm-up failed: {str(e)}"
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)

    @step(order=3, name="Filter Pending Records", returns="Dict with pending records info")
    def step_filter_pending_records(self) -> Dict[str, Any]:
        """
        Step 2: Filter records needing LLM scoring.

        When deterministic table exists:
            LEFT ANTI JOIN to exclude already-matched records (mirrors notebook).
        Otherwise:
            Plain SQL filter on search_results / scoring_results.
            NOTE: notebook's else branch also had record_status = 'ACTIVE' —
            kept here for parity but golden dedup may not always have this column.

        Uses isEmpty() for cheap existence check — avoids full count scan.
        """
        if self._deterministic_table_exists:
            filter_query = f"""
            SELECT
                u.{self._master_id_key},
                u.attributes_combined,
                u.search_results
            FROM {self._unified_dedup_table} u
            LEFT ANTI JOIN {self._unified_deterministic_dedup_table} ud
                ON u.{self._master_id_key} = ud.{self._master_id_key}
            WHERE u.search_results IS NOT NULL
              AND u.search_results != ''
              AND (u.scoring_results IS NULL OR u.scoring_results = '')
            """
        else:
            filter_query = f"""
            SELECT
                u.{self._master_id_key},
                u.attributes_combined,
                u.search_results
            FROM {self._unified_dedup_table} u
            WHERE u.search_results IS NOT NULL
              AND u.search_results != ''
              AND (u.scoring_results IS NULL OR u.scoring_results = '')
            """

        df_pending = self.spark.sql(filter_query)
        has_records = not df_pending.isEmpty()

        self.logger.info(f"  Deterministic table exists: {self._deterministic_table_exists}")
        self.logger.info(f"  Has records to process:     {has_records}")

        if not has_records:
            self.logger.info("  No new records to process")
            self._stats['pending_count'] = 0
            self._df_pending = None
            self._pending_count = 0
            return {'pending_count': 0, 'has_records': False}

        self._df_pending = df_pending
        self._pending_count = 1  # Actual count deferred — avoids extra scan
        self._stats['pending_count'] = 1

        return {'pending_count': 1, 'has_records': True}

    @step(order=4, name="Execute LLM Query", returns="DataFrame with LLM results")
    def step_call_llm_endpoint(self) -> Dict[str, Any]:
        """
        Step 3: Call LLM endpoint via native ai_query().

        Includes:
            - union_clause: folds deterministic results into 'er' CTE when table exists.
            - Priority dedup: deterministic reason rows win per exploded_result.lakefusion_id.
            - Rank filter: top N per query record.
            - Match classification: threshold-based Spark when() — no UDF.
            - Reconstruct exploded_result with match_status.
        """
        if self._df_pending is None:
            self.logger.info("  No pending records to process")
            return {'records_scored': 0}

        self.logger.info("  Running LLM matching (this may take a while)...")

        llm_query = self._build_llm_query()

        try:
            df_llm_results = self.spark.sql(llm_query)
            self.logger.info("  LLM processing completed")
        except Exception as e:
            import traceback
            error_msg = f"ERROR: LLM query execution failed: {str(e)}"
            self.logger.error(error_msg)
            self.logger.info(traceback.format_exc())
            raise RuntimeError(error_msg)

        # ── Priority dedup: deterministic reason rows win per match lakefusion_id ──
        # Mirrors notebook post-LLM dedup step exactly
        from pyspark.sql import functions as F
        from pyspark.sql.window import Window

        df_with_priority = df_llm_results.withColumn(
            "priority",
            F.when(
                F.col("exploded_result.reason").contains(
                    "Due to Deterministic Match of Rule"
                ),
                1,
            ).otherwise(0),
        )

        w_priority = (
            Window
            .partitionBy(f"exploded_result.lakefusion_id")
            .orderBy(
                F.col("priority").desc(),
                F.col("exploded_result.score").desc(),
            )
        )

        df_llm_results = (
            df_with_priority
            .withColumn("rn", F.row_number().over(w_priority))
            .filter("rn = 1")
            .drop("rn", "priority")
        )

        # ── Rank filter: top N per query record ───────────────────────────────
        # Mirrors notebook STEP 7
        w_rank = (
            Window
            .partitionBy(f"query_{self._master_id_key}")
            .orderBy(F.col("exploded_result.score").desc())
        )

        df_filtered = (
            df_llm_results
            .filter(F.col(f"match_{self._master_id_key}").isNotNull())
            .withColumn("rank", F.row_number().over(w_rank))
            .filter(F.col("rank") <= self._max_potential_matches)
            .drop("rank")
        )

        # ── Match classification via Spark when() — mirrors notebook STEP 8 ──
        # Uses Spark when() instead of notebook's classify_match_udf — no UDF needed
        df_classified = df_filtered.withColumn(
            "match_status",
            F.when(F.col("exploded_result.score").isNull(), "NO_MATCH")
            .when(
                (F.col("exploded_result.score") >= self._merge_min) &
                (F.col("exploded_result.score") <= self._merge_max),
                "MATCH",
            )
            .when(
                (F.col("exploded_result.score") >= self._matches_min) &
                (F.col("exploded_result.score") <= self._matches_max),
                "POTENTIAL_MATCH",
            )
            .otherwise("NO_MATCH"),
        )

        # ── Reconstruct exploded_result with match_status — mirrors notebook STEP 8 ──
        df_with_match_status = (
            df_classified
            .withColumn(
                "exploded_result",
                F.struct(
                    F.col("exploded_result.id").alias("id"),
                    F.col("match_status").alias("match"),
                    F.col("exploded_result.score").alias("score"),
                    F.col("exploded_result.reason").alias("reason"),
                    F.col("exploded_result.lakefusion_id").alias("lakefusion_id"),
                ),
            )
            .select(
                F.col(f"query_{self._master_id_key}"),
                F.col(f"match_{self._master_id_key}"),
                "exploded_result",
                "exploded_result_id",
                "scoring_results_json",
                "match_status",
            )
        )

        self._df_scored = df_with_match_status
        self._stats['records_scored'] = 1  # Deferred

        return {'records_scored': 1}

    @step(order=5, name="Merge Scoring Results", returns="Update statistics")
    def step_merge_scoring_results(self) -> Dict[str, Any]:
        """
        Step 4: Merge scoring_results back into unified_deduplicate table.

        Groups by query_lakefusion_id, serializes results to JSON,
        then MERGE-updates scoring_results on the unified_dedup table.
        Mirrors notebook STEP 9.
        """
        if self._df_scored is None:
            self.logger.info("  No scored results to merge")
            return {'records_updated': 0}

        from delta.tables import DeltaTable
        from pyspark.sql.functions import col, collect_list, struct, to_json

        df_scoring_updates = (
            self._df_scored
            .groupBy(col(f"query_{self._master_id_key}").alias(self._master_id_key))
            .agg(
                collect_list(
                    struct(
                        col("exploded_result.id").alias("id"),
                        col("exploded_result.match").alias("match"),
                        col("exploded_result.score").alias("score"),
                        col("exploded_result.reason").alias("reason"),
                        col("exploded_result.lakefusion_id").alias("lakefusion_id"),
                    )
                ).alias("results_array")
            )
            .withColumn("scoring_results", to_json(col("results_array")))
            .select(col(self._master_id_key), "scoring_results")
        )

        unified_delta = DeltaTable.forName(self.spark, self._unified_dedup_table)
        (
            unified_delta.alias("target")
            .merge(
                source=df_scoring_updates.alias("source"),
                condition=f"target.{self._master_id_key} = source.{self._master_id_key}",
            )
            .whenMatchedUpdate(set={"scoring_results": "source.scoring_results"})
            .execute()
        )

        self.logger.info("  Unified dedup table updated with scoring_results")
        self._stats['records_updated'] = 1

        return {'records_updated': 1}

    @step(order=5, name="Rebuild Processed Table", returns="Write statistics")
    def step_rebuild_processed_table(self) -> Dict[str, Any]:
        """
        Step 5: Full OVERWRITE rebuild of processed_unified_deduplicate from
        all records with scoring_results in unified_dedup.

        Uses LATERAL VIEW EXPLODE — mirrors notebook STEP 10 exactly.
        NOT a MERGE — every run is a full rebuild from source of truth.
        """
        if self._df_scored is None:
            self.logger.info("  No scored results — skipping processed table rebuild")
            return {'records_written': 0}

        self.logger.info(
            "  Building processed_unified_dedup from all records with scoring_results"
        )

        rebuild_query = f"""
        SELECT
            u.{self._master_id_key}        AS query_{self._master_id_key},
            exploded.lakefusion_id         AS match_{self._master_id_key},
            exploded                       AS exploded_result,
            exploded.id                    AS exploded_result_id
        FROM {self._unified_dedup_table} u
        LATERAL VIEW EXPLODE(
            FROM_JSON(u.scoring_results, 'array<struct<
                id:string,
                match:string,
                score:double,
                reason:string,
                lakefusion_id:string
            >>')
        ) AS exploded
        WHERE u.scoring_results IS NOT NULL
          AND u.scoring_results != ''
        """

        df_processed = self.spark.sql(rebuild_query)

        # Full overwrite — mirrors notebook STEP 10
        (
            df_processed
            .write
            .mode("overwrite")
            .option("mergeSchema", "true")
            .saveAsTable(self._processed_unified_dedup_table)
        )

        self.logger.info(
            f"  Processed unified dedup table rebuilt: {self._processed_unified_dedup_table}"
        )

        return {'status': 'rebuilt'}

    @step(order=6, name="Optimize Processed Table", returns="None")
    def step_optimize_processed_table(self) -> None:
        """
        Step 6: Optimize processed table using CLUSTER BY.

        Mirrors notebook STEP 11:
            ALTER TABLE ... CLUSTER BY (query_lakefusion_id, match_lakefusion_id)
        """
        try:
            self.spark.sql(
                f"ALTER TABLE {self._processed_unified_dedup_table} "
                f"CLUSTER BY (query_{self._master_id_key}, match_{self._master_id_key})"
            )
            self.logger.info("  Processed table optimized with CLUSTER BY")
        except Exception as e:
            self.logger.info(f"  Optimization skipped: {str(e)}")

    @step(order=7, name="Sync Processed Table (Skipped Scenario)", returns="Sync status")
    def step_sync_processed_table_from_scoring(self) -> Dict[str, Any]:
        """
        Step 7 (skipped-path only): Rebuild processed_unified_dedup from existing
        scoring_results when no new records needed LLM scoring.

        Uses full OVERWRITE via LATERAL VIEW EXPLODE — mirrors notebook STEP 5
        in the early-exit branch exactly. NOT a MERGE.
        """
        self.logger.info("  Syncing processed table from existing scoring_results")

        with_scoring = self.spark.sql(f"""
            SELECT COUNT(*) AS cnt
            FROM {self._unified_dedup_table}
            WHERE scoring_results IS NOT NULL
              AND scoring_results != ''
        """).collect()[0]['cnt']

        self.logger.info(f"  Records with scoring_results: {with_scoring}")

        if with_scoring == 0:
            self.logger.info("  No scoring_results to process")

            if not self.spark.catalog.tableExists(self._processed_unified_dedup_table):
                self.logger.info(
                    f"  Creating empty processed_unified_dedup table: {self._processed_unified_dedup_table}"
                )
                empty_schema = StructType([
                    StructField(f"query_{self._master_id_key}", StringType(), True),
                    StructField(f"match_{self._master_id_key}", StringType(), True),
                    StructField("exploded_result", StructType([
                        StructField("id", StringType(), True),
                        StructField("match", StringType(), True),
                        StructField("score", DoubleType(), True),
                        StructField("reason", StringType(), True),
                        StructField("lakefusion_id", StringType(), True),
                    ]), True),
                    StructField("exploded_result_id", StringType(), True),
                ])
                empty_df = self.spark.createDataFrame([], empty_schema)
                (
                    empty_df.write
                    .mode("overwrite")
                    .option("mergeSchema", "true")
                    .saveAsTable(self._processed_unified_dedup_table)
                )
                self.logger.info("  ✓ Empty processed_unified_dedup table created")

            return {'status': 'no_data'}

        rebuild_query = f"""
        SELECT
            u.{self._master_id_key}        AS query_{self._master_id_key},
            exploded.lakefusion_id         AS match_{self._master_id_key},
            exploded                       AS exploded_result,
            exploded.id                    AS exploded_result_id
        FROM {self._unified_dedup_table} u
        LATERAL VIEW EXPLODE(
            FROM_JSON(u.scoring_results, 'array<struct<
                id:string,
                match:string,
                score:double,
                reason:string,
                lakefusion_id:string
            >>')
        ) AS exploded
        WHERE u.scoring_results IS NOT NULL
          AND u.scoring_results != ''
        """

        df_from_scoring = self.spark.sql(rebuild_query)

        # Full overwrite — mirrors notebook STEP 5 skip path
        (
            df_from_scoring
            .write
            .mode("overwrite")
            .option("mergeSchema", "true")
            .saveAsTable(self._processed_unified_dedup_table)
        )

        self.logger.info(
            f"  Processed unified dedup table synced: {self._processed_unified_dedup_table}"
        )

        return {'status': 'synced'}

    # ─────────────────────────────────────────────────────────────
    # Lifecycle methods
    # ─────────────────────────────────────────────────────────────

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Core LLM matching business logic for golden dedup.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Validate LLM endpoint
            self.step_validate_llm_endpoint()

            # Step 2: Warm up LLM endpoint (scale-from-zero handling)
            self.step_warmup_llm_endpoint()

            # Step 3: Filter records for LLM scoring
            filter_result = self.step_filter_pending_records()

            if not filter_result.get('has_records', False):
                # Sync processed table from existing scoring_results even on skip
                self.step_sync_processed_table_from_scoring()

                return TaskResult.skipped(
                    message="No records to process - all records already have scoring results",
                    task_name=self.context.task_name,
                    task_values={
                        'llm_matching_complete': True,
                        'records_scored': 0
                    }
                )

            # Step 3: Execute LLM query (includes priority dedup + rank + classification)
            self.step_call_llm_endpoint()

            # Step 4: Merge scoring results to unified_deduplicate table
            self.step_merge_scoring_results()

            # Step 5: Full rebuild of processed_unified_deduplicate (OVERWRITE)
            self.step_rebuild_processed_table()

            # Step 6: Optimize processed table
            self.step_optimize_processed_table()

            return TaskResult.success(
                message=f"Golden dedup LLM matching completed",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'llm_matching_complete': True,
                    'records_scored': self._stats.get('records_scored', 0)
                },
                artifacts={
                    'unified_dedup_table': self._unified_dedup_table,
                    'processed_unified_dedup_table': self._processed_unified_dedup_table
                }
            )

        except Exception as e:
            raise RuntimeError(f"Golden dedup LLM matching failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the LLM matching results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            records_scored  = self._stats.get('records_scored', 0)
            records_updated = self._stats.get('records_updated', 0)

            validation = ValidationResult(
                passed=records_updated > 0 or records_scored == 0,
                message="Golden dedup LLM scoring results merged to unified_deduplicate table",
                expected=records_scored,
                actual=records_updated
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("llm_matching_complete", True)
                self.dbutils.jobs.taskValues.set(
                    "records_scored", self._stats.get('records_scored', 0)
                )
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _build_union_clause(self) -> str:
        """
        Build UNION clause folding deterministic results into the 'er' CTE.

        When deterministic table exists, already-matched records from
        unified_deterministic_deduplicate are included alongside new LLM results
        so the processed table stays complete.

        Returns empty string when deterministic table does not exist.
        Mirrors notebook union_clause construction exactly.
        """
        if not self._deterministic_table_exists:
            return ""

        return f"""
    UNION
    SELECT
        {self._master_id_key},
        FIRST(attributes_combined)  AS attributes_combined,
        FIRST(search_results)       AS search_results,
        CONCAT(
            '[',
            CONCAT_WS(',', COLLECT_LIST(json_item)),
            ']'
        ) AS combined_column,
        FIRST(exploded_result) AS exploded_result
    FROM (
        SELECT
            {self._master_id_key},
            CONCAT(
                '{{"id": "',             exploded_result.id,
                '", "score": ',          exploded_result.score,
                ', "reason": "',         exploded_result.reason,
                '", "lakefusion_id": "', exploded_result.lakefusion_id,
                '"}}'
            ) AS json_item,
            attributes_combined,
            search_results,
            deterministic_match_result,
            is_deterministic_match,
            NAMED_STRUCT(
                'id',            exploded_result.id,
                'score',         CAST(exploded_result.score AS DOUBLE),
                'reason',        exploded_result.reason,
                'lakefusion_id', exploded_result.lakefusion_id
            ) AS exploded_result
        FROM {self._unified_deterministic_dedup_table}
    )
    GROUP BY {self._master_id_key}
        """

    def _build_llm_query(self) -> str:
        """
        Build the full LLM SQL query with ai_query().

        Filter subquery (uf):
            - LEFT ANTI JOIN against deterministic table when it exists.
            - Plain filter when deterministic table is absent.

        union_clause:
            - Folds deterministic results into 'er' CTE when table exists.
            - Appended inside the FROM clause of 'er' after the WHERE condition,
              matching notebook's exact placement.

        Mirrors notebook STEP 5 (uf + union_clause) and STEP 5 (llm_query) exactly.
        """
        merged_desc_column = "attributes_combined"

        additional_instructions_clause = ""
        if self._additional_instructions and self._additional_instructions.strip():
            additional_instructions_clause = f" {self._additional_instructions}"

        self.logger.info(
            f"  Building LLM query for {self._max_potential_matches} matches per record"
        )

        # ── Filter subquery — same branching logic as step_filter_pending_records ──
        if self._deterministic_table_exists:
            filter_query = f"""
            SELECT
                u.{self._master_id_key},
                u.{merged_desc_column},
                u.search_results
            FROM {self._unified_dedup_table} u
            LEFT ANTI JOIN {self._unified_deterministic_dedup_table} ud
                ON u.{self._master_id_key} = ud.{self._master_id_key}
            WHERE u.search_results IS NOT NULL
              AND u.search_results != ''
              AND (u.scoring_results IS NULL OR u.scoring_results = '')
            """
        else:
            filter_query = f"""
            SELECT
                u.{self._master_id_key},
                u.{merged_desc_column},
                u.search_results
            FROM {self._unified_dedup_table} u
            WHERE u.search_results IS NOT NULL
              AND u.search_results != ''
              AND (u.scoring_results IS NULL OR u.scoring_results = '')
            """

        uf_sub_query = f"uf AS ({filter_query})"
        union_clause = self._build_union_clause()

        # ── Prompt construction ───────────────────────────────────────────────
        if not self._base_prompt:
            self.logger.info("  Using default prompt")
            attributes_str = ' | '.join(self._match_attributes)
            default_prompt = f"""You are an expert in classifying two records as matching or not matching.
You will be provided with a golden record and a list of potential matches.
You need to find the closest matching record with a similarity score to indicate how similar they are.
Take into account:
1. The attributes are not mutually exclusive.
2. The attributes are not exhaustive.
3. The attributes are not consistent.
4. The attributes are not complete.
5. The attributes can have typos.
6. The entity type being considered is: {self.context.entity}.
7. Do not consider scores in the search results. Generate your own similarity scores.
8. If additional instructions are present, consider them too.{additional_instructions_clause}
Follow these rules for input and output:
**Input:**
- Golden Record Format:
  The golden record will be provided as a single string in the following format:
  {attributes_str}
  Each field is separated by a vertical bar (|).
  Note: Some columns can have aggregated values separated by (bullet)
- List of Potential Matches:
  A string containing comma-separated entries in this EXACT format:
  [match_record, lakefusion_id, score], [match_record, lakefusion_id, score], ...
  Example: [John | Smith | john@email.com | 555-1234, abc123def456, 0.85], [Jane | Doe | jane@email.com | 555-5678, xyz789ghi012, 0.75], ...
  WHERE:
  - match_record: Pipe-separated fields (BEFORE first comma inside brackets)
  - lakefusion_id: 32-character hexadecimal string (BETWEEN first and second comma)
  - score: Decimal number (AFTER second comma, before closing bracket)
**CRITICAL EXTRACTION RULES:**
- For EACH entry in the list, you MUST extract the lakefusion_id
- The lakefusion_id is ALWAYS between the FIRST comma and SECOND comma inside each bracket
- If you cannot find a valid lakefusion_id, DO NOT return that entry
- lakefusion_id format: 32 lowercase hexadecimal characters (a-f, 0-9)
- Example valid lakefusion_id: d728dead49f8c4bbbf0be3dcdc65d215
**Output:**
Only return a plain JSON list of objects:
1. No extra text, no headers, no introductory phrases, and no comments.
2. Do not use code blocks, markdown, or any other formatting.
3. The JSON list MUST contain EXACTLY {self._max_potential_matches} objects (one for each potential match in the input list).
4. Each object must have these keys:
    a. id: String (the match_record - text BEFORE first comma in brackets).
    b. score: Float (YOUR similarity score from 0.0 to 1.0 - NOT the vector score).
    c. reason: String (brief explanation for YOUR score, comparing to the golden record).
    d. lakefusion_id: String (COPY the 32-char hex string between 1st and 2nd comma EXACTLY).
    d. {self._master_id_key}: String (COPY the 32-char hex string between 1st and 2nd comma EXACTLY).
5. VERIFY each lakefusion_id is exactly 32 characters of a-f and 0-9.
6. Return EXACTLY {self._max_potential_matches} results, no more, no less.
7. Ensure scores are in descending order (highest similarity first)."""
            safe_prompt = default_prompt.replace("'", "\\'")
        else:
            self.logger.info("  Using custom base prompt")

            def safe_format(template, **kwargs):
                class SafeDict(dict):
                    def __missing__(self, key):
                        return '{' + key + '}'
                return template.format_map(SafeDict(**kwargs))

            clean_prompt = (
                self._base_prompt
                .replace("{query_entity}", "")
                .replace("{merged_desc_column}", "")
                .replace("{search_results}", "")
            )
            formatted_prompt = safe_format(
                clean_prompt,
                entity=self.context.entity,
                additional_instructions=self._additional_instructions,
                attributes=' | '.join(self._match_attributes),
                max_potential_matches=self._max_potential_matches,
            )
            safe_prompt = formatted_prompt.replace("'", "\\'")

        prompt_concat_parts = (
            f"CONCAT('{safe_prompt}', "
            f"'\\nQuery record: ', {merged_desc_column}, "
            f"'\\nList of potential matches with vector search scores (JSON Array): ', search_results)"
        )

        # ── Full LLM query — mirrors notebook exactly ─────────────────────────
        # NOTE: 'er' CTE uses comma join + WHERE (not INNER JOIN ... ON) to match
        # the notebook's exact SQL structure, which allows union_clause to be
        # appended after the WHERE condition inside the FROM clause.
        llm_query = f"""
WITH m AS (
    SELECT {self._master_id_key}, {merged_desc_column}
    FROM   {self.context.master_table}
),
{uf_sub_query},
llm_results AS (
    SELECT
        {self._master_id_key},
        {merged_desc_column},
        search_results,
        ai_query(
            '{self._scoring_endpoint}',
            {prompt_concat_parts},
            responseFormat => '{{
                "type": "json_schema",
                "json_schema": {{
                    "name": "match_results",
                    "schema": {{
                        "type": "object",
                        "properties": {{
                            "results": {{
                                "type": "array",
                                "items": {{
                                    "type": "object",
                                    "properties": {{
                                        "id":                        {{ "type": "string" }},
                                        "score":                     {{ "type": "number" }},
                                        "reason":                    {{ "type": "string" }},
                                        "{self._master_id_key}":     {{ "type": "string" }}
                                    }},
                                    "required": ["id", "match", "score", "reason", "{self._master_id_key}"],
                                    "additionalProperties": false
                                }}
                            }}
                        }},
                        "required": ["results"],
                        "additionalProperties": false
                    }},
                    "strict": true
                }}
            }}',
            modelParameters => named_struct('temperature', {self._llm_temperature})
        ) AS scoring_results
    FROM uf
),
er AS (
    SELECT
        uf.*,
        get_json_object(llm_results.scoring_results, '$.results') AS combined_results,
        EXPLODE(FROM_JSON(
            get_json_object(llm_results.scoring_results, '$.results'),
            'ARRAY<STRUCT<
                id     STRING,
                score  DOUBLE,
                reason STRING,
                lakefusion_id STRING
            >>'
        )) AS exploded_result
    FROM uf, llm_results
    WHERE uf.{self._master_id_key} = llm_results.{self._master_id_key}
    {union_clause}
)
SELECT
    er.{self._master_id_key}              AS query_{self._master_id_key},
    er.exploded_result.lakefusion_id      AS match_{self._master_id_key},
    er.exploded_result,
    er.exploded_result.`id`               AS exploded_result_id,
    er.combined_results                   AS scoring_results_json
FROM er
LEFT JOIN m ON er.exploded_result.lakefusion_id = m.{self._master_id_key}
WHERE m.{self._master_id_key} IS NOT NULL
        """

        return llm_query