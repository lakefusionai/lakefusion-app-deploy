"""
Golden Deduplication Vector Search Executor.

Performs vector similarity search to find potential matches between
master records (master-to-master matching for golden deduplication).

Key Differences from Normal Deduplication:
    - Uses unified_deduplicate table instead of unified table
    - No record_status column - filtering by search_results/scoring_results
    - Matches masters against themselves (excluding self-matches)
"""

import time
from typing import Any, Dict, Optional

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class GoldenVectorSearchExecutor(BaseStepTask):
    """
    Executor for Golden Deduplication Vector Search operations.

    Contains core business logic migrated from golden_deduplication/Entity_Matching_Vector_Search notebook.
    Searches unified_deduplicate records (masters) against the master table vector index
    to find potential master-to-master matches based on embedding similarity.

    Key Differences from Normal VectorSearchExecutor:
        - Uses unified_deduplicate table (not unified table)
        - No record_status filtering - uses search_results/scoring_results
        - Excludes self-matches (where lakefusion_id matches)

    External Override Support:
        Users can provide a GoldenVectorSearchExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        1. Validate embedding endpoint
        2. Setup/verify vector search endpoint
        3. Create or sync vector search index
        4. Filter records needing search (empty search_results)
        5. Execute vector search via UDF (excluding self-matches)
        6. Merge results back to unified_deduplicate table
    """

    # Configuration constants
    TIMEOUT_SECONDS = 10 * 60  # 10 minutes
    POLL_INTERVAL = 20  # seconds
    MAX_PIPELINE_FAILURES = 3  # fail on 3rd occurrence
    REGISTRATION_TIMEOUT = 1800  # 30 minutes for index registration

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the golden dedup vector search task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._index = None
        self._client = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Step intermediate results
        self._unified_dedup_table: Optional[str] = None
        self._embedding_endpoint: Optional[str] = None
        self._vs_endpoint: Optional[str] = None
        self._max_potential_matches: int = 3
        self._merged_desc_column: str = 'attributes_combined'
        self._master_id_key: str = 'lakefusion_id'
        self._df_pending = None
        self._pending_count: int = 0
        self._df_results = None
        self._df_deduped = None

    def pre_execute(self) -> None:
        """
        PRE phase: Validate inputs and setup endpoints.

        Can be overridden by GoldenVectorSearchExtended.pre_execute()
        """
        self.print_header("GOLDEN DEDUP - VECTOR SEARCH")
        self.logger.info("GOLDEN DEDUP - VECTOR SEARCH")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id or 'prod'}")

        # Build table names for golden dedup
        self._unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate"
        if self.context.experiment_id:
            self._unified_dedup_table += f"_{self.context.experiment_id}"

        self.logger.info(f"Unified Dedup Table: {self._unified_dedup_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")

        # Get params
        params = self.context.params
        self._embedding_endpoint = params.get('embedding_endpoint')
        self._vs_endpoint = params.get('vs_endpoint')
        self._max_potential_matches = int(params.get('max_potential_matches', 3))
        self._merged_desc_column = params.get('merged_desc_column', 'attributes_combined')
        self._master_id_key = params.get('master_id_key', 'lakefusion_id')

        self.logger.info(f"Embedding Endpoint: {self._embedding_endpoint}")
        self.logger.info(f"VS Endpoint: {self._vs_endpoint}")
        self.logger.info(f"Max Potential Matches: {self._max_potential_matches}")

        # Validate required params
        if not self._embedding_endpoint:
            raise ValueError("embedding_endpoint is required in params")
        if not self._vs_endpoint:
            raise ValueError("vs_endpoint is required in params")

    @step(order=1, name="Validate Embedding Endpoint", returns="None")
    def step_validate_embedding_endpoint(self) -> None:
        """Step 1: Validate embedding endpoint is ready."""
        from lakefusion_core_engine.utils.model_serving import wait_until_serving_endpoint_ready

        wait_until_serving_endpoint_ready(endpoint_name=self._embedding_endpoint, timeout_minutes=5)
        self.logger.info(f"Embedding endpoint '{self._embedding_endpoint}' is ready")

    @step(order=2, name="Setup Vector Search Endpoint", returns="None")
    def step_setup_vs_endpoint(self) -> None:
        """Step 2: Setup vector search endpoint."""
        from databricks.vector_search.client import VectorSearchClient

        self._client = VectorSearchClient(disable_notice=True)

        try:
            response = self._client.list_endpoints()
            existing_endpoints = [ep['name'] for ep in response.get('endpoints', [])]
        except Exception as e:
            self.logger.info(f"Could not fetch Vector Search endpoints: {e}")
            existing_endpoints = []

        if self._vs_endpoint in existing_endpoints:
            self.logger.info(f"Endpoint '{self._vs_endpoint}' already exists. Skipping creation.")
        else:
            try:
                self.logger.info(f"Creating new endpoint '{self._vs_endpoint}' ...")
                self._client.create_endpoint(
                    name=self._vs_endpoint,
                    endpoint_type="STANDARD"
                )
                self.logger.info(f"Endpoint '{self._vs_endpoint}' created successfully.")
            except Exception as e:
                self.logger.info(f"Exception occurred while creating the Vector Search endpoint: {e}")

    @step(order=3, name="Wait for VS Endpoint", returns="None")
    def step_wait_for_vs_endpoint(self) -> None:
        """Step 3: Wait for VS endpoint to be ready."""
        from lakefusion_core_engine.utils.model_serving import wait_until_vector_search_ready

        wait_until_vector_search_ready(endpoint_name=self._vs_endpoint)
        self.logger.info(f"Vector Search endpoint '{self._vs_endpoint}' is ready")

    @step(order=4, name="Create/Sync Vector Search Index", returns="None")
    def step_create_or_sync_index(self) -> None:
        """Step 4: Create or sync vector search index."""
        from lakefusion_core_engine.utils.model_serving import sync_index_with_retry

        index_name = f"{self.context.master_table}_index"
        self._stats['index_name'] = index_name

        # -------------------------------------------------
        # STEP 4.1: Create index with retry logic
        # -------------------------------------------------
        MAX_CREATE_RETRIES = 3
        CREATE_RETRY_INTERVAL = 60  # seconds
        index_already_exists = False

        for attempt in range(1, MAX_CREATE_RETRIES + 1):
            try:
                self.logger.info(f"Attempting to create index (attempt {attempt}/{MAX_CREATE_RETRIES})...")
                self._index = self._client.create_delta_sync_index(
                    endpoint_name=self._vs_endpoint,
                    source_table_name=self.context.master_table,
                    columns_to_sync=[self._master_id_key, self._merged_desc_column],
                    index_name=index_name,
                    pipeline_type="TRIGGERED",
                    primary_key=self._master_id_key,
                    embedding_source_column=self._merged_desc_column,
                    embedding_model_endpoint_name=self._embedding_endpoint
                )
                self.logger.info(f"Create request submitted for index: {index_name}")
                break  # Success, exit retry loop

            except Exception as e:
                error_msg = str(e)
                error_lower = error_msg.lower()

                # Case 1: Index already exists - this is fine, proceed to wait loop
                if "already exists" in error_lower:
                    self.logger.info(f"Index already exists, proceeding to sync: {error_msg}")
                    index_already_exists = True
                    break

                # Case 2: Permanent errors - fail immediately
                if ("maximum number of indexes" in error_lower or
                    "permission denied" in error_lower or
                    "unauthorized" in error_lower):
                    raise RuntimeError(f"Index creation failed: {error_msg}")

                # Case 3: Transient errors - retry
                self.logger.info(f"Create attempt {attempt} failed: {error_msg}")
                if attempt < MAX_CREATE_RETRIES:
                    self.logger.info(f"Retrying in {CREATE_RETRY_INTERVAL} seconds...")
                    time.sleep(CREATE_RETRY_INTERVAL)
                else:
                    raise RuntimeError(
                        f"Index creation failed after {MAX_CREATE_RETRIES} attempts: {error_msg}"
                    )

        # -------------------------------------------------
        # STEP 4.2: Wait for index registration
        # -------------------------------------------------
        self.logger.info("Waiting for index registration...")
        start = time.time()

        while self._index is None:
            if time.time() - start > self.REGISTRATION_TIMEOUT:
                raise TimeoutError(
                    f"Index '{index_name}' not registered within {self.REGISTRATION_TIMEOUT}s"
                )

            try:
                self._index = self._client.get_index(
                    endpoint_name=self._vs_endpoint,
                    index_name=index_name,
                )
                self.logger.info("Index is now registered and accessible")
            except Exception as e:
                error_lower = str(e).lower()
                if "not exist" in error_lower or "not_exist" in error_lower:
                    self.logger.info("  Index not visible yet - waiting...")
                    time.sleep(20)
                else:
                    raise RuntimeError(f"Unexpected error while locating index: {e}")

        # -------------------------------------------------
        # STEP 4.3: Wait for index to be ready before sync
        # -------------------------------------------------
        self.logger.info("Waiting for index to be ready before sync...")
        self._index.wait_until_ready()
        self.logger.info("Index is ready")

        # -------------------------------------------------
        # STEP 4.4: Trigger sync (if not already running)
        # -------------------------------------------------
        # Log current status for debugging
        index_status = self._index.describe()['status']
        current_status = index_status.get('detailed_state', 'UNKNOWN')
        self.logger.info(f"Current index status: {current_status}")

        # Log additional details if pipeline failed
        if current_status == "ONLINE_PIPELINE_FAILED":
            status_message = index_status.get('message', 'No message available')
            self.logger.info(f"Pipeline failure details: {status_message}")
            self.logger.info(f"Full index status: {index_status}")

        # Only trigger sync if not already running (can't sync while RUNNING)
        if current_status in ["ONLINE_TRIGGERED_UPDATE", "ONLINE_UPDATING_PIPELINE_RESOURCES", "ONLINE_PIPELINE_FAILED"]:
            self.logger.info("Sync already in progress or failed. Skipping sync trigger...")
        else:
            self.logger.info("Triggering index sync (with scale-from-zero retry handling)...")
            try:
                sync_index_with_retry(
                    index=self._index,
                    embedding_endpoint_name=self._embedding_endpoint,
                    max_retries=10,
                    retry_interval_seconds=60,
                    timeout_minutes=10
                )
                self.logger.info("Index sync initiated successfully!")
            except Exception as sync_error:
                error_msg = f"ERROR: Index sync failed: {str(sync_error)}"
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

        # -------------------------------------------------
        # STEP 4.5: Tolerant wait loop for sync completion
        # -------------------------------------------------
        self.logger.info("Waiting for index to be ready and synced...")
        start_time = time.time()
        pipeline_failed_count = 0

        self._index.wait_until_ready()

        while True:
            index_status_info = self._index.describe()['status']
            status = index_status_info.get('detailed_state', 'UNKNOWN')
            self.logger.info(f"  Index status: {status}")

            # Success
            if status == "ONLINE_NO_PENDING_UPDATE":
                self.logger.info("Index is fully synced and ready.")
                break

            # Actively updating - reset timer, let it continue (no timeout while making progress)
            if status in ["ONLINE_TRIGGERED_UPDATE", "ONLINE_UPDATING_PIPELINE_RESOURCES"]:
                start_time = time.time()  # Reset timer since progress is being made
                self.logger.info("  Sync in progress, resetting timeout timer...")

            # Transient failure handling - apply timeout only when failed
            if status == "ONLINE_PIPELINE_FAILED":
                pipeline_failed_count += 1
                # Log failure details
                status_message = index_status_info.get('message', 'No message available')
                self.logger.info(f"ONLINE_PIPELINE_FAILED detected ({pipeline_failed_count}/{self.MAX_PIPELINE_FAILURES})")
                self.logger.info(f"  Failure reason: {status_message}")

                # Check timeout only when in failed state
                elapsed = time.time() - start_time
                if elapsed > self.TIMEOUT_SECONDS:
                    error_msg = f"ERROR: Index sync timed out after {int(elapsed)} seconds in failed state"
                    self.logger.info(f"{error_msg}")
                    raise TimeoutError(error_msg)

                if pipeline_failed_count >= self.MAX_PIPELINE_FAILURES:
                    error_msg = f"ERROR: Index entered ONLINE_PIPELINE_FAILED state 3 times. Last message: {status_message}"
                    self.logger.info(f"{error_msg}")
                    raise Exception(error_msg)

            time.sleep(self.POLL_INTERVAL)

    @step(order=5, name="Filter Pending Records", returns="DataFrame and count of pending records")
    def step_filter_pending_records(self) -> Dict[str, Any]:
        """Step 5: Filter records needing vector search."""
        from pyspark.sql.functions import col

        df_unified_dedup = self.spark.table(self._unified_dedup_table)

        # Golden dedup: Filter for records with empty search_results
        # (no record_status column in unified_deduplicate)
        df_pending_search = df_unified_dedup.filter(
            col("search_results") == ""
        ).select(self._master_id_key, self._merged_desc_column)

        pending_count = df_pending_search.isEmpty()

        self.logger.info(f"Unified dedup table total records: {df_unified_dedup.count()}")
        self.logger.info(f"Records pending search (empty search_results): {pending_count}")

        self._stats['pending_count'] = pending_count

        if pending_count:
            self._df_pending = None
            self._pending_count = 0
            return {'pending_count': 0, 'has_records': False}

        # Get actual row count for partitioning
        row_count = df_pending_search.count()
        self._stats['pending_count'] = row_count

        # Calculate optimal partitions
        optimal_partitions = self._get_optimal_partitions(row_count, workload_type="vs")
        self.logger.info(f"optimal_partitions: {optimal_partitions}")

        df_pending_search = df_pending_search.repartition(optimal_partitions)
        self.logger.info(f"Repartitioned to {optimal_partitions} partitions for parallel processing")

        self._df_pending = df_pending_search
        self._pending_count = row_count

        return {'pending_count': row_count, 'has_records': True}

    @step(order=6, name="Execute Vector Search", returns="DataFrame with search results")
    def step_execute_vector_search(self) -> Dict[str, Any]:
        """Step 6: Execute vector search via UDF with self-match exclusion."""
        if self._df_pending is None:
            self.logger.info("No pending records to search")
            return {'records_searched': 0}

        from pyspark.sql.functions import pandas_udf, expr
        from pyspark.sql.types import ArrayType, StructType, StructField, StringType, FloatType
        import pandas as pd
        from databricks.vector_search.client import VectorSearchClient
        from concurrent.futures import ThreadPoolExecutor, as_completed

        # Import retry function from SDK utils
        from lakefusion_core_engine.utils.model_serving import similarity_search_with_retry

        # Capture variables for UDF closure
        master_table = self.context.master_table
        merged_desc_column = self._merged_desc_column
        master_id_key = self._master_id_key
        # Request more results to account for self-match filtering
        max_potential_matches = self._max_potential_matches

        # UDF schema: returns array of struct with description, lakefusion_id, and score
        result_schema = ArrayType(StructType([
            StructField("text", StringType()),
            StructField("lakefusion_id", StringType()),
            StructField("score", FloatType())
        ]))

        client = VectorSearchClient()
        index = client.get_index(index_name=f"{master_table}_index")

        @pandas_udf(result_schema)
        def vector_search_results_udf(descriptions: pd.Series, query_ids: pd.Series) -> pd.Series:
            """
            Perform vector search for Golden Dedup - matching masters against the master index.
            Queries come from unified_dedup, but search against master_table index.
            Excludes self-matches to avoid matching a record with itself.
            Uses ThreadPoolExecutor for concurrent execution within each partition.

            Args:
                descriptions: Series of attributes_combined strings from unified_dedup
                query_ids: Series of lakefusion_ids (to exclude self-matches)

            Returns:
                Series of arrays containing top matches (excluding self) with scores
            """
            # Request extra results to account for self-match that will be filtered
            # Request n+1 to ensure we get n results after removing self-match
            num_results_requested = int(max_potential_matches) + 1

            def get_results(text, query_id):
                try:
                    # Use retry wrapper with exponential backoff
                    results = similarity_search_with_retry(
                        index,
                        query_text=text,
                        columns=[merged_desc_column, master_id_key],
                        num_results=num_results_requested
                    )

                    formatted = []
                    for r in results["result"]["data_array"]:
                        result_text = r[0]           # attributes_combined
                        result_id = r[1]             # lakefusion_id
                        result_score = float(r[2])   # similarity score

                        # CRITICAL: Skip self-matches where query_id == result_id
                        if result_id == query_id:
                            continue

                        formatted.append({
                            "text": result_text,
                            "lakefusion_id": result_id,
                            "score": result_score
                        })

                        # Stop after collecting max_potential_matches (excluding self)
                        if len(formatted) >= int(max_potential_matches):
                            break

                    return formatted

                except Exception as e:
                    print(f"Error during vector search for query_id {query_id}: {e}")
                    return []

            # Use ThreadPoolExecutor for concurrent execution within partition
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = {executor.submit(get_results, desc, qid): i
                           for i, (desc, qid) in enumerate(zip(descriptions, query_ids))}
                results = [None] * len(descriptions)
                for future in as_completed(futures):
                    results[futures[future]] = future.result()
            return pd.Series(results)

        self.logger.info("Vector search UDF defined")
        self.logger.info(f"  - Queries from: {self._unified_dedup_table}")
        self.logger.info(f"  - Searches against: {master_table} index")
        self.logger.info(f"  - Returns top {max_potential_matches} matches per record (excluding self)")
        self.logger.info(f"  - Requests {int(max_potential_matches) + 1} results to filter self-matches")
        self.logger.info(f"  - Includes: text, lakefusion_id, score")

        # Apply the UDF with both attributes_combined and lakefusion_id
        self.logger.info("Running Golden Dedup vector search (this may take a while)...")

        df_with_results = self._df_pending.withColumn(
            "search_results_array",
            vector_search_results_udf(
                self._df_pending[self._merged_desc_column],
                self._df_pending[self._master_id_key]  # Pass lakefusion_id to filter self-matches
            )
        )

        # Convert array-of-structs to a formatted string for storage
        df_with_final_results = df_with_results.withColumn(
            "search_results",
            expr("""
              concat_ws('], [', transform(search_results_array, x ->
                concat(x.text, ', ', x.lakefusion_id, ', ', cast(x.score as string))
              ))
            """).alias("search_results")
        )

        self._stats['records_searched'] = self._stats.get('pending_count', 0)
        self._df_results = df_with_final_results

        return {'records_searched': self._stats['records_searched']}

    @step(order=7, name="Deduplicate Results", returns="DataFrame with deduplicated results")
    def step_deduplicate_results(self) -> Dict[str, Any]:
        """Step 7: Deduplicate results."""
        if self._df_results is None:
            self.logger.info("No results to deduplicate")
            return {'dedup_count': 0}

        # Deduplicate by lakefusion_id (keeping first occurrence)
        df_deduplicated = self._df_results.dropDuplicates([self._master_id_key])

        self._df_deduped = df_deduplicated

        return {'status': 'deduplicated'}

    @step(order=8, name="Merge Results", returns="Merge statistics")
    def step_merge_results(self) -> Dict[str, Any]:
        """Step 8: Merge results to unified_deduplicate table."""
        if self._df_deduped is None:
            self.logger.info("No deduplicated results to merge")
            return {'records_updated': 0}

        from delta.tables import DeltaTable

        delta_table = DeltaTable.forName(self.spark, self._unified_dedup_table)

        # Perform merge operation
        delta_table.alias("target").merge(
            source=self._df_deduped.alias("source"),
            condition=f"target.{self._master_id_key} = source.{self._master_id_key}"
        ).whenMatchedUpdate(
            set={"search_results": "source.search_results"}
        ).execute()

        self._stats['records_updated'] = self._stats.get('pending_count', 0)

        return {'records_updated': self._stats['records_updated']}

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Core vector search business logic for golden dedup.

        This method is NOT overridable by end users.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Validate embedding endpoint
            self.step_validate_embedding_endpoint()

            # Step 2: Setup vector search endpoint
            self.step_setup_vs_endpoint()

            # Step 3: Wait for VS endpoint
            self.step_wait_for_vs_endpoint()

            # Step 4: Create/sync vector search index
            self.step_create_or_sync_index()

            # Step 5: Filter records for vector search (empty search_results)
            filter_result = self.step_filter_pending_records()

            if not filter_result.get('has_records', False):
                return TaskResult.skipped(
                    message="No records to process - all records already have search results",
                    task_name=self.context.task_name,
                    task_values={
                        'vector_search_complete': True,
                        'records_searched': 0
                    }
                )

            # Step 6: Execute vector search (with self-match exclusion)
            self.step_execute_vector_search()

            # Step 7: Deduplicate results
            self.step_deduplicate_results()

            # Step 8: Merge results to unified_deduplicate table
            self.step_merge_results()

            return TaskResult.success(
                message=f"Golden dedup vector search completed for {self._stats['records_searched']} records",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'vector_search_complete': True,
                    'records_searched': self._stats.get('records_searched', 0)
                },
                artifacts={
                    'unified_dedup_table': self._unified_dedup_table,
                    'master_table': self.context.master_table,
                    'index_name': self._stats.get('index_name')
                }
            )

        except Exception as e:
            raise RuntimeError(f"Golden dedup vector search failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """
        Validate the vector search results.

        Args:
            result: TaskResult from execute()

        Returns:
            TaskResult with validation results added
        """
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            records_searched = self._stats.get('records_searched', 0)
            records_updated = self._stats.get('records_updated', 0)

            validation = ValidationResult(
                passed=records_updated > 0 or records_searched == 0,
                message="Golden dedup vector search results merged to unified_deduplicate table",
                expected=records_searched,
                actual=records_updated
            )
            result.add_validation(validation)

            if not validation.passed and records_searched > 0:
                result.add_message(f"Warning: Searched {records_searched} records but only updated {records_updated}")

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """
        POST phase: Print summary.

        Can be overridden by GoldenVectorSearchExtended.post_execute()
        """
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("vector_search_complete", True)
                self.dbutils.jobs.taskValues.set(
                    "records_searched",
                    self._stats.get('records_searched', 0)
                )
            except Exception:
                pass  # Ignore if not running in a job

    # =========================================================================
    # Private helper methods (core business logic)
    # =========================================================================

    def _get_optimal_partitions(self, row_count: int, workload_type: str = "vs") -> int:
        """
        Calculate optimal partition count based on data size.

        Args:
            row_count: Total number of rows
            workload_type: "vs" for Vector Search, "merge" for Delta merge

        Returns:
            Optimal partition count
        """
        if workload_type == "vs":
            # Vector Search: tiered partitioning based on data size
            if row_count <= 500:
                target_rows, min_p, max_p = 50, 1, 10
            elif row_count <= 2000:
                target_rows, min_p, max_p = 100, 4, 20
            elif row_count <= 10000:
                target_rows, min_p, max_p = 200, 8, 50
            elif row_count <= 50000:
                target_rows, min_p, max_p = 300, 16, 166
            elif row_count <= 200000:
                target_rows, min_p, max_p = 500, 32, 400
            elif row_count <= 1000000:
                target_rows, min_p, max_p = 1000, 64, 1000
            else:
                target_rows, min_p, max_p = 2000, 128, 2000

            calculated = row_count // target_rows
            partitions = max(min_p, min(max_p, calculated))

        return partitions
