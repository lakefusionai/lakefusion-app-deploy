"""
Golden Deduplication Manual Merge Executor.

Handles manual merge operations between master records (master-to-master merge)
for golden deduplication.

Key Differences from Normal Deduplication:
    - Master-to-master merge (both records are lakefusion_ids)
    - Uses unified_deduplicate table for contributor updates
    - Uses MASTER_MANUAL_MERGE action type
    - Deletes merged master from master table
"""

import json
from datetime import datetime
from typing import Any, Dict, Optional

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult
from lakefusion_core_engine.utils.steward_decisions import write_steward_decision


class GoldenManualMergeExecutor(BaseStepTask):
    """
    Executor for Golden Deduplication Manual Merge operations.

    Contains core business logic migrated from golden_deduplication/Manual_Merge notebook.
    Handles user-initiated merges between two master records where one master
    absorbs another and the merged master is deleted.

    Key Differences from Normal ManualMergeExecutor:
        - Both master_id and match_record_id are lakefusion_ids (masters)
        - Updates unified table to reassign contributors
        - Deletes merged master from master table
        - Uses MASTER_MANUAL_MERGE action type

    External Override Support:
        Users can provide a GoldenManualMergeExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        1. Validate both masters exist
        2. Get all contributors for both masters
        3. Apply survivorship rules to merge attributes
        4. Update master table with merged attributes
        5. Delete merged master from master table
        6. Log merge activity
        7. Update attribute version sources
        8. Reassign unified contributors to survivor
        9. Verify final state
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the golden dedup manual merge task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._engine = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Step intermediate results
        self._unified_table: Optional[str] = None
        self._unified_dedup_table: Optional[str] = None
        self._merge_activities_table: Optional[str] = None
        self._attribute_version_sources_table: Optional[str] = None
        self._master_id: Optional[str] = None
        self._match_record_id: Optional[str] = None
        self._action_type: str = 'MASTER_MANUAL_MERGE'
        self._entity_attributes: list = []
        self._entity_attributes_datatype: dict = {}
        self._default_survivorship_rules: list = []
        self._dataset_objects: dict = {}
        self._match_attributes: list = []
        self._id_key: str = 'lakefusion_id'
        self._unified_id_key: str = 'surrogate_key'
        self._df_contributors = None
        self._df_final_results = None

    def pre_execute(self) -> None:
        """
        PRE phase: Validate inputs and setup survivorship engine.

        Can be overridden by GoldenManualMergeExtended.pre_execute()
        """
        self.print_header("GOLDEN DEDUP MANUAL MERGE")
        self.logger.info("GOLDEN DEDUP MANUAL MERGE")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id or 'None'}")

        # Build table names
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified"
        self._unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate"

        if self.context.experiment_id:
            self._unified_table += f"_{self.context.experiment_id}"
            self._unified_dedup_table += f"_{self.context.experiment_id}"

        self._merge_activities_table = f"{self.context.master_table}_merge_activities"
        self._attribute_version_sources_table = f"{self.context.master_table}_attribute_version_sources"

        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Unified Table: {self._unified_table}")
        self.logger.info(f"Unified Dedup Table: {self._unified_dedup_table}")
        self.logger.info(f"Merge Activities Table: {self._merge_activities_table}")
        self.logger.info(f"Attribute Version Sources Table: {self._attribute_version_sources_table}")

        # Get params
        params = self.context.params
        self._master_id = params.get('master_id')
        self._match_record_id = params.get('match_record_id')
        self._action_type = params.get('operation_type', 'MASTER_MANUAL_MERGE')
        self._entity_attributes = params.get('entity_attributes', [])
        self._entity_attributes_datatype = params.get('entity_attributes_datatype', {})
        self._default_survivorship_rules = params.get('default_survivorship_rules', [])
        self._dataset_objects = params.get('dataset_objects', {})
        self._match_attributes = params.get('match_attributes', [])

        # Parse JSON if strings
        if isinstance(self._entity_attributes, str):
            self._entity_attributes = json.loads(self._entity_attributes)
        if isinstance(self._entity_attributes_datatype, str):
            self._entity_attributes_datatype = json.loads(self._entity_attributes_datatype)
        if isinstance(self._default_survivorship_rules, str):
            self._default_survivorship_rules = json.loads(self._default_survivorship_rules)
        if isinstance(self._dataset_objects, str):
            self._dataset_objects = json.loads(self._dataset_objects)
        if isinstance(self._match_attributes, str):
            self._match_attributes = json.loads(self._match_attributes)

        self._id_key = 'lakefusion_id'
        self._unified_id_key = 'surrogate_key'

        self.logger.info(f"\nMerge Operation:")
        self.logger.info(f"  Keeping master: {self._master_id}")
        self.logger.info(f"  Merging match: {self._match_record_id}")

        # Validate required params
        if not self._master_id:
            raise ValueError("master_id is required in params")
        if not self._match_record_id:
            raise ValueError("match_record_id is required in params")

        # Setup survivorship engine
        self._setup_survivorship_engine()

        # Capture record snapshots BEFORE any modifications (both from master table)
        try:
            spark = self.context.spark
            attr_cols = ", ".join(self._entity_attributes)
            master_row = spark.sql(
                f"SELECT {attr_cols} FROM {self.context.master_table} WHERE lakefusion_id = '{self._master_id}'"
            ).collect()
            self._sd_master_attrs = master_row[0].asDict() if master_row else {}
            match_row = spark.sql(
                f"SELECT {attr_cols} FROM {self.context.master_table} WHERE lakefusion_id = '{self._match_record_id}'"
            ).collect()
            self._sd_match_attrs = match_row[0].asDict() if match_row else {}
        except Exception as e:
            self.logger.warning(f"Could not capture steward decision snapshots: {e}")
            self._sd_master_attrs = {}
            self._sd_match_attrs = {}

    @step(order=1, name="Validate Input Masters", returns="None")
    def step_validate_input_masters(self) -> None:
        """Step 1: Validate both masters exist."""
        validation_query = f"""
            SELECT {self._id_key}, COUNT(*) as cnt
            FROM {self.context.master_table}
            WHERE {self._id_key} IN ('{self._master_id}', '{self._match_record_id}')
            GROUP BY {self._id_key}
        """

        validation_result = self.spark.sql(validation_query).collect()

        if len(validation_result) != 2:
            existing_ids = [row[self._id_key] for row in validation_result]
            if self._master_id not in existing_ids:
                raise ValueError(f"Master ID {self._master_id} does not exist in master table")
            if self._match_record_id not in existing_ids:
                raise ValueError(f"Match record ID {self._match_record_id} does not exist in master table")

        self.logger.info(f"Master {self._master_id} exists")
        self.logger.info(f"Match record {self._match_record_id} exists")

    @step(order=2, name="Get All Contributors", returns="DataFrame with contributors")
    def step_get_all_contributors(self) -> Dict[str, Any]:
        """Step 2: Get all contributors for both masters."""
        from pyspark.sql.functions import col

        attrs_select = ', '.join([f'u.{attr}' for attr in self._entity_attributes])

        all_contributors_query = f"""
            SELECT
                u.master_{self._id_key},
                u.{self._unified_id_key},
                u.source_path,
                {attrs_select}
            FROM {self._unified_table} u
            WHERE u.master_{self._id_key} IN ('{self._master_id}', '{self._match_record_id}')
                AND u.record_status != 'DELETED'
            ORDER BY u.master_{self._id_key}, u.{self._unified_id_key}
        """

        self._df_contributors = self.spark.sql(all_contributors_query)
        total_contributors = self._df_contributors.count()

        self.logger.info(f"Found {total_contributors} total contributors")

        self._stats['total_contributors'] = total_contributors

        return {'total_contributors': total_contributors}

    @step(order=3, name="Apply Survivorship Engine", returns="DataFrame with merged results")
    def step_apply_survivorship(self) -> Dict[str, Any]:
        """Step 3: Apply survivorship engine."""
        if self._df_contributors is None:
            self.logger.info("No contributors to process")
            return {'status': 'no_data'}

        from pyspark.sql.functions import col, lit, collect_list, struct, udf
        from pyspark.sql.types import StructType, StructField, MapType, StringType, ArrayType

        engine = self._engine

        def apply_survivorship_wrapper(unified_records):
            records_list = [r.asDict() for r in unified_records]
            result = engine.apply_survivorship(unified_records=records_list)
            return result.to_dict()

        udf_output_schema = StructType([
            StructField("resultant_record", MapType(StringType(), StringType())),
            StructField("resultant_master_attribute_source_mapping", ArrayType(StructType([
                StructField("attribute_name", StringType()),
                StructField("attribute_value", StringType()),
                StructField("source", StringType())
            ])))
        ])

        survivorship_udf = udf(apply_survivorship_wrapper, udf_output_schema)

        # Group all contributors together under the survivor master
        grouped_contributors = (
            self._df_contributors
            .groupBy(lit(self._master_id).alias(self._id_key))
            .agg(
                collect_list(
                    struct([col(c) for c in self._df_contributors.columns if c != f"master_{self._id_key}"])
                ).alias("unified_records")
            )
        )

        # Apply survivorship UDF
        result_df = grouped_contributors.withColumn(
            "survivorship_result",
            survivorship_udf(col("unified_records"))
        )

        # Extract results
        self._df_final_results = result_df.select(
            col(self._id_key),
            col("survivorship_result.resultant_record").alias("merged_record"),
            col("survivorship_result.resultant_master_attribute_source_mapping").alias("attribute_sources")
        )

        self.logger.info(f"Survivorship applied to master {self._master_id}")

        return {'status': 'completed'}

    @step(order=4, name="Update Master Table", returns="Update statistics")
    def step_update_master_table(self) -> Dict[str, Any]:
        """Step 4: Update master table."""
        if self._df_final_results is None:
            self.logger.info("No final results to update")
            return {'status': 'no_data'}

        from delta.tables import DeltaTable
        from pyspark.sql.functions import col, coalesce, lit, concat_ws

        from lakefusion_core_engine.utils import merged_record_column

        # Prepare master updates with proper type casting
        master_updates_cols = [col(self._id_key)]

        for attr in self._entity_attributes:
            if attr == self._id_key:
                continue

            target_type = self._entity_attributes_datatype.get(attr, "string")
            master_updates_cols.append(merged_record_column(attr, target_type))

        # Add attributes_combined
        if self._match_attributes:
            concat_cols = []
            for attr in self._match_attributes:
                if attr in self._entity_attributes and attr != self._id_key:
                    concat_cols.append(coalesce(col(f"merged_record.{attr}").cast("string"), lit("")))

            if concat_cols:
                master_updates_cols.append(concat_ws(" | ", *concat_cols).alias("attributes_combined"))
            else:
                master_updates_cols.append(lit("").alias("attributes_combined"))
        else:
            master_updates_cols.append(lit("").alias("attributes_combined"))

        master_updates_df = self._df_final_results.select(*master_updates_cols)

        # Update master table
        master_delta = DeltaTable.forName(self.spark, self.context.master_table)

        master_delta.alias("target").merge(
            source=master_updates_df.alias("source"),
            condition=f"target.{self._id_key} = source.{self._id_key}"
        ).whenMatchedUpdateAll().execute()

        self.logger.info(f"Updated master {self._master_id} with merged attributes")

        return {'status': 'updated'}

    @step(order=5, name="Delete Merged Master", returns="Delete statistics")
    def step_delete_merged_master(self) -> Dict[str, Any]:
        """Step 5: Delete merged master from master table."""
        from delta.tables import DeltaTable

        master_delta = DeltaTable.forName(self.spark, self.context.master_table)
        master_delta.delete(f"{self._id_key} = '{self._match_record_id}'")

        self.logger.info(f"Deleted match record {self._match_record_id} from master table")

        return {'status': 'deleted'}

    @step(order=6, name="Log Merge Activity", returns="Log statistics")
    def step_log_merge_activity(self) -> Dict[str, Any]:
        """Step 6: Log merge activity."""
        from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType

        master_table_version = self.spark.sql(
            f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1"
        ).collect()[0]["version"]

        self._stats['master_table_version'] = master_table_version

        merge_activities = [{
            "master_id": self._master_id,
            "match_id": self._match_record_id,
            "source": "",
            "version": master_table_version,
            "action_type": self._action_type,
            "created_at": datetime.now()
        }]

        merge_activities_schema = StructType([
            StructField("master_id", StringType(), True),
            StructField("match_id", StringType(), True),
            StructField("source", StringType(), True),
            StructField("version", IntegerType(), False),
            StructField("action_type", StringType(), False),
            StructField("created_at", TimestampType(), False)
        ])

        df_merge_activities = self.spark.createDataFrame(merge_activities, schema=merge_activities_schema)
        df_merge_activities.write.mode("append").saveAsTable(self._merge_activities_table)

        self.logger.info(f"Logged merge activity with version {master_table_version}")

        return {'version': master_table_version}

    @step(order=7, name="Update Attribute Version Sources", returns="Update statistics")
    def step_update_attribute_version_sources(self) -> Dict[str, Any]:
        """Step 7: Update attribute version sources."""
        if self._df_final_results is None:
            self.logger.info("No final results to update")
            return {'status': 'no_data'}

        from pyspark.sql.functions import col, lit

        attribute_sources_df = self._df_final_results.select(
            col(self._id_key).alias("lakefusion_id"),
            lit(self._stats['master_table_version']).cast("integer").alias("version"),
            col("attribute_sources").alias("attribute_source_mapping")
        )

        attribute_sources_df.write.mode("append").saveAsTable(self._attribute_version_sources_table)

        self.logger.info(f"Logged attribute version sources for master {self._master_id}")

        return {'status': 'updated'}

    @step(order=8, name="Reassign Unified Contributors", returns="Reassignment statistics")
    def step_reassign_unified_contributors(self) -> Dict[str, Any]:
        """Step 8: Reassign unified contributors to survivor."""
        if self._df_contributors is None:
            self.logger.info("No contributors to reassign")
            return {'contributors_reassigned': 0}

        from delta.tables import DeltaTable
        from pyspark.sql.functions import col, lit

        unified_updates_df = self._df_contributors.select(
            col(self._unified_id_key),
            lit(self._master_id).alias("new_master_id")
        )

        updates_count = unified_updates_df.count()

        unified_delta = DeltaTable.forName(self.spark, self._unified_table)

        unified_delta.alias("target").merge(
            source=unified_updates_df.alias("source"),
            condition=f"target.{self._unified_id_key} = source.{self._unified_id_key}"
        ).whenMatchedUpdate(
            set={f"master_{self._id_key}": "source.new_master_id"}
        ).execute()

        self.logger.info(f"Updated {updates_count} unified records to point to master {self._master_id}")

        self._stats['contributors_reassigned'] = updates_count

        return {'contributors_reassigned': updates_count}

    @step(order=9, name="Verify Final State", returns="Verification statistics")
    def step_verify_final_state(self) -> Dict[str, Any]:
        """Step 9: Verify final state."""
        # Verify master exists
        final_master_check = self.spark.sql(f"""
            SELECT COUNT(*) as cnt
            FROM {self.context.master_table}
            WHERE {self._id_key} = '{self._master_id}'
        """).collect()[0]["cnt"]

        # Verify match deleted
        match_deleted_check = self.spark.sql(f"""
            SELECT COUNT(*) as cnt
            FROM {self.context.master_table}
            WHERE {self._id_key} = '{self._match_record_id}'
        """).collect()[0]["cnt"]

        # Verify contributors point to master
        final_contributors = self.spark.sql(f"""
            SELECT COUNT(*) as cnt
            FROM {self._unified_table}
            WHERE master_{self._id_key} = '{self._master_id}'
                AND record_status != 'DELETED'
        """).collect()[0]["cnt"]

        # Verify merge activity was logged
        merge_activity_logged = self.spark.sql(f"""
            SELECT COUNT(*) as cnt
            FROM {self._merge_activities_table}
            WHERE master_id = '{self._master_id}'
                AND match_id = '{self._match_record_id}'
                AND version = {self._stats['master_table_version']}
        """).collect()[0]["cnt"]

        self.logger.info(f"  Master {self._master_id} exists: {final_master_check == 1}")
        self.logger.info(f"  Match {self._match_record_id} deleted: {match_deleted_check == 0}")
        self.logger.info(f"  Total contributors for master: {final_contributors}")
        self.logger.info(f"  Merge activity logged: {merge_activity_logged == 1}")

        self._stats['merge_verified'] = (final_master_check == 1) and (match_deleted_check == 0) and (merge_activity_logged == 1)
        self._stats['final_contributor_count'] = final_contributors

        return {
            'master_exists': final_master_check == 1,
            'match_deleted': match_deleted_check == 0,
            'final_contributors': final_contributors,
            'activity_logged': merge_activity_logged == 1,
            'verified': self._stats['merge_verified']
        }

    @step(order=10, name="Write Steward Decision", returns="decision_id")
    def step_write_steward_decision(self) -> Dict[str, Any]:
        """Write frozen record snapshots to steward_decisions Delta table."""
        decision_id = write_steward_decision(
            spark=self.context.spark, catalog_name=self.context.catalog_name,
            entity_name=self.context.entity, entity_id=str(self.context.entity_id or ""),
            action_type=self._action_type, master_id=self._master_id,
            match_id=self._match_record_id,
            master_attrs=getattr(self, '_sd_master_attrs', {}),
            match_attrs=getattr(self, '_sd_match_attrs', {}),
            created_by=self.context.params.get("created_by", ""),
            logger=self.logger,
        )
        return {"decision_id": decision_id}

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Core manual merge business logic for golden dedup.

        This method is NOT overridable by end users.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Validate input masters exist
            self.step_validate_input_masters()

            # Step 2: Get all contributors for both masters
            self.step_get_all_contributors()

            # Step 3: Apply survivorship engine
            self.step_apply_survivorship()

            # Step 4: Update master table
            self.step_update_master_table()

            # Step 5: Delete merged master from master table
            self.step_delete_merged_master()

            # Step 6: Log merge activity
            self.step_log_merge_activity()

            # Step 7: Update attribute version sources
            self.step_update_attribute_version_sources()

            # Step 8: Reassign unified contributors
            self.step_reassign_unified_contributors()

            # Step 9: Verify final state
            self.step_verify_final_state()

            # Step 10: Write steward decision
            self.step_write_steward_decision()

            return TaskResult.success(
                message=f"Golden dedup manual merge completed: {self._master_id} absorbed {self._match_record_id}",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'manual_merge_complete': True,
                    'master_id': self._master_id,
                    'merged_id': self._match_record_id
                },
                artifacts={
                    'master_table': self.context.master_table,
                    'version': self._stats.get('master_table_version')
                }
            )

        except Exception as e:
            raise RuntimeError(f"Golden dedup manual merge failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the manual merge results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            validation = ValidationResult(
                passed=self._stats.get('merge_verified', False),
                message=f"Master {self._master_id} successfully absorbed {self._match_record_id}",
                expected=1,
                actual=1 if self._stats.get('merge_verified') else 0
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("manual_merge_complete", True)
                self.dbutils.jobs.taskValues.set("master_id", self._master_id)
                self.dbutils.jobs.taskValues.set("merged_id", self._match_record_id)
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _setup_survivorship_engine(self) -> None:
        """Setup survivorship engine with dataset path mapping."""
        from lakefusion_core_engine.survivorship import SurvivorshipEngine

        self._engine = SurvivorshipEngine(
            survivorship_config=self._default_survivorship_rules,
            entity_attributes=self._entity_attributes,
            entity_attributes_datatype=self._entity_attributes_datatype,
            id_key=self._unified_id_key
        )

        self.logger.info("Survivorship Engine initialized")
