"""
Golden Deduplication Manual Not Match Executor.

Handles manual not-a-match operations between master records
for golden deduplication. Marks two masters as not a match
to exclude them from future matching.

Key Differences from Normal Deduplication:
    - Master-to-master not-a-match (both records are lakefusion_ids)
    - Uses MANUAL_NOT_A_MATCH action type
    - Empty source field (for master-to-master operations)
"""

import json
from datetime import datetime
from typing import Any, Dict, Optional

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult
from lakefusion_core_engine.utils.steward_decisions import write_steward_decision


class GoldenManualNotMatchExecutor(BaseStepTask):
    """
    Executor for Golden Deduplication Manual Not Match operations.

    Contains core business logic migrated from golden_deduplication/Manual_Not_Match notebook.
    Handles user-initiated marking of two master records as not a match,
    which excludes them from future matching considerations.

    Key Differences from Normal ManualNotMatchExecutor:
        - Both master_id and match_record_id are lakefusion_ids (masters)
        - Empty source field in merge_activities
        - Uses MANUAL_NOT_A_MATCH action type

    External Override Support:
        Users can provide a GoldenManualNotMatchExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        1. Validate both masters exist
        2. Check if pair is already marked as not a match
        3. Log MANUAL_NOT_A_MATCH activity
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the golden dedup manual not match task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}

        # Step intermediate results
        self._merge_activities_table: Optional[str] = None
        self._master_id: Optional[str] = None
        self._match_record_id: Optional[str] = None
        self._action_type: str = 'MANUAL_NOT_A_MATCH'
        self._id_key: str = 'lakefusion_id'
        self._is_duplicate: bool = False
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """
        PRE phase: Validate inputs.

        Can be overridden by GoldenManualNotMatchExtended.pre_execute()
        """
        self.print_header("GOLDEN DEDUP MANUAL NOT A MATCH")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id or 'None'}")

        # Build table names
        self._merge_activities_table = f"{self.context.master_table}_merge_activities"

        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Merge Activities Table: {self._merge_activities_table}")

        # Get params
        params = self.context.params
        self._master_id = params.get('master_id')
        self._match_record_id = params.get('match_record_id')
        self._action_type = params.get('action_type', 'MANUAL_NOT_A_MATCH')

        self._id_key = 'lakefusion_id'

        self.logger.info(f"\nOperation:")
        self.logger.info(f"  Master: {self._master_id}")
        self.logger.info(f"  Rejecting match: {self._match_record_id}")

        # Validate required params
        if not self._master_id:
            raise ValueError("master_id is required in params")
        if not self._match_record_id:
            raise ValueError("match_record_id is required in params")

        # Capture record snapshots BEFORE any modifications (both from master table)
        try:
            entity_attributes = params.get('entity_attributes', [])
            if isinstance(entity_attributes, str):
                import json as _json
                entity_attributes = _json.loads(entity_attributes)
            if entity_attributes:
                attr_cols = ", ".join(entity_attributes)
                master_row = self.spark.sql(
                    f"SELECT {attr_cols} FROM {self.context.master_table} WHERE lakefusion_id = '{self._master_id}'"
                ).collect()
                self._sd_master_attrs = master_row[0].asDict() if master_row else {}
                match_row = self.spark.sql(
                    f"SELECT {attr_cols} FROM {self.context.master_table} WHERE lakefusion_id = '{self._match_record_id}'"
                ).collect()
                self._sd_match_attrs = match_row[0].asDict() if match_row else {}
            else:
                self._sd_master_attrs = {}
                self._sd_match_attrs = {}
        except Exception as e:
            self.logger.warning(f"Could not capture steward decision snapshots: {e}")
            self._sd_master_attrs = {}
            self._sd_match_attrs = {}

    @step(order=1, name="Validate Both Masters Exist", returns="None")
    def step_validate_both_masters_exist(self) -> None:
        """Step 1: Validate both masters exist."""
        validation_query = f"""
            SELECT {self._id_key}, COUNT(*) as cnt
            FROM {self.context.master_table}
            WHERE {self._id_key} IN ('{self._master_id}', '{self._match_record_id}')
            GROUP BY {self._id_key}
        """

        validation_result = self.spark.sql(validation_query).collect()

        if len(validation_result) != 2:
            existing_ids = [row[self._id_key] for row in validation_result]
            if self._master_id not in existing_ids:
                error_msg = f"Master ID {self._master_id} does not exist in master table"
                self.logger.info(f"ERROR: {error_msg}")
                raise ValueError(error_msg)
            if self._match_record_id not in existing_ids:
                error_msg = f"Match record ID {self._match_record_id} does not exist in master table"
                self.logger.info(f"ERROR: {error_msg}")
                raise ValueError(error_msg)

        self.logger.info(f"Master {self._master_id} exists")
        self.logger.info(f"Match record {self._match_record_id} exists")
        self.logger.info(f"Both records validated")

    @step(order=2, name="Check Existing Not Match", returns="Dict with duplicate status")
    def step_check_existing_not_match(self) -> Dict[str, Any]:
        """Step 2: Check if pair is already marked as not a match."""
        existing_not_match_query = f"""
            SELECT COUNT(*) as cnt
            FROM {self._merge_activities_table}
            WHERE master_id = '{self._master_id}'
                AND match_id = '{self._match_record_id}'
                AND action_type = '{self._action_type}'
        """

        existing_count = self.spark.sql(existing_not_match_query).collect()[0]['cnt']

        if existing_count > 0:
            self.logger.info(f"WARNING: This pair is already marked as NOT A MATCH")
            self.logger.info(f"  Existing entries: {existing_count}")
            self.logger.info(f"  Will skip logging to avoid duplicates")
            self._is_duplicate = True
            return {'is_duplicate': True, 'existing_count': existing_count}

        self.logger.info(f"Pair not previously marked as NOT A MATCH")
        self._is_duplicate = False
        return {'is_duplicate': False, 'existing_count': 0}

    @step(order=3, name="Log Not Match Activity", returns="Log statistics")
    def step_log_not_match_activity(self) -> Dict[str, Any]:
        """Step 3: Log MANUAL_NOT_A_MATCH activity."""
        if self._is_duplicate:
            self.logger.info("Skipping logging - pair already marked as NOT A MATCH")
            return {'status': 'skipped', 'logged': False}

        from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType

        master_table_version = self.spark.sql(
            f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1"
        ).collect()[0]["version"]

        self.logger.info(f"Master table current version: {master_table_version}")

        # For golden dedup (master-to-master), source is empty string
        not_match_activity = [{
            "master_id": self._master_id,
            "match_id": self._match_record_id,
            "source": "",
            "version": master_table_version,
            "action_type": self._action_type,
            "created_at": datetime.now()
        }]

        not_match_schema = StructType([
            StructField("master_id", StringType(), True),
            StructField("match_id", StringType(), True),
            StructField("source", StringType(), True),
            StructField("version", IntegerType(), True),
            StructField("action_type", StringType(), False),
            StructField("created_at", TimestampType(), False)
        ])

        df_not_match_activity = self.spark.createDataFrame(not_match_activity, schema=not_match_schema)

        self.logger.info(f"  Prepared MANUAL_NOT_A_MATCH activity")
        self.logger.info(f"    Master: {self._master_id}")
        self.logger.info(f"    Match: {self._match_record_id}")

        df_not_match_activity.write.mode("append").saveAsTable(self._merge_activities_table)

        self.logger.info(f"MANUAL_NOT_A_MATCH activity logged")

        self._stats['logged'] = True
        self._stats['master_table_version'] = master_table_version

        return {'status': 'logged', 'logged': True, 'version': master_table_version}

    @step(order=4, name="Write Steward Decision", returns="decision_id")
    def step_write_steward_decision(self) -> Dict[str, Any]:
        """Write frozen record snapshots to steward_decisions Delta table."""
        decision_id = write_steward_decision(
            spark=self.spark, catalog_name=self.context.catalog_name,
            entity_name=self.context.entity, entity_id=str(self.context.entity_id or ""),
            action_type="MANUAL_NOT_A_MATCH", master_id=self._master_id,
            match_id=self._match_record_id,
            master_attrs=getattr(self, '_sd_master_attrs', {}),
            match_attrs=getattr(self, '_sd_match_attrs', {}),
            created_by=self.context.params.get("created_by", ""),
            logger=self.logger,
        )
        return {"decision_id": decision_id}

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Core manual not match business logic for golden dedup.

        This method is NOT overridable by end users.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Validate both masters exist
            self.step_validate_both_masters_exist()

            # Step 2: Check if already marked as not a match
            check_result = self.step_check_existing_not_match()

            if check_result.get('is_duplicate', False):
                return TaskResult.skipped(
                    message=f"Pair already marked as NOT A MATCH",
                    task_name=self.context.task_name,
                    task_values={
                        'manual_not_match_complete': True,
                        'skipped': True
                    }
                )

            # Step 3: Log manual not a match activity
            self.step_log_not_match_activity()

            # Step 4: Write steward decision
            self.step_write_steward_decision()

            return TaskResult.success(
                message=f"Golden dedup manual not match completed: {self._master_id} and {self._match_record_id} marked as NOT A MATCH",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'manual_not_match_complete': True,
                    'master_id': self._master_id,
                    'match_record_id': self._match_record_id
                },
                artifacts={
                    'master_table': self.context.master_table,
                    'merge_activities_table': self._merge_activities_table
                }
            )

        except Exception as e:
            raise RuntimeError(f"Golden dedup manual not match failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the manual not match results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            validation = ValidationResult(
                passed=self._stats.get('logged', False),
                message=f"NOT A MATCH logged for {self._master_id} and {self._match_record_id}",
                expected=1,
                actual=1 if self._stats.get('logged') else 0
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("manual_not_match_complete", True)
            except Exception:
                pass
