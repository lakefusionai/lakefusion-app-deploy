"""
Golden Deduplication Process Auto Merge Executor.

Processes auto-merge operations for high-confidence matches between
master records for golden deduplication.

Key Differences from Normal Deduplication:
    - Master-to-master merging
    - Uses unified_deduplicate and processed_unified_deduplicate tables
    - Uses MASTER_JOB_MERGE action type
    - Handles transitive merge relationships (connected components)
"""

import json
from datetime import datetime
from typing import Any, Dict

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class GoldenProcessAutoMergeExecutor(BaseStepTask):
    """
    Executor for Golden Deduplication Process Auto Merge operations.

    Contains core business logic migrated from golden_deduplication/Process_Auto_Merge notebook.
    Automatically merges master records that have been classified as MATCH
    with high confidence, using survivorship rules to determine attribute values.

    Key Differences from Normal ProcessAutoMergeExecutor:
        - Master-to-master merging (deletes merged masters)
        - Uses connected components algorithm for transitive matches
        - Uses MASTER_JOB_MERGE action type
        - Filters existing merge relationships to avoid duplicates

    External Override Support:
        Users can provide a GoldenProcessAutoMergeExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        1. Filter MATCH records from processed_unified_deduplicate
        2. Build undirected graph (bidirectional matches)
        3. Find connected components (transitive grouping)
        4. Select survivor for each group
        5. Get all contributors for each group
        6. Apply survivorship engine
        7. Update master table
        8. Delete merged masters
        9. Log merge activities
        10. Update attribute version sources
        11. Reassign unified contributors
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the golden dedup process auto merge task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._engine = None

        # Step intermediate results
        self._df_matches = None
        self._match_count = 0
        self._already_merged_count = 0
        self._df_edges = None
        self._df_components = None
        self._num_components = 0
        self._df_survivors = None
        self._df_merge_plan = None
        self._records_to_merge = 0
        self._df_combined_contributors = None
        self._df_final_results = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """
        PRE phase: Validate inputs and setup survivorship engine.

        Can be overridden by GoldenProcessAutoMergeExtended.pre_execute()
        """
        self.print_header("GOLDEN DEDUP - AUTO MERGE PROCESSING")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id or 'None'}")

        # Build table names
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified"
        self._unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate"
        self._processed_unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_processed_unified_deduplicate"

        if self.context.experiment_id:
            self._unified_table += f"_{self.context.experiment_id}"
            self._unified_dedup_table += f"_{self.context.experiment_id}"
            self._processed_unified_dedup_table += f"_{self.context.experiment_id}"

        self._merge_activities_table = f"{self.context.master_table}_merge_activities"
        self._attribute_version_sources_table = f"{self.context.master_table}_attribute_version_sources"

        self.logger.info(f"Unified Table: {self._unified_table}")
        self.logger.info(f"Unified Dedup Table: {self._unified_dedup_table}")
        self.logger.info(f"Processed Unified Dedup Table: {self._processed_unified_dedup_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Merge Activities Table: {self._merge_activities_table}")
        self.logger.info(f"Attribute Version Sources Table: {self._attribute_version_sources_table}")

        # Get params
        params = self.context.params
        self._entity_attributes = params.get('entity_attributes', [])
        self._entity_attributes_datatype = params.get('entity_attributes_datatype', {})
        self._default_survivorship_rules = params.get('default_survivorship_rules', [])
        self._dataset_objects = params.get('dataset_objects', {})
        self._match_attributes = params.get('match_attributes', [])

        # Parse JSON if strings
        if isinstance(self._entity_attributes, str):
            self._entity_attributes = json.loads(self._entity_attributes)
        if isinstance(self._entity_attributes_datatype, str):
            self._entity_attributes_datatype = json.loads(self._entity_attributes_datatype)
        if isinstance(self._default_survivorship_rules, str):
            self._default_survivorship_rules = json.loads(self._default_survivorship_rules)
        if isinstance(self._dataset_objects, str):
            self._dataset_objects = json.loads(self._dataset_objects)
        if isinstance(self._match_attributes, str):
            self._match_attributes = json.loads(self._match_attributes)

        self._id_key = 'lakefusion_id'
        self._unified_id_key = 'surrogate_key'

        # Setup survivorship engine
        self._setup_survivorship_engine()

    @step(order=1, name="Filter Match Records", returns="df_matches, match_count, already_merged_count")
    def step_filter_match_records(self) -> None:
        """Step 1: Filter MATCH records from processed_unified_deduplicate."""
        self._df_matches, self._match_count, self._already_merged_count = self._filter_match_records()

    @step(order=2, name="Build Undirected Graph", returns="df_edges")
    def step_build_undirected_graph(self) -> None:
        """Step 2: Build undirected graph from matches."""
        self._df_edges = self._build_undirected_graph(self._df_matches)

    @step(order=3, name="Find Connected Components", returns="df_components, num_components")
    def step_find_connected_components(self) -> None:
        """Step 3: Find connected components using GraphFrames or Union-Find fallback."""
        self._df_components, self._num_components = self._find_connected_components(self._df_edges)

    @step(order=4, name="Select Survivors", returns="df_survivors")
    def step_select_survivors(self) -> None:
        """Step 4: Select survivor for each group."""
        self._df_survivors = self._select_survivors(self._df_components)

    @step(order=5, name="Identify Merge Records", returns="df_merge_plan, records_to_merge")
    def step_identify_merge_records(self) -> None:
        """Step 5: Identify records to be merged (non-survivors)."""
        self._df_merge_plan, self._records_to_merge = self._identify_merge_records(self._df_components, self._df_survivors)

    @step(order=6, name="Get All Contributors", returns="df_combined_contributors")
    def step_get_all_contributors(self) -> None:
        """Step 6: Get all contributors for each group."""
        self._df_combined_contributors = self._get_all_contributors(self._df_merge_plan, self._df_survivors)

    @step(order=7, name="Apply Survivorship", returns="df_final_results")
    def step_apply_survivorship(self) -> None:
        """Step 7: Apply survivorship engine."""
        self._df_final_results = self._apply_survivorship(self._df_combined_contributors)

    @step(order=8, name="Update Master Table", returns="None")
    def step_update_master_table(self) -> None:
        """Step 8: Update master table with merged records."""
        self._update_master_table(self._df_final_results)

    @step(order=9, name="Delete Merged Masters", returns="None")
    def step_delete_merged_masters(self) -> None:
        """Step 9: Delete merged records from master table."""
        self._delete_merged_masters(self._df_merge_plan)

    @step(order=10, name="Log Merge Activities", returns="None")
    def step_log_merge_activities(self) -> None:
        """Step 10: Log merge activities."""
        self._log_merge_activities(self._df_merge_plan)

    @step(order=11, name="Update Attribute Version Sources", returns="None")
    def step_update_attribute_version_sources(self) -> None:
        """Step 11: Update attribute version sources."""
        self._update_attribute_version_sources(self._df_final_results)

    @step(order=12, name="Reassign Unified Contributors", returns="None")
    def step_reassign_unified_contributors(self) -> None:
        """Step 12: Reassign unified contributors to survivors."""
        self._reassign_unified_contributors(self._df_combined_contributors, self._df_survivors)

    @step(order=13, name="Verify Final State", returns="None")
    def step_verify_final_state(self) -> None:
        """Step 13: Verify final state."""
        self._verify_final_state(self._num_components, self._records_to_merge)

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Core auto merge business logic for golden dedup.

        This method is NOT overridable by end users.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Filter MATCH records
            self.step_filter_match_records()

            if self._match_count == 0:
                return TaskResult.skipped(
                    message=f"No NEW MATCH records to process - {self._already_merged_count} pairs already merged",
                    task_name=self.context.task_name,
                    task_values={
                        'auto_merge_complete': True,
                        'records_merged': 0,
                        'already_merged_skipped': self._already_merged_count
                    }
                )

            # Step 2: Build undirected graph
            self.step_build_undirected_graph()

            # Step 3: Find connected components
            self.step_find_connected_components()

            # Step 4: Select survivor for each group
            self.step_select_survivors()

            # Step 5: Identify records to merge
            self.step_identify_merge_records()

            if self._records_to_merge == 0:
                return TaskResult.skipped(
                    message="All groups have only 1 member - nothing to merge",
                    task_name=self.context.task_name,
                    task_values={
                        'auto_merge_complete': True,
                        'records_merged': 0
                    }
                )

            # Step 6: Get all contributors
            self.step_get_all_contributors()

            # Step 7: Apply survivorship
            self.step_apply_survivorship()

            # Step 8: Update master table
            self.step_update_master_table()

            # Step 9: Delete merged masters
            self.step_delete_merged_masters()

            # Step 10: Log merge activities
            self.step_log_merge_activities()

            # Step 11: Update attribute version sources
            self.step_update_attribute_version_sources()

            # Step 12: Reassign unified contributors
            self.step_reassign_unified_contributors()

            # Step 13: Verify final state
            self.step_verify_final_state()

            return TaskResult.success(
                message=f"Golden dedup auto merge completed: {self._records_to_merge} records merged into {self._num_components} survivors",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'auto_merge_complete': True,
                    'records_merged': self._records_to_merge,
                    'groups_processed': self._num_components,
                    'survivors_count': self._stats.get('survivor_count', 0)
                },
                artifacts={
                    'master_table': self.context.master_table,
                    'version': self._stats.get('master_table_version')
                }
            )

        except Exception as e:
            raise RuntimeError(f"Golden dedup auto merge failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the auto merge results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            validation = ValidationResult(
                passed=True,
                message=f"Auto merge completed: {self._stats.get('records_to_merge', 0)} merged",
                expected=self._stats.get('records_to_merge', 0),
                actual=self._stats.get('records_to_merge', 0)
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("auto_merge_complete", True)
                self.dbutils.jobs.taskValues.set("records_merged", self._stats.get('records_to_merge', 0))
                self.dbutils.jobs.taskValues.set("groups_processed", self._stats.get('num_components', 0))
                self.dbutils.jobs.taskValues.set("survivors_count", self._stats.get('survivor_count', 0))
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _setup_survivorship_engine(self) -> None:
        """Setup survivorship engine with dataset path mapping."""
        from lakefusion_core_engine.survivorship import SurvivorshipEngine

        self._engine = SurvivorshipEngine(
            survivorship_config=self._default_survivorship_rules,
            entity_attributes=self._entity_attributes,
            entity_attributes_datatype=self._entity_attributes_datatype,
            id_key=self._unified_id_key
        )

        self.logger.info("Survivorship Engine initialized")

    def _resolve_master_lineage(self):
        """Build absorbed->surviving closure from MASTER_*_MERGE history.

        Returns a function canon(lf_id) that walks the lineage to the current
        canonical surviving master lf_id. A master may have been absorbed
        multiple times in a chain; canon walks until fixed point.
        """
        df_chain = self.spark.sql(f"""
            SELECT match_id AS absorbed, master_id AS surviving
            FROM {self._merge_activities_table}
            WHERE action_type IN ('MASTER_JOB_MERGE', 'MASTER_MANUAL_MERGE', 'MASTER_FORCE_MERGE')
        """)

        pairs = {r['absorbed']: r['surviving'] for r in df_chain.collect()}

        def canon(lf_id):
            seen = set()
            cur = lf_id
            while cur in pairs and cur not in seen:
                seen.add(cur)
                cur = pairs[cur]
            return cur

        return canon

    def _get_blocked_master_pairs(self):
        """Compute master-pair blocks derived from MANUAL_UNMERGE history.

        For every MANUAL_UNMERGE row (former_master_id, unmerged_sk):
          - resolve former_master_id to its current canonical via master lineage
          - find current master of unmerged_sk in unified_table
        The resulting (canonical_former, current_master_of_sk) pair must never
        be auto-merged.
        """
        from pyspark.sql.functions import col, udf
        from pyspark.sql.types import StringType

        df_unmerge_with_current_master = self.spark.sql(f"""
            SELECT
                ma.master_id AS former_master_id,
                u.master_{self._id_key} AS current_master_of_sk
            FROM {self._merge_activities_table} ma
            JOIN {self._unified_table} u
              ON u.{self._unified_id_key} = ma.match_id
            WHERE ma.action_type = 'MANUAL_UNMERGE'
              AND u.record_status != 'DELETED'
              AND u.master_{self._id_key} IS NOT NULL
        """)

        canon = self._resolve_master_lineage()
        canon_udf = udf(canon, StringType())

        df_blocked = (
            df_unmerge_with_current_master
            .withColumn("master_a", canon_udf(col("former_master_id")))
            .withColumnRenamed("current_master_of_sk", "master_b")
            .select("master_a", "master_b")
            .filter(col("master_a").isNotNull() & col("master_b").isNotNull())
            .filter(col("master_a") != col("master_b"))
            .distinct()
        )

        return df_blocked

    def _filter_match_records(self):
        """Step 1: Filter MATCH records from processed_unified_deduplicate."""
        self.print_header("STEP 1: FILTER MATCH RECORDS FROM PROCESSED_UNIFIED_DEDUP")

        from pyspark.sql.functions import col

        # Get all MATCH records
        df_all_matches = self.spark.sql(f"""
            SELECT
                query_{self._id_key},
                match_{self._id_key},
                exploded_result.score as match_score,
                exploded_result.reason as match_reason
            FROM {self._processed_unified_dedup_table}
            WHERE exploded_result.match = 'MATCH'
        """)

        total_match_count = df_all_matches.count()
        self.logger.info(f"  Total MATCH records in processed_unified_dedup: {total_match_count}")

        # Get existing merge relationships
        df_existing_merges = self.spark.sql(f"""
            SELECT DISTINCT master_id, match_id
            FROM {self._merge_activities_table}
            WHERE action_type IN ('MASTER_JOB_MERGE', 'MASTER_MANUAL_MERGE', 'MASTER_FORCE_MERGE')
        """)

        existing_merge_count = df_existing_merges.count()
        self.logger.info(f"  Existing merge relationships: {existing_merge_count}")

        # Filter out pairs that already exist
        df_matches = df_all_matches.alias("m").join(
            df_existing_merges.alias("e"),
            on=(
                ((col(f"m.query_{self._id_key}") == col("e.master_id")) & (col(f"m.match_{self._id_key}") == col("e.match_id"))) |
                ((col(f"m.query_{self._id_key}") == col("e.match_id")) & (col(f"m.match_{self._id_key}") == col("e.master_id")))
            ),
            how="left_anti"
        )

        after_existing_merge_filter_count = df_matches.count()
        already_merged_count = total_match_count - after_existing_merge_filter_count

        self.logger.info(f"  Already merged pairs (skipped): {already_merged_count}")

        # Block pairs that violate MANUAL_UNMERGE history (any contributor SK on
        # either side has an unmerge relationship with the other master, after
        # walking master lineage).
        df_blocked_pairs = self._get_blocked_master_pairs()
        blocked_pair_count = df_blocked_pairs.count()
        self.logger.info(f"  Blocked master-pairs from MANUAL_UNMERGE history: {blocked_pair_count}")

        df_matches = df_matches.alias("m").join(
            df_blocked_pairs.alias("b"),
            on=(
                ((col(f"m.query_{self._id_key}") == col("b.master_a")) & (col(f"m.match_{self._id_key}") == col("b.master_b"))) |
                ((col(f"m.query_{self._id_key}") == col("b.master_b")) & (col(f"m.match_{self._id_key}") == col("b.master_a")))
            ),
            how="left_anti"
        )

        match_count = df_matches.count()
        blocked_by_unmerge_count = after_existing_merge_filter_count - match_count

        self.logger.info(f"  Blocked by manual unmerge: {blocked_by_unmerge_count}")
        self.logger.info(f"Found {match_count} NEW MATCH records for auto-merge")

        self._stats['total_match_count'] = total_match_count
        self._stats['already_merged_count'] = already_merged_count
        self._stats['blocked_by_unmerge_count'] = blocked_by_unmerge_count
        self._stats['new_match_count'] = match_count

        return df_matches, match_count, already_merged_count

    def _build_undirected_graph(self, df_matches):
        """Step 2: Build undirected graph from matches."""
        self.print_header("STEP 2: BUILD UNDIRECTED GRAPH")

        from pyspark.sql.functions import col

        # Create edges in both directions
        df_edges_forward = df_matches.select(
            col(f"query_{self._id_key}").alias("node1"),
            col(f"match_{self._id_key}").alias("node2")
        )

        df_edges_backward = df_matches.select(
            col(f"match_{self._id_key}").alias("node1"),
            col(f"query_{self._id_key}").alias("node2")
        )

        df_edges = df_edges_forward.union(df_edges_backward).distinct()

        edge_count = df_edges.count()
        self.logger.info(f"Created {edge_count} undirected edges")

        return df_edges

    def _find_connected_components(self, df_edges):
        """Step 3: Find connected components using GraphFrames or Union-Find fallback."""
        self.print_header("STEP 3: FIND CONNECTED COMPONENTS")

        # Try GraphFrames first, fallback to Union-Find algorithm
        try:
            from graphframes import GraphFrame

            # Create nodes DataFrame
            df_nodes = df_edges.select("node1").union(df_edges.select("node2")).distinct() \
                .withColumnRenamed("node1", "id")

            # Create graph
            graph = GraphFrame(
                df_nodes,
                df_edges.withColumnRenamed("node1", "src").withColumnRenamed("node2", "dst")
            )

            # Find connected components
            df_components = graph.connectedComponents()
            df_components = df_components.withColumnRenamed("id", self._id_key)

            self.logger.info("Using GraphFrames for connected components")

        except ImportError:
            self.logger.info("GraphFrames not available, using optimized broadcast algorithm")

            # Collect edges for in-memory processing
            edges_list = [(row['node1'], row['node2']) for row in df_edges.collect()]

            self.logger.info(f"  Processing {len(edges_list)} edges in memory...")

            # Union-Find algorithm
            parent = {}

            def find(x):
                if x not in parent:
                    parent[x] = x
                if parent[x] != x:
                    parent[x] = find(parent[x])
                return parent[x]

            def union(x, y):
                px, py = find(x), find(y)
                if px != py:
                    parent[px] = py

            for node1, node2 in edges_list:
                union(node1, node2)

            # Get final components
            components = {}
            for node in parent.keys():
                root = find(node)
                if root not in components:
                    components[root] = []
                components[root].append(node)

            # Convert back to DataFrame
            component_data = []
            for root, members in components.items():
                for member in members:
                    component_data.append((member, root))

            df_components = self.spark.createDataFrame(component_data, ["id", "component"])
            df_components = df_components.withColumnRenamed("id", self._id_key)

            self.logger.info(f"Processed {len(parent)} nodes in {len(components)} components")

        num_components = df_components.select("component").distinct().count()
        total_records = df_components.count()

        self.logger.info(f"Found {num_components} connected components")
        self.logger.info(f"Total records in groups: {total_records}")
        self.logger.info(f"Average group size: {total_records / num_components if num_components > 0 else 0:.2f}")

        self._stats['num_components'] = num_components

        return df_components, num_components

    def _select_survivors(self, df_components):
        """Step 4: Select survivor for each group."""
        self.print_header("STEP 4: SELECT SURVIVOR FOR EACH GROUP")

        from pyspark.sql.functions import col, row_number
        from pyspark.sql import Window

        # Get first appearance timestamp
        df_first_appearance = self.spark.sql(f"""
            SELECT master_id as {self._id_key}, MIN(created_at) as first_seen
            FROM {self._merge_activities_table}
            GROUP BY master_id
        """)

        # Get contributor count
        df_contributor_count = self.spark.sql(f"""
            SELECT master_{self._id_key} as {self._id_key}, COUNT(DISTINCT {self._unified_id_key}) as contributor_count
            FROM {self._unified_table}
            WHERE record_status != 'DELETED' AND master_{self._id_key} IS NOT NULL
            GROUP BY master_{self._id_key}
        """)

        # Join with metadata
        df_components_with_metadata = df_components \
            .join(df_first_appearance, self._id_key, "left") \
            .join(df_contributor_count, self._id_key, "left") \
            .fillna({"contributor_count": 0})

        # Rank within each component
        window_survivor = Window.partitionBy("component").orderBy(
            col("first_seen").asc_nulls_last(),
            col("contributor_count").desc(),
            col(self._id_key).asc()
        )

        df_survivors = df_components_with_metadata \
            .withColumn("rank", row_number().over(window_survivor)) \
            .filter(col("rank") == 1) \
            .select("component", col(self._id_key).alias("survivor_id"), "first_seen", "contributor_count")

        survivor_count = df_survivors.count()
        self.logger.info(f"Selected {survivor_count} survivors (one per group)")

        self._stats['survivor_count'] = survivor_count

        return df_survivors

    def _identify_merge_records(self, df_components, df_survivors):
        """Step 5: Identify records to be merged (non-survivors)."""
        self.print_header("STEP 5: IDENTIFY RECORDS TO BE MERGED")

        from pyspark.sql.functions import col

        df_merge_plan = df_components \
            .join(df_survivors, "component") \
            .filter(col(self._id_key) != col("survivor_id"))

        records_to_merge = df_merge_plan.count()
        self.logger.info(f"Identified {records_to_merge} records to be merged into survivors")

        self._stats['records_to_merge'] = records_to_merge

        return df_merge_plan, records_to_merge

    def _get_all_contributors(self, df_merge_plan, df_survivors):
        """Step 6: Get all contributors for each group."""
        self.print_header("STEP 6: GET ALL CONTRIBUTORS FOR EACH GROUP")

        from pyspark.sql.functions import col

        # Get all contributors from unified table
        df_all_contributors = self.spark.sql(f"""
            SELECT master_{self._id_key} as {self._id_key}, {self._unified_id_key}, source_path, source_id
            FROM {self._unified_table}
            WHERE record_status != 'DELETED' AND master_{self._id_key} IS NOT NULL
        """)

        # Get survivor's contributors
        df_survivor_contributors = df_merge_plan.select("survivor_id", "component").distinct() \
            .join(df_all_contributors, col("survivor_id") == col(self._id_key)) \
            .select("component", "survivor_id", self._unified_id_key, "source_path", "source_id")

        # Get merging records' contributors
        df_merging_contributors = df_merge_plan \
            .join(df_all_contributors, self._id_key) \
            .select("component", "survivor_id", self._unified_id_key, "source_path", "source_id")

        # Combine
        df_combined_contributors = df_survivor_contributors.union(df_merging_contributors).distinct()

        contributor_count = df_combined_contributors.count()
        self.logger.info(f"Retrieved {contributor_count} total contributors across all groups")

        return df_combined_contributors

    def _apply_survivorship(self, df_combined_contributors):
        """Step 7: Apply survivorship engine."""
        self.print_header("STEP 7: APPLY SURVIVORSHIP ENGINE")

        from pyspark.sql.functions import col, collect_list, struct, udf
        from pyspark.sql.types import StructType, StructField, MapType, StringType, ArrayType

        # Get full unified records
        df_unified_records = self.spark.table(self._unified_table).filter(col("record_status") != "DELETED")

        # Join contributors with unified records
        all_contributors_df = df_combined_contributors \
            .select(
                col("survivor_id").alias("survivor_lakefusion_id"),
                col(self._unified_id_key).alias("contributor_surrogate_key")
            ) \
            .join(
                df_unified_records,
                col("contributor_surrogate_key") == df_unified_records[self._unified_id_key]
            ) \
            .select(
                col("survivor_lakefusion_id").alias(self._id_key),
                col("contributor_surrogate_key").alias(self._unified_id_key),
                "source_path",
                *self._entity_attributes
            )

        # Group by survivor
        grouped_contributors = (
            all_contributors_df
            .groupBy(self._id_key)
            .agg(
                collect_list(
                    struct([col(c) for c in all_contributors_df.columns if c != self._id_key])
                ).alias("unified_records")
            )
        )

        # Define UDF
        engine = self._engine

        def apply_survivorship_wrapper(unified_records):
            records_list = [r.asDict() for r in unified_records]
            result = engine.apply_survivorship(unified_records=records_list)
            return result.to_dict()

        udf_output_schema = StructType([
            StructField("resultant_record", MapType(StringType(), StringType())),
            StructField("resultant_master_attribute_source_mapping", ArrayType(StructType([
                StructField("attribute_name", StringType()),
                StructField("attribute_value", StringType()),
                StructField("source", StringType())
            ])))
        ])

        survivorship_udf = udf(apply_survivorship_wrapper, udf_output_schema)

        # Apply UDF
        result_df = grouped_contributors.withColumn(
            "survivorship_result",
            survivorship_udf(col("unified_records"))
        )

        # Extract results
        final_results_df = result_df.select(
            col(self._id_key),
            col("survivorship_result.resultant_record").alias("merged_record"),
            col("survivorship_result.resultant_master_attribute_source_mapping").alias("attribute_sources")
        )

        survivor_count = final_results_df.count()
        self.logger.info(f"Survivorship applied to {survivor_count} survivors")

        return final_results_df

    def _update_master_table(self, df_final_results):
        """Step 8: Update master table with merged records."""
        self.print_header("STEP 8: UPDATE MASTER TABLE")

        from delta.tables import DeltaTable
        from pyspark.sql.functions import col, coalesce, lit, concat_ws

        from lakefusion_core_engine.utils import merged_record_column

        # Build update columns
        master_updates_cols = [col(self._id_key)]

        for attr in self._entity_attributes:
            if attr == self._id_key:
                continue

            target_type = self._entity_attributes_datatype.get(attr, "string")
            master_updates_cols.append(merged_record_column(attr, target_type))

        # Add attributes_combined
        if self._match_attributes:
            concat_cols = [coalesce(col(f"merged_record.{attr}").cast("string"), lit("")) for attr in self._match_attributes if attr in self._entity_attributes and attr != self._id_key]
            if concat_cols:
                master_updates_cols.append(concat_ws(" | ", *concat_cols).alias("attributes_combined"))
            else:
                master_updates_cols.append(lit("").alias("attributes_combined"))
        else:
            master_updates_cols.append(lit("").alias("attributes_combined"))

        master_updates_df = df_final_results.select(*master_updates_cols)

        # Update master table
        master_delta = DeltaTable.forName(self.spark, self.context.master_table)

        master_delta.alias("target").merge(
            source=master_updates_df.alias("source"),
            condition=f"target.{self._id_key} = source.{self._id_key}"
        ).whenMatchedUpdateAll().execute()

        updates_count = master_updates_df.count()
        self.logger.info(f"Updated {updates_count} survivor records in master table")

    def _delete_merged_masters(self, df_merge_plan):
        """Step 9: Delete merged records from master table."""
        self.print_header("STEP 9: DELETE MERGED RECORDS FROM MASTER TABLE")

        from delta.tables import DeltaTable

        merged_ids = [row[self._id_key] for row in df_merge_plan.select(self._id_key).distinct().collect()]

        self.logger.info(f"  Deleting {len(merged_ids)} merged records from master table")

        if merged_ids:
            master_delta = DeltaTable.forName(self.spark, self.context.master_table)
            quoted_ids = [f"'{id}'" for id in merged_ids]
            delete_condition = f"{self._id_key} IN ({','.join(quoted_ids)})"
            master_delta.delete(delete_condition)

            self.logger.info(f"Deleted {len(merged_ids)} merged records from master table")

    def _log_merge_activities(self, df_merge_plan):
        """Step 10: Log merge activities."""
        self.print_header("STEP 10: LOG MERGE ACTIVITIES")

        from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType

        master_table_version = self.spark.sql(
            f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1"
        ).collect()[0]["version"]

        self._stats['master_table_version'] = master_table_version

        merge_activities = []
        current_time = datetime.now()

        for row in df_merge_plan.collect():
            merge_activities.append({
                "master_id": row["survivor_id"],
                "match_id": row[self._id_key],
                "source": "",
                "version": master_table_version,
                "action_type": "MASTER_JOB_MERGE",
                "created_at": current_time
            })

        merge_activities_schema = StructType([
            StructField("master_id", StringType(), True),
            StructField("match_id", StringType(), True),
            StructField("source", StringType(), True),
            StructField("version", IntegerType(), False),
            StructField("action_type", StringType(), False),
            StructField("created_at", TimestampType(), False)
        ])

        df_merge_activities = self.spark.createDataFrame(merge_activities, schema=merge_activities_schema)
        df_merge_activities.write.mode("append").saveAsTable(self._merge_activities_table)

        self.logger.info(f"Logged {len(merge_activities)} merge activities with version {master_table_version}")

    def _update_attribute_version_sources(self, df_final_results):
        """Step 11: Update attribute version sources."""
        self.print_header("STEP 11: UPDATE ATTRIBUTE VERSION SOURCES")

        from pyspark.sql.functions import col, lit

        attribute_sources_df = df_final_results.select(
            col(self._id_key).alias("lakefusion_id"),
            lit(self._stats['master_table_version']).cast("integer").alias("version"),
            col("attribute_sources").alias("attribute_source_mapping")
        )

        attribute_sources_df.write.mode("append").saveAsTable(self._attribute_version_sources_table)

        version_sources_count = attribute_sources_df.count()
        self.logger.info(f"Logged {version_sources_count} attribute version source records")

    def _reassign_unified_contributors(self, df_combined_contributors, df_survivors):
        """Step 12: Reassign unified contributors to survivors."""
        self.print_header("STEP 12: UPDATE UNIFIED TABLE - REASSIGN CONTRIBUTORS")

        from delta.tables import DeltaTable

        df_affected_contributors = df_combined_contributors.select(self._unified_id_key, "survivor_id").distinct()

        unified_delta = DeltaTable.forName(self.spark, self._unified_table)

        unified_delta.alias("target").merge(
            source=df_affected_contributors.alias("source"),
            condition=f"target.{self._unified_id_key} = source.{self._unified_id_key}"
        ).whenMatchedUpdate(
            set={f"master_{self._id_key}": "source.survivor_id"}
        ).execute()

        affected_count = df_affected_contributors.count()
        self.logger.info(f"Updated master_{self._id_key} for {affected_count} contributors in unified table")

    def _verify_final_state(self, num_components, records_to_merge):
        """Step 13: Verify final state."""
        self.print_header("STEP 13: VERIFY FINAL STATE")

        final_master_count = self.spark.table(self.context.master_table).count()

        final_merge_count = self.spark.sql(f"""
            SELECT COUNT(*) as cnt
            FROM {self._merge_activities_table}
            WHERE action_type = 'MASTER_JOB_MERGE'
        """).collect()[0]["cnt"]

        self.logger.info(f"  Final master table count: {final_master_count}")
        self.logger.info(f"  Total MASTER_JOB_MERGE activities: {final_merge_count}")
        self.logger.info(f"  Groups processed: {num_components}")
        self.logger.info(f"  Records merged this run: {records_to_merge}")

        self._stats['final_master_count'] = final_master_count
        self._stats['final_merge_count'] = final_merge_count
