"""
Golden Deduplication Process Deterministic Executor.

Processes deterministic rule-based matches between master records
for golden deduplication.

Note: This executor processes records that match based on deterministic
rules (exact matches on certain attributes) rather than LLM scoring.

Key Differences from Normal ProcessDeterministicExecutor:
    - Uses unified_deduplicate table (not unified)
    - Uses unified_deterministic_deduplicate table
    - id_key = "lakefusion_id" (master-to-master context)
    - No record_status = 'ACTIVE' filter (not applicable to dedup table)
    - Rule schema: old keys (rule_name, column, fuzzy_type, logical_op)
    - Score hardcoded to 1.0 / match hardcoded to "MATCH"
    - Final select: lakefusion_id (not surrogate_key)
"""

import json
from typing import Any, Dict, List

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from delta.tables import DeltaTable

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class GoldenProcessDeterministicExecutor(BaseStepTask):
    """
    Executor for Golden Deduplication Process Deterministic operations.

    Contains core business logic migrated from golden_deduplication/Process Deterministic notebook.
    Processes master records that match based on deterministic rules,
    applying rule-based matching before LLM scoring.

    Rule schema (old / golden dedup):
        {
            "rule_name": "rule1",
            "conditions": [
                {
                    "column": "first_name",     # field name
                    "match_type": "exact",      # "exact" | "fuzzy"
                    "fuzzy_type": "levenshtein",# "levenshtein" | "jaro_winkler" | "soundex"
                    "threshold": 1              # distance for levenshtein; ratio for jaro_winkler
                }
            ],
            "logical_op": "AND"                 # "AND" | "OR"
        }

    External Override Support:
        Users can provide a GoldenProcessDeterministicExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        1. Read unified_deduplicate and master tables
        2. Filter pending records (search_results != '' and scoring_results == '')
        3. Parse search results and join with master
        4. Apply rule-based filtering
        5. Compute deterministic matches
        6. Write to unified_deterministic_deduplicate table
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the golden dedup process deterministic task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}

        # Step intermediate results
        self._df_unified      = None
        self._df_master       = None
        self._df_pending      = None
        self._pending_count   = 0
        self._df_parsed       = None
        self._df_with_rules   = None
        self._df_deterministic = None

        # id_key for golden dedup is always lakefusion_id
        self._id_key = "lakefusion_id"

        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """
        PRE phase: Validate inputs and setup.

        Can be overridden by GoldenProcessDeterministicExtended.pre_execute()
        """
        self.print_header("GOLDEN DEDUP - PROCESS DETERMINISTIC")
        self.logger.info(f"Entity:     {self.context.entity}")
        self.logger.info(f"Catalog:    {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id or 'prod'}")

        # Build table names — always uses _deduplicate suffix for golden dedup
        suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._unified_dedup_table = (
            f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate{suffix}"
        )
        self._unified_deterministic_dedup_table = (
            f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deterministic_deduplicate{suffix}"
        )
        self._processed_unified_dedup_table = (
            f"{self.context.catalog_name}.silver.{self.context.entity}_processed_unified_deduplicate{suffix}"
        )

        self._merge_activities_table = f"{self.context.master_table}_merge_activities"
        self._attribute_version_sources_table = f"{self.context.master_table}_attribute_version_sources"

        self.logger.info(f"Unified Dedup Table:              {self._unified_dedup_table}")
        self.logger.info(f"Unified Deterministic Dedup Table:{self._unified_deterministic_dedup_table}")
        self.logger.info(f"Processed Unified Dedup Table:    {self._processed_unified_dedup_table}")
        self.logger.info(f"Master Table:                     {self.context.master_table}")

        # Get params
        params = self.context.params
        self._match_attributes           = params.get('attributes', [])
        self._entity_attributes_datatype = params.get('entity_attributes_datatype', {})
        self._rules_config               = params.get('rules_config', [])

        if isinstance(self._match_attributes, str):
            self._match_attributes = json.loads(self._match_attributes)
        if isinstance(self._entity_attributes_datatype, str):
            self._entity_attributes_datatype = json.loads(self._entity_attributes_datatype)
        

        # Use default rule if none provided
        if not self._rules_config and self._match_attributes:
            self._rules_config = []

        self.logger.info(f"Match Attributes: {self._match_attributes}")
        self.logger.info(f"Rules Config:     {len(self._rules_config)} rules")

    # ─────────────────────────────────────────────────────────────
    # Steps
    # ─────────────────────────────────────────────────────────────

    @step(order=1, name="Read Source Data", returns="df_unified, df_master")
    def step_read_source_data(self) -> None:
        """Step 1: Read unified_deduplicate and master tables."""
        self._df_unified, self._df_master = self._read_source_data()

    @step(order=2, name="Filter Pending Records", returns="df_pending, pending_count")
    def step_filter_pending_records(self) -> None:
        """Step 2: Filter records that have search_results but no scoring_results yet."""
        self._df_pending, self._pending_count = self._filter_pending_records(self._df_unified)

    @step(order=3, name="Parse and Join", returns="df_parsed")
    def step_parse_and_join(self) -> None:
        """Step 3: Parse search results and join with master."""
        self._df_parsed = self._parse_and_join(self._df_pending, self._df_master)

    @step(order=4, name="Apply Rules", returns="df_with_rules")
    def step_apply_rules(self) -> None:
        """Step 4: Apply deterministic rules."""
        self._df_with_rules = self._apply_rules(self._df_parsed)

    @step(order=5, name="Compute Deterministic Matches", returns="df_deterministic")
    def step_compute_deterministic_matches(self) -> None:
        """Step 5: Compute deterministic matches and build exploded_result struct."""
        self._df_deterministic = self._compute_deterministic_matches(self._df_with_rules)

    @step(order=6, name="Write Deterministic Table", returns="None")
    def step_write_deterministic_table(self) -> None:
        """Step 6: Write to unified_deterministic_deduplicate table."""
        self._write_deterministic_table(self._df_deterministic)

    # ─────────────────────────────────────────────────────────────
    # Lifecycle methods
    # ─────────────────────────────────────────────────────────────

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Core process deterministic business logic for golden dedup.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Exit early if no rules configured
            if not len(self._rules_config):
                self.logger.info("No deterministic rules configured — skipping")
                return TaskResult.success(
                    message="No deterministic rules configured — skipping",
                    task_name=self.context.task_name,
                    metrics={'deterministic_count': 0},
                    task_values={
                        'process_deterministic_complete': True,
                        'deterministic_matches': 0
                    }
                )

            self.step_read_source_data()
            self.step_filter_pending_records()

          

            self.step_parse_and_join()
            self.step_apply_rules()
            self.step_compute_deterministic_matches()
            self.step_write_deterministic_table()

            return TaskResult.success(
                message=f"Golden dedup process deterministic completed: {self._stats['deterministic_count']} deterministic matches",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'process_deterministic_complete': True,
                    'deterministic_matches': self._stats.get('deterministic_count', 0)
                },
                artifacts={
                    'unified_deterministic_dedup_table': self._unified_deterministic_dedup_table
                }
            )

        except Exception as e:
            raise RuntimeError(f"Golden dedup process deterministic failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the process deterministic results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            validation = ValidationResult(
                passed=True,
                message=f"Process deterministic completed: {self._stats.get('deterministic_count', 0)} matches",
                expected=self._stats.get('pending_count', 0),
                actual=self._stats.get('deterministic_count', 0)
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("process_deterministic_complete", True)
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _read_source_data(self):
        """Step 1: Read unified_deduplicate and master tables."""
        self.print_header("STEP 1: READ SOURCE DATA")

        df_unified = self.spark.read.table(self._unified_dedup_table)
        df_master  = self.spark.read.table(self.context.master_table)

        unified_count = df_unified.count()
        master_count  = df_master.count()

        self.logger.info(f"  Unified dedup table: {unified_count} records")
        self.logger.info(f"  Master table:        {master_count} records")

        self._stats['unified_count'] = unified_count
        self._stats['master_count']  = master_count

        return df_unified, df_master

    def _filter_pending_records(self, df_unified):
        """
        Step 2: Filter records that have search_results but no scoring_results.

        NOTE: No record_status = 'ACTIVE' filter — the unified_deduplicate table
        does not carry a record_status column (golden dedup context).
        Mirrors notebook: .filter(search_results != '').filter(scoring_results == '')
        """
        self.print_header("STEP 2: FILTER RECORDS FOR DETERMINISTIC PROCESSING")

        df_pending = df_unified.filter(
            (F.col("search_results") != "") &
            (F.col("scoring_results") == "")
        )

        pending_count = df_pending.count()
        self.logger.info(f"  Records pending deterministic processing: {pending_count}")

        self._stats['pending_count'] = pending_count

        return df_pending, pending_count

    def _parse_and_join(self, df_pending, df_master):
        """
        Step 3: Parse search_results into exploded candidate rows and inner-join with master.

        Parsing:
            - Strip outer brackets, split on '], ['.
            - Extract master lakefusion_id (second comma-separated token).
            - Explode to one row per candidate.

        Join: exp.search_results_master_lakefusion_ids == mst.lakefusion_id
        Group: collect_list of attributes_combined_master per unified row.
        """
        self.print_header("STEP 3: PARSE AND JOIN WITH MASTER")

        # Strip outer brackets and split into individual candidate strings
        df_cleaned = df_pending.withColumn(
            "search_results_array",
            F.split(
                F.regexp_replace(F.col("search_results"), r"^\[|\]$", ""),
                "\\], \\[",
            ),
        )

        # Extract master lakefusion_id from each candidate string
        df_cleaned = df_cleaned.withColumn(
            "search_results_master_lakefusion_ids",
            F.transform(
                F.col("search_results_array"),
                lambda x: F.trim(F.split(x, ",")[1]),
            ),
        )

        # One row per candidate master record
        df_exploded = df_cleaned.withColumn(
            "search_results_master_lakefusion_ids",
            F.explode("search_results_master_lakefusion_ids"),
        )

        df_exploded = df_exploded.alias("exp")
        df_master   = df_master.alias("mst")

        df_joined = df_exploded.join(
            df_master,
            F.col("exp.search_results_master_lakefusion_ids") == F.col(f"mst.{self._id_key}"),
            "inner",
        )

        # Build pipe-separated attribute string + lakefusion_id for each master row
        df_joined = df_joined.withColumn(
            "attributes_combined_master",
            F.concat(
                F.concat_ws(
                    " | ",
                    *[
                        F.when(F.trim(F.col(f"mst.{c}")) == "", "null")
                         .otherwise(
                             F.coalesce(F.col(f"mst.{c}").cast("string"), F.lit("null"))
                         )
                        for c in self._match_attributes
                    ],
                ),
                F.lit(", "),
                F.coalesce(F.col(f"mst.{self._id_key}").cast("string"), F.lit("null")),
            ),
        )

        # Group back: one unified row → list of master candidate strings
        group_cols = [f"exp.{c}" for c in df_exploded.columns]
        df_result = (
            df_joined
            .groupBy(*group_cols)
            .agg(
                F.collect_list("attributes_combined_master").alias(
                    "attributes_combined_master_array"
                )
            )
            .select(
                "exp.*",
                "attributes_combined_master_array",
                "search_results_master_lakefusion_ids",
            )
        )

        parsed_count = df_result.count()
        self.logger.info(f"  Parsed and joined {parsed_count} records")

        return df_result

    def _apply_rules(self, df_parsed: DataFrame) -> DataFrame:
        """
        Step 4: Parse master candidate strings into structs and apply rules.
    
        Uses experiment-2 rule schema keys:
            rule_cfg["name"], cond["attribute"], cond["function"], rule_cfg["logical_operator"]
        """
        self.print_header("STEP 4: APPLY DETERMINISTIC RULES")
    
        def build_dynamic_struct(x_col, attributes, entity_attributes_datatype):
            """Build a struct from a pipe-separated master attribute string."""
            struct_fields = []
            parts = F.split(F.split(x_col, ",")[0], "\\|")
    
            for idx, attr in enumerate(attributes):
                raw_value = F.trim(F.element_at(parts, idx + 1))
                struct_fields.append(raw_value.alias(f"{attr}_matches"))
    
            lakefusion_id = F.trim(F.regexp_extract(x_col, r",\s*([a-f0-9]{32})", 1))
            struct_fields.append(lakefusion_id.alias("lakefusion_id"))
    
            return F.struct(*struct_fields)
    
        # Parse each master candidate string into a struct
        df_parsed = df_parsed.withColumn(
            "search_result_parsed",
            F.transform(
                F.col("attributes_combined_master_array"),
                lambda x: build_dynamic_struct(
                    x, self._match_attributes, self._entity_attributes_datatype
                ),
            ),
        )
    
        # Apply rules → '<rule_name>_results' columns
        df_with_rules = df_parsed
        for rule_cfg in self._rules_config:
            rule_name  = rule_cfg["name"]                                    # ← was rule_cfg["rule_name"]
            conditions = rule_cfg["conditions"]
            logical_op = rule_cfg.get("logical_operator", "AND")             # ← was "logical_op"
    
            condition_parts = []
            for cond in conditions:
                col_name   = cond["attribute"]                               # ← was cond["column"]
                match_type = cond.get("match_type", "exact")
                fuzzy_func = cond.get("function")                            # ← was cond.get("fuzzy_type", ...)
                threshold  = cond.get("threshold")
    
                if match_type == "exact":
                    condition_parts.append(f"({col_name} = x.{col_name}_matches)")
                elif match_type == "fuzzy":
                    if fuzzy_func == "levenshtein":
                        # threshold is a similarity ratio (0–1) — mirrors ProcessDeterministicExecutor
                        condition_parts.append(
                            f"(levenshtein({col_name}, x.{col_name}_matches) / "
                            f"greatest(length({col_name}), length(x.{col_name}_matches))"
                            f" >= {threshold})"                              # ← was <= threshold (distance)
                        )
                    elif fuzzy_func == "jaro_winkler":
                        condition_parts.append(
                            f"(jaro_winkler_similarity({col_name}, x.{col_name}_matches)"
                            f" >= {threshold})"
                        )
                    elif fuzzy_func == "soundex":
                        condition_parts.append(
                            f"(soundex({col_name}) = soundex(x.{col_name}_matches))"
                        )
                    else:
                        raise ValueError(f"Unsupported fuzzy function: {fuzzy_func}")
                else:
                    raise ValueError(f"Unsupported match_type: {match_type}")
    
            combined_condition = f" {logical_op} ".join(condition_parts)
            rule_expr = F.expr(
                f"filter(search_result_parsed, x -> ({combined_condition}))"
            ).alias(rule_name)
    
            df_with_rules = df_with_rules.withColumn(f"{rule_name}_results", rule_expr)
    
        self.logger.info(f"  Applied {len(self._rules_config)} deterministic rules")
    
        return df_with_rules
    def _compute_deterministic_matches(self, df_with_rules: DataFrame) -> DataFrame:
        """
        Step 5: Flag deterministic matches, pick first matching rule,
        explode matched results, and build exploded_result struct.

        Score is hardcoded to 1.0 and match to "MATCH" — golden dedup context
        does not use threshold-based scoring (mirrors notebook exactly).

        Final select columns (golden dedup / single source):
            lakefusion_id, attributes_combined, search_results,
            deterministic_match_result, is_deterministic_match, exploded_result
        """
        self.print_header("STEP 5: COMPUTE DETERMINISTIC MATCHES")

        rule_cols = [f"{r['name']}_results" for r in self._rules_config]

        # 1. Flag: any non-empty rule array → deterministic match candidate
        is_match_expr = F.lit(False)
        for c in rule_cols:
            is_match_expr = is_match_expr | (F.size(F.col(c)) > 0)
        df_rules = df_with_rules.withColumn("is_deterministic_match", is_match_expr)

        # 2. Coalesce: first matching rule wins (preserves priority order)
        when_exprs = []
        for r in self._rules_config:                          # ← iterate rules_config, not rule_cols
            c = f"{r['name']}_results"
            when_exprs.append(
                F.when(
                    F.size(F.col(c)) > 0,
                    F.struct(
                        F.col(c).alias("rule_result"),
                        F.lit(r['name']).alias("rule_name"), # ← was c.replace("_results", "")
                    ),
                )
            )

        df_rules = df_rules.withColumn(
            "deterministic_match_result",
            F.coalesce(*when_exprs) if when_exprs else F.lit(None),
        )

        # 3. Explode matched results
        df_exploded = df_rules.withColumn(
            "rule",
            F.explode("deterministic_match_result.rule_result"),
        )

        # 4. All struct fields except lakefusion_id become the "id" display value
        selected_rule_fields = [
            f.name
            for f in df_exploded.schema["rule"].dataType.fields
            if f.name != "lakefusion_id"
        ]
        concat_col = F.concat_ws(" | ", *[F.col(f"rule.{f}") for f in selected_rule_fields])

        # 5. Build exploded_result struct
        # Score hardcoded to 1.0 and match to "MATCH" — mirrors notebook
        df_final = df_exploded.withColumn(
            "exploded_result",
            F.struct(
                concat_col.alias("id"),
                F.lit("MATCH").alias("match"),
                F.lit(1.0).cast("double").alias("score"),
                F.concat(
                    F.lit("Due to Deterministic Match of Rule: "),
                    F.col("deterministic_match_result.rule_name"),
                ).alias("reason"),
                F.col("rule.lakefusion_id").alias("lakefusion_id"),
            ),
        )

        # 6. Filter and select — golden dedup uses lakefusion_id (not surrogate_key)
        df_final = (
            df_final
            .filter(F.col("is_deterministic_match") == F.lit(True))
            .drop("rule")
            .select(
                self._id_key,               # "lakefusion_id" — golden dedup context
                "attributes_combined",
                "search_results",
                "deterministic_match_result",
                "is_deterministic_match",
                "exploded_result",
            )
        )

        deterministic_count = df_final.count()
        self.logger.info(f"  Found {deterministic_count} deterministic matches")
        self._stats['deterministic_count'] = deterministic_count

        return df_final

    def _write_deterministic_table(self, df_deterministic: DataFrame) -> None:
        """
        Step 6: Write to unified_deterministic_deduplicate table.

        - New table: overwrite + OPTIMIZE ZORDER BY lakefusion_id.
        - Existing table: MERGE on lakefusion_id (whenNotMatchedInsertAll).
          No OPTIMIZE after merge — matches notebook behavior.
        """
        self.print_header("STEP 6: WRITE TO UNIFIED_DETERMINISTIC_DEDUPLICATE TABLE")

        table_exists = self.spark.catalog.tableExists(self._unified_deterministic_dedup_table)

        if not table_exists:
            (
                df_deterministic
                .write
                .mode("overwrite")
                .option("mergeSchema", "true")
                .saveAsTable(self._unified_deterministic_dedup_table)
            )
            self.spark.sql(
                f"OPTIMIZE {self._unified_deterministic_dedup_table}"
                f" ZORDER BY ({self._id_key})"
            )
            self.logger.info(f"  Created and optimized: {self._unified_deterministic_dedup_table}")
        else:
            delta_table = DeltaTable.forName(self.spark, self._unified_deterministic_dedup_table)
            (
                delta_table.alias("target")
                .merge(
                    source=df_deterministic.alias("source"),
                    condition=f"target.{self._id_key} = source.{self._id_key}",
                )
                .whenNotMatchedInsertAll()
                .execute()
            )
            self.logger.info(f"  Merged into existing table: {self._unified_deterministic_dedup_table}")

        final_count = self.spark.table(self._unified_deterministic_dedup_table).count()
        self.logger.info(f"  Total records in deterministic table: {final_count}")

        self._stats['deterministic_table_count'] = final_count