"""
Golden Deduplication Process Potential Match Executor.

Builds the potential match table for golden deduplication, showing
pending and merged relationships between master records.

Key Differences from Normal Deduplication:
    - Uses processed_unified_deduplicate table
    - Builds potential_match_deduplicate table
    - Handles transitive merge chains
    - Shows both PENDING and MERGED relationships
"""

import json
from typing import Any, Dict

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class GoldenProcessPotentialMatchExecutor(BaseStepTask):
    """
    Executor for Golden Deduplication Process Potential Match operations.

    Contains core business logic migrated from golden_deduplication/Process_Potential_Match notebook.
    Builds a comprehensive potential match table that shows:
    - PENDING: Master pairs that are potential matches (not yet merged)
    - MERGED: Master pairs that have been merged (with transitive resolution)

    Key Differences from Normal ProcessPotentialMatchExecutor:
        - Uses processed_unified_deduplicate table
        - Creates potential_match_deduplicate table
        - Resolves transitive merge chains to ultimate survivors
        - Excludes NOT_A_MATCH pairs

    External Override Support:
        Users can provide a GoldenProcessPotentialMatchExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        1. Build transitive merge chain
        2. Resolve ultimate survivors
        3. Build merged records with proper reasons
        4. Lookup best match scores
        5. Get NOT_A_MATCH pairs to exclude
        6. Build pending and merged relationships
        7. Get master attributes for related records
        8. Build potential matches struct
        9. Add column tags
        10. Write to Delta table
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the golden dedup process potential match task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}

        # Step intermediate results
        self._merge_lookup = None
        self._merge_info = None
        self._active_masters_set = None
        self._ultimate_survivor_map = None
        self._merge_path_map = None
        self._transitive_flag_map = None
        self._df_merged_records = None
        self._df_potential_match = None
        self._df_with_tags = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """
        PRE phase: Validate inputs and setup.

        Can be overridden by GoldenProcessPotentialMatchExtended.pre_execute()
        """
        self.print_header("GOLDEN DEDUP - POTENTIAL MATCH TABLE")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id or 'None'}")

        # Build table names
        self._unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate"
        self._processed_unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_processed_unified_deduplicate"
        self._potential_match_dedup_table = f"{self.context.catalog_name}.gold.{self.context.entity}_master_potential_match_deduplicate"

        if self.context.experiment_id:
            self._unified_dedup_table += f"_{self.context.experiment_id}"
            self._processed_unified_dedup_table += f"_{self.context.experiment_id}"
            self._potential_match_dedup_table += f"_{self.context.experiment_id}"

        self._merge_activities_table = f"{self.context.master_table}_merge_activities"
        self._attribute_version_sources_table = f"{self.context.master_table}_attribute_version_sources"
        self._unified_table = self.context.unified_table

        self.logger.info(f"Unified Dedup Table: {self._unified_dedup_table}")
        self.logger.info(f"Processed Unified Dedup Table: {self._processed_unified_dedup_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Potential Match Dedup Table: {self._potential_match_dedup_table}")
        self.logger.info(f"Merge Activities Table: {self._merge_activities_table}")
        self.logger.info(f"Attribute Version Sources Table: {self._attribute_version_sources_table}")
        self.logger.info(f"Unified Table: {self._unified_table}")

        # Get params
        params = self.context.params
        self._entity_attributes = params.get('entity_attributes', [])

        if isinstance(self._entity_attributes, str):
            self._entity_attributes = json.loads(self._entity_attributes)

        self._id_key = 'lakefusion_id'

    @step(order=1, name="Build Transitive Merge Chain", returns="merge_lookup, merge_info, active_masters_set")
    def step_build_transitive_merge_chain(self) -> None:
        """Step 1: Build transitive merge chain."""
        self._merge_lookup, self._merge_info, self._active_masters_set = self._build_transitive_merge_chain()

    @step(order=2, name="Resolve Ultimate Survivors", returns="ultimate_survivor_map, merge_path_map, transitive_flag_map")
    def step_resolve_ultimate_survivors(self) -> None:
        """Step 2: Resolve ultimate survivors (transitive closure)."""
        self._ultimate_survivor_map, self._merge_path_map, self._transitive_flag_map = self._resolve_ultimate_survivors(
            self._merge_lookup, self._active_masters_set
        )

    @step(order=3, name="Build Merged Records DataFrame", returns="df_merged_records")
    def step_build_merged_records_dataframe(self) -> None:
        """Step 3: Build merged records DataFrame."""
        self._df_merged_records = self._build_merged_records_dataframe(
            self._merge_info, self._ultimate_survivor_map, self._merge_path_map, self._transitive_flag_map, self._active_masters_set
        )

    @step(order=4, name="Build Potential Match DataFrame", returns="df_potential_match")
    def step_build_potential_match_dataframe(self) -> None:
        """Step 4: Build final potential match DataFrame with proper score lookups."""
        self._df_potential_match = self._build_potential_match_dataframe(self._df_merged_records)

    @step(order=5, name="Add Column Tags", returns="df_with_tags")
    def step_add_column_tags(self) -> None:
        """Step 5: Add column tags."""
        self._df_with_tags = self._add_column_tags(self._df_potential_match)

    @step(order=6, name="Write to Delta Table", returns="None")
    def step_write_to_delta_table(self) -> None:
        """Step 6: Write to Delta table."""
        self._write_to_delta_table(self._df_with_tags)

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Core process potential match business logic for golden dedup.

        This method is NOT overridable by end users.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Check if processed table exists
            if not self.spark.catalog.tableExists(self._processed_unified_dedup_table):
                return TaskResult.skipped(
                    message=f"Table {self._processed_unified_dedup_table} does not exist, skipping",
                    task_name=self.context.task_name,
                    task_values={'potential_match_complete': False}
                )

            # Step 1: Build transitive merge chain
            self.step_build_transitive_merge_chain()

            # Step 2: Resolve ultimate survivors
            self.step_resolve_ultimate_survivors()

            # Step 3: Build merged records DataFrame
            self.step_build_merged_records_dataframe()

            # Step 4: Build final potential match DataFrame
            self.step_build_potential_match_dataframe()

            # Step 5: Add column tags
            self.step_add_column_tags()

            # Step 6: Write to Delta table
            self.step_write_to_delta_table()

            return TaskResult.success(
                message=f"Golden dedup potential match table completed",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'potential_match_complete': True
                },
                artifacts={
                    'potential_match_table': self._potential_match_dedup_table
                }
            )

        except Exception as e:
            raise RuntimeError(f"Golden dedup potential match processing failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the potential match results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            validation = ValidationResult(
                passed=True,
                message=f"Potential match table completed",
                expected=1,
                actual=1
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("potential_match_complete", True)
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _build_transitive_merge_chain(self):
        """Step 1: Build transitive merge chain."""
        self.print_header("STEP 1: BUILD TRANSITIVE MERGE CHAIN")

        # Get active masters
        df_active_masters = self.spark.sql(f"SELECT {self._id_key} FROM {self.context.master_table}")
        active_masters_set = set([row[self._id_key] for row in df_active_masters.collect()])
        self.logger.info(f"Active masters loaded: {len(active_masters_set)}")

        # Get all master-to-master merges
        df_all_merges = self.spark.sql(f"""
            SELECT
                master_id as immediate_survivor,
                match_id as merged_record,
                action_type,
                created_at
            FROM {self._merge_activities_table}
            WHERE action_type IN ('MASTER_JOB_MERGE', 'MASTER_MANUAL_MERGE', 'MASTER_FORCE_MERGE')
                AND master_id IS NOT NULL
                AND match_id IS NOT NULL
        """)

        # Build merge lookup
        merge_lookup = {}
        merge_info = {}

        for row in df_all_merges.collect():
            merged = row['merged_record']
            survivor = row['immediate_survivor']
            action_type = row['action_type']
            created_at = row['created_at']

            if merged not in merge_info or created_at > merge_info[merged][2]:
                merge_lookup[merged] = survivor
                merge_info[merged] = (survivor, action_type, created_at)

        self.logger.info(f"Merge relationships loaded: {len(merge_lookup)}")

        self._stats['active_masters'] = len(active_masters_set)
        self._stats['merge_relationships'] = len(merge_lookup)

        return merge_lookup, merge_info, active_masters_set

    def _resolve_ultimate_survivors(self, merge_lookup, active_masters_set, max_depth=10):
        """Step 2: Resolve ultimate survivors (transitive closure)."""
        self.print_header("STEP 2: RESOLVE ULTIMATE SURVIVORS")

        def find_ultimate_survivor(merged_id):
            current = merged_id
            path = [merged_id]
            depth = 0

            while current in merge_lookup and depth < max_depth:
                next_survivor = merge_lookup[current]
                path.append(next_survivor)

                if next_survivor in active_masters_set:
                    return next_survivor, path, len(path) > 2

                current = next_survivor
                depth += 1

            if current in active_masters_set:
                return current, path, len(path) > 2

            return path[-1] if path else None, path, len(path) > 2

        ultimate_survivor_map = {}
        merge_path_map = {}
        transitive_flag_map = {}

        for merged_id in merge_lookup.keys():
            ultimate, path, is_transitive = find_ultimate_survivor(merged_id)
            ultimate_survivor_map[merged_id] = ultimate
            merge_path_map[merged_id] = path
            transitive_flag_map[merged_id] = is_transitive

        self.logger.info(f"Transitive closure resolved")

        return ultimate_survivor_map, merge_path_map, transitive_flag_map

    def _build_merged_records_dataframe(self, merge_info, ultimate_survivor_map, merge_path_map, transitive_flag_map, active_masters_set):
        """Step 3: Build merged records DataFrame."""
        self.print_header("STEP 3: BUILD MERGED RECORDS DATAFRAME")

        from pyspark.sql.types import StructType, StructField, StringType, BooleanType, IntegerType

        merged_records_data = []

        for merged_id, (immediate_survivor, action_type, created_at) in merge_info.items():
            ultimate_survivor = ultimate_survivor_map.get(merged_id, immediate_survivor)
            is_transitive = transitive_flag_map.get(merged_id, False)
            path = merge_path_map.get(merged_id, [merged_id, immediate_survivor])

            if ultimate_survivor in active_masters_set:
                merged_records_data.append({
                    'ultimate_survivor': ultimate_survivor,
                    'merged_record': merged_id,
                    'immediate_survivor': immediate_survivor,
                    'action_type': action_type,
                    'is_transitive': is_transitive,
                    'merge_depth': len(path) - 1,
                    'merge_remaining': -1,
                    'merge_total': -1,
                })

        # --- Merge Health Check ---
        # For each merged master, check how many of its source records are still
        # assigned to the survivor in the unified table.  This detects partial or
        # full unmerges that happened after the golden merge.
        if merged_records_data:
            self.print_header("STEP 3.5: MERGE HEALTH CHECK")

            # Build a temporary DataFrame so we can use SQL
            pre_health_schema = StructType([
                StructField('ultimate_survivor', StringType(), True),
                StructField('merged_record', StringType(), True),
            ])
            pre_health_data = [
                {'ultimate_survivor': r['ultimate_survivor'], 'merged_record': r['merged_record']}
                for r in merged_records_data
            ]
            df_pre_health = self.spark.createDataFrame(pre_health_data, pre_health_schema)
            df_pre_health.createOrReplaceTempView("merged_health_temp")

            health_query = f"""
            WITH source_records AS (
                SELECT
                    ma.master_id AS merged_master,
                    ma.match_id  AS source_sk,
                    mh.ultimate_survivor
                FROM {self._merge_activities_table} ma
                INNER JOIN merged_health_temp mh
                    ON ma.master_id = mh.merged_record
                WHERE ma.action_type IN ('JOB_INSERT','JOB_MERGE','MANUAL_MERGE','INITIAL_LOAD')
                  AND ma.match_id LIKE 'sk_%'
            )
            SELECT
                sr.merged_master,
                sr.ultimate_survivor,
                COUNT(DISTINCT sr.source_sk) AS total_source_records,
                COUNT(DISTINCT CASE
                    WHEN u.master_{self._id_key} = sr.ultimate_survivor
                     AND u.record_status != 'DELETED'
                    THEN sr.source_sk
                END) AS remaining_count
            FROM source_records sr
            LEFT JOIN {self._unified_table} u
                ON u.{self.context.unified_id_key} = sr.source_sk
            GROUP BY sr.merged_master, sr.ultimate_survivor
            """

            health_results = self.spark.sql(health_query).collect()
            health_map = {
                row['merged_master']: (row['remaining_count'], row['total_source_records'])
                for row in health_results
            }

            # Filter and annotate merged_records_data
            filtered_data = []
            removed_count = 0
            partial_count = 0
            for record in merged_records_data:
                merged_id = record['merged_record']
                remaining, total = health_map.get(merged_id, (None, None))

                if remaining is not None and remaining == 0 and total > 0:
                    # Fully unmerged — exclude
                    removed_count += 1
                    continue
                elif remaining is not None and total is not None and 0 < remaining < total:
                    # Partially merged
                    record['action_type'] = 'MASTER_PARTIAL_MERGE'
                    record['merge_remaining'] = remaining
                    record['merge_total'] = total
                    partial_count += 1
                else:
                    # Fully merged or no source records found — keep as-is
                    record['merge_remaining'] = remaining if remaining is not None else -1
                    record['merge_total'] = total if total is not None else -1

                filtered_data.append(record)

            merged_records_data = filtered_data
            self.logger.info(f"  Health check complete: {removed_count} fully unmerged (removed), {partial_count} partially merged")

        schema = StructType([
            StructField('ultimate_survivor', StringType(), True),
            StructField('merged_record', StringType(), True),
            StructField('immediate_survivor', StringType(), True),
            StructField('action_type', StringType(), True),
            StructField('is_transitive', BooleanType(), True),
            StructField('merge_depth', IntegerType(), True),
            StructField('merge_remaining', IntegerType(), True),
            StructField('merge_total', IntegerType(), True),
        ])

        df_merged_records = self.spark.createDataFrame(merged_records_data, schema)
        self.logger.info(f"Merged records DataFrame created: {len(merged_records_data)} records")

        self._stats['merged_records'] = len(merged_records_data)

        return df_merged_records

    def _build_potential_match_dataframe(self, df_merged_records):
        """Step 4-12: Build final potential match DataFrame with proper score lookups."""
        df_merged_records.createOrReplaceTempView("merged_records_temp")

        # Step 4: Lookup best match scores for merged records
        self.print_header("STEP 4: LOOKUP BEST MATCH SCORES FOR MERGED RECORDS")

        best_match_scores_query = f"""
        WITH all_matches AS (
            SELECT
                query_{self._id_key} as record_id,
                match_{self._id_key} as partner_id,
                exploded_result.score as score,
                exploded_result.reason as reason
            FROM {self._processed_unified_dedup_table}
            WHERE exploded_result.match = 'MATCH'

            UNION ALL

            SELECT
                match_{self._id_key} as record_id,
                query_{self._id_key} as partner_id,
                exploded_result.score as score,
                exploded_result.reason as reason
            FROM {self._processed_unified_dedup_table}
            WHERE exploded_result.match = 'MATCH'
        ),
        ranked_matches AS (
            SELECT
                record_id,
                partner_id,
                score,
                reason,
                ROW_NUMBER() OVER (PARTITION BY record_id ORDER BY score DESC) as rn
            FROM all_matches
        )
        SELECT
            record_id as merged_record,
            partner_id as matched_with,
            score as best_match_score,
            reason as best_match_reason
        FROM ranked_matches
        WHERE rn = 1
        """

        df_best_match_scores = self.spark.sql(best_match_scores_query)
        df_best_match_scores.createOrReplaceTempView("best_match_scores_temp")
        self.logger.info("Best match scores query prepared")

        # Step 5: Lookup direct relationship scores
        self.print_header("STEP 5: LOOKUP DIRECT RELATIONSHIP SCORES")

        direct_scores_query = f"""
        WITH direct_forward AS (
            SELECT
                query_{self._id_key} as survivor_id,
                match_{self._id_key} as merged_id,
                exploded_result.score as score,
                exploded_result.reason as reason,
                exploded_result.match as match_status
            FROM {self._processed_unified_dedup_table}
        ),
        direct_reverse AS (
            SELECT
                match_{self._id_key} as survivor_id,
                query_{self._id_key} as merged_id,
                exploded_result.score as score,
                exploded_result.reason as reason,
                exploded_result.match as match_status
            FROM {self._processed_unified_dedup_table}
        )
        SELECT * FROM direct_forward
        UNION ALL
        SELECT * FROM direct_reverse
        """

        df_direct_scores = self.spark.sql(f"""
            WITH raw AS (
                {direct_scores_query}
            )
            SELECT
                survivor_id,
                merged_id,
                score,
                reason,
                match_status
            FROM (
                SELECT *,
                    ROW_NUMBER() OVER (
                        PARTITION BY survivor_id, merged_id
                        ORDER BY score DESC
                    ) AS rn
                FROM raw
            )
            WHERE rn = 1
        """)
        df_direct_scores.createOrReplaceTempView("direct_scores_temp")
        self.logger.info("Direct scores query prepared")

        # Step 6: Build final merged records with scores and reasons
        self.print_header("STEP 6: BUILD FINAL MERGED RECORDS WITH SCORES AND REASONS")

        final_merged_query = f"""
        WITH merged_with_scores AS (
            SELECT
                mr.ultimate_survivor,
                mr.merged_record,
                mr.immediate_survivor,
                mr.action_type,
                mr.is_transitive,
                mr.merge_depth,
                mr.merge_remaining,
                mr.merge_total,
                bms.best_match_score,
                bms.best_match_reason,
                bms.matched_with,
                ds.score as direct_score,
                ds.reason as direct_reason,
                ds.match_status as direct_match_status
            FROM merged_records_temp mr
            LEFT JOIN best_match_scores_temp bms
                ON mr.merged_record = bms.merged_record
            LEFT JOIN direct_scores_temp ds
                ON mr.ultimate_survivor = ds.survivor_id
                AND mr.merged_record = ds.merged_id
        )
        SELECT
            ultimate_survivor,
            merged_record,
            action_type,
            is_transitive,
            merge_depth,
            CASE
                WHEN action_type = 'MASTER_FORCE_MERGE' THEN 1.0
                WHEN action_type = 'MASTER_MANUAL_MERGE' THEN COALESCE(direct_score, best_match_score, 1.0)
                WHEN action_type = 'MASTER_JOB_MERGE' THEN COALESCE(best_match_score, direct_score, 1.0)
                ELSE COALESCE(best_match_score, direct_score, 1.0)
            END as display_score,
            CASE
                WHEN action_type = 'MASTER_FORCE_MERGE' THEN 
                    'Force merged'
                WHEN action_type = 'MASTER_MANUAL_MERGE' AND direct_reason IS NOT NULL THEN
                    CONCAT('Masters merged manually - ', direct_reason)
                WHEN action_type = 'MASTER_MANUAL_MERGE' THEN
                    'Masters merged manually'
                WHEN action_type = 'MASTER_JOB_MERGE' AND is_transitive = true AND best_match_reason IS NOT NULL THEN
                    CONCAT('Merged via connected records - ', best_match_reason)
                WHEN action_type = 'MASTER_JOB_MERGE' AND is_transitive = true THEN
                    'Merged via connected component (transitive)'
                WHEN action_type = 'MASTER_JOB_MERGE' AND best_match_reason IS NOT NULL THEN
                    CONCAT('Masters merged automatically - ', best_match_reason)
                WHEN action_type = 'MASTER_JOB_MERGE' AND direct_reason IS NOT NULL THEN
                    CONCAT('Masters merged automatically - ', direct_reason)
                WHEN action_type = 'MASTER_JOB_MERGE' THEN
                    'Masters merged automatically (high confidence match)'
                ELSE 'Merged'
            END as display_reason,
            merge_remaining,
            merge_total
        FROM merged_with_scores
        """

        df_final_merged = self.spark.sql(final_merged_query)
        df_final_merged.createOrReplaceTempView("final_merged_temp")
        self.logger.info("Final merged records query prepared")

        # Step 7: Get NOT_A_MATCH pairs
        self.print_header("STEP 7: GET NOT_A_MATCH PAIRS TO EXCLUDE")

        not_a_match_query = f"""
        SELECT DISTINCT
            ma.master_id as master1_{self._id_key},
            ma.match_id as master2_{self._id_key}
        FROM {self._merge_activities_table} ma
        WHERE ma.action_type = 'MANUAL_NOT_A_MATCH'
            AND ma.master_id IS NOT NULL
            AND ma.match_id IS NOT NULL
        """
        self.logger.info("NOT_A_MATCH query prepared")

        # Step 8: Build pending and merged relationships
        self.print_header("STEP 8: BUILD PENDING AND MERGED RELATIONSHIPS")

        pending_matches_query = f"""
        WITH not_a_match_bidirectional AS (
            SELECT master1_{self._id_key}, master2_{self._id_key} FROM ({not_a_match_query})
            UNION
            SELECT master2_{self._id_key} as master1_{self._id_key}, master1_{self._id_key} as master2_{self._id_key}
            FROM ({not_a_match_query})
        ),
        active_masters AS (
            SELECT {self._id_key} FROM {self.context.master_table}
        )
        SELECT DISTINCT
            pu.query_{self._id_key} as master1_{self._id_key},
            pu.match_{self._id_key} as master2_{self._id_key},
            pu.exploded_result.score as score,
            pu.exploded_result.reason as reason,
            'PENDING' as merge_status,
            CAST(NULL AS STRING) as merge_remaining,
            CAST(NULL AS STRING) as merge_total
        FROM {self._processed_unified_dedup_table} pu
        INNER JOIN active_masters am1 ON pu.query_{self._id_key} = am1.{self._id_key}
        INNER JOIN active_masters am2 ON pu.match_{self._id_key} = am2.{self._id_key}
        LEFT JOIN not_a_match_bidirectional nam
            ON pu.query_{self._id_key} = nam.master1_{self._id_key}
            AND pu.match_{self._id_key} = nam.master2_{self._id_key}
        WHERE pu.exploded_result.match = 'POTENTIAL_MATCH'
            AND nam.master1_{self._id_key} IS NULL
        """

        # Build merged matches from final_merged with actual scores
        merged_matches_query = f"""
        SELECT
            ultimate_survivor as master1_{self._id_key},
            merged_record as master2_{self._id_key},
            display_score as score,
            display_reason as reason,
            CASE
                WHEN action_type IS NOT NULL THEN action_type
                ELSE 'MERGED'
            END as merge_status,
            CAST(merge_remaining AS STRING) as merge_remaining,
            CAST(merge_total AS STRING) as merge_total
        FROM final_merged_temp
        """

        all_relationships_query = f"""
        WITH pending AS ({pending_matches_query}),
        merged AS ({merged_matches_query})
        SELECT * FROM pending
        UNION ALL
        SELECT * FROM merged
        """

        self.logger.info("Relationships queries prepared")

        # Step 9: Get master attributes for related records
        self.print_header("STEP 9: GET MASTER ATTRIBUTES FOR RELATED RECORDS")

        # Get attribute values from attribute_version_sources for merged masters
        merged_master_attributes_query = f"""
        WITH merged_ids AS (
            SELECT DISTINCT merged_record as {self._id_key}
            FROM final_merged_temp
        ),
        latest_versions AS (
            SELECT
                avs.{self._id_key},
                avs.version,
                avs.attribute_source_mapping,
                ROW_NUMBER() OVER (PARTITION BY avs.{self._id_key} ORDER BY avs.version DESC) as rn
            FROM {self._attribute_version_sources_table} avs
            INNER JOIN merged_ids mi ON avs.{self._id_key} = mi.{self._id_key}
        )
        SELECT
            {self._id_key},
            version,
            attribute_source_mapping
        FROM latest_versions
        WHERE rn = 1
        """

        # Build pivot query for merged master attributes
        pivot_cols = ", ".join([
            f"MAX(CASE WHEN attribute_name = '{attr}' THEN attribute_value END) as {attr}"
            for attr in self._entity_attributes
        ])

        merged_attrs_flattened_query = f"""
        WITH latest_merged_attrs AS ({merged_master_attributes_query})
        SELECT
            {self._id_key},
            exploded.attribute_name,
            exploded.attribute_value
        FROM latest_merged_attrs
        LATERAL VIEW EXPLODE(attribute_source_mapping) AS exploded
        """

        merged_masters_reconstructed_query = f"""
        WITH flattened AS ({merged_attrs_flattened_query})
        SELECT
            {self._id_key},
            {pivot_cols}
        FROM flattened
        GROUP BY {self._id_key}
        """

        self.logger.info("Attribute queries prepared")

        # Step 10: Join relationships with master attributes
        self.print_header("STEP 10: JOIN RELATIONSHIPS WITH MASTER ATTRIBUTES")

        active_master_cols = [f"CAST(m.{attr} AS STRING) as {attr}" for attr in self._entity_attributes]
        active_master_select = ", ".join([f"m.{self._id_key}"] + active_master_cols + ["m.attributes_combined"])

        join_query = f"""
        WITH relationships AS ({all_relationships_query}),
        active_masters AS (
            SELECT {active_master_select}
            FROM {self.context.master_table} m
        ),
        merged_masters_reconstructed AS ({merged_masters_reconstructed_query}),
        all_masters AS (
            SELECT * FROM active_masters
            UNION ALL
            SELECT
                mr.{self._id_key},
                {', '.join([f'mr.{attr}' for attr in self._entity_attributes])},
                NULL as attributes_combined
            FROM merged_masters_reconstructed mr
            WHERE mr.{self._id_key} NOT IN (SELECT {self._id_key} FROM active_masters)
        )
        SELECT
            r.master1_{self._id_key},
            r.master2_{self._id_key},
            r.score,
            r.reason,
            r.merge_status,
            r.merge_remaining,
            r.merge_total,
            md2.{self._id_key},
            {', '.join([f'md2.{attr}' for attr in self._entity_attributes])},
            COALESCE(md2.attributes_combined, '') as attributes_combined
        FROM relationships r
        INNER JOIN all_masters md2
            ON r.master2_{self._id_key} = md2.{self._id_key}
        """

        self.logger.info("Join query prepared")

        # Step 11: Build potential matches struct
        self.print_header("STEP 11: BUILD POTENTIAL MATCHES STRUCT")

        named_struct_parts = []
        for attr in self._entity_attributes:
            named_struct_parts.append(f"'{attr}', {attr}")

        named_struct_parts.extend([
            "'__score__', CAST(score AS STRING)",
            "'__reason__', reason",
            f"'{self._id_key}', {self._id_key}",
            "'__mergestatus__', merge_status",
            "'__merge_remaining__', merge_remaining",
            "'__merge_total__', merge_total",
            "'__attributes_combined__', attributes_combined"
        ])

        named_struct_expr = f"NAMED_STRUCT({', '.join(named_struct_parts)})"

        aggregate_query = f"""
        WITH relationships_with_attrs AS ({join_query})
        SELECT
            master1_{self._id_key} as {self._id_key},
            COLLECT_SET({named_struct_expr}) as potential_matches
        FROM relationships_with_attrs
        GROUP BY master1_{self._id_key}
        """

        self.logger.info("Aggregate query prepared")

        # Step 12: Build final potential match table
        self.print_header("STEP 12: BUILD FINAL POTENTIAL MATCH TABLE")

        master_attr_list = [f"m.{attr}" for attr in self._entity_attributes]
        master_select = ", ".join([f"m.{self._id_key}"] + master_attr_list + ["m.attributes_combined"])

        final_query = f"""
        WITH aggregated AS ({aggregate_query})
        SELECT
            {master_select},
            COALESCE(a.potential_matches, ARRAY()) as potential_matches
        FROM {self.context.master_table} m
        LEFT JOIN aggregated a
            ON m.{self._id_key} = a.{self._id_key}
        ORDER BY m.{self._id_key}
        """

        df_potential_match = self.spark.sql(final_query)
        self.logger.info("Final potential match DataFrame created")

        return df_potential_match

    def _add_column_tags(self, df_potential_match):
        """Step 9: Add column tags."""
        self.print_header("STEP 9: ADD COLUMN TAGS")

        from pyspark.sql.functions import lit, create_map

        try:
            schema_name = self.context.master_table.split('.')[1]
            table_name = self.context.master_table.split('.')[2]

            tags_query = f"""
                SELECT column_name, MAP_FROM_ARRAYS(COLLECT_LIST(tag_name), COLLECT_LIST(tag_value)) AS tags_map
                FROM {self.context.catalog_name}.information_schema.column_tags
                WHERE schema_name = '{schema_name}' AND table_name = '{table_name}'
                GROUP BY column_name
            """

            column_tags_df = self.spark.sql(tags_query)

            if column_tags_df.take(1):
                # Build tags map expressions for each attribute using SQL subquery
                tags_expr = []
                for attr in self._entity_attributes:
                    tags_expr.append(
                        f"'{attr}', (SELECT tags_map FROM column_tags WHERE column_name = '{attr}')"
                    )

                map_clause = f"MAP({', '.join(tags_expr)}) AS tags"

                # Register the DataFrame as temp view for SQL join
                df_potential_match.createOrReplaceTempView("pot_match_temp")

                # Build final query with actual tags
                df_with_tags = self.spark.sql(f"""
                    WITH column_tags AS (
                        {tags_query}
                    )
                    SELECT
                        pot_match_temp.*,
                        {map_clause}
                    FROM pot_match_temp
                """)

                self.logger.info("Column tags added from information_schema")
            else:
                self.logger.info("No column tags found, using empty tags map")
                tag_columns = []
                for attr in self._entity_attributes:
                    tag_columns.extend([lit(attr), lit(None).cast("map<string,string>")])

                df_with_tags = df_potential_match.withColumn("tags", create_map(*tag_columns))

        except Exception as e:
            self.logger.error(f"Error adding tags: {e}, proceeding with empty tags")
            tag_columns = []
            for attr in self._entity_attributes:
                tag_columns.extend([lit(attr), lit(None).cast("map<string,string>")])

            df_with_tags = df_potential_match.withColumn("tags", create_map(*tag_columns))

        return df_with_tags

    def _write_to_delta_table(self, df_with_tags):
        """Step 10: Write to Delta table."""
        self.print_header("STEP 10: WRITE TO DELTA TABLE")

        table_exists = self.spark.catalog.tableExists(self._potential_match_dedup_table)

        self.logger.info(f"  {'Updating' if table_exists else 'Creating'} table: {self._potential_match_dedup_table}")

        df_with_tags.write \
            .format("delta") \
            .option("mergeSchema", "true") \
            .mode("overwrite") \
            .saveAsTable(self._potential_match_dedup_table)

        self.logger.info("Table written successfully")

        final_count = self.spark.table(self._potential_match_dedup_table).count()
        self.logger.info(f"Total records in potential match table: {final_count}")

        self._stats['potential_match_count'] = final_count
