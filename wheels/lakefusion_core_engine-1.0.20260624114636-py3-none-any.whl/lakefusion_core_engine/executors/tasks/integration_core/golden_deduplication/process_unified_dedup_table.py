"""
Golden Deduplication Process Unified Dedup Table Executor.

Creates and maintains the unified_deduplicate table that contains
master records with search_results and scoring_results columns
for golden deduplication.

This task is unique to golden deduplication - it syncs the master table
to unified_deduplicate table and clears search/scoring results for
changed records.
"""

import json
from datetime import datetime
from typing import Any, Dict

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ProcessUnifiedDedupTableExecutor(BaseStepTask):
    """
    Executor for creating/syncing the unified_deduplicate table.

    Contains core business logic migrated from golden_deduplication/Process_Unified_Dedup_Table notebook.
    This task maintains the unified_deduplicate table that mirrors the master table
    with additional columns for vector search and LLM scoring results.

    This task is UNIQUE to golden deduplication:
        - Normal deduplication uses the unified table directly
        - Golden deduplication creates a separate unified_deduplicate table
          that mirrors masters for master-to-master matching

    External Override Support:
        Users can provide a ProcessUnifiedDedupTableExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        Initial Load:
            1. Clone master table to unified_deduplicate
            2. Add search_results and scoring_results columns (empty)

        Incremental:
            1. Get last processed version from metadata
            2. Identify changed lakefusion_ids from merge_activities
            3. Identify records that reference changed IDs
            4. Sync master to unified_deduplicate with Delta MERGE
            5. Clear search results for indirect updates
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the process unified dedup table task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}

        # Step intermediate results
        self._dedup_table_exists = False
        self._last_processed_version = None
        self._current_master_version = None
        self._changed_ids_df = None
        self._changed_ids_list = None
        self._indirect_update_df = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """
        PRE phase: Validate inputs and setup.

        Can be overridden by ProcessUnifiedDedupTableExtended.pre_execute()
        """
        self.print_header("CREATE UNIFIED DEDUP TABLE FOR GOLDEN DEDUPLICATION")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id or 'None'}")

        # Build table names
        self._unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate"

        if self.context.experiment_id:
            self._unified_dedup_table += f"_{self.context.experiment_id}"

        self._merge_activities_table = f"{self.context.master_table}_merge_activities"

        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Unified Dedup Table: {self._unified_dedup_table}")
        self.logger.info(f"Merge Activities Table: {self._merge_activities_table}")

        # Get params
        params = self.context.params
        self._meta_info_table = params.get('meta_info_table')

        if isinstance(self._meta_info_table, str) and self._meta_info_table:
            pass
        else:
            self._meta_info_table = f"{self.context.catalog_name}.silver.table_meta_info"

        self.logger.info(f"Meta Info Table: {self._meta_info_table}")

        self._id_key = 'lakefusion_id'

    @step(order=1, name="Check Table Exists", returns="dedup_table_exists")
    def step_check_table_exists(self) -> None:
        """Step 1: Check if unified_dedup table exists."""
        self._dedup_table_exists = self._check_table_exists()

    @step(order=2, name="Initial Load - Create Table", returns="None")
    def step_initial_load(self) -> TaskResult:
        """Step 2: Execute initial load - create unified_dedup table."""
        return self._execute_initial_load()

    @step(order=3, name="Get Version Info", returns="last_processed_version, current_master_version")
    def step_get_version_info(self) -> None:
        """Step 3: Get last processed and current master versions."""
        self._last_processed_version, self._current_master_version = self._get_version_info()

    @step(order=4, name="Identify Changed IDs", returns="changed_ids_df, changed_ids_list")
    def step_identify_changed_ids(self) -> None:
        """Step 4: Identify changed lakefusion_ids from merge activities."""
        self._changed_ids_df, self._changed_ids_list = self._identify_changed_ids()

    @step(order=5, name="Identify Indirect Updates", returns="indirect_update_df")
    def step_identify_indirect_updates(self) -> None:
        """Step 5: Identify records that reference changed IDs."""
        self._indirect_update_df = self._identify_indirect_updates()

    @step(order=6, name="Sync Master to Unified Dedup", returns="None")
    def step_sync_master_to_unified_dedup(self) -> None:
        """Step 6: Sync master to unified_dedup with Delta MERGE."""
        self._sync_master_to_unified_dedup()

    @step(order=7, name="Clear Indirect Updates", returns="None")
    def step_clear_indirect_updates(self) -> None:
        """Step 7: Clear search results for indirect updates."""
        self._clear_indirect_updates()

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Core unified dedup table sync logic.

        This method is NOT overridable by end users.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Check if unified_dedup table exists
            self.step_check_table_exists()

            if not self._dedup_table_exists:
                # Initial load - create table
                return self.step_initial_load()
            else:
                # Incremental - sync changes
                return self._execute_incremental()

        except Exception as e:
            raise RuntimeError(f"Process unified dedup table failed: {str(e)}") from e

    def _execute_incremental(self) -> TaskResult:
        """Execute incremental sync - update changed records."""
        self.print_header("INCREMENTAL MODE - DETECTING CHANGES")

        # Step 3: Get version info
        self.step_get_version_info()

        if self._current_master_version == self._last_processed_version:
            self.logger.info("\nNo changes detected - master version unchanged")
            return TaskResult.skipped(
                message="No changes detected",
                task_name=self.context.task_name,
                task_values={
                    'unified_dedup_sync_complete': True,
                    'records_processed': 0,
                    'master_version': int(self._current_master_version)
                }
            )

        self.logger.info(f"  Detected changes: versions {self._last_processed_version} -> {self._current_master_version}")

        # Step 4: Identify changed IDs
        self.step_identify_changed_ids()

        if len(self._changed_ids_list) == 0:
            return TaskResult.skipped(
                message="No changed records in merge activities",
                task_name=self.context.task_name,
                task_values={
                    'unified_dedup_sync_complete': True,
                    'records_processed': 0,
                    'master_version': int(self._current_master_version)
                }
            )

        # Step 5: Identify indirect updates
        self.step_identify_indirect_updates()

        # Step 6: Sync master to unified_dedup
        self.step_sync_master_to_unified_dedup()

        # Step 7: Clear indirect updates
        self.step_clear_indirect_updates()

        # Calculate statistics
        from pyspark.sql.functions import col

        total_records = self.spark.table(self._unified_dedup_table).count()
        records_with_empty_results = self.spark.table(self._unified_dedup_table).filter(
            col("search_results") == ""
        ).count()

        changed_count = len(self._changed_ids_list)
        indirect_count = self._indirect_update_df.count() if self._indirect_update_df else 0
        total_records_processed = changed_count + indirect_count

        self._stats['mode'] = 'incremental'
        self._stats['records_processed'] = total_records_processed
        self._stats['master_version'] = int(self._current_master_version)
        self._stats['direct_updates'] = changed_count
        self._stats['indirect_updates'] = indirect_count
        self._stats['records_needing_vector_search'] = records_with_empty_results

        return TaskResult.success(
            message=f"Incremental sync complete: {total_records_processed} records processed",
            task_name=self.context.task_name,
            metrics=self._stats,
            task_values={
                'unified_dedup_sync_complete': True,
                'records_processed': total_records_processed,
                'master_version': int(self._current_master_version)
            },
            artifacts={
                'unified_dedup_table': self._unified_dedup_table,
                'mode': 'incremental'
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            validation = ValidationResult(
                passed=True,
                message=f"Unified dedup table sync completed",
                expected=1,
                actual=1
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("unified_dedup_sync_complete", True)
                self.dbutils.jobs.taskValues.set("records_processed", self._stats.get('records_processed', 0))
                self.dbutils.jobs.taskValues.set("master_version", self._stats.get('master_version', 0))
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _check_table_exists(self) -> bool:
        """Check if unified_dedup table exists."""
        self.print_header("STEP 1: CHECK IF UNIFIED_DEDUP TABLE EXISTS")

        try:
            self.spark.sql(f"DESCRIBE TABLE {self._unified_dedup_table}")
            self.logger.info(f"Unified dedup table exists: {self._unified_dedup_table}")
            return True
        except Exception:
            self.logger.info(f"Unified dedup table does not exist: {self._unified_dedup_table}")
            return False

    def _execute_initial_load(self) -> TaskResult:
        """Execute initial load - create unified_dedup table."""
        self.print_header("INITIAL LOAD - CREATING UNIFIED_DEDUP TABLE")

        from pyspark.sql.functions import lit
        from pyspark.sql.types import StringType

        # Get current master table version
        master_version = self.spark.sql(
            f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1"
        ).select("version").collect()[0][0]

        self.logger.info(f"  Current master version: {master_version}")

        # Read master table
        master_df = self.spark.table(self.context.master_table)

        # Add search_results and scoring_results columns
        unified_dedup_df = master_df \
            .withColumn("search_results", lit("").cast(StringType())) \
            .withColumn("scoring_results", lit("").cast(StringType()))

        # Write to unified_dedup table
        unified_dedup_df.write.format("delta").mode("overwrite").saveAsTable(self._unified_dedup_table)

        record_count = unified_dedup_df.count()
        self.logger.info(f"Created unified_dedup table with {record_count} records")
        self.logger.info(f"  Added columns: search_results, scoring_results")

        self._stats['mode'] = 'initial_load'
        self._stats['records_processed'] = record_count
        self._stats['master_version'] = int(master_version)

        return TaskResult.success(
            message=f"Initial load complete: {record_count} records cloned from master",
            task_name=self.context.task_name,
            metrics=self._stats,
            task_values={
                'unified_dedup_sync_complete': True,
                'records_processed': record_count,
                'master_version': int(master_version)
            },
            artifacts={
                'unified_dedup_table': self._unified_dedup_table,
                'mode': 'initial_load'
            }
        )

    def _get_version_info(self):
        """Get last processed and current master versions."""
        # Get last processed version
        last_processed_query = f"""
            SELECT last_processed_version
            FROM {self._meta_info_table}
            WHERE table_name = '{self.context.master_table}'
                AND entity_name = '{self.context.entity}'
        """

        last_processed_result = self.spark.sql(last_processed_query).collect()

        if len(last_processed_result) == 0:
            error_msg = f"ERROR: No metadata found for table '{self.context.master_table}' in {self._meta_info_table}"
            self.logger.info(error_msg)
            raise ValueError(error_msg)

        last_processed_version = last_processed_result[0]['last_processed_version']
        current_master_version = self.spark.sql(
            f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1"
        ).select("version").collect()[0][0]

        self.logger.info(f"  Last processed master version: {last_processed_version}")
        self.logger.info(f"  Current master version: {current_master_version}")

        return last_processed_version, current_master_version

    def _identify_changed_ids(self):
        """Identify changed lakefusion_ids from merge activities."""
        self.print_header("STEP 2: IDENTIFY CHANGED LAKEFUSION_IDS")

        # Get changed master_ids
        master_ids_df = self.spark.sql(f"""
            SELECT DISTINCT master_id as {self._id_key}
            FROM {self._merge_activities_table}
            WHERE version > {self._last_processed_version}
              AND version <= {self._current_master_version}
        """)

        master_ids_count = master_ids_df.count()
        self.logger.info(f"Found {master_ids_count} master_ids with changes")

        # Get changed match_ids for golden dedup merges
        match_ids_df = self.spark.sql(f"""
            SELECT DISTINCT match_id as {self._id_key}
            FROM {self._merge_activities_table}
            WHERE version > {self._last_processed_version}
              AND version <= {self._current_master_version}
              AND action_type IN ('MASTER_MANUAL_MERGE', 'MASTER_JOB_MERGE', 'MASTER_FORCE_MERGE')
        """)

        match_ids_count = match_ids_df.count()
        self.logger.info(f"Found {match_ids_count} match_ids from golden dedup merges")

        # Combine and deduplicate
        changed_ids_df = master_ids_df.union(match_ids_df).distinct()
        changed_count = changed_ids_df.count()

        self.logger.info(f"Total unique changed lakefusion_ids: {changed_count}")

        changed_ids_list = [row[self._id_key] for row in changed_ids_df.collect()]

        return changed_ids_df, changed_ids_list

    def _identify_indirect_updates(self):
        """Identify records that reference changed IDs."""
        self.print_header("STEP 3: IDENTIFY RECORDS THAT REFERENCE CHANGED IDS")

        if not self._changed_ids_list:
            return None

        conditions = " OR ".join([f"search_results LIKE '%{changed_id}%'" for changed_id in self._changed_ids_list])

        indirect_update_query = f"""
            SELECT DISTINCT {self._id_key}
            FROM {self._unified_dedup_table}
            WHERE search_results != ''
              AND ({conditions})
        """

        indirect_update_df = self.spark.sql(indirect_update_query)
        indirect_count = indirect_update_df.count()

        self.logger.info(f"Found {indirect_count} records that reference changed masters")

        all_ids_to_clear = self._changed_ids_df.union(indirect_update_df).distinct()
        total_to_clear = all_ids_to_clear.count()

        self.logger.info(f"Total records to clear search/scoring results: {total_to_clear}")

        return indirect_update_df

    def _sync_master_to_unified_dedup(self):
        """Sync master to unified_dedup with Delta MERGE."""
        self.print_header("STEP 4: SYNC MASTER TO UNIFIED_DEDUP WITH DELTA MERGE")

        from pyspark.sql.functions import col, lit, when
        from delta.tables import DeltaTable

        current_master_df = self.spark.table(self.context.master_table)

        # Prepare master data with conditional result clearing
        master_with_results_df = (
            current_master_df
            .withColumn("search_results",
                        when(col(self._id_key).isin(self._changed_ids_list), lit(""))
                        .otherwise(lit(None)))
            .withColumn("scoring_results",
                        when(col(self._id_key).isin(self._changed_ids_list), lit(""))
                        .otherwise(lit(None)))
        )

        unified_dedup_delta = DeltaTable.forName(self.spark, self._unified_dedup_table)

        # Build update set
        update_cols = {col_name: f"source.{col_name}" for col_name in current_master_df.columns}
        update_cols["search_results"] = "COALESCE(source.search_results, target.search_results)"
        update_cols["scoring_results"] = "COALESCE(source.scoring_results, target.scoring_results)"

        # Ensure target schema has all source columns before merge
        target_columns = {f.name for f in unified_dedup_delta.toDF().schema.fields}
        source_columns = master_with_results_df.schema.fields
        missing_cols = [f for f in source_columns if f.name not in target_columns]

        if missing_cols:
            self.logger.info(f"  Adding {len(missing_cols)} new column(s) to unified_dedup: {[f.name for f in missing_cols]}")
            col_defs = ", ".join(f"`{f.name}` {f.dataType.simpleString()}" for f in missing_cols)
            self.spark.sql(f"ALTER TABLE {self._unified_dedup_table} ADD COLUMNS ({col_defs})")
            # Refresh DeltaTable reference after schema change
            unified_dedup_delta = DeltaTable.forName(self.spark, self._unified_dedup_table)

        self.logger.info("  Executing Delta MERGE operation...")

        (
            unified_dedup_delta.alias("target")
            .merge(
                master_with_results_df.alias("source"),
                f"target.{self._id_key} = source.{self._id_key}"
            )
            .whenMatchedUpdate(set=update_cols)
            .whenNotMatchedInsertAll()
            .whenNotMatchedBySourceDelete()
            .execute()
        )

        self.logger.info(f"Delta MERGE completed successfully")

    def _clear_indirect_updates(self):
        """Clear search results for indirect updates."""
        if self._indirect_update_df is None:
            return

        indirect_count = self._indirect_update_df.count()
        if indirect_count == 0:
            return

        self.print_header("STEP 5: CLEAR SEARCH RESULTS FOR INDIRECT UPDATES")

        from pyspark.sql.functions import col, lit
        from pyspark.sql.types import StringType
        from delta.tables import DeltaTable

        indirect_only_df = self._indirect_update_df.join(self._changed_ids_df, on=self._id_key, how="left_anti")
        indirect_only_count = indirect_only_df.count()

        if indirect_only_count > 0:
            self.logger.info(f"  Clearing search results for {indirect_only_count} indirect updates...")

            indirect_clear_df = (
                indirect_only_df
                .select(col(self._id_key))
                .withColumn("search_results", lit("").cast(StringType()))
                .withColumn("scoring_results", lit("").cast(StringType()))
            )

            unified_dedup_delta = DeltaTable.forName(self.spark, self._unified_dedup_table)

            unified_dedup_delta.alias("target").merge(
                indirect_clear_df.alias("source"),
                f"target.{self._id_key} = source.{self._id_key}"
            ).whenMatchedUpdate(set={
                "search_results": "source.search_results",
                "scoring_results": "source.scoring_results"
            }).execute()

            self.logger.info(f"  Cleared search/scoring results for {indirect_only_count} indirect updates")
