"""
Golden Deduplication Update Table Metadata Executor.

Updates the last processed version in metadata table for all tables
involved in golden deduplication pipeline.
"""

import json
from typing import Any, Dict

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class GoldenUpdateTableMetadataExecutor(BaseStepTask):
    """
    Executor for Golden Deduplication Update Table Metadata operations.

    Contains core business logic migrated from golden_deduplication/Update_Table_Metadata notebook.
    Updates the metadata table with latest processed versions for:
    - Master table
    - Unified table (or unified_deduplicate for golden dedup)
    - Secondary/dataset tables

    External Override Support:
        Users can provide a GoldenUpdateTableMetadataExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        1. Update metadata for master table
        2. Update metadata for unified table
        3. Update metadata for all secondary tables
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the update table metadata task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}

        # Step intermediate results
        self._master_version = None
        self._unified_version = None
        self._secondary_versions = {}
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """
        PRE phase: Validate inputs.

        Can be overridden by GoldenUpdateTableMetadataExtended.pre_execute()
        """
        self.print_header("GOLDEN DEDUP - UPDATE TABLE METADATA")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id or 'None'}")

        # Sanitize experiment_id (remove hyphens) to match production behavior
        experiment_id = self.context.experiment_id
        if experiment_id:
            experiment_id = experiment_id.replace("-", "")

        # Build table names
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified"
        self._master_table = f"{self.context.catalog_name}.gold.{self.context.entity}_master"
        self._meta_info_table = f"{self.context.catalog_name}.silver.table_meta_info"

        if experiment_id:
            self._unified_table += f"_{experiment_id}"
            self._master_table += f"_{experiment_id}"

        self.logger.info(f"Master Table: {self._master_table}")
        self.logger.info(f"Unified Table: {self._unified_table}")
        self.logger.info(f"Meta Info Table: {self._meta_info_table}")

        # Get params
        params = self.context.params
        self._dataset_tables = params.get('dataset_tables', [])
        self._is_golden_deduplication = params.get('is_golden_deduplication', True)

        if isinstance(self._dataset_tables, str):
            self._dataset_tables = json.loads(self._dataset_tables)

        self.logger.info(f"Dataset Tables: {len(self._dataset_tables)}")
        self.logger.info(f"Is Golden Deduplication: {self._is_golden_deduplication}")

    @step(order=1, name="Update Master Table Metadata", returns="master_version")
    def step_update_master_metadata(self) -> None:
        """Step 1: Update metadata for master table."""
        self._master_version = self._update_table_metadata(self._master_table)
        self.logger.info(f"Updated master table {self._master_table}: version {self._master_version}")

    @step(order=2, name="Update Unified Table Metadata", returns="unified_version")
    def step_update_unified_metadata(self) -> None:
        """Step 2: Update metadata for unified table."""
        self._unified_version = self._update_table_metadata(self._unified_table)
        self.logger.info(f"Updated unified table {self._unified_table}: version {self._unified_version}")

    @step(order=3, name="Update Secondary Tables Metadata", returns="secondary_versions")
    def step_update_secondary_metadata(self) -> None:
        """Step 3: Update metadata for all secondary tables."""
        for dataset in self._dataset_tables:
            version = self._update_table_metadata(dataset)
            self._secondary_versions[dataset] = version
            self.logger.info(f"Updated secondary table {dataset}: version {version}")

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Core update table metadata logic.

        This method is NOT overridable by end users.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Update master table metadata
            self.step_update_master_metadata()

            # Step 2: Update unified table metadata
            self.step_update_unified_metadata()

            # Step 3: Update all secondary tables
            self.step_update_secondary_metadata()

            self._stats['master_version'] = self._master_version
            self._stats['unified_version'] = self._unified_version
            self._stats['secondary_versions'] = self._secondary_versions
            self._stats['tables_updated'] = 2 + len(self._dataset_tables)

            return TaskResult.success(
                message=f"Successfully updated metadata for {self._stats['tables_updated']} tables",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'metadata_update_complete': True,
                    'master_version': self._master_version,
                    'unified_version': self._unified_version
                },
                artifacts={
                    'meta_info_table': self._meta_info_table
                }
            )

        except Exception as e:
            raise RuntimeError(f"Update table metadata failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the update metadata results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            validation = ValidationResult(
                passed=True,
                message=f"Metadata updated for {self._stats.get('tables_updated', 0)} tables",
                expected=2 + len(self._dataset_tables),
                actual=self._stats.get('tables_updated', 0)
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("metadata_update_complete", True)
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _update_table_metadata(self, table_name: str) -> int:
        """
        Update or insert last processed version into metadata table.

        Args:
            table_name: Fully qualified table name

        Returns:
            The latest version number
        """
        from delta.tables import DeltaTable
        from pyspark.sql.functions import current_timestamp

        # Ensure meta info table exists
        if not self.spark.catalog.tableExists(self._meta_info_table):
            schema = "table_name STRING, entity_name STRING, last_processed_version LONG, last_processed_timestamp TIMESTAMP"
            self.spark.sql(f"CREATE TABLE {self._meta_info_table} ({schema}) USING DELTA")

        # Get latest version
        latest_version = self.spark.sql(
            f"DESCRIBE HISTORY {table_name}"
        ).selectExpr("max(version)").first()[0]

        # Create DataFrame to upsert
        new_row = self.spark.createDataFrame(
            [(table_name, self.context.entity, latest_version)],
            ["table_name", "entity_name", "last_processed_version"]
        )
        new_row = new_row.withColumn("last_processed_timestamp", current_timestamp())

        # Merge into meta info table
        delta_meta = DeltaTable.forName(self.spark, self._meta_info_table)

        delta_meta.alias("target").merge(
            new_row.alias("source"),
            condition="target.table_name = source.table_name AND target.entity_name = source.entity_name"
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

        return latest_version
