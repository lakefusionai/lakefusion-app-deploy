"""
Incremental Load tasks module.

Contains task executors for processing CDC (Change Data Feed) incrementals.
Handles INSERT, UPDATE, and DELETE operations with proper deduplication
and survivorship recalculation.

Key Features:
    - CDF-based change detection and deduplication
    - STANDALONE vs MULTI_CONTRIBUTOR scenario handling
    - Survivorship recalculation for multi-contributor updates/deletes
    - Batch execution for atomic updates
    - Idempotent processing (safe for re-runs)

Available Tasks:
    - CheckIncrementExistsExecutor: Check source tables for CDF changes
    - ValidateIncrementalLoadExecutor: Validate CDF data quality before processing
    - IncrementInsertsExecutor: Process INSERT incrementals
    - IncrementUpdatesExecutor: Process UPDATE incrementals with survivorship
    - IncrementDeletesExecutor: Process DELETE incrementals with survivorship

Usage:
------
    from lakefusion_core_engine.executors.tasks.integration_core.incremental_load import (
        CheckIncrementExistsExecutor,
        ValidateIncrementalLoadExecutor,
        IncrementInsertsExecutor
    )
"""

from .check_increment_exists import CheckIncrementExistsExecutor
from .validate_incremental_load import ValidateIncrementalLoadExecutor
from .increment_inserts import IncrementInsertsExecutor
from .increment_updates import IncrementUpdatesExecutor
from .increment_deletes import IncrementDeletesExecutor

__all__ = [
    'CheckIncrementExistsExecutor',
    'ValidateIncrementalLoadExecutor',
    'IncrementInsertsExecutor',
    'IncrementUpdatesExecutor',
    'IncrementDeletesExecutor',
]
