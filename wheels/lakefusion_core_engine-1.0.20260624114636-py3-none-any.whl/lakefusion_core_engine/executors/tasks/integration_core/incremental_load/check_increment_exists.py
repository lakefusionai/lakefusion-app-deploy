"""
Check Increment Exists Executor.

Checks if ANY source table (primary + secondary) has new changes (INSERT/UPDATE/DELETE).
Sets flags to control which downstream notebooks should run.

Key Features:
    - Single pass through CDF to check all change types at once
    - Tracks version info for each source table
    - Sets has_inserts, has_updates, has_deletes flags
    - Early exit if no incrementals exist
"""

import json
from typing import Any, Dict, List

from pyspark.sql.functions import col, count, when

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class CheckIncrementExistsExecutor(BaseStepTask):
    """
    Executor for checking increment existence in source tables.

    Checks all source tables for CDF changes since last processed version.
    Determines which downstream notebooks should run based on change types.

    Workflow:
        1. Read last processed version from meta_info table
        2. Check each source table for CDF changes
        3. Categorize changes as INSERT, UPDATE, DELETE
        4. Set flags for downstream processing
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the check increment exists task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._tables_with_inserts: List[str] = []
        self._tables_with_updates: List[str] = []
        self._tables_with_deletes: List[str] = []
        self._table_version_info: Dict[str, Any] = {}
        # Step execution intermediate results
        self._total_inserts: int = 0
        self._total_updates: int = 0
        self._total_deletes: int = 0
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """PRE phase: Validate inputs and setup configuration."""
        self.print_header("CHECK INCREMENT EXISTS")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")

        params = self.context.params
        self._dataset_tables = params.get('dataset_tables', [])

        if isinstance(self._dataset_tables, str):
            self._dataset_tables = json.loads(self._dataset_tables)

        # Build table names
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._meta_info_table = f"{self.context.catalog_name}.silver.table_meta_info"
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"

        self.logger.info(f"Meta Info Table: {self._meta_info_table}")
        self.logger.info(f"Unified Table: {self._unified_table}")
        self.logger.info(f"Source Tables: {len(self._dataset_tables)}")

    @step(order=1, name="Check Source Tables", returns="tables_checked")
    def step_check_source_tables(self) -> int:
        """
        Step 1: Check each source table for CDF changes.

        Returns:
            Number of tables checked
        """
        self.print_header(f"Checking incrementals for entity: {self.context.entity}")
        self.logger.info(f"Source tables to check: {len(self._dataset_tables)}")

        for source_table in self._dataset_tables:
            has_inserts, has_updates, has_deletes, start_ver, current_ver, counts = \
                self._check_table_changes(source_table)

            # Store version info
            last_processed = start_ver - 1 if start_ver > 0 else None
            self._table_version_info[source_table] = {
                "last_processed_version": last_processed,
                "starting_version": start_ver,
                "current_version": current_ver,
                "has_inserts": has_inserts,
                "has_updates": has_updates,
                "has_deletes": has_deletes,
                "insert_count": counts["inserts"],
                "update_count": counts["updates"],
                "delete_count": counts["deletes"]
            }

            if has_inserts:
                self._tables_with_inserts.append(source_table)
                self._total_inserts += counts["inserts"]

            if has_updates:
                self._tables_with_updates.append(source_table)
                self._total_updates += counts["updates"]

            if has_deletes:
                self._tables_with_deletes.append(source_table)
                self._total_deletes += counts["deletes"]

        return len(self._dataset_tables)

    @step(order=2, name="Aggregate Results", returns="has_changes")
    def step_aggregate_results(self) -> bool:
        """
        Step 2: Aggregate results and build statistics.

        Returns:
            True if any changes were found, False otherwise
        """
        has_any_changes = (
            len(self._tables_with_inserts) > 0 or
            len(self._tables_with_updates) > 0 or
            len(self._tables_with_deletes) > 0
        )

        self._stats = {
            'total_inserts': self._total_inserts,
            'total_updates': self._total_updates,
            'total_deletes': self._total_deletes,
            'tables_with_inserts': len(self._tables_with_inserts),
            'tables_with_updates': len(self._tables_with_updates),
            'tables_with_deletes': len(self._tables_with_deletes)
        }

        return has_any_changes

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Check for increment changes.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Check source tables
            self.step_check_source_tables()

            # Step 2: Aggregate results
            has_any_changes = self.step_aggregate_results()

            if not has_any_changes:
                return TaskResult.skipped(
                    message="No changes found in any source table",
                    task_name=self.context.task_name,
                    task_values={
                        'status': 'NO_CHANGES',
                        'has_inserts': False,
                        'has_updates': False,
                        'has_deletes': False,
                        'tables_with_inserts': json.dumps([]),
                        'tables_with_updates': json.dumps([]),
                        'tables_with_deletes': json.dumps([]),
                        'table_version_info': json.dumps({})
                    }
                )

            return TaskResult.success(
                message=f"Found changes: {self._total_inserts} inserts, {self._total_updates} updates, {self._total_deletes} deletes",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'status': 'CHANGES_FOUND',
                    'has_inserts': len(self._tables_with_inserts) > 0,
                    'has_updates': len(self._tables_with_updates) > 0,
                    'has_deletes': len(self._tables_with_deletes) > 0,
                    'tables_with_inserts': json.dumps(self._tables_with_inserts),
                    'tables_with_updates': json.dumps(self._tables_with_updates),
                    'tables_with_deletes': json.dumps(self._tables_with_deletes),
                    'table_version_info': json.dumps(self._table_version_info),
                    'entity': self.context.entity,
                    'unified_table': self._unified_table,
                    'total_inserts': self._total_inserts,
                    'total_updates': self._total_updates,
                    'total_deletes': self._total_deletes
                }
            )

        except Exception as e:
            raise RuntimeError(f"Failed to check increments: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate increment check results."""
        if result.is_failed:
            return result

        validation = ValidationResult(
            passed=True,
            message=f"Checked {len(self._dataset_tables)} source tables"
        )
        result.add_validation(validation)
        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_header("INCREMENTAL CHECK SUMMARY")

        if result.status == TaskStatus.SKIPPED:
            self.logger.info("NO CHANGES found in any source table")
            self.logger.info("Exiting early - no processing needed")
        else:
            self.logger.info(f"Found changes in {len(set(self._tables_with_inserts + self._tables_with_updates + self._tables_with_deletes))} unique table(s):")

            if self._tables_with_inserts:
                self.logger.info(f"\nINSERTS: {len(self._tables_with_inserts)} table(s)")
                for tbl in self._tables_with_inserts:
                    info = self._table_version_info[tbl]
                    self.logger.info(f"  - {tbl}: {info['insert_count']} inserts")

            if self._tables_with_updates:
                self.logger.info(f"\nUPDATES: {len(self._tables_with_updates)} table(s)")
                for tbl in self._tables_with_updates:
                    info = self._table_version_info[tbl]
                    self.logger.info(f"  - {tbl}: {info['update_count']} updates")

            if self._tables_with_deletes:
                self.logger.info(f"\nDELETES: {len(self._tables_with_deletes)} table(s)")
                for tbl in self._tables_with_deletes:
                    info = self._table_version_info[tbl]
                    self.logger.info(f"  - {tbl}: {info['delete_count']} deletes")

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                task_values = result.task_values or {}
                for key, value in task_values.items():
                    self.dbutils.jobs.taskValues.set(key=key, value=value)
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _get_last_processed_version(self, table_path: str) -> int:
        """Get last processed version from meta_info table."""
        try:
            if not self.spark.catalog.tableExists(self._meta_info_table):
                self.logger.info(f" ERROR: Meta info table doesn't exist: {self._meta_info_table}")
                self.logger.info(" Meta info table must be created by Prepare Tables notebook first")
                raise Exception(f"Meta info table {self._meta_info_table} does not exist. Run Prepare Tables notebook first.")

            meta_df = self.spark.read.table(self._meta_info_table) \
                .filter(col("table_name") == table_path) \
                .filter(col("entity_name") == self.context.entity)

            if meta_df.count() > 0:
                return meta_df.select("last_processed_version").first()[0]
            return None

        except Exception as e:
            self.logger.info(f"Error reading last_processed_version for {table_path}: {e}")
            raise

    def _get_current_version(self, table_path: str) -> int:
        """Get current version of Delta table."""
        try:
            history = self.spark.sql(f"DESCRIBE HISTORY {table_path}").selectExpr("max(version)").first()[0]
            return history
        except Exception as e:
            self.logger.info(f"Error getting version for {table_path}: {e}")
            return None

    def _is_cdf_enabled(self, table_path: str) -> bool:
        """Check if Change Data Feed is enabled on table."""
        try:
            props = self.spark.sql(f"SHOW TBLPROPERTIES {table_path}").collect()
            for prop in props:
                if prop['key'] == 'delta.enableChangeDataFeed' and prop['value'].lower() == 'true':
                    return True
            return False
        except Exception:
            return False

    def _check_table_changes(self, table_path: str):
        """
        Check if table has any changes since last processed version.

        Returns:
            Tuple of (has_inserts, has_updates, has_deletes, starting_version, current_version, counts)
        """
        try:
            # Check if table exists
            if not self.spark.catalog.tableExists(table_path):
                self.logger.info(f"  Table {table_path} doesn't exist")
                return False, False, False, 0, 0, {"inserts": 0, "updates": 0, "deletes": 0}

            # Check if CDF is enabled
            if not self._is_cdf_enabled(table_path):
                self.logger.info(f"  CDF not enabled on {table_path} - skipping")
                return False, False, False, 0, 0, {"inserts": 0, "updates": 0, "deletes": 0}

            last_version = self._get_last_processed_version(table_path)
            current_version = self._get_current_version(table_path)

            if current_version is None:
                self.logger.info(f"  Table {table_path} has no versions")
                return False, False, False, 0, 0, {"inserts": 0, "updates": 0, "deletes": 0}

            # Calculate starting version
            starting_version = (last_version + 1) if last_version is not None else 0

            # No new versions
            if current_version < starting_version:
                self.logger.info(f"  {table_path}: No new versions")
                return False, False, False, starting_version, current_version, {"inserts": 0, "updates": 0, "deletes": 0}

            self.logger.info(f"  {table_path}: Checking versions {starting_version} to {current_version}")

            # Read CDF once for all change types
            df_cdf = self.spark.read.format("delta") \
                .option("readChangeFeed", "true") \
                .option("startingVersion", starting_version) \
                .option("endingVersion", current_version) \
                .table(table_path)

            # Count all change types in a single pass
            change_counts = df_cdf.groupBy().agg(
                count(when(col("_change_type") == "insert", 1)).alias("inserts"),
                count(when(col("_change_type") == "update_postimage", 1)).alias("updates"),
                count(when(col("_change_type") == "delete", 1)).alias("deletes")
            ).collect()[0]

            insert_count = change_counts["inserts"]
            update_count = change_counts["updates"]
            delete_count = change_counts["deletes"]

            has_inserts = insert_count > 0
            has_updates = update_count > 0
            has_deletes = delete_count > 0

            if has_inserts or has_updates or has_deletes:
                self.logger.info(f"  {table_path}: Found changes:")
                if has_inserts:
                    self.logger.info(f"    - {insert_count} INSERT records")
                if has_updates:
                    self.logger.info(f"    - {update_count} UPDATE records")
                if has_deletes:
                    self.logger.info(f"    - {delete_count} DELETE records")
            else:
                self.logger.info(f"  {table_path}: No changes found")

            counts = {
                "inserts": insert_count,
                "updates": update_count,
                "deletes": delete_count
            }

            return has_inserts, has_updates, has_deletes, starting_version, current_version, counts

        except Exception as e:
            self.logger.info(f"  Error checking {table_path}: {e}")
            import traceback
            self.logger.info(traceback.format_exc())
            return False, False, False, 0, 0, {"inserts": 0, "updates": 0, "deletes": 0}
