"""
Increment Deletes to Unified Executor.

Processes DELETE incrementals from ALL source tables, updates unified table
status to DELETED, and handles master table deletions with survivorship
recalculation for multi-contributor scenarios.

Key Features:
    - CDF-based DELETE detection with deduplication
    - Marks unified records as DELETED (soft delete)
    - STANDALONE vs MULTI_CONTRIBUTOR scenario categorization
    - STANDALONE: Delete from master (no remaining contributors)
    - MULTI_CONTRIBUTOR: Recalculate survivorship with remaining contributors
    - Clears search_results for records referencing deleted masters
"""

import json
from datetime import datetime
from typing import Any, Dict, List, Tuple

from pyspark.sql.functions import col, lit, udf, row_number, desc
from pyspark.sql.types import (
    StringType, StructType, StructField, IntegerType, ArrayType, TimestampType
)
from pyspark.sql.window import Window

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class IncrementDeletesExecutor(BaseStepTask):
    """
    Executor for processing DELETE incrementals into unified/master tables.

    Reads CDF deletes from each source table, marks unified records as DELETED,
    and handles master table updates based on remaining contributors.

    Workflow:
        1. Read CDF deletes with deduplication (keep only latest=DELETE)
        2. Update unified table status to DELETED (Phase 1.5)
        3. Identify affected master records via master_lakefusion_id
        4. Categorize by remaining contributors:
           - STANDALONE (0 remaining) -> delete from master
           - MULTI_CONTRIBUTOR (has remaining) -> recalculate survivorship
        5. Batch execute: master deletes/updates, merge_activities, attribute_versions
        6. Clear search_results for records referencing deleted masters
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the increment deletes task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._survivorship_engine = None
        # Step execution intermediate results
        self._records_to_mark_delete: List[str] = []
        self._unified_updated_count: int = 0
        self._deleted_by_surrogate: Dict[str, Any] = {}
        self._lakefusion_to_deleted_sks: Dict[str, List[str]] = {}
        self._deleted_lakefusion_ids: List[str] = []
        self._standalone_ids: List[str] = []
        self._multi_contributor_ids: List[str] = []
        self._master_deleted_count: int = 0
        self._master_updated_count: int = 0
        self._merge_activities_count: int = 0
        self._attr_versions_count: int = 0
        self._survivorship_count: int = 0
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """PRE phase: Parse parameters and setup configuration."""
        self.print_header("INCREMENT DELETES TO UNIFIED")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")

        params = self.context.params
        self._primary_table = params.get('primary_table')
        self._primary_key = params.get('primary_key')
        self._entity_attributes = params.get('entity_attributes', [])
        self._entity_attributes_datatype = params.get('entity_attributes_datatype', {})
        self._attributes_mapping = params.get('attributes_mapping', [])
        self._match_attributes = params.get('match_attributes', [])
        self._dataset_objects = params.get('dataset_objects', {})
        self._survivorship_config = params.get('survivorship_config', [])
        self._has_deletes = params.get('has_deletes', True)
        self._tables_with_deletes = params.get('tables_with_deletes', [])
        self._table_version_info = params.get('table_version_info', {})

        # Parse JSON strings if needed
        for attr in ['entity_attributes', 'entity_attributes_datatype', 'attributes_mapping',
                     'match_attributes', 'dataset_objects', 'survivorship_config',
                     'tables_with_deletes', 'table_version_info']:
            val = getattr(self, f'_{attr}')
            if isinstance(val, str):
                setattr(self, f'_{attr}', json.loads(val))

        # Convert has_deletes to boolean
        if isinstance(self._has_deletes, str):
            self._has_deletes = self._has_deletes.lower() == 'true'

        # Build table names
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"
        self._master_table = f"{self.context.catalog_name}.gold.{self.context.entity}_master{experiment_suffix}"
        self._meta_info_table = f"{self.context.catalog_name}.silver.table_meta_info"
        self._merge_activities_table = f"{self._master_table}_merge_activities"
        self._attribute_version_sources_table = f"{self._master_table}_attribute_version_sources"

        self.logger.info(f"Tables with deletes: {len(self._tables_with_deletes)}")

    @step(order=1, name="Initialize Dependencies", returns="dependencies_ready")
    def step_initialize_dependencies(self) -> bool:
        """
        Step 1: Initialize dependencies and UDFs.

        Returns:
            True if dependencies are initialized successfully
        """
        from lakefusion_core_engine.identifiers import generate_surrogate_key
        from lakefusion_core_engine.models import RecordStatus, ActionType
        from lakefusion_core_engine.survivorship import SurvivorshipEngine

        self._generate_surrogate_key = generate_surrogate_key
        self._RecordStatus = RecordStatus
        self._ActionType = ActionType

        # Create UDF
        self._generate_surrogate_key_udf = udf(
            lambda source_path, source_id: generate_surrogate_key(source_path, str(source_id)),
            StringType()
        )

        # Initialize survivorship engine
        self._init_survivorship_engine(SurvivorshipEngine)

        return True

    @step(order=2, name="Collect Deletes", returns="delete_count")
    def step_collect_deletes(self) -> int:
        """
        Step 2: Collect all surrogate keys to mark as DELETED.

        Returns:
            Number of records to mark as deleted
        """
        self._records_to_mark_delete = self._phase1_collect_deletes()
        return len(self._records_to_mark_delete)

    @step(order=3, name="Update Unified Status", returns="unified_updated")
    def step_update_unified_status(self) -> int:
        """
        Step 3: Update unified table status to DELETED.

        Returns:
            Number of unified records updated
        """
        self._unified_updated_count = self._phase15_update_unified_to_deleted(self._records_to_mark_delete)
        return self._unified_updated_count

    @step(order=4, name="Identify Affected Masters", returns="affected_masters")
    def step_identify_affected_masters(self) -> int:
        """
        Step 4: Identify and categorize affected master records.

        Returns:
            Number of affected master records
        """
        self._deleted_by_surrogate, self._lakefusion_to_deleted_sks = \
            self._phase2_identify_affected_masters(self._records_to_mark_delete)

        self._deleted_lakefusion_ids = list(set([
            info['lakefusion_id'] for info in self._deleted_by_surrogate.values()
            if info['lakefusion_id']
        ]))

        # Categorize by remaining contributors
        self._standalone_ids, self._multi_contributor_ids = \
            self._categorize_by_remaining_contributors(self._deleted_lakefusion_ids, self._records_to_mark_delete)

        return len(self._deleted_lakefusion_ids)

    @step(order=5, name="Batch Execute", returns="records_processed")
    def step_batch_execute(self) -> int:
        """
        Step 5: Batch execute master deletes/updates, merge activities, attribute versions.

        Returns:
            Total number of records processed
        """
        self._master_deleted_count, self._master_updated_count, self._merge_activities_count, \
            self._attr_versions_count, self._survivorship_count = \
            self._phase3_batch_execution(
                self._standalone_ids, self._multi_contributor_ids,
                self._deleted_by_surrogate, self._lakefusion_to_deleted_sks
            )

        return self._master_deleted_count + self._master_updated_count

    @step(order=6, name="Cleanup", returns="cleanup_complete")
    def step_cleanup(self) -> bool:
        """
        Step 6: Clear search results and master_lakefusion_id for deleted records.

        Returns:
            True when cleanup is complete
        """
        self._phase4_cleanup(self._deleted_lakefusion_ids, self._deleted_by_surrogate)
        return True

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Process DELETE incrementals.

        Returns:
            TaskResult with execution status and metrics
        """
        # Early exit check
        if not self._has_deletes or len(self._tables_with_deletes) == 0:
            return TaskResult.skipped(
                message="No DELETE incrementals found",
                task_name=self.context.task_name,
                task_values={
                    'status': 'SKIPPED',
                    'records_marked_delete_unified': 0,
                    'records_deleted_master': 0
                }
            )

        try:
            # Step 1: Initialize dependencies
            self.step_initialize_dependencies()

            # Step 2: Collect deletes
            delete_count = self.step_collect_deletes()

            if delete_count == 0:
                return TaskResult.skipped(
                    message="No delete records found after deduplication",
                    task_name=self.context.task_name,
                    task_values={'status': 'NO_DATA_PROCESSED'}
                )

            self.logger.info(f"Total records to mark as DELETE: {delete_count}")

            # Step 3: Update unified status
            self.step_update_unified_status()

            # Step 4: Identify affected masters
            self.step_identify_affected_masters()

            # Step 5: Batch execute
            self.step_batch_execute()

            # Step 6: Cleanup
            self.step_cleanup()

            self._stats = {
                'records_marked_delete': len(self._records_to_mark_delete),
                'unified_updated': self._unified_updated_count,
                'master_deleted': self._master_deleted_count,
                'master_updated_survivorship': self._master_updated_count,
                'merge_activities': self._merge_activities_count,
                'attribute_versions': self._attr_versions_count,
                'survivorship_recalculations': self._survivorship_count,
                'standalone_count': len(self._standalone_ids),
                'multi_contributor_count': len(self._multi_contributor_ids),
                'sources_processed': len(self._tables_with_deletes)
            }

            return TaskResult.success(
                message=f"Marked {len(self._records_to_mark_delete)} unified records as DELETED, "
                        f"deleted {self._master_deleted_count} master records",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'status': 'SUCCESS',
                    'records_marked_delete_unified': len(self._records_to_mark_delete),
                    'records_deleted_master': self._master_deleted_count,
                    'records_updated_master_survivorship': self._master_updated_count,
                    'merge_activities_logged': self._merge_activities_count
                }
            )

        except Exception as e:
            raise RuntimeError(f"Failed to process delete incrementals: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate delete processing results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        records_deleted = self._stats.get('records_marked_delete', 0)
        validation = ValidationResult(
            passed=records_deleted >= 0,
            message=f"Marked {records_deleted} records as DELETED in unified table"
        )
        result.add_validation(validation)
        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("status", "SUCCESS")
                self.dbutils.jobs.taskValues.set("records_marked_delete_unified",
                    self._stats.get('records_marked_delete', 0))
                self.dbutils.jobs.taskValues.set("records_deleted_master",
                    self._stats.get('master_deleted', 0))
                self.dbutils.jobs.taskValues.set("records_updated_master_survivorship",
                    self._stats.get('master_updated_survivorship', 0))
                self.dbutils.jobs.taskValues.set("merge_activities_logged",
                    self._stats.get('merge_activities', 0))
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _init_survivorship_engine(self, SurvivorshipEngine) -> None:
        """Initialize survivorship engine if config is available."""
        if self._survivorship_config:
            try:
                self._survivorship_engine = SurvivorshipEngine(
                    survivorship_config=self._survivorship_config,
                    entity_attributes=self._entity_attributes,
                    entity_attributes_datatype=self._entity_attributes_datatype,
                    id_key="surrogate_key"
                )
                self.logger.info(f"Survivorship Engine initialized with {len(self._survivorship_config)} rules")
            except Exception as e:
                self.logger.info(f"Failed to initialize Survivorship Engine: {e}")
                self._survivorship_engine = None
        else:
            self.logger.info("No survivorship_config provided - survivorship recalculation will be skipped")

    def _get_mapping_for_table(self, source_table: str) -> Dict:
        """Get attribute mapping for a specific source table."""
        for mapping in self._attributes_mapping:
            if source_table in mapping:
                return mapping[source_table]
        return {}

    def _read_and_deduplicate_cdf_for_deletes(self, source_table: str, start_version: int,
                                               end_version: int, source_pk_column: str) -> List[str]:
        """Read CDF and deduplicate, keeping only records with DELETE as latest operation."""
        from pyspark.sql import functions as F
        from pyspark.sql.window import Window

        self.logger.info(f"  Reading ALL CDF change types for deduplication...")

        df_cdf = self.spark.read.format("delta") \
            .option("readChangeFeed", "true") \
            .option("startingVersion", start_version) \
            .option("endingVersion", end_version) \
            .table(source_table)

        # Classify operations
        df_cdf = df_cdf.withColumn(
            "operation_type",
            F.when(F.col("_change_type") == "insert", F.lit("insert"))
             .when(F.col("_change_type") == "update_postimage", F.lit("update"))
             .when(F.col("_change_type") == "delete", F.lit("delete"))
             .otherwise(F.col("_change_type"))
        )

        # Generate surrogate_key
        df_cdf = df_cdf.withColumn("_source_pk_value", F.col(source_pk_column).cast("string"))
        df_cdf = df_cdf.withColumn(
            "surrogate_key",
            self._generate_surrogate_key_udf(F.lit(source_table), F.col("_source_pk_value"))
        )

        # Deduplication: Keep LATEST operation per surrogate_key
        window_spec = Window.partitionBy("surrogate_key") \
                            .orderBy(F.desc("_commit_version"), F.desc("_commit_timestamp"))

        df_latest = df_cdf.withColumn(
            "_row_num", F.row_number().over(window_spec)
        ).filter(F.col("_row_num") == 1)

        # Keep ONLY records where latest operation is DELETE
        df_deletes_only = df_latest.filter(F.col("operation_type") == "delete")

        delete_count = df_deletes_only.count()
        self.logger.info(f"  After deduplication: {delete_count} records with DELETE as latest operation")

        # Return list of surrogate_keys to mark as DELETED
        delete_surrogate_keys = [row.surrogate_key for row in df_deletes_only.select("surrogate_key").collect()]

        return delete_surrogate_keys

    def _phase1_collect_deletes(self) -> List[str]:
        """Phase 1: Collect all surrogate keys to mark as DELETED."""
        self.logger.info("=" * 80)
        self.logger.info("PHASE 1: COLLECTING DELETES FROM SOURCE TABLES")
        self.logger.info("=" * 80)

        records_to_mark_delete = []

        for source_table in self._tables_with_deletes:
            self.logger.info(f"\nProcessing: {source_table}")

            version_info = self._table_version_info.get(source_table)
            if not version_info or not version_info.get("has_deletes", False):
                self.logger.info(f"  No deletes for {source_table}, skipping...")
                continue

            starting_version = version_info.get("starting_version",
                version_info.get("last_processed_version", 0) + 1)
            current_version = version_info.get("current_version", 0)

            # Get attribute mapping
            attr_mapping = self._get_mapping_for_table(source_table)
            if not attr_mapping:
                self.logger.info(f"  No attribute mapping found, skipping...")
                continue

            # Determine primary key column name in source
            source_primary_key = attr_mapping.get(self._primary_key, self._primary_key)

            try:
                deleted_sks = self._read_and_deduplicate_cdf_for_deletes(
                    source_table, starting_version, current_version, source_primary_key
                )

                if len(deleted_sks) == 0:
                    self.logger.info(f"  No deletes to process after deduplication")
                    continue

                self.logger.info(f"  Generated {len(deleted_sks)} surrogate keys to mark as DELETE")
                records_to_mark_delete.extend(deleted_sks)

            except Exception as e:
                self.logger.info(f"  Error reading CDF from {source_table}: {e}")
                import traceback
                self.logger.info(traceback.format_exc())
                continue

        return records_to_mark_delete

    def _phase15_update_unified_to_deleted(self, records_to_mark_delete: List[str]) -> int:
        """Phase 1.5: Update unified table status to DELETED."""
        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 1.5: Update Unified Table Status to DELETED")
        self.logger.info("=" * 80)

        if not records_to_mark_delete:
            self.logger.info("  No records to update in unified table")
            return 0

        # Check which records actually exist in unified
        sks_str = "','".join(records_to_mark_delete)
        existing_records = self.spark.sql(f"""
            SELECT surrogate_key
            FROM {self._unified_table}
            WHERE surrogate_key IN ('{sks_str}')
            AND record_status IN ('{self._RecordStatus.ACTIVE.value}', '{self._RecordStatus.MERGED.value}')
        """).collect()

        existing_sks = [row.surrogate_key for row in existing_records]
        skipped_count = len(records_to_mark_delete) - len(existing_sks)

        if len(existing_sks) > 0:
            self.logger.info(f"  Updating {len(existing_sks)} records to DELETED status...")

            batch_size = 1000
            total_updated = 0

            for i in range(0, len(existing_sks), batch_size):
                batch = existing_sks[i:i + batch_size]
                sks_str = "','".join(batch)

                self.spark.sql(f"""
                    UPDATE {self._unified_table}
                    SET record_status = '{self._RecordStatus.DELETED.value}'
                    WHERE surrogate_key IN ('{sks_str}')
                    AND record_status IN ('{self._RecordStatus.ACTIVE.value}', '{self._RecordStatus.MERGED.value}')
                """)

                total_updated += len(batch)
                self.logger.info(f"    Updated batch {i//batch_size + 1}: {len(batch)} records")

            self.logger.info(f"  Successfully updated {total_updated} records to DELETED status")

        if skipped_count > 0:
            self.logger.info(f"  Skipped {skipped_count} records (not found in unified table)")

        return len(existing_sks)

    def _phase2_identify_affected_masters(self, records_to_mark_delete: List[str]) -> Tuple[Dict, Dict]:
        """Phase 2: Identify affected master records."""
        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 2: IDENTIFYING AFFECTED MASTER RECORDS")
        self.logger.info("=" * 80)

        deleted_by_surrogate = {}

        if records_to_mark_delete:
            self.logger.info(f"Looking up master_lakefusion_id for {len(records_to_mark_delete)} deleted surrogate keys...")

            batch_size = 1000
            for i in range(0, len(records_to_mark_delete), batch_size):
                batch = records_to_mark_delete[i:i + batch_size]
                sks_str = "','".join(batch)

                df_lookup = self.spark.sql(f"""
                    SELECT surrogate_key, master_lakefusion_id
                    FROM {self._unified_table}
                    WHERE surrogate_key IN ('{sks_str}')
                    AND master_lakefusion_id IS NOT NULL
                    AND master_lakefusion_id != ''
                """)

                for row in df_lookup.collect():
                    deleted_by_surrogate[row.surrogate_key] = {
                        'lakefusion_id': row.master_lakefusion_id,
                        'surrogate_key': row.surrogate_key
                    }

            self.logger.info(f"  Found {len(deleted_by_surrogate)} surrogate keys mapped to master_lakefusion_ids")

        # Create reverse mapping: lakefusion_id -> list of deleted surrogate_keys
        lakefusion_to_deleted_sks = {}
        for sk, info in deleted_by_surrogate.items():
            lfid = info['lakefusion_id']
            if lfid:
                if lfid not in lakefusion_to_deleted_sks:
                    lakefusion_to_deleted_sks[lfid] = []
                lakefusion_to_deleted_sks[lfid].append(sk)

        return deleted_by_surrogate, lakefusion_to_deleted_sks

    def _categorize_by_remaining_contributors(self, deleted_lakefusion_ids: List[str],
                                               records_to_mark_delete: List[str]) -> Tuple[List[str], List[str]]:
        """Categorize by remaining contributors (STANDALONE = 0, MULTI_CONTRIBUTOR = has remaining)."""
        self.logger.info("\nCategorizing affected master records by remaining contributors...")

        if not deleted_lakefusion_ids:
            self.logger.info("  No MERGED records to categorize")
            return [], []

        ids_str = "','".join(deleted_lakefusion_ids)
        ids_values = ",".join([f"('{id}')" for id in deleted_lakefusion_ids])
        deleted_sks_str = "','".join(records_to_mark_delete)

        df_categorized = self.spark.sql(f"""
            WITH DeletedIds AS (
                SELECT lakefusion_id FROM VALUES {ids_values} AS t(lakefusion_id)
            ),
            RemainingContributorCount AS (
                SELECT
                    master_lakefusion_id,
                    COUNT(*) as contributor_count
                FROM {self._unified_table}
                WHERE master_lakefusion_id IN ('{ids_str}')
                AND record_status = '{self._RecordStatus.MERGED.value}'
                AND surrogate_key NOT IN ('{deleted_sks_str}')
                GROUP BY master_lakefusion_id
            )
            SELECT
                d.lakefusion_id,
                COALESCE(cc.contributor_count, 0) as remaining_contributor_count,
                CASE
                    WHEN COALESCE(cc.contributor_count, 0) = 0 THEN 'STANDALONE'
                    ELSE 'MULTI_CONTRIBUTOR'
                END as scenario
            FROM DeletedIds d
            LEFT JOIN RemainingContributorCount cc ON d.lakefusion_id = cc.master_lakefusion_id
        """)

        standalone_ids = [row.lakefusion_id for row in df_categorized.filter(col("scenario") == "STANDALONE").collect()]
        multi_contributor_ids = [row.lakefusion_id for row in df_categorized.filter(col("scenario") == "MULTI_CONTRIBUTOR").collect()]

        self.logger.info(f"  STANDALONE (no remaining contributors): {len(standalone_ids)}")
        self.logger.info(f"  MULTI_CONTRIBUTOR (has remaining contributors): {len(multi_contributor_ids)}")

        return standalone_ids, multi_contributor_ids

    def _phase3_batch_execution(self, standalone_ids: List[str], multi_contributor_ids: List[str],
                                 deleted_by_surrogate: Dict, lakefusion_to_deleted_sks: Dict):
        """Phase 3: Batch execute master deletes/updates, merge activities, attribute versions."""
        from delta.tables import DeltaTable

        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 3: BATCH EXECUTION")
        self.logger.info("=" * 80)

        master_ids_to_delete = []
        all_master_updates = []
        all_merge_activities = []
        all_attribute_versions = []
        records_processed_with_survivorship = []

        # Process STANDALONE deletions
        if standalone_ids:
            self.logger.info(f"\nProcessing STANDALONE deletions ({len(standalone_ids)} records)...")

            for lakefusion_id in standalone_ids:
                master_ids_to_delete.append(lakefusion_id)
                deleted_sks = lakefusion_to_deleted_sks.get(lakefusion_id, [])

                for deleted_sk in deleted_sks:
                    all_merge_activities.append({
                        'master_id': lakefusion_id,
                        'match_id': deleted_sk,
                        'source': 'SYSTEM',
                        'version': None,
                        'action_type': self._ActionType.SOURCE_DELETE.value
                    })

            self.logger.info(f"  Prepared {len(standalone_ids)} STANDALONE records for deletion")

        # Process MULTI_CONTRIBUTOR deletions with survivorship
        if multi_contributor_ids and self._survivorship_engine:
            self.logger.info(f"\nProcessing MULTI_CONTRIBUTOR deletions ({len(multi_contributor_ids)} records)...")

            for lakefusion_id in multi_contributor_ids:
                result = self._process_multi_contributor_delete(
                    lakefusion_id, deleted_by_surrogate, lakefusion_to_deleted_sks
                )

                if result:
                    action, data = result

                    if action == 'DELETE':
                        master_ids_to_delete.append(lakefusion_id)
                        all_merge_activities.extend(data)
                    elif action == 'SURVIVORSHIP':
                        update_record, attr_mapping, merge_activities = data
                        all_master_updates.append(update_record)
                        all_attribute_versions.append({
                            'lakefusion_id': lakefusion_id,
                            'version': None,
                            'attribute_source_mapping': attr_mapping
                        })
                        all_merge_activities.extend(merge_activities)
                        records_processed_with_survivorship.append(lakefusion_id)

        # Execute batch operations
        master_version = None

        # Step 1: Delete from master table
        master_deleted_count = 0
        if master_ids_to_delete:
            master_deleted_count = self._batch_delete_from_master(list(set(master_ids_to_delete)))

        # Step 2: Update master table with survivorship results
        if all_master_updates:
            master_version = self._batch_update_master(all_master_updates)
            for activity in all_merge_activities:
                if activity['version'] is None and activity['master_id'] in records_processed_with_survivorship:
                    activity['version'] = master_version
            for attr_version in all_attribute_versions:
                attr_version['version'] = master_version

        # Step 3: Insert attribute versions
        if all_attribute_versions:
            self._batch_insert_attribute_versions(all_attribute_versions)

        # Step 4: Insert merge activities
        if all_merge_activities:
            # Set version for deletion activities
            if master_version is None:
                current_version = self.spark.sql(f"DESCRIBE HISTORY {self._master_table} LIMIT 1").first()['version']
                master_version = current_version + 1

            for activity in all_merge_activities:
                if activity['version'] is None:
                    activity['version'] = master_version

            self._batch_insert_merge_activities(all_merge_activities)

        return (master_deleted_count, len(all_master_updates), len(all_merge_activities),
                len(all_attribute_versions), len(records_processed_with_survivorship))

    def _process_multi_contributor_delete(self, lakefusion_id: str, deleted_by_surrogate: Dict,
                                           lakefusion_to_deleted_sks: Dict):
        """Process a MULTI_CONTRIBUTOR delete with survivorship recalculation."""
        try:
            deleted_sks_for_master = [
                sk for sk, info in deleted_by_surrogate.items()
                if info['lakefusion_id'] == lakefusion_id
            ]

            # Fetch remaining contributors (MERGED status, excluding deleted)
            df_contributors = self.spark.sql(f"""
                SELECT * FROM {self._unified_table}
                WHERE master_lakefusion_id = '{lakefusion_id}'
                AND record_status = '{self._RecordStatus.MERGED.value}'
                ORDER BY surrogate_key
            """)

            contributor_records = df_contributors.collect()

            if not contributor_records:
                # No remaining contributors, delete from master
                merge_activities = [{
                    'master_id': lakefusion_id,
                    'match_id': sk,
                    'source': 'SYSTEM',
                    'version': None,
                    'action_type': self._ActionType.SOURCE_DELETE.value
                } for sk in deleted_sks_for_master]
                return ('DELETE', merge_activities)

            # Convert to list of dicts for survivorship engine
            unified_records = []
            for row in contributor_records:
                record_dict = row.asDict()
                if 'surrogate_key' in record_dict and 'source_path' in record_dict:
                    unified_records.append(record_dict)

            if not unified_records:
                return None

            # Apply survivorship
            survivorship_result = self._survivorship_engine.apply_survivorship(
                unified_records=unified_records
            )

            resultant_record = survivorship_result.resultant_record
            attribute_source_mapping = survivorship_result.resultant_master_attribute_source_mapping

            # Build update record
            update_record = {'lakefusion_id': lakefusion_id}
            for attr in self._entity_attributes:
                if attr == 'lakefusion_id':
                    continue
                update_record[attr] = resultant_record.get(attr)

            if 'attributes_combined' in resultant_record:
                update_record['attributes_combined'] = resultant_record.get('attributes_combined')
            elif self._match_attributes:
                update_record['attributes_combined'] = self._generate_attributes_combined(
                    resultant_record, self._match_attributes
                )

            # Convert attribute_source_mapping
            updated_attr_mapping = []
            for attr_map in attribute_source_mapping:
                updated_attr_mapping.append({
                    'attribute_name': attr_map.attribute_name,
                    'attribute_value': attr_map.attribute_value,
                    'source': attr_map.source
                })

            # Get unique sources
            all_sources = []
            for m in updated_attr_mapping:
                source = m['source']
                if ',' in source:
                    all_sources.extend([s.strip() for s in source.split(',')])
                else:
                    all_sources.append(source)
            unique_sources = ','.join(sorted(set(all_sources)))

            merge_activities = [{
                'master_id': lakefusion_id,
                'match_id': sk,
                'source': unique_sources,
                'version': None,
                'action_type': self._ActionType.SOURCE_DELETE.value
            } for sk in deleted_sks_for_master]

            return ('SURVIVORSHIP', (update_record, updated_attr_mapping, merge_activities))

        except Exception as e:
            self.logger.info(f"Error processing multi-contributor delete {lakefusion_id}: {e}")
            import traceback
            self.logger.info(traceback.format_exc())

        return None

    def _generate_attributes_combined(self, record_dict: Dict, attributes_list: List[str]) -> str:
        """Generate attributes_combined string from attribute values."""
        values = []
        for attr in attributes_list:
            val = record_dict.get(attr)
            if val is not None and str(val).strip():
                values.append(str(val).strip().lower())
        return '||'.join(values) if values else ''

    def _batch_delete_from_master(self, master_ids_to_delete: List[str]) -> int:
        """Batch delete from master table."""
        self.logger.info(f"\nDeleting {len(master_ids_to_delete)} records from master table...")

        batch_size = 1000
        total_deleted = 0

        for i in range(0, len(master_ids_to_delete), batch_size):
            batch = master_ids_to_delete[i:i + batch_size]
            ids_str = "','".join(batch)

            self.spark.sql(f"""
                DELETE FROM {self._master_table}
                WHERE lakefusion_id IN ('{ids_str}')
            """)

            total_deleted += len(batch)
            self.logger.info(f"  Deleted batch {i//batch_size + 1}: {len(batch)} records")

        self.logger.info(f"  Successfully deleted {total_deleted} records from master table")
        return total_deleted

    def _batch_update_master(self, all_master_updates: List[Dict]) -> int:
        """Batch update master table with survivorship results."""
        from delta.tables import DeltaTable

        self.logger.info(f"\nUpdating {len(all_master_updates)} master records with survivorship results...")

        master_update_schema = StructType([StructField('lakefusion_id', StringType(), False)])
        for attr in self._entity_attributes:
            if attr != 'lakefusion_id':
                master_update_schema.add(StructField(attr, StringType(), True))

        if self._match_attributes:
            master_update_schema.add(StructField('attributes_combined', StringType(), True))

        df_master_updates = self.spark.createDataFrame(all_master_updates, schema=master_update_schema)

        master_delta = DeltaTable.forName(self.spark, self._master_table)
        master_delta.alias("target").merge(
            source=df_master_updates.alias("source"),
            condition="target.lakefusion_id = source.lakefusion_id"
        ).whenMatchedUpdateAll().execute()

        new_master_version = self.spark.sql(f"DESCRIBE HISTORY {self._master_table} LIMIT 1").first()['version']
        self.logger.info(f"  Updated {len(all_master_updates)} master records")
        self.logger.info(f"  Master version: {new_master_version}")

        return new_master_version

    def _batch_insert_merge_activities(self, all_merge_activities: List[Dict]) -> None:
        """Batch insert merge activities."""
        from delta.tables import DeltaTable

        self.logger.info(f"\nBatch inserting {len(all_merge_activities)} merge activities...")

        merge_activities_schema = StructType([
            StructField('master_id', StringType(), False),
            StructField('match_id', StringType(), True),
            StructField('source', StringType(), False),
            StructField('version', IntegerType(), False),
            StructField('action_type', StringType(), False),
            StructField('created_at', TimestampType(), False)
        ])

        now = datetime.now()
        activities_with_ts = [{**record, 'created_at': now} for record in all_merge_activities]

        merge_activities_df = self.spark.createDataFrame(activities_with_ts, schema=merge_activities_schema)

        merge_activities_delta = DeltaTable.forName(self.spark, self._merge_activities_table)

        merge_activities_delta.alias("target").merge(
            source=merge_activities_df.alias("source"),
            condition="""target.master_id = source.master_id
                         AND target.match_id = source.match_id
                         AND target.source = source.source
                         AND target.version = source.version
                         AND target.action_type = source.action_type"""
        ).whenNotMatchedInsertAll().execute()

        self.logger.info(f"  Inserted {len(all_merge_activities)} merge activities")

    def _batch_insert_attribute_versions(self, all_attribute_versions: List[Dict]) -> None:
        """Batch insert attribute version sources."""
        from delta.tables import DeltaTable

        self.logger.info(f"\nBatch inserting {len(all_attribute_versions)} attribute versions...")

        attr_version_schema = StructType([
            StructField('lakefusion_id', StringType(), False),
            StructField('version', IntegerType(), False),
            StructField('attribute_source_mapping', ArrayType(StructType([
                StructField('attribute_name', StringType(), True),
                StructField('attribute_value', StringType(), True),
                StructField('source', StringType(), True)
            ])), False)
        ])

        df_attr_versions = self.spark.createDataFrame(all_attribute_versions, schema=attr_version_schema)

        attr_version_delta = DeltaTable.forName(self.spark, self._attribute_version_sources_table)

        attr_version_delta.alias("target").merge(
            source=df_attr_versions.alias("source"),
            condition="target.lakefusion_id = source.lakefusion_id AND target.version = source.version"
        ).whenNotMatchedInsertAll().execute()

        self.logger.info(f"  Inserted {len(all_attribute_versions)} attribute versions")

    def _phase4_cleanup(self, deleted_lakefusion_ids: List[str], deleted_by_surrogate: Dict) -> None:
        """Phase 4: Clear search results and master_lakefusion_id for deleted records."""
        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 4: CLEANUP")
        self.logger.info("=" * 80)

        # Clear search_results for records referencing deleted lakefusion_ids
        if deleted_lakefusion_ids:
            self.logger.info("\nClearing search_results for records referencing deleted lakefusion_ids...")

            total_cleared = 0

            if self.spark.catalog.tableExists(self._unified_table):
                for lakefusion_id in deleted_lakefusion_ids:
                    try:
                        records_with_refs = self.spark.sql(f"""
                            SELECT surrogate_key FROM {self._unified_table}
                            WHERE search_results LIKE '%{lakefusion_id}%'
                            AND record_status = 'ACTIVE'
                        """).collect()

                        if records_with_refs:
                            sks_str = "','".join([row.surrogate_key for row in records_with_refs])
                            self.spark.sql(f"""
                                UPDATE {self._unified_table}
                                SET search_results = '', scoring_results = ''
                                WHERE surrogate_key IN ('{sks_str}')
                            """)
                            total_cleared += len(records_with_refs)
                    except Exception:
                        continue

            if total_cleared > 0:
                self.logger.info(f"  Cleared search_results for {total_cleared} records")

        # Clear master_lakefusion_id for deleted records
        merged_records_to_clear = list(deleted_by_surrogate.keys())

        if merged_records_to_clear:
            self.logger.info("\nClearing master_lakefusion_id for deleted records...")

            batch_size = 1000
            total_cleared = 0

            for i in range(0, len(merged_records_to_clear), batch_size):
                batch = merged_records_to_clear[i:i + batch_size]
                sks_str = "','".join(batch)

                self.spark.sql(f"""
                    UPDATE {self._unified_table}
                    SET master_lakefusion_id = ''
                    WHERE surrogate_key IN ('{sks_str}')
                    AND record_status = '{self._RecordStatus.DELETED.value}'
                """)

                total_cleared += len(batch)

            self.logger.info(f"  Cleared master_lakefusion_id for {total_cleared} deleted records")
