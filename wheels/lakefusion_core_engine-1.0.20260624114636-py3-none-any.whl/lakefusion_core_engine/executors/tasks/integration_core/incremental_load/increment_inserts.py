"""
Increment Inserts to Unified Executor.

Processes INSERT incrementals from ALL source tables, transforms to unified schema,
and merges into unified table with proper deduplication.

Key Features:
    - CDF-based INSERT detection with deduplication
    - Keeps only records where latest operation is INSERT
    - Idempotency check to prevent duplicate inserts on re-run
    - Surrogate key generation for record identification
    - Attribute mapping and type conversion
"""

import json
from typing import Any, Dict, List

from pyspark.sql import DataFrame
from pyspark.sql.functions import (
    col, lit, udf, concat_ws, regexp_replace, trim, row_number,
    desc, current_timestamp, when
)
from pyspark.sql.types import StringType
from pyspark.sql.window import Window

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class IncrementInsertsExecutor(BaseStepTask):
    """
    Executor for processing INSERT incrementals into unified table.

    Reads CDF inserts from each source table, deduplicates, transforms
    to unified schema, and merges into unified table.

    Workflow:
        1. Read CDF inserts from each source with deduplication
        2. Transform using attribute mappings to unified schema
        3. Generate surrogate_key (hash of source_path + source_primary_key)
        4. Add metadata columns (status, timestamps, source info)
        5. Union all sources and deduplicate by surrogate_key
        6. Idempotency filter - exclude records already in unified
        7. Merge into unified table (insert only if not exists)
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the increment inserts task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        # Step execution intermediate results
        self._all_transformed_dfs: List[DataFrame] = []
        self._df_all_inserts: DataFrame = None
        self._df_deduped: DataFrame = None
        self._total_insert_count: int = 0
        self._deduped_count: int = 0
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """PRE phase: Parse parameters and setup configuration."""
        self.print_header("INCREMENT INSERTS TO UNIFIED")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")

        params = self.context.params
        self._primary_table = params.get('primary_table')
        self._primary_key = params.get('primary_key')
        self._entity_attributes = params.get('entity_attributes', [])
        self._entity_attributes_datatype = params.get('entity_attributes_datatype', {})
        self._attributes_mapping = params.get('attributes_mapping', [])
        self._match_attributes = params.get('match_attributes', [])
        self._has_inserts = params.get('has_inserts', True)
        self._tables_with_inserts = params.get('tables_with_inserts', [])
        self._table_version_info = params.get('table_version_info', {})

        # Parse JSON strings if needed
        for attr in ['entity_attributes', 'entity_attributes_datatype', 'attributes_mapping',
                     'match_attributes', 'tables_with_inserts', 'table_version_info']:
            val = getattr(self, f'_{attr}')
            if isinstance(val, str):
                setattr(self, f'_{attr}', json.loads(val))

        # Convert has_inserts to boolean
        if isinstance(self._has_inserts, str):
            self._has_inserts = self._has_inserts.lower() == 'true'

        # Add lakefusion_id to entity attributes if not present
        if "lakefusion_id" not in self._entity_attributes:
            self._entity_attributes.append("lakefusion_id")

        # Build table names
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"
        self._master_table = f"{self.context.catalog_name}.gold.{self.context.entity}_master{experiment_suffix}"
        self._meta_info_table = f"{self.context.catalog_name}.silver.table_meta_info"

        self.logger.info(f"Tables with inserts: {len(self._tables_with_inserts)}")

    @step(order=1, name="Initialize Dependencies", returns="dependencies_ready")
    def step_initialize_dependencies(self) -> bool:
        """
        Step 1: Initialize dependencies and UDFs.

        Returns:
            True if dependencies are initialized successfully
        """
        from lakefusion_core_engine.identifiers import generate_surrogate_key
        from lakefusion_core_engine.models import RecordStatus

        self._generate_surrogate_key = generate_surrogate_key
        self._RecordStatus = RecordStatus

        # Create UDF
        self._generate_surrogate_key_udf = udf(
            lambda source_path, source_id: generate_surrogate_key(source_path, str(source_id)),
            StringType()
        )

        return True

    @step(order=2, name="Process Source Tables", returns="tables_processed")
    def step_process_source_tables(self) -> int:
        """
        Step 2: Process each source table for INSERT incrementals.

        Returns:
            Number of tables processed with data
        """
        self._all_transformed_dfs = []

        for source_table in self._tables_with_inserts:
            df_transformed = self._process_source_table(source_table)
            if df_transformed is not None:
                self._all_transformed_dfs.append(df_transformed)

        return len(self._all_transformed_dfs)

    @step(order=3, name="Union and Deduplicate", returns="deduped_count")
    def step_union_and_deduplicate(self) -> int:
        """
        Step 3: Union all sources and deduplicate by surrogate_key.

        Returns:
            Number of records after deduplication
        """
        if len(self._all_transformed_dfs) == 0:
            return 0

        # Union all sources
        self._df_all_inserts = self._all_transformed_dfs[0]
        for df in self._all_transformed_dfs[1:]:
            self._df_all_inserts = self._df_all_inserts.unionByName(df, allowMissingColumns=True)

        self._total_insert_count = self._df_all_inserts.count()
        self.logger.info(f"Combined total: {self._total_insert_count} INSERT records")

        # Idempotency filter
        self._df_all_inserts = self._filter_existing_records(self._df_all_inserts)

        # Deduplicate by surrogate_key
        window_spec = Window.partitionBy("surrogate_key").orderBy(desc("created_at"))
        self._df_deduped = self._df_all_inserts \
            .withColumn("_rn", row_number().over(window_spec)) \
            .filter(col("_rn") == 1) \
            .drop("_rn")

        self._deduped_count = self._df_deduped.count()
        return self._deduped_count

    @step(order=4, name="Merge Into Unified", returns="merged_count")
    def step_merge_into_unified(self) -> int:
        """
        Step 4: Merge deduplicated inserts into unified table.

        Returns:
            Number of records merged
        """
        self._merge_into_unified(self._df_deduped)
        return self._deduped_count

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Process INSERT incrementals.

        Returns:
            TaskResult with execution status and metrics
        """
        # Early exit check
        if not self._has_inserts or len(self._tables_with_inserts) == 0:
            return TaskResult.skipped(
                message="No INSERT incrementals found",
                task_name=self.context.task_name,
                task_values={
                    'status': 'SKIPPED',
                    'records_inserted': 0
                }
            )

        try:
            # Step 1: Initialize dependencies
            self.step_initialize_dependencies()

            # Step 2: Process source tables
            tables_processed = self.step_process_source_tables()

            if tables_processed == 0:
                return TaskResult.skipped(
                    message="No data to process from any source table",
                    task_name=self.context.task_name,
                    task_values={'status': 'NO_DATA_PROCESSED'}
                )

            # Step 3: Union and deduplicate
            deduped_count = self.step_union_and_deduplicate()

            if deduped_count == 0:
                return TaskResult.skipped(
                    message="No new records to insert after deduplication",
                    task_name=self.context.task_name,
                    task_values={'status': 'NO_NEW_RECORDS'}
                )

            # Step 4: Merge into unified
            self.step_merge_into_unified()

            self._stats = {
                'total_inserts': self._total_insert_count,
                'deduped_count': self._deduped_count,
                'sources_processed': len(self._all_transformed_dfs)
            }

            return TaskResult.success(
                message=f"Merged {self._deduped_count} new records into unified table",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'status': 'SUCCESS',
                    'records_inserted': self._deduped_count,
                    'unified_table': self._unified_table,
                    'master_table': self._master_table
                }
            )

        except Exception as e:
            raise RuntimeError(f"Failed to process insert incrementals: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate insert processing results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        records_inserted = self._stats.get('deduped_count', 0)
        validation = ValidationResult(
            passed=records_inserted >= 0,
            message=f"Inserted {records_inserted} records into unified table"
        )
        result.add_validation(validation)
        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("status", "SUCCESS")
                self.dbutils.jobs.taskValues.set("records_inserted",
                    self._stats.get('deduped_count', 0))
                self.dbutils.jobs.taskValues.set("unified_table", self._unified_table)
                self.dbutils.jobs.taskValues.set("master_table", self._master_table)
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _get_mapping_for_table(self, source_table: str) -> Dict:
        """Get attribute mapping for a specific source table."""
        for attr_map in self._attributes_mapping:
            for dataset_path, mapping in attr_map.items():
                if source_table.startswith(dataset_path):
                    # Reverse mapping: source->entity
                    return {v: k for k, v in mapping.items()}
        return {}

    def _get_spark_data_type(self, dtype_str: str) -> str:
        """Convert string data type to Spark type."""
        dtype_map = {
            'bigint': 'bigint', 'boolean': 'boolean', 'char': 'string',
            'varchar': 'string', 'date': 'date', 'double precision': 'double',
            'integer': 'int', 'numeric': 'float', 'real': 'float',
            'smallint': 'smallint', 'text': 'string', 'timestamp': 'timestamp',
            'string': 'string', 'int': 'int', 'long': 'bigint',
            'double': 'double', 'float': 'float', 'decimal': 'decimal(10,2)',
        }
        return dtype_map.get(dtype_str.lower().strip(), 'string')

    def _read_and_deduplicate_cdf(self, source_table: str, start_version: int,
                                   end_version: int, source_pk_column: str):
        """Read CDF and deduplicate, keeping only records with INSERT as latest operation."""
        from pyspark.sql import functions as F
        from pyspark.sql.window import Window

        self.logger.info(f"  Reading ALL CDF change types for deduplication...")

        df_cdf = self.spark.read.format("delta") \
            .option("readChangeFeed", "true") \
            .option("startingVersion", start_version) \
            .option("endingVersion", end_version) \
            .table(source_table)

        # Classify operations
        df_cdf = df_cdf.withColumn(
            "operation_type",
            F.when(F.col("_change_type") == "insert", F.lit("insert"))
             .when(F.col("_change_type") == "update_postimage", F.lit("update"))
             .when(F.col("_change_type") == "delete", F.lit("delete"))
             .otherwise(F.col("_change_type"))
        )

        # Generate surrogate_key
        df_cdf = df_cdf.withColumn(
            "_source_id_concat",
            F.col(source_pk_column).cast("string")
        )

        df_cdf = df_cdf.withColumn(
            "surrogate_key",
            self._generate_surrogate_key_udf(F.lit(source_table), F.col("_source_id_concat"))
        )

        # Keep LATEST operation per surrogate_key
        window_spec = Window.partitionBy("surrogate_key") \
                            .orderBy(F.desc("_commit_version"), F.desc("_commit_timestamp"))

        df_latest = df_cdf.withColumn(
            "_row_num", F.row_number().over(window_spec)
        ).filter(F.col("_row_num") == 1).drop("_row_num")

        # Keep ONLY records where latest operation is INSERT
        df_inserts_only = df_latest.filter(F.col("operation_type") == "insert")

        insert_count = df_inserts_only.count()
        self.logger.info(f"  After deduplication: {insert_count} records with INSERT as latest operation")

        return df_inserts_only.drop("operation_type", "_source_id_concat")

    def _process_source_table(self, source_table: str):
        """Process a single source table for INSERT incrementals."""
        self.logger.info(f"\nProcessing: {source_table}")

        version_info = self._table_version_info.get(source_table)
        if not version_info:
            self.logger.info(f"  Version info not found, skipping...")
            return None

        starting_version = version_info.get("starting_version", 0)
        current_version = version_info.get("current_version", 0)

        # Get attribute mapping
        mapping_dict = self._get_mapping_for_table(source_table)
        if not mapping_dict:
            self.logger.info(f"  No mapping found, skipping...")
            return None

        # Find source PK column
        source_pk_column = None
        for src_col, entity_col in mapping_dict.items():
            if entity_col == self._primary_key:
                source_pk_column = src_col
                break

        if not source_pk_column:
            self.logger.info(f"  Primary key not found in mapping, skipping...")
            return None

        try:
            # Read and deduplicate CDF
            df_inserts = self._read_and_deduplicate_cdf(
                source_table, starting_version, current_version, source_pk_column
            )

            if df_inserts.count() == 0:
                self.logger.info(f"  No inserts to process after deduplication")
                return None

            # Drop CDF metadata
            df_clean = df_inserts.drop("_change_type", "_commit_version", "_commit_timestamp")

            # Store source PK before transformation
            df_clean = df_clean.withColumn("_source_pk_value", col(source_pk_column).cast("string"))

            # Apply column mappings
            df_transformed = df_clean.selectExpr(
                *[f"`{source_col}` as `{entity_col}`" for source_col, entity_col in mapping_dict.items()],
                "_source_pk_value"
            )

            # Add missing entity attributes as NULL
            for col_name in self._entity_attributes:
                if col_name not in df_transformed.columns and col_name != "lakefusion_id":
                    sql_dtype = self._entity_attributes_datatype.get(col_name, "string")
                    spark_dtype = self._get_spark_data_type(sql_dtype)
                    df_transformed = df_transformed.withColumn(col_name, lit(None).cast(spark_dtype))

            # Add metadata columns
            df_transformed = df_transformed.withColumn(
                "surrogate_key",
                self._generate_surrogate_key_udf(lit(source_table), col("_source_pk_value"))
            )
            df_transformed = df_transformed.withColumn("source_path", lit(source_table))
            df_transformed = df_transformed.withColumn("source_id", col("_source_pk_value"))
            df_transformed = df_transformed.withColumn("master_lakefusion_id", lit(""))
            df_transformed = df_transformed.drop("_source_pk_value")

            df_transformed = df_transformed.withColumn("record_status", lit(self._RecordStatus.ACTIVE.value))
            df_transformed = df_transformed.withColumn("created_at", current_timestamp())
            df_transformed = df_transformed.withColumn("updated_at", lit(None).cast("timestamp"))

            # Generate attributes_combined
            available_attrs = [attr for attr in self._match_attributes if attr in df_transformed.columns]
            if available_attrs:
                df_transformed = df_transformed.withColumn(
                    "attributes_combined",
                    concat_ws(" | ", *[regexp_replace(trim(col(c)), r'\s+', ' ') for c in available_attrs])
                )
            else:
                df_transformed = df_transformed.withColumn("attributes_combined", lit(""))

            # Add search/scoring columns
            df_transformed = df_transformed.withColumn("search_results", lit(""))
            df_transformed = df_transformed.withColumn("scoring_results", lit(""))

            self.logger.info(f"  Completed processing {source_table}")
            return df_transformed

        except Exception as e:
            self.logger.info(f"  Error processing {source_table}: {e}")
            import traceback
            self.logger.info(traceback.format_exc())
            return None

    def _filter_existing_records(self, df_inserts):
        """Filter out records that already exist in unified table (idempotency)."""
        self.logger.info("Checking for existing records (idempotency)...")

        df_new = df_inserts.alias("ins").join(
            self.spark.table(self._unified_table).select("surrogate_key").alias("uni"),
            col("ins.surrogate_key") == col("uni.surrogate_key"),
            "left_anti"
        )

        original_count = df_inserts.count()
        new_count = df_new.count()

        if original_count > new_count:
            self.logger.info(f"  Skipped {original_count - new_count} records already in unified")

        return df_new

    def _merge_into_unified(self, df_deduped):
        """Merge deduplicated inserts into unified table."""
        from delta.tables import DeltaTable

        self.logger.info(f"\nMerging into unified table: {self._unified_table}")

        if not self.spark.catalog.tableExists(self._unified_table):
            error_msg = f"ERROR: Unified table {self._unified_table} does not exist. Run Prepare Tables notebook first."
            self.logger.info(error_msg)
            raise Exception(error_msg)

        delta_unified = DeltaTable.forName(self.spark, self._unified_table)

        delta_unified.alias("target").merge(
            df_deduped.alias("source"),
            "target.surrogate_key = source.surrogate_key"
        ).whenNotMatchedInsertAll().execute()

        self.logger.info(f"  Merged records into unified table")
