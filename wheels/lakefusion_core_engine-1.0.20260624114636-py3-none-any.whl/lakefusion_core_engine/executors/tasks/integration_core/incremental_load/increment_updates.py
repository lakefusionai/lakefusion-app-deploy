"""
Increment Updates to Unified Executor.

Processes UPDATE incrementals from ALL source tables, applies survivorship
for multi-contributor scenarios, and updates unified/master tables.

Key Features:
    - CDF-based UPDATE detection with PRE/POST comparison
    - Identifies changed attributes by comparing preimage vs postimage
    - STANDALONE vs MULTI_CONTRIBUTOR scenario categorization
    - Survivorship recalculation for multi-contributor updates
    - Batch execution for master, merge_activities, attribute_version_sources tables
"""

import json
from datetime import datetime
from typing import Any, Dict, List, Set, Tuple

from pyspark.sql import DataFrame
from pyspark.sql.functions import (
    col, lit, udf, concat_ws, coalesce, regexp_replace, trim, row_number,
    desc, when
)
from pyspark.sql.types import (
    StringType, StructType, StructField, IntegerType, ArrayType, TimestampType
)
from pyspark.sql.window import Window

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class IncrementUpdatesExecutor(BaseStepTask):
    """
    Executor for processing UPDATE incrementals into unified/master tables.

    Reads CDF updates from each source table, compares PRE/POST to identify
    changed attributes, updates unified table, and applies survivorship for
    multi-contributor master records.

    Workflow:
        1. Read CDF updates (PRE and POST images) with deduplication
        2. Compare PRE vs POST to identify changed attributes
        3. Transform using attribute mappings to unified schema
        4. Update unified table with new values (Phase 1.5)
        5. Identify affected master records via master_lakefusion_id
        6. Categorize by scenarios (STANDALONE, MULTI_CONTRIBUTOR)
        7. Apply survivorship for MULTI_CONTRIBUTOR scenarios
        8. Batch execute: master updates, merge_activities, attribute_version_sources
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the increment updates task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._survivorship_engine = None
        # Step execution intermediate results
        self._all_transformed_updates: List[DataFrame] = []
        self._all_updated_surrogate_keys: List[str] = []
        self._changed_attributes_by_surrogate: Dict[str, List[str]] = {}
        self._df_all_updates: DataFrame = None
        self._df_all_updates_deduped: DataFrame = None
        self._total_update_count: int = 0
        self._deduped_count: int = 0
        self._matched_count: int = 0
        self._updated_lakefusion_ids: List[str] = []
        self._surrogate_to_lakefusion: Dict[str, str] = {}
        self._changed_attributes_by_lakefusion: Dict[str, List[str]] = {}
        self._standalone_ids: List[str] = []
        self._multi_contributor_ids: List[str] = []
        self._master_updates_count: int = 0
        self._merge_activities_count: int = 0
        self._attr_versions_count: int = 0
        self._survivorship_count: int = 0
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """PRE phase: Parse parameters and setup configuration."""
        self.print_header("INCREMENT UPDATES TO UNIFIED")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")

        params = self.context.params
        self._primary_table = params.get('primary_table')
        self._primary_key = params.get('primary_key')
        self._entity_attributes = params.get('entity_attributes', [])
        self._entity_attributes_datatype = params.get('entity_attributes_datatype', {})
        self._attributes_mapping = params.get('attributes_mapping', [])
        self._match_attributes = params.get('match_attributes', [])
        self._dataset_objects = params.get('dataset_objects', {})
        self._survivorship_config = params.get('survivorship_config', [])
        self._has_updates = params.get('has_updates', True)
        self._tables_with_updates = params.get('tables_with_updates', [])
        self._table_version_info = params.get('table_version_info', {})

        # Parse JSON strings if needed
        for attr in ['entity_attributes', 'entity_attributes_datatype', 'attributes_mapping',
                     'match_attributes', 'dataset_objects', 'survivorship_config',
                     'tables_with_updates', 'table_version_info']:
            val = getattr(self, f'_{attr}')
            if isinstance(val, str):
                setattr(self, f'_{attr}', json.loads(val))

        # Convert has_updates to boolean
        if isinstance(self._has_updates, str):
            self._has_updates = self._has_updates.lower() == 'true'

        # Build table names
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"
        self._master_table = f"{self.context.catalog_name}.gold.{self.context.entity}_master{experiment_suffix}"
        self._meta_info_table = f"{self.context.catalog_name}.silver.table_meta_info"
        self._merge_activities_table = f"{self._master_table}_merge_activities"
        self._attribute_version_sources_table = f"{self._master_table}_attribute_version_sources"

        self.logger.info(f"Tables with updates: {len(self._tables_with_updates)}")

    @step(order=1, name="Initialize Dependencies", returns="dependencies_ready")
    def step_initialize_dependencies(self) -> bool:
        """
        Step 1: Initialize dependencies and UDFs.

        Returns:
            True if dependencies are initialized successfully
        """
        from lakefusion_core_engine.identifiers import generate_surrogate_key
        from lakefusion_core_engine.models import RecordStatus, ActionType
        from lakefusion_core_engine.survivorship import SurvivorshipEngine

        self._generate_surrogate_key = generate_surrogate_key
        self._RecordStatus = RecordStatus
        self._ActionType = ActionType

        # Create UDF
        self._generate_surrogate_key_udf = udf(
            lambda source_path, source_id: generate_surrogate_key(source_path, str(source_id)),
            StringType()
        )

        # Initialize survivorship engine
        self._init_survivorship_engine(SurvivorshipEngine)

        return True

    @step(order=2, name="Process Source Tables", returns="tables_processed")
    def step_process_source_tables(self) -> int:
        """
        Step 2: Process source tables and collect updates.

        Returns:
            Number of tables processed with data
        """
        self._all_transformed_updates, self._all_updated_surrogate_keys, self._changed_attributes_by_surrogate = \
            self._phase1_process_source_tables()

        return len(self._all_transformed_updates)

    @step(order=3, name="Union and Deduplicate", returns="deduped_count")
    def step_union_and_deduplicate(self) -> int:
        """
        Step 3: Union all sources and deduplicate by surrogate_key.

        Returns:
            Number of records after deduplication
        """
        if len(self._all_transformed_updates) == 0:
            return 0

        # Union all sources
        self._df_all_updates = self._all_transformed_updates[0]
        for df in self._all_transformed_updates[1:]:
            self._df_all_updates = self._df_all_updates.unionByName(df, allowMissingColumns=True)

        self._total_update_count = self._df_all_updates.count()
        self.logger.info(f"Combined total: {self._total_update_count} UPDATE records")

        # Deduplicate by surrogate_key
        window_spec = Window.partitionBy("surrogate_key").orderBy(lit(1))
        self._df_all_updates_deduped = self._df_all_updates \
            .withColumn("_rn", row_number().over(window_spec)) \
            .filter(col("_rn") == 1) \
            .drop("_rn")

        self._deduped_count = self._df_all_updates_deduped.count()
        return self._deduped_count

    @step(order=4, name="Update Unified Table", returns="unified_updated")
    def step_update_unified_table(self) -> int:
        """
        Step 4: Update unified table with new values.

        Returns:
            Number of unified records updated
        """
        self._matched_count = self._phase15_update_unified(self._df_all_updates_deduped)
        return self._matched_count

    @step(order=5, name="Identify Affected Masters", returns="affected_masters")
    def step_identify_affected_masters(self) -> int:
        """
        Step 5: Identify affected master records via merge_activities.

        Returns:
            Number of affected master records
        """
        self._updated_lakefusion_ids, self._surrogate_to_lakefusion, self._changed_attributes_by_lakefusion = \
            self._phase2_identify_affected_masters(
                self._df_all_updates_deduped, self._changed_attributes_by_surrogate
            )

        # Categorize by scenario
        self._standalone_ids, self._multi_contributor_ids = self._categorize_by_scenario(self._updated_lakefusion_ids)

        return len(self._updated_lakefusion_ids)

    @step(order=6, name="Batch Execute", returns="records_processed")
    def step_batch_execute(self) -> int:
        """
        Step 6: Batch execute master updates, merge activities, attribute versions.

        Returns:
            Total number of records processed
        """
        self._master_updates_count, self._merge_activities_count, self._attr_versions_count, self._survivorship_count = \
            self._phase3_batch_execution(
                self._standalone_ids, self._multi_contributor_ids,
                self._surrogate_to_lakefusion, self._changed_attributes_by_lakefusion
            )

        return self._master_updates_count

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Process UPDATE incrementals.

        Returns:
            TaskResult with execution status and metrics
        """
        # Early exit check
        if not self._has_updates or len(self._tables_with_updates) == 0:
            return TaskResult.skipped(
                message="No UPDATE incrementals found",
                task_name=self.context.task_name,
                task_values={
                    'status': 'SKIPPED',
                    'records_updated_unified': 0,
                    'records_updated_master': 0
                }
            )

        try:
            # Step 1: Initialize dependencies
            self.step_initialize_dependencies()

            # Step 2: Process source tables
            tables_processed = self.step_process_source_tables()

            if tables_processed == 0:
                return TaskResult.skipped(
                    message="No data to process from any source table",
                    task_name=self.context.task_name,
                    task_values={'status': 'NO_DATA_PROCESSED'}
                )

            # Step 3: Union and deduplicate
            self.step_union_and_deduplicate()

            # Step 4: Update unified table
            self.step_update_unified_table()

            # Step 5: Identify affected masters
            self.step_identify_affected_masters()

            # Step 6: Batch execute
            self.step_batch_execute()

            self._stats = {
                'total_updates': self._total_update_count,
                'deduped_count': self._deduped_count,
                'unified_updates': self._matched_count,
                'master_updates': self._master_updates_count,
                'merge_activities': self._merge_activities_count,
                'attribute_versions': self._attr_versions_count,
                'survivorship_recalculations': self._survivorship_count,
                'standalone_count': len(self._standalone_ids),
                'multi_contributor_count': len(self._multi_contributor_ids),
                'sources_processed': len(self._all_transformed_updates)
            }

            return TaskResult.success(
                message=f"Updated {self._matched_count} unified, {self._master_updates_count} master records",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'status': 'SUCCESS',
                    'records_updated_unified': self._matched_count,
                    'records_updated_master': self._master_updates_count,
                    'merge_activities_logged': self._merge_activities_count,
                    'attribute_versions_logged': self._attr_versions_count,
                    'records_requiring_survivorship': self._survivorship_count
                }
            )

        except Exception as e:
            raise RuntimeError(f"Failed to process update incrementals: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate update processing results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        records_updated = self._stats.get('unified_updates', 0)
        validation = ValidationResult(
            passed=records_updated >= 0,
            message=f"Updated {records_updated} records in unified table"
        )
        result.add_validation(validation)
        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("status", "SUCCESS")
                self.dbutils.jobs.taskValues.set("records_updated_unified",
                    self._stats.get('unified_updates', 0))
                self.dbutils.jobs.taskValues.set("records_updated_master",
                    self._stats.get('master_updates', 0))
                self.dbutils.jobs.taskValues.set("merge_activities_logged",
                    self._stats.get('merge_activities', 0))
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _init_survivorship_engine(self, SurvivorshipEngine) -> None:
        """Initialize survivorship engine if config is available."""
        if self._survivorship_config:
            try:
                self._survivorship_engine = SurvivorshipEngine(
                    survivorship_config=self._survivorship_config,
                    entity_attributes=self._entity_attributes,
                    entity_attributes_datatype=self._entity_attributes_datatype,
                    id_key="surrogate_key"
                )
                self.logger.info(f"Survivorship Engine initialized with {len(self._survivorship_config)} rules")
            except Exception as e:
                self.logger.info(f"Failed to initialize Survivorship Engine: {e}")
                self._survivorship_engine = None
        else:
            self.logger.info("No survivorship_config provided - survivorship recalculation will be skipped")

    def _get_mapping_for_table(self, source_table: str) -> Dict:
        """Get attribute mapping for a specific source table (reversed: source->entity)."""
        for mapping in self._attributes_mapping:
            if source_table in mapping:
                # Reverse mapping: entity->source becomes source->entity
                return {v: k for k, v in mapping[source_table].items()}
        return {}

    def _get_spark_data_type(self, dtype_str: str) -> str:
        """Convert string data type to Spark type."""
        dtype_map = {
            'bigint': 'bigint', 'boolean': 'boolean', 'char': 'string',
            'varchar': 'string', 'date': 'date', 'double precision': 'double',
            'integer': 'int', 'numeric': 'float', 'real': 'float',
            'smallint': 'smallint', 'text': 'string', 'timestamp': 'timestamp',
            'string': 'string', 'int': 'int', 'long': 'bigint',
            'double': 'double', 'float': 'float', 'decimal': 'decimal(10,2)',
        }
        return dtype_map.get(dtype_str.lower().strip(), 'string')

    def _read_and_deduplicate_cdf_for_updates(self, source_table: str, start_version: int,
                                               end_version: int, source_pk_column: str):
        """Read CDF and deduplicate, keeping only records with UPDATE as latest operation."""
        from pyspark.sql import functions as F
        from pyspark.sql.window import Window

        self.logger.info(f"  Reading ALL CDF change types for deduplication...")

        df_cdf = self.spark.read.format("delta") \
            .option("readChangeFeed", "true") \
            .option("startingVersion", start_version) \
            .option("endingVersion", end_version) \
            .table(source_table)

        # Classify operations
        df_cdf = df_cdf.withColumn(
            "operation_type",
            F.when(F.col("_change_type") == "insert", F.lit("insert"))
             .when(F.col("_change_type") == "update_postimage", F.lit("update"))
             .when(F.col("_change_type") == "delete", F.lit("delete"))
             .when(F.col("_change_type") == "update_preimage", F.lit("update_pre"))
             .otherwise(F.col("_change_type"))
        )

        # Generate surrogate_key
        df_cdf = df_cdf.withColumn("_source_pk_value", F.col(source_pk_column).cast("string"))
        df_cdf = df_cdf.withColumn(
            "surrogate_key",
            self._generate_surrogate_key_udf(F.lit(source_table), F.col("_source_pk_value"))
        )

        # Deduplication: Keep LATEST operation per surrogate_key (exclude preimages for dedup)
        df_for_dedup = df_cdf.filter(F.col("operation_type") != "update_pre")

        window_spec = Window.partitionBy("surrogate_key") \
                            .orderBy(F.desc("_commit_version"), F.desc("_commit_timestamp"))

        df_latest = df_for_dedup.withColumn(
            "_row_num", F.row_number().over(window_spec)
        ).filter(F.col("_row_num") == 1)

        # Keep ONLY records where latest operation is UPDATE
        df_updates_only = df_latest.filter(F.col("operation_type") == "update")

        update_count = df_updates_only.count()
        self.logger.info(f"  After deduplication: {update_count} records with UPDATE as latest operation")

        if update_count == 0:
            return self.spark.createDataFrame([], df_cdf.schema), \
                   self.spark.createDataFrame([], df_cdf.schema)

        # Get surrogate_keys to process
        update_surrogate_keys = [row.surrogate_key for row in df_updates_only.select("surrogate_key").collect()]

        # Get BOTH preimage and postimage for these surrogate_keys
        df_preimage = df_cdf.filter(
            (F.col("_change_type") == "update_preimage") &
            (F.col("surrogate_key").isin(update_surrogate_keys))
        )

        df_postimage = df_cdf.filter(
            (F.col("_change_type") == "update_postimage") &
            (F.col("surrogate_key").isin(update_surrogate_keys))
        )

        # Keep only LATEST preimage and postimage by version
        window_latest = Window.partitionBy("surrogate_key", "_change_type") \
                              .orderBy(F.desc("_commit_version"), F.desc("_commit_timestamp"))

        df_preimage = df_preimage.withColumn("_rn", F.row_number().over(window_latest)) \
                                 .filter(F.col("_rn") == 1).drop("_rn")

        df_postimage = df_postimage.withColumn("_rn", F.row_number().over(window_latest)) \
                                   .filter(F.col("_rn") == 1).drop("_rn")

        return df_preimage, df_postimage

    def _phase1_process_source_tables(self) -> Tuple[List[DataFrame], List[str], Dict[str, List[str]]]:
        """Phase 1: Process source tables and collect updates."""
        self.logger.info("=" * 80)
        self.logger.info(f"PHASE 1: Process Source Table Updates (Collection Phase)")
        self.logger.info(f"Tables to process: {len(self._tables_with_updates)}")
        self.logger.info("=" * 80)

        all_transformed_updates = []
        all_updated_surrogate_keys = []
        changed_attributes_by_surrogate = {}

        for source_table in self._tables_with_updates:
            result = self._process_source_table_updates(source_table, changed_attributes_by_surrogate)
            if result is not None:
                df_transformed, surrogate_keys = result
                all_transformed_updates.append(df_transformed)
                all_updated_surrogate_keys.extend(surrogate_keys)

        self.logger.info(f"\nTotal changed attributes tracked: {len(changed_attributes_by_surrogate)} records")
        return all_transformed_updates, all_updated_surrogate_keys, changed_attributes_by_surrogate

    def _process_source_table_updates(self, source_table: str, changed_attributes_by_surrogate: Dict):
        """Process a single source table for UPDATE incrementals."""
        self.logger.info(f"\nProcessing: {source_table}")

        version_info = self._table_version_info.get(source_table)
        if not version_info or not version_info.get("has_updates", False):
            self.logger.info(f"  No updates for {source_table}, skipping...")
            return None

        starting_version = version_info.get("starting_version", version_info.get("last_processed_version", 0) + 1)
        current_version = version_info.get("current_version", 0)

        # Get attribute mapping
        mapping_dict = self._get_mapping_for_table(source_table)
        if not mapping_dict:
            self.logger.info(f"  No mapping found, skipping...")
            return None

        # Find source PK column
        source_pk_column = None
        for src_col, entity_col in mapping_dict.items():
            if entity_col == self._primary_key:
                source_pk_column = src_col
                break

        if not source_pk_column:
            self.logger.info(f"  Primary key not found in mapping, skipping...")
            return None

        try:
            # Read CDF with deduplication
            df_preimage, df_postimage = self._read_and_deduplicate_cdf_for_updates(
                source_table, starting_version, current_version, source_pk_column
            )

            if df_postimage.count() == 0:
                self.logger.info(f"  No updates found after deduplication")
                return None

            # Clean CDF metadata
            df_preimage_clean = df_preimage.drop("_change_type", "_commit_version", "_commit_timestamp", "operation_type", "_source_pk_value")
            df_postimage_clean = df_postimage.drop("_change_type", "_commit_version", "_commit_timestamp", "operation_type", "_source_pk_value")

            # Store source PK before transformation
            df_postimage_clean = df_postimage_clean.withColumn("_source_pk_value", col(source_pk_column).cast("string"))
            df_preimage_clean = df_preimage_clean.withColumn("_source_pk_value", col(source_pk_column).cast("string"))

            # Transform to entity schema
            df_post_transformed = df_postimage_clean.selectExpr(
                *[f"`{source_col}` as `{entity_col}`" for source_col, entity_col in mapping_dict.items()],
                "_source_pk_value"
            )
            df_pre_transformed = df_preimage_clean.selectExpr(
                *[f"`{source_col}` as `{entity_col}`" for source_col, entity_col in mapping_dict.items()],
                "_source_pk_value"
            )

            # Add missing entity attributes
            for col_name in self._entity_attributes:
                if col_name not in df_post_transformed.columns:
                    sql_dtype = self._entity_attributes_datatype.get(col_name, "string")
                    spark_dtype = self._get_spark_data_type(sql_dtype)
                    df_post_transformed = df_post_transformed.withColumn(col_name, lit(None).cast(spark_dtype))
                    df_pre_transformed = df_pre_transformed.withColumn(col_name, lit(None).cast(spark_dtype))

            # Generate surrogate_key for both
            df_post_transformed = df_post_transformed.withColumn(
                "surrogate_key",
                self._generate_surrogate_key_udf(lit(source_table), col("_source_pk_value"))
            )
            df_pre_transformed = df_pre_transformed.withColumn(
                "surrogate_key",
                self._generate_surrogate_key_udf(lit(source_table), col("_source_pk_value"))
            )

            # Compare PRE vs POST to identify changed attributes
            self._compare_pre_post(df_pre_transformed, df_post_transformed, changed_attributes_by_surrogate)

            # Continue with POSTIMAGE for unified table update
            df_transformed = df_post_transformed
            df_transformed = df_transformed.withColumn("source_path", lit(source_table))
            df_transformed = df_transformed.withColumn("source_id", col("_source_pk_value"))
            df_transformed = df_transformed.drop("_source_pk_value")

            # Generate attributes_combined
            available_attrs = [attr for attr in self._match_attributes if attr in df_transformed.columns]
            if available_attrs:
                df_transformed = df_transformed.withColumn(
                    "attributes_combined",
                    concat_ws(" | ", *[coalesce(regexp_replace(trim(col(c)), r'\s+', ' '), lit("")) for c in available_attrs])
                )
            else:
                df_transformed = df_transformed.withColumn("attributes_combined", lit(""))

            # Add metadata columns
            df_transformed = df_transformed.withColumn("search_results", lit(""))
            df_transformed = df_transformed.withColumn("scoring_results", lit(""))
            df_transformed = df_transformed.withColumn("master_lakefusion_id", lit(""))
            df_transformed = df_transformed.withColumn("record_status", lit(self._RecordStatus.ACTIVE.value))

            # Track surrogate keys
            surrogate_keys = [row.surrogate_key for row in df_transformed.select("surrogate_key").collect()]

            self.logger.info(f"  Completed {source_table}")
            return df_transformed, surrogate_keys

        except Exception as e:
            self.logger.info(f"  Error processing {source_table}: {e}")
            import traceback
            self.logger.info(traceback.format_exc())
            return None

    def _compare_pre_post(self, df_pre: DataFrame, df_post: DataFrame,
                          changed_attributes_by_surrogate: Dict) -> None:
        """Compare PRE vs POST to identify changed attributes."""
        self.logger.info(f"  Comparing pre/post to identify changed attributes...")

        # Join pre and post on surrogate_key with aliases
        df_pre_aliased = df_pre.select(
            col("surrogate_key"),
            *[col(c).alias(f"pre_{c}") for c in self._entity_attributes if c in df_pre.columns]
        )

        df_post_aliased = df_post.select(
            col("surrogate_key"),
            *[col(c).alias(f"post_{c}") for c in self._entity_attributes if c in df_post.columns]
        )

        df_comparison = df_pre_aliased.join(df_post_aliased, on="surrogate_key", how="inner")

        # For each record, identify which attributes changed
        comparison_records = df_comparison.collect()

        for row in comparison_records:
            surrogate_key = row.surrogate_key
            changed_attrs = []

            for attr in self._entity_attributes:
                try:
                    pre_value = row[f"pre_{attr}"]
                    post_value = row[f"post_{attr}"]

                    if str(pre_value) != str(post_value):
                        changed_attrs.append(attr)
                except (KeyError, AttributeError):
                    continue

            if changed_attrs:
                changed_attributes_by_surrogate[surrogate_key] = changed_attrs

        self.logger.info(f"  Identified changed attributes for {len(changed_attributes_by_surrogate)} records")

    def _phase15_update_unified(self, df_all_updates_deduped: DataFrame) -> int:
        """Phase 1.5: Update unified table with new values."""
        from delta.tables import DeltaTable

        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 1.5: Update Unified Table with New Values")
        self.logger.info("=" * 80)

        # Check which records exist in unified
        df_unified_existing = self.spark.read.table(self._unified_table).select(
            "surrogate_key", "record_status", "master_lakefusion_id"
        )

        # LEFT JOIN to identify existing vs new records
        df_with_check = df_all_updates_deduped.alias("upd").join(
            df_unified_existing.alias("ext"),
            on="surrogate_key",
            how="left"
        )

        # Records that EXIST -> UPDATE (preserve their record_status AND master_lakefusion_id)
        df_existing_updates = df_with_check.filter(col("ext.record_status").isNotNull()).select(
            *[col(f"upd.{c}") for c in df_all_updates_deduped.columns if c not in ["record_status", "master_lakefusion_id"]],
            col("ext.record_status").alias("record_status"),
            col("ext.master_lakefusion_id").alias("master_lakefusion_id")
        )

        # Records that DON'T EXIST -> INSERT as ACTIVE
        df_new_records = df_with_check.filter(col("ext.record_status").isNull()).select(
            *[col(f"upd.{c}") for c in df_all_updates_deduped.columns]
        ).withColumn("record_status", lit(self._RecordStatus.ACTIVE.value))

        existing_count = df_existing_updates.count()
        new_count = df_new_records.count()

        self.logger.info(f"  Existing records to UPDATE: {existing_count}")
        self.logger.info(f"  New records to INSERT as ACTIVE: {new_count}")

        # UPDATE existing records
        if existing_count > 0:
            delta_unified = DeltaTable.forName(self.spark, self._unified_table)

            update_expressions = {}
            for col_name in df_existing_updates.columns:
                if col_name != "surrogate_key":
                    update_expressions[col_name] = f"source.{col_name}"

            delta_unified.alias("target").merge(
                df_existing_updates.alias("source"),
                "target.surrogate_key = source.surrogate_key"
            ).whenMatchedUpdate(set=update_expressions).execute()

            self.logger.info(f"  Updated {existing_count} existing records")

        # INSERT new records using MERGE
        if new_count > 0:
            delta_unified = DeltaTable.forName(self.spark, self._unified_table)

            delta_unified.alias("target").merge(
                df_new_records.alias("source"),
                "target.surrogate_key = source.surrogate_key"
            ).whenNotMatchedInsertAll().execute()

            self.logger.info(f"  Inserted {new_count} new records as ACTIVE (upsert via MERGE)")

        return existing_count + new_count

    def _phase2_identify_affected_masters(self, df_all_updates_deduped: DataFrame,
                                           changed_attributes_by_surrogate: Dict):
        """Phase 2: Identify affected master records via merge_activities."""
        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 2: Identify Affected Master Records")
        self.logger.info("=" * 80)

        # Get merged surrogate keys
        df_unified_existing = self.spark.read.table(self._unified_table).select("surrogate_key", "record_status")

        df_updates_with_status = df_all_updates_deduped.alias("upd").join(
            df_unified_existing.alias("ext"),
            on="surrogate_key",
            how="inner"
        ).select(
            col("upd.surrogate_key"),
            col("ext.record_status")
        )

        merged_surrogate_keys = [row.surrogate_key for row in df_updates_with_status.filter(
            col("record_status") == self._RecordStatus.MERGED.value
        ).collect()]

        merged_update_count = len(merged_surrogate_keys)
        self.logger.info(f"Records with MERGED status in unified: {merged_update_count} surrogate keys")

        if merged_update_count == 0:
            self.logger.info("No MERGED records to process in master - only ACTIVE records were updated")
            return [], {}, {}

        # Lookup lakefusion_ids from unified table
        surrogate_keys_str = "','".join(merged_surrogate_keys)

        df_lakefusion_mapping = self.spark.sql(f"""
            SELECT surrogate_key, master_lakefusion_id as lakefusion_id
            FROM {self._unified_table}
            WHERE surrogate_key IN ('{surrogate_keys_str}')
            AND master_lakefusion_id IS NOT NULL
            AND master_lakefusion_id != ''
        """)

        surrogate_to_lakefusion = {row.surrogate_key: row.lakefusion_id for row in df_lakefusion_mapping.collect()}
        updated_lakefusion_ids = list(set(surrogate_to_lakefusion.values()))

        self.logger.info(f"Unique MERGED lakefusion_ids to process: {len(updated_lakefusion_ids)}")

        # Map changed attributes to lakefusion_ids
        changed_attributes_by_lakefusion = {}
        updated_lakefusion_ids_set = set(updated_lakefusion_ids)

        for surrogate_key, changed_attrs in changed_attributes_by_surrogate.items():
            lakefusion_id = surrogate_to_lakefusion.get(surrogate_key)
            if lakefusion_id and lakefusion_id in updated_lakefusion_ids_set:
                if lakefusion_id not in changed_attributes_by_lakefusion:
                    changed_attributes_by_lakefusion[lakefusion_id] = set()
                changed_attributes_by_lakefusion[lakefusion_id].update(changed_attrs)

        changed_attributes_by_lakefusion = {k: list(v) for k, v in changed_attributes_by_lakefusion.items()}

        return updated_lakefusion_ids, surrogate_to_lakefusion, changed_attributes_by_lakefusion

    def _categorize_by_scenario(self, updated_lakefusion_ids: List[str]) -> Tuple[List[str], List[str]]:
        """Categorize updated records by scenario using contributor count."""
        self.logger.info("\nCategorizing by scenario using contributor count from unified table...")

        if not updated_lakefusion_ids:
            return [], []

        ids_str = "','".join(updated_lakefusion_ids)

        categorization_query = f"""
        SELECT
            master_lakefusion_id as lakefusion_id,
            COUNT(*) as contributor_count,
            CASE
                WHEN COUNT(*) = 1 THEN 'STANDALONE'
                WHEN COUNT(*) > 1 THEN 'MULTI_CONTRIBUTOR'
                ELSE 'UNKNOWN'
            END as scenario
        FROM {self._unified_table}
        WHERE master_lakefusion_id IN ('{ids_str}')
        AND record_status = '{self._RecordStatus.MERGED.value}'
        GROUP BY master_lakefusion_id
        """

        df_categorized = self.spark.sql(categorization_query)

        standalone_ids = [row.lakefusion_id for row in df_categorized.filter(col("scenario") == "STANDALONE").collect()]
        multi_contributor_ids = [row.lakefusion_id for row in df_categorized.filter(col("scenario") == "MULTI_CONTRIBUTOR").collect()]

        self.logger.info(f"  STANDALONE: {len(standalone_ids)}")
        self.logger.info(f"  MULTI_CONTRIBUTOR: {len(multi_contributor_ids)}")

        return standalone_ids, multi_contributor_ids

    def _phase3_batch_execution(self, standalone_ids: List[str], multi_contributor_ids: List[str],
                                 surrogate_to_lakefusion: Dict, changed_attributes_by_lakefusion: Dict):
        """Phase 3: Batch execute master updates, merge activities, attribute versions."""
        from delta.tables import DeltaTable

        self.logger.info("\n" + "=" * 80)
        self.logger.info("PHASE 3: Batch Execution")
        self.logger.info("=" * 80)

        all_master_updates = []
        all_merge_activities = []
        all_attribute_versions = []
        records_processed_with_survivorship = []

        # Process STANDALONE updates
        for lakefusion_id in standalone_ids:
            result = self._process_standalone_update(
                lakefusion_id, surrogate_to_lakefusion, changed_attributes_by_lakefusion
            )
            if result:
                update_record, attr_mapping, merge_activity = result
                all_master_updates.append(update_record)
                all_attribute_versions.append({
                    'lakefusion_id': lakefusion_id,
                    'version': None,
                    'attribute_source_mapping': attr_mapping
                })
                all_merge_activities.append(merge_activity)

        # Process MULTI_CONTRIBUTOR updates with survivorship
        if multi_contributor_ids and self._survivorship_engine:
            for lakefusion_id in multi_contributor_ids:
                result = self._process_multi_contributor_update(
                    lakefusion_id, surrogate_to_lakefusion, changed_attributes_by_lakefusion
                )
                if result:
                    update_record, attr_mapping, merge_activities = result
                    all_master_updates.append(update_record)
                    all_attribute_versions.append({
                        'lakefusion_id': lakefusion_id,
                        'version': None,
                        'attribute_source_mapping': attr_mapping
                    })
                    all_merge_activities.extend(merge_activities)
                    records_processed_with_survivorship.append(lakefusion_id)

        # Execute batch operations
        master_version = None

        # Step 1: Update master table
        if all_master_updates:
            master_version = self._batch_update_master(all_master_updates)
            for activity in all_merge_activities:
                activity['version'] = master_version
            for attr_version in all_attribute_versions:
                attr_version['version'] = master_version

        # Step 2: Clear search results for updated masters
        if all_master_updates:
            self._clear_search_results_for_updated_masters(all_master_updates)

        # Step 3: Insert merge activities
        if all_merge_activities:
            self._batch_insert_merge_activities(all_merge_activities)

        # Step 4: Insert attribute versions
        if all_attribute_versions:
            self._batch_insert_attribute_versions(all_attribute_versions)

        return (len(all_master_updates), len(all_merge_activities),
                len(all_attribute_versions), len(records_processed_with_survivorship))

    def _process_standalone_update(self, lakefusion_id: str, surrogate_to_lakefusion: Dict,
                                    changed_attributes_by_lakefusion: Dict):
        """Process a STANDALONE update (single contributor)."""
        try:
            # Find surrogate key for this standalone master
            standalone_surrogate_keys = [sk for sk, lfid in surrogate_to_lakefusion.items() if lfid == lakefusion_id]
            if not standalone_surrogate_keys:
                return None

            unified_record = self.spark.sql(f"""
                SELECT * FROM {self._unified_table}
                WHERE surrogate_key = '{standalone_surrogate_keys[0]}'
                LIMIT 1
            """).first()

            if not unified_record:
                return None

            # Get current attribute sources
            attr_sources = self.spark.sql(f"""
                SELECT explode(attribute_source_mapping) as attr_map
                FROM {self._attribute_version_sources_table}
                WHERE lakefusion_id = '{lakefusion_id}'
            """).collect()

            current_sources = {row.attr_map.attribute_name: row.attr_map.source for row in attr_sources}
            changed_attrs = changed_attributes_by_lakefusion.get(lakefusion_id, [])
            unified_source_path = unified_record.source_path

            # Build update record
            update_record = {'lakefusion_id': lakefusion_id}
            updated_attr_mapping = []
            has_changes = False

            for attr in self._entity_attributes:
                if attr == 'lakefusion_id':
                    continue

                attr_value = getattr(unified_record, attr, None)
                attr_value_str = str(attr_value) if attr_value is not None else None
                update_record[attr] = attr_value_str

                updated_attr_mapping.append({
                    'attribute_name': attr,
                    'attribute_value': attr_value_str,
                    'source': unified_source_path
                })

                if attr in changed_attrs and current_sources.get(attr) == unified_source_path:
                    has_changes = True

            # Add attributes_combined
            attributes_combined = getattr(unified_record, 'attributes_combined', None)
            if attributes_combined:
                update_record['attributes_combined'] = str(attributes_combined)
                updated_attr_mapping.append({
                    'attribute_name': 'attributes_combined',
                    'attribute_value': str(attributes_combined),
                    'source': unified_source_path
                })

            if has_changes:
                merge_activity = {
                    'master_id': lakefusion_id,
                    'match_id': standalone_surrogate_keys[0],
                    'source': unified_source_path,
                    'version': None,
                    'action_type': 'SOURCE_UPDATE'
                }
                return update_record, updated_attr_mapping, merge_activity

        except Exception as e:
            self.logger.info(f"Error processing standalone {lakefusion_id}: {e}")

        return None

    def _process_multi_contributor_update(self, lakefusion_id: str, surrogate_to_lakefusion: Dict,
                                           changed_attributes_by_lakefusion: Dict):
        """Process a MULTI_CONTRIBUTOR update with survivorship recalculation."""
        try:
            changed_attrs = changed_attributes_by_lakefusion.get(lakefusion_id, [])
            if not changed_attrs:
                return None

            # Fetch all contributor records
            df_contributors = self.spark.sql(f"""
                SELECT * FROM {self._unified_table}
                WHERE master_lakefusion_id = '{lakefusion_id}'
                AND record_status = '{self._RecordStatus.MERGED.value}'
                ORDER BY surrogate_key
            """)

            contributor_records = df_contributors.collect()
            if not contributor_records:
                return None

            # Convert to list of dicts for survivorship engine
            unified_records = []
            for row in contributor_records:
                record_dict = row.asDict()
                if 'surrogate_key' in record_dict and 'source_path' in record_dict:
                    unified_records.append(record_dict)

            if not unified_records:
                return None

            # Apply survivorship
            survivorship_result = self._survivorship_engine.apply_survivorship(
                unified_records=unified_records
            )

            resultant_record = survivorship_result.resultant_record
            attribute_source_mapping = survivorship_result.resultant_master_attribute_source_mapping

            # Build update record
            update_record = {'lakefusion_id': lakefusion_id}
            for attr in self._entity_attributes:
                if attr == 'lakefusion_id':
                    continue
                update_record[attr] = resultant_record.get(attr)

            if 'attributes_combined' in resultant_record:
                update_record['attributes_combined'] = resultant_record.get('attributes_combined')
            elif self._match_attributes:
                update_record['attributes_combined'] = self._generate_attributes_combined(
                    resultant_record, self._match_attributes
                )

            # Convert attribute_source_mapping
            updated_attr_mapping = []
            for attr_map in attribute_source_mapping:
                updated_attr_mapping.append({
                    'attribute_name': attr_map.attribute_name,
                    'attribute_value': attr_map.attribute_value,
                    'source': attr_map.source
                })

            # Get unique sources
            all_sources = []
            for m in updated_attr_mapping:
                source = m['source']
                if ',' in source:
                    all_sources.extend([s.strip() for s in source.split(',')])
                else:
                    all_sources.append(source)
            unique_sources = ','.join(sorted(set(all_sources)))

            # Get updated surrogate keys for merge activities
            updated_sks = [sk for sk, lfid in surrogate_to_lakefusion.items()
                          if lfid == lakefusion_id]

            merge_activities = [{
                'master_id': lakefusion_id,
                'match_id': sk,
                'source': unique_sources,
                'version': None,
                'action_type': self._ActionType.SOURCE_UPDATE.value
            } for sk in updated_sks]

            return update_record, updated_attr_mapping, merge_activities

        except Exception as e:
            self.logger.info(f"Error processing multi-contributor {lakefusion_id}: {e}")
            import traceback
            self.logger.info(traceback.format_exc())

        return None

    def _generate_attributes_combined(self, record_dict: Dict, attributes_list: List[str]) -> str:
        """Generate attributes_combined string from attribute values."""
        values = []
        for attr in attributes_list:
            value = record_dict.get(attr, '')
            if value is None:
                value = ''
            values.append(str(value))
        return ' | '.join(values)

    def _batch_update_master(self, all_master_updates: List[Dict]) -> int:
        """Batch update master table."""
        from delta.tables import DeltaTable

        self.logger.info(f"\nBatch updating {len(all_master_updates)} master records...")

        master_update_fields = [StructField('lakefusion_id', StringType(), False)]
        for attr in self._entity_attributes:
            if attr != 'lakefusion_id':
                master_update_fields.append(StructField(attr, StringType(), True))
        master_update_fields.append(StructField('attributes_combined', StringType(), True))

        master_update_schema = StructType(master_update_fields)
        master_updates_df = self.spark.createDataFrame(all_master_updates, schema=master_update_schema)

        master_delta_table = DeltaTable.forName(self.spark, self._master_table)

        update_columns = [attr for attr in self._entity_attributes if attr != 'lakefusion_id']
        update_columns.append('attributes_combined')

        master_delta_table.alias("target").merge(
            source=master_updates_df.alias("source"),
            condition="target.lakefusion_id = source.lakefusion_id"
        ).whenMatchedUpdate(set={
            attr: f"source.{attr}" for attr in update_columns
        }).execute()

        # Get new master version
        master_version = self.spark.sql(f"""
            SELECT MAX(version) as version
            FROM (DESCRIBE HISTORY {self._master_table})
        """).first()['version']

        self.logger.info(f"  Master table version: {master_version}")
        return master_version

    def _clear_search_results_for_updated_masters(self, all_master_updates: List[Dict]) -> None:
        """Clear search_results for records referencing updated masters."""
        updated_master_ids = [record['lakefusion_id'] for record in all_master_updates]

        if self.spark.catalog.tableExists(self._unified_table):
            for lakefusion_id in updated_master_ids:
                try:
                    records_with_refs = self.spark.sql(f"""
                        SELECT surrogate_key FROM {self._unified_table}
                        WHERE search_results LIKE '%{lakefusion_id}%'
                        AND record_status = 'ACTIVE'
                    """).collect()

                    if records_with_refs:
                        sks_str = "','".join([row.surrogate_key for row in records_with_refs])
                        self.spark.sql(f"""
                            UPDATE {self._unified_table}
                            SET search_results = '', scoring_results = ''
                            WHERE surrogate_key IN ('{sks_str}')
                        """)
                except Exception:
                    continue

    def _batch_insert_merge_activities(self, all_merge_activities: List[Dict]) -> None:
        """Batch insert merge activities."""
        from delta.tables import DeltaTable

        self.logger.info(f"\nBatch inserting {len(all_merge_activities)} merge activities...")

        merge_activities_schema = StructType([
            StructField('master_id', StringType(), False),
            StructField('match_id', StringType(), True),
            StructField('source', StringType(), False),
            StructField('version', IntegerType(), False),
            StructField('action_type', StringType(), False),
            StructField('created_at', TimestampType(), False)
        ])

        now = datetime.now()
        activities_with_ts = [{**record, 'created_at': now} for record in all_merge_activities]

        merge_activities_df = self.spark.createDataFrame(activities_with_ts, schema=merge_activities_schema)

        merge_activities_delta = DeltaTable.forName(self.spark, self._merge_activities_table)

        merge_activities_delta.alias("target").merge(
            source=merge_activities_df.alias("source"),
            condition="""target.master_id = source.master_id
                         AND target.match_id = source.match_id
                         AND target.source = source.source
                         AND target.version = source.version
                         AND target.action_type = source.action_type"""
        ).whenNotMatchedInsertAll().execute()

        self.logger.info(f"  Inserted {len(all_merge_activities)} merge activities")

    def _batch_insert_attribute_versions(self, all_attribute_versions: List[Dict]) -> None:
        """Batch insert attribute version sources."""
        from delta.tables import DeltaTable

        self.logger.info(f"\nBatch inserting {len(all_attribute_versions)} attribute versions...")

        attr_mapping_struct = StructType([
            StructField("attribute_name", StringType(), True),
            StructField("attribute_value", StringType(), True),
            StructField("source", StringType(), True)
        ])

        attr_version_schema = StructType([
            StructField('lakefusion_id', StringType(), False),
            StructField('version', IntegerType(), False),
            StructField('attribute_source_mapping', ArrayType(attr_mapping_struct), True)
        ])

        attr_version_df = self.spark.createDataFrame(all_attribute_versions, schema=attr_version_schema)

        attr_version_delta = DeltaTable.forName(self.spark, self._attribute_version_sources_table)

        attr_version_delta.alias("target").merge(
            source=attr_version_df.alias("source"),
            condition="target.lakefusion_id = source.lakefusion_id AND target.version = source.version"
        ).whenNotMatchedInsertAll().execute()

        self.logger.info(f"  Inserted {len(all_attribute_versions)} attribute versions")
