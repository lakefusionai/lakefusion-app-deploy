"""
Validate Incremental Load Executor for integration core.

Validates CDF (Change Data Feed) data quality before processing incremental
changes. Performs 8 validation checks to ensure data integrity before
proceeding with insert/update/delete processing.

Workflow:
1. Validate CDF data readability for all tables with changes
2. Detect schema drift in source tables
3. Validate primary key has no NULL values in INSERT batch
4. Validate primary key uniqueness within INSERT batch
5. Validate primary key conflicts with existing unified records
6. Detect record count anomalies
7. Validate CDF version continuity
8. Detect update/delete orphans (PKs not in unified)
"""

import json
from datetime import datetime
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit, udf, count, when, desc, row_number
from pyspark.sql.types import StringType
from pyspark.sql.window import Window

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ValidateIncrementalLoadExecutor(BaseStepTask):
    """
    Executor for validating CDF data quality before incremental load processing.

    Performs comprehensive validation checks on CDF data to ensure data
    integrity before inserts, updates, and deletes are applied to
    unified and master tables.
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        super().__init__(context, override_instance=override_instance)
        self.validation_results = {
            "entity": "",
            "timestamp": "",
            "critical_issues": [],
            "warnings": [],
            "checks_passed": [],
            "validation_passed": True
        }
        # Tracking lists for validation results
        self.unreadable_tables = []
        self.schema_drift_issues = []
        self.pk_column_missing_tables = []
        self.tables_with_pk_nulls = []
        self.tables_with_pk_duplicates = []
        self.tables_with_unified_conflicts = []
        self.record_count_anomalies = []
        self.version_gaps = []
        self.orphan_updates = []
        self.orphan_deletes = []
        # get logger from context params (base class already sets a safe fallback)
        self.logger = context.params.get("logger") or self.logger

        # Cached CDF DataFrames keyed by table path
        self._cdf_cache: Dict[str, DataFrame] = {}

        # UDF references
        self._generate_surrogate_key_udf = None

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("=" * 60)
        self.logger.info("INCREMENTAL LOAD VALIDATION")
        self.logger.info("=" * 60)
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")

        params = self.context.params

        # From Parse_Entity_Model_JSON
        self._dataset_tables = params.get('dataset_tables', [])
        self._attributes_mapping = params.get('attributes_mapping', [])
        self._primary_key = params.get('primary_key', '')
        self._primary_table = params.get('primary_table', '')

        # From Check_Increments_Exists
        self._has_inserts = params.get('has_inserts', False)
        self._has_updates = params.get('has_updates', False)
        self._has_deletes = params.get('has_deletes', False)
        self._tables_with_inserts = params.get('tables_with_inserts', [])
        self._tables_with_updates = params.get('tables_with_updates', [])
        self._tables_with_deletes = params.get('tables_with_deletes', [])
        self._table_version_info = params.get('table_version_info', {})

        # Parse JSON strings if needed
        for attr in ['dataset_tables', 'attributes_mapping', 'tables_with_inserts',
                     'tables_with_updates', 'tables_with_deletes', 'table_version_info']:
            val = getattr(self, f'_{attr}')
            if isinstance(val, str):
                setattr(self, f'_{attr}', json.loads(val))

        for attr in ['has_inserts', 'has_updates', 'has_deletes']:
            val = getattr(self, f'_{attr}')
            if isinstance(val, str):
                setattr(self, f'_{attr}', val.lower() == 'true')

        # Build table names
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"
        self._meta_info_table = f"{self.context.catalog_name}.silver.table_meta_info"

        # All tables that have any changes
        self._all_changed_tables = list(set(
            self._tables_with_inserts +
            self._tables_with_updates +
            self._tables_with_deletes
        ))

        # Initialize surrogate key UDF
        from lakefusion_core_engine.identifiers import generate_surrogate_key
        self._generate_surrogate_key_udf = udf(
            lambda source_path, source_id: generate_surrogate_key(source_path, str(source_id)),
            StringType()
        )

        self.logger.info(f"Primary Key: {self._primary_key}")
        self.logger.info(f"Tables with inserts: {len(self._tables_with_inserts)}")
        self.logger.info(f"Tables with updates: {len(self._tables_with_updates)}")
        self.logger.info(f"Tables with deletes: {len(self._tables_with_deletes)}")
        self.logger.info(f"Total tables with changes: {len(self._all_changed_tables)}")
        self.logger.info("=" * 60)

        self.validation_results["entity"] = self.context.entity
        self.validation_results["timestamp"] = datetime.now().isoformat()

    # =========================================================================
    # Helper methods
    # =========================================================================

    def _get_mapping_for_table(self, source_table: str) -> Optional[Dict[str, str]]:
        """Get attribute mapping for a source table. Returns {entity_attr: dataset_attr}."""
        for mapping_entry in self._attributes_mapping:
            for table_path, mapping in mapping_entry.items():
                if source_table.startswith(table_path) or table_path == source_table:
                    return mapping
        return None

    def _get_source_pk_column(self, table_mapping: Dict[str, str]) -> Optional[str]:
        """Get the source column name mapped to the primary key."""
        return table_mapping.get(self._primary_key)

    def _get_cdf_dataframe(self, source_table: str) -> Optional[DataFrame]:
        """Get cached CDF DataFrame for a table, reading it if not cached."""
        if source_table in self._cdf_cache:
            return self._cdf_cache[source_table]

        version_info = self._table_version_info.get(source_table)
        if not version_info:
            return None

        start_version = version_info.get("starting_version", 0)
        end_version = version_info.get("current_version", 0)

        try:
            df_cdf = self.spark.read.format("delta") \
                .option("readChangeFeed", "true") \
                .option("startingVersion", start_version) \
                .option("endingVersion", end_version) \
                .table(source_table)
            self._cdf_cache[source_table] = df_cdf
            return df_cdf
        except Exception:
            return None

    def _get_insert_records(self, df_cdf: DataFrame, source_pk_column: str,
                            source_table: str) -> DataFrame:
        """Filter CDF for INSERT records with deduplication (latest operation per PK)."""
        # Classify operations
        df_classified = df_cdf.withColumn(
            "operation_type",
            when(col("_change_type") == "insert", lit("insert"))
            .when(col("_change_type") == "update_postimage", lit("update"))
            .when(col("_change_type") == "delete", lit("delete"))
            .otherwise(col("_change_type"))
        )

        # Generate surrogate key for dedup
        df_classified = df_classified.withColumn(
            "_source_id_str", col(source_pk_column).cast("string")
        ).withColumn(
            "surrogate_key",
            self._generate_surrogate_key_udf(lit(source_table), col("_source_id_str"))
        )

        # Keep latest operation per surrogate_key
        window_spec = Window.partitionBy("surrogate_key") \
            .orderBy(desc("_commit_version"), desc("_commit_timestamp"))

        df_latest = df_classified.withColumn(
            "_rn", row_number().over(window_spec)
        ).filter(col("_rn") == 1).drop("_rn")

        # Keep only INSERTs
        return df_latest.filter(col("operation_type") == "insert")

    def _get_update_delete_records(self, df_cdf: DataFrame, source_pk_column: str,
                                    source_table: str, change_type: str) -> DataFrame:
        """Filter CDF for UPDATE or DELETE records with deduplication."""
        target_type = "update" if change_type == "update" else "delete"
        cdf_type = "update_postimage" if change_type == "update" else "delete"

        df_classified = df_cdf.withColumn(
            "operation_type",
            when(col("_change_type") == "insert", lit("insert"))
            .when(col("_change_type") == "update_postimage", lit("update"))
            .when(col("_change_type") == "delete", lit("delete"))
            .otherwise(col("_change_type"))
        )

        # Generate surrogate key
        df_classified = df_classified.withColumn(
            "_source_id_str", col(source_pk_column).cast("string")
        ).withColumn(
            "surrogate_key",
            self._generate_surrogate_key_udf(lit(source_table), col("_source_id_str"))
        )

        # Keep latest operation per surrogate_key
        window_spec = Window.partitionBy("surrogate_key") \
            .orderBy(desc("_commit_version"), desc("_commit_timestamp"))

        df_latest = df_classified.withColumn(
            "_rn", row_number().over(window_spec)
        ).filter(col("_rn") == 1).drop("_rn")

        return df_latest.filter(col("operation_type") == target_type)

    # =========================================================================
    # Validation steps
    # =========================================================================

    @step(order=1, name="Validate CDF Data Readability", returns="dict - CDF readability status")
    def step_validate_cdf_readability(self) -> Dict[str, Any]:
        """Validation 1: Check if CDF can be read for all tables with changes."""
        for source_table in self._all_changed_tables:
            version_info = self._table_version_info.get(source_table)
            if not version_info:
                self.unreadable_tables.append({
                    "table": source_table,
                    "reason": "No version info available"
                })
                self.logger.info(f"  [FAIL] No version info: {source_table}")
                continue

            start_version = version_info.get("starting_version", 0)
            end_version = version_info.get("current_version", 0)

            try:
                df_cdf = self.spark.read.format("delta") \
                    .option("readChangeFeed", "true") \
                    .option("startingVersion", start_version) \
                    .option("endingVersion", end_version) \
                    .table(source_table)

                record_count = df_cdf.count()
                self._cdf_cache[source_table] = df_cdf
                self.logger.info(f"  [OK] CDF readable: {source_table} (versions {start_version}-{end_version}, {record_count} records)")
            except Exception as e:
                self.unreadable_tables.append({
                    "table": source_table,
                    "reason": str(e),
                    "version_range": f"{start_version}-{end_version}"
                })
                self.logger.info(f"  [FAIL] CDF unreadable: {source_table} - {str(e)}")

        if self.unreadable_tables:
            self.validation_results["critical_issues"].append({
                "check": "CDF Data Readability",
                "issue": "Cannot read CDF for some tables",
                "details": self.unreadable_tables
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] {len(self.unreadable_tables)} table(s) have unreadable CDF")
        else:
            self.validation_results["checks_passed"].append("CDF Data Readability")
            self.logger.info(f"\n[PASSED] CDF readable for all {len(self._all_changed_tables)} table(s)")

        return {
            "unreadable_tables": self.unreadable_tables,
            "tables_checked": len(self._all_changed_tables),
            "passed": len(self.unreadable_tables) == 0
        }

    @step(order=2, name="Validate Schema Drift Detection", returns="dict - schema drift status")
    def step_validate_schema_drift(self) -> Dict[str, Any]:
        """Validation 2: Check if mapped columns still exist in source CDF data."""
        has_pk_drift = False

        for source_table in self._all_changed_tables:
            # Skip if CDF unreadable
            if any(t["table"] == source_table for t in self.unreadable_tables):
                continue

            table_mapping = self._get_mapping_for_table(source_table)
            if not table_mapping:
                continue

            df_cdf = self._get_cdf_dataframe(source_table)
            if df_cdf is None:
                continue

            # CDF columns include _change_type, _commit_version, _commit_timestamp
            cdf_columns = [c for c in df_cdf.columns if not c.startswith("_")]

            source_pk_column = self._get_source_pk_column(table_mapping)

            for entity_attr, dataset_attr in table_mapping.items():
                if dataset_attr not in cdf_columns:
                    is_pk = (dataset_attr == source_pk_column)
                    self.schema_drift_issues.append({
                        "table": source_table,
                        "entity_attr": entity_attr,
                        "dataset_attr": dataset_attr,
                        "is_primary_key": is_pk
                    })
                    if is_pk:
                        has_pk_drift = True
                        self.pk_column_missing_tables.append(source_table)
                        self.logger.info(f"  [FAIL] PK column missing: {source_table}.{dataset_attr}")
                    else:
                        self.logger.info(f"  [WARN] Column missing: {source_table}.{dataset_attr} -> {entity_attr}")

            if not any(d["table"] == source_table for d in self.schema_drift_issues):
                self.logger.info(f"  [OK] No schema drift: {source_table}")

        if has_pk_drift:
            self.validation_results["critical_issues"].append({
                "check": "Schema Drift Detection",
                "issue": "Primary key column missing from source tables",
                "details": [d for d in self.schema_drift_issues if d["is_primary_key"]]
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] Primary key column missing in {len(self.pk_column_missing_tables)} table(s)")

        non_pk_drift = [d for d in self.schema_drift_issues if not d["is_primary_key"]]
        if non_pk_drift:
            self.validation_results["warnings"].append({
                "check": "Schema Drift Detection",
                "issue": "Non-PK mapped columns missing from source tables",
                "details": non_pk_drift
            })
            self.logger.info(f"\n[WARNING] {len(non_pk_drift)} non-PK mapped column(s) missing (will be NULL)")

        if not self.schema_drift_issues:
            self.validation_results["checks_passed"].append("Schema Drift Detection")
            self.logger.info(f"\n[PASSED] No schema drift detected")

        return {
            "schema_drift_issues": self.schema_drift_issues,
            "pk_column_missing_tables": self.pk_column_missing_tables,
            "passed": len(self.schema_drift_issues) == 0
        }

    @step(order=3, name="Validate PK Nulls in Incremental Batch", returns="dict - PK null status")
    def step_validate_pk_nulls(self) -> Dict[str, Any]:
        """Validation 3: Check for NULL values in primary key columns of INSERT records."""
        for source_table in self._tables_with_inserts:
            # Skip if CDF unreadable or PK column missing
            if any(t["table"] == source_table for t in self.unreadable_tables):
                continue
            if source_table in self.pk_column_missing_tables:
                continue

            table_mapping = self._get_mapping_for_table(source_table)
            if not table_mapping:
                continue

            source_pk_column = self._get_source_pk_column(table_mapping)
            if not source_pk_column:
                continue

            df_cdf = self._get_cdf_dataframe(source_table)
            if df_cdf is None:
                continue

            try:
                # Filter to INSERT records only
                df_inserts = df_cdf.filter(col("_change_type") == "insert")
                total_count = df_inserts.count()

                if total_count == 0:
                    self.logger.info(f"  [OK] No inserts: {source_table}")
                    continue

                null_count = df_inserts.filter(col(source_pk_column).isNull()).count()

                if null_count > 0:
                    null_pct = round((null_count / total_count) * 100, 2)
                    self.tables_with_pk_nulls.append({
                        "table": source_table,
                        "column": source_pk_column,
                        "total_insert_records": total_count,
                        "null_count": null_count,
                        "null_percentage": null_pct
                    })
                    self.logger.info(f"  [FAIL] NULLs found: {source_table}.{source_pk_column}")
                    self.logger.info(f"    Total inserts: {total_count}, NULL count: {null_count} ({null_pct}%)")
                else:
                    self.logger.info(f"  [OK] No NULLs: {source_table}.{source_pk_column} ({total_count} insert records)")
            except Exception as e:
                self.logger.info(f"  [WARN] Could not check NULLs: {source_table}.{source_pk_column} - {str(e)}")

        if self.tables_with_pk_nulls:
            self.validation_results["critical_issues"].append({
                "check": "PK Nulls in Incremental Batch",
                "issue": "NULL values found in primary key columns of INSERT records",
                "details": self.tables_with_pk_nulls
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] {len(self.tables_with_pk_nulls)} table(s) have NULL primary keys in INSERT batch")
        else:
            self.validation_results["checks_passed"].append("PK Nulls in Incremental Batch")
            self.logger.info(f"\n[PASSED] No NULL primary keys in INSERT records")

        return {
            "tables_with_pk_nulls": self.tables_with_pk_nulls,
            "passed": len(self.tables_with_pk_nulls) == 0
        }

    @step(order=4, name="Validate PK Uniqueness Within Batch", returns="dict - PK uniqueness status")
    def step_validate_pk_uniqueness_within_batch(self) -> Dict[str, Any]:
        """Validation 4: Check for duplicate PK values within each table's INSERT batch."""
        for source_table in self._tables_with_inserts:
            # Skip if CDF unreadable or PK column missing
            if any(t["table"] == source_table for t in self.unreadable_tables):
                continue
            if source_table in self.pk_column_missing_tables:
                continue

            table_mapping = self._get_mapping_for_table(source_table)
            if not table_mapping:
                continue

            source_pk_column = self._get_source_pk_column(table_mapping)
            if not source_pk_column:
                continue

            df_cdf = self._get_cdf_dataframe(source_table)
            if df_cdf is None:
                continue

            try:
                # Filter to INSERT records only
                df_inserts = df_cdf.filter(col("_change_type") == "insert")
                total_count = df_inserts.count()

                if total_count == 0:
                    self.logger.info(f"  [OK] No inserts: {source_table}")
                    continue

                distinct_count = df_inserts.select(source_pk_column).distinct().count()
                duplicate_count = total_count - distinct_count

                if duplicate_count > 0:
                    self.tables_with_pk_duplicates.append({
                        "table": source_table,
                        "column": source_pk_column,
                        "total_insert_records": total_count,
                        "distinct_values": distinct_count,
                        "duplicate_count": duplicate_count
                    })
                    self.logger.info(f"  [FAIL] Duplicates found: {source_table}.{source_pk_column}")
                    self.logger.info(f"    Total inserts: {total_count}, Distinct: {distinct_count}, Duplicates: {duplicate_count}")
                else:
                    self.logger.info(f"  [OK] All unique: {source_table}.{source_pk_column} ({total_count} insert records)")
            except Exception as e:
                self.logger.info(f"  [WARN] Could not check uniqueness: {source_table}.{source_pk_column} - {str(e)}")

        if self.tables_with_pk_duplicates:
            self.validation_results["critical_issues"].append({
                "check": "PK Uniqueness Within Batch",
                "issue": "Duplicate primary key values found within INSERT batch",
                "details": self.tables_with_pk_duplicates
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] {len(self.tables_with_pk_duplicates)} table(s) have duplicate PKs within INSERT batch")
        else:
            self.validation_results["checks_passed"].append("PK Uniqueness Within Batch")
            self.logger.info(f"\n[PASSED] All primary keys unique within INSERT batches")

        return {
            "tables_with_pk_duplicates": self.tables_with_pk_duplicates,
            "passed": len(self.tables_with_pk_duplicates) == 0
        }

    @step(order=5, name="Validate PK Conflicts with Unified", returns="dict - PK conflict status")
    def step_validate_pk_conflicts_with_unified(self) -> Dict[str, Any]:
        """Validation 5: Check if INSERT records conflict with existing unified records."""
        if not self.spark.catalog.tableExists(self._unified_table):
            self.logger.info(f"  [WARN] Unified table does not exist: {self._unified_table}")
            self.validation_results["checks_passed"].append("PK Conflicts with Unified")
            return {"tables_with_unified_conflicts": [], "passed": True}

        for source_table in self._tables_with_inserts:
            # Skip if CDF unreadable or PK column missing
            if any(t["table"] == source_table for t in self.unreadable_tables):
                continue
            if source_table in self.pk_column_missing_tables:
                continue

            table_mapping = self._get_mapping_for_table(source_table)
            if not table_mapping:
                continue

            source_pk_column = self._get_source_pk_column(table_mapping)
            if not source_pk_column:
                continue

            df_cdf = self._get_cdf_dataframe(source_table)
            if df_cdf is None:
                continue

            try:
                # Get INSERT records with surrogate keys
                df_inserts = self._get_insert_records(df_cdf, source_pk_column, source_table)
                insert_count = df_inserts.count()

                if insert_count == 0:
                    self.logger.info(f"  [OK] No inserts: {source_table}")
                    continue

                # Check for conflicts with existing unified records
                df_unified_keys = self.spark.table(self._unified_table).select("surrogate_key")

                df_conflicts = df_inserts.alias("ins").join(
                    df_unified_keys.alias("uni"),
                    col("ins.surrogate_key") == col("uni.surrogate_key"),
                    "left_semi"
                )

                conflict_count = df_conflicts.count()

                if conflict_count > 0:
                    self.tables_with_unified_conflicts.append({
                        "table": source_table,
                        "total_insert_records": insert_count,
                        "conflict_count": conflict_count,
                        "conflict_percentage": round((conflict_count / insert_count) * 100, 2)
                    })
                    self.logger.info(f"  [FAIL] Conflicts found: {source_table}")
                    self.logger.info(f"    Insert records: {insert_count}, Already in unified: {conflict_count} ({round((conflict_count / insert_count) * 100, 2)}%)")
                else:
                    self.logger.info(f"  [OK] No conflicts: {source_table} ({insert_count} insert records)")
            except Exception as e:
                self.logger.info(f"  [WARN] Could not check conflicts: {source_table} - {str(e)}")

        if self.tables_with_unified_conflicts:
            self.validation_results["critical_issues"].append({
                "check": "PK Conflicts with Unified",
                "issue": "INSERT records conflict with existing unified records",
                "details": self.tables_with_unified_conflicts
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] {len(self.tables_with_unified_conflicts)} table(s) have INSERT records conflicting with unified")
        else:
            self.validation_results["checks_passed"].append("PK Conflicts with Unified")
            self.logger.info(f"\n[PASSED] No INSERT records conflict with existing unified records")

        return {
            "tables_with_unified_conflicts": self.tables_with_unified_conflicts,
            "passed": len(self.tables_with_unified_conflicts) == 0
        }

    @step(order=6, name="Validate Record Count Anomalies", returns="dict - anomaly detection status")
    def step_validate_record_count_anomalies(self) -> Dict[str, Any]:
        """Validation 6: Detect unusually large INSERT batches that may indicate data issues."""
        ANOMALY_THRESHOLD_PCT = 50  # inserts > 50% of existing unified count for source

        if not self.spark.catalog.tableExists(self._unified_table):
            self.validation_results["checks_passed"].append("Record Count Anomalies")
            self.logger.info(f"  [OK] Unified table does not exist yet, skipping anomaly check")
            return {"record_count_anomalies": [], "passed": True}

        for source_table in self._tables_with_inserts:
            if any(t["table"] == source_table for t in self.unreadable_tables):
                continue

            version_info = self._table_version_info.get(source_table, {})
            insert_count = version_info.get("insert_count", 0)

            if insert_count == 0:
                continue

            try:
                # Count existing unified records from this source
                existing_count = self.spark.table(self._unified_table) \
                    .filter(col("source_path") == source_table) \
                    .count()

                if existing_count == 0:
                    self.logger.info(f"  [OK] First load for source: {source_table} ({insert_count} inserts)")
                    continue

                ratio = round((insert_count / existing_count) * 100, 2)

                if ratio > ANOMALY_THRESHOLD_PCT:
                    self.record_count_anomalies.append({
                        "table": source_table,
                        "insert_count": insert_count,
                        "existing_unified_count": existing_count,
                        "ratio_percentage": ratio
                    })
                    self.logger.info(f"  [WARN] Anomaly: {source_table}")
                    self.logger.info(f"    Inserts: {insert_count}, Existing: {existing_count}, Ratio: {ratio}%")
                else:
                    self.logger.info(f"  [OK] Normal: {source_table} ({insert_count} inserts vs {existing_count} existing, {ratio}%)")
            except Exception as e:
                self.logger.info(f"  [WARN] Could not check anomaly: {source_table} - {str(e)}")

        if self.record_count_anomalies:
            self.validation_results["warnings"].append({
                "check": "Record Count Anomalies",
                "issue": f"Insert batch sizes exceed {ANOMALY_THRESHOLD_PCT}% of existing records (possible full reload)",
                "details": self.record_count_anomalies
            })
            self.logger.info(f"\n[WARNING] {len(self.record_count_anomalies)} table(s) have unusually large INSERT batches")
        else:
            self.validation_results["checks_passed"].append("Record Count Anomalies")
            self.logger.info(f"\n[PASSED] No record count anomalies detected")

        return {
            "record_count_anomalies": self.record_count_anomalies,
            "passed": len(self.record_count_anomalies) == 0
        }

    @step(order=7, name="Validate CDF Version Continuity", returns="dict - version continuity status")
    def step_validate_version_continuity(self) -> Dict[str, Any]:
        """Validation 7: Check for gaps between last processed version and starting version."""
        for source_table in self._all_changed_tables:
            version_info = self._table_version_info.get(source_table, {})
            last_processed = version_info.get("last_processed_version")
            starting_version = version_info.get("starting_version", 0)

            if last_processed is None:
                self.logger.info(f"  [OK] First increment: {source_table} (starting at version {starting_version})")
                continue

            expected_start = last_processed + 1

            if starting_version != expected_start:
                gap_size = starting_version - expected_start
                self.version_gaps.append({
                    "table": source_table,
                    "last_processed_version": last_processed,
                    "expected_starting_version": expected_start,
                    "actual_starting_version": starting_version,
                    "gap_size": gap_size
                })
                self.logger.info(f"  [WARN] Version gap: {source_table}")
                self.logger.info(f"    Last processed: {last_processed}, Expected start: {expected_start}, Actual start: {starting_version}")
            else:
                self.logger.info(f"  [OK] Continuous: {source_table} (version {last_processed} -> {starting_version})")

        if self.version_gaps:
            self.validation_results["warnings"].append({
                "check": "CDF Version Continuity",
                "issue": "Version gaps detected between last processed and current versions",
                "details": self.version_gaps
            })
            self.logger.info(f"\n[WARNING] {len(self.version_gaps)} table(s) have version gaps")
        else:
            self.validation_results["checks_passed"].append("CDF Version Continuity")
            self.logger.info(f"\n[PASSED] CDF versions are continuous for all tables")

        return {
            "version_gaps": self.version_gaps,
            "passed": len(self.version_gaps) == 0
        }

    @step(order=8, name="Validate Update/Delete Orphan Detection", returns="dict - orphan detection status")
    def step_validate_orphan_detection(self) -> Dict[str, Any]:
        """Validation 8: Check if UPDATE/DELETE records reference PKs not in unified."""
        if not self.spark.catalog.tableExists(self._unified_table):
            self.validation_results["checks_passed"].append("Update/Delete Orphan Detection")
            self.logger.info(f"  [OK] Unified table does not exist, skipping orphan check")
            return {"orphan_updates": [], "orphan_deletes": [], "passed": True}

        df_unified_keys = self.spark.table(self._unified_table).select("surrogate_key")

        # Check UPDATE orphans
        for source_table in self._tables_with_updates:
            if any(t["table"] == source_table for t in self.unreadable_tables):
                continue
            if source_table in self.pk_column_missing_tables:
                continue

            table_mapping = self._get_mapping_for_table(source_table)
            if not table_mapping:
                continue

            source_pk_column = self._get_source_pk_column(table_mapping)
            if not source_pk_column:
                continue

            df_cdf = self._get_cdf_dataframe(source_table)
            if df_cdf is None:
                continue

            try:
                df_updates = self._get_update_delete_records(
                    df_cdf, source_pk_column, source_table, "update"
                )
                update_count = df_updates.count()

                if update_count == 0:
                    continue

                df_orphans = df_updates.alias("upd").join(
                    df_unified_keys.alias("uni"),
                    col("upd.surrogate_key") == col("uni.surrogate_key"),
                    "left_anti"
                )
                orphan_count = df_orphans.count()

                if orphan_count > 0:
                    self.orphan_updates.append({
                        "table": source_table,
                        "total_update_records": update_count,
                        "orphan_count": orphan_count
                    })
                    self.logger.info(f"  [WARN] Update orphans: {source_table} ({orphan_count}/{update_count} not in unified)")
                else:
                    self.logger.info(f"  [OK] No update orphans: {source_table} ({update_count} updates)")
            except Exception as e:
                self.logger.info(f"  [WARN] Could not check update orphans: {source_table} - {str(e)}")

        # Check DELETE orphans
        for source_table in self._tables_with_deletes:
            if any(t["table"] == source_table for t in self.unreadable_tables):
                continue
            if source_table in self.pk_column_missing_tables:
                continue

            table_mapping = self._get_mapping_for_table(source_table)
            if not table_mapping:
                continue

            source_pk_column = self._get_source_pk_column(table_mapping)
            if not source_pk_column:
                continue

            df_cdf = self._get_cdf_dataframe(source_table)
            if df_cdf is None:
                continue

            try:
                df_deletes = self._get_update_delete_records(
                    df_cdf, source_pk_column, source_table, "delete"
                )
                delete_count = df_deletes.count()

                if delete_count == 0:
                    continue

                df_orphans = df_deletes.alias("del").join(
                    df_unified_keys.alias("uni"),
                    col("del.surrogate_key") == col("uni.surrogate_key"),
                    "left_anti"
                )
                orphan_count = df_orphans.count()

                if orphan_count > 0:
                    self.orphan_deletes.append({
                        "table": source_table,
                        "total_delete_records": delete_count,
                        "orphan_count": orphan_count
                    })
                    self.logger.info(f"  [WARN] Delete orphans: {source_table} ({orphan_count}/{delete_count} not in unified)")
                else:
                    self.logger.info(f"  [OK] No delete orphans: {source_table} ({delete_count} deletes)")
            except Exception as e:
                self.logger.info(f"  [WARN] Could not check delete orphans: {source_table} - {str(e)}")

        has_orphans = len(self.orphan_updates) > 0 or len(self.orphan_deletes) > 0

        if has_orphans:
            orphan_details = []
            if self.orphan_updates:
                orphan_details.extend([{**o, "type": "UPDATE"} for o in self.orphan_updates])
            if self.orphan_deletes:
                orphan_details.extend([{**o, "type": "DELETE"} for o in self.orphan_deletes])

            self.validation_results["warnings"].append({
                "check": "Update/Delete Orphan Detection",
                "issue": "UPDATE/DELETE records reference PKs not found in unified table",
                "details": orphan_details
            })
            self.logger.info(f"\n[WARNING] Found orphan records: {len(self.orphan_updates)} update table(s), {len(self.orphan_deletes)} delete table(s)")
        else:
            self.validation_results["checks_passed"].append("Update/Delete Orphan Detection")
            self.logger.info(f"\n[PASSED] No orphan UPDATE/DELETE records detected")

        return {
            "orphan_updates": self.orphan_updates,
            "orphan_deletes": self.orphan_deletes,
            "passed": not has_orphans
        }

    # =========================================================================
    # Execution lifecycle
    # =========================================================================

    def execute(self) -> TaskResult:
        """Execute all validation checks."""
        # Run all validations
        self.step_validate_cdf_readability()
        self.step_validate_schema_drift()
        self.step_validate_pk_nulls()
        self.step_validate_pk_uniqueness_within_batch()
        self.step_validate_pk_conflicts_with_unified()
        self.step_validate_record_count_anomalies()
        self.step_validate_version_continuity()
        self.step_validate_orphan_detection()

        # Print validation summary
        self._print_validation_summary()

        # Build result
        if self.validation_results["validation_passed"]:
            return TaskResult.success(
                message="Incremental validation passed - pipeline can proceed",
                task_name=self.context.task_name,
                metrics={
                    'checks_passed': len(self.validation_results["checks_passed"]),
                    'warnings': len(self.validation_results["warnings"]),
                    'critical_issues': 0,
                    'validation_passed': True
                },
                task_values={
                    'validation_passed': True,
                    'validation_results': json.dumps(self.validation_results)
                }
            )
        else:
            # Print exit message with details
            self.logger.info("\n" + "=" * 60)
            self.logger.info("EXITING PIPELINE DUE TO CRITICAL ISSUES")
            self.logger.info("=" * 60)
            self.logger.info("\nPlease fix the following issues:")
            for issue in self.validation_results["critical_issues"]:
                self.logger.info(f"\n[FAIL] {issue['check']}")
                self.logger.info(f"   {issue['issue']}")
                if isinstance(issue['details'], list) and len(issue['details']) <= 5:
                    for detail in issue['details']:
                        self.logger.info(f"   - {detail}")

            # Build error summary and raise
            error_summary = {
                "status": "failed",
                "message": "Incremental validation failed - critical issues found",
                "critical_issues_count": len(self.validation_results["critical_issues"]),
                "issues": [issue["check"] for issue in self.validation_results["critical_issues"]]
            }
            raise ValueError(
                f"Incremental validation failed with {len(self.validation_results['critical_issues'])} critical issue(s): {json.dumps(error_summary, indent=2)}"
            )

    def _print_validation_summary(self) -> None:
        """Print validation summary."""
        self.logger.info("\n" + "=" * 60)
        self.logger.info("INCREMENTAL VALIDATION SUMMARY")
        self.logger.info("=" * 60)
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Timestamp: {self.validation_results['timestamp']}")
        self.logger.info(f"Tables with changes: {len(self._all_changed_tables)}")

        self.logger.info("\n" + "-" * 60)
        self.logger.info("CHECKS PASSED:")
        self.logger.info("-" * 60)
        for check in self.validation_results["checks_passed"]:
            self.logger.info(f"  [PASSED] {check}")

        if self.validation_results["warnings"]:
            self.logger.info("\n" + "-" * 60)
            self.logger.info("WARNINGS:")
            self.logger.info("-" * 60)
            for warning in self.validation_results["warnings"]:
                self.logger.info(f"  [WARN] {warning['check']}: {warning['issue']}")
                if isinstance(warning['details'], list):
                    self.logger.info(f"     Count: {len(warning['details'])}")

        if self.validation_results["critical_issues"]:
            self.logger.info("\n" + "-" * 60)
            self.logger.info("CRITICAL ISSUES:")
            self.logger.info("-" * 60)
            for issue in self.validation_results["critical_issues"]:
                self.logger.info(f"  [FAIL] {issue['check']}: {issue['issue']}")
                if isinstance(issue['details'], list):
                    self.logger.info(f"     Count: {len(issue['details'])}")
                    for item in issue['details'][:3]:
                        if isinstance(item, dict):
                            self.logger.info(f"     - {item}")
                        else:
                            self.logger.info(f"     - {item}")

        self.logger.info("\n" + "=" * 60)
        if self.validation_results["validation_passed"]:
            self.logger.info("[SUCCESS] INCREMENTAL VALIDATION PASSED - PIPELINE CAN PROCEED")
        else:
            self.logger.info("[FAILED] INCREMENTAL VALIDATION FAILED - PIPELINE CANNOT PROCEED")
        self.logger.info("=" * 60)

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Incremental load validation completed",
            actual={
                'checks_passed': self.validation_results["checks_passed"],
                'warnings': len(self.validation_results["warnings"])
            }
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self._print_validation_summary()

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            self.context.dbutils.jobs.taskValues.set('validation_passed', True)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info("\n" + "=" * 60)
        self.logger.info("EXITING PIPELINE DUE TO CRITICAL ISSUES")
        self.logger.info("=" * 60)
        self.logger.info("\nPlease fix the following issues:")
        for issue in self.validation_results["critical_issues"]:
            self.logger.info(f"\n[FAIL] {issue['check']}")
            self.logger.info(f"   {issue['issue']}")
            if isinstance(issue['details'], list) and len(issue['details']) <= 5:
                for detail in issue['details']:
                    self.logger.info(f"   - {detail}")
