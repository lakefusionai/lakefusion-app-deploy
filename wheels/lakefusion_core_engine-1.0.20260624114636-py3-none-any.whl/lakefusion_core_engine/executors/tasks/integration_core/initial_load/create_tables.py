"""
Create Tables Executor for integration core.

Creates the 4 core tables required for entity processing:
1. Master table - Golden records with lakefusion_id
2. Unified table - All source records with matching metadata
3. Merge Activities table - Audit log of merge operations
4. Attribute Version Sources table - Tracks attribute provenance

Also enables Change Data Feed (CDF) on source tables.

Workflow:
1. Construct table names with experiment suffix
2. Create master table schema
3. Create unified table schema
4. Create merge activities table schema
5. Create attribute version sources table schema
6. Enable CDF on all source tables
7. Verify all tables created
"""

import json
from typing import Any, Dict, List, Optional

from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType,
    TimestampType, ArrayType
)

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult
from lakefusion_core_engine.utils.parse_utils import get_spark_data_type, create_schema_fields


class CreateTablesExecutor(BaseStepTask):
    """
    Executor for creating initial load tables.

    Creates master, unified, merge_activities, and attribute_version_sources
    tables with appropriate schemas and CDF settings.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.tables_created = []
        self.cdf_enabled_count = 0
        self.cdf_failed_count = 0
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    @property
    def entity(self) -> str:
        """Get entity name from params."""
        return self.context.params.get('entity', '')

    @property
    def catalog_name(self) -> str:
        """Get catalog name from context."""
        return self.context.catalog_name

    @property
    def experiment_id(self) -> str:
        """Get experiment ID from params."""
        return self.context.params.get('experiment_id', '')

    @property
    def id_key(self) -> str:
        """Get ID key from params."""
        return self.context.params.get('id_key', 'lakefusion_id')

    @property
    def primary_key(self) -> str:
        """Get primary key from params."""
        return self.context.params.get('primary_key', '')

    @property
    def entity_attributes(self) -> List[str]:
        """Get entity attributes from params."""
        attrs = self.context.params.get('entity_attributes', [])
        if isinstance(attrs, str):
            return json.loads(attrs)
        return attrs

    @property
    def entity_attributes_datatype(self) -> Dict[str, str]:
        """Get entity attributes datatype from params."""
        datatypes = self.context.params.get('entity_attributes_datatype', {})
        if isinstance(datatypes, str):
            return json.loads(datatypes)
        return datatypes

    @property
    def dataset_tables(self) -> List[str]:
        """Get dataset tables from params."""
        tables = self.context.params.get('dataset_tables', [])
        if isinstance(tables, str):
            return json.loads(tables)
        return tables

    @property
    def experiment_suffix(self) -> str:
        """Get experiment suffix for table names."""
        if self.experiment_id:
            return f"_{self.experiment_id}"
        return ""

    @property
    def master_table(self) -> str:
        """Get master table name."""
        return f"{self.catalog_name}.gold.{self.entity}_master{self.experiment_suffix}"

    @property
    def unified_table(self) -> str:
        """Get unified table name."""
        return f"{self.catalog_name}.silver.{self.entity}_unified{self.experiment_suffix}"

    @property
    def merge_activities_table(self) -> str:
        """Get merge activities table name."""
        return f"{self.master_table}_merge_activities"

    @property
    def attribute_version_sources_table(self) -> str:
        """Get attribute version sources table name."""
        return f"{self.master_table}_attribute_version_sources"

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*60)
        self.logger.info("CREATE TABLES")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Catalog: {self.catalog_name}")
        self.logger.info(f"Experiment: {self.experiment_id if self.experiment_id else 'prod'}")
        self.logger.info(f"ID Key: {self.id_key}")
        self.logger.info(f"Primary Key: {self.primary_key}")
        self.logger.info(f"Attributes: {len(self.entity_attributes)}")
        self.logger.info(f"Entity Attributes Datatypes:")
        for attr, dtype in self.entity_attributes_datatype.items():
            self.logger.info(f"  {attr}: {dtype}")
        self.logger.info("="*60)

        self.logger.info(f"\nTable Names:")
        self.logger.info(f"  Master: {self.master_table}")
        self.logger.info(f"  Unified: {self.unified_table}")
        self.logger.info(f"  Merge Activities: {self.merge_activities_table}")
        self.logger.info(f"  Attribute Version Sources: {self.attribute_version_sources_table}")

    def _enable_cdf_on_table(self, table_name: str) -> bool:
        """
        Enable Change Data Feed on a table.

        Args:
            table_name: Fully qualified table name

        Returns:
            True if CDF enabled successfully, False otherwise
        """
        spark = self.context.spark
        try:
            spark.sql(f"ALTER TABLE {table_name} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)")
            self.logger.info(f"  [OK] CDF enabled on {table_name}")
            return True
        except Exception as e:
            self.logger.info(f"  [WARN] Could not enable CDF on {table_name}: {str(e)}")
            return False

    @step(order=1, name="Create Master Table", returns="dict - master table creation status")
    def step_create_master_table(self) -> Dict[str, Any]:
        """Create the master table."""
        spark = self.context.spark

        # Drop existing table if exists (fail-safe)
        spark.sql(f"DROP TABLE IF EXISTS {self.master_table}")
        self.logger.info(f"  [OK] Dropped existing table (if any)")

        # Create schema with EXACT attribute names using SDK utility
        master_fields = create_schema_fields(
            self.entity_attributes,
            self.entity_attributes_datatype,
            id_key=self.id_key,
            include_lakefusion_id=True
        )

        # Add system columns
        master_fields.extend([
            StructField("attributes_combined", StringType(), True)
        ])

        master_schema = StructType(master_fields)

        # Create empty DataFrame with schema
        master_df = spark.createDataFrame([], master_schema)

        # Write as Delta table with CDF enabled
        master_df.write \
            .format("delta") \
            .option("delta.enableChangeDataFeed", "true") \
            .mode("overwrite") \
            .saveAsTable(self.master_table)

        self.logger.info(f"  [OK] Created {self.master_table}")
        self.logger.info(f"  [OK] Attributes: {len(self.entity_attributes)}")
        self.logger.info(f"  [OK] CDF: Enabled")

        self.tables_created.append(self.master_table)
        return {
            "table": self.master_table,
            "attributes_count": len(self.entity_attributes),
            "cdf_enabled": True,
            "created": True
        }

    @step(order=2, name="Create Unified Table", returns="dict - unified table creation status")
    def step_create_unified_table(self) -> Dict[str, Any]:
        """Create the unified table."""
        spark = self.context.spark

        # Drop existing table if exists (fail-safe)
        spark.sql(f"DROP TABLE IF EXISTS {self.unified_table}")
        self.logger.info(f"  [OK] Dropped existing table (if any)")

        # Create schema
        unified_fields = [
            StructField("surrogate_key", StringType(), True),
            StructField("source_path", StringType(), True),
            StructField("source_id", StringType(), True),
            StructField("master_lakefusion_id", StringType(), True),
            StructField("record_status", StringType(), True),
            StructField("attributes_combined", StringType(), True),
            StructField("search_results", StringType(), True),
            StructField("scoring_results", StringType(), True)
        ]

        # Add all entity attributes (NO lakefusion_id in unified)
        for attr_name in self.entity_attributes:
            if attr_name == self.id_key:  # Skip lakefusion_id
                continue

            # Get datatype, default to 'string' if not found
            dtype_str = self.entity_attributes_datatype.get(attr_name, 'string')
            spark_dtype = get_spark_data_type(dtype_str)
            unified_fields.append(StructField(attr_name, spark_dtype, True))

        unified_schema = StructType(unified_fields)

        # Create empty DataFrame with schema
        unified_df = spark.createDataFrame([], unified_schema)

        # Write as Delta table with CDF enabled
        unified_df.write \
            .format("delta") \
            .option("delta.enableChangeDataFeed", "true") \
            .mode("overwrite") \
            .saveAsTable(self.unified_table)

        self.logger.info(f"  [OK] Created {self.unified_table}")
        self.logger.info(f"  [OK] Attributes: {len([a for a in self.entity_attributes if a != self.id_key])}")
        self.logger.info(f"  [OK] Added master_lakefusion_id column")
        self.logger.info(f"  [OK] CDF: Enabled")

        self.tables_created.append(self.unified_table)
        return {
            "table": self.unified_table,
            "attributes_count": len([a for a in self.entity_attributes if a != self.id_key]),
            "cdf_enabled": True,
            "created": True
        }

    @step(order=3, name="Create Merge Activities Table", returns="dict - merge activities table creation status")
    def step_create_merge_activities_table(self) -> Dict[str, Any]:
        """Create the merge activities table."""
        spark = self.context.spark

        # Drop existing table if exists (fail-safe)
        spark.sql(f"DROP TABLE IF EXISTS {self.merge_activities_table}")
        self.logger.info(f"  [OK] Dropped existing table (if any)")

        # Create schema - log table with single timestamp
        merge_activities_schema = StructType([
            StructField("master_id", StringType(), True),
            StructField("match_id", StringType(), True),
            StructField("source", StringType(), True),
            StructField("version", IntegerType(), True),
            StructField("action_type", StringType(), True),
            StructField("created_at", TimestampType(), True)
        ])

        # Create empty DataFrame
        merge_activities_df = spark.createDataFrame([], merge_activities_schema)

        # Write as Delta table (NO CDF - it's a log table)
        merge_activities_df.write \
            .format("delta") \
            .mode("overwrite") \
            .saveAsTable(self.merge_activities_table)

        self.logger.info(f"  [OK] Created {self.merge_activities_table}")
        self.logger.info(f"  [OK] Log table: Insert-only (no CDF)")

        self.tables_created.append(self.merge_activities_table)
        return {
            "table": self.merge_activities_table,
            "cdf_enabled": False,
            "created": True
        }

    @step(order=4, name="Create Attribute Version Sources Table", returns="dict - attribute version sources table creation status")
    def step_create_attribute_version_sources_table(self) -> Dict[str, Any]:
        """Create the attribute version sources table."""
        spark = self.context.spark

        # Drop existing table if exists (fail-safe)
        spark.sql(f"DROP TABLE IF EXISTS {self.attribute_version_sources_table}")
        self.logger.info(f"  [OK] Dropped existing table (if any)")

        # Create schema - log table, no timestamps needed
        attribute_version_sources_schema = StructType([
            StructField(self.id_key, StringType(), True),
            StructField("version", IntegerType(), True),
            StructField("attribute_source_mapping", ArrayType(StructType([
                StructField("attribute_name", StringType(), True),
                StructField("attribute_value", StringType(), True),
                StructField("source", StringType(), True)
            ])), True)
        ])

        # Create empty DataFrame
        attr_version_df = spark.createDataFrame([], attribute_version_sources_schema)

        # Write as Delta table (NO CDF - version tracking table)
        attr_version_df.write \
            .format("delta") \
            .mode("overwrite") \
            .saveAsTable(self.attribute_version_sources_table)

        self.logger.info(f"  [OK] Created {self.attribute_version_sources_table}")
        self.logger.info(f"  [OK] Version tracking table (no timestamps)")

        self.tables_created.append(self.attribute_version_sources_table)
        return {
            "table": self.attribute_version_sources_table,
            "cdf_enabled": False,
            "created": True
        }

    @step(order=5, name="Enable CDF on Source Tables", returns="dict - CDF enablement status")
    def step_enable_cdf_on_source_tables(self) -> Dict[str, Any]:
        """Enable CDF on all source tables."""
        spark = self.context.spark

        for source_table in self.dataset_tables:
            # Check if table exists before trying to enable CDF
            if spark.catalog.tableExists(source_table):
                if self._enable_cdf_on_table(source_table):
                    self.cdf_enabled_count += 1
                else:
                    self.cdf_failed_count += 1
            else:
                self.logger.info(f"  [WARN] Table does not exist: {source_table}")
                self.cdf_failed_count += 1

        self.logger.info(f"\n[OK] CDF enabled on {self.cdf_enabled_count}/{len(self.dataset_tables)} source tables")
        if self.cdf_failed_count > 0:
            self.logger.info(f"[WARN] {self.cdf_failed_count} tables failed or don't exist")

        return {
            "cdf_enabled_count": self.cdf_enabled_count,
            "cdf_failed_count": self.cdf_failed_count,
            "total_source_tables": len(self.dataset_tables)
        }

    @step(order=6, name="Verify Tables", returns="dict - verification status")
    def step_verify_tables(self) -> Dict[str, Any]:
        """Verify all tables were created successfully."""
        spark = self.context.spark

        tables_to_verify = [
            ("Master", self.master_table),
            ("Unified", self.unified_table),
            ("Merge Activities", self.merge_activities_table),
            ("Attribute Version Sources", self.attribute_version_sources_table)
        ]

        all_created = True
        verification_results = {}
        for name, table in tables_to_verify:
            exists = spark.catalog.tableExists(table)
            status = "[OK]" if exists else "[FAIL]"
            self.logger.info(f"{status} {name}: {table}")
            verification_results[name] = exists
            if not exists:
                all_created = False

        return {
            "all_created": all_created,
            "verification_results": verification_results
        }

    def execute(self) -> TaskResult:
        """Execute the create tables workflow."""
        # Create all 4 tables via step methods
        self.step_create_master_table()
        self.step_create_unified_table()
        self.step_create_merge_activities_table()
        self.step_create_attribute_version_sources_table()

        # Enable CDF on source tables
        self.step_enable_cdf_on_source_tables()

        # Verify all tables created
        verification_result = self.step_verify_tables()
        if not verification_result["all_created"]:
            raise ValueError("Not all tables were created successfully! One or more tables failed to create. Check logs above.")

        self.logger.info(f"\n[OK] All 4 tables created successfully!")

        return TaskResult.success(
            message=f"Created 4 tables for entity '{self.entity}'",
            task_name=self.context.task_name,
            metrics={
                'tables_created': len(self.tables_created),
                'attributes_count': len(self.entity_attributes),
                'cdf_enabled_count': self.cdf_enabled_count,
                'cdf_failed_count': self.cdf_failed_count
            },
            task_values={
                'master_table': self.master_table,
                'unified_table': self.unified_table,
                'merge_activities_table': self.merge_activities_table,
                'attribute_version_sources_table': self.attribute_version_sources_table
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="All tables created and verified",
            actual={'tables_created': self.tables_created}
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary and show table schemas."""
        self.logger.info("\n" + "="*60)
        self.logger.info("TABLE SCHEMAS")
        self.logger.info("="*60)

        spark = self.context.spark

        tables_to_show = [
            ("Master", self.master_table),
            ("Unified", self.unified_table),
            ("Merge Activities", self.merge_activities_table),
            ("Attribute Version Sources", self.attribute_version_sources_table)
        ]

        for name, table in tables_to_show:
            if spark.catalog.tableExists(table):
                self.logger.info(f"\n{name} Table: {table}")
                self.logger.info("-" * 60)
                schema = spark.table(table).schema
                for field in schema:
                    self.logger.info(f"  {field.name:30s} : {field.dataType}")
            else:
                self.logger.info(f"\n{name} Table: {table}")
                self.logger.info("-" * 60)
                self.logger.info(f"  [WARN] Table does not exist")

        self.logger.info("\n" + "="*60)
        self.logger.info("[SUCCESS] CREATE TABLES - COMPLETE")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Catalog: {self.catalog_name}")
        self.logger.info(f"Experiment: {self.experiment_id if self.experiment_id else 'prod'}")
        self.logger.info(f"Tables Created: 4")
        self.logger.info(f"Attributes: {len(self.entity_attributes)}")
        self.logger.info("="*60)
        self.logger.info("\nNext: Load Primary Source")
        self.logger.info("="*60)

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Create tables failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.info(f"  Error: {error}")
