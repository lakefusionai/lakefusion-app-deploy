"""
Load Primary Source Executor for integration core.

Loads data from the primary source table into master and unified tables.
This is the first data loading step in the initial load pipeline.

Workflow:
1. Read primary source data
2. Apply attribute mapping with type casting
3. Generate lakefusion_id and surrogate_key
4. Create attributes_combined column
5. Insert into master table
6. Insert into unified table (status=MERGED)
7. Log to merge_activities table
8. Log to attribute_version_sources table
9. Verify data consistency
"""

import json
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql.functions import (
    col, lit, udf, concat_ws, coalesce, current_timestamp, struct
)
from pyspark.sql.types import StringType, ArrayType, StructType, StructField

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult
from lakefusion_core_engine.utils.parse_utils import get_spark_data_type
from lakefusion_core_engine.identifiers import generate_lakefusion_id, generate_surrogate_key
from lakefusion_core_engine.models import RecordStatus, ActionType


class LoadPrimarySourceExecutor(BaseStepTask):
    """
    Executor for loading primary source data.

    Loads data from the primary source into master and unified tables,
    generating IDs and logging merge activities.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.record_count = 0
        self.master_version = 0
        # Intermediate DataFrames for step-based execution
        self.primary_df: DataFrame = None
        self.mapped_df: DataFrame = None
        self.id_df: DataFrame = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    @property
    def entity(self) -> str:
        """Get entity name from params."""
        return self.context.params.get('entity', '')

    @property
    def catalog_name(self) -> str:
        """Get catalog name from context."""
        return self.context.catalog_name

    @property
    def experiment_id(self) -> str:
        """Get experiment ID from params."""
        return self.context.params.get('experiment_id', '')

    @property
    def primary_table(self) -> str:
        """Get primary table from params."""
        return self.context.params.get('primary_table', '')

    @property
    def primary_key(self) -> str:
        """Get primary key from params."""
        return self.context.params.get('primary_key', '')

    @property
    def entity_attributes(self) -> List[str]:
        """Get entity attributes from params."""
        attrs = self.context.params.get('entity_attributes', [])
        if isinstance(attrs, str):
            return json.loads(attrs)
        return attrs

    @property
    def entity_attributes_datatype(self) -> Dict[str, str]:
        """Get entity attributes datatype from params."""
        datatypes = self.context.params.get('entity_attributes_datatype', {})
        if isinstance(datatypes, str):
            return json.loads(datatypes)
        return datatypes

    @property
    def match_attributes(self) -> List[str]:
        """Get match attributes from params."""
        attrs = self.context.params.get('match_attributes', [])
        if isinstance(attrs, str):
            return json.loads(attrs)
        return attrs

    @property
    def attributes_mapping(self) -> List[Dict]:
        """Get attributes mapping from params."""
        mapping = self.context.params.get('attributes_mapping', [])
        if isinstance(mapping, str):
            return json.loads(mapping)
        return mapping

    @property
    def experiment_suffix(self) -> str:
        """Get experiment suffix for table names."""
        if self.experiment_id:
            return f"_{self.experiment_id}"
        return ""

    @property
    def master_table(self) -> str:
        """Get master table name."""
        return f"{self.catalog_name}.gold.{self.entity}_master{self.experiment_suffix}"

    @property
    def unified_table(self) -> str:
        """Get unified table name."""
        return f"{self.catalog_name}.silver.{self.entity}_unified{self.experiment_suffix}"

    @property
    def merge_activities_table(self) -> str:
        """Get merge activities table name."""
        return f"{self.master_table}_merge_activities"

    @property
    def attribute_version_sources_table(self) -> str:
        """Get attribute version sources table name."""
        return f"{self.master_table}_attribute_version_sources"

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*60)
        self.logger.info("LOAD PRIMARY SOURCE")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Catalog: {self.catalog_name}")
        self.logger.info(f"Experiment: {self.experiment_id if self.experiment_id else 'prod'}")
        self.logger.info(f"Primary Table: {self.primary_table}")
        self.logger.info(f"Primary Key: {self.primary_key}")
        self.logger.info(f"Entity Attributes: {len(self.entity_attributes)}")
        self.logger.info("\nConstructed Table Names:")
        self.logger.info(f"  Master: {self.master_table}")
        self.logger.info(f"  Unified: {self.unified_table}")
        self.logger.info(f"  Merge Activities: {self.merge_activities_table}")
        self.logger.info(f"  Attribute Version Sources: {self.attribute_version_sources_table}")
        self.logger.info("="*60)

    def _get_primary_table_mapping(self) -> Dict[str, str]:
        """Get attribute mapping for the primary table."""
        for mapping_entry in self.attributes_mapping:
            if self.primary_table in mapping_entry:
                return mapping_entry[self.primary_table]
        raise ValueError(f"No attribute mapping found for primary table: {self.primary_table}")

    @step(order=1, name="Read Primary Source Data", returns="dict - source data stats")
    def step_read_primary_source(self) -> Dict[str, Any]:
        """Read data from the primary source table."""
        spark = self.context.spark

        self.primary_df = spark.read.table(self.primary_table)
        self.record_count = self.primary_df.count()

        self.logger.info(f"[OK] Read {self.record_count} records from {self.primary_table}")
        self.logger.info(f"[OK] Columns: {len(self.primary_df.columns)}")

        return {
            "record_count": self.record_count,
            "column_count": len(self.primary_df.columns),
            "source_table": self.primary_table
        }

    @step(order=2, name="Apply Attribute Mapping with Type Casting", returns="dict - mapping stats")
    def step_apply_attribute_mapping(self) -> Dict[str, Any]:
        """Apply attribute mapping with type casting to the source data."""
        primary_table_mapping = self._get_primary_table_mapping()
        self.logger.info(f"[OK] Found attribute mapping for {self.primary_table}")
        self.logger.info(f"[OK] Mapping: {len(primary_table_mapping)} attributes")

        # Build select expressions for column mapping WITH TYPE CASTING
        select_exprs = []
        mapped_columns = set()

        for entity_attr, dataset_attr in primary_table_mapping.items():
            if dataset_attr in self.primary_df.columns:
                # Get the target data type from entity model
                target_dtype_str = self.entity_attributes_datatype.get(entity_attr, 'string')
                target_spark_dtype = get_spark_data_type(target_dtype_str)

                # Get source data type
                source_field = [f for f in self.primary_df.schema.fields if f.name == dataset_attr][0]
                source_dtype = source_field.dataType

                # Cast to target type to match master table schema
                select_exprs.append(col(dataset_attr).cast(target_spark_dtype).alias(entity_attr))
                mapped_columns.add(entity_attr)

                # Log the mapping with type info
                if str(source_dtype) != str(target_spark_dtype):
                    self.logger.info(f"  Mapped: {dataset_attr} ({source_dtype}) -> {entity_attr} ({target_spark_dtype}) [CAST]")
                else:
                    self.logger.info(f"  Mapped: {dataset_attr} -> {entity_attr} ({target_spark_dtype})")
            else:
                self.logger.info(f"  [WARN] Warning: Dataset column '{dataset_attr}' not found in source table")

        self.logger.info(f"\n[OK] Mapped {len(select_exprs)} columns")

        # Add any missing entity attributes as NULL with CORRECT data type
        missing_attrs = 0
        for attr in self.entity_attributes:
            if attr not in mapped_columns and attr != "lakefusion_id":
                dtype_str = self.entity_attributes_datatype.get(attr, 'string')
                spark_dtype = get_spark_data_type(dtype_str)
                select_exprs.append(lit(None).cast(spark_dtype).alias(attr))
                missing_attrs += 1

        if missing_attrs > 0:
            self.logger.info(f"[OK] Added {missing_attrs} missing attributes as NULL (with correct types)")

        # Apply all mappings in a single select operation
        self.mapped_df = self.primary_df.select(*select_exprs)

        self.logger.info(f"\n[OK] Mapped DataFrame has {self.mapped_df.count()} records")
        self.logger.info(f"[OK] Resulting columns: {self.mapped_df.columns}")

        return {
            "mapped_columns": len(select_exprs),
            "missing_attrs_added": missing_attrs
        }

    @step(order=3, name="Generate IDs", returns="dict - ID generation stats")
    def step_generate_ids(self) -> Dict[str, Any]:
        """Generate lakefusion_id and surrogate_key for records."""
        # Create UDFs for ID generation
        generate_lakefusion_id_udf = udf(
            lambda source_path, source_id: generate_lakefusion_id(source_path, str(source_id)),
            StringType()
        )
        generate_surrogate_key_udf = udf(
            lambda source_path, source_id: generate_surrogate_key(source_path, str(source_id)),
            StringType()
        )

        # Add source metadata
        self.id_df = self.mapped_df \
            .withColumn("source_path", lit(self.primary_table)) \
            .withColumn("source_id", col(self.primary_key).cast("string"))

        # Generate both IDs deterministically based on source
        self.id_df = self.id_df \
            .withColumn("lakefusion_id", generate_lakefusion_id_udf(col("source_path"), col("source_id"))) \
            .withColumn("surrogate_key", generate_surrogate_key_udf(col("source_path"), col("source_id")))

        self.logger.info(f"[OK] Generated lakefusion_id for {self.record_count} records")
        self.logger.info(f"[OK] Generated surrogate_key for {self.record_count} records")
        self.logger.info(f"[OK] IDs are deterministic - same input produces same ID")

        return {
            "lakefusion_ids_generated": self.record_count,
            "surrogate_keys_generated": self.record_count
        }

    @step(order=4, name="Create Attributes Combined", returns="dict - attributes combined stats")
    def step_create_attributes_combined(self) -> Dict[str, Any]:
        """Create the attributes_combined column for matching."""
        combine_attrs = [attr for attr in self.match_attributes]
        # Use coalesce to preserve null positions as empty strings between separators.
        # Without this, concat_ws silently drops NULLs, misaligning fields with attribute order.
        self.id_df = self.id_df.withColumn(
            "attributes_combined",
            concat_ws(" | ", *[coalesce(col(attr).cast("string"), lit("")) for attr in combine_attrs])
        )

        self.logger.info(f"[OK] Created attributes_combined from {len(combine_attrs)} attributes")

        return {
            "attributes_combined_count": len(combine_attrs),
            "match_attributes": combine_attrs
        }

    @step(order=5, name="Insert into Master Table", returns="dict - master insert stats")
    def step_insert_master_table(self) -> Dict[str, Any]:
        """Insert records into the master table."""
        spark = self.context.spark

        master_columns = ["lakefusion_id"] + [attr for attr in self.entity_attributes if attr != "lakefusion_id"] + ["attributes_combined"]
        master_insert_df = self.id_df.select(*master_columns)

        before_count = spark.read.table(self.master_table).count()
        master_insert_df.write.format("delta").mode("append").saveAsTable(self.master_table)
        after_count = spark.read.table(self.master_table).count()
        inserted_count = after_count - before_count

        self.logger.info(f"[OK] Inserted {inserted_count} records into Master table")
        self.logger.info(f"  Before: {before_count}, After: {after_count}")

        return {
            "inserted_count": inserted_count,
            "before_count": before_count,
            "after_count": after_count
        }

    @step(order=6, name="Insert into Unified Table", returns="dict - unified insert stats")
    def step_insert_unified_table(self) -> Dict[str, Any]:
        """Insert records into the unified table with MERGED status."""
        spark = self.context.spark

        unified_select_cols = [
            "surrogate_key",
            "source_path",
            "source_id",
            col("lakefusion_id").alias("master_lakefusion_id"),
            lit(RecordStatus.MERGED.value).alias("record_status")
        ] + [col(attr) for attr in self.entity_attributes if attr != "lakefusion_id"] + [
            "attributes_combined",
            lit("").alias("search_results"),
            lit("").alias("scoring_results")
        ]

        unified_insert_df = self.id_df.select(*unified_select_cols)

        before_count = spark.read.table(self.unified_table).count()
        unified_insert_df.write.format("delta").mode("append").saveAsTable(self.unified_table)
        after_count = spark.read.table(self.unified_table).count()
        inserted_count = after_count - before_count

        self.logger.info(f"[OK] Inserted {inserted_count} records into Unified table")
        self.logger.info(f"  Status: {RecordStatus.MERGED.value} (primary records are pre-merged)")
        self.logger.info(f"  master_lakefusion_id: Linked to Master table")
        self.logger.info(f"  Before: {before_count}, After: {after_count}")

        return {
            "inserted_count": inserted_count,
            "before_count": before_count,
            "after_count": after_count,
            "record_status": RecordStatus.MERGED.value
        }

    @step(order=7, name="Log to Merge Activities", returns="dict - merge activities stats")
    def step_log_merge_activities(self) -> Dict[str, Any]:
        """Log initial load activities to the merge activities table."""
        spark = self.context.spark

        # Get current version of master table
        self.master_version = spark.sql(f"DESCRIBE HISTORY {self.master_table}").selectExpr("max(version)").first()[0]
        self.logger.info(f"[OK] Master table version: {self.master_version}")

        merge_activities_df = self.id_df.select(
            col("lakefusion_id").alias("master_id"),
            col("surrogate_key").alias("match_id"),
            col("source_path").alias("source"),
            lit(self.master_version).alias("version"),
            lit(ActionType.INITIAL_LOAD.value).alias("action_type"),
            current_timestamp().alias("created_at")
        )

        before_count = spark.read.table(self.merge_activities_table).count()
        merge_activities_df.write.format("delta").mode("append").saveAsTable(self.merge_activities_table)
        after_count = spark.read.table(self.merge_activities_table).count()
        inserted_count = after_count - before_count

        self.logger.info(f"[OK] Logged {inserted_count} activities to Merge Activities table")
        self.logger.info(f"  Action Type: {ActionType.INITIAL_LOAD.value}")
        self.logger.info(f"  master_id = lakefusion_id, match_id = surrogate_key")
        self.logger.info(f"  Before: {before_count}, After: {after_count}")

        return {
            "inserted_count": inserted_count,
            "action_type": ActionType.INITIAL_LOAD.value,
            "master_version": self.master_version
        }

    @step(order=8, name="Log to Attribute Version Sources", returns="dict - attribute version stats")
    def step_log_attribute_version_sources(self) -> Dict[str, Any]:
        """Log attribute version sources for provenance tracking."""
        spark = self.context.spark

        # Create attribute source mapping for each record
        entity_attributes_local = self.entity_attributes  # Local copy for UDF

        def create_attribute_mapping(row):
            """Create attribute source mapping for a single record."""
            mapping = []
            source_path = row["source_path"]

            for attr in entity_attributes_local:
                if attr == "lakefusion_id":
                    continue

                attr_value = row[attr]
                if attr_value is not None:
                    mapping.append({
                        "attribute_name": attr,
                        "attribute_value": str(attr_value),
                        "source": source_path
                    })

            return mapping

        # Register UDF for creating attribute mapping
        create_mapping_udf = udf(
            create_attribute_mapping,
            ArrayType(StructType([
                StructField("attribute_name", StringType()),
                StructField("attribute_value", StringType()),
                StructField("source", StringType())
            ]))
        )

        # Create attribute version sources records DIRECTLY from id_df
        attr_version_df = self.id_df.select(
            col("lakefusion_id"),
            lit(self.master_version).alias("version"),
            create_mapping_udf(struct(*self.id_df.columns)).alias("attribute_source_mapping")
        )

        before_count = spark.read.table(self.attribute_version_sources_table).count()
        attr_version_df.write.format("delta").mode("append").saveAsTable(self.attribute_version_sources_table)
        after_count = spark.read.table(self.attribute_version_sources_table).count()
        inserted_count = after_count - before_count

        self.logger.info(f"[OK] Logged {inserted_count} attribute version records")
        self.logger.info(f"  Version: {self.master_version}")
        self.logger.info(f"  Before: {before_count}, After: {after_count}")

        return {
            "inserted_count": inserted_count,
            "version": self.master_version
        }

    def execute(self) -> TaskResult:
        """Execute the load primary source workflow."""
        # Execute all steps in sequence
        self.step_read_primary_source()
        self.step_apply_attribute_mapping()
        self.step_generate_ids()
        self.step_create_attributes_combined()
        self.step_insert_master_table()
        self.step_insert_unified_table()
        self.step_log_merge_activities()
        self.step_log_attribute_version_sources()

        return TaskResult.success(
            message=f"Loaded {self.record_count} records from primary source",
            task_name=self.context.task_name,
            metrics={
                'records_loaded': self.record_count,
                'master_version': self.master_version,
                'source_table': self.primary_table
            },
            task_values={
                'primary_load_complete': True,
                'primary_records_loaded': self.record_count
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result by checking data consistency."""
        if result.is_failed:
            return result

        self.logger.info("\n" + "="*60)
        self.logger.info("VERIFICATION")
        self.logger.info("="*60)

        spark = self.context.spark

        # Count records in each table
        master_count = spark.read.table(self.master_table).count()
        unified_count = spark.read.table(self.unified_table).count()
        merge_activities_count = spark.read.table(self.merge_activities_table).count()
        attr_version_count = spark.read.table(self.attribute_version_sources_table).count()

        self.logger.info(f"Master Table: {master_count} records")
        self.logger.info(f"Unified Table: {unified_count} records (status=MERGED)")
        self.logger.info(f"Merge Activities: {merge_activities_count} records (action=INITIAL_LOAD)")
        self.logger.info(f"Attribute Version Sources: {attr_version_count} records")

        # Verify counts match
        if master_count == unified_count == merge_activities_count == attr_version_count:
            self.logger.info(f"\n[OK] All counts match: {master_count} records")
            result.add_validation(ValidationResult(
                passed=True,
                message="Record counts match across all tables",
                actual={'count': master_count}
            ))
        else:
            self.logger.info(f"\n[WARN] Warning: Counts don't match!")
            self.logger.info(f"   Master: {master_count}")
            self.logger.info(f"   Unified: {unified_count}")
            self.logger.info(f"   Merge Activities: {merge_activities_count}")
            self.logger.info(f"   Attr Version Sources: {attr_version_count}")
            result.add_validation(ValidationResult(
                passed=False,
                message="Record counts don't match across tables",
                actual={
                    'master': master_count,
                    'unified': unified_count,
                    'merge_activities': merge_activities_count,
                    'attr_version': attr_version_count
                }
            ))

        # Verify lakefusion_id consistency
        self.logger.info("\n" + "="*60)
        self.logger.info("LAKEFUSION_ID CONSISTENCY CHECK")
        self.logger.info("="*60)

        master_ids = spark.read.table(self.master_table).select("lakefusion_id").distinct()
        merge_master_ids = spark.read.table(self.merge_activities_table).select(col("master_id").alias("lakefusion_id")).distinct()
        attr_version_ids = spark.read.table(self.attribute_version_sources_table).select("lakefusion_id").distinct()

        master_id_count = master_ids.count()
        merge_id_count = merge_master_ids.count()
        attr_id_count = attr_version_ids.count()

        self.logger.info(f"Unique lakefusion_ids in Master: {master_id_count}")
        self.logger.info(f"Unique master_ids in Merge Activities: {merge_id_count}")
        self.logger.info(f"Unique lakefusion_ids in Attr Version Sources: {attr_id_count}")

        if master_id_count == merge_id_count == attr_id_count:
            self.logger.info("[SUCCESS] All lakefusion_ids are consistent across tables!")
            result.add_validation(ValidationResult(
                passed=True,
                message="Lakefusion IDs consistent across tables",
                actual={'unique_ids': master_id_count}
            ))
        else:
            self.logger.info("[FAIL] ERROR: lakefusion_ids don't match across tables!")
            result.add_validation(ValidationResult(
                passed=False,
                message="Lakefusion IDs inconsistent across tables",
                actual={
                    'master': master_id_count,
                    'merge': merge_id_count,
                    'attr_version': attr_id_count
                }
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*60)
        self.logger.info("[SUCCESS] LOAD PRIMARY SOURCE - COMPLETE")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Source: {self.primary_table}")
        self.logger.info(f"Records Loaded: {self.record_count}")
        self.logger.info(f"Master Version: {self.master_version}")
        self.logger.info("="*60)
        self.logger.info("Next: Load Secondary Sources")
        self.logger.info("="*60)

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Load primary source failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.info(f"  Error: {error}")
