"""
Load Secondary Sources Executor for integration core.

Loads data from secondary source tables (non-primary) into the unified table.
Secondary source records are loaded with ACTIVE status and no master linkage.

Workflow:
1. Derive secondary sources (all tables except primary)
2. For each secondary source:
   a. Find attribute mapping
   b. Find primary key column mapping
   c. Read source data
   d. Apply attribute mapping with type casting
   e. Generate surrogate_key
   f. Create attributes_combined column
   g. Insert into unified table (status=ACTIVE)
3. Verify data consistency
"""

import json
import traceback
from typing import Any, Dict, List, Optional

from pyspark.sql.functions import col, lit, udf, concat_ws, coalesce
from pyspark.sql.types import StringType

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult
from lakefusion_core_engine.utils.parse_utils import get_spark_data_type
from lakefusion_core_engine.identifiers import generate_surrogate_key
from lakefusion_core_engine.models import RecordStatus


class LoadSecondarySourcesExecutor(BaseStepTask):
    """
    Executor for loading secondary source data.

    Loads data from all non-primary source tables into the unified table
    with ACTIVE status for later matching.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.total_records_loaded = 0
        self.successful_sources = 0
        self.failed_sources = []
        self.secondary_tables = []
        # Intermediate state for step-based execution
        self.unified_before_count = 0
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    @property
    def entity(self) -> str:
        """Get entity name from params."""
        return self.context.params.get('entity', '')

    @property
    def catalog_name(self) -> str:
        """Get catalog name from context."""
        return self.context.catalog_name

    @property
    def experiment_id(self) -> str:
        """Get experiment ID from params."""
        return self.context.params.get('experiment_id', '')

    @property
    def dataset_tables(self) -> List[str]:
        """Get dataset tables from params."""
        tables = self.context.params.get('dataset_tables', [])
        if isinstance(tables, str):
            return json.loads(tables)
        return tables

    @property
    def dataset_objects(self) -> Dict[str, Dict]:
        """Get dataset objects from params."""
        objects = self.context.params.get('dataset_objects', {})
        if isinstance(objects, str):
            return json.loads(objects)
        return objects

    @property
    def primary_table(self) -> str:
        """Get primary table from params."""
        return self.context.params.get('primary_table', '')

    @property
    def primary_key(self) -> str:
        """Get primary key from params."""
        return self.context.params.get('primary_key', '')

    @property
    def entity_attributes(self) -> List[str]:
        """Get entity attributes from params."""
        attrs = self.context.params.get('entity_attributes', [])
        if isinstance(attrs, str):
            return json.loads(attrs)
        return attrs

    @property
    def entity_attributes_datatype(self) -> Dict[str, str]:
        """Get entity attributes datatype from params."""
        datatypes = self.context.params.get('entity_attributes_datatype', {})
        if isinstance(datatypes, str):
            return json.loads(datatypes)
        return datatypes

    @property
    def attributes_mapping(self) -> List[Dict]:
        """Get attributes mapping from params."""
        mapping = self.context.params.get('attributes_mapping', [])
        if isinstance(mapping, str):
            return json.loads(mapping)
        return mapping

    @property
    def match_attributes(self) -> List[str]:
        """Get match attributes from params."""
        attrs = self.context.params.get('match_attributes', [])
        if isinstance(attrs, str):
            return json.loads(attrs)
        return attrs

    @property
    def experiment_suffix(self) -> str:
        """Get experiment suffix for table names."""
        if self.experiment_id:
            return f"_{self.experiment_id}"
        return ""

    @property
    def unified_table(self) -> str:
        """Get unified table name."""
        return f"{self.catalog_name}.silver.{self.entity}_unified{self.experiment_suffix}"

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*60)
        self.logger.info("LOAD SECONDARY SOURCES")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Catalog: {self.catalog_name}")
        self.logger.info(f"Experiment: {self.experiment_id if self.experiment_id else 'prod'}")
        self.logger.info(f"Unified Table: {self.unified_table}")
        self.logger.info(f"Primary Table: {self.primary_table}")
        self.logger.info(f"Primary Key (Entity): {self.primary_key}")
        self.logger.info(f"Total Dataset Tables: {len(self.dataset_tables)}")
        self.logger.info("="*60)

    def _get_secondary_tables(self) -> List[str]:
        """Derive secondary tables by excluding primary table."""
        return [table for table in self.dataset_tables if table != self.primary_table]

    def _get_table_mapping(self, table: str) -> Dict[str, str]:
        """Get attribute mapping for a specific table."""
        for mapping_entry in self.attributes_mapping:
            if table in mapping_entry:
                return mapping_entry[table]
        return None

    def _process_secondary_source(self, idx: int, secondary_table: str) -> bool:
        """
        Process a single secondary source table.

        Args:
            idx: Index of the source (1-based)
            secondary_table: Path to the secondary table

        Returns:
            True if successful, False otherwise
        """
        spark = self.context.spark
        total_secondary = len(self.secondary_tables)

        self.logger.info("\n" + "-"*60)
        self.logger.info(f"Processing Secondary Source {idx}/{total_secondary}")
        self.logger.info(f"  Table: {secondary_table}")
        self.logger.info("-"*60)

        # Step a: Find attribute mapping for this secondary table
        self.logger.info(f"\n[{idx}.a] Finding attribute mapping...")

        secondary_mapping = self._get_table_mapping(secondary_table)

        if not secondary_mapping:
            self.logger.info(f"  [WARN] Warning: No attribute mapping found for {secondary_table}")
            self.logger.info(f"  Skipping this source")
            self.failed_sources.append({"table": secondary_table, "reason": "No attribute mapping"})
            return False

        self.logger.info(f"  [OK] Found mapping with {len(secondary_mapping)} attributes")

        # Step b: Find the source column that maps to the entity's primary key
        self.logger.info(f"\n[{idx}.b] Finding primary key column...")

        source_primary_key = secondary_mapping.get(self.primary_key)

        if not source_primary_key:
            self.logger.info(f"  [WARN] Warning: Entity primary key '{self.primary_key}' not found in mapping")
            self.logger.info(f"  Available entity attributes in mapping: {list(secondary_mapping.keys())}")
            self.logger.info(f"  Skipping this source")
            self.failed_sources.append({"table": secondary_table, "reason": f"Entity primary key '{self.primary_key}' not in mapping"})
            return False

        self.logger.info(f"  [OK] Source primary key column: {source_primary_key}")
        self.logger.info(f"  [OK] Entity attribute '{self.primary_key}' maps from dataset column '{source_primary_key}'")

        # Step c: Read secondary source data
        self.logger.info(f"\n[{idx}.c] Reading data from {secondary_table}...")
        secondary_df = spark.read.table(secondary_table)
        source_record_count = secondary_df.count()
        self.logger.info(f"  [OK] Read {source_record_count} records")

        if source_record_count == 0:
            self.logger.info(f"  [WARN] Skipping - no records in source table")
            return True  # Not a failure, just empty

        # Verify source_primary_key column exists
        if source_primary_key not in secondary_df.columns:
            self.logger.info(f"  [FAIL] Error: Primary key column '{source_primary_key}' not found in source table")
            self.logger.info(f"  Available columns: {secondary_df.columns}")
            self.failed_sources.append({"table": secondary_table, "reason": f"Primary key column '{source_primary_key}' not found"})
            return False

        # Step d: Apply attribute mapping WITH TYPE CASTING
        self.logger.info(f"\n[{idx}.d] Applying attribute mapping with type casting...")

        select_exprs = []
        mapped_columns = set()

        for entity_attr, dataset_attr in secondary_mapping.items():
            if dataset_attr in secondary_df.columns:
                target_dtype_str = self.entity_attributes_datatype.get(entity_attr, 'string')
                target_spark_dtype = get_spark_data_type(target_dtype_str)

                source_field = [f for f in secondary_df.schema.fields if f.name == dataset_attr][0]
                source_dtype = source_field.dataType

                select_exprs.append(col(dataset_attr).cast(target_spark_dtype).alias(entity_attr))
                mapped_columns.add(entity_attr)

                if str(source_dtype) != str(target_spark_dtype):
                    self.logger.info(f"    Mapped: {dataset_attr} ({source_dtype}) -> {entity_attr} ({target_spark_dtype}) [CAST]")
                else:
                    self.logger.info(f"    Mapped: {dataset_attr} -> {entity_attr} ({target_spark_dtype})")
            else:
                self.logger.info(f"    [WARN] Warning: Dataset column '{dataset_attr}' not found in source table")

        self.logger.info(f"  [OK] Mapped {len(select_exprs)} columns")

        # Add missing entity attributes as NULL with CORRECT data type
        missing_attrs = 0
        for attr in self.entity_attributes:
            if attr not in mapped_columns and attr != "lakefusion_id":
                dtype_str = self.entity_attributes_datatype.get(attr, 'string')
                spark_dtype = get_spark_data_type(dtype_str)
                select_exprs.append(lit(None).cast(spark_dtype).alias(attr))
                missing_attrs += 1

        if missing_attrs > 0:
            self.logger.info(f"  [OK] Added {missing_attrs} missing attributes as NULL (with correct types)")

        # Apply all mappings in a single select operation
        mapped_df = secondary_df.select(*select_exprs)

        self.logger.info(f"  [OK] Resulting columns: {mapped_df.columns}")
        self.logger.info(f"  [OK] All columns now match unified table schema types")

        # Step e: Generate surrogate_key
        self.logger.info(f"\n[{idx}.e] Generating surrogate keys...")

        generate_surrogate_key_udf = udf(
            lambda source_path, source_id: generate_surrogate_key(source_path, str(source_id)),
            StringType()
        )

        # Add source metadata
        mapped_df = mapped_df \
            .withColumn("source_path", lit(secondary_table)) \
            .withColumn("source_id", col(self.primary_key).cast("string"))

        # Generate surrogate_key deterministically
        mapped_df = mapped_df.withColumn(
            "surrogate_key",
            generate_surrogate_key_udf(col("source_path"), col("source_id"))
        )

        self.logger.info(f"  [OK] Generated surrogate keys for {source_record_count} records")
        self.logger.info(f"  [OK] Using '{self.primary_key}' as source_id")

        # Step f: Create attributes_combined
        self.logger.info(f"\n[{idx}.f] Creating attributes_combined column...")

        combine_attrs = [attr for attr in self.match_attributes]
        mapped_df = mapped_df.withColumn(
            "attributes_combined",
            concat_ws(" | ", *[coalesce(col(attr).cast("string"), lit("")) for attr in combine_attrs])
        )

        self.logger.info(f"  [OK] Created attributes_combined from {len(combine_attrs)} attributes")

        # Step g: Prepare for unified table insert
        self.logger.info(f"\n[{idx}.g] Preparing data for Unified table insert...")

        unified_select_cols = [
            "surrogate_key",
            "source_path",
            "source_id",
            lit(None).cast(StringType()).alias("master_lakefusion_id"),  # NULL until matched/merged
            lit(RecordStatus.ACTIVE.value).alias("record_status")
        ] + [col(attr) for attr in self.entity_attributes if attr != "lakefusion_id"] + [
            "attributes_combined",
            lit("").alias("search_results"),
            lit("").alias("scoring_results")
        ]

        unified_insert_df = mapped_df.select(*unified_select_cols)

        records_to_insert = unified_insert_df.count()
        self.logger.info(f"  [OK] Prepared {records_to_insert} records for insert")
        self.logger.info(f"  [OK] Status: {RecordStatus.ACTIVE.value}")
        self.logger.info(f"  [OK] master_lakefusion_id: NULL (will be set after matching/merging)")
        self.logger.info(f"  [OK] Schema matches unified table (all types cast to entity model types)")

        # Step h: Insert into unified table
        self.logger.info(f"\n[{idx}.h] Inserting into Unified table...")

        before_insert = spark.read.table(self.unified_table).count()
        unified_insert_df.write.format("delta").mode("append").saveAsTable(self.unified_table)
        after_insert = spark.read.table(self.unified_table).count()
        inserted = after_insert - before_insert

        self.logger.info(f"  [OK] Inserted {inserted} records")
        self.logger.info(f"  [OK] Before: {before_insert}, After: {after_insert}")

        self.total_records_loaded += inserted
        self.successful_sources += 1

        self.logger.info(f"\n[SUCCESS] Successfully processed {secondary_table}")
        return True

    @step(order=1, name="Derive Secondary Sources", returns="dict - secondary sources info")
    def step_derive_secondary_sources(self) -> Dict[str, Any]:
        """Derive secondary tables by excluding primary table."""
        self.secondary_tables = self._get_secondary_tables()

        self.logger.info(f"Dataset Tables: {len(self.dataset_tables)}")
        self.logger.info(f"Primary Table: {self.primary_table}")
        self.logger.info(f"Secondary Tables: {len(self.secondary_tables)}")

        # Check if secondary sources exist
        if not self.secondary_tables or len(self.secondary_tables) == 0:
            self.logger.info("\n[INFO] No secondary sources found for this entity")
            self.logger.info("[OK] This is a single-source entity")
            return {
                "secondary_sources_count": 0,
                "is_single_source": True,
                "secondary_tables": []
            }

        self.logger.info(f"\n[OK] Found {len(self.secondary_tables)} secondary source(s):")
        for i, sec_table in enumerate(self.secondary_tables, 1):
            table_info = self.dataset_objects.get(sec_table, {})
            table_name = table_info.get("name", sec_table)
            self.logger.info(f"  {i}. {sec_table}")
            self.logger.info(f"     Name: {table_name}")
            self.logger.info(f"     Active: {table_info.get('is_active', 'Unknown')}")

        return {
            "secondary_sources_count": len(self.secondary_tables),
            "is_single_source": False,
            "secondary_tables": self.secondary_tables
        }

    @step(order=2, name="Process Secondary Sources", returns="dict - processing stats")
    def step_process_secondary_sources(self) -> Dict[str, Any]:
        """Process all secondary source tables."""
        spark = self.context.spark

        # If no secondary sources, return early
        if not self.secondary_tables or len(self.secondary_tables) == 0:
            return {
                "processed": 0,
                "successful": 0,
                "failed": 0,
                "records_loaded": 0
            }

        # Get unified table count before processing
        self.unified_before_count = spark.read.table(self.unified_table).count()
        self.logger.info(f"Unified table count before: {self.unified_before_count}")

        # Process each secondary source
        for idx, secondary_table in enumerate(self.secondary_tables, 1):
            try:
                self._process_secondary_source(idx, secondary_table)
            except Exception as e:
                self.logger.info(f"\n[FAIL] Error processing {secondary_table}:")
                self.logger.info(f"   {str(e)}")
                self.logger.info(f"\n   Stack trace:")
                traceback.print_exc()
                self.failed_sources.append({"table": secondary_table, "reason": str(e)})
                # Continue with next source instead of failing the entire job
                continue

        return {
            "processed": len(self.secondary_tables),
            "successful": self.successful_sources,
            "failed": len(self.failed_sources),
            "records_loaded": self.total_records_loaded
        }

    def execute(self) -> TaskResult:
        """Execute the load secondary sources workflow."""
        # Step 1: Derive secondary sources
        derive_result = self.step_derive_secondary_sources()

        # Check if secondary sources exist - handle single-source entity
        if derive_result["is_single_source"]:
            self.logger.info("\n" + "="*60)
            self.logger.info("EXITING - NO SECONDARY SOURCES TO LOAD")
            self.logger.info("="*60)

            return TaskResult.success(
                message="No secondary sources to load (single-source entity)",
                task_name=self.context.task_name,
                metrics={
                    'secondary_sources_count': 0,
                    'records_loaded': 0,
                    'is_single_source': True
                },
                task_values={
                    'secondary_load_complete': True,
                    'secondary_records_loaded': 0,
                    'secondary_sources_count': 0
                }
            )

        # Step 2: Process secondary sources
        self.step_process_secondary_sources()

        # Determine overall status (matches production behavior - continues even if all fail)
        if len(self.failed_sources) == 0:
            status_message = f"Loaded {self.total_records_loaded} records from {self.successful_sources} secondary sources"
        elif self.successful_sources > 0:
            status_message = f"Partial success: Loaded {self.total_records_loaded} records from {self.successful_sources}/{len(self.secondary_tables)} sources"
        else:
            # All sources failed - still continue (matches production notebook behavior)
            status_message = f"All {len(self.secondary_tables)} secondary sources failed to load"
            self.logger.info(f"\n[WARN] {status_message}")
            for fs in self.failed_sources:
                self.logger.info(f"  - {fs['table']}: {fs['reason']}")

        return TaskResult.success(
            message=status_message,
            task_name=self.context.task_name,
            metrics={
                'secondary_sources_count': len(self.secondary_tables),
                'successful_sources': self.successful_sources,
                'failed_sources': len(self.failed_sources),
                'records_loaded': self.total_records_loaded,
                'is_single_source': False
            },
            task_values={
                'secondary_load_complete': True,
                'secondary_records_loaded': self.total_records_loaded,
                'secondary_sources_count': len(self.secondary_tables)
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        self.logger.info("\n" + "="*60)
        self.logger.info("VERIFICATION")
        self.logger.info("="*60)

        spark = self.context.spark

        # Get final unified table count
        unified_after_count = spark.read.table(self.unified_table).count()

        self.logger.info(f"Unified Table:")
        self.logger.info(f"  Total records: {unified_after_count}")

        self.logger.info(f"\nSecondary Sources Processing Summary:")
        self.logger.info(f"  Total secondary sources: {len(self.secondary_tables)}")
        self.logger.info(f"  Successfully processed: {self.successful_sources}")
        self.logger.info(f"  Failed: {len(self.failed_sources)}")
        self.logger.info(f"  Total records loaded: {self.total_records_loaded}")

        if self.failed_sources:
            self.logger.info(f"\n[WARN] Failed Sources:")
            for failed in self.failed_sources:
                self.logger.info(f"    - {failed['table']}")
                self.logger.info(f"      Reason: {failed['reason']}")

        result.add_validation(ValidationResult(
            passed=len(self.failed_sources) == 0,
            message="Secondary sources validation",
            actual={
                'successful': self.successful_sources,
                'failed': len(self.failed_sources),
                'records': self.total_records_loaded
            }
        ))

        # Count records by status
        self.logger.info(f"\n" + "-"*60)
        self.logger.info("Unified Table Record Status Breakdown:")
        self.logger.info("-"*60)
        status_counts = spark.read.table(self.unified_table) \
            .groupBy("record_status") \
            .count() \
            .orderBy("record_status")
        status_counts.show(truncate=False)

        # Count records by source
        self.logger.info(f"\n" + "-"*60)
        self.logger.info("Unified Table Records by Source:")
        self.logger.info("-"*60)
        source_counts = spark.read.table(self.unified_table) \
            .groupBy("source_path") \
            .count() \
            .orderBy(col("count").desc())
        source_counts.show(truncate=False)

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        status = 'SUCCESS' if len(self.failed_sources) == 0 else 'PARTIAL SUCCESS'

        self.logger.info("\n" + "="*60)
        self.logger.info(f"[{status}] LOAD SECONDARY SOURCES - COMPLETE")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Primary Table: {self.primary_table}")
        self.logger.info(f"Secondary Sources: {len(self.secondary_tables)}")
        self.logger.info(f"  - Processed: {self.successful_sources}")
        self.logger.info(f"  - Failed: {len(self.failed_sources)}")
        self.logger.info(f"Records Loaded: {self.total_records_loaded}")
        self.logger.info(f"Status: {status}")
        self.logger.info("="*60)
        if self.failed_sources:
            self.logger.info(f"\n[WARN] {len(self.failed_sources)} source(s) failed - check logs above")
        self.logger.info("Next: Entity Matching - Vector Search")
        self.logger.info("="*60)

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Load secondary sources failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.info(f"  Error: {error}")
