"""
Validate Initial Load Executor for integration core.

Validates entity configuration before creating tables. Performs 7 validation
checks to ensure data integrity before proceeding with initial load.

Workflow:
1. Validate source table existence
2. Validate attribute mapping completeness
3. Validate primary key mapping existence
4. Validate primary key column existence
5. Validate primary key has no NULL values
6. Validate primary key uniqueness
7. Validate mapped column existence
"""

import json
from datetime import datetime
from typing import Any, Dict, List, Optional

from pyspark.sql.functions import col

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ValidateInitialLoadExecutor(BaseStepTask):
    """
    Executor for validating entity configuration before initial load.

    Performs comprehensive validation checks on source tables, attribute
    mappings, and primary key integrity.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.validation_results = {
            "entity": "",
            "timestamp": "",
            "critical_issues": [],
            "warnings": [],
            "checks_passed": [],
            "validation_passed": True
        }
        # Tracking lists for validation results
        self.missing_tables = []
        self.tables_without_mapping = []
        self.tables_missing_pk_mapping = []
        self.tables_missing_pk_column = []
        self.tables_with_nulls = []
        self.tables_with_duplicates = []
        self.missing_mapped_columns = []
        self.special_char_columns = []
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    @property
    def entity(self) -> str:
        """Get entity name from context."""
        return self.context.entity

    @property
    def catalog_name(self) -> str:
        """Get catalog name from context."""
        return self.context.catalog_name

    @property
    def dataset_tables(self) -> List[str]:
        """Get dataset tables from params."""
        tables = self.context.params.get('dataset_tables', [])
        if isinstance(tables, str):
            return json.loads(tables)
        return tables

    @property
    def attributes_mapping(self) -> List[Dict]:
        """Get attributes mapping from params."""
        mapping = self.context.params.get('attributes_mapping', [])
        if isinstance(mapping, str):
            return json.loads(mapping)
        return mapping

    @property
    def primary_table(self) -> str:
        """Get primary table from params."""
        return self.context.params.get('primary_table', '')

    @property
    def primary_key(self) -> str:
        """Get primary key from params."""
        return self.context.params.get('primary_key', '')

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*60)
        self.logger.info("ENTITY CONFIGURATION VALIDATION")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Catalog: {self.catalog_name}")
        self.logger.info(f"Primary Table: {self.primary_table}")
        self.logger.info(f"Primary Key: {self.primary_key}")
        self.logger.info(f"Total Tables: {len(self.dataset_tables)}")
        self.logger.info("="*60)

        self.validation_results["entity"] = self.entity
        self.validation_results["timestamp"] = datetime.now().isoformat()

    @step(order=1, name="Validate Source Table Existence", returns="dict - validation status for table existence")
    def step_validate_source_table_existence(self) -> Dict[str, Any]:
        """Validation 1: Check if all source tables exist."""
        spark = self.context.spark

        for table in self.dataset_tables:
            try:
                spark.sql(f"DESCRIBE TABLE {table}")
                self.logger.info(f"  [OK] Table exists: {table}")
            except Exception:
                self.missing_tables.append(table)
                self.logger.info(f"  [FAIL] Table NOT found: {table}")

        if self.missing_tables:
            self.validation_results["critical_issues"].append({
                "check": "Source Table Existence",
                "issue": "Missing tables",
                "details": self.missing_tables
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] {len(self.missing_tables)} table(s) do not exist")
        else:
            self.validation_results["checks_passed"].append("Source Table Existence")
            self.logger.info(f"\n[PASSED] All {len(self.dataset_tables)} tables exist")

        return {
            "missing_tables": self.missing_tables,
            "tables_checked": len(self.dataset_tables),
            "passed": len(self.missing_tables) == 0
        }

    @step(order=2, name="Validate Attribute Mapping Completeness", returns="dict - validation status for attribute mappings")
    def step_validate_attribute_mapping_completeness(self) -> Dict[str, Any]:
        """Validation 2: Check if all tables have attribute mappings."""
        mapped_tables = [list(mapping.keys())[0] for mapping in self.attributes_mapping]

        for table in self.dataset_tables:
            if table in mapped_tables:
                self.logger.info(f"  [OK] Mapping exists: {table}")
            else:
                self.tables_without_mapping.append(table)
                self.logger.info(f"  [FAIL] Mapping NOT found: {table}")

        if self.tables_without_mapping:
            self.validation_results["critical_issues"].append({
                "check": "Attribute Mapping Completeness",
                "issue": "Tables without attribute mappings",
                "details": self.tables_without_mapping
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] {len(self.tables_without_mapping)} table(s) missing attribute mappings")
        else:
            self.validation_results["checks_passed"].append("Attribute Mapping Completeness")
            self.logger.info(f"\n[PASSED] All {len(self.dataset_tables)} tables have attribute mappings")

        return {
            "tables_without_mapping": self.tables_without_mapping,
            "tables_checked": len(self.dataset_tables),
            "passed": len(self.tables_without_mapping) == 0
        }

    @step(order=3, name="Validate Primary Key Mapping Existence", returns="dict - validation status for PK mappings")
    def step_validate_primary_key_mapping_existence(self) -> Dict[str, Any]:
        """Validation 3: Check if primary key is mapped for all tables."""
        for table in self.dataset_tables:
            # Find the mapping for this table
            table_mapping = None
            for mapping_entry in self.attributes_mapping:
                if table in mapping_entry:
                    table_mapping = mapping_entry[table]
                    break

            if not table_mapping:
                # Already caught in validation 2, skip
                continue

            # Check if primary_key is in the mapping
            if self.primary_key in table_mapping:
                source_pk_column = table_mapping[self.primary_key]
                self.logger.info(f"  [OK] Primary key mapped: {table}")
                self.logger.info(f"    Entity attr '{self.primary_key}' <- Dataset column '{source_pk_column}'")
            else:
                self.tables_missing_pk_mapping.append(table)
                self.logger.info(f"  [FAIL] Primary key NOT mapped: {table}")
                self.logger.info(f"    Entity primary key '{self.primary_key}' not found in mapping")

        if self.tables_missing_pk_mapping:
            self.validation_results["critical_issues"].append({
                "check": "Primary Key Mapping Existence",
                "issue": "Tables missing primary key mapping",
                "details": self.tables_missing_pk_mapping
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] {len(self.tables_missing_pk_mapping)} table(s) missing primary key mapping")
        else:
            self.validation_results["checks_passed"].append("Primary Key Mapping Existence")
            self.logger.info(f"\n[PASSED] All tables have primary key mappings")

        return {
            "tables_missing_pk_mapping": self.tables_missing_pk_mapping,
            "passed": len(self.tables_missing_pk_mapping) == 0
        }

    @step(order=4, name="Validate Primary Key Column Existence", returns="dict - validation status for PK columns")
    def step_validate_primary_key_column_existence(self) -> Dict[str, Any]:
        """Validation 4: Check if primary key column exists in source tables."""
        spark = self.context.spark

        for table in self.dataset_tables:
            # Skip if table doesn't exist or has no mapping
            if table in self.missing_tables or table in self.tables_without_mapping:
                continue

            # Find the mapping for this table
            table_mapping = None
            for mapping_entry in self.attributes_mapping:
                if table in mapping_entry:
                    table_mapping = mapping_entry[table]
                    break

            # Skip if primary key not mapped
            if self.primary_key not in table_mapping:
                continue

            source_pk_column = table_mapping[self.primary_key]

            try:
                table_df = spark.read.table(table)
                table_columns = table_df.columns

                if source_pk_column in table_columns:
                    self.logger.info(f"  [OK] Column exists: {table}.{source_pk_column}")
                else:
                    self.tables_missing_pk_column.append({
                        "table": table,
                        "expected_column": source_pk_column,
                        "available_columns": table_columns
                    })
                    self.logger.info(f"  [FAIL] Column NOT found: {table}.{source_pk_column}")
                    self.logger.info(f"    Available columns: {', '.join(table_columns[:5])}...")
            except Exception as e:
                self.logger.info(f"  [WARN] Could not read table: {table} - {str(e)}")

        if self.tables_missing_pk_column:
            self.validation_results["critical_issues"].append({
                "check": "Primary Key Column Existence",
                "issue": "Primary key columns not found in source tables",
                "details": self.tables_missing_pk_column
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] {len(self.tables_missing_pk_column)} table(s) missing primary key column")
        else:
            self.validation_results["checks_passed"].append("Primary Key Column Existence")
            self.logger.info(f"\n[PASSED] All primary key columns exist in source tables")

        return {
            "tables_missing_pk_column": self.tables_missing_pk_column,
            "passed": len(self.tables_missing_pk_column) == 0
        }

    @step(order=5, name="Validate Primary Key Nulls", returns="dict - validation status for PK NULL values")
    def step_validate_primary_key_nulls(self) -> Dict[str, Any]:
        """Validation 5: Check for NULL values in primary key columns."""
        spark = self.context.spark

        for table in self.dataset_tables:
            # Skip if table has issues from previous validations
            if table in self.missing_tables or table in self.tables_without_mapping:
                continue

            # Find the mapping for this table
            table_mapping = None
            for mapping_entry in self.attributes_mapping:
                if table in mapping_entry:
                    table_mapping = mapping_entry[table]
                    break

            # Skip if primary key not mapped
            if self.primary_key not in table_mapping:
                continue

            source_pk_column = table_mapping[self.primary_key]

            # Skip if column doesn't exist
            column_missing = any(item["table"] == table for item in self.tables_missing_pk_column)
            if column_missing:
                continue

            try:
                table_df = spark.read.table(table)
                total_count = table_df.count()
                null_count = table_df.filter(col(source_pk_column).isNull()).count()

                if null_count > 0:
                    self.tables_with_nulls.append({
                        "table": table,
                        "column": source_pk_column,
                        "total_records": total_count,
                        "null_count": null_count,
                        "null_percentage": round((null_count / total_count) * 100, 2)
                    })
                    self.logger.info(f"  [FAIL] NULLs found: {table}.{source_pk_column}")
                    self.logger.info(f"    Total records: {total_count}, NULL count: {null_count} ({round((null_count / total_count) * 100, 2)}%)")
                else:
                    self.logger.info(f"  [OK] No NULLs: {table}.{source_pk_column} ({total_count} records)")
            except Exception as e:
                self.logger.info(f"  [WARN] Could not check NULLs: {table}.{source_pk_column} - {str(e)}")

        if self.tables_with_nulls:
            self.validation_results["critical_issues"].append({
                "check": "Primary Key NULL Check",
                "issue": "NULL values found in primary key columns",
                "details": self.tables_with_nulls
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] {len(self.tables_with_nulls)} table(s) have NULL values in primary key")
        else:
            self.validation_results["checks_passed"].append("Primary Key NULL Check")
            self.logger.info(f"\n[PASSED] No NULL values in primary key columns")

        return {
            "tables_with_nulls": self.tables_with_nulls,
            "passed": len(self.tables_with_nulls) == 0
        }

    @step(order=6, name="Validate Primary Key Uniqueness", returns="dict - validation status for PK uniqueness")
    def step_validate_primary_key_uniqueness(self) -> Dict[str, Any]:
        """Validation 6: Check for duplicate values in primary key columns."""
        spark = self.context.spark

        for table in self.dataset_tables:
            # Skip if table has issues from previous validations
            if table in self.missing_tables or table in self.tables_without_mapping:
                continue

            # Find the mapping for this table
            table_mapping = None
            for mapping_entry in self.attributes_mapping:
                if table in mapping_entry:
                    table_mapping = mapping_entry[table]
                    break

            # Skip if primary key not mapped
            if self.primary_key not in table_mapping:
                continue

            source_pk_column = table_mapping[self.primary_key]

            # Skip if column doesn't exist
            column_missing = any(item["table"] == table for item in self.tables_missing_pk_column)
            if column_missing:
                continue

            try:
                table_df = spark.read.table(table)
                total_count = table_df.count()
                distinct_count = table_df.select(source_pk_column).distinct().count()
                duplicate_count = total_count - distinct_count

                if duplicate_count > 0:
                    self.tables_with_duplicates.append({
                        "table": table,
                        "column": source_pk_column,
                        "total_records": total_count,
                        "distinct_values": distinct_count,
                        "duplicate_count": duplicate_count
                    })
                    self.logger.info(f"  [FAIL] Duplicates found: {table}.{source_pk_column}")
                    self.logger.info(f"    Total: {total_count}, Distinct: {distinct_count}, Duplicates: {duplicate_count}")
                else:
                    self.logger.info(f"  [OK] All unique: {table}.{source_pk_column} ({total_count} records)")
            except Exception as e:
                self.logger.info(f"  [WARN] Could not check uniqueness: {table}.{source_pk_column} - {str(e)}")

        if self.tables_with_duplicates:
            self.validation_results["critical_issues"].append({
                "check": "Primary Key Uniqueness Check",
                "issue": "Duplicate values found in primary key columns",
                "details": self.tables_with_duplicates
            })
            self.validation_results["validation_passed"] = False
            self.logger.info(f"\n[CRITICAL] {len(self.tables_with_duplicates)} table(s) have duplicate primary keys")
        else:
            self.validation_results["checks_passed"].append("Primary Key Uniqueness Check")
            self.logger.info(f"\n[PASSED] All primary key values are unique")

        return {
            "tables_with_duplicates": self.tables_with_duplicates,
            "passed": len(self.tables_with_duplicates) == 0
        }

    @step(order=7, name="Validate Mapped Column Existence", returns="dict - validation status for mapped columns")
    def step_validate_mapped_column_existence(self) -> Dict[str, Any]:
        """Validation 7: Check if all mapped columns exist in source tables."""
        spark = self.context.spark

        for table in self.dataset_tables:
            # Skip if table doesn't exist or has no mapping
            if table in self.missing_tables or table in self.tables_without_mapping:
                continue

            # Find the mapping for this table
            table_mapping = None
            for mapping_entry in self.attributes_mapping:
                if table in mapping_entry:
                    table_mapping = mapping_entry[table]
                    break

            try:
                table_df = spark.read.table(table)
                table_columns = table_df.columns

                self.logger.info(f"\n  Table: {table}")

                # Check each mapped column
                for entity_attr, dataset_attr in table_mapping.items():
                    if dataset_attr in table_columns:
                        self.logger.info(f"    [OK] {dataset_attr} -> {entity_attr}")

                        # Check for special characters
                        special_chars = [char for char in dataset_attr if not (char.isalnum() or char == '_')]
                        if special_chars:
                            self.special_char_columns.append({
                                "table": table,
                                "column": dataset_attr,
                                "special_chars": list(set(special_chars))
                            })
                            self.logger.info(f"      [WARN] Contains special characters: {list(set(special_chars))}")
                    else:
                        self.missing_mapped_columns.append({
                            "table": table,
                            "entity_attr": entity_attr,
                            "dataset_attr": dataset_attr,
                            "available_columns": table_columns
                        })
                        self.logger.info(f"    [FAIL] {dataset_attr} -> {entity_attr} (column not found)")
            except Exception as e:
                self.logger.info(f"  [WARN] Could not read table: {table} - {str(e)}")

        if self.missing_mapped_columns:
            self.validation_results["warnings"].append({
                "check": "Mapped Column Existence",
                "issue": "Mapped columns not found in source tables",
                "details": self.missing_mapped_columns
            })
            self.logger.info(f"\n[WARNING] {len(self.missing_mapped_columns)} mapped column(s) not found in source tables")
            self.logger.info("   Pipeline will continue but these attributes will be NULL")
        else:
            self.validation_results["checks_passed"].append("Mapped Column Existence")
            self.logger.info(f"\n[PASSED] All mapped columns exist in source tables")

        if self.special_char_columns:
            self.validation_results["warnings"].append({
                "check": "Special Characters in Column Names",
                "issue": "Columns contain special characters",
                "details": self.special_char_columns
            })
            self.logger.info(f"\n[WARNING] {len(self.special_char_columns)} column(s) contain special characters")
            self.logger.info("   This may cause issues in some SQL contexts")

        return {
            "missing_mapped_columns": self.missing_mapped_columns,
            "special_char_columns": self.special_char_columns,
            "passed": len(self.missing_mapped_columns) == 0
        }

    def execute(self) -> TaskResult:
        """Execute all validation checks."""
        # Run all validations via step methods
        self.step_validate_source_table_existence()
        self.step_validate_attribute_mapping_completeness()
        self.step_validate_primary_key_mapping_existence()
        self.step_validate_primary_key_column_existence()
        self.step_validate_primary_key_nulls()
        self.step_validate_primary_key_uniqueness()
        self.step_validate_mapped_column_existence()

        # Print validation summary (matches production behavior - print BEFORE raising exception)
        self._print_validation_summary()

        # Build result
        if self.validation_results["validation_passed"]:
            return TaskResult.success(
                message="Validation passed - pipeline can proceed",
                task_name=self.context.task_name,
                metrics={
                    'checks_passed': len(self.validation_results["checks_passed"]),
                    'warnings': len(self.validation_results["warnings"]),
                    'critical_issues': 0,
                    'validation_passed': True
                },
                task_values={
                    'validation_passed': True,
                    'validation_results': json.dumps(self.validation_results)
                }
            )
        else:
            # Print exit message with details (matches production)
            self.logger.info("\n" + "="*60)
            self.logger.info("EXITING PIPELINE DUE TO CRITICAL ISSUES")
            self.logger.info("="*60)
            self.logger.info("\nPlease fix the following issues:")
            for issue in self.validation_results["critical_issues"]:
                self.logger.info(f"\n[FAIL] {issue['check']}")
                self.logger.info(f"   {issue['issue']}")
                if isinstance(issue['details'], list) and len(issue['details']) <= 5:
                    for detail in issue['details']:
                        self.logger.info(f"   - {detail}")

            # Build error summary and raise
            error_summary = {
                "status": "failed",
                "message": "Validation failed - critical issues found",
                "critical_issues_count": len(self.validation_results["critical_issues"]),
                "issues": [issue["check"] for issue in self.validation_results["critical_issues"]]
            }
            raise ValueError(
                f"Pipeline validation failed with {len(self.validation_results['critical_issues'])} critical issue(s): {json.dumps(error_summary, indent=2)}"
            )

    def _print_validation_summary(self) -> None:
        """Print validation summary (called before success/failure decision)."""
        self.logger.info("\n" + "="*60)
        self.logger.info("VALIDATION SUMMARY")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Timestamp: {self.validation_results['timestamp']}")
        self.logger.info(f"Total Tables: {len(self.dataset_tables)}")

        self.logger.info("\n" + "-"*60)
        self.logger.info("CHECKS PASSED:")
        self.logger.info("-"*60)
        for check in self.validation_results["checks_passed"]:
            self.logger.info(f"  [PASSED] {check}")

        if self.validation_results["warnings"]:
            self.logger.info("\n" + "-"*60)
            self.logger.info("WARNINGS:")
            self.logger.info("-"*60)
            for warning in self.validation_results["warnings"]:
                self.logger.info(f"  [WARN] {warning['check']}: {warning['issue']}")
                if isinstance(warning['details'], list):
                    self.logger.info(f"     Count: {len(warning['details'])}")

        if self.validation_results["critical_issues"]:
            self.logger.info("\n" + "-"*60)
            self.logger.info("CRITICAL ISSUES:")
            self.logger.info("-"*60)
            for issue in self.validation_results["critical_issues"]:
                self.logger.info(f"  [FAIL] {issue['check']}: {issue['issue']}")
                if isinstance(issue['details'], list):
                    self.logger.info(f"     Count: {len(issue['details'])}")
                    for item in issue['details'][:3]:
                        if isinstance(item, dict):
                            self.logger.info(f"     - {item}")
                        else:
                            self.logger.info(f"     - {item}")

        self.logger.info("\n" + "="*60)
        if self.validation_results["validation_passed"]:
            self.logger.info("[SUCCESS] VALIDATION PASSED - PIPELINE CAN PROCEED")
        else:
            self.logger.info("[FAILED] VALIDATION FAILED - PIPELINE CANNOT PROCEED")
        self.logger.info("="*60)

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Entity configuration validation completed",
            actual={
                'checks_passed': self.validation_results["checks_passed"],
                'warnings': len(self.validation_results["warnings"])
            }
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*60)
        self.logger.info("VALIDATION SUMMARY")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Timestamp: {self.validation_results['timestamp']}")
        self.logger.info(f"Total Tables: {len(self.dataset_tables)}")

        self.logger.info("\n" + "-"*60)
        self.logger.info("CHECKS PASSED:")
        self.logger.info("-"*60)
        for check in self.validation_results["checks_passed"]:
            self.logger.info(f"  [PASSED] {check}")

        if self.validation_results["warnings"]:
            self.logger.info("\n" + "-"*60)
            self.logger.info("WARNINGS:")
            self.logger.info("-"*60)
            for warning in self.validation_results["warnings"]:
                self.logger.info(f"  [WARN] {warning['check']}: {warning['issue']}")
                if isinstance(warning['details'], list):
                    self.logger.info(f"     Count: {len(warning['details'])}")

        if self.validation_results["critical_issues"]:
            self.logger.info("\n" + "-"*60)
            self.logger.info("CRITICAL ISSUES:")
            self.logger.info("-"*60)
            for issue in self.validation_results["critical_issues"]:
                self.logger.info(f"  [FAIL] {issue['check']}: {issue['issue']}")
                if isinstance(issue['details'], list):
                    self.logger.info(f"     Count: {len(issue['details'])}")
                    for item in issue['details'][:3]:
                        if isinstance(item, dict):
                            self.logger.info(f"     - {item}")
                        else:
                            self.logger.info(f"     - {item}")

        self.logger.info("\n" + "="*60)
        if self.validation_results["validation_passed"]:
            self.logger.info("[SUCCESS] VALIDATION PASSED - PIPELINE CAN PROCEED")
        else:
            self.logger.info("[FAILED] VALIDATION FAILED - PIPELINE CANNOT PROCEED")
        self.logger.info("="*60)

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            self.context.dbutils.jobs.taskValues.set('validation_passed', True)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info("\n" + "="*60)
        self.logger.info("EXITING PIPELINE DUE TO CRITICAL ISSUES")
        self.logger.info("="*60)
        self.logger.info("\nPlease fix the following issues:")
        for issue in self.validation_results["critical_issues"]:
            self.logger.info(f"\n[FAIL] {issue['check']}")
            self.logger.info(f"   {issue['issue']}")
            if isinstance(issue['details'], list) and len(issue['details']) <= 5:
                for detail in issue['details']:
                    self.logger.info(f"   - {detail}")
