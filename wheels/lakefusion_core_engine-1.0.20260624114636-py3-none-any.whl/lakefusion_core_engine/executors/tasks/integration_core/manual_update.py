"""
Manual Update Executor for integration core.

Manually updates attributes on a master record, updates attribute version
sources, logs merge activities, and clears stale search results.

Workflow:
1. Get current master record
2. Get current attribute source mapping
3. Update master table with new attribute values
4. Build and insert new attribute source mapping
5. Insert merge activity record
6. Clear stale search results in unified table
"""

import json
from typing import Any, Dict, List, Optional

from pyspark.sql.functions import current_timestamp

from ...base import BaseTask
from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ManualUpdateExecutor(BaseStepTask):
    """
    Executor for manual entity profile updates.

    Allows direct updates to master record attributes with proper
    tracking in attribute version sources and merge activities.
    """

    MANUAL_UPDATE_SOURCE = "MANUAL_UPDATE"

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.lakefusion_id = context.params.get('lakefusion_id', '')
        self.update_attributes = context.params.get('update_attributes', {})
        self.new_version = 0
        self.affected_unified_count = 0
        # Instance variables for intermediate results
        self.current_master = None
        self.current_attr_values = {}
        self.existing_attrs_dict = {}
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    @property
    def entity_name(self) -> str:
        """Get entity name from context."""
        return self.context.entity

    @property
    def entity_attributes(self) -> List[str]:
        """Get entity attributes list from params."""
        attrs = self.context.params.get('entity_attributes', [])
        if isinstance(attrs, str):
            return json.loads(attrs)
        return attrs

    @property
    def master_table(self) -> str:
        """Get the master table name (prod suffix)."""
        return f"{self.context.catalog_name}.gold.{self.entity_name}_master_prod"

    @property
    def merge_activities_table(self) -> str:
        """Get the merge activities table name."""
        return f"{self.master_table}_merge_activities"

    @property
    def attr_version_sources_table(self) -> str:
        """Get the attribute version sources table name."""
        return f"{self.master_table}_attribute_version_sources"

    @property
    def unified_table(self) -> str:
        """Get the unified table name (prod suffix)."""
        return f"{self.context.catalog_name}.silver.{self.entity_name}_unified_prod"

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*80)
        self.logger.info("MANUAL UPDATE ENTITY PROFILE")
        self.logger.info("="*80)
        self.logger.info(f"Entity: {self.entity_name}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"LakeFusion ID: {self.lakefusion_id}")
        self.logger.info(f"Attributes to update: {list(self.update_attributes.keys())}")
        self.logger.info(f"Entity attributes: {self.entity_attributes}")
        self.logger.info(f"Master Table: {self.master_table}")
        self.logger.info(f"Merge Activities Table: {self.merge_activities_table}")
        self.logger.info(f"Attribute Version Sources Table: {self.attr_version_sources_table}")
        self.logger.info(f"Unified Table: {self.unified_table}")

    @step(order=1, name="Get Current Master Record", returns="current_master and current_attr_values")
    def step_get_current_master_record(self) -> Dict[str, Any]:
        """Get the current master record for the given lakefusion_id."""
        spark = self.context.spark

        current_master_df = spark.sql(f"""
            SELECT *
            FROM {self.master_table}
            WHERE lakefusion_id = '{self.lakefusion_id}'
        """)

        if current_master_df.count() == 0:
            raise ValueError(f"Master record not found for lakefusion_id: {self.lakefusion_id}")

        self.current_master = current_master_df.collect()[0]
        self.logger.info(f"  Found master record for lakefusion_id: {self.lakefusion_id}")

        # Store current attribute values for comparison
        self.current_attr_values = {
            attr: self.current_master[attr]
            for attr in self.entity_attributes
            if attr in self.current_master.asDict()
        }

        self.logger.info(f"\nCurrent attribute values:")
        for attr, val in self.current_attr_values.items():
            if attr in self.update_attributes:
                self.logger.info(f"  - {attr}: '{val}' -> '{self.update_attributes[attr]}' (UPDATING)")
            else:
                self.logger.info(f"  - {attr}: '{val}'")

        return {
            'lakefusion_id': self.lakefusion_id,
            'current_attr_values': self.current_attr_values
        }

    @step(order=2, name="Get Current Attribute Source Mapping", returns="existing_attrs_dict")
    def step_get_current_attribute_source_mapping(self) -> Dict[str, Any]:
        """Get the current attribute source mapping for the record."""
        spark = self.context.spark

        current_mapping_df = spark.sql(f"""
            SELECT attribute_source_mapping, version
            FROM {self.attr_version_sources_table}
            WHERE lakefusion_id = '{self.lakefusion_id}'
            ORDER BY version DESC
            LIMIT 1
        """)

        self.existing_attrs_dict = {}
        if current_mapping_df.count() > 0:
            mapping_row = current_mapping_df.collect()[0]
            current_mapping = mapping_row['attribute_source_mapping']

            if current_mapping:
                if isinstance(current_mapping, str):
                    existing_attrs = json.loads(current_mapping)
                elif isinstance(current_mapping, list):
                    existing_attrs = []
                    for item in current_mapping:
                        if hasattr(item, 'asDict'):
                            existing_attrs.append(item.asDict())
                        elif isinstance(item, dict):
                            existing_attrs.append(item)
                        else:
                            existing_attrs.append(dict(item) if item else {})
                else:
                    existing_attrs = []

                self.existing_attrs_dict = {
                    attr['attribute_name']: attr
                    for attr in existing_attrs
                    if attr and 'attribute_name' in attr
                }
                self.logger.info(f"  Found existing attribute source mapping")
                self.logger.info(f"  Attributes tracked: {list(self.existing_attrs_dict.keys())}")
        else:
            self.logger.info("  No existing attribute source mapping found")
            self.logger.info("  Will create initial mapping from current master values")
            for attr in self.entity_attributes:
                if attr in self.current_attr_values and self.current_attr_values[attr] is not None:
                    self.existing_attrs_dict[attr] = {
                        "attribute_name": attr,
                        "attribute_value": str(self.current_attr_values[attr]),
                        "source": "INITIAL_LOAD"
                    }

        return {
            'existing_attrs_dict': self.existing_attrs_dict
        }

    @step(order=3, name="Update Master Table", returns="new_version")
    def step_update_master_table(self) -> Dict[str, Any]:
        """Update the master table with new attribute values."""
        spark = self.context.spark

        set_clauses = []
        for attr_name, attr_value in self.update_attributes.items():
            if attr_value is None:
                set_clauses.append(f"{attr_name} = NULL")
            else:
                escaped_value = str(attr_value).replace("'", "''")
                set_clauses.append(f"{attr_name} = '{escaped_value}'")

        if set_clauses:
            set_clause = ", ".join(set_clauses)

            update_master_query = f"""
                UPDATE {self.master_table}
                SET {set_clause}
                WHERE lakefusion_id = '{self.lakefusion_id}'
            """

            self.logger.info(f"Executing update query...")
            spark.sql(update_master_query)
            self.logger.info(f"  Master table updated successfully")

            # Update attributes_combined
            updated_record = spark.sql(f"""
                SELECT * FROM {self.master_table} WHERE lakefusion_id = '{self.lakefusion_id}'
            """).collect()

            if updated_record:
                attr_values = []
                for attr in self.entity_attributes:
                    if attr in updated_record[0].asDict():
                        val = updated_record[0][attr]
                        attr_values.append(str(val) if val is not None else '')

                attributes_combined = " | ".join(attr_values)
                attributes_combined_escaped = attributes_combined.replace("'", "''")

                spark.sql(f"""
                    UPDATE {self.master_table}
                    SET attributes_combined = '{attributes_combined_escaped}'
                    WHERE lakefusion_id = '{self.lakefusion_id}'
                """)
                self.logger.info(f"  attributes_combined updated")

        # Get new version
        version_df = spark.sql(f"""
            SELECT COALESCE(MAX(version), 0) + 1 as new_version
            FROM {self.attr_version_sources_table}
            WHERE lakefusion_id = '{self.lakefusion_id}'
        """)
        self.new_version = version_df.collect()[0]['new_version']
        self.logger.info(f"\n  New version: {self.new_version}")

        return {
            'new_version': self.new_version
        }

    @step(order=4, name="Build and Insert Attribute Source Mapping", returns="updated_attrs list")
    def step_build_and_insert_attribute_source_mapping(self) -> Dict[str, Any]:
        """Build and insert new attribute source mapping."""
        spark = self.context.spark

        new_attribute_mapping = []
        updated_attrs = []

        for attr_name in self.entity_attributes:
            if attr_name in self.update_attributes:
                new_value = self.update_attributes[attr_name]
                new_attribute_mapping.append({
                    "attribute_name": attr_name,
                    "attribute_value": str(new_value) if new_value is not None else None,
                    "source": self.MANUAL_UPDATE_SOURCE
                })
                updated_attrs.append(attr_name)
                self.logger.info(f"    {attr_name}: Updated to '{new_value}' (source: {self.MANUAL_UPDATE_SOURCE})")
            elif attr_name in self.existing_attrs_dict:
                new_attribute_mapping.append(self.existing_attrs_dict[attr_name])
                self.logger.info(f"  - {attr_name}: Unchanged (source: {self.existing_attrs_dict[attr_name].get('source', 'unknown')})")
            elif attr_name in self.current_attr_values and self.current_attr_values[attr_name] is not None:
                new_attribute_mapping.append({
                    "attribute_name": attr_name,
                    "attribute_value": str(self.current_attr_values[attr_name]),
                    "source": "INITIAL_LOAD"
                })
                self.logger.info(f"  + {attr_name}: Added from master (source: INITIAL_LOAD)")

        # Build SQL array of structs
        mapping_sql = self._build_sql_array_of_structs(new_attribute_mapping)

        insert_attr_version_query = f"""
            INSERT INTO {self.attr_version_sources_table}
            (lakefusion_id, version, attribute_source_mapping)
            VALUES (
                '{self.lakefusion_id}',
                {self.new_version},
                {mapping_sql}
            )
        """

        spark.sql(insert_attr_version_query)
        self.logger.info(f"\n  Attribute version sources updated")
        self.logger.info(f"  - version: {self.new_version}")
        self.logger.info(f"  - Updated attributes: {updated_attrs}")

        return {
            'updated_attrs': updated_attrs
        }

    @step(order=5, name="Insert Merge Activities", returns="merge activity record info")
    def step_insert_merge_activities(self) -> Dict[str, Any]:
        """Insert a merge activity record for the manual update."""
        spark = self.context.spark

        insert_merge_activities_query = f"""
            INSERT INTO {self.merge_activities_table}
            (master_id, match_id, source, version, action_type, created_at)
            VALUES (
                '{self.lakefusion_id}',
                NULL,
                '{self.MANUAL_UPDATE_SOURCE}',
                {self.new_version},
                'MANUAL_UPDATE',
                current_timestamp()
            )
        """

        spark.sql(insert_merge_activities_query)
        self.logger.info(f"  Merge activities updated")
        self.logger.info(f"  - master_id: {self.lakefusion_id}")
        self.logger.info(f"  - action_type: MANUAL_UPDATE")
        self.logger.info(f"  - version: {self.new_version}")

        return {
            'master_id': self.lakefusion_id,
            'action_type': 'MANUAL_UPDATE',
            'version': self.new_version
        }

    @step(order=6, name="Clear Stale Search Results", returns="affected_unified_count")
    def step_clear_stale_search_results(self) -> Dict[str, Any]:
        """Clear stale search results in the unified table."""
        spark = self.context.spark

        affected_records_query = f"""
            SELECT surrogate_key, source_path, source_id, scoring_results
            FROM {self.unified_table}
            WHERE record_status = 'ACTIVE'
              AND scoring_results IS NOT NULL
              AND scoring_results != ''
              AND scoring_results != '[]'
              AND scoring_results LIKE '%{self.lakefusion_id}%'
        """

        affected_df = spark.sql(affected_records_query)
        self.affected_unified_count = affected_df.count()

        self.logger.info(f"  Found {self.affected_unified_count} ACTIVE records with lakefusion_id in scoring_results")

        if self.affected_unified_count > 0:
            clear_results_query = f"""
                UPDATE {self.unified_table}
                SET search_results = NULL,
                    scoring_results = NULL
                WHERE record_status = 'ACTIVE'
                  AND scoring_results IS NOT NULL
                  AND scoring_results != ''
                  AND scoring_results != '[]'
                  AND scoring_results LIKE '%{self.lakefusion_id}%'
            """

            spark.sql(clear_results_query)
            self.logger.info(f"  Cleared search_results and scoring_results for {self.affected_unified_count} ACTIVE records")
            self.logger.info("  These records will be re-evaluated in the next entity matching run")
        else:
            self.logger.info("  No ACTIVE records found with this lakefusion_id in scoring_results")

        return {
            'affected_unified_count': self.affected_unified_count
        }

    def execute(self) -> TaskResult:
        """Execute the manual update workflow."""
        # Step 1: Get current master record
        self.step_get_current_master_record()

        # Step 2: Get current attribute source mapping
        self.step_get_current_attribute_source_mapping()

        # Step 3: Update master table
        self.step_update_master_table()

        # Step 4: Build and insert attribute source mapping
        self.step_build_and_insert_attribute_source_mapping()

        # Step 5: Insert merge activities
        self.step_insert_merge_activities()

        # Step 6: Clear stale search results
        self.step_clear_stale_search_results()

        return TaskResult.success(
            message=f"Manual update completed for {self.lakefusion_id}",
            task_name=self.context.task_name,
            metrics={
                'lakefusion_id': self.lakefusion_id,
                'attributes_updated': list(self.update_attributes.keys()),
                'new_version': self.new_version,
                'unified_records_cleared': self.affected_unified_count
            },
            task_values={
                'manual_update_complete': True,
                'lakefusion_id': self.lakefusion_id,
                'new_version': self.new_version
            }
        )

    def _build_sql_array_of_structs(self, mapping_list: List[Dict]) -> str:
        """Convert list of dicts to SQL array of named_struct."""
        if not mapping_list:
            return "array()"

        struct_parts = []
        for item in mapping_list:
            attr_name = str(item.get('attribute_name', '')).replace("'", "''")
            attr_value = item.get('attribute_value')
            if attr_value is None:
                attr_value_sql = "NULL"
            else:
                attr_value_sql = "'" + str(attr_value).replace("'", "''") + "'"
            source = str(item.get('source', '')).replace("'", "''")

            struct_parts.append(
                f"named_struct('attribute_name', '{attr_name}', 'attribute_value', {attr_value_sql}, 'source', '{source}')"
            )

        return f"array({', '.join(struct_parts)})"

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Manual update completed",
            actual=self.lakefusion_id
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*80)
        self.logger.info("MANUAL UPDATE COMPLETED SUCCESSFULLY")
        self.logger.info("="*80)

        if result.is_success:
            self.logger.info(f"""
Summary:
--------
Entity: {self.entity_name}
LakeFusion ID: {self.lakefusion_id}

Updates performed:
1.   Master table
   - Updated attributes: {list(self.update_attributes.keys())}

2.   Attribute version sources
   - New version {self.new_version} created
   - Only updated attributes marked with source='{self.MANUAL_UPDATE_SOURCE}'
   - Other attributes retain their original sources

3.   Merge activities
   - MANUAL_UPDATE action recorded at version {self.new_version}

4.   Unified table
   - Cleared stale search/scoring results for {self.affected_unified_count} ACTIVE records
   - These records will be re-matched in the next entity matching run
""")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Manual update failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.error(f"  Error: {error}")
