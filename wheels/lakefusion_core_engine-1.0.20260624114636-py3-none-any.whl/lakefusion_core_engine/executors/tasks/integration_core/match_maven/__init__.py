"""
Match Maven experiment tasks module.

Contains task executors for Match Maven experiment pipeline operations.
Match Maven allows testing deduplication configurations with limited record
sets before running full production pipelines.

Key Features:
    - Supports both single-source (golden dedup) and multi-source (normal dedup) modes
    - Creates experiment-specific tables with _{experiment_id} suffix
    - Processes limited record ranges for quick testing
    - No threshold-based classification (raw scores for analysis)

Available Tasks:
    - CreateTablesExperimentExecutor: Create experiment tables (master, unified, unified_dedup)
    - LoadExperimentDataExecutor: Load data with record range limits
    - VectorSearchExperimentExecutor: Vector search for experiment records
    - LLMMatchingExperimentExecutor: LLM matching without threshold classification
    - ProcessPotentialMatchExperimentExecutor: Create potential match table for analysis

Usage:
------
    from lakefusion_core_engine.executors.tasks.integration_core.match_maven import (
        CreateTablesExperimentExecutor,
        LoadExperimentDataExecutor,
        VectorSearchExperimentExecutor
    )
"""

from .create_tables_experiment import CreateTablesExperimentExecutor
from .load_experiment_data import LoadExperimentDataExecutor
from .entity_matching_vector_search_experiment import VectorSearchExperimentExecutor
from .entity_matching_llm_experiment import LLMMatchingExperimentExecutor
from .process_potential_match_experiment import ProcessPotentialMatchExperimentExecutor
from .process_deterministic_experiment import ProcessDeterministicExecutor
from .process_deterministic_potential_match_experiment import ProcessDeterministicPotentialMatchExperimentExecutor


__all__ = [
    'CreateTablesExperimentExecutor',
    'LoadExperimentDataExecutor',
    'VectorSearchExperimentExecutor',
    'LLMMatchingExperimentExecutor',
    'ProcessPotentialMatchExperimentExecutor',
    'ProcessDeterministicExecutor',
    'ProcessDeterministicPotentialMatchExperimentExecutor'

]
