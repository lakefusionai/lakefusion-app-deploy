"""
Create Tables Experiment Executor.

Creates experiment tables for Match Maven testing with experiment ID suffix.
Supports both single-source (golden dedup) and multi-source (normal dedup) modes.

Key Features:
    - Creates master table with entity attributes and attributes_combined column
    - For multi-source: Creates unified table with surrogate_key, record_status
    - For single-source: Creates unified_deduplicate table mirroring master
    - All tables have CDF enabled for change tracking
    - Tables use _{experiment_id} suffix for isolation
"""

import json
from typing import Any, Dict, Optional, List

from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, LongType,
    DoubleType, FloatType, BooleanType, DateType, TimestampType, DecimalType
)

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class CreateTablesExperimentExecutor(BaseStepTask):
    """
    Executor for creating experiment tables in Match Maven pipeline.

    Creates empty Delta tables with proper schemas for experiment testing.
    Tables are isolated with _{experiment_id} suffix to avoid conflicts.

    Workflow:
        1. Parse entity attributes and data types
        2. Build table names with experiment suffix
        3. Create master table with entity schema
        4. For multi-source: Create unified table
        5. For single-source: Create unified_deduplicate table
        6. Verify table creation
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the create tables experiment task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._tables_created: List[str] = []

        # Step intermediate results
        self._id_key: str = 'lakefusion_id'
        self._primary_key: Optional[str] = None
        self._entity_attributes: List[str] = []
        self._entity_attributes_datatype: Dict[str, str] = {}
        self._is_single_source: bool = False
        self._master_table: Optional[str] = None
        self._unified_table: Optional[str] = None
        self._unified_dedup_table: Optional[str] = None
        self._potential_match_table: Optional[str] = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """PRE phase: Validate inputs and setup configuration."""
        self.print_header("CREATE TABLES - MATCH MAVEN EXPERIMENT")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id}")

        params = self.context.params
        self._id_key = params.get('id_key', 'lakefusion_id')
        self._primary_key = params.get('primary_key')
        self._entity_attributes = params.get('entity_attributes', [])
        self._entity_attributes_datatype = params.get('entity_attributes_datatype', {})
        self._is_single_source = params.get('is_single_source', False)

        # Parse JSON strings if needed
        if isinstance(self._entity_attributes, str):
            self._entity_attributes = json.loads(self._entity_attributes)
        if isinstance(self._entity_attributes_datatype, str):
            self._entity_attributes_datatype = json.loads(self._entity_attributes_datatype)
        if isinstance(self._is_single_source, str):
            self._is_single_source = self._is_single_source.lower() == "true"

        self.logger.info(f"ID Key: {self._id_key}")
        self.logger.info(f"Primary Key: {self._primary_key}")
        self.logger.info(f"Is Single Source: {self._is_single_source}")
        self.logger.info(f"Attributes: {len(self._entity_attributes)}")

        # Build table names
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._master_table = f"{self.context.catalog_name}.gold.{self.context.entity}_master{experiment_suffix}"
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"
        self._unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate{experiment_suffix}"
        self._potential_match_table = f"{self._master_table}_potential_match"

        self.logger.info(f"\nTable Names:")
        self.logger.info(f"  Master: {self._master_table}")
        self.logger.info(f"  Unified: {self._unified_table}")
        if self._is_single_source:
            self.logger.info(f"  Unified Dedup: {self._unified_dedup_table}")

    @step(order=1, name="Create Master Table", returns="None - creates master Delta table")
    def step_create_master_table(self) -> Dict[str, Any]:
        """Step 1: Create master table with entity schema."""
        # Drop existing table
        self.spark.sql(f"DROP TABLE IF EXISTS {self._master_table}")
        self.logger.info(f"  Dropped existing table (if any)")

        # Create schema
        master_fields = self._create_schema_fields(include_lakefusion_id=True)
        master_fields.append(StructField("attributes_combined", StringType(), True))
        master_schema = StructType(master_fields)

        # Create empty DataFrame
        master_df = self.spark.createDataFrame([], master_schema)

        # Write as Delta table
        master_df.write \
            .format("delta") \
            .option("delta.enableChangeDataFeed", "true") \
            .mode("overwrite") \
            .saveAsTable(self._master_table)

        self._tables_created.append(self._master_table)
        self._stats['master_attributes'] = len(self._entity_attributes)
        self.logger.info(f"  Created {self._master_table}")
        self.logger.info(f"  Attributes: {len(self._entity_attributes)}")
        self.logger.info(f"  CDF: Enabled")

        return {'table': self._master_table, 'attributes': len(self._entity_attributes)}

    @step(order=2, name="Create Source Table", returns="None - creates unified or unified_dedup table")
    def step_create_source_table(self) -> Dict[str, Any]:
        """Step 2: Create unified or unified_dedup table based on mode."""
        if self._is_single_source:
            return self._create_unified_dedup_table()
        else:
            return self._create_unified_table()

    @step(order=3, name="Verify Tables", returns="Verification status")
    def step_verify_tables(self) -> Dict[str, Any]:
        """Step 3: Verify all tables were created."""
        all_created = True
        verification_results = []

        for table in self._tables_created:
            exists = self.spark.catalog.tableExists(table)
            status = "OK" if exists else "FAILED"
            self.logger.info(f"  [{status}] {table}")
            verification_results.append({'table': table, 'exists': exists})
            if not exists:
                all_created = False

        if not all_created:
            raise Exception("Not all tables were created successfully")

        self._stats['tables_created'] = len(self._tables_created)
        self.logger.info(f"\n  All {len(self._tables_created)} tables created successfully")
        self.logger.info(f"  Mode: {'Single-Source (Golden Dedup)' if self._is_single_source else 'Multi-Source'}")

        return {'all_created': all_created, 'tables': verification_results}

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Create experiment tables.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Create master table
            self.step_create_master_table()

            # Step 2: Create unified or unified_dedup table based on mode
            self.step_create_source_table()

            # Step 3: Verify tables
            self.step_verify_tables()

            return TaskResult.success(
                message=f"Created {len(self._tables_created)} experiment tables",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'tables_created': True,
                    'master_table': self._master_table,
                    'unified_table': self._unified_table if not self._is_single_source else "",
                    'unified_dedup_table': self._unified_dedup_table if self._is_single_source else "",
                    'potential_match_table': self._potential_match_table
                },
                artifacts={
                    'tables': self._tables_created
                }
            )

        except Exception as e:
            raise RuntimeError(f"Failed to create experiment tables: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate table creation."""
        if result.is_failed:
            return result

        try:
            all_exist = all(
                self.spark.catalog.tableExists(table)
                for table in self._tables_created
            )

            validation = ValidationResult(
                passed=all_exist,
                message=f"All {len(self._tables_created)} tables verified",
                expected=len(self._tables_created),
                actual=len(self._tables_created) if all_exist else 0
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("tables_created", True)
                self.dbutils.jobs.taskValues.set("master_table", self._master_table)
                self.dbutils.jobs.taskValues.set("unified_table",
                    self._unified_table if not self._is_single_source else "")
                self.dbutils.jobs.taskValues.set("unified_dedup_table",
                    self._unified_dedup_table if self._is_single_source else "")
                self.dbutils.jobs.taskValues.set("potential_match_table", self._potential_match_table)
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _get_spark_data_type(self, dtype_str: str):
        """Convert string data type to Spark DataType."""
        dtype_map = {
            'bigint': LongType(),
            'boolean': BooleanType(),
            'char': StringType(),
            'varchar': StringType(),
            'date': DateType(),
            'double precision': DoubleType(),
            'integer': IntegerType(),
            'numeric': FloatType(),
            'real': FloatType(),
            'smallint': IntegerType(),
            'text': StringType(),
            'timestamp': TimestampType(),
            'string': StringType(),
            'int': IntegerType(),
            'long': LongType(),
            'double': DoubleType(),
            'float': FloatType(),
            'decimal': DecimalType(10, 2),
        }
        return dtype_map.get(dtype_str.lower(), StringType())

    def _create_schema_fields(self, include_lakefusion_id: bool = True) -> List[StructField]:
        """Create StructFields for a schema."""
        fields = []

        if include_lakefusion_id:
            fields.append(StructField(self._id_key, StringType(), True))

        for attr_name in self._entity_attributes:
            if attr_name == self._id_key:
                continue
            dtype_str = self._entity_attributes_datatype.get(attr_name, 'string')
            spark_dtype = self._get_spark_data_type(dtype_str)
            fields.append(StructField(attr_name, spark_dtype, True))

        return fields

    def _create_unified_table(self) -> Dict[str, Any]:
        """Create unified table for multi-source mode."""
        self.logger.info("\n  Creating UNIFIED TABLE (Multi-Source)")

        # Drop existing table
        self.spark.sql(f"DROP TABLE IF EXISTS {self._unified_table}")
        self.logger.info(f"  Dropped existing table (if any)")

        # Create schema - simplified for experiments (no master_lakefusion_id)
        unified_fields = [
            StructField("surrogate_key", StringType(), True),
            StructField("source_path", StringType(), True),
            StructField("source_id", StringType(), True),
            StructField("record_status", StringType(), True)
        ]

        # Add entity attributes (no lakefusion_id)
        for attr_name in self._entity_attributes:
            if attr_name == self._id_key:
                continue
            dtype_str = self._entity_attributes_datatype.get(attr_name, 'string')
            spark_dtype = self._get_spark_data_type(dtype_str)
            unified_fields.append(StructField(attr_name, spark_dtype, True))

        # Add system columns
        unified_fields.extend([
            StructField("attributes_combined", StringType(), True),
            StructField("search_results", StringType(), True),
            StructField("scoring_results", StringType(), True)
        ])

        unified_schema = StructType(unified_fields)

        # Create empty DataFrame
        unified_df = self.spark.createDataFrame([], unified_schema)

        # Write as Delta table
        unified_df.write \
            .format("delta") \
            .option("delta.enableChangeDataFeed", "true") \
            .mode("overwrite") \
            .saveAsTable(self._unified_table)

        self._tables_created.append(self._unified_table)
        self.logger.info(f"  Created {self._unified_table}")
        self.logger.info(f"  SIMPLIFIED: No master_lakefusion_id column (experiment mode)")
        self.logger.info(f"  CDF: Enabled")

        return {'table': self._unified_table, 'mode': 'multi-source'}

    def _create_unified_dedup_table(self) -> Dict[str, Any]:
        """Create unified_deduplicate table for single-source mode."""
        self.logger.info("\n  Creating UNIFIED DEDUP TABLE (Single-Source)")

        # Drop existing table
        self.spark.sql(f"DROP TABLE IF EXISTS {self._unified_dedup_table}")
        self.logger.info(f"  Dropped existing table (if any)")

        # Create schema - matches master but with search/scoring results
        unified_dedup_fields = self._create_schema_fields(include_lakefusion_id=True)
        unified_dedup_fields.extend([
            StructField("attributes_combined", StringType(), True),
            StructField("search_results", StringType(), True),
            StructField("scoring_results", StringType(), True)
        ])

        unified_dedup_schema = StructType(unified_dedup_fields)

        # Create empty DataFrame
        unified_dedup_df = self.spark.createDataFrame([], unified_dedup_schema)

        # Write as Delta table
        unified_dedup_df.write \
            .format("delta") \
            .mode("overwrite") \
            .saveAsTable(self._unified_dedup_table)

        self._tables_created.append(self._unified_dedup_table)
        self.logger.info(f"  Created {self._unified_dedup_table}")
        self.logger.info(f"  Schema matches master table + search/scoring columns")

        return {'table': self._unified_dedup_table, 'mode': 'single-source'}
