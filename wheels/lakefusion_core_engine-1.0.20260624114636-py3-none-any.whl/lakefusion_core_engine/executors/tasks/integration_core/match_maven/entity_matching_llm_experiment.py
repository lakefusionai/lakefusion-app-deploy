"""
LLM Matching Experiment Executor.

Performs LLM-based entity matching for Match Maven experiments.
Experiment mode does NOT apply threshold-based classification.

Key Features:
    - Uses LLM to score potential matches from vector search
    - No MATCH/POTENTIAL_MATCH/NO_MATCH classification (experiment mode)
    - Stores raw scores in scoring_results for analysis
    - Creates processed table with exploded match results
    - Excludes records already handled by match rules (LEFT ANTI JOIN)
"""

import json
from typing import Any, Dict

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class LLMMatchingExperimentExecutor(BaseStepTask):
    """
    Executor for LLM Matching operations in Match Maven experiments.

    Uses LLM to score and rank potential matches from vector search.
    Unlike production mode, experiment mode keeps raw scores for analysis.

    Workflow:
        1. Validate LLM endpoint readiness
        2. Check processed table status
        3. Filter records for processing (excluding deterministic matches via LEFT ANTI JOIN)
        4. Execute LLM scoring via ai_query
        5. Update source table with scoring_results
        6. Rebuild processed table with exploded results
        7. Verify final state
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the LLM matching experiment task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._llm_temperature: float = 0.0

        # Step intermediate results
        self._records_to_process: int = 0
        self._results_count: int = 0
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """PRE phase: Validate inputs and setup configuration."""
        params = self.context.params
        self._llm_endpoint = params.get('llm_endpoint')
        self._max_potential_matches = int(params.get('max_potential_matches', 3))
        self._is_single_source = params.get('is_single_source', False)
        self._attributes = params.get('attributes', [])
        self._additional_instructions = params.get('additional_instructions', '')
        self._base_prompt = params.get('base_prompt', '')
        llm_temp = params.get('llm_temperature', 0.0)
        self._llm_temperature = float(llm_temp) if llm_temp else 0.0
        self._merged_desc_column = "attributes_combined"
        self._master_id_key = "lakefusion_id"

        if isinstance(self._is_single_source, str):
            self._is_single_source = self._is_single_source.lower() == "true"
        if isinstance(self._attributes, str):
            self._attributes = json.loads(self._attributes)

        # Set mode-specific configuration
        if self._is_single_source:
            self._source_id_key = "lakefusion_id"
            self._mode_name = "GOLDEN DEDUP (Single Source)"
        else:
            self._source_id_key = "surrogate_key"
            self._mode_name = "NORMAL DEDUP (Multi Source)"

        # Build table names
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._master_table = f"{self.context.catalog_name}.gold.{self.context.entity}_master{experiment_suffix}"
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"
        self._unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate{experiment_suffix}"
        self._processed_unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_processed_unified{experiment_suffix}"
        self._processed_unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_processed_unified_deduplicate{experiment_suffix}"

        # Deterministic tables (used for LEFT ANTI JOIN to skip already-matched records)
        self._unified_deterministic_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deterministic{experiment_suffix}"
        self._unified_deterministic_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deterministic_deduplicate{experiment_suffix}"

        if self._is_single_source:
            self._source_table = self._unified_dedup_table
            self._processed_table = self._processed_unified_dedup_table
            self._deterministic_table = self._unified_deterministic_dedup_table
        else:
            self._source_table = self._unified_table
            self._processed_table = self._processed_unified_table
            self._deterministic_table = self._unified_deterministic_table

        self.print_header(f"LLM ENTITY MATCHING - EXPERIMENT MODE ({self._mode_name})")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Experiment: {self.context.experiment_id}")
        self.logger.info(f"Is Single Source: {self._is_single_source}")
        self.logger.info(f"Source Table: {self._source_table}")
        self.logger.info(f"Source ID Key: {self._source_id_key}")
        self.logger.info(f"Processed Table: {self._processed_table}")
        self.logger.info(f"LLM Endpoint: {self._llm_endpoint}")
        self.logger.info(f"Max Potential Matches: {self._max_potential_matches}")
        self.logger.info("EXPERIMENT MODE: No threshold classification")
        self.logger.info("  All matches will be scored without MATCH/POTENTIAL_MATCH/NO_MATCH status")

    @step(order=1, name="Validate LLM Endpoint", returns="None")
    def step_validate_llm_endpoint(self) -> None:
        """Step 1: Validate LLM endpoint is ready."""
        self._validate_llm_endpoint()

    @step(order=2, name="Check Processed Table", returns="None")
    def step_check_processed_table(self) -> None:
        """Step 2: Check processed table status."""
        self._check_processed_table()

    @step(order=3, name="Filter Records for Processing", returns="records_to_process")
    def step_filter_records_for_processing(self) -> int:
        """Step 3: Filter records for LLM processing."""
        self._records_to_process = self._filter_records_for_processing()
        return self._records_to_process

    @step(order=4, name="Execute LLM Matching", returns="results_count")
    def step_execute_llm_matching(self) -> int:
        """Step 4: Build and execute LLM query."""
        self._results_count = self._execute_llm_matching()
        return self._results_count

    @step(order=5, name="Rebuild Processed Table", returns="None")
    def step_rebuild_processed_table(self) -> None:
        """Step 5: Rebuild processed table."""
        self._rebuild_processed_table()

    @step(order=6, name="Verify Final State", returns="None")
    def step_verify_final_state(self) -> None:
        """Step 6: Verify final state."""
        self._verify_final_state()

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Perform LLM matching for experiment.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Validate LLM endpoint
            self.step_validate_llm_endpoint()

            # Step 2: Check processed table
            self.step_check_processed_table()

            # Step 3: Filter records for LLM processing
            self.step_filter_records_for_processing()

            if self._records_to_process == 0:
                # Check for existing scoring_results to rebuild processed table
                existing_scored = self._check_existing_scored()
                if existing_scored > 0:
                    self._rebuild_processed_from_existing()

                return TaskResult.skipped(
                    message="No new records to process",
                    task_name=self.context.task_name,
                    task_values={
                        'llm_matching_complete': True,
                        'records_processed': 0
                    }
                )

            # Step 4: Build and execute LLM query
            self.step_execute_llm_matching()

            # Step 5: Rebuild processed table
            self.step_rebuild_processed_table()

            # Step 6: Verify final state
            self.step_verify_final_state()

            return TaskResult.success(
                message=f"{self._mode_name} LLM matching completed for {self._results_count} results",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'llm_matching_complete': True,
                    'records_processed': self._results_count
                }
            )

        except Exception as e:
            raise RuntimeError(f"LLM matching failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate LLM matching results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            records_processed = self._stats.get('results_count', 0)

            validation = ValidationResult(
                passed=True,
                message=f"LLM matching processed {records_processed} results",
                expected=self._stats.get('expected_results', 0),
                actual=records_processed
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("llm_matching_complete", True)
                self.dbutils.jobs.taskValues.set("records_processed",
                    self._stats.get('results_count', 0))
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _validate_llm_endpoint(self) -> None:
        """Step 1: Validate LLM endpoint is ready."""
        self.print_header("STEP 1: VALIDATE LLM ENDPOINT")

        from lakefusion_core_engine.utils.model_serving import wait_until_serving_endpoint_ready

        wait_until_serving_endpoint_ready(endpoint_name=self._llm_endpoint, timeout_minutes=5)
        self.logger.info(f"  LLM endpoint '{self._llm_endpoint}' is ready")

    def _check_processed_table(self) -> None:
        """Step 2: Check processed table status."""
        self.print_header("STEP 2: CHECK PROCESSED TABLE")

        try:
            processed_df = self.spark.table(self._processed_table)
            processed_count = processed_df.count()
            self.logger.info(f"  Processed table exists with {processed_count} records")
        except Exception:
            self.logger.info("  Processed table does not exist yet (will be created)")

    def _filter_records_for_processing(self) -> int:
        """
        Step 3: Filter records for LLM processing.

        Uses LEFT ANTI JOIN against the deterministic table to exclude records
        already handled by match rules, mirroring notebook logic.
        """
        self.print_header("STEP 3: FILTER RECORDS FOR LLM PROCESSING")

        # Check whether the deterministic table exists — drives union_clause usage
        self._deterministic_table_exists = self.spark.catalog.tableExists(self._deterministic_table)
        self.logger.info(f"  Deterministic table exists: {self._deterministic_table_exists}")

        if self._is_single_source:
            if self._deterministic_table_exists:
                filter_query = f"""
                  SELECT
                    u.{self._source_id_key},
                    u.{self._merged_desc_column},
                    u.search_results
                  FROM {self._source_table} u
                  LEFT ANTI JOIN {self._deterministic_table} ud
                    ON u.{self._master_id_key} = ud.{self._master_id_key}
                  WHERE u.search_results IS NOT NULL
                    AND u.search_results != ''
                    AND (u.scoring_results IS NULL OR u.scoring_results = '')
                """
            else:
                filter_query = f"""
                  SELECT
                    u.{self._source_id_key},
                    u.{self._merged_desc_column},
                    u.search_results
                  FROM {self._source_table} u
                  WHERE u.search_results IS NOT NULL
                    AND u.search_results != ''
                    AND (u.scoring_results IS NULL OR u.scoring_results = '')
                """
        else:
            if self._deterministic_table_exists:
                filter_query = f"""
                  SELECT
                    u.{self._source_id_key},
                    u.{self._merged_desc_column},
                    u.search_results
                  FROM {self._source_table} u
                  LEFT ANTI JOIN {self._deterministic_table} ud
                    ON u.{self._source_id_key} = ud.{self._source_id_key}
                  WHERE u.record_status = 'ACTIVE'
                    AND u.search_results IS NOT NULL
                    AND u.search_results != ''
                    AND (u.scoring_results IS NULL OR u.scoring_results = '')
                """
            else:
                filter_query = f"""
                  SELECT
                    u.{self._source_id_key},
                    u.{self._merged_desc_column},
                    u.search_results
                  FROM {self._source_table} u
                  WHERE u.record_status = 'ACTIVE'
                    AND u.search_results IS NOT NULL
                    AND u.search_results != ''
                    AND (u.scoring_results IS NULL OR u.scoring_results = '')
                """

        # Store the filter query for reuse in _execute_llm_matching
        self._filter_query = filter_query

        uf_sub_query = f"uf AS ({filter_query})"
        records_to_process = self.spark.sql(
            f"WITH {uf_sub_query} SELECT COUNT(*) AS cnt FROM uf"
        ).collect()[0]['cnt']

        expected_results = records_to_process * self._max_potential_matches

        self.logger.info(f"  Records to process: {records_to_process}")
        self.logger.info(f"  Expected results: {expected_results} ({self._max_potential_matches} matches per record)")

        self._stats['records_to_process'] = records_to_process
        self._stats['expected_results'] = expected_results

        return records_to_process

    def _check_existing_scored(self) -> int:
        """Check if there are existing scoring_results in the source table."""
        if self._is_single_source:
            check_query = f"""
            SELECT COUNT(*) AS cnt FROM {self._source_table}
            WHERE scoring_results IS NOT NULL AND scoring_results != ''
            """
        else:
            check_query = f"""
            SELECT COUNT(*) AS cnt FROM {self._source_table}
            WHERE record_status = 'ACTIVE'
            AND scoring_results IS NOT NULL AND scoring_results != ''
            """
        return self.spark.sql(check_query).collect()[0]['cnt']

    def _rebuild_processed_from_existing(self) -> None:
        """Rebuild processed table from existing scoring_results when no new records to process."""
        self.print_header("REBUILDING PROCESSED TABLE FROM EXISTING DATA")

        if self._is_single_source:
            rebuild_query = f"""
            SELECT
              u.lakefusion_id AS query_lakefusion_id,
              exploded.lakefusion_id AS match_lakefusion_id,
              exploded AS exploded_result,
              exploded.id AS exploded_result_id
            FROM {self._source_table} u
            LATERAL VIEW EXPLODE(
              FROM_JSON(u.scoring_results, 'array<struct<
                id:string, score:double, reason:string, lakefusion_id:string
              >>')
            ) AS exploded
            WHERE u.scoring_results IS NOT NULL AND u.scoring_results != ''
            """
        else:
            rebuild_query = f"""
            SELECT
              u.surrogate_key,
              exploded.lakefusion_id AS lakefusion_id,
              exploded AS exploded_result,
              exploded.id AS exploded_result_id
            FROM {self._source_table} u
            LATERAL VIEW EXPLODE(
              FROM_JSON(u.scoring_results, 'array<struct<
                id:string, score:double, reason:string, lakefusion_id:string
              >>')
            ) AS exploded
            WHERE u.record_status = 'ACTIVE'
            AND u.scoring_results IS NOT NULL AND u.scoring_results != ''
            """

        df_from_scoring = self.spark.sql(rebuild_query)
        result_count = df_from_scoring.count()

        df_from_scoring.write.mode("overwrite").option("mergeSchema", "true").saveAsTable(self._processed_table)
        self.logger.info(f"  Processed table updated with {result_count} records from existing scoring_results")

    def _safe_format(self, template: str, **kwargs) -> str:
        """Format a template, leaving unrecognized placeholders intact."""
        class SafeDict(dict):
            def __missing__(self, key):
                return '{' + key + '}'
        return template.format_map(SafeDict(**kwargs))

    def _build_union_clause(self) -> str:
        """
        Build the UNION clause that appends deterministic match results into the 'er' CTE.

        When the deterministic table exists, its already-scored records are folded back
        into the exploded results set so the processed table stays complete.
        If the table does not exist, an empty string is returned (no UNION).
        """
        if not self._deterministic_table_exists:
            return ""

        unified_id_key = self._master_id_key if self._is_single_source else self._source_id_key

        return f"""
        UNION
        SELECT
            {unified_id_key},
            FIRST(attributes_combined) AS attributes_combined,
            FIRST(search_results) AS search_results,
            CONCAT(
                '[',
                CONCAT_WS(',', COLLECT_LIST(json_item)),
                ']'
            ) AS combined_column,
            FIRST(exploded_result) AS exploded_result
        FROM (
            SELECT
                {unified_id_key},
                CONCAT(
                    '{{"id": "', exploded_result.id,
                    '", "score": ', exploded_result.score,
                    ', "reason": "', exploded_result.reason,
                    '", "lakefusion_id": "', exploded_result.lakefusion_id,
                    '"}}'
                ) AS json_item,
                attributes_combined,
                search_results,
                deterministic_match_result,
                is_deterministic_match,
                NAMED_STRUCT(
                    'id', exploded_result.id,
                    'score', CAST(exploded_result.score AS DOUBLE),
                    'reason', exploded_result.reason,
                    'lakefusion_id', exploded_result.lakefusion_id
                ) AS exploded_result
            FROM {self._deterministic_table}
        )
        GROUP BY {unified_id_key}
        """

    def _execute_llm_matching(self) -> int:
        """Step 4: Build and execute LLM query."""
        self.print_header("STEP 4: BUILD AND EXECUTE LLM QUERY")

        uf_sub_query = f"uf AS ({self._filter_query})"
        union_clause = self._build_union_clause()

        # ── Prompt construction ───────────────────────────────────────────────
        additional_instructions_clause = ""
        if self._additional_instructions and self._additional_instructions.strip():
            additional_instructions_clause = f" {self._additional_instructions}"

        if not self._base_prompt:
            self.logger.info("  Using default prompt")
            default_prompt = f"""You are an expert in classifying two entities as matching or not matching.
You will be provided with a query entity and a list of possible entities.
You need to find the closest matching entity with a similarity score to indicate how similar they are.
Take into account:
1. The attributes are not mutually exclusive.
2. The attributes are not exhaustive.
3. The attributes are not consistent.
4. The attributes are not complete.
5. The attributes can have typos.
6. The entity type being considered is: {self.context.entity}.
7. Do not consider scores in the search results. Generate your own similarity scores.
8. If additional instructions are present, consider them too.{additional_instructions_clause}
Follow these rules for input and output:
**Input:**
- Query Entity Format:
  The query entity will be provided as a single string in the following format:
  {' | '.join(self._attributes)}
  Each field is separated by a vertical bar (|).
  Note: Some columns can have aggregated values separated by ()
- List of Possible Entities:
  A string containing comma-separated entries in this EXACT format:
  [entity_description, lakefusion_id, score], [entity_description, lakefusion_id, score], ...
**CRITICAL EXTRACTION RULES:**
- For EACH entry in the list, you MUST extract the lakefusion_id
- The lakefusion_id is ALWAYS between the FIRST comma and SECOND comma inside each bracket
- lakefusion_id format: 32 lowercase hexadecimal characters (a-f, 0-9)
**Output:**
Only return a plain JSON list of objects:
1. No extra text, no headers, no introductory phrases, and no comments.
2. Do not use code blocks, markdown, or any other formatting.
3. The JSON list MUST contain EXACTLY {self._max_potential_matches} objects.
4. Each object must have these keys:
    a. id: String (the entity_description - text BEFORE first comma in brackets).
    b. score: Float (YOUR similarity score from 0.0 to 1.0 - NOT the vector score).
    c. reason: String (brief explanation for YOUR score).
    d. lakefusion_id: String (COPY the 32-char hex string between 1st and 2nd comma EXACTLY).
5. VERIFY each lakefusion_id is exactly 32 characters of a-f and 0-9.
6. Return EXACTLY {self._max_potential_matches} results, no more, no less.
7. Ensure scores are in descending order (highest similarity first)."""
            safe_prompt = default_prompt.replace("'", "\\'")
        else:
            self.logger.info(f"  Using base prompt (first 100 chars): '{self._base_prompt[:100]}'")
            clean_prompt = (
                self._base_prompt
                .replace("{query_entity}", "")
                .replace("{merged_desc_column}", "")
                .replace("{search_results}", "")
            )
            formatted_prompt = self._safe_format(
                clean_prompt,
                entity=self.context.entity,
                additional_instructions=self._additional_instructions,
                attributes=' | '.join(self._attributes),
                max_potential_matches=self._max_potential_matches
            )
            safe_prompt = formatted_prompt.replace("'", "\\'")

        prompt_concat_parts = (
            f"CONCAT('{safe_prompt}', "
            f"'\\nQuery record: ', {self._merged_desc_column}, "
            f"'\\nList of potential matches with vector search scores (JSON Array): ', search_results)"
        )

        # ── Final SELECT differs by source mode ───────────────────────────────
        if self._is_single_source:
            final_select = f"""
            SELECT
              er.{self._source_id_key} AS query_lakefusion_id,
              er.exploded_result.{self._master_id_key} AS match_lakefusion_id,
              er.exploded_result,
              er.exploded_result.`id` AS exploded_result_id,
              er.combined_results AS scoring_results_json
            FROM er
            WHERE er.exploded_result.{self._master_id_key} IS NOT NULL
            """
        else:
            final_select = f"""
            SELECT
              er.{self._source_id_key},
              er.exploded_result.{self._master_id_key} AS {self._master_id_key},
              er.exploded_result,
              er.exploded_result.`id` AS exploded_result_id,
              er.combined_results AS scoring_results_json
            FROM er
            WHERE er.exploded_result.{self._master_id_key} IS NOT NULL
            """

        # ── Full LLM query ────────────────────────────────────────────────────
        llm_query = f"""
        WITH {uf_sub_query},
        llm_results AS (
          SELECT
            {self._source_id_key},
            {self._merged_desc_column},
            search_results,
            ai_query(
              '{self._llm_endpoint}',
              {prompt_concat_parts},
              responseFormat => '{{
                "type": "json_schema",
                "json_schema": {{
                  "name": "match_results",
                  "schema": {{
                    "type": "object",
                    "properties": {{
                      "results": {{
                        "type": "array",
                        "items": {{
                          "type": "object",
                          "properties": {{
                            "id": {{ "type": "string" }},
                            "score": {{ "type": "number" }},
                            "reason": {{ "type": "string" }},
                            "lakefusion_id": {{ "type": "string" }}
                          }},
                          "required": ["id", "score", "reason", "lakefusion_id"],
                          "additionalProperties": false
                        }}
                      }}
                    }},
                    "required": ["results"],
                    "additionalProperties": false
                  }},
                  "strict": true
                }}
              }}',
              modelParameters => named_struct('temperature', {self._llm_temperature})
            ) AS scoring_results
          FROM uf
        ),
        er AS (
          SELECT
            uf.*,
            get_json_object(llm_results.scoring_results, '$.results') AS combined_results,
            EXPLODE(FROM_JSON(
              get_json_object(llm_results.scoring_results, '$.results'),
              'ARRAY<STRUCT<
                  id STRING, score DOUBLE, reason STRING, lakefusion_id STRING
              >>'
            )) AS exploded_result
          FROM uf, llm_results
          WHERE uf.{self._source_id_key} = llm_results.{self._source_id_key}
        )
        {final_select}
        """

        self.logger.info("  Running LLM matching (this may take a while)...")

        df_llm_results = self.spark.sql(llm_query)

        # ── Filter and rank results ───────────────────────────────────────────
        from pyspark.sql.functions import col, row_number
        from pyspark.sql.window import Window

        partition_key = "query_lakefusion_id" if self._is_single_source else self._source_id_key
        match_key = "match_lakefusion_id" if self._is_single_source else self._master_id_key

        window_spec = Window.partitionBy(partition_key).orderBy(col("exploded_result.score").desc())

        df_filtered = (
            df_llm_results
            .filter(col(match_key).isNotNull())
            .withColumn("rank", row_number().over(window_spec))
            .filter(col("rank") <= self._max_potential_matches)
            .drop("rank")
        )

        filtered_count = df_filtered.count()
        self.logger.info(f"  LLM processing completed — {filtered_count} scored results")

        self._stats['results_count'] = filtered_count

        # ── Update source table with scoring_results ──────────────────────────
        self._update_source_table(df_filtered, partition_key)

        return filtered_count

    def _update_source_table(self, df_results, agg_key: str) -> None:
        """Update source table with scoring_results via MERGE."""
        self.print_header("STEP 5: UPDATE SOURCE TABLE WITH SCORING RESULTS")

        from pyspark.sql.functions import to_json, collect_list, struct, col

        df_scoring_agg = (
            df_results
            .groupBy(agg_key)
            .agg(
                to_json(
                    collect_list(
                        struct(
                            col("exploded_result.id").alias("id"),
                            col("exploded_result.score").alias("score"),
                            col("exploded_result.reason").alias("reason"),
                            col("exploded_result.lakefusion_id").alias("lakefusion_id")
                        )
                    )
                ).alias("scoring_results")
            )
        )

        update_count = df_scoring_agg.count()
        self.logger.info(f"  Updating {update_count} records in source table with scoring_results")

        df_scoring_agg.createOrReplaceTempView("scoring_updates")

        source_table_key = "lakefusion_id" if self._is_single_source else self._source_id_key

        update_sql = f"""
        MERGE INTO {self._source_table} AS target
        USING scoring_updates AS source
        ON target.{source_table_key} = source.{agg_key}
        WHEN MATCHED THEN UPDATE SET
            target.scoring_results = source.scoring_results
        """

        self.spark.sql(update_sql)
        self.logger.info("  Source table updated with scoring_results")

    def _rebuild_processed_table(self) -> None:
        """Step 6: Rebuild processed table from all records with scoring_results."""
        self.print_header("STEP 6: REBUILD PROCESSED TABLE")

        self.logger.info("  Building processed table from all records with scoring_results")

        if self._is_single_source:
            processed_query = f"""
            SELECT
              u.lakefusion_id AS query_lakefusion_id,
              exploded.lakefusion_id AS match_lakefusion_id,
              exploded AS exploded_result,
              exploded.id AS exploded_result_id
            FROM {self._source_table} u
            LATERAL VIEW EXPLODE(
              FROM_JSON(u.scoring_results, 'array<struct<
                id:string, score:double, reason:string, lakefusion_id:string
              >>')
            ) AS exploded
            WHERE u.scoring_results IS NOT NULL AND u.scoring_results != ''
            """
        else:
            processed_query = f"""
            SELECT
              u.surrogate_key,
              exploded.lakefusion_id AS lakefusion_id,
              exploded AS exploded_result,
              exploded.id AS exploded_result_id
            FROM {self._source_table} u
            LATERAL VIEW EXPLODE(
              FROM_JSON(u.scoring_results, 'array<struct<
                id:string, score:double, reason:string, lakefusion_id:string
              >>')
            ) AS exploded
            WHERE u.record_status = 'ACTIVE'
            AND u.scoring_results IS NOT NULL AND u.scoring_results != ''
            """

        df_processed = self.spark.sql(processed_query)
        processed_count = df_processed.count()
        self.logger.info(f"  Processed records to write: {processed_count}")

        df_processed.write.mode("overwrite").option("mergeSchema", "true").saveAsTable(self._processed_table)
        self.logger.info(f"  Processed table saved: {self._processed_table}")

        self._stats['processed_count'] = processed_count

        # Optimize
        try:
            self.spark.sql(f"OPTIMIZE {self._processed_table} ZORDER BY ({source_table_key})")
            self.logger.info("  Optimized processed table")
        except Exception:
            pass

    def _verify_final_state(self) -> None:
        """Step 7: Verify final state and log summary stats."""
        self.print_header("STEP 7: VERIFY FINAL STATE")

        self.logger.info("  EXPERIMENT MODE: No threshold classification applied")
        self.logger.info("  All scores are raw LLM similarity scores for analysis")
