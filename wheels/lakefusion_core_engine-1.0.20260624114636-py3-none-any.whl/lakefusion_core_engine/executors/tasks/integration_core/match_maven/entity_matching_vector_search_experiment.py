"""
Vector Search Experiment Executor.

Performs vector similarity search for Match Maven experiments.
Supports both single-source (golden dedup) and multi-source (normal dedup) modes.

Key Features:
    - For single-source: Clones master to unified_dedup, excludes self-matches
    - For multi-source: Searches unified records against master index
    - Creates and syncs vector search index on master table
    - Stores search results in source table for LLM processing
"""

import time
from typing import Any, Dict, Optional

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class VectorSearchExperimentExecutor(BaseStepTask):
    """
    Executor for Vector Search operations in Match Maven experiments.

    Performs vector similarity search to find potential matches.
    Handles both golden dedup (self-match exclusion) and normal dedup modes.

    Workflow:
        1. For single-source: Clone master to unified_deduplicate
        2. Validate embedding endpoint
        3. Setup vector search endpoint
        4. Create/sync vector search index on master table
        5. Filter records needing search (empty search_results)
        6. Execute vector search via UDF
        7. Merge results to source table
    """

    MAX_WAIT_SECONDS = 1800  # 30 minutes
    POLL_INTERVAL = 20  # seconds
    MAX_BACKEND_ERRORS = 10
    MAX_PIPELINE_FAILURES = 3
    REGISTRATION_TIMEOUT = 1800  # 30 minutes

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the vector search experiment task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._index = None
        self._client = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Step intermediate results
        self._embedding_endpoint: Optional[str] = None
        self._vs_endpoint: Optional[str] = None
        self._max_potential_matches: int = 5
        self._is_single_source: bool = False
        self._merged_desc_column: str = "attributes_combined"
        self._master_id_key: str = "lakefusion_id"
        self._source_id_key: str = "surrogate_key"
        self._mode_name: str = ""
        self._filter_by_status: bool = True
        self._exclude_self_matches: bool = False
        self._master_table: Optional[str] = None
        self._unified_table: Optional[str] = None
        self._unified_dedup_table: Optional[str] = None
        self._source_table: Optional[str] = None
        self._df_pending = None
        self._pending_count: int = 0
        self._df_results = None
        self._df_deduped = None

    def pre_execute(self) -> None:
        """PRE phase: Validate inputs and setup configuration."""
        params = self.context.params
        self._embedding_endpoint = params.get('embedding_endpoint')
        self._vs_endpoint = params.get('vs_endpoint')
        self._max_potential_matches = int(params.get('max_potential_matches', 5))
        self._is_single_source = params.get('is_single_source', False)
        self._merged_desc_column = "attributes_combined"
        self._master_id_key = "lakefusion_id"

        if isinstance(self._is_single_source, str):
            self._is_single_source = self._is_single_source.lower() == "true"

        # Set mode-specific configuration
        if self._is_single_source:
            self._source_id_key = "lakefusion_id"
            self._mode_name = "GOLDEN DEDUP (Single Source)"
            self._filter_by_status = False
            self._exclude_self_matches = True
        else:
            self._source_id_key = "surrogate_key"
            self._mode_name = "NORMAL DEDUP (Multi Source)"
            self._filter_by_status = True
            self._exclude_self_matches = False

        # Build table names
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._master_table = f"{self.context.catalog_name}.gold.{self.context.entity}_master{experiment_suffix}"
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"
        self._unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate{experiment_suffix}"

        self._source_table = self._unified_dedup_table if self._is_single_source else self._unified_table

        self.print_header(f"EXPERIMENT VECTOR SEARCH - {self._mode_name}")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id}")
        self.logger.info(f"Is Single Source: {self._is_single_source}")
        self.logger.info("-" * 70)
        self.logger.info(f"Source Table: {self._source_table}")
        self.logger.info(f"Source ID Key: {self._source_id_key}")
        self.logger.info(f"Master Table: {self._master_table}")
        self.logger.info("-" * 70)
        self.logger.info(f"Embedding Endpoint: {self._embedding_endpoint}")
        self.logger.info(f"VS Endpoint: {self._vs_endpoint}")
        self.logger.info(f"Max Potential Matches: {self._max_potential_matches}")
        self.logger.info(f"Exclude Self-Matches: {self._exclude_self_matches}")

    @step(order=0, name="Process Unified Dedup Table (Single Source)", returns="None - clones master to unified_dedup")
    def step_process_unified_dedup_table(self) -> Dict[str, Any]:
        """Step 0: Clone master to unified_deduplicate for single source mode."""
        if not self._is_single_source:
            self.logger.info("Skipping - not in single source mode")
            return {'skipped': True}

        from pyspark.sql.functions import lit

        # Check if unified_dedup table exists
        unified_dedup_exists = self.spark.catalog.tableExists(self._unified_dedup_table)

        if unified_dedup_exists:
            existing_count = self.spark.table(self._unified_dedup_table).count()
            self.logger.info(f"Unified dedup table exists with {existing_count} records")
        else:
            self.logger.info(f"Creating unified dedup table: {self._unified_dedup_table}")

        # Read master table
        df_master = self.spark.table(self._master_table)

        # Clone master to unified_dedup with search/scoring columns
        df_unified_dedup = df_master.withColumn("search_results", lit("")) \
                                     .withColumn("scoring_results", lit(""))

        # Overwrite for fresh experiment state
        df_unified_dedup.write.mode("overwrite").option("mergeSchema", "true") \
                        .saveAsTable(self._unified_dedup_table)

        self.logger.info(f"  Source: {self._master_table}")
        self.logger.info(f"  Target: {self._unified_dedup_table}")

        return {'cloned': True}

    @step(order=1, name="Validate Embedding Endpoint", returns="None")
    def step_validate_embedding_endpoint(self) -> None:
        """Step 1: Validate embedding endpoint is ready."""
        from lakefusion_core_engine.utils.model_serving import wait_until_serving_endpoint_ready

        wait_until_serving_endpoint_ready(endpoint_name=self._embedding_endpoint, timeout_minutes=5)
        self.logger.info(f"  Embedding endpoint '{self._embedding_endpoint}' is ready")

    @step(order=2, name="Setup Vector Search Endpoint", returns="None")
    def step_setup_vs_endpoint(self) -> None:
        """Step 2: Setup vector search endpoint."""
        from databricks.vector_search.client import VectorSearchClient

        self._client = VectorSearchClient(disable_notice=True)

        try:
            response = self._client.list_endpoints()
            existing_endpoints = [ep['name'] for ep in response.get('endpoints', [])]
        except Exception as e:
            self.logger.info(f"  Could not fetch Vector Search endpoints: {e}")
            existing_endpoints = []

        if self._vs_endpoint in existing_endpoints:
            self.logger.info(f"  Endpoint '{self._vs_endpoint}' already exists")
        else:
            self.logger.info(f"  Creating new endpoint '{self._vs_endpoint}'...")
            self._client.create_endpoint(
                name=self._vs_endpoint,
                endpoint_type="STANDARD"
            )
            self.logger.info(f"  Endpoint created successfully")

    @step(order=3, name="Wait for VS Endpoint", returns="None")
    def step_wait_for_vs_endpoint(self) -> None:
        """Step 3: Wait for VS endpoint to be ready."""
        from lakefusion_core_engine.utils.model_serving import wait_until_vector_search_ready

        wait_until_vector_search_ready(endpoint_name=self._vs_endpoint)
        self.logger.info(f"  Vector Search endpoint '{self._vs_endpoint}' is ready")

    @step(order=4, name="Create/Sync Vector Search Index", returns="None")
    def step_create_or_sync_index(self) -> None:
        """Step 4: Create or sync vector search index on master table."""
        from lakefusion_core_engine.utils.model_serving import sync_index_with_retry

        index_name = f"{self._master_table}_index"
        self._stats['index_name'] = index_name

        # -------------------------------------------------
        # STEP 4.1: Create index with retry logic
        # -------------------------------------------------
        MAX_CREATE_RETRIES = 3
        CREATE_RETRY_INTERVAL = 60  # seconds
        index_already_exists = False

        for attempt in range(1, MAX_CREATE_RETRIES + 1):
            try:
                self.logger.info(f"Attempting to create index (attempt {attempt}/{MAX_CREATE_RETRIES})...")
                self._index = self._client.create_delta_sync_index(
                    endpoint_name=self._vs_endpoint,
                    source_table_name=self._master_table,
                    index_name=index_name,
                    columns_to_sync=[self._master_id_key, self._merged_desc_column],
                    pipeline_type="TRIGGERED",
                    primary_key=self._master_id_key,
                    embedding_source_column=self._merged_desc_column,
                    embedding_model_endpoint_name=self._embedding_endpoint
                )
                self.logger.info(f"Create request submitted for index: {index_name}")
                break  # Success, exit retry loop

            except Exception as e:
                error_msg = str(e)
                error_lower = error_msg.lower()

                # Case 1: Index already exists - this is fine, proceed to wait loop
                if "already exists" in error_lower:
                    self.logger.info(f"Index already exists, proceeding to sync: {error_msg}")
                    index_already_exists = True
                    break

                # Case 2: Permanent errors - fail immediately
                if ("maximum number of indexes" in error_lower or
                    "permission denied" in error_lower or
                    "unauthorized" in error_lower):
                    raise RuntimeError(f"Index creation failed: {error_msg}")

                # Case 3: Transient errors - retry
                self.logger.info(f"Create attempt {attempt} failed: {error_msg}")
                if attempt < MAX_CREATE_RETRIES:
                    self.logger.info(f"Retrying in {CREATE_RETRY_INTERVAL} seconds...")
                    time.sleep(CREATE_RETRY_INTERVAL)
                else:
                    raise RuntimeError(
                        f"Index creation failed after {MAX_CREATE_RETRIES} attempts: {error_msg}"
                    )

        # -------------------------------------------------
        # STEP 4.2: Wait for index registration
        # -------------------------------------------------
        self.logger.info("Waiting for index registration...")
        start = time.time()

        while self._index is None:
            if time.time() - start > self.REGISTRATION_TIMEOUT:
                raise TimeoutError(
                    f"Index '{index_name}' not registered within {self.REGISTRATION_TIMEOUT}s"
                )

            try:
                self._index = self._client.get_index(
                    endpoint_name=self._vs_endpoint,
                    index_name=index_name,
                )
                self.logger.info("Index is now registered and accessible")
            except Exception as e:
                error_lower = str(e).lower()
                if "not exist" in error_lower or "not_exist" in error_lower:
                    self.logger.info("  Index not visible yet - waiting...")
                    time.sleep(20)
                else:
                    raise RuntimeError(f"Unexpected error while locating index: {e}")

        # -------------------------------------------------
        # STEP 4.3: Wait for index to be ready before sync
        # -------------------------------------------------
        self.logger.info("Waiting for index to be ready before sync...")
        self._index.wait_until_ready()
        self.logger.info("Index is ready")

        # -------------------------------------------------
        # STEP 4.4: Trigger sync (if not already running)
        # -------------------------------------------------
        # Log current status for debugging
        index_status = self._index.describe()['status']
        current_status = index_status.get('detailed_state', 'UNKNOWN')
        self.logger.info(f"Current index status: {current_status}")

        # Log additional details if pipeline failed
        if current_status == "ONLINE_PIPELINE_FAILED":
            status_message = index_status.get('message', 'No message available')
            self.logger.info(f"Pipeline failure details: {status_message}")
            self.logger.info(f"Full index status: {index_status}")

        # Only trigger sync if not already running (can't sync while RUNNING)
        if current_status in ["ONLINE_TRIGGERED_UPDATE", "ONLINE_UPDATING_PIPELINE_RESOURCES", "ONLINE_PIPELINE_FAILED"]:
            self.logger.info("Sync already in progress or failed. Skipping sync trigger...")
        else:
            self.logger.info("Triggering index sync (with scale-from-zero retry handling)...")
            try:
                sync_index_with_retry(
                    index=self._index,
                    embedding_endpoint_name=self._embedding_endpoint,
                    max_retries=10,
                    retry_interval_seconds=60,
                    timeout_minutes=10
                )
                self.logger.info("Index sync initiated successfully!")
            except Exception as sync_error:
                error_msg = f"ERROR: Index sync failed: {str(sync_error)}"
                self.logger.info(error_msg)
                raise RuntimeError(error_msg)

        # -------------------------------------------------
        # STEP 4.5: Tolerant wait loop for sync completion
        # -------------------------------------------------
        self.logger.info("Waiting for index to be ready and synced (tolerant mode)...")
        start_time = time.time()
        consecutive_backend_errors = 0
        pipeline_failed_count = 0

        while True:
            try:
                self._index.wait_until_ready()

                status_info = self._index.describe()
                status = status_info["status"]["detailed_state"]
                message = status_info["status"].get("message", "")

                self.logger.info(f"  Index status: {status}")
                if message:
                    self.logger.info(f"    Message: {message}")

                consecutive_backend_errors = 0

                # Success
                if status == "ONLINE_NO_PENDING_UPDATE":
                    self.logger.info("Index is fully synced and ready.")
                    break

                # Actively updating - reset timer, let it continue (no timeout while making progress)
                if status in ["ONLINE_TRIGGERED_UPDATE", "ONLINE_UPDATING_PIPELINE_RESOURCES"]:
                    start_time = time.time()  # Reset timer since progress is being made
                    self.logger.info("  Sync in progress, resetting timeout timer...")

                # Transient failure handling - apply timeout only when failed
                if status == "ONLINE_PIPELINE_FAILED":
                    pipeline_failed_count += 1
                    self.logger.info(
                        f"ONLINE_PIPELINE_FAILED detected "
                        f"({pipeline_failed_count}/{self.MAX_PIPELINE_FAILURES})"
                    )

                    # Check timeout only when in failed state
                    elapsed = time.time() - start_time
                    if elapsed > self.MAX_WAIT_SECONDS:
                        raise TimeoutError(
                            f"Index sync timed out after {int(elapsed)} seconds in failed state"
                        )

                    if pipeline_failed_count >= self.MAX_PIPELINE_FAILURES:
                        raise RuntimeError(
                            "Index entered ONLINE_PIPELINE_FAILED state too many times"
                        )

            except Exception as e:
                consecutive_backend_errors += 1
                self.logger.info(
                    f"Backend error tolerated "
                    f"({consecutive_backend_errors}/{self.MAX_BACKEND_ERRORS}): {e}"
                )

                if consecutive_backend_errors >= self.MAX_BACKEND_ERRORS:
                    raise RuntimeError(
                        "Too many consecutive backend errors while waiting for index readiness"
                    )

            time.sleep(self.POLL_INTERVAL)

    @step(order=5, name="Filter Pending Records", returns="DataFrame and count of pending records")
    def step_filter_pending_records(self) -> Dict[str, Any]:
        """Step 5: Filter records needing vector search."""
        from pyspark.sql.functions import col

        df_source = self.spark.table(self._source_table)

        if self._filter_by_status:
            # Normal dedup: filter by ACTIVE status and empty search_results
            df_pending = df_source.filter(
                (col("record_status") == "ACTIVE") &
                (col("search_results") == "")
            ).select(self._source_id_key, self._merged_desc_column)
        else:
            # Golden dedup: just filter by empty search_results
            df_pending = df_source.filter(
                col("search_results") == ""
            ).select(self._source_id_key, self._merged_desc_column)

        pending_count = df_pending.isEmpty()

        if pending_count:
            self.logger.info("\nNo records to process - all records already have search results")
            self._df_pending = None
            self._pending_count = 0
            return {'pending_count': 0, 'has_records': False}

        # Get actual row count for partitioning
        row_count = df_pending.count()
        self._stats['pending_count'] = row_count

        # Calculate optimal partitions
        optimal_partitions = self._get_optimal_partitions(row_count)
        self.logger.info(f"optimal_partitions: {optimal_partitions}")

        df_pending = df_pending.repartition(optimal_partitions, self._source_id_key)

        self._df_pending = df_pending
        self._pending_count = row_count

        return {'pending_count': row_count, 'has_records': True}

    @step(order=6, name="Execute Vector Search", returns="DataFrame with search results")
    def step_execute_vector_search(self) -> Dict[str, Any]:
        """Step 6 & 7: Execute vector search via UDF."""
        if self._df_pending is None:
            print("No pending records to search")
            return {'records_searched': 0}

        from pyspark.sql.functions import pandas_udf, expr
        from pyspark.sql.types import ArrayType, StructType, StructField, StringType, FloatType
        import pandas as pd
        from databricks.vector_search.client import VectorSearchClient
        from concurrent.futures import ThreadPoolExecutor, as_completed

        # Import retry function from SDK utils
        from lakefusion_core_engine.utils.model_serving import similarity_search_with_retry

        # Capture for UDF closure
        _master_table = self._master_table
        _merged_desc_column = self._merged_desc_column
        _master_id_key = self._master_id_key
        _max_potential_matches = self._max_potential_matches
        exclude_self_matches = self._exclude_self_matches

        # UDF schema
        result_schema = ArrayType(StructType([
            StructField("text", StringType()),
            StructField("lakefusion_id", StringType()),
            StructField("score", FloatType())
        ]))

        # Broadcast variables for UDF - create client and index outside UDF
        client = VectorSearchClient()
        index = client.get_index(index_name=f"{_master_table}_index")
        num_results_requested = int(_max_potential_matches) + 1

        if exclude_self_matches:
            # Golden dedup UDF - excludes self-matches
            @pandas_udf(result_schema)
            def vector_search_results_udf(descriptions: pd.Series, query_ids: pd.Series) -> pd.Series:
                """
                Vector search for Golden Dedup - excludes self-matches.
                Queries come from unified_dedup, searches against master_table index.
                Uses ThreadPoolExecutor for concurrent execution within each partition.
                """
                def get_results(text, query_id):
                    try:
                        # Use retry wrapper with exponential backoff
                        results = similarity_search_with_retry(
                            index,
                            query_text=text,
                            columns=[_merged_desc_column, _master_id_key],
                            num_results=num_results_requested
                        )

                        formatted = []
                        for r in results["result"]["data_array"]:
                            result_text = r[0]
                            result_id = r[1]
                            result_score = float(r[2])

                            # CRITICAL: Skip self-matches
                            if result_id == query_id:
                                continue

                            formatted.append({
                                "text": result_text,
                                "lakefusion_id": result_id,
                                "score": result_score
                            })

                            if len(formatted) >= int(_max_potential_matches):
                                break

                        return formatted
                    except Exception as e:
                        print(f"Error during vector search for query_id {query_id}: {e}")
                        return []

                # Use ThreadPoolExecutor for concurrent execution within partition
                with ThreadPoolExecutor(max_workers=10) as executor:
                    futures = {executor.submit(get_results, desc, qid): i
                               for i, (desc, qid) in enumerate(zip(descriptions, query_ids))}
                    results = [None] * len(descriptions)
                    for future in as_completed(futures):
                        results[futures[future]] = future.result()
                return pd.Series(results)

            print("Golden Dedup UDF defined (with self-match filtering + ThreadPoolExecutor)")
            print(f"  - Requests {int(_max_potential_matches) + 1} results to filter self-matches")

        else:
            # Normal dedup UDF - no self-match filtering
            @pandas_udf(result_schema)
            def vector_search_results_udf(descriptions: pd.Series) -> pd.Series:
                """Uses ThreadPoolExecutor for concurrent execution within each partition."""
                def get_results(text):
                    try:
                        # Use retry wrapper with exponential backoff
                        results = similarity_search_with_retry(
                            index,
                            query_text=text,
                            columns=[_merged_desc_column, _master_id_key],
                            num_results=int(_max_potential_matches)
                        )

                        formatted = []
                        for r in results["result"]["data_array"]:
                            formatted.append({
                                "text": r[0],
                                "lakefusion_id": r[1],
                                "score": float(r[2])
                            })
                        return formatted
                    except Exception as e:
                        print(f"Error during vector search: {e}")
                        return []

                # Use ThreadPoolExecutor for concurrent execution within partition
                with ThreadPoolExecutor(max_workers=10) as executor:
                    futures = {executor.submit(get_results, desc): i
                               for i, desc in enumerate(descriptions)}
                    results = [None] * len(descriptions)
                    for future in as_completed(futures):
                        results[futures[future]] = future.result()
                return pd.Series(results)

            print("Normal Dedup UDF defined (with ThreadPoolExecutor)")

        print(f"  - Searches against: {_master_table} index")
        print(f"  - Returns top {_max_potential_matches} matches per record")

        print(f"Running {self._mode_name} vector search...")

        if exclude_self_matches:
            # Golden dedup - pass both description and ID
            df_with_results = self._df_pending.withColumn(
                "search_results_array",
                vector_search_results_udf(
                    self._df_pending[self._merged_desc_column],
                    self._df_pending[self._source_id_key]
                )
            )
        else:
            # Normal dedup - just description
            df_with_results = self._df_pending.withColumn(
                "search_results_array",
                vector_search_results_udf(self._df_pending[self._merged_desc_column])
            )

        # Convert array-of-structs to formatted string for storage
        df_with_final_results = df_with_results.withColumn(
            "search_results",
            expr("""
              concat_ws('], [', transform(search_results_array, x ->
                concat(x.text, ', ', x.lakefusion_id, ', ', cast(x.score as string))
              ))
            """).alias("search_results")
        )

        self._stats['records_searched'] = self._stats.get('pending_count', 0)
        self._df_results = df_with_final_results

        return {'records_searched': self._stats['records_searched']}

    @step(order=7, name="Deduplicate Results", returns="DataFrame with deduplicated results")
    def step_deduplicate_results(self) -> Dict[str, Any]:
        """Step 8: Deduplicate results."""
        if self._df_results is None:
            self.logger.info("No results to deduplicate")
            return {'dedup_count': 0}

        df_deduped = self._df_results.dropDuplicates([self._source_id_key])

        self._df_deduped = df_deduped

        return {'status': 'deduplicated'}

    @step(order=8, name="Merge Results", returns="Merge statistics")
    def step_merge_results(self) -> Dict[str, Any]:
        """Step 9: Merge results to source table."""
        if self._df_deduped is None:
            print("No deduplicated results to merge")
            return {'records_updated': 0}

        from delta.tables import DeltaTable

        delta_table = DeltaTable.forName(self.spark, self._source_table)

        delta_table.alias("target").merge(
            source=self._df_deduped.alias("source"),
            condition=f"target.{self._source_id_key} = source.{self._source_id_key}"
        ).whenMatchedUpdate(
            set={"search_results": "source.search_results"}
        ).execute()

        print(f"Merge completed to {self._source_table}")

        self._stats['records_updated'] = self._stats.get('pending_count', 0)

        return {'records_updated': self._stats['records_updated']}

    @step(order=9, name="Optimize Table", returns="None")
    def step_optimize_table(self) -> None:
        """Step 10: Optimize source table."""
        self.spark.sql(f"OPTIMIZE {self._source_table} ZORDER BY ({self._source_id_key})")
        self.logger.info(f"Optimization completed")
        self.logger.info(f"  Z-Ordered by: {self._source_id_key}")

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Perform vector search for experiment.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 0: For single source, clone master to unified_dedup
            if self._is_single_source:
                self.step_process_unified_dedup_table()

            # Step 1: Validate embedding endpoint
            self.step_validate_embedding_endpoint()

            # Step 2: Setup vector search endpoint
            self.step_setup_vs_endpoint()

            # Step 3: Wait for VS endpoint
            self.step_wait_for_vs_endpoint()

            # Step 4: Create/sync vector search index
            self.step_create_or_sync_index()

            # Step 5: Filter records for vector search
            filter_result = self.step_filter_pending_records()

            if not filter_result.get('has_records', False):
                return TaskResult.skipped(
                    message="No records to process - all records already have search results",
                    task_name=self.context.task_name,
                    task_values={
                        'vector_search_complete': True,
                        'records_searched': 0
                    }
                )

            # Step 6: Execute vector search
            self.step_execute_vector_search()

            # Step 7: Deduplicate results
            self.step_deduplicate_results()

            # Step 8: Merge results to source table
            self.step_merge_results()

            # Step 9: Optimize table
            self.step_optimize_table()

            return TaskResult.success(
                message=f"{self._mode_name} vector search completed for {self._stats['records_searched']} records",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'vector_search_complete': True,
                    'records_searched': self._stats.get('records_searched', 0)
                }
            )

        except Exception as e:
            raise RuntimeError(f"Vector search failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate vector search results."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            records_searched = self._stats.get('records_searched', 0)
            records_updated = self._stats.get('records_updated', 0)

            validation = ValidationResult(
                passed=records_updated > 0 or records_searched == 0,
                message=f"Vector search results merged to source table",
                expected=records_searched,
                actual=records_updated
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("vector_search_complete", True)
                self.dbutils.jobs.taskValues.set("records_searched",
                    self._stats.get('records_searched', 0))
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _get_optimal_partitions(self, row_count: int, rows_per_partition: int = 50) -> int:
        """
        Calculate optimal partition count based on data size.
        For Vector Search UDFs:
        - Smaller partitions = more parallel API calls
        - But too small = task scheduling overhead
        - Sweet spot: 20-100 rows per partition for API workloads

        Args:
            row_count: Total number of rows
            rows_per_partition: Target rows per partition (default 50 for API workloads)

        Returns:
            Optimal partition count
        """
        # Tiered approach based on data size
        if row_count <= 100:
            # Very small: 10-20 rows per partition
            partitions = max(5, row_count // 10)
        elif row_count <= 1000:
            # Small: 20-30 rows per partition
            partitions = max(20, row_count // 25)
        elif row_count <= 10000:
            # Medium: 30-50 rows per partition
            partitions = max(50, row_count // 40)
        elif row_count <= 100000:
            # Large: 50-100 rows per partition
            partitions = max(200, row_count // 75)
        elif row_count <= 1000000:
            # Very large: 100-200 rows per partition
            partitions = max(1000, row_count // 150)
        else:
            # Massive: 200-500 rows per partition
            partitions = max(2000, min(5000, row_count // 300))

        return partitions
