"""
Load Experiment Data Executor.

Loads data for Match Maven experiments with record range limits.
Supports both single-source (golden dedup) and multi-source (normal dedup) modes.

Key Features:
    - Processes limited record ranges [record_start, record_end]
    - For single-source: Loads primary to master, clones to unified_dedup
    - For multi-source: Loads primary to master, secondary to unified
    - Generates lakefusion_id and surrogate_key for records
    - Creates attributes_combined from match attributes
"""

import json
from math import ceil as math_ceil
from typing import Any, Dict, List, Optional

from pyspark.sql.functions import (
    col, lit, udf, concat_ws, row_number
)
from pyspark.sql.types import (
    StringType, IntegerType, LongType, DoubleType, FloatType,
    BooleanType, DateType, TimestampType, DecimalType
)
from pyspark.sql.window import Window

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class LoadExperimentDataExecutor(BaseStepTask):
    """
    Executor for loading experiment data in Match Maven pipeline.

    Loads data with record range limits for quick experiment testing.
    Supports both single-source and multi-source entity configurations.

    Workflow:
        For Single-Source:
            1. Load primary source records within range
            2. Generate lakefusion_id and surrogate_key
            3. Insert into master table
            4. Clone master to unified_deduplicate

        For Multi-Source:
            1. Load ALL primary records to master (initial load only)
            2. Load secondary records with proportional limits
            3. Insert secondaries into unified with ACTIVE status
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the load experiment data task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}

        # Step intermediate results
        self._primary_table: Optional[str] = None
        self._primary_key: Optional[str] = None
        self._entity_attributes: List[str] = []
        self._entity_attributes_datatype: Dict[str, str] = {}
        self._match_attributes: List[str] = []
        self._attributes_mapping: List[Dict] = []
        self._dataset_tables: List[str] = []
        self._is_single_source: bool = False
        self._processed_records: List[int] = [0, 2000]
        self._record_start: int = 0
        self._record_end: int = 2000
        self._record_limit: int = 2000
        self._master_table: Optional[str] = None
        self._unified_table: Optional[str] = None
        self._unified_dedup_table: Optional[str] = None
        self._secondary_tables: List[str] = []
        self._is_initial_load: bool = False
        self._generate_lakefusion_id = None
        self._generate_surrogate_key = None
        self._RecordStatus = None
        self._generate_lakefusion_id_udf = None
        self._generate_surrogate_key_udf = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """PRE phase: Parse parameters and setup configuration."""
        self.print_header("LOAD EXPERIMENT DATA")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id}")

        params = self.context.params
        self._primary_table = params.get('primary_table')
        self._primary_key = params.get('primary_key')
        self._entity_attributes = params.get('entity_attributes', [])
        self._entity_attributes_datatype = params.get('entity_attributes_datatype', {})
        self._match_attributes = params.get('match_attributes', [])
        self._attributes_mapping = params.get('attributes_mapping', [])
        self._dataset_tables = params.get('dataset_tables', [])
        self._is_single_source = params.get('is_single_source', False)
        self._processed_records = params.get('processed_records', [0, 2000])

        # Parse JSON strings if needed
        if isinstance(self._entity_attributes, str):
            self._entity_attributes = json.loads(self._entity_attributes)
        if isinstance(self._entity_attributes_datatype, str):
            self._entity_attributes_datatype = json.loads(self._entity_attributes_datatype)
        if isinstance(self._match_attributes, str):
            self._match_attributes = json.loads(self._match_attributes)
        if isinstance(self._attributes_mapping, str):
            self._attributes_mapping = json.loads(self._attributes_mapping)
        if isinstance(self._dataset_tables, str):
            self._dataset_tables = json.loads(self._dataset_tables)
        if isinstance(self._processed_records, str):
            self._processed_records = json.loads(self._processed_records)
        if isinstance(self._is_single_source, str):
            self._is_single_source = self._is_single_source.lower() == "true"

        # Parse record range
        self._record_start = self._processed_records[0] if self._processed_records else 0
        self._record_end = self._processed_records[1] if len(self._processed_records) > 1 else 2000
        self._record_limit = self._record_end - self._record_start

        self.logger.info(f"Is Single Source: {self._is_single_source}")
        self.logger.info(f"Processed Records Range: [{self._record_start}, {self._record_end}]")
        self.logger.info(f"Record Limit: {self._record_limit}")
        self.logger.info(f"Primary Table: {self._primary_table}")

        # Build table names
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._master_table = f"{self.context.catalog_name}.gold.{self.context.entity}_master{experiment_suffix}"
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"
        self._unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate{experiment_suffix}"

        # Derive secondary tables
        self._secondary_tables = [t for t in self._dataset_tables if t != self._primary_table]

        self.logger.info(f"\nTable Names:")
        self.logger.info(f"  Master: {self._master_table}")
        if self._is_single_source:
            self.logger.info(f"  Unified Dedup: {self._unified_dedup_table}")
        else:
            self.logger.info(f"  Unified: {self._unified_table}")
            self.logger.info(f"  Secondary Tables: {len(self._secondary_tables)}")

    @step(order=1, name="Initialize UDFs", returns="None - creates ID generator UDFs")
    def step_initialize_udfs(self) -> Dict[str, Any]:
        """Step 1: Import ID generators and create UDFs."""
        from lakefusion_core_engine.identifiers import generate_lakefusion_id, generate_surrogate_key
        from lakefusion_core_engine.models import RecordStatus

        self._generate_lakefusion_id = generate_lakefusion_id
        self._generate_surrogate_key = generate_surrogate_key
        self._RecordStatus = RecordStatus

        # Create UDFs
        self._generate_lakefusion_id_udf = udf(lambda: generate_lakefusion_id(), StringType())
        self._generate_surrogate_key_udf = udf(
            lambda source_path, source_id: generate_surrogate_key(source_path, str(source_id)),
            StringType()
        )

        self.logger.info("ID generator UDFs initialized")
        return {'udfs_initialized': True}

    @step(order=2, name="Check Initial Load", returns="Boolean indicating initial load status")
    def step_check_initial_load(self) -> Dict[str, Any]:
        """Step 2: Check if this is an initial load."""
        master_count_before = self.spark.table(self._master_table).count()
        is_initial_load = (self._record_start == 0)

        self._stats['master_count_before'] = master_count_before
        self._stats['is_initial_load'] = is_initial_load
        self._is_initial_load = is_initial_load

        self.logger.info(f"Master table current count: {master_count_before}")
        self.logger.info(f"Is initial load: {is_initial_load}")

        return {'master_count_before': master_count_before, 'is_initial_load': is_initial_load}

    @step(order=3, name="Load Data", returns="Statistics about loaded records")
    def step_load_data(self) -> Dict[str, Any]:
        """Step 3: Load data based on mode (single-source or multi-source)."""
        if self._is_single_source:
            return self._load_single_source()
        else:
            return self._load_multi_source(self._is_initial_load)

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Load experiment data.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Initialize UDFs
            self.step_initialize_udfs()

            # Step 2: Check initial load
            self.step_check_initial_load()

            # Step 3: Load data based on mode
            self.step_load_data()

            return TaskResult.success(
                message=f"Loaded experiment data for {self.context.entity}",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'records_loaded': self._stats.get('total_records_loaded', 0)
                }
            )

        except Exception as e:
            raise RuntimeError(f"Failed to load experiment data: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate data loading."""
        if result.is_failed:
            return result

        try:
            total_loaded = self._stats.get('total_records_loaded', 0)

            validation = ValidationResult(
                passed=total_loaded >= 0,
                message=f"Loaded {total_loaded} records",
                expected=self._record_limit,
                actual=total_loaded
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set(
                    "records_loaded",
                    self._stats.get('total_records_loaded', 0)
                )
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _get_spark_data_type(self, dtype_str: str):
        """Convert string data type to Spark DataType."""
        dtype_map = {
            'bigint': LongType(),
            'boolean': BooleanType(),
            'char': StringType(),
            'varchar': StringType(),
            'date': DateType(),
            'double precision': DoubleType(),
            'integer': IntegerType(),
            'numeric': FloatType(),
            'real': FloatType(),
            'smallint': IntegerType(),
            'text': StringType(),
            'timestamp': TimestampType(),
            'string': StringType(),
            'int': IntegerType(),
            'long': LongType(),
            'double': DoubleType(),
            'float': FloatType(),
            'decimal': DecimalType(10, 2),
        }
        return dtype_map.get(dtype_str.lower(), StringType())

    def _apply_attribute_mapping(self, df, table_name: str):
        """Apply attribute mapping with type casting to a DataFrame."""
        # Find mapping for this table
        table_mapping = None
        for mapping_entry in self._attributes_mapping:
            if table_name in mapping_entry:
                table_mapping = mapping_entry[table_name]
                break

        if not table_mapping:
            raise ValueError(f"No attribute mapping found for table: {table_name}")

        # Build select expressions
        select_exprs = []
        mapped_columns = set()

        for entity_attr, dataset_attr in table_mapping.items():
            if dataset_attr in df.columns:
                target_dtype_str = self._entity_attributes_datatype.get(entity_attr, 'string')
                target_spark_dtype = self._get_spark_data_type(target_dtype_str)
                select_exprs.append(col(dataset_attr).cast(target_spark_dtype).alias(entity_attr))
                mapped_columns.add(entity_attr)

        # Add missing attributes as NULL
        for attr in self._entity_attributes:
            if attr not in mapped_columns and attr != "lakefusion_id":
                dtype_str = self._entity_attributes_datatype.get(attr, 'string')
                spark_dtype = self._get_spark_data_type(dtype_str)
                select_exprs.append(lit(None).cast(spark_dtype).alias(attr))

        return df.select(*select_exprs)

    def _load_single_source(self) -> Dict[str, Any]:
        """Load data for single-source (golden dedup) mode."""
        self.logger.info("\n  SINGLE SOURCE MODE - Loading Primary with Record Limit")

        # Read primary source
        primary_df = self.spark.read.table(self._primary_table)

        # Apply attribute mapping
        mapped_df = self._apply_attribute_mapping(primary_df, self._primary_table)

        # Add row numbers for limiting
        window_spec = Window.orderBy(col(self._primary_key))
        mapped_df = mapped_df.withColumn("_row_num", row_number().over(window_spec))

        # Filter to specified range (1-indexed row_number)
        filtered_df = mapped_df.filter(
            (col("_row_num") > self._record_start) & (col("_row_num") <= self._record_end)
        ).drop("_row_num")

        records_to_load = filtered_df.count()
        self.logger.info(f"  Records in range [{self._record_start+1}, {self._record_end}]: {records_to_load}")

        if records_to_load == 0:
            self.logger.info("\n  No records to load in specified range")
            self._stats['total_records_loaded'] = 0
            return {'records_loaded': 0, 'mode': 'single-source'}

        # Generate lakefusion_id
        id_df = filtered_df.withColumn("lakefusion_id", self._generate_lakefusion_id_udf())

        # Add source metadata
        id_df = id_df.withColumn("source_path", lit(self._primary_table)) \
                     .withColumn("source_id", col(self._primary_key).cast("string"))

        # Generate surrogate_key
        id_df = id_df.withColumn(
            "surrogate_key",
            self._generate_surrogate_key_udf(col("source_path"), col("source_id"))
        )

        # Create attributes_combined
        combine_attrs = [attr for attr in self._match_attributes if attr in id_df.columns]
        id_df = id_df.withColumn(
            "attributes_combined",
            concat_ws(" | ", *[col(attr) for attr in combine_attrs])
        )

        # Prepare master insert
        master_columns = ["lakefusion_id"] + [attr for attr in self._entity_attributes if attr != "lakefusion_id"] + ["attributes_combined"]
        master_insert_df = id_df.select(*master_columns)

        # Insert into master table
        master_insert_df.write.format("delta").mode("append").saveAsTable(self._master_table)
        self._stats['master_records_inserted'] = records_to_load

        # Clone master to unified_dedup for self-comparison
        self.logger.info("\n  Cloning Master to Unified Dedup for self-comparison...")

        master_df = self.spark.table(self._master_table)
        unified_dedup_df = master_df.withColumn("search_results", lit("").cast(StringType())) \
                                     .withColumn("scoring_results", lit("").cast(StringType()))

        # Overwrite unified_dedup
        unified_dedup_df.write.format("delta").mode("overwrite").saveAsTable(self._unified_dedup_table)

        self._stats['unified_dedup_records'] = unified_dedup_df.count()
        self._stats['total_records_loaded'] = records_to_load
        self.logger.info(f"  All records have empty search_results and scoring_results")

        return {'records_loaded': records_to_load, 'mode': 'single-source'}

    def _load_multi_source(self, is_initial_load: bool) -> Dict[str, Any]:
        """Load data for multi-source mode."""
        self.logger.info("\n  MULTI SOURCE MODE")

        total_records_loaded = 0

        # Step 1: Load primary to master (initial load only)
        if is_initial_load:
            self.logger.info("\n  STEP 1: Loading ALL Primary Records to Master")

            primary_df = self.spark.read.table(self._primary_table)
            mapped_df = self._apply_attribute_mapping(primary_df, self._primary_table)

            # Generate lakefusion_id
            id_df = mapped_df.withColumn("lakefusion_id", self._generate_lakefusion_id_udf())

            # Add source metadata
            id_df = id_df.withColumn("source_path", lit(self._primary_table)) \
                         .withColumn("source_id", col(self._primary_key).cast("string"))

            # Generate surrogate_key
            id_df = id_df.withColumn(
                "surrogate_key",
                self._generate_surrogate_key_udf(col("source_path"), col("source_id"))
            )

            # Create attributes_combined
            combine_attrs = [attr for attr in self._match_attributes if attr in id_df.columns]
            id_df = id_df.withColumn(
                "attributes_combined",
                concat_ws(" | ", *[col(attr) for attr in combine_attrs])
            )

            # Prepare and insert into master
            master_columns = ["lakefusion_id"] + [attr for attr in self._entity_attributes if attr != "lakefusion_id"] + ["attributes_combined"]
            master_insert_df = id_df.select(*master_columns)
            master_insert_df.write.format("delta").mode("append").saveAsTable(self._master_table)

            self._stats['master_records_inserted'] = master_insert_df.count()
            self.logger.info(f"    Inserted {self._stats['master_records_inserted']} records into master")
        else:
            self.logger.info("\n  STEP 1: SKIPPING Primary Load (Incremental)")

        # Step 2: Load secondary records with limit
        self.logger.info("\n  STEP 2: Loading Secondary Records with Limit")

        if len(self._secondary_tables) == 0:
            self.logger.info("    No secondary tables to process")
        else:
            num_secondary = len(self._secondary_tables)
            records_per_source = math_ceil(self._record_limit / num_secondary)
            remaining_limit = self._record_limit

            self.logger.info(f"    Secondary tables: {num_secondary}")
            self.logger.info(f"    Total record limit: {self._record_limit}")
            self.logger.info(f"    Records per source: {records_per_source}")

            for idx, secondary_table in enumerate(self._secondary_tables, 1):
                self.logger.info(f"\n    [{idx}/{num_secondary}] Processing: {secondary_table}")

                if remaining_limit <= 0:
                    self.logger.info(f"      Record limit reached, skipping")
                    continue

                secondary_df = self.spark.read.table(secondary_table)

                # Apply attribute mapping
                mapped_df = self._apply_attribute_mapping(secondary_df, secondary_table)

                # Add row numbers for range filtering
                window_spec = Window.orderBy(col(self._primary_key))
                mapped_df = mapped_df.withColumn("_row_num", row_number().over(window_spec))

                # Calculate range for this source
                source_start = int(self._record_start / num_secondary) if idx > 1 else self._record_start
                source_limit = min(records_per_source, remaining_limit)

                filtered_df = mapped_df.filter(
                    (col("_row_num") > source_start) &
                    (col("_row_num") <= source_start + source_limit)
                ).drop("_row_num")

                records_to_load = filtered_df.count()
                self.logger.info(f"      Records in range: {records_to_load}")

                if records_to_load == 0:
                    continue

                # Add source metadata
                mapped_df = filtered_df.withColumn("source_path", lit(secondary_table)) \
                                        .withColumn("source_id", col(self._primary_key).cast("string"))

                # Generate surrogate_key
                mapped_df = mapped_df.withColumn(
                    "surrogate_key",
                    self._generate_surrogate_key_udf(col("source_path"), col("source_id"))
                )

                # Create attributes_combined
                combine_attrs = [attr for attr in self._match_attributes if attr in mapped_df.columns]
                mapped_df = mapped_df.withColumn(
                    "attributes_combined",
                    concat_ws(" | ", *[col(attr) for attr in combine_attrs])
                )

                # Prepare for unified insert
                unified_select_cols = [
                    "surrogate_key",
                    "source_path",
                    "source_id",
                    lit(self._RecordStatus.ACTIVE.value).alias("record_status")
                ] + [col(attr) for attr in self._entity_attributes if attr != "lakefusion_id"] + [
                    "attributes_combined",
                    lit("").alias("search_results"),
                    lit("").alias("scoring_results")
                ]

                unified_insert_df = mapped_df.select(*unified_select_cols)

                # Insert into unified
                before_unified = self.spark.table(self._unified_table).count()
                unified_insert_df.write.format("delta").mode("append").saveAsTable(self._unified_table)
                after_unified = self.spark.table(self._unified_table).count()
                inserted = after_unified - before_unified

                self.logger.info(f"      Inserted {inserted} records into Unified (status=ACTIVE)")

                total_records_loaded += inserted
                remaining_limit -= inserted

        self._stats['total_records_loaded'] = total_records_loaded
        self.logger.info(f"\n  Total records loaded: {total_records_loaded}")

        return {'records_loaded': total_records_loaded, 'mode': 'multi-source'}
