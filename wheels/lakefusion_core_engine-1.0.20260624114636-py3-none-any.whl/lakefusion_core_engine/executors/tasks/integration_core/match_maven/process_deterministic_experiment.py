"""
Process Deterministic Executor for experiment-based deduplication.

Handles match rules for entity matching using the
experiment-2 schema (rule["name"], conditions[].attribute, function,
logical_operator, action_on_match).

Workflow:
1. Load unified and master tables (with is_single_source-aware filters)
2. Filter and prepare data (parse search results, explode candidates)
3. Join with master table
4. Parse and apply deterministic rules
5. Extract matches (is_single_source-aware select)
6. Save to unified_deterministic table (merge condition uses source_id_key)
"""

from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType, NullType
from delta.tables import DeltaTable

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ProcessDeterministicExecutor(BaseStepTask):
    """
    Executor for processing deterministic matches (Experiment-2 schema).

    Applies configurable matching rules to identify deterministic matches
    between unified records and master records.

    Rule schema (experiment-2):
        {
            "name": "Rule1",
            "conditions": [
                {
                    "attribute": "fname",       # field name (was "column")
                    "match_type": "exact",      # "exact" | "fuzzy"
                    "function": None,           # "levenshtein" | "jaro_winkler" | "soundex"
                    "threshold": None           # float for fuzzy; None for exact
                }
            ],
            "logical_operator": "AND",          # was "logical_op"
            "action_on_match": "auto-merge"     # "auto-merge" | "potential-match" | "not-a-match"
        }
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.match_count = 0

        # Default rules config - can be overridden via params
        # Uses experiment-2 schema keys
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self.rules_config = context.params.get('rules_config', [])

        # Set source_id_key based on is_single_source
        is_single_source = context.params.get('is_single_source', False)
        if isinstance(is_single_source, str):
            is_single_source = is_single_source.lower() == "true"
        self._is_single_source = is_single_source

        _unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"
        _unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate{experiment_suffix}"
        _unified_deterministic_deduplicate_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deterministic_deduplicate{experiment_suffix}"
        _unified_deterministic_table=f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deterministic{experiment_suffix}"
                
        
        self._unified_deterministic_table= _unified_deterministic_deduplicate_table if self._is_single_source else _unified_deterministic_table
        self._unified_table = _unified_dedup_table if self._is_single_source else _unified_table

        if self._is_single_source:
            self._source_id_key = "lakefusion_id"
            self._mode_name = "GOLDEN DEDUP (Single Source)"
            self._filter_by_status = False
            self._exclude_self_matches = True
        else:
            self._source_id_key = "surrogate_key"
            self._mode_name = "NORMAL DEDUP (Multi Source)"
            self._filter_by_status = True
            self._exclude_self_matches = False

        
        
        # Instance variables for intermediate results (step-based execution)
        self.df_unified = None
        self.df_master = None
        self.df_cleaned = None
        self.df_exploded = None
        self.df_result = None
        self.df_parsed = None
        self.df_with_rules = None
        self.df_final = None

        # Tracking variables
        self.initial_count = 0
        self._is_empty = False

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""

       
        
        print("=" * 80)
        print("PROCESS MATCH RULES (EXPERIMENT-2)")
        print("=" * 80)
        print(f"Entity:                     {self.context.entity}")
        print(f"Catalog:                    {self.context.catalog_name}")
        print(f"Experiment ID:              {self.context.experiment_id or 'None'}")
        print(f"Is Single Source:           {self._is_single_source}")
        print(f"Source ID Key:              {self._source_id_key}")
        print(f"Unified Table:              {self._unified_table}")
        print(f"Master Table:               {self.context.master_table}")
        print(f"Unified Deterministic Table:{self._unified_deterministic_table}")
        print(f"Rules:                      {len(self.rules_config)}")
        print("=" * 80)

    # ─────────────────────────────────────────────────────────────
    # Private helpers
    # ─────────────────────────────────────────────────────────────

    def _build_dynamic_struct(
        self,
        x_col,
        attributes: List[str],
        entity_attributes_datatype: Dict[str, str],
    ):
        """
        Build a typed struct from a pipe-separated master attribute string.

        Format:  "val1 | val2 | ... | valN, <lakefusion_id>"
        Each positional value is kept as string for uniform fuzzy matching;
        downstream rule expressions cast if needed.
        """
        struct_fields = []
        parts = F.split(F.split(x_col, ",")[0], "\\|")

        for idx, attr in enumerate(attributes):
            raw_value = F.trim(F.element_at(parts, idx + 1))
            struct_fields.append(raw_value.alias(f"{attr}_matches"))

        lakefusion_id = F.trim(F.regexp_extract(x_col, r",\s*([a-f0-9]{32})", 1))
        struct_fields.append(lakefusion_id.alias("lakefusion_id"))

        return F.struct(*struct_fields)

    def _build_rule(self, rule: Dict) -> "Column":
        """
        Build a Spark filter-array expression for a single rule dict.

        Experiment-2 schema keys used:
            rule["name"]                      → result column alias
            rule["conditions"][]["attribute"] → field name (was "column")
            rule["conditions"][]["function"]  → fuzzy function (was "fuzzy_type")
            rule["conditions"][]["threshold"] → similarity threshold
            rule["logical_operator"]          → "AND" | "OR" (was "logical_op")
        """
        rule_name = rule["name"]
        conditions = rule["conditions"]
        logical_op = rule.get("logical_operator", "AND")

        condition_parts = []

        for cond in conditions:
            attr       = cond["attribute"]                  # ← experiment-2 key
            match_type = cond.get("match_type", "exact")
            fuzzy_func = cond.get("function")               # ← experiment-2 key
            threshold  = cond.get("threshold")

            if match_type == "exact":
                condition_parts.append(f"({attr} = x.{attr}_matches)")

            elif match_type == "fuzzy":
                if fuzzy_func == "levenshtein":
                    # threshold is a similarity ratio (0–1):
                    # similarity = 1 - (distance / max_len)  ≥  threshold
                    # NOTE: >= threshold (NOT <= (1 - threshold)) — matches notebook logic
                    condition_parts.append(
                        f"(levenshtein({attr}, x.{attr}_matches) / "
                        f"greatest(length({attr}), length(x.{attr}_matches))"
                        f" >= {threshold})"
                    )
                elif fuzzy_func == "jaro_winkler":
                    condition_parts.append(
                        f"(jaro_winkler_similarity({attr}, x.{attr}_matches)"
                        f" >= {threshold})"
                    )
                elif fuzzy_func == "soundex":
                    condition_parts.append(
                        f"(soundex({attr}) = soundex(x.{attr}_matches))"
                    )
                else:
                    raise ValueError(f"Unsupported fuzzy function: {fuzzy_func}")
            else:
                raise ValueError(f"Unsupported match_type: {match_type}")

        combined_condition = f" {logical_op} ".join(condition_parts)
        expr_str = f"filter(search_result_parsed, x -> ({combined_condition}))"

        return F.expr(expr_str).alias(rule_name)

    def _apply_rules(self, df_parsed: DataFrame) -> DataFrame:
        """Apply all configured rules, adding a '<name>_results' column each."""
        df_out = df_parsed
        for rule in self.rules_config:
            df_out = df_out.withColumn(
                f"{rule['name']}_results",
                self._build_rule(rule),
            )
        return df_out

    def _compute_deterministic_matches(self, df_with_rules: DataFrame) -> DataFrame:
        """
        Flag deterministic matches and pick the first matching rule.

        All rules are considered; action_on_match is stored in the
        deterministic_match_result struct so callers can apply business logic
        (auto-merge / potential-match / not-a-match) after extraction.
        """
        match_cols = [f"{r['name']}_results" for r in self.rules_config]

        # 1. Flag: any non-empty rule array → deterministic match candidate
        is_match_expr = F.lit(False)
        for c in match_cols:
            is_match_expr = is_match_expr | (F.size(F.col(c)) > 0)
        df_out = df_with_rules.withColumn("is_deterministic_match", is_match_expr)

        # 2. Coalesce: first matching rule wins (preserves priority order)
        when_exprs = []
        for rule in self.rules_config:
            c      = f"{rule['name']}_results"
            action = rule["action_on_match"]
            when_exprs.append(
                F.when(
                    F.size(F.col(c)) > 0,
                    F.struct(
                        F.col(c).alias("rule_result"),
                        F.lit(rule["name"]).alias("rule_name"),
                        F.lit(action).alias("action_on_match"),   # ← new in experiment-2
                    ),
                )
            )

        df_out = df_out.withColumn(
            "deterministic_match_result",
            F.coalesce(*when_exprs) if when_exprs else F.lit(None),
        )

        return df_out

    # ─────────────────────────────────────────────────────────────
    # Steps
    # ─────────────────────────────────────────────────────────────

    @step(order=1, name="Load Tables", returns="DataFrames for unified and master tables")
    def step_load_tables(self) -> Dict[str, Any]:
        """
        Step 1: Load unified and master tables with is_single_source-aware filters.

        Single source: no record_status filter (not applicable for dedup).
        Multi source:  filter record_status = 'ACTIVE'.
        Both:          filter search_results != '' and scoring_results == ''.
        """
        spark = self.context.spark

        if self._is_single_source:
            self.df_unified = (
                spark.read.table(self._unified_table)
                .filter(F.col("search_results") != "")
                .filter(F.col("scoring_results") == "")
            )
        else:
            self.df_unified = (
                spark.read.table(self._unified_table)
                .filter(F.col("record_status") == "ACTIVE")
                .filter(F.col("search_results") != "")
                .filter(F.col("scoring_results") == "")
            )

        self.df_master = spark.read.table(self.context.master_table)

        print(f"  Loaded unified table: {self._unified_table}")
        print(f"  Loaded master table:  {self.context.master_table}")

        return {
            'unified_table_loaded': True,
            'master_table_loaded': True,
        }

    @step(order=2, name="Filter and Prepare Data", returns="Filtered DataFrame with parsed search results")
    def step_filter_and_prepare(self) -> Dict[str, Any]:
        """
        Step 2: Count records and parse search_results into an exploded candidate array.

        Parsing:
          - Strip outer brackets, split on '], [' to get individual candidate strings.
          - Extract the master lakefusion_id (second comma-separated token) from each.
          - Explode to one row per candidate master record.
        """
        #self.initial_count = self.df_unified.count()
        #print(f"  Records to process: {self.initial_count}")

        # if self.initial_count == 0:
        #     self._is_empty = True
        #     return {'records_to_process': 0, 'is_empty': True}

        # Strip outer brackets and split into individual candidate strings
        self.df_cleaned = self.df_unified.withColumn(
            "search_results_array",
            F.split(
                F.regexp_replace(F.col("search_results"), r"^\[|\]$", ""),
                "\\], \\[",
            ),
        )

        # Extract the master lakefusion_id from each candidate string
        self.df_cleaned = self.df_cleaned.withColumn(
            "search_results_master_lakefusion_ids",
            F.transform(
                F.col("search_results_array"),
                lambda x: F.trim(F.split(x, ",")[1]),
            ),
        )

        # One row per candidate master record
        self.df_exploded = self.df_cleaned.withColumn(
            "search_results_master_lakefusion_ids",
            F.explode("search_results_master_lakefusion_ids"),
        )

        return {'records_to_process': self.initial_count, 'is_empty': False}

    @step(order=3, name="Join with Master Table", returns="DataFrame joined with master records")
    def step_join_with_master(self) -> Dict[str, Any]:
        """Step 3: Inner-join exploded unified rows with the master table."""
        # if self._is_empty:
        #     print("  Skipping – no records to process")
        #     return {'skipped': True}

        attributes = self.context.attributes

        self.df_exploded = self.df_exploded.alias("exp")
        self.df_master = self.df_master.alias("mst")

        df_joined = self.df_exploded.join(
            self.df_master,
            F.col("exp.search_results_master_lakefusion_ids") == F.col("mst.lakefusion_id"),
            "inner",
        )

        # Build pipe-separated attribute string + lakefusion_id for each master row
        df_joined = df_joined.withColumn(
            "attributes_combined_master",
            F.concat(
                F.concat_ws(
                    " | ",
                    *[
                        F.when(F.trim(F.col(f"mst.{c}")) == "", "null")
                         .otherwise(
                             F.coalesce(F.col(f"mst.{c}").cast("string"), F.lit("null"))
                         )
                        for c in attributes
                    ],
                ),
                F.lit(", "),
                F.coalesce(F.col("mst.lakefusion_id").cast("string"), F.lit("null")),
            ),
        )

        # Group back: one unified row → list of master candidate strings
        # Use collect_set to avoid duplicates
        group_cols = [f"exp.{c}" for c in self.df_exploded.columns]
        self.df_result = (
            df_joined
            .groupBy(*group_cols)
            .agg(
                F.collect_set("attributes_combined_master").alias(
                    "attributes_combined_master_array"
                )
            )
            .select(
                "exp.*",
                "attributes_combined_master_array",
                "search_results_master_lakefusion_ids",
            )
        )

        print("  Joined with master table")

        return {'joined': True}

    @step(order=4, name="Parse and Apply Rules", returns="DataFrame with rule results")
    def step_parse_and_apply_rules(self) -> Dict[str, Any]:
        """Step 4: Parse master candidate strings into structs and apply rules."""
        # if self._is_empty:
        #     print("  Skipping – no records to process")
        #     return {'skipped': True}

        attributes = self.context.attributes
        entity_attributes_datatype = self.context.entity_attributes_datatype

        # Parse each master candidate string into a struct
        self.df_parsed = self.df_result.withColumn(
            "search_result_parsed",
            F.transform(
                F.col("attributes_combined_master_array"),
                lambda x: self._build_dynamic_struct(x, attributes, entity_attributes_datatype),
            ),
        )

        # Apply rules → '<name>_results' columns
        self.df_with_rules = self._apply_rules(self.df_parsed)

        # Compute first-match deterministic result
        self.df_final = self._compute_deterministic_matches(self.df_with_rules)

        print(f"  Applied {len(self.rules_config)} rules")

        return {'rules_applied': len(self.rules_config)}

    @step(order=5, name="Extract Matches", returns="DataFrame with extracted match results")
    def step_extract_matches(self) -> Dict[str, Any]:
        """
        Step 5: Explode matched rule results into individual rows.

        Column selection is is_single_source-aware:
          - Multi source:   surrogate_key + search_results_master_lakefusion_ids → lakefusion_id
          - Single source:  lakefusion_id only (no surrogate_key column)
        """
       

        df_exploded = self.df_final.withColumn(
            "rule",
            F.explode("deterministic_match_result.rule_result"),
        )

        # All struct fields except lakefusion_id become the "id" display value
        selected_rule_fields = [
            f.name
            for f in df_exploded.schema["rule"].dataType.fields
            if f.name != "lakefusion_id"
        ]
        concat_col = F.concat_ws(" | ", *[F.col(f"rule.{f}") for f in selected_rule_fields])

        # Build the exploded_result struct
        # action_on_match replaces the hard-coded "MATCH" literal (experiment-2)
        df_exploded = df_exploded.withColumn(
            "exploded_result",
            F.struct(
                concat_col.alias("id"),
                F.col("deterministic_match_result.action_on_match").alias("match"),
                F.lit(1.0).cast("double").alias("score"),
                F.concat(
                    F.lit("Due to Deterministic Match of Rule: "),
                    F.col("deterministic_match_result.rule_name"),
                ).alias("reason"),
                F.col("rule.lakefusion_id").alias("lakefusion_id"),
            ),
        )

        # is_single_source-aware column selection — mirrors notebook branching
        if not self._is_single_source:
            self.df_final = (
                df_exploded
                .filter(F.col("is_deterministic_match") == F.lit(True))
                .drop("rule")
                .select(
                    "surrogate_key",
                    "search_results_master_lakefusion_ids",
                    "attributes_combined",
                    "search_results",
                    "deterministic_match_result",
                    "is_deterministic_match",
                    "exploded_result",
                )
                .withColumnRenamed("search_results_master_lakefusion_ids", "lakefusion_id")
            )
        else:
            self.df_final = (
                df_exploded
                .filter(F.col("is_deterministic_match") == F.lit(True))
                .drop("rule")
                .select(
                    "lakefusion_id",
                    "attributes_combined",
                    "search_results",
                    "deterministic_match_result",
                    "is_deterministic_match",
                    "exploded_result",
                )
            )

        self.match_count = self.df_final.count()
        print(f"  Deterministic matches found: {self.match_count}")

        return {'matches_found': self.match_count}

    @step(order=6, name="Save to Deterministic Table", returns="Table save status")
    def step_save_to_table(self) -> Dict[str, Any]:
        """
        Step 6: Persist results to the unified deterministic table.

        - New table: overwrite + OPTIMIZE ZORDER BY source_id_key.
        - Existing table: MERGE on source_id_key (whenNotMatchedInsertAll),
          followed by OPTIMIZE ZORDER BY source_id_key.

        NOTE: merge condition uses self._source_id_key (surrogate_key or
        lakefusion_id), NOT the hardcoded id_key ("master_lakefusion_id").
        """
        # if self._is_empty:
        #     print("  Skipping – no records to process")
        #     return {'skipped': True}

        spark = self.context.spark
        unified_deterministic_table = self._unified_deterministic_table
        table_exists = spark.catalog.tableExists(unified_deterministic_table)

        if not table_exists:
            (
                self.df_final
                .write
                .mode("overwrite")
                .option("mergeSchema", "true")
                .saveAsTable(unified_deterministic_table)
            )
            print(f"  Created new table: {unified_deterministic_table}")
        else:
            delta_table = DeltaTable.forName(spark, unified_deterministic_table)
            (
                delta_table.alias("target")
                .merge(
                    source=self.df_final.alias("source"),
                    condition=f"target.{self._source_id_key} = source.{self._source_id_key}",
                )
                .whenNotMatchedInsertAll()
                .execute()
            )
            print(f"  Merged into existing table: {unified_deterministic_table}")

        # Optimize regardless of create vs merge path
        spark.sql(
            f"OPTIMIZE {unified_deterministic_table} ZORDER BY ({self._source_id_key})"
        )
        print(f"  Optimized table: {unified_deterministic_table}")

        return {
            'table_exists': table_exists,
            'match_count': self.match_count,
        }

    # ─────────────────────────────────────────────────────────────
    # Lifecycle methods
    # ─────────────────────────────────────────────────────────────

    def execute(self) -> TaskResult:
        """Execute the match rules workflow."""
        # Exit early if no rules configured
        if not len(self.rules_config):
            print("No deterministic rules configured — skipping")
            return TaskResult.success(
                message="No deterministic rules configured — skipping",
                task_name=self.context.task_name,
                metrics={'records_processed': 0, 'matches_found': 0, 'rules_applied': 0},
                task_values={'deterministic_complete': True},
            )

        self.step_load_tables()
        self.step_filter_and_prepare()

    

        self.step_join_with_master()
        self.step_parse_and_apply_rules()
        self.step_extract_matches()
        self.step_save_to_table()

        return TaskResult.success(
            message=f"Match rules completed — {self.match_count} matches found",
            task_name=self.context.task_name,
            metrics={
                'records_processed': self.initial_count,
                'matches_found': self.match_count,
                'rules_applied': len(self.rules_config),
            },
            task_values={
                'deterministic_complete': True,
            },
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Match rules completed"
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        print("\n" + "=" * 80)
        print("PROCESS DETERMINISTIC COMPLETE")
        print("=" * 80)

        if result.is_success:
            metrics = result.metrics
            print("\nSummary:")
            print(f"  Records processed: {metrics.get('records_processed', 0)}")
            print(f"  Matches found:     {metrics.get('matches_found', 0)}")
            print(f"  Rules applied:     {metrics.get('rules_applied', 0)}")

    def on_success(self, result: TaskResult) -> None:
        """Push task values to Databricks job context."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Log failure details."""
        print(f"  Process deterministic failed: {result.message}")
        if result.errors:
            for error in result.errors:
                print(f"  Error: {error}")