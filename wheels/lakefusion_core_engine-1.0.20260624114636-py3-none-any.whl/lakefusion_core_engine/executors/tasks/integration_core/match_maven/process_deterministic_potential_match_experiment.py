"""
Process Potential Match Experiment Executor.

Creates deterministic potential match table for Match Maven experiment analysis.
Shows ALL deterministic matches without threshold-based filtering.

Key Features:
    - Creates deterministic_potential_match table from unified_deterministic results
    - Queries from deterministic table (NOT processed_unified)
    - Shows ALL matches where is_deterministic_match = true
    - Aggregates matches per master record with counts
    - Stores match details with id, match, score, reason, lakefusion_id
"""

import json
from typing import Any, Dict

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ProcessDeterministicPotentialMatchExperimentExecutor(BaseStepTask):
    """
    Executor for creating deterministic potential match table in Match Maven experiments.

    Creates a table showing all deterministic matches per master record.
    Experiment mode shows ALL is_deterministic_match=true rows without status filtering.

    Data source: unified_deterministic table (not processed_unified).

    Workflow:
        1. Verify deterministic table exists and has records
        2. Build and execute potential match query
        3. Optimize table
        4. Generate summary statistics
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the process potential match experiment task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}

        # Step intermediate results
        self._deterministic_count: int = 0
        self._potential_count: int = 0
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """PRE phase: Validate inputs and setup configuration."""
        params = self.context.params
        self._attributes = params.get('attributes', [])
        self._is_single_source = params.get('is_single_source', False)

        if isinstance(self._attributes, str):
            self._attributes = json.loads(self._attributes)
        if isinstance(self._is_single_source, str):
            self._is_single_source = self._is_single_source.lower() == "true"

        # Set mode-specific configuration
        if self._is_single_source:
            self._mode_name = "GOLDEN DEDUP (Single Source)"
            self._source_id_key = "query_lakefusion_id"
            self._match_id_key = "match_lakefusion_id"
        else:
            self._mode_name = "NORMAL DEDUP (Multi Source)"
            self._source_id_key = "surrogate_key"
            self._match_id_key = "lakefusion_id"

        # Build table names
        experiment_suffix = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._master_table = f"{self.context.catalog_name}.gold.{self.context.entity}_master{experiment_suffix}"
        self._unified_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified{experiment_suffix}"
        self._unified_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deduplicate{experiment_suffix}"

        # Deterministic tables — primary data source for this executor
        self._unified_deterministic_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deterministic{experiment_suffix}"
        self._unified_deterministic_dedup_table = f"{self.context.catalog_name}.silver.{self.context.entity}_unified_deterministic_deduplicate{experiment_suffix}"

        # Output table — named 'deterministic_potential_match' to match notebook
        self._potential_match_table = f"{self.context.catalog_name}.silver.{self.context.entity}_deterministic_potential_match{experiment_suffix}"

        # Resolve mode-specific source and deterministic tables
        if self._is_single_source:
            self._source_table = self._unified_dedup_table
            self._deterministic_table = self._unified_deterministic_dedup_table
        else:
            self._source_table = self._unified_table
            self._deterministic_table = self._unified_deterministic_table

        self.print_header(f"PROCESS POTENTIAL MATCH - EXPERIMENT MODE ({self._mode_name})")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Experiment: {self.context.experiment_id}")
        self.logger.info(f"Is Single Source: {self._is_single_source}")
        self.logger.info(f"Source Table: {self._source_table}")
        self.logger.info(f"Deterministic Table: {self._deterministic_table}")
        self.logger.info(f"Master Table: {self._master_table}")
        self.logger.info(f"Potential Match Table: {self._potential_match_table}")
        self.logger.info("EXPERIMENT MODE: Shows ALL deterministic matches (is_deterministic_match = true)")

    @step(order=1, name="Verify Deterministic Table", returns="deterministic_count")
    def step_verify_deterministic_table(self) -> int:
        """Step 1: Verify deterministic table exists and has records."""
        self._deterministic_count = self._verify_deterministic_table()
        return self._deterministic_count

    @step(order=2, name="Create Potential Match Table", returns="potential_count")
    def step_create_potential_match_table(self) -> int:
        """Step 2: Build and execute potential match query, write output table."""
        self._potential_count = self._create_potential_match_table()
        return self._potential_count

    @step(order=3, name="Optimize Table", returns="None")
    def step_optimize_table(self) -> None:
        """Step 3: Optimize potential match table."""
        self._optimize_table()

    @step(order=4, name="Get Summary Statistics", returns="stats")
    def step_get_summary_statistics(self) -> Dict[str, Any]:
        """Step 4: Get summary statistics."""
        self._get_summary_statistics()
        return self._stats

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Create deterministic potential match table.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Verify deterministic table
            self.step_verify_deterministic_table()

            if self._deterministic_count == 0:
                return TaskResult.skipped(
                    message="No records in deterministic table - nothing to process",
                    task_name=self.context.task_name,
                    task_values={
                        'potential_match_complete': True,
                        'potential_match_count': 0
                    }
                )

            # Step 2: Create potential match table
            self.step_create_potential_match_table()

            # Step 3: Optimize table
            self.step_optimize_table()

            # Step 4: Get summary statistics
            self.step_get_summary_statistics()

            return TaskResult.success(
                message=f"Created deterministic potential match table with {self._potential_count} master records",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'potential_match_complete': True,
                    'potential_match_count': self._stats.get('total_matches', 0)
                },
                artifacts={
                    'potential_match_table': self._potential_match_table
                }
            )

        except Exception as e:
            raise RuntimeError(f"Failed to create potential match table: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate potential match table creation."""
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            potential_count = self._stats.get('potential_count', 0)

            validation = ValidationResult(
                passed=potential_count >= 0,
                message=f"Created potential match table with {potential_count} master records",
                expected=self._stats.get('deterministic_count', 0),
                actual=potential_count
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """POST phase: Print summary."""
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("potential_match_complete", True)
                self.dbutils.jobs.taskValues.set("potential_match_count",
                    self._stats.get('total_matches', 0))
            except Exception:
                pass

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _verify_deterministic_table(self) -> int:
        """Step 1: Verify deterministic table exists and has records."""
        self.print_header("STEP 1: VERIFY DETERMINISTIC TABLE")

        if not self.spark.catalog.tableExists(self._deterministic_table):
            self.logger.info(f"  Deterministic table not found: {self._deterministic_table} — skipping")
            self._stats['deterministic_count'] = 0
            return 0

        try:
            df_deterministic = self.spark.table(self._deterministic_table)
            deterministic_count = df_deterministic.count()
            self.logger.info(f"  Deterministic table exists: {self._deterministic_table}")
            self.logger.info(f"  Total records: {deterministic_count}")
            self._stats['deterministic_count'] = deterministic_count
            return deterministic_count
        except Exception as e:
            raise Exception(f"Deterministic table not found: {self._deterministic_table} — {str(e)}")

    def _create_potential_match_table(self) -> int:
        """
        Step 2: Build and execute the potential match query.

        Data source: deterministic table (unified_deterministic /
        unified_deterministic_deduplicate), NOT processed_unified.

        JOIN: pd.exploded_result.lakefusion_id = m.lakefusion_id
        FILTER: pd.is_deterministic_match = true

        STRUCT fields in potential_matches include:
            id, match (action_on_match), score, reason, lakefusion_id,
            + source_lakefusion_id (single source) OR
              source_surrogate_key + source_id + source_name (multi source)
        """
        self.print_header("STEP 2: CREATE POTENTIAL MATCH TABLE")

        # Build attribute select list
        attr_names = [attr.name if hasattr(attr, 'name') else attr for attr in self._attributes]
        master_attrs = ", ".join([f"m.{attr}" for attr in attr_names])

        if self._is_single_source:
            # Golden Dedup: join deterministic table on exploded_result.lakefusion_id
            potential_match_query = f"""
            SELECT
                m.lakefusion_id,
                m.attributes_combined,
                {master_attrs},
                CONCAT('[',
                    ARRAY_JOIN(
                        COLLECT_LIST(
                            TO_JSON(
                                STRUCT(
                                    pd.exploded_result.id            AS id,
                                    pd.exploded_result.match         AS match,
                                    pd.exploded_result.score         AS score,
                                    pd.exploded_result.reason        AS reason,
                                    pd.exploded_result.lakefusion_id AS lakefusion_id,
                                    pd.lakefusion_id                 AS source_lakefusion_id
                                )
                            )
                        ),
                        ','
                    ),
                ']') AS potential_matches,
                COUNT(*) AS match_count
            FROM {self._deterministic_table} pd
            JOIN {self._master_table} m
                ON pd.exploded_result.lakefusion_id = m.lakefusion_id
            WHERE pd.exploded_result.lakefusion_id IS NOT NULL
              AND pd.is_deterministic_match = true
            GROUP BY m.lakefusion_id, m.attributes_combined, {master_attrs}
            """
        else:
            # Normal Dedup: join deterministic table + source table + master table
            potential_match_query = f"""
            SELECT
                m.lakefusion_id,
                m.attributes_combined,
                {master_attrs},
                CONCAT('[',
                    ARRAY_JOIN(
                        COLLECT_LIST(
                            TO_JSON(
                                STRUCT(
                                    pd.exploded_result.id            AS id,
                                    pd.exploded_result.match         AS match,
                                    pd.exploded_result.score         AS score,
                                    pd.exploded_result.reason        AS reason,
                                    pd.exploded_result.lakefusion_id AS lakefusion_id,
                                    pd.surrogate_key                 AS source_surrogate_key,
                                    u.source_id                      AS source_id,
                                    u.source_path                    AS source_name
                                )
                            )
                        ),
                        ','
                    ),
                ']') AS potential_matches,
                COUNT(*) AS match_count
            FROM {self._deterministic_table} pd
            JOIN {self._source_table} u
                ON pd.surrogate_key = u.surrogate_key
            JOIN {self._master_table} m
                ON pd.exploded_result.lakefusion_id = m.lakefusion_id
            WHERE pd.exploded_result.lakefusion_id IS NOT NULL
              AND pd.is_deterministic_match = true
              AND u.record_status = 'ACTIVE'
            GROUP BY m.lakefusion_id, m.attributes_combined, {master_attrs}
            """

        df_potential = self.spark.sql(potential_match_query)
        potential_count = df_potential.count()

        self.logger.info(f"  Found {potential_count} master records with deterministic matches")

        # Write to potential match table
        df_potential.write.mode("overwrite").option("mergeSchema", "true").saveAsTable(self._potential_match_table)

        self._stats['potential_count'] = potential_count
        self.logger.info(f"  Created potential match table: {self._potential_match_table}")

        return potential_count

    def _optimize_table(self) -> None:
        """Step 3: Optimize potential match table."""
        self.print_header("STEP 3: OPTIMIZE POTENTIAL MATCH TABLE")

        try:
            self.spark.sql(f"OPTIMIZE {self._potential_match_table}")
            self.logger.info("  Optimized potential match table")
        except Exception as e:
            self.logger.info(f"  Optimization skipped: {str(e)}")

    def _get_summary_statistics(self) -> None:
        """Step 4: Get summary statistics."""
        self.print_header("STEP 4: SUMMARY STATISTICS")

        total_potential = self.spark.table(self._potential_match_table).count()
        total_matches = self.spark.sql(f"""
            SELECT SUM(match_count) AS total FROM {self._potential_match_table}
        """).collect()[0]['total'] or 0

        self._stats['total_potential'] = total_potential
        self._stats['total_matches'] = int(total_matches)
        self._stats['avg_matches_per_master'] = (
            total_matches / total_potential if total_potential > 0 else 0
        )

        self.logger.info(f"  Master records with matches: {total_potential}")
        self.logger.info(f"  Total deterministic matches: {int(total_matches)}")
        self.logger.info(f"  Average matches per master: {self._stats['avg_matches_per_master']:.2f}")
        self.logger.info(f"  Mode: {self._mode_name}")
        self.logger.info("  EXPERIMENT MODE: ALL deterministic matches shown (is_deterministic_match = true)")