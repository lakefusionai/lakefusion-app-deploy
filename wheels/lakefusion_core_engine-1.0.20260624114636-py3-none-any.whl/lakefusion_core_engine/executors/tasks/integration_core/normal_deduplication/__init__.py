"""
Normal Deduplication tasks module.

Contains task executors for normal deduplication pipeline operations.

Available Tasks:
    - VectorSearchExecutor: Vector similarity search for entity matching
    - LLMMatchingExecutor: LLM-based entity matching classification
    - LLMMatchingDeterministicExecutor: LLM-based deterministic entity matching
    - ManualMergeExecutor: Manual merge operations for unified records

Usage:
------
    from lakefusion_core_engine.executors.tasks.integration_core.normal_deduplication import (
        VectorSearchExecutor,
        LLMMatchingExecutor,
        LLMMatchingDeterministicExecutor,
        ManualMergeExecutor
    )
"""

from .entity_matching_vector_search import VectorSearchExecutor
from .entity_matching_llm import LLMMatchingExecutor
from .manual_merge import ManualMergeExecutor
from .manual_not_match import ManualNotMatchExecutor
from .manual_unmerge import ManualUnmergeExecutor
from .process_deterministic import ProcessDeterministicExecutor
from .process_auto_merge import ProcessAutoMergeExecutor
from .process_potential_match import ProcessPotentialMatchExecutor
from .process_unmatched_records import ProcessUnmatchedRecordsExecutor
from .update_table_metadata import UpdateTableMetadataExecutor

__all__ = [
    'VectorSearchExecutor',
    'LLMMatchingExecutor',
    'ManualMergeExecutor',
    'ManualNotMatchExecutor',
    'ManualUnmergeExecutor',
    'ProcessDeterministicExecutor',
    'ProcessAutoMergeExecutor',
    'ProcessPotentialMatchExecutor',
    'ProcessUnmatchedRecordsExecutor',
    'UpdateTableMetadataExecutor',
]
