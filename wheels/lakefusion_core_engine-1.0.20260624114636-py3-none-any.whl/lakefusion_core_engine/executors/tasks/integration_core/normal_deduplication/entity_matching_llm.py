"""
Entity Matching LLM Task.

Uses LLM for entity matching classification based on vector search results.

Key updates from notebook reference:
    - Filter applies LEFT ANTI JOIN against unified_deterministic table when it exists
    - union_clause folds deterministic results into 'er' CTE when applicable
    - Priority dedup: deterministic reason rows win per exploded_result.lakefusion_id
    - Rank filter applied before match classification
    - OPTIMIZE runs after CLUSTER BY on processed_unified table
"""

import json
import string
from typing import Any, Dict, List, Optional

from delta.tables import DeltaTable
from pyspark.sql.functions import (
    col, collect_list, struct, to_json, udf
)
from pyspark.sql.types import DoubleType, StringType, StructField, StructType

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, ValidationResult
from lakefusion_core_engine.utils.model_serving import (
    wait_until_serving_endpoint_ready,
    warm_up_llm_endpoint
)


class LLMMatchingExecutor(BaseStepTask):
    """
    Task to perform LLM-based entity matching.

    Uses LLM to classify potential matches identified by vector search
    and applies threshold-based classification.

    External Override Support:
        Users can provide a LLMMatchingExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        1. Validate vector search completion
        2. Validate LLM endpoint
        3. Check processed unified table
        4. Filter records (LEFT ANTI JOIN deterministic table if it exists)
        5. Build and execute LLM query with union_clause
        6. Priority dedup + rank filter + match classification
        7. Update unified table with scoring results
        8. Rebuild processed unified table (full OVERWRITE)
        9. Optimize processed unified table (CLUSTER BY + OPTIMIZE)
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the LLM matching task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._df_llm_results = None
        self._df_with_match_status = None
        self._records_to_process = 0
        self._expected_results = 0
        self._processed_count = 0
        self._skip_result: Optional[TaskResult] = None

        # Deterministic table — built in pre_execute, drives filter and union_clause
        self._unified_deterministic_table: Optional[str] = None
        self._deterministic_table_exists: bool = False

        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """Log task initialization and configuration."""
        self.print_header("LLM ENTITY MATCHING - THRESHOLD-BASED CLASSIFICATION")
        self.logger.info(f"Entity:                 {self.context.entity}")
        self.logger.info(f"Experiment:             {self.context.experiment_id if self.context.experiment_id else 'prod'}")
        self.logger.info(f"Unified Table:          {self.context.unified_table}")
        self.logger.info(f"Processed Unified Table:{self.context.processed_unified_table}")
        self.logger.info(f"Master Table:           {self.context.master_table}")
        self.logger.info(f"LLM Endpoint:           {self.context.llm_endpoint}")
        self.logger.info(f"Max Potential Matches:  {self.context.max_potential_matches}")
        self.logger.info(f"Match Thresholds:")
        self.logger.info(f"  MERGE:          [{self.context.merge_min}-{self.context.merge_max}]")
        self.logger.info(f"  POTENTIAL_MATCH:[{self.context.matches_min}-{self.context.matches_max}]")
        self.logger.info(f"  NO_MATCH:       [{self.context.not_match_min}-{self.context.not_match_max}]")

        # Build unified_deterministic table name and check existence
        # Mirrors notebook: unified_deteministic_table + deteministic_unified_table_exists
        catalog  = self.context.catalog_name
        entity   = self.context.entity
        exp_sfx  = f"_{self.context.experiment_id}" if self.context.experiment_id else ""
        self._unified_deterministic_table = (
            f"{catalog}.silver.{entity}_unified_deterministic{exp_sfx}"
        )
        self._deterministic_table_exists = self.spark.catalog.tableExists(
            self._unified_deterministic_table
        )

        self.logger.info(
            f"Unified Deterministic Table: {self._unified_deterministic_table} "
            f"(exists={self._deterministic_table_exists})"
        )

    # ─────────────────────────────────────────────────────────────
    # Steps
    # ─────────────────────────────────────────────────────────────

    @step(order=1, name="Validate Vector Search", returns="validation status")
    def step_validate_vector_search(self) -> Dict[str, Any]:
        """Validate that vector search completed successfully."""
        if not self._validate_vector_search():
            error_msg = "ERROR: Vector search was not completed successfully"
            self.logger.info(error_msg)
            raise ValueError(error_msg)
        return {'vector_search_valid': True}

    @step(order=2, name="Validate LLM Endpoint", returns="endpoint validation status")
    def step_validate_llm_endpoint(self) -> Dict[str, Any]:
        """Validate that LLM endpoint is ready."""
        if not self._validate_llm_endpoint():
            error_msg = f"ERROR: LLM endpoint '{self.context.llm_endpoint}' is not ready"
            self.logger.info(error_msg)
            raise ValueError(error_msg)
        return {'llm_endpoint_valid': True}

    @step(order=3, name="Check Processed Unified Table", returns="table existence status")
    def step_check_processed_unified_table(self) -> Dict[str, Any]:
        """Check if processed unified table exists."""
        self._check_processed_unified_table()
        processed_unified_table_exists = self.spark.catalog.tableExists(
            self.context.processed_unified_table
        )
        return {'processed_unified_exists': processed_unified_table_exists}

    @step(order=4, name="Filter Records for Processing", returns="records to process status")
    def step_filter_records_for_processing(self) -> Dict[str, Any]:
        """Filter records that need LLM processing."""
        self._skip_result = self._filter_records_for_processing()
        return {
            'skip_processing': self._skip_result is not None,
            'records_to_process': self._records_to_process
        }

    @step(order=5, name="Build and Execute LLM Query", returns="LLM query results")
    def step_build_and_execute_llm_query(self) -> Dict[str, Any]:
        """Build and execute the LLM query."""
        if self._skip_result:
            self.logger.info("  Skipping - no records to process")
            return {'skipped': True}
        self._build_and_execute_llm_query()
        return {'llm_query_executed': True}

    @step(order=6, name="Apply Match Classification", returns="classified results")
    def step_apply_match_classification(self) -> Dict[str, Any]:
        """Apply priority dedup, rank filter, and threshold-based match classification."""
        if self._skip_result:
            self.logger.info("  Skipping - no records to process")
            return {'skipped': True}
        self._apply_match_classification()
        return {'classification_applied': True}

    @step(order=7, name="Update Unified with Scoring", returns="update status")
    def step_update_unified_with_scoring(self) -> Dict[str, Any]:
        """Update unified table with scoring results."""
        if self._skip_result:
            self.logger.info("  Skipping - no records to process")
            return {'skipped': True}
        self._update_unified_with_scoring()
        return {'unified_updated': True}

    @step(order=8, name="Rebuild Processed Unified", returns="rebuild status")
    def step_rebuild_processed_unified(self) -> Dict[str, Any]:
        """Rebuild processed unified table from all active records."""
        if self._skip_result:
            self.logger.info("  Skipping - no records to process")
            return {'skipped': True}
        self._rebuild_processed_unified()
        return {'processed_unified_rebuilt': True}

    @step(order=9, name="Optimize Processed Unified", returns="optimization status")
    def step_optimize_processed_unified(self) -> Dict[str, Any]:
        """Optimize the processed unified table."""
        if self._skip_result:
            self.logger.info("  Skipping - no records to process")
            return {'skipped': True}
        self._optimize_processed_unified()
        return {'processed_unified_optimized': True}

    # ─────────────────────────────────────────────────────────────
    # Lifecycle methods
    # ─────────────────────────────────────────────────────────────

    def execute(self) -> TaskResult:
        """Execute LLM-based entity matching."""
        try:
            self.step_validate_vector_search()
            self.step_validate_llm_endpoint()
            self.step_check_processed_unified_table()
            self.step_filter_records_for_processing()
            if self._skip_result:
                return self._skip_result

            self.step_build_and_execute_llm_query()
            self.step_apply_match_classification()
            self.step_update_unified_with_scoring()
            self.step_rebuild_processed_unified()
            self.step_optimize_processed_unified()

            return TaskResult.success(
                message="LLM matching completed successfully",
                metrics=self._stats,
                artifacts={
                    'processed_unified_table': self.context.processed_unified_table,
                    'unified_table': self.context.unified_table,
                    'processed_count': self._processed_count
                },
                task_values={
                    'llm_matching_complete': True
                }
            )

        except Exception as e:
            raise RuntimeError(f"Failed to execute LLM matching: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the LLM matching results."""
        if result.is_failed:
            return result
        # Full validation commented out in production for performance — mirrors notebook
        return result

    def post_execute(self, result: TaskResult) -> None:
        """Print completion summary."""
        self.print_header("LLM MATCHING COMPLETED")
        self.logger.info(f"  Total records in processed_unified: {self._processed_count}")
        self.logger.info(f"  Processed unified table: {self.context.processed_unified_table}")
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        self.dbutils.jobs.taskValues.set("llm_matching_complete", True)
        self.dbutils.jobs.taskValues.set("processed_unified_count", self._processed_count)

    # =========================================================================
    # Private helper methods
    # =========================================================================

    def _validate_vector_search(self) -> bool:
        """Validate that vector search completed successfully."""
        self.print_header("STEP 1: VALIDATE VECTOR SEARCH COMPLETION")
        try:
            vector_search_complete = self.dbutils.jobs.taskValues.get(
                taskKey="Entity_Matching_Vector_Search",
                key="vector_search_complete",
                debugValue=True
            )
            if not vector_search_complete:
                self.logger.info("  ERROR: Vector search was not completed successfully")
                return False
            self.logger.info("  ✓ Vector search completed successfully")
            return True
        except Exception as e:
            self.logger.info(f"  ⚠️  Could not verify vector search completion: {e}")
            self.logger.info("  Proceeding with LLM matching...")
            return True

    def _validate_llm_endpoint(self) -> bool:
        """Validate that LLM endpoint is ready."""
        self.print_header("STEP 2: VALIDATE LLM ENDPOINT")
        try:
            wait_until_serving_endpoint_ready(
                endpoint_name=self.context.llm_endpoint, timeout_minutes=5
            )
            self.logger.info(f"  ✓ LLM endpoint '{self.context.llm_endpoint}' is ready")
            return True
        except ValueError as e:
            self.logger.info(f"  ERROR: LLM endpoint not ready: {str(e)}")
            return False

    # NOTE: Warm-up step commented out - handled at infrastructure level
    # def _warm_up_llm_endpoint(self) -> None: ...

    def _check_processed_unified_table(self) -> None:
        """Check if processed unified table exists."""
        self.print_header("STEP 3: CHECK PROCESSED UNIFIED TABLE")
        processed_unified_table_exists = self.spark.catalog.tableExists(
            self.context.processed_unified_table
        )
        if processed_unified_table_exists:
            existing_count = self.spark.table(self.context.processed_unified_table).count()
            self.logger.info(f"  ✓ Processed unified table exists: {existing_count} records")
        else:
            self.logger.info(f"  ℹ️  Will be created: {self.context.processed_unified_table}")

    def _filter_records_for_processing(self) -> Optional[TaskResult]:
        """
        Filter records that need LLM processing.

        When deterministic table exists:
            LEFT ANTI JOIN to exclude already-matched records — mirrors notebook STEP 4.
        Otherwise:
            Plain filter on ACTIVE records with search_results and empty scoring_results.

        Uses isEmpty() for cheap existence check — avoids full count scan.

        Returns:
            TaskResult if no records to process (skip), None otherwise.
        """
        self.print_header("STEP 4: FILTER RECORDS FOR LLM PROCESSING")

        unified_id_key    = self.context.unified_id_key
        merged_desc_column = self.context.merged_desc_column

        if self._deterministic_table_exists:
            filter_query = f"""
            SELECT
                u.{unified_id_key},
                u.{merged_desc_column},
                u.search_results
            FROM {self.context.unified_table} u
            LEFT ANTI JOIN {self._unified_deterministic_table} ud
                ON u.{unified_id_key} = ud.{unified_id_key}
            WHERE u.record_status = 'ACTIVE'
              AND u.search_results IS NOT NULL
              AND u.search_results != ''
              AND (u.scoring_results IS NULL OR u.scoring_results = '')
            """
        else:
            filter_query = f"""
            SELECT
                u.{unified_id_key},
                u.{merged_desc_column},
                u.search_results
            FROM {self.context.unified_table} u
            WHERE u.record_status = 'ACTIVE'
              AND u.search_results IS NOT NULL
              AND u.search_results != ''
              AND (u.scoring_results IS NULL OR u.scoring_results = '')
            """

        records_to_process_empty = self.spark.sql(filter_query).isEmpty()

        self.logger.info(f"  Deterministic table exists: {self._deterministic_table_exists}")
        self.logger.info(f"  ✓ Filter: ACTIVE records with search_results and empty scoring_results")

        if records_to_process_empty:
            return self._handle_no_records_to_process()

        return None

    def _handle_no_records_to_process(self) -> TaskResult:
        """
        Handle case when there are no new records to process.

        Rebuilds processed_unified from existing scoring_results if available,
        or creates an empty table if not. Mirrors notebook STEP 5 skip path.
        """
        self.logger.info("  ℹ️  No new records to process")
        self.print_header("STEP 5: UPDATE PROCESSED UNIFIED FROM SCORING RESULTS")

        unified_id_key = self.context.unified_id_key
        master_id_key  = self.context.master_id_key

        active_with_scoring_empty = self.spark.sql(f"""
            SELECT *
            FROM {self.context.unified_table}
            WHERE record_status = 'ACTIVE'
              AND scoring_results IS NOT NULL
              AND scoring_results != ''
        """).isEmpty()

        if not active_with_scoring_empty:
            rebuild_query = f"""
            SELECT
                u.{unified_id_key},
                exploded.{master_id_key} AS {master_id_key},
                exploded                 AS exploded_result,
                exploded.id              AS exploded_result_id
            FROM {self.context.unified_table} u
            LATERAL VIEW EXPLODE(
                FROM_JSON(u.scoring_results, 'array<struct<
                    id:string, match:string, score:double,
                    reason:string, lakefusion_id:string
                >>')
            ) AS exploded
            WHERE u.record_status = 'ACTIVE'
              AND u.scoring_results IS NOT NULL
              AND u.scoring_results != ''
            """
            df_from_scoring = self.spark.sql(rebuild_query)
            (
                df_from_scoring.write
                .mode("overwrite")
                .option("mergeSchema", "true")
                .saveAsTable(self.context.processed_unified_table)
            )
        else:
            self.logger.info("  No scoring_results to process")

            if not self.spark.catalog.tableExists(self.context.processed_unified_table):
                self.logger.info(
                    f"  Creating empty processed_unified table: {self.context.processed_unified_table}"
                )
                empty_schema = StructType([
                    StructField(unified_id_key, StringType(), True),
                    StructField(master_id_key,  StringType(), True),
                    StructField("exploded_result", StructType([
                        StructField("id",            StringType(), True),
                        StructField("match",         StringType(), True),
                        StructField("score",         DoubleType(), True),
                        StructField("reason",        StringType(), True),
                        StructField("lakefusion_id", StringType(), True)
                    ]), True),
                    StructField("exploded_result_id", StringType(), True)
                ])
                empty_df = self.spark.createDataFrame([], empty_schema)
                (
                    empty_df.write
                    .mode("overwrite")
                    .option("mergeSchema", "true")
                    .saveAsTable(self.context.processed_unified_table)
                )
                self.logger.info("  ✓ Empty processed_unified table created")

        self.dbutils.jobs.taskValues.set("llm_matching_complete", True)
        self.dbutils.jobs.taskValues.set("records_processed", 0)
        self.dbutils.jobs.taskValues.set("processed_unified_count", 0)

        return TaskResult.success(
            message="No new records to process",
            metrics={"records_processed": 0, "status": "skipped"}
        )

    def _build_union_clause(self) -> str:
        """
        Build UNION clause folding deterministic results into the 'er' CTE.

        When deterministic table exists, already-matched records from
        unified_deterministic are included alongside new LLM results.

        NOTE: Groups by unified_id_key (surrogate_key) — NOT master_id_key.
        This is the normal dedup variant; golden dedup uses master_id_key.

        Returns empty string when deterministic table does not exist.
        Mirrors notebook union_clause construction exactly.
        """
        if not self._deterministic_table_exists:
            return ""

        unified_id_key = self.context.unified_id_key

        return f"""
    UNION
    SELECT
        {unified_id_key},
        FIRST(attributes_combined)  AS attributes_combined,
        FIRST(search_results)       AS search_results,
        CONCAT(
            '[',
            CONCAT_WS(',', COLLECT_LIST(json_item)),
            ']'
        ) AS combined_column,
        FIRST(exploded_result) AS exploded_result
    FROM (
        SELECT
            {unified_id_key},
            CONCAT(
                '{{"id": "',             exploded_result.id,
                '", "score": ',          exploded_result.score,
                ', "reason": "',         exploded_result.reason,
                '", "lakefusion_id": "', exploded_result.lakefusion_id,
                '"}}'
            ) AS json_item,
            attributes_combined,
            search_results,
            deterministic_match_result,
            is_deterministic_match,
            NAMED_STRUCT(
                'id',            exploded_result.id,
                'score',         CAST(exploded_result.score AS DOUBLE),
                'reason',        exploded_result.reason,
                'lakefusion_id', exploded_result.lakefusion_id
            ) AS exploded_result
        FROM {self._unified_deterministic_table}
    )
    GROUP BY {unified_id_key}
        """

    def _safe_format(self, template: str, **kwargs) -> str:
        """Format a template, leaving unrecognized placeholders intact."""
        class SafeDict(dict):
            def __missing__(self, key):
                return '{' + key + '}'
        return template.format_map(SafeDict(**kwargs))

    def _build_and_execute_llm_query(self) -> None:
        """
        Build and execute the LLM query.

        Filter subquery (uf):
            - LEFT ANTI JOIN against deterministic table when it exists.
            - Plain ACTIVE filter when deterministic table is absent.

        union_clause:
            - Folds deterministic results into 'er' CTE when table exists.
            - Groups by unified_id_key (surrogate_key) — normal dedup context.

        Mirrors notebook STEP 5 (uf + union_clause) and STEP 6 (llm_query).
        """
        self.print_header("STEP 5: BUILD LLM QUERY")

        unified_id_key     = self.context.unified_id_key
        master_id_key      = self.context.master_id_key
        merged_desc_column = self.context.merged_desc_column
        max_potential_matches = self.context.max_potential_matches
        entity             = self.context.entity
        attributes         = self.context.attributes
        additional_instructions = self.context.additional_instructions
        base_prompt        = self.context.base_prompt
        llm_endpoint       = self.context.llm_endpoint
        llm_temperature    = float(self.context.params.get('llm_temperature', 0.0))

        # ── Filter subquery — matches _filter_records_for_processing branching ──
        if self._deterministic_table_exists:
            filter_query = f"""
            SELECT
                u.{unified_id_key},
                u.{merged_desc_column},
                u.search_results
            FROM {self.context.unified_table} u
            LEFT ANTI JOIN {self._unified_deterministic_table} ud
                ON u.{unified_id_key} = ud.{unified_id_key}
            WHERE u.record_status = 'ACTIVE'
              AND u.search_results IS NOT NULL
              AND u.search_results != ''
              AND (u.scoring_results IS NULL OR u.scoring_results = '')
            """
        else:
            filter_query = f"""
            SELECT
                u.{unified_id_key},
                u.{merged_desc_column},
                u.search_results
            FROM {self.context.unified_table} u
            WHERE u.record_status = 'ACTIVE'
              AND u.search_results IS NOT NULL
              AND u.search_results != ''
              AND (u.scoring_results IS NULL OR u.scoring_results = '')
            """

        uf_sub_query  = f"uf AS ({filter_query})"
        union_clause  = self._build_union_clause()

        # ── Additional instructions clause ────────────────────────────────────
        additional_instructions_clause = ""
        if additional_instructions and additional_instructions.strip():
            additional_instructions_clause = f" {additional_instructions}"

        self.logger.info(
            f"  ✓ Building LLM query for {max_potential_matches} matches per record"
        )

        # ── Prompt construction ───────────────────────────────────────────────
        if base_prompt is None or base_prompt == '':
            self.logger.info("  Using default prompt")
            default_prompt = f"""You are an expert in classifying two entities as matching or not matching.
You will be provided with a query entity and a list of possible entities.
You need to find the closest matching entity with a similarity score to indicate how similar they are.
Take into account:
1. The attributes are not mutually exclusive.
2. The attributes are not exhaustive.
3. The attributes are not consistent.
4. The attributes are not complete.
5. The attributes can have typos.
6. The entity type being considered is: {entity}.
7. Do not consider scores in the search results. Generate your own similarity scores.
8. If additional instructions are present, consider them too.{additional_instructions_clause}
Follow these rules for input and output:
**Input:**
- Query Entity Format:
  The query entity will be provided as a single string in the following format:
  {' | '.join(attributes)}
  Each field is separated by a vertical bar (|).
  Note: Some columns can have aggregated values separated by (bullet)
- List of Possible Entities:
  A string containing comma-separated entries in this EXACT format:
  [entity_description, lakefusion_id, score], [entity_description, lakefusion_id, score], ...
  WHERE:
  - entity_description: Pipe-separated fields (BEFORE first comma inside brackets)
  - lakefusion_id: 32-character hexadecimal string (BETWEEN first and second comma)
  - score: Decimal number (AFTER second comma, before closing bracket)
**CRITICAL EXTRACTION RULES:**
- For EACH entry in the list, you MUST extract the lakefusion_id
- The lakefusion_id is ALWAYS between the FIRST comma and SECOND comma inside each bracket
- If you cannot find a valid lakefusion_id, DO NOT return that entry
- lakefusion_id format: 32 lowercase hexadecimal characters (a-f, 0-9)
- Example valid lakefusion_id: d728dead49f8c4bbbf0be3dcdc65d215
**Output:**
Only return a plain JSON list of objects:
1. No extra text, no headers, no introductory phrases, and no comments.
2. Do not use code blocks, markdown, or any other formatting.
3. The JSON list MUST contain EXACTLY {max_potential_matches} objects (one for each entity in the input list).
4. Each object must have these keys:
    a. id: String (the entity_description - text BEFORE first comma in brackets).
    b. score: Float (YOUR similarity score from 0.0 to 1.0 - NOT the vector score).
    c. reason: String (brief explanation for YOUR score).
    d. lakefusion_id: String (COPY the 32-char hex string between 1st and 2nd comma EXACTLY).
5. VERIFY each lakefusion_id is exactly 32 characters of a-f and 0-9.
6. Return EXACTLY {max_potential_matches} results, no more, no less.
7. Ensure scores are in descending order (highest similarity first)."""
            safe_prompt = default_prompt.replace("'", "\\'")
        else:
            self.logger.info("  Using custom base prompt")
            clean_prompt = (
                base_prompt
                .replace("{query_entity}", "")
                .replace("{merged_desc_column}", "")
                .replace("{search_results}", "")
            )
            formatted_prompt = self._safe_format(
                clean_prompt,
                entity=entity,
                additional_instructions=additional_instructions,
                attributes=' | '.join(attributes),
                max_potential_matches=max_potential_matches,
            )
            safe_prompt = formatted_prompt.replace("'", "\\'")

        prompt_concat_parts = (
            f"CONCAT('{safe_prompt}', "
            f"'\\nQuery record: ', {merged_desc_column}, "
            f"'\\nList of potential matches with vector search scores (JSON Array): ', search_results)"
        )

        # ── Full LLM query — mirrors notebook STEP 5 + STEP 6 exactly ────────
        # 'er' CTE uses comma join + WHERE (not INNER JOIN) to allow union_clause
        # to be appended after the WHERE condition inside the CTE body.
        llm_query = f"""
WITH m AS (
    SELECT {master_id_key}, {merged_desc_column}
    FROM   {self.context.master_table}
),
{uf_sub_query},
llm_results AS (
    SELECT
        {unified_id_key},
        {merged_desc_column},
        search_results,
        ai_query(
            '{llm_endpoint}',
            {prompt_concat_parts},
            responseFormat => '{{
                "type": "json_schema",
                "json_schema": {{
                    "name": "match_results",
                    "schema": {{
                        "type": "object",
                        "properties": {{
                            "results": {{
                                "type": "array",
                                "items": {{
                                    "type": "object",
                                    "properties": {{
                                        "id":                  {{ "type": "string" }},
                                        "score":               {{ "type": "number" }},
                                        "reason":              {{ "type": "string" }},
                                        "{master_id_key}":     {{ "type": "string" }}
                                    }},
                                    "required": ["id", "match", "score", "reason", "{master_id_key}"],
                                    "additionalProperties": false
                                }}
                            }}
                        }},
                        "required": ["results"],
                        "additionalProperties": false
                    }},
                    "strict": true
                }}
            }}',
            modelParameters => named_struct('temperature', {llm_temperature})
        ) AS scoring_results
    FROM uf
),
er AS (
    SELECT
        uf.*,
        get_json_object(llm_results.scoring_results, '$.results') AS combined_results,
        EXPLODE(FROM_JSON(
            get_json_object(llm_results.scoring_results, '$.results'),
            'ARRAY<STRUCT<
                id     STRING,
                score  DOUBLE,
                reason STRING,
                lakefusion_id STRING
            >>'
        )) AS exploded_result
    FROM uf, llm_results
    WHERE uf.{unified_id_key} = llm_results.{unified_id_key}
    {union_clause}
)
SELECT
    er.{unified_id_key},
    er.exploded_result.{master_id_key}  AS {master_id_key},
    er.exploded_result,
    er.exploded_result.`id`             AS exploded_result_id,
    er.combined_results                 AS scoring_results_json
FROM er
LEFT JOIN m ON er.exploded_result.{master_id_key} = m.{master_id_key}
WHERE m.{master_id_key} IS NOT NULL
        """

        self.print_header("STEP 6: EXECUTE LLM QUERY")
        self.logger.info("  ⏳ Running LLM matching (this may take a while)...")

        try:
            self._df_llm_results = self.spark.sql(llm_query)
            self.logger.info("  ✓ LLM processing completed")
        except Exception as e:
            import traceback
            error_msg = f"ERROR: LLM query execution failed: {str(e)}"
            self.logger.error(error_msg)
            self.logger.info(traceback.format_exc())
            raise RuntimeError(error_msg)

    def _apply_match_classification(self) -> None:
        """
        Apply priority dedup, rank filter, and threshold-based match classification.

        Steps (mirrors notebook post-LLM cells):
            1. Priority dedup: deterministic reason rows win per exploded_result.lakefusion_id.
            2. Rank filter: top N per unified_id_key by score.
            3. Classification: threshold-based match_status via UDF.
            4. Reconstruct exploded_result with match_status.
        """
        self.print_header("STEP 8: APPLY MATCH CLASSIFICATION")

        from pyspark.sql import functions as F
        from pyspark.sql.window import Window

        unified_id_key = self.context.unified_id_key
        master_id_key  = self.context.master_id_key

        # ── 1. Priority dedup: deterministic reason rows win per lakefusion_id ──
        # Mirrors notebook post-STEP 6 dedup cell exactly
        df_with_priority = self._df_llm_results.withColumn(
            "priority",
            F.when(
                F.col("exploded_result.reason").contains(
                    "Due to Deterministic Match of Rule"
                ),
                1,
            ).otherwise(0),
        )

        w_priority = (
            Window
            .partitionBy("exploded_result.lakefusion_id")
            .orderBy(
                F.col("priority").desc(),
                F.col("exploded_result.score").desc(),
            )
        )

        df_deduped = (
            df_with_priority
            .withColumn("rn", F.row_number().over(w_priority))
            .filter("rn = 1")
            .drop("rn", "priority")
        )

        # ── 2. Rank filter: top N per query record ────────────────────────────
        # Mirrors notebook STEP 7 (filter null + top N)
        w_rank = (
            Window
            .partitionBy(unified_id_key)
            .orderBy(F.col("exploded_result.score").desc())
        )

        df_filtered = (
            df_deduped
            .filter(F.col(master_id_key).isNotNull())
            .withColumn("rank", F.row_number().over(w_rank))
            .filter(F.col("rank") <= self.context.max_potential_matches)
            .drop("rank")
        )

        # ── 3. Classification via UDF — mirrors notebook STEP 8 ──────────────
        merge_min     = self.context.merge_min
        merge_max     = self.context.merge_max
        matches_min   = self.context.matches_min
        matches_max   = self.context.matches_max
        not_match_min = self.context.not_match_min
        not_match_max = self.context.not_match_max

        def classify_match_status(score):
            if score is None:
                return "NO_MATCH"
            if merge_min <= score <= merge_max:
                return "MATCH"
            elif matches_min <= score <= matches_max:
                return "POTENTIAL_MATCH"
            elif not_match_min <= score <= not_match_max:
                return "NO_MATCH"
            else:
                return "NO_MATCH"

        classify_match_udf = udf(classify_match_status, StringType())

        df_classified = df_filtered.withColumn(
            "match_status",
            classify_match_udf(col("exploded_result.score"))
        )

        # ── 4. Reconstruct exploded_result with match_status ──────────────────
        self._df_with_match_status = (
            df_classified
            .withColumn(
                "exploded_result",
                struct(
                    col("exploded_result.id").alias("id"),
                    col("match_status").alias("match"),
                    col("exploded_result.score").alias("score"),
                    col("exploded_result.reason").alias("reason"),
                    col("exploded_result.lakefusion_id").alias("lakefusion_id"),
                ),
            )
            .select(
                unified_id_key,
                master_id_key,
                "exploded_result",
                "exploded_result_id",
                "scoring_results_json",
                "match_status",
            )
        )

    def _update_unified_with_scoring(self) -> None:
        """Update unified table with scoring results."""
        self.print_header("STEP 9: UPDATE UNIFIED TABLE WITH SCORING RESULTS")

        unified_id_key = self.context.unified_id_key

        df_scoring_updates = (
            self._df_with_match_status
            .groupBy(unified_id_key)
            .agg(
                collect_list(
                    struct(
                        col("exploded_result.id").alias("id"),
                        col("exploded_result.match").alias("match"),
                        col("exploded_result.score").alias("score"),
                        col("exploded_result.reason").alias("reason"),
                        col("exploded_result.lakefusion_id").alias("lakefusion_id"),
                    )
                ).alias("results_array")
            )
            .withColumn("scoring_results", to_json(col("results_array")))
            .select(unified_id_key, "scoring_results")
        )

        unified_delta = DeltaTable.forName(self.spark, self.context.unified_table)
        (
            unified_delta.alias("target")
            .merge(
                source=df_scoring_updates.alias("source"),
                condition=f"target.{unified_id_key} = source.{unified_id_key}",
            )
            .whenMatchedUpdate(set={"scoring_results": "source.scoring_results"})
            .execute()
        )

        self.logger.info("  ✓ Unified table updated with scoring_results")

    def _rebuild_processed_unified(self) -> None:
        """
        Rebuild processed unified table from all active records.

        Full OVERWRITE via LATERAL VIEW EXPLODE from unified table.
        Mirrors notebook STEP 10 exactly.
        """
        self.print_header("STEP 10: REBUILD PROCESSED UNIFIED TABLE")

        unified_id_key = self.context.unified_id_key
        master_id_key  = self.context.master_id_key

        rebuild_query = f"""
        SELECT
            u.{unified_id_key},
            exploded.{master_id_key} AS {master_id_key},
            exploded                 AS exploded_result,
            exploded.id              AS exploded_result_id
        FROM {self.context.unified_table} u
        LATERAL VIEW EXPLODE(
            FROM_JSON(u.scoring_results, 'array<struct<
                id:string, match:string, score:double,
                reason:string, lakefusion_id:string
            >>')
        ) AS exploded
        WHERE u.record_status = 'ACTIVE'
          AND u.scoring_results IS NOT NULL
          AND u.scoring_results != ''
        """

        df_processed_unified = self.spark.sql(rebuild_query)

        self.logger.info(
            "  Building processed_unified from all active records with scoring_results"
        )

        (
            df_processed_unified.write
            .mode("overwrite")
            .option("mergeSchema", "true")
            .saveAsTable(self.context.processed_unified_table)
        )

    def _optimize_processed_unified(self) -> None:
        """
        Optimize the processed unified table.

        Mirrors notebook STEP 11:
            ALTER TABLE ... CLUSTER BY (exploded_result.match, master_id_key)
            OPTIMIZE ...
        Both calls are required — matches notebook exactly.
        """
        self.print_header("STEP 11: OPTIMIZE PROCESSED UNIFIED TABLE")

        master_id_key = self.context.master_id_key

        self.spark.sql(f"""
            ALTER TABLE {self.context.processed_unified_table}
            CLUSTER BY (exploded_result.match, {master_id_key})
        """)

        self.spark.sql(f"OPTIMIZE {self.context.processed_unified_table}")

        self.logger.info("  ✓ Processed unified table optimized")