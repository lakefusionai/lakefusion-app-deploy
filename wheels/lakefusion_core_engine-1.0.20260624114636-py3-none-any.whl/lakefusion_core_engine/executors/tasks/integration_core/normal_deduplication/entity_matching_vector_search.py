"""
Vector Search Executor.

Performs vector similarity search to find potential matches between
unified records and master records.

NOTE: This executor's core logic is aligned with the production notebook
at integration-core/normal_deduplication/Entity_Matching_Vector_Search.py
"""

import time
from typing import Any, Dict, Optional

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class VectorSearchExecutor(BaseStepTask):
    """
    Executor for Vector Search operations.

    Contains core business logic migrated from Entity_Matching_Vector_Search notebook.
    Searches unified records against the master table vector index to find
    potential matches based on embedding similarity.

    External Override Support:
        Users can provide a VectorSearchExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.

    Workflow:
        1. Validate embedding endpoint
        2. Setup/verify vector search endpoint
        3. Wait for VS endpoint
        4. Create or sync vector search index
        5. Filter records needing search
        6. Define and execute vector search via UDF
        7. Deduplicate results
        8. Merge results back to unified table
    """

    # Configuration constants (matching production)
    TIMEOUT_SECONDS = 10 * 60  # 10 minutes
    POLL_INTERVAL = 20  # seconds
    MAX_PIPELINE_FAILURES = 3  # fail on 3rd occurrence

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the vector search task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        self._stats: Dict[str, Any] = {}
        self._index = None
        self._client = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Instance variables for intermediate results (step-based execution)
        self._embedding_endpoint: Optional[str] = None
        self._vs_endpoint: Optional[str] = None
        self._max_potential_matches: int = 3
        self._merged_desc_column: str = 'attributes_combined'
        self._unified_id_key: str = 'surrogate_key'
        self._master_id_key: str = 'lakefusion_id'

        # DataFrames for intermediate results
        self.df_pending = None
        self.df_results = None
        self.df_deduped = None

        # Flags
        self._is_empty = False

    def pre_execute(self) -> None:
        """
        PRE phase: Validate inputs and setup endpoints.

        Can be overridden by VectorSearchExtended.pre_execute()
        """
        self.print_header("VECTOR SEARCH - ENTITY MATCHING")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment: {self.context.experiment_id or 'prod'}")
        self.logger.info(f"Unified Table: {self.context.unified_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")

        # Get params
        params = self.context.params
        self._embedding_endpoint = params.get('embedding_endpoint')
        self._vs_endpoint = params.get('vs_endpoint')
        self._max_potential_matches = int(params.get('max_potential_matches', 3))
        self._merged_desc_column = params.get('merged_desc_column', 'attributes_combined')
        self._unified_id_key = params.get('unified_id_key', 'surrogate_key')
        self._master_id_key = params.get('master_id_key', 'lakefusion_id')

        self.logger.info(f"Unified ID Key: {self._unified_id_key}")
        self.logger.info(f"Master ID Key: {self._master_id_key}")
        self.logger.info(f"Embedding Endpoint: {self._embedding_endpoint}")
        self.logger.info(f"VS Endpoint: {self._vs_endpoint}")
        self.logger.info(f"Max Potential Matches: {self._max_potential_matches}")

        # Validate required params
        if not self._embedding_endpoint:
            raise ValueError("embedding_endpoint is required in params")
        if not self._vs_endpoint:
            raise ValueError("vs_endpoint is required in params")

    @step(order=1, name="Validate Embedding Endpoint", returns="Embedding endpoint validation status")
    def step_validate_embedding_endpoint(self) -> Dict[str, Any]:
        """Step 1: Validate embedding endpoint is ready."""
        self._validate_embedding_endpoint()
        return {'embedding_endpoint_ready': True}

    @step(order=2, name="Setup Vector Search Endpoint", returns="VS endpoint setup status")
    def step_setup_vs_endpoint(self) -> Dict[str, Any]:
        """Step 2: Setup vector search endpoint."""
        self._setup_vs_endpoint()
        return {'vs_endpoint_setup': True}

    @step(order=3, name="Wait for VS Endpoint", returns="VS endpoint ready status")
    def step_wait_for_vs_endpoint(self) -> Dict[str, Any]:
        """Step 3: Wait for VS endpoint to be ready."""
        self._wait_for_vs_endpoint()
        return {'vs_endpoint_ready': True}

    @step(order=4, name="Create/Sync Vector Search Index", returns="Index name and sync status")
    def step_create_or_sync_index(self) -> Dict[str, Any]:
        """Step 4: Create or sync vector search index."""
        self._create_or_sync_index()
        return {'index_name': self._stats.get('index_name'), 'index_synced': True}

    @step(order=5, name="Filter Pending Records", returns="DataFrame of records needing search")
    def step_filter_pending_records(self) -> Dict[str, Any]:
        """Step 5: Filter records needing vector search."""
        self.df_pending, self._is_empty = self._filter_pending_records()
        return {
            'is_empty': self._is_empty,
            'pending_count': self._stats.get('pending_count', 0)
        }

    @step(order=6, name="Execute Vector Search", returns="DataFrame with search results")
    def step_execute_vector_search(self) -> Dict[str, Any]:
        """Step 6: Execute vector search via UDF."""
        if self._is_empty:
            self.logger.info("Skipping - no records to process")
            return {'skipped': True}
        self.df_results = self._execute_vector_search(self.df_pending)
        return {'search_executed': True}

    @step(order=7, name="Deduplicate Results", returns="DataFrame with deduplicated results")
    def step_deduplicate_results(self) -> Dict[str, Any]:
        """Step 7: Deduplicate results."""
        if self._is_empty:
            self.logger.info("Skipping - no records to process")
            return {'skipped': True}
        self.df_deduped = self._deduplicate_results(self.df_results)
        return {'deduplicated': True}

    @step(order=8, name="Merge Results to Unified Table", returns="Merge completion status")
    def step_merge_results(self) -> Dict[str, Any]:
        """Step 8: Merge results to unified table."""
        if self._is_empty:
            self.logger.info("Skipping - no records to process")
            return {'skipped': True}
        self._merge_results(self.df_deduped)
        return {'merged': True}

    def execute(self) -> TaskResult:
        """
        EXECUTE phase: Core vector search business logic.

        This method is NOT overridable by end users.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Validate embedding endpoint
            self.step_validate_embedding_endpoint()

            # Step 2: Setup vector search endpoint
            self.step_setup_vs_endpoint()

            # Step 3: Wait for VS endpoint
            self.step_wait_for_vs_endpoint()

            # Step 4: Create/sync vector search index
            self.step_create_or_sync_index()

            # Step 5: Filter records for vector search
            self.step_filter_pending_records()

            if self._is_empty:
                return TaskResult.skipped(
                    message="No records to process - all ACTIVE records already have search results",
                    task_name=self.context.task_name,
                    task_values={
                        'vector_search_complete': True,
                        'records_searched': 0
                    }
                )

            # Step 6: Execute vector search
            self.step_execute_vector_search()

            # Step 7: Deduplicate results
            self.step_deduplicate_results()

            # Step 8: Merge results to unified table
            self.step_merge_results()

            return TaskResult.success(
                message="Vector search completed successfully",
                task_name=self.context.task_name,
                metrics=self._stats,
                task_values={
                    'vector_search_complete': True,
                    'records_searched': self._stats.get('records_searched', 0)
                },
                artifacts={
                    'unified_table': self.context.unified_table,
                    'master_table': self.context.master_table,
                    'index_name': self._stats.get('index_name')
                }
            )

        except Exception as e:
            raise RuntimeError(f"Vector search failed: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """
        Validate the vector search results.

        Args:
            result: TaskResult from execute()

        Returns:
            TaskResult with validation results added
        """
        if result.is_failed or result.status == TaskStatus.SKIPPED:
            return result

        try:
            validation = ValidationResult(
                passed=True,
                message="Vector search results merged to unified table"
            )
            result.add_validation(validation)

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """
        POST phase: Print summary.

        Can be overridden by VectorSearchExtended.post_execute()
        """
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        if self.dbutils:
            try:
                self.dbutils.jobs.taskValues.set("vector_search_complete", True)
                # Note: records_searched is commented out in production
                # self.dbutils.jobs.taskValues.set(
                #     "records_searched",
                #     self._stats.get('records_searched', 0)
                # )
            except Exception:
                pass  # Ignore if not running in a job

    # =========================================================================
    # Private helper methods (core business logic matching production)
    # =========================================================================

    def _validate_embedding_endpoint(self) -> None:
        """Validate embedding endpoint is ready."""
        self.logger.info("Validating embedding endpoint...")

        # Import model_serving utilities from SDK
        from lakefusion_core_engine.utils.model_serving import wait_until_serving_endpoint_ready

        try:
            wait_until_serving_endpoint_ready(endpoint_name=self._embedding_endpoint, timeout_minutes=5)
            self.logger.info(f"Embedding endpoint '{self._embedding_endpoint}' is ready")
        except ValueError as e:
            error_msg = f"ERROR: Embedding endpoint not ready: {str(e)}"
            self.logger.info(error_msg)
            raise

    def _setup_vs_endpoint(self) -> None:
        """Setup vector search endpoint."""
        self.logger.info("Setting up vector search endpoint...")

        from databricks.vector_search.client import VectorSearchClient

        self._client = VectorSearchClient(disable_notice=True)

        try:
            # Safely list existing endpoints
            response = self._client.list_endpoints()
            existing_endpoints = [ep['name'] for ep in response.get('endpoints', [])]
        except Exception as e:
            self.logger.info(f"Could not fetch Vector Search endpoints: {e}")
            existing_endpoints = []

        # Check if endpoint already exists
        if self._vs_endpoint in existing_endpoints:
            self.logger.info(f"Endpoint '{self._vs_endpoint}' already exists. Skipping creation.")
        else:
            try:
                self.logger.info(f"Creating new endpoint '{self._vs_endpoint}' ...")
                self._client.create_endpoint(
                    name=self._vs_endpoint,
                    endpoint_type="STANDARD"
                )
                self.logger.info(f"Endpoint '{self._vs_endpoint}' created successfully.")
            except Exception as e:
                self.logger.info(f"Exception occurred while creating the Vector Search endpoint: {e}")

    def _wait_for_vs_endpoint(self) -> None:
        """Wait for VS endpoint to be ready."""
        self.logger.info("Waiting for VS endpoint to be ready...")

        from lakefusion_core_engine.utils.model_serving import wait_until_vector_search_ready

        try:
            wait_until_vector_search_ready(endpoint_name=self._vs_endpoint)
            self.logger.info(f"Vector Search endpoint '{self._vs_endpoint}' is ready")
        except ValueError as e:
            error_msg = f"ERROR: Vector search endpoint not ready: {str(e)}"
            self.logger.info(error_msg)
            raise

    def _create_or_sync_index(self) -> None:
        """Create or sync vector search index (matching production logic)."""
        self.logger.info("Creating/syncing vector search index...")

        from lakefusion_core_engine.utils.model_serving import sync_index_with_retry

        index_name = f"{self.context.master_table}_index"
        self._stats['index_name'] = index_name

        # -------------------------------------------------
        # STEP 4.1: Create index with retry logic
        # -------------------------------------------------
        MAX_CREATE_RETRIES = 3
        CREATE_RETRY_INTERVAL = 60  # seconds
        index_already_exists = False

        for attempt in range(1, MAX_CREATE_RETRIES + 1):
            try:
                self.logger.info(f"Attempting to create index (attempt {attempt}/{MAX_CREATE_RETRIES})...")
                self._index = self._client.create_delta_sync_index(
                    endpoint_name=self._vs_endpoint,
                    source_table_name=self.context.master_table,
                    index_name=index_name,
                    pipeline_type="TRIGGERED",
                    primary_key=self._master_id_key,
                    embedding_source_column=self._merged_desc_column,
                    embedding_model_endpoint_name=self._embedding_endpoint
                )
                self.logger.info(f"Create request submitted for index: {index_name}")
                break  # Success, exit retry loop

            except Exception as e:
                error_msg = str(e)
                error_lower = error_msg.lower()

                # Case 1: Index already exists - this is fine, proceed to wait loop
                if "already exists" in error_lower:
                    self.logger.info(f"Index already exists, proceeding to sync: {error_msg}")
                    index_already_exists = True
                    break

                # Case 2: Permanent errors - fail immediately
                if ("maximum number of indexes" in error_lower or
                    "permission denied" in error_lower or
                    "unauthorized" in error_lower):
                    raise RuntimeError(f"Index creation failed: {error_msg}")

                # Case 3: Transient errors - retry
                self.logger.info(f"Create attempt {attempt} failed: {error_msg}")
                if attempt < MAX_CREATE_RETRIES:
                    self.logger.info(f"Retrying in {CREATE_RETRY_INTERVAL} seconds...")
                    time.sleep(CREATE_RETRY_INTERVAL)
                else:
                    raise RuntimeError(
                        f"Index creation failed after {MAX_CREATE_RETRIES} attempts: {error_msg}"
                    )

        # -------------------------------------------------
        # STEP 4.2: Wait for index registration
        # -------------------------------------------------
        self.logger.info("Waiting for index registration...")

        REGISTRATION_TIMEOUT = 1800  # 30 minutes
        start = time.time()

        while self._index is None:
            if time.time() - start > REGISTRATION_TIMEOUT:
                raise TimeoutError(
                    f"Index '{index_name}' not registered within {REGISTRATION_TIMEOUT}s"
                )

            try:
                self._index = self._client.get_index(
                    endpoint_name=self._vs_endpoint,
                    index_name=index_name,
                )
                self.logger.info("Index is now registered and accessible")
            except Exception as e:
                error_lower = str(e).lower()
                if "not exist" in error_lower or "not_exist" in error_lower:
                    self.logger.info("  Index not visible yet - waiting...")
                    time.sleep(20)
                else:
                    raise RuntimeError(f"Unexpected error while locating index: {e}")

        # -------------------------------------------------
        # STEP 4.3: Wait for index to be ready before sync
        # -------------------------------------------------
        self.logger.info("Waiting for index to be ready before sync...")
        self._index.wait_until_ready()
        self.logger.info("Index is ready")

        # -------------------------------------------------
        # STEP 4.4: Trigger sync (if not already running)
        # -------------------------------------------------
        # Log current status for debugging
        index_status = self._index.describe()['status']
        current_status = index_status.get('detailed_state', 'UNKNOWN')
        self.logger.info(f"Current index status: {current_status}")

        # Log additional details if pipeline failed
        if current_status == "ONLINE_PIPELINE_FAILED":
            status_message = index_status.get('message', 'No message available')
            self.logger.info(f"Pipeline failure details: {status_message}")
            self.logger.info(f"Full index status: {index_status}")

        # Only trigger sync if not already running (can't sync while RUNNING)
        if current_status in ["ONLINE_TRIGGERED_UPDATE", "ONLINE_UPDATING_PIPELINE_RESOURCES", "ONLINE_PIPELINE_FAILED"]:
            self.logger.info("Sync already in progress or failed. Skipping sync trigger...")
        else:
            self.logger.info("Triggering index sync (with scale-from-zero retry handling)...")
            try:
                sync_index_with_retry(
                    index=self._index,
                    embedding_endpoint_name=self._embedding_endpoint,
                    max_retries=10,
                    retry_interval_seconds=60,
                    timeout_minutes=10
                )
                self.logger.info("Index sync initiated successfully!")
            except Exception as sync_error:
                error_msg = f"ERROR: Index sync failed: {str(sync_error)}"
                self.logger.info(error_msg)
                raise RuntimeError(error_msg)

        # -------------------------------------------------
        # STEP 4.5: Tolerant wait loop for sync completion
        # -------------------------------------------------
        self.logger.info("Waiting for index to be ready and synced...")
        start_time = time.time()
        pipeline_failed_count = 0

        try:
            self._index.wait_until_ready()

            while True:
                index_status_info = self._index.describe()['status']
                status = index_status_info.get('detailed_state', 'UNKNOWN')
                self.logger.info(f"  Index status: {status}")

                # Success
                if status == "ONLINE_NO_PENDING_UPDATE":
                    self.logger.info("Index is fully synced and ready.")
                    break

                # Actively updating - reset timer, let it continue (no timeout while making progress)
                if status in ["ONLINE_TRIGGERED_UPDATE", "ONLINE_UPDATING_PIPELINE_RESOURCES"]:
                    start_time = time.time()  # Reset timer since progress is being made
                    self.logger.info("  Sync in progress, resetting timeout timer...")

                # Transient failure handling - apply timeout only when failed
                if status == "ONLINE_PIPELINE_FAILED":
                    pipeline_failed_count += 1
                    # Log failure details
                    status_message = index_status_info.get('message', 'No message available')
                    self.logger.info(
                        f"ONLINE_PIPELINE_FAILED detected "
                        f"({pipeline_failed_count}/{self.MAX_PIPELINE_FAILURES})"
                    )
                    self.logger.info(f"  Failure reason: {status_message}")

                    # Check timeout only when in failed state
                    elapsed = time.time() - start_time
                    if elapsed > self.TIMEOUT_SECONDS:
                        error_message = (
                            f"ERROR: Index sync timed out after "
                            f"{int(elapsed)} seconds in failed state"
                        )
                        self.logger.info(f"{error_message}")
                        raise TimeoutError(error_message)

                    if pipeline_failed_count >= self.MAX_PIPELINE_FAILURES:
                        error_message = (
                            f"ERROR: Index entered ONLINE_PIPELINE_FAILED "
                            f"state 3 times. Last message: {status_message}"
                        )
                        self.logger.info(f"{error_message}")
                        raise Exception(error_message)

                # Still processing
                time.sleep(self.POLL_INTERVAL)

        except Exception as e:
            error_message = f"ERROR: Index failed to sync: {e}"
            self.logger.info(f"{error_message}")
            raise

    def _get_optimal_partitions(self, row_count: int, workload_type: str = "vs") -> int:
        """
        Calculate optimal partition count based on data size.

        Args:
            row_count: Total number of rows
            workload_type: "vs" for Vector Search, "merge" for Delta merge

        Returns:
            Optimal partition count
        """
        if workload_type == "vs":
            # Vector Search: 200-500 rows per partition
            if row_count <= 500:
                target_rows, min_p, max_p = 50, 1, 10
            elif row_count <= 2000:
                target_rows, min_p, max_p = 100, 4, 20
            elif row_count <= 10000:
                target_rows, min_p, max_p = 200, 8, 50
            elif row_count <= 50000:
                target_rows, min_p, max_p = 300, 16, 166
            elif row_count <= 200000:
                target_rows, min_p, max_p = 500, 32, 400
            elif row_count <= 1000000:
                target_rows, min_p, max_p = 1000, 64, 1000
            else:
                target_rows, min_p, max_p = 2000, 128, 2000

            calculated = row_count // target_rows
            partitions = max(min_p, min(max_p, calculated))

        return partitions

    def _filter_pending_records(self):
        """Filter records needing vector search."""
        self.logger.info("Filtering records for vector search...")

        from pyspark.sql.functions import col

        # Read unified table
        df_unified = self.spark.table(self.context.unified_table)

        # CRITICAL: Filter for records with ACTIVE status AND empty search_results
        # These are the records that need to be matched against master
        df_pending_search = df_unified.filter(
            (col("record_status") == "ACTIVE") &
            (col("search_results") == "")
        ).select(self._unified_id_key, self._merged_desc_column)

        # Check if empty (matching production logic)
        pending_count = df_pending_search.isEmpty()

        self.logger.info(f"Records pending search (ACTIVE + empty search_results): {pending_count}")

        if pending_count:
            self.logger.info("\nNo records to process - all ACTIVE records already have search results")
            return None, True

        # Get actual row count for partitioning
        row_count = df_pending_search.count()

        # Calculate optimal partitions using production logic
        optimal_partitions = self._get_optimal_partitions(row_count, workload_type="vs")
        self.logger.info(f"optimal_partitions: {optimal_partitions}")

        # Repartition
        df_pending_search = df_pending_search.repartition(optimal_partitions)

        self._stats['pending_count'] = row_count
        self._stats['optimal_partitions'] = optimal_partitions

        return df_pending_search, False

    def _execute_vector_search(self, df_pending):
        """Execute vector search via UDF with ThreadPoolExecutor concurrency."""
        self.logger.info("Defining and executing vector search UDF...")

        from pyspark.sql.functions import pandas_udf, expr
        from pyspark.sql.types import ArrayType, StructType, StructField, StringType, FloatType
        import pandas as pd
        from databricks.vector_search.client import VectorSearchClient
        from concurrent.futures import ThreadPoolExecutor, as_completed

        # Import retry function from SDK utils
        from lakefusion_core_engine.utils.model_serving import similarity_search_with_retry

        # Capture variables for UDF closure
        master_table = self.context.master_table
        merged_desc_column = self._merged_desc_column
        master_id_key = self._master_id_key
        max_potential_matches = self._max_potential_matches

        # UDF schema: returns array of struct with description, lakefusion_id, and score
        result_schema = ArrayType(StructType([
            StructField("text", StringType()),
            StructField("lakefusion_id", StringType()),
            StructField("score", FloatType())
        ]))

        # Get fresh client and index for UDF
        client = VectorSearchClient()
        index = client.get_index(index_name=f"{master_table}_index")

        # Extract logger before UDF to avoid capturing `self` (which contains dbutils)
        # in the UDF closure — dbutils cannot be pickled by Spark
        logger = self.logger

        @pandas_udf(result_schema)
        def vector_search_results_udf(descriptions: pd.Series) -> pd.Series:
            """
            Perform vector search against master table for each unified record.
            Uses ThreadPoolExecutor for concurrent execution within each partition.

            Args:
                descriptions: Series of attribute_combined strings from unified table

            Returns:
                Series of arrays containing top matches from master table with scores
            """
            def get_results(text):
                try:
                    # Use retry wrapper with exponential backoff
                    results = similarity_search_with_retry(
                        index,
                        query_text=text,
                        columns=[merged_desc_column, master_id_key],
                        num_results=int(max_potential_matches)
                    )

                    formatted = []
                    for r in results["result"]["data_array"]:
                        formatted.append({
                            "text": r[0],              # attributes_combined
                            "lakefusion_id": r[1],    # lakefusion_id from master
                            "score": float(r[2])      # similarity score
                        })
                    return formatted

                except Exception as e:
                    logger.info(f"Error during vector search for input: {text[:50]}... -> {e}")
                    return []

            # Use ThreadPoolExecutor for concurrent execution within partition
            with ThreadPoolExecutor(max_workers=10) as executor:
                futures = {executor.submit(get_results, desc): i
                           for i, desc in enumerate(descriptions)}
                results = [None] * len(descriptions)
                for future in as_completed(futures):
                    results[futures[future]] = future.result()
            return pd.Series(results)

        self.logger.info("Vector search UDF defined")
        self.logger.info(f"  - Searches against: {master_table}")
        self.logger.info(f"  - Returns top {max_potential_matches} matches per record")
        self.logger.info(f"  - Includes: text, lakefusion_id, score")

        # Execute vector search
        self.logger.info("Running vector search (this may take a while for large datasets)...")

        df_with_results = df_pending.withColumn(
            "search_results_array",
            vector_search_results_udf(df_pending[self._merged_desc_column])
        )

        # Convert array-of-structs to a formatted string for storage
        df_with_final_results = df_with_results.withColumn(
            "search_results",
            expr("""
              concat_ws('], [', transform(search_results_array, x ->
                concat(x.text, ', ', x.lakefusion_id, ', ', cast(x.score as string))
              ))
            """).alias("search_results")
        )

        # Note: count is commented out in production for performance
        # search_results_count = df_with_final_results.count()
        # self.logger.info(f"Vector search completed for {search_results_count} records")

        return df_with_final_results

    def _deduplicate_results(self, df_results):
        """Deduplicate results."""
        self.logger.info("Deduplicating results...")

        # Deduplicate by surrogate_key (keeping first occurrence)
        df_deduplicated = df_results.dropDuplicates([self._unified_id_key])

        # Note: count is commented out in production for performance
        # dedup_count = df_deduplicated.count()
        # self.logger.info(f"Deduplicated results: {dedup_count} unique records")

        return df_deduplicated

    def _merge_results(self, df_deduped):
        """Merge results to unified table."""
        self.logger.info("Merging results to unified table...")

        from delta.tables import DeltaTable

        delta_table = DeltaTable.forName(self.spark, self.context.unified_table)

        # Note: counts are commented out in production for performance
        # before_merge_empty = self.spark.table(self.context.unified_table).filter(
        #     col("search_results") == ""
        # ).count()

        # Perform merge operation
        delta_table.alias("target").merge(
            source=df_deduped.alias("source"),
            condition=f"target.{self._unified_id_key} = source.{self._unified_id_key}"
        ).whenMatchedUpdate(
            set={"search_results": "source.search_results"}
        ).execute()

        # Note: counts are commented out in production for performance
        # after_merge_empty = self.spark.table(self.context.unified_table).filter(
        #     col("search_results") == ""
        # ).count()

        self.logger.info(f"Merge completed")
        # self.logger.info(f"  Records with empty search_results before: {before_merge_empty}")
        # self.logger.info(f"  Records with empty search_results after: {after_merge_empty}")
        # self.logger.info(f"  Records updated: {before_merge_empty - after_merge_empty}")
