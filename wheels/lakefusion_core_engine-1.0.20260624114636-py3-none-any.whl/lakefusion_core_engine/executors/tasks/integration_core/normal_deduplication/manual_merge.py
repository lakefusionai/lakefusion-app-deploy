"""
Manual Merge Executor for normal deduplication.

Handles manual merge operations where unified records are merged into a master record.
Applies survivorship rules to determine the final attribute values.

Workflow:
1. Validate master record exists
2. Fetch existing MERGED contributors
3. Fetch new records to merge
4. Combine all contributors
5. Prepare records for survivorship
6. Apply survivorship engine
7. Update master table
8. Update attribute version sources
9. Log manual merge activities
10. Update unified table for merged records
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql.functions import (
    col, lit, collect_list, struct,
    current_timestamp, udf, concat_ws, coalesce
)
from pyspark.sql.types import (
    StructType, StructField, StringType, MapType, ArrayType
)
from delta.tables import DeltaTable

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult

from lakefusion_core_engine.utils import merged_record_column
from lakefusion_core_engine.utils.steward_decisions import write_steward_decision


class ManualMergeExecutor(BaseStepTask):
    """
    Executor for manual merge operations.

    Merges unified records into a master record using survivorship rules.
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        super().__init__(context, override_instance=override_instance)
        self.id_key = context.master_id_key
        self.unified_id_key = context.unified_id_key
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Instance variables for intermediate results
        self.new_contributors_data = None
        self.new_contributors_schema = None
        self.new_count = 0
        self.existing_count = 0
        self.total_count = 0
        self.new_master_version = 0
        self.merge_activities_count = 0

        # Step-specific intermediate results
        self._existing_contributors_df: DataFrame = None
        self._new_contributors_df: DataFrame = None
        self._all_contributors_df: DataFrame = None
        self._grouped_contributors: DataFrame = None
        self._final_results_df: DataFrame = None
        self._survivorship_engine = None

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*80)
        self.logger.info("MANUAL MERGE PROCESSING")
        self.logger.info("="*80)
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Master ID: {self.context.master_id}")
        self.logger.info(f"Master ID Key: {self.id_key}")
        self.logger.info(f"Unified ID Key: {self.unified_id_key}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id or 'None'}")
        self.logger.info(f"Unified Table: {self.context.unified_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Merge Activities Table: {self.context.merge_activities_table}")
        self.logger.info(f"Attribute Version Sources Table: {self.context.attribute_version_sources_table}")

        # Parse unified_dataset_ids
        unified_dataset_ids = self.context.unified_dataset_ids
        unified_record_ids = []
        dataset_ids = []
        for unified_dataset_id in unified_dataset_ids:
            unified_record_ids.append(unified_dataset_id.get("id"))
            dataset_ids.append(unified_dataset_id.get("dataset_id"))

        self.logger.info(f"Records to merge: {len(unified_record_ids)}")
        self.logger.info(f"Surrogate keys: {unified_record_ids}")
        self.logger.info(f"Dataset IDs: {dataset_ids}")
        self.logger.info("="*80)

        # Store for use in execute
        self.context.state['unified_record_ids'] = unified_record_ids
        self.context.state['dataset_ids'] = dataset_ids

        # Capture record snapshots BEFORE any modifications for steward decisions
        try:
            spark = self.context.spark
            entity_attributes = self.context.entity_attributes
            attr_cols = ", ".join(entity_attributes)
            master_id = self.context.master_id

            master_row = spark.sql(
                f"SELECT {attr_cols} FROM {self.context.master_table} WHERE {self.id_key} = '{master_id}'"
            ).collect()
            self._sd_master_attrs = master_row[0].asDict() if master_row else {}

            match_id = unified_record_ids[0] if unified_record_ids else None
            if match_id:
                match_row = spark.sql(
                    f"SELECT {attr_cols}, source_path FROM {self.context.unified_table} WHERE {self.unified_id_key} = '{match_id}'"
                ).collect()
                self._sd_match_attrs = match_row[0].asDict() if match_row else {}
            else:
                self._sd_match_attrs = {}
        except Exception as e:
            self.logger.warning(f"Could not capture steward decision snapshots: {e}")
            self._sd_master_attrs = {}
            self._sd_match_attrs = {}

    @step(order=1, name="Validate Master Record Exists", returns="master_exists count")
    def step_validate_master_exists(self) -> Dict[str, Any]:
        """Validate that the master record exists."""
        spark = self.context.spark
        master_id = self.context.master_id

        master_exists_query = f"""
        SELECT COUNT(*) as count
        FROM {self.context.master_table}
        WHERE {self.id_key} = '{master_id}'
        """

        master_exists = spark.sql(master_exists_query).collect()[0]['count']

        if master_exists == 0:
            error_msg = f"ERROR: Master record with {self.id_key} = '{master_id}' not found"
            self.logger.info(error_msg)
            raise ValueError(error_msg)

        self.logger.info(f"Master record exists: {self.id_key} = {master_id}")

        return {'master_exists': master_exists, 'master_id': master_id}

    @step(order=2, name="Fetch Existing Contributors", returns="existing_contributors_df")
    def step_fetch_existing_contributors(self) -> Dict[str, Any]:
        """Fetch existing MERGED contributors for the master record."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes
        master_id = self.context.master_id

        attribute_cols = ", ".join([f"u.{attr}" for attr in entity_attributes])

        existing_contributors_query = f"""
        SELECT
            u.{self.unified_id_key},
            u.source_path,
            {attribute_cols}
        FROM {self.context.unified_table} u
        WHERE u.master_{self.id_key} = '{master_id}'
            AND u.record_status = 'MERGED'
        """

        self._existing_contributors_df = spark.sql(existing_contributors_query)
        self.existing_count = self._existing_contributors_df.count()

        self.logger.info(f"Existing contributors found: {self.existing_count}")

        return {'existing_count': self.existing_count}

    @step(order=3, name="Fetch New Records to Merge", returns="new_contributors_df")
    def step_fetch_new_records(self) -> Dict[str, Any]:
        """Fetch new records to merge from the unified table."""
        spark = self.context.spark
        unified_record_ids = self.context.state['unified_record_ids']
        entity_attributes = self.context.entity_attributes

        attribute_cols = ", ".join([f"u.{attr}" for attr in entity_attributes])
        surrogate_keys_list = ", ".join([f"'{sk}'" for sk in unified_record_ids])

        new_contributors_query = f"""
        SELECT
            u.{self.unified_id_key},
            u.source_path,
            {attribute_cols}
        FROM {self.context.unified_table} u
        WHERE u.{self.unified_id_key} IN ({surrogate_keys_list})
            AND u.record_status = 'ACTIVE'
        """

        self._new_contributors_df = spark.sql(new_contributors_query)
        self.new_count = self._new_contributors_df.count()

        self.logger.info(f"New records to merge: {self.new_count}")

        # Validate all requested records were found
        if self.new_count != len(unified_record_ids):
            missing_count = len(unified_record_ids) - self.new_count
            self.logger.info(f"WARNING: {missing_count} requested records not found or not in ACTIVE status")

            found_keys = [row[self.unified_id_key] for row in self._new_contributors_df.select(self.unified_id_key).collect()]
            missing_keys = [sk for sk in unified_record_ids if sk not in found_keys]
            self.logger.info(f"  Missing keys: {missing_keys}")

        if self.new_count == 0:
            error_msg = "ERROR: No ACTIVE records found to merge"
            self.logger.info(error_msg)
            raise ValueError(error_msg)

        # Materialize data for later use
        self.new_contributors_schema = self._new_contributors_df.schema
        self.new_contributors_data = self._new_contributors_df.collect()
        self.logger.info(f"Materialized {len(self.new_contributors_data)} new contributor records")

        return {'new_count': self.new_count}

    @step(order=4, name="Combine All Contributors", returns="all_contributors_df")
    def step_combine_contributors(self) -> Dict[str, Any]:
        """Combine existing and new contributors."""
        self._all_contributors_df = self._existing_contributors_df.union(self._new_contributors_df)
        self.total_count = self._all_contributors_df.count()

        self.logger.info(f"Total contributors: {self.total_count}")
        self.logger.info(f"  Existing: {self.existing_count}")
        self.logger.info(f"  New: {self.new_count}")

        self.logger.info("\nUnified Records:")
        self._all_contributors_df.select(self.unified_id_key, "source_path").show(10, truncate=False)

        return {'total_count': self.total_count}

    @step(order=5, name="Prepare Records for Survivorship", returns="grouped_contributors")
    def step_prepare_for_survivorship(self) -> Dict[str, Any]:
        """Group records for survivorship processing."""
        entity_attributes = self.context.entity_attributes
        master_id = self.context.master_id

        self._grouped_contributors = (
            self._all_contributors_df
            .withColumn(self.id_key, lit(master_id))
            .groupBy(self.id_key)
            .agg(
                collect_list(
                    struct(
                        col(self.unified_id_key),
                        col("source_path"),
                        *[col(attr) for attr in entity_attributes]
                    )
                ).alias("unified_records")
            )
        )

        self.logger.info(f"Records grouped for survivorship")
        self.logger.info(f"  Total records in group: {self.total_count}")

        return {'grouped': True}

    @step(order=6, name="Apply Survivorship Engine", returns="survivorship results")
    def step_apply_survivorship(self) -> Dict[str, Any]:
        """Apply survivorship rules to determine final attribute values."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes
        entity_attributes_datatype = self.context.entity_attributes_datatype
        default_survivorship_rules = self.context.default_survivorship_rules
        dataset_objects = self.context.dataset_objects

        # Initialize survivorship engine
        from lakefusion_core_engine.survivorship import SurvivorshipEngine

        self.logger.info(f"  Survivorship rules: {len(default_survivorship_rules)}")

        self._survivorship_engine = SurvivorshipEngine(
            survivorship_config=default_survivorship_rules,
            entity_attributes=entity_attributes,
            entity_attributes_datatype=entity_attributes_datatype,
            id_key=self.unified_id_key
        )

        self.logger.info("Survivorship Engine initialized")

        # Define UDF wrapper
        engine = self._survivorship_engine

        def apply_survivorship_wrapper(unified_records):
            records_list = [r.asDict() for r in unified_records]
            result = engine.apply_survivorship(unified_records=records_list)
            return result.to_dict()

        udf_output_schema = StructType([
            StructField("resultant_record", MapType(StringType(), StringType())),
            StructField("resultant_master_attribute_source_mapping", ArrayType(StructType([
                StructField("attribute_name", StringType()),
                StructField("attribute_value", StringType()),
                StructField("source", StringType())
            ])))
        ])

        survivorship_udf = udf(apply_survivorship_wrapper, udf_output_schema)
        self.logger.info("UDF registered")

        result_df = self._grouped_contributors.withColumn(
            "survivorship_result",
            survivorship_udf(col("unified_records"))
        )

        self._final_results_df = result_df.select(
            col(self.id_key),
            col("survivorship_result.resultant_record").alias("merged_record"),
            col("survivorship_result.resultant_master_attribute_source_mapping").alias("attribute_sources")
        )

        self.logger.info(f"Survivorship applied")
        self.logger.info(f"  Master records processed: {self._final_results_df.count()}")

        # Store for later steps
        self.context.state['final_results_df'] = self._final_results_df

        return {'survivorship_applied': True}

    @step(order=7, name="Update Master Table", returns="master table version")
    def step_update_master_table(self) -> Dict[str, Any]:
        """Update the master table with survivorship results."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes
        entity_attributes_datatype = self.context.entity_attributes_datatype
        match_attributes = self.context.match_attributes

        master_updates_cols = [col(self.id_key)]

        for attr in entity_attributes:
            if attr == self.id_key:
                continue

            target_type = entity_attributes_datatype.get(attr, "string")
            master_updates_cols.append(merged_record_column(attr, target_type))

        # Add attributes_combined generation
        if match_attributes:
            concat_cols = []
            for attr in match_attributes:
                if attr in entity_attributes and attr != self.id_key:
                    concat_cols.append(coalesce(col(f"merged_record.{attr}").cast("string"), lit("")))

            if concat_cols:
                master_updates_cols.append(
                    concat_ws(" | ", *concat_cols).alias("attributes_combined")
                )
            else:
                master_updates_cols.append(lit("").alias("attributes_combined"))
        else:
            master_updates_cols.append(lit("").alias("attributes_combined"))

        master_updates_df = self._final_results_df.select(*master_updates_cols)

        self.logger.info(f"Prepared master updates with attributes_combined")
        self.logger.info(f"  Match attributes used: {len([a for a in match_attributes if a in entity_attributes and a != self.id_key])}")

        # Get current master table version
        current_master_version = spark.sql(f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1").select("version").collect()[0][0]
        self.logger.info(f"  Current master table version: {current_master_version}")

        # Perform merge
        master_delta_table = DeltaTable.forName(spark, self.context.master_table)

        update_dict = {attr: f"source.{attr}" for attr in entity_attributes if attr != self.id_key}
        update_dict["attributes_combined"] = "source.attributes_combined"

        master_delta_table.alias("target").merge(
            master_updates_df.alias("source"),
            f"target.{self.id_key} = source.{self.id_key}"
        ).whenMatchedUpdate(set=update_dict).execute()

        self.new_master_version = spark.sql(f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1").select("version").collect()[0][0]

        self.logger.info(f"Master table updated")
        self.logger.info(f"  New version: {self.new_master_version}")
        self.logger.info(f"  Records updated: {master_updates_df.count()}")

        return {'new_master_version': int(self.new_master_version)}

    @step(order=8, name="Update Attribute Version Sources", returns="attribute sources count")
    def step_update_attribute_version_sources(self) -> Dict[str, Any]:
        """Update the attribute version sources table."""
        spark = self.context.spark

        attribute_sources_update_df = self._final_results_df.select(
            col(self.id_key),
            lit(self.new_master_version).alias("version"),
            col("attribute_sources").alias("attribute_source_mapping")
        )

        attr_sources_delta_table = DeltaTable.forName(spark, self.context.attribute_version_sources_table)

        attr_sources_delta_table.alias("target").merge(
            attribute_sources_update_df.alias("source"),
            f"target.{self.id_key} = source.{self.id_key} AND target.version = source.version"
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

        count = attribute_sources_update_df.count()
        self.logger.info(f"Attribute version sources updated")
        self.logger.info(f"  Records updated: {count}")

        return {'attribute_sources_updated': count}

    @step(order=9, name="Log Manual Merge Activities", returns="merge activities count")
    def step_log_merge_activities(self) -> Dict[str, Any]:
        """Log manual merge activities to the merge activities table."""
        spark = self.context.spark
        master_id = self.context.master_id

        # Recreate dataframe from materialized data
        new_contributors_df = spark.createDataFrame(self.new_contributors_data, schema=self.new_contributors_schema)

        merge_activities_df = (
            new_contributors_df
            .select(
                lit(master_id).alias("master_id"),
                col(self.unified_id_key).alias("match_id"),
                col("source_path").alias("source"),
                lit(self.new_master_version).alias("version"),
                lit("MANUAL_MERGE").alias("action_type"),
                current_timestamp().alias("created_at")
            )
        )

        self.merge_activities_count = merge_activities_df.count()

        if self.merge_activities_count > 0:
            merge_activities_delta_table = DeltaTable.forName(spark, self.context.merge_activities_table)

            merge_activities_delta_table.alias("target").merge(
                merge_activities_df.alias("source"),
                f"""target.match_id = source.match_id
                    AND target.master_id = source.master_id
                    AND target.version = source.version
                    AND target.action_type = source.action_type"""
            ).whenNotMatchedInsertAll().execute()

            self.logger.info(f"Merge activities logged")
            self.logger.info(f"  New MANUAL_MERGE activities: {self.merge_activities_count}")
        else:
            self.logger.info("  No new merge activities to log")

        return {'merge_activities_logged': self.merge_activities_count}

    @step(order=10, name="Update Unified Table for Merged Records", returns="unified records updated")
    def step_update_unified_table(self) -> Dict[str, Any]:
        """Update the unified table to mark merged records."""
        spark = self.context.spark
        master_id = self.context.master_id

        # Recreate dataframe from materialized data
        new_contributors_df = spark.createDataFrame(self.new_contributors_data, schema=self.new_contributors_schema)

        unified_updates_df = (
            new_contributors_df
            .select(
                col(self.unified_id_key),
                lit(master_id).alias(f"master_{self.id_key}"),
                lit("MERGED").alias("record_status")
            )
        )

        count = unified_updates_df.count()
        self.logger.info(f"  Prepared {count} records for unified table update")

        unified_delta_table = DeltaTable.forName(spark, self.context.unified_table)

        unified_delta_table.alias("target").merge(
            unified_updates_df.alias("source"),
            f"target.{self.unified_id_key} = source.{self.unified_id_key}"
        ).whenMatchedUpdate(set={
            f"master_{self.id_key}": f"source.master_{self.id_key}",
            "record_status": "source.record_status"
        }).execute()

        self.logger.info(f"Unified table updated")
        self.logger.info(f"  Records updated: {count}")

        return {'unified_records_updated': count}

    @step(order=11, name="Write Steward Decision", returns="decision_id")
    def step_write_steward_decision(self) -> Dict[str, Any]:
        """Write frozen record snapshots (captured in pre_execute) to steward_decisions Delta table."""
        unified_record_ids = self.context.state.get('unified_record_ids', [])
        master_attrs = getattr(self, '_sd_master_attrs', {})
        match_attrs = getattr(self, '_sd_match_attrs', {})
        match_source = match_attrs.get("source_path", "") if match_attrs else ""

        decision_id = write_steward_decision(
            spark=self.context.spark,
            catalog_name=self.context.catalog_name,
            entity_name=self.context.entity,
            entity_id=str(self.context.entity_id or ""),
            action_type="MANUAL_MERGE",
            master_id=self.context.master_id,
            match_id=unified_record_ids[0] if unified_record_ids else "",
            master_attrs=master_attrs,
            match_attrs=match_attrs,
            match_source=match_source,
            created_by=self.context.params.get("created_by", ""),
            logger=self.logger,
        )
        return {"decision_id": decision_id}

    def execute(self) -> TaskResult:
        """Execute the manual merge workflow."""
        # Step 1: Validate master record exists
        self.step_validate_master_exists()

        # Step 2: Fetch existing contributors
        self.step_fetch_existing_contributors()

        # Step 3: Fetch new records to merge
        self.step_fetch_new_records()

        # Step 4: Combine all contributors
        self.step_combine_contributors()

        # Step 5: Prepare records for survivorship
        self.step_prepare_for_survivorship()

        # Step 6: Apply survivorship engine
        self.step_apply_survivorship()

        # Step 7: Update master table
        self.step_update_master_table()

        # Step 8: Update attribute version sources
        self.step_update_attribute_version_sources()

        # Step 9: Log manual merge activities
        self.step_log_merge_activities()

        # Step 10: Update unified table for merged records
        self.step_update_unified_table()

        # Step 11: Write steward decision with frozen snapshots
        self.step_write_steward_decision()

        # Return success
        return TaskResult.success(
            message="Manual merge completed successfully",
            task_name=self.context.task_name,
            metrics={
                'master_id': self.context.master_id,
                'records_merged': self.new_count,
                'existing_contributors': self.existing_count,
                'total_contributors': self.total_count,
                'merge_activities_logged': self.merge_activities_count,
                'master_version': int(self.new_master_version)
            },
            task_values={
                'manual_merge_complete': True,
                'records_merged': self.new_count,
                'master_id': self.context.master_id,
                'master_version': int(self.new_master_version)
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        # Validate records were merged
        result.add_validation(ValidationResult(
            passed=self.new_count > 0,
            message="Records merged",
            expected="> 0",
            actual=self.new_count
        ))

        # Validate master table version incremented
        result.add_validation(ValidationResult(
            passed=self.new_master_version > 0,
            message="Master table version updated",
            expected="> 0",
            actual=self.new_master_version
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*80)
        self.logger.info("MANUAL MERGE PROCESSING COMPLETE")
        self.logger.info("="*80)

        if result.is_success:
            metrics = result.metrics
            self.logger.info(f"\nSummary:")
            self.logger.info(f"  Master ID: {metrics.get('master_id')}")
            self.logger.info(f"  New records merged: {metrics.get('records_merged')}")
            self.logger.info(f"  Existing contributors: {metrics.get('existing_contributors')}")
            self.logger.info(f"  Total contributors: {metrics.get('total_contributors')}")
            self.logger.info(f"  Merge activities logged: {metrics.get('merge_activities_logged')}")
            self.logger.info(f"  Master table version: {metrics.get('master_version')}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        # Set task values for downstream tasks
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Manual merge failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.info(f"  Error: {error}")
