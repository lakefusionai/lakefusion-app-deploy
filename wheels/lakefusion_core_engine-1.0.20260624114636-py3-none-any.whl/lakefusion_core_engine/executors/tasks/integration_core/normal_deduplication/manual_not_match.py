"""
Manual Not Match Executor for normal deduplication.

Handles manual "not a match" operations where unified records are marked as not matching
a specific master record. If records have no other potential matches, they are inserted
as new individual masters.

Workflow:
1. Validate master record exists
2. Validate records exist and get source paths
3. Log MANUAL_NOT_A_MATCH activities
4. Check for other potential matches
5. Decision point - if all have other matches, exit early
6. Fetch full records for insertion
7. Generate new lakefusion IDs
8. Prepare records for master insert
9. Insert into master table
10. Prepare attribute version sources
11. Update attribute version sources
12. Log JOB_INSERT activities
13. Update unified table
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql.functions import (
    col, lit, collect_list, struct,
    current_timestamp, udf, concat_ws, coalesce
)
from pyspark.sql.types import (
    StructType, StructField, StringType, ArrayType, BooleanType
)
from delta.tables import DeltaTable

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult
from lakefusion_core_engine.utils.steward_decisions import write_steward_decision


class ManualNotMatchExecutor(BaseStepTask):
    """
    Executor for manual "not a match" operations.

    Marks unified records as not matching a master, and creates new individual
    masters for records without other potential matches.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.id_key = context.master_id_key
        self.unified_id_key = context.unified_id_key
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Will be set during execution
        self.activities_count = 0
        self.with_other_count = 0
        self.without_other_count = 0
        self.new_lakefusion_ids = {}
        self.new_master_version = 0

        # Instance variables for intermediate results
        self.existing_records_data = None
        self.existing_records_schema = None
        self.records_without_other_matches_data = None
        self.full_records_data = None
        self.full_records_schema = None
        self.master_insert_df = None
        self.attr_sources_df = None
        self.early_exit_result = None

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        unified_dataset_ids = self.context.unified_dataset_ids
        not_match_surrogate_keys = []
        not_match_dataset_ids = []
        for item in unified_dataset_ids:
            not_match_surrogate_keys.append(item.get("id"))
            not_match_dataset_ids.append(item.get("dataset_id"))

        self.logger.info("="*80)
        self.logger.info("MANUAL NOT A MATCH PROCESSING")
        self.logger.info("="*80)
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Master ID: {self.context.master_id}")
        self.logger.info(f"Master ID Key: {self.id_key}")
        self.logger.info(f"Unified ID Key: {self.unified_id_key}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id or 'None'}")
        self.logger.info(f"Unified Table: {self.context.unified_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Processed Unified Table: {self.context.processed_unified_table}")
        self.logger.info(f"Merge Activities Table: {self.context.merge_activities_table}")
        self.logger.info(f"Attribute Version Sources Table: {self.context.attribute_version_sources_table}")
        self.logger.info(f"Records to mark as NOT A MATCH: {len(not_match_surrogate_keys)}")
        self.logger.info(f"Surrogate keys: {not_match_surrogate_keys}")
        self.logger.info(f"Dataset IDs: {not_match_dataset_ids}")
        self.logger.info("="*80)

        # Store for use in execute
        self.context.state['not_match_surrogate_keys'] = not_match_surrogate_keys
        self.context.state['not_match_dataset_ids'] = not_match_dataset_ids

        # Capture record snapshots BEFORE any modifications
        try:
            spark = self.context.spark
            attr_cols = ", ".join(self.context.entity_attributes)
            master_row = spark.sql(
                f"SELECT {attr_cols} FROM {self.context.master_table} WHERE {self.id_key} = '{self.context.master_id}'"
            ).collect()
            self._sd_master_attrs = master_row[0].asDict() if master_row else {}
            match_id = not_match_surrogate_keys[0] if not_match_surrogate_keys else None
            if match_id:
                match_row = spark.sql(
                    f"SELECT {attr_cols}, source_path FROM {self.context.unified_table} WHERE {self.unified_id_key} = '{match_id}'"
                ).collect()
                self._sd_match_attrs = match_row[0].asDict() if match_row else {}
            else:
                self._sd_match_attrs = {}
        except Exception as e:
            self.logger.warning(f"Could not capture steward decision snapshots: {e}")
            self._sd_master_attrs = {}
            self._sd_match_attrs = {}

    @step(order=1, name="Validate Master Record Exists", returns="master_exists confirmation")
    def step_validate_master_exists(self) -> Dict[str, Any]:
        """Validate that the master record exists."""
        spark = self.context.spark
        master_id = self.context.master_id

        master_exists_query = f"""
        SELECT COUNT(*) as count
        FROM {self.context.master_table}
        WHERE {self.id_key} = '{master_id}'
        """

        master_exists = spark.sql(master_exists_query).collect()[0]['count']

        if master_exists == 0:
            error_msg = f"ERROR: Master record with {self.id_key} = '{master_id}' not found"
            self.logger.info(error_msg)
            raise ValueError(error_msg)

        self.logger.info(f"  Master record exists: {self.id_key} = {master_id}")

        return {
            'master_id': master_id,
            'master_exists': True
        }

    @step(order=2, name="Validate Records and Get Source Paths", returns="existing_records_data and schema")
    def step_validate_records_and_get_source_paths(self) -> Dict[str, Any]:
        """Validate records exist and get source paths from unified table."""
        spark = self.context.spark
        not_match_surrogate_keys = self.context.state['not_match_surrogate_keys']

        surrogate_keys_list = ", ".join([f"'{sk}'" for sk in not_match_surrogate_keys])

        check_processed_query = f"""
        SELECT DISTINCT {self.unified_id_key}
        FROM {self.context.processed_unified_table}
        WHERE {self.unified_id_key} IN ({surrogate_keys_list})
        """

        processed_records_df = spark.sql(check_processed_query)
        processed_unique_count = processed_records_df.count()

        self.logger.info(f"  Unique surrogate keys found in processed_unified: {processed_unique_count}")

        if processed_unique_count == 0:
            error_msg = "ERROR: No records found in processed_unified table"
            self.logger.info(error_msg)
            raise ValueError(error_msg)

        if processed_unique_count != len(not_match_surrogate_keys):
            missing_count = len(not_match_surrogate_keys) - processed_unique_count
            self.logger.info(f"  WARNING: {missing_count} requested records not found in processed_unified")

            found_keys = [row[self.unified_id_key] for row in processed_records_df.select(self.unified_id_key).collect()]
            missing_keys = [sk for sk in not_match_surrogate_keys if sk not in found_keys]
            self.logger.info(f"  Missing keys: {missing_keys}")

        # Get match counts
        match_count_query = f"""
        SELECT
            {self.unified_id_key},
            COUNT(*) as match_count
        FROM {self.context.processed_unified_table}
        WHERE {self.unified_id_key} IN ({surrogate_keys_list})
        GROUP BY {self.unified_id_key}
        """

        match_counts_df = spark.sql(match_count_query)
        self.logger.info(f"\n  Match counts per record:")
        for row in match_counts_df.collect():
            self.logger.info(f"    {row[self.unified_id_key]}: {row['match_count']} potential matches")

        # Get source paths from unified table
        get_source_paths_query = f"""
        SELECT {self.unified_id_key}, source_path
        FROM {self.context.unified_table}
        WHERE {self.unified_id_key} IN ({surrogate_keys_list})
        """

        existing_records_df = spark.sql(get_source_paths_query)
        existing_count = existing_records_df.count()

        self.logger.info(f"\n  Source paths retrieved from unified table: {existing_count}")

        if existing_count != len(not_match_surrogate_keys):
            self.logger.info(f"  WARNING: Expected {len(not_match_surrogate_keys)} records in unified, found {existing_count}")

        self.existing_records_data = existing_records_df.collect()
        self.existing_records_schema = existing_records_df.schema
        self.logger.info(f"  Materialized {len(self.existing_records_data)} records")

        # Store for later steps
        self.context.state['existing_records_data'] = self.existing_records_data
        self.context.state['existing_records_schema'] = self.existing_records_schema

        return {
            'existing_records_count': len(self.existing_records_data),
            'processed_unique_count': processed_unique_count
        }

    @step(order=3, name="Log MANUAL_NOT_A_MATCH Activities", returns="activities_count")
    def step_log_not_match_activities(self) -> Dict[str, Any]:
        """Log MANUAL_NOT_A_MATCH activities to merge activities table."""
        spark = self.context.spark
        master_id = self.context.master_id

        existing_records_df = spark.createDataFrame(self.existing_records_data)
        master_table_version = spark.sql(f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1").collect()[0]["version"]

        self.logger.info(f"  Master table current version: {master_table_version}")

        not_match_activities_df = existing_records_df.select(
            lit(master_id).alias("master_id"),
            col(self.unified_id_key).alias("match_id"),
            col("source_path").alias("source"),
            lit(master_table_version).alias("version"),
            lit("MANUAL_NOT_A_MATCH").alias("action_type"),
            current_timestamp().alias("created_at")
        )

        self.activities_count = not_match_activities_df.count()
        self.logger.info(f"  Prepared {self.activities_count} MANUAL_NOT_A_MATCH activities")

        merge_activities_delta_table = DeltaTable.forName(spark, self.context.merge_activities_table)

        merge_activities_delta_table.alias("target").merge(
            not_match_activities_df.alias("source"),
            f"""target.match_id = source.match_id
                AND target.master_id = source.master_id
                AND target.action_type = source.action_type"""
        ).whenNotMatchedInsertAll().execute()

        self.logger.info(f"  MANUAL_NOT_A_MATCH activities logged")
        self.logger.info(f"  Records logged: {self.activities_count}")

        return {
            'activities_count': self.activities_count,
            'master_table_version': master_table_version
        }

    @step(order=4, name="Check for Other Potential Matches", returns="with_other_count and without_other_count")
    def step_check_other_potential_matches(self) -> Dict[str, Any]:
        """Check for other potential matches for the records."""
        spark = self.context.spark
        master_id = self.context.master_id
        not_match_surrogate_keys = self.context.state['not_match_surrogate_keys']
        surrogate_keys_list = ", ".join([f"'{sk}'" for sk in not_match_surrogate_keys])

        existing_records_df = spark.createDataFrame(self.existing_records_data)

        # Get not_a_match history
        not_a_match_history_query = f"""
        SELECT DISTINCT
            ma.match_id as {self.unified_id_key},
            ma.master_id as rejected_master_id
        FROM {self.context.merge_activities_table} ma
        WHERE ma.action_type = 'MANUAL_NOT_A_MATCH'
            AND ma.match_id IN ({surrogate_keys_list})
        """

        not_a_match_history_df = spark.sql(not_a_match_history_query)
        not_a_match_count = not_a_match_history_df.count()

        self.logger.info(f"  Found {not_a_match_count} previously rejected masters for these records")

        if not_a_match_count > 0:
            self.logger.info(f"  Previously rejected masters:")
            for row in not_a_match_history_df.collect():
                self.logger.info(f"    {row[self.unified_id_key]} -> Rejected master: {row['rejected_master_id']}")

        # Get records with match results
        check_matches_query = f"""
        SELECT
            pu.{self.unified_id_key},
            pu.exploded_result.lakefusion_id as match_lakefusion_id,
            pu.exploded_result.score as match_score,
            pu.exploded_result.match as match_type,
            pu.exploded_result.reason as match_reason
        FROM {self.context.processed_unified_table} pu
        WHERE pu.{self.unified_id_key} IN ({surrogate_keys_list})
        """

        records_with_matches_df = spark.sql(check_matches_query)

        self.logger.info(f"\n  All matches found in processed_unified:")
        matches_data = records_with_matches_df.collect()
        for row in matches_data:
            self.logger.info(f"    {row[self.unified_id_key]} -> Master: {row['match_lakefusion_id']}, Score: {row['match_score']}, Type: {row['match_type']}")

        # Filter for other matches
        if not_a_match_count > 0:
            other_potential_matches_df = records_with_matches_df.join(
                not_a_match_history_df,
                on=[
                    records_with_matches_df[self.unified_id_key] == not_a_match_history_df[self.unified_id_key],
                    records_with_matches_df["match_lakefusion_id"] == not_a_match_history_df["rejected_master_id"]
                ],
                how="left_anti"
            ).filter(
                (col("match_lakefusion_id") != master_id) &
                (col("match_type") == "POTENTIAL_MATCH")
            )
        else:
            other_potential_matches_df = records_with_matches_df.filter(
                (col("match_lakefusion_id") != master_id) &
                (col("match_type") == "POTENTIAL_MATCH")
            )

        # Group and check for other potential matches
        grouped_other_matches_df = other_potential_matches_df.groupBy(self.unified_id_key).agg(
            collect_list("match_lakefusion_id").alias("other_potential_match_ids"),
            collect_list("match_score").alias("other_match_scores"),
            collect_list("match_type").alias("other_match_types")
        )

        def has_other_potential_matches_udf_func(match_ids_array):
            if not match_ids_array:
                return False
            return len(match_ids_array) > 0

        has_other_potential_matches_udf = udf(has_other_potential_matches_udf_func, BooleanType())

        records_with_other_matches_check = grouped_other_matches_df.withColumn(
            "has_other_potential_matches",
            has_other_potential_matches_udf(col("other_potential_match_ids"))
        )

        records_with_other_matches_df_full = records_with_other_matches_check.join(
            existing_records_df,
            on=self.unified_id_key,
            how="inner"
        )

        records_without_grouped = existing_records_df.join(
            grouped_other_matches_df,
            on=self.unified_id_key,
            how="left_anti"
        ).withColumn("has_other_potential_matches", lit(False))

        records_with_other_matches_df = records_with_other_matches_df_full.select(
            self.unified_id_key, "source_path", "has_other_potential_matches",
            "other_potential_match_ids", "other_match_scores", "other_match_types"
        ).unionByName(
            records_without_grouped.select(
                self.unified_id_key, "source_path", "has_other_potential_matches",
                lit(None).cast("array<string>").alias("other_potential_match_ids"),
                lit(None).cast("array<string>").alias("other_match_scores"),
                lit(None).cast("array<string>").alias("other_match_types")
            ),
            allowMissingColumns=True
        )

        records_with_other_matches = records_with_other_matches_df.filter(col("has_other_potential_matches") == True)
        records_without_other_matches = records_with_other_matches_df.filter(col("has_other_potential_matches") == False)

        self.with_other_count = records_with_other_matches.count()
        self.without_other_count = records_without_other_matches.count()

        self.logger.info(f"\n  Analysis complete:")
        self.logger.info(f"  Records with other POTENTIAL matches: {self.with_other_count}")
        if self.with_other_count > 0:
            self.logger.info(f"    Details:")
            for row in records_with_other_matches.collect():
                self.logger.info(f"      {row[self.unified_id_key]}: {len(row['other_potential_match_ids'])} other POTENTIAL matches")
                for i, (mid, score, mtype) in enumerate(zip(row['other_potential_match_ids'], row['other_match_scores'], row['other_match_types'])):
                    self.logger.info(f"        -> Master {mid}: score={score}, type={mtype}")

        self.logger.info(f"  Records without other POTENTIAL matches: {self.without_other_count}")
        if self.without_other_count > 0:
            self.logger.info(f"    (These records have no other POTENTIAL matches or only NO_MATCH alternatives)")
            for row in records_without_other_matches.collect():
                self.logger.info(f"      {row[self.unified_id_key]}")

        # Store records without other matches for later steps
        self.records_without_other_matches_data = records_without_other_matches.select(
            col(self.unified_id_key),
            col("source_path")
        ).collect()

        return {
            'with_other_count': self.with_other_count,
            'without_other_count': self.without_other_count
        }

    @step(order=5, name="Decision Point", returns="should_continue or early_exit_result")
    def step_decision_point(self) -> Dict[str, Any]:
        """Decision point - determine if we should continue with insertion."""
        master_id = self.context.master_id

        if self.without_other_count == 0:
            # All records have other POTENTIAL matches - exit early
            self.logger.info("  All records have other potential matches")
            self.logger.info("  MANUAL_NOT_A_MATCH logged successfully")
            self.logger.info("  No further action needed - records will be re-evaluated in next matching cycle")

            self.early_exit_result = TaskResult.success(
                message="All records have other POTENTIAL matches. MANUAL_NOT_A_MATCH logged. No further action taken.",
                task_name=self.context.task_name,
                metrics={
                    'master_id': master_id,
                    'records_marked_not_match': self.activities_count,
                    'records_with_other_matches': self.with_other_count,
                    'records_without_other_matches': 0,
                    'new_masters_created': 0,
                    'action': 'not_a_match_logged_only'
                },
                task_values={
                    'manual_not_match_complete': True,
                    'action': 'not_a_match_logged_only',
                    'records_marked_not_match': self.activities_count
                }
            )

            return {
                'should_continue': False,
                'action': 'early_exit'
            }

        # Proceed with insertion for records without other matches
        self.logger.info(f"  Found {self.without_other_count} records with NO other potential matches")
        self.logger.info(f"  Proceeding to insert as individual masters")
        self.logger.info(f"  Materialized {len(self.records_without_other_matches_data)} records for insertion")

        return {
            'should_continue': True,
            'action': 'continue_to_insertion'
        }

    @step(order=6, name="Fetch Full Records for Insertion", returns="full_records_data and schema")
    def step_fetch_full_records(self) -> Dict[str, Any]:
        """Fetch full records from unified table for insertion."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes

        no_match_surrogate_keys = [row[self.unified_id_key] for row in self.records_without_other_matches_data]
        no_match_keys_list = ", ".join([f"'{sk}'" for sk in no_match_surrogate_keys])

        self.logger.info(f"  Surrogate keys to insert: {no_match_surrogate_keys}")

        attribute_cols = ", ".join([f"u.{attr}" for attr in entity_attributes if attr != self.id_key])

        fetch_full_records_query = f"""
        SELECT
            u.{self.unified_id_key},
            u.source_path,
            {attribute_cols}
        FROM {self.context.unified_table} u
        WHERE u.{self.unified_id_key} IN ({no_match_keys_list})
        """

        full_records_df = spark.sql(fetch_full_records_query)
        full_records_count = full_records_df.count()

        self.logger.info(f"  Fetched {full_records_count} full records from unified table")

        self.full_records_data = full_records_df.collect()
        self.full_records_schema = full_records_df.schema
        self.logger.info(f"  Materialized {len(self.full_records_data)} full records")

        return {
            'full_records_count': len(self.full_records_data)
        }

    @step(order=7, name="Generate New LakeFusion IDs", returns="new_lakefusion_ids mapping")
    def step_generate_lakefusion_ids(self) -> Dict[str, Any]:
        """Generate new lakefusion IDs for records to be inserted."""
        from lakefusion_core_engine.identifiers import generate_lakefusion_id

        for row in self.full_records_data:
            surrogate_key = row[self.unified_id_key]
            new_lf_id = generate_lakefusion_id()
            self.new_lakefusion_ids[surrogate_key] = new_lf_id
            self.logger.info(f"  {surrogate_key} -> {new_lf_id}")

        self.logger.info(f"  Generated {len(self.new_lakefusion_ids)} new lakefusion IDs")

        return {
            'new_lakefusion_ids_count': len(self.new_lakefusion_ids)
        }

    @step(order=8, name="Prepare Records for Master Insert", returns="master_insert_df count")
    def step_prepare_master_insert(self) -> Dict[str, Any]:
        """Prepare records for master table insert."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes
        entity_attributes_datatype = self.context.entity_attributes_datatype
        match_attributes = self.context.match_attributes

        full_records_df = spark.createDataFrame(self.full_records_data, schema=self.full_records_schema)

        new_ids_data = [{"surrogate_key": sk, "new_lakefusion_id": lf_id}
                        for sk, lf_id in self.new_lakefusion_ids.items()]
        new_ids_df = spark.createDataFrame(new_ids_data)

        records_with_ids_df = full_records_df.join(
            new_ids_df,
            on=self.unified_id_key,
            how="inner"
        )

        insert_cols = [col("new_lakefusion_id").alias(self.id_key)]

        for attr in entity_attributes:
            if attr == self.id_key:
                continue

            target_type = entity_attributes_datatype.get(attr, "string")

            if target_type.lower() in ["timestamp", "date", "datetime"]:
                insert_cols.append(col(attr).cast("timestamp").alias(attr))
            elif target_type.lower() in ["int", "integer", "long", "bigint"]:
                insert_cols.append(col(attr).cast("long").alias(attr))
            elif target_type.lower() in ["float", "double", "decimal"]:
                insert_cols.append(col(attr).cast("double").alias(attr))
            elif target_type.lower() in ["boolean", "bool"]:
                insert_cols.append(col(attr).cast("boolean").alias(attr))
            else:
                insert_cols.append(col(attr).alias(attr))

        # Add attributes_combined
        if match_attributes:
            concat_cols = []
            for attr in match_attributes:
                if attr in entity_attributes:
                    concat_cols.append(coalesce(col(attr).cast("string"), lit("")))

            if concat_cols:
                insert_cols.append(
                    concat_ws(" ", *concat_cols).alias("attributes_combined")
                )
            else:
                insert_cols.append(lit("").alias("attributes_combined"))
        else:
            insert_cols.append(lit("").alias("attributes_combined"))

        self.master_insert_df = records_with_ids_df.select(*insert_cols)

        insert_count = self.master_insert_df.count()
        self.logger.info(f"  Prepared {insert_count} records for master insert")

        return {
            'master_insert_count': insert_count
        }

    @step(order=9, name="Insert Into Master Table", returns="new_master_version")
    def step_insert_into_master(self) -> Dict[str, Any]:
        """Insert records into master table."""
        spark = self.context.spark

        current_master_version = spark.sql(f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1").select("version").collect()[0][0]
        self.logger.info(f"  Current master version: {current_master_version}")

        master_delta_table = DeltaTable.forName(spark, self.context.master_table)

        master_delta_table.alias("target").merge(
            self.master_insert_df.alias("source"),
            f"target.{self.id_key} = source.{self.id_key}"
        ).whenNotMatchedInsertAll().execute()

        self.new_master_version = spark.sql(f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1").select("version").collect()[0][0]

        self.logger.info(f"  Master table updated")
        self.logger.info(f"  New version: {self.new_master_version}")
        self.logger.info(f"  Inserted records: {self.master_insert_df.count()}")

        return {
            'new_master_version': self.new_master_version,
            'inserted_count': self.master_insert_df.count()
        }

    @step(order=10, name="Prepare Attribute Version Sources", returns="attr_sources_df count")
    def step_prepare_attribute_version_sources(self) -> Dict[str, Any]:
        """Prepare attribute version sources for the new records."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes

        new_ids_data = [{"surrogate_key": sk, "new_lakefusion_id": lf_id}
                        for sk, lf_id in self.new_lakefusion_ids.items()]
        new_ids_df = spark.createDataFrame(new_ids_data)

        full_records_df = spark.createDataFrame(self.full_records_data, schema=self.full_records_schema)
        records_with_ids_df = full_records_df.join(new_ids_df, on=self.unified_id_key, how="inner")

        def create_single_contributor_sources(source_path, attributes, attribute_values_row):
            if hasattr(attribute_values_row, 'asDict'):
                attribute_values = attribute_values_row.asDict()
            else:
                attribute_values = attribute_values_row

            sources = []
            for attr in attributes:
                if attr != 'lakefusion_id':
                    value = attribute_values.get(attr)
                    sources.append({
                        "attribute_name": attr,
                        "attribute_value": str(value) if value is not None else None,
                        "source": source_path
                    })
            return sources

        single_contributor_udf = udf(
            lambda source_path, attr_row: create_single_contributor_sources(
                source_path,
                entity_attributes,
                attr_row
            ),
            ArrayType(StructType([
                StructField("attribute_name", StringType()),
                StructField("attribute_value", StringType()),
                StructField("source", StringType())
            ]))
        )

        attr_cols_struct = struct(*[col(attr).alias(attr) for attr in entity_attributes if attr != self.id_key])

        self.attr_sources_df = records_with_ids_df.select(
            col("new_lakefusion_id").alias(self.id_key),
            lit(self.new_master_version).alias("version"),
            single_contributor_udf(col("source_path"), attr_cols_struct).alias("attribute_source_mapping")
        )

        attr_sources_count = self.attr_sources_df.count()
        self.logger.info(f"  Prepared attribute version sources")
        self.logger.info(f"  Records: {attr_sources_count}")

        return {
            'attr_sources_count': attr_sources_count
        }

    @step(order=11, name="Update Attribute Version Sources", returns="records updated/inserted count")
    def step_update_attribute_version_sources(self) -> Dict[str, Any]:
        """Update attribute version sources table."""
        spark = self.context.spark

        attr_sources_delta_table = DeltaTable.forName(spark, self.context.attribute_version_sources_table)

        attr_sources_delta_table.alias("target").merge(
            self.attr_sources_df.alias("source"),
            f"target.{self.id_key} = source.{self.id_key} AND target.version = source.version"
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

        updated_count = self.attr_sources_df.count()
        self.logger.info(f"  Attribute version sources updated")
        self.logger.info(f"  Records updated/inserted: {updated_count}")

        return {
            'updated_count': updated_count
        }

    @step(order=12, name="Log JOB_INSERT Activities", returns="insert_activities_count")
    def step_log_job_insert_activities(self) -> Dict[str, Any]:
        """Log JOB_INSERT activities to merge activities table."""
        spark = self.context.spark

        new_ids_data = [{"surrogate_key": sk, "new_lakefusion_id": lf_id}
                        for sk, lf_id in self.new_lakefusion_ids.items()]
        new_ids_df = spark.createDataFrame(new_ids_data)

        full_records_df = spark.createDataFrame(self.full_records_data, schema=self.full_records_schema)
        records_with_ids_df = full_records_df.join(new_ids_df, on=self.unified_id_key, how="inner")

        insert_activities_df = records_with_ids_df.select(
            col("new_lakefusion_id").alias("master_id"),
            col(self.unified_id_key).alias("match_id"),
            col("source_path").alias("source"),
            lit(self.new_master_version).alias("version"),
            lit("JOB_INSERT").alias("action_type"),
            current_timestamp().alias("created_at")
        )

        insert_activities_count = insert_activities_df.count()
        self.logger.info(f"  Prepared {insert_activities_count} JOB_INSERT activities")

        merge_activities_delta_table = DeltaTable.forName(spark, self.context.merge_activities_table)

        merge_activities_delta_table.alias("target").merge(
            insert_activities_df.alias("source"),
            f"""target.match_id = source.match_id
                AND target.master_id = source.master_id
                AND target.version = source.version
                AND target.action_type = source.action_type"""
        ).whenNotMatchedInsertAll().execute()

        self.logger.info(f"  JOB_INSERT activities logged")
        self.logger.info(f"  Records logged: {insert_activities_count}")

        return {
            'insert_activities_count': insert_activities_count
        }

    @step(order=13, name="Update Unified Table", returns="unified_updates_count")
    def step_update_unified_table(self) -> Dict[str, Any]:
        """Update unified table with new master IDs and record status."""
        spark = self.context.spark

        new_ids_data = [{"surrogate_key": sk, "new_lakefusion_id": lf_id}
                        for sk, lf_id in self.new_lakefusion_ids.items()]
        new_ids_df = spark.createDataFrame(new_ids_data)

        full_records_df = spark.createDataFrame(self.full_records_data, schema=self.full_records_schema)
        records_with_ids_df = full_records_df.join(new_ids_df, on=self.unified_id_key, how="inner")

        unified_updates_df = records_with_ids_df.select(
            col(self.unified_id_key),
            col("new_lakefusion_id").alias(f"master_{self.id_key}"),
            lit("MERGED").alias("record_status")
        )

        unified_updates_count = unified_updates_df.count()
        self.logger.info(f"  Prepared {unified_updates_count} records for unified table update")

        unified_delta_table = DeltaTable.forName(spark, self.context.unified_table)

        unified_delta_table.alias("target").merge(
            unified_updates_df.alias("source"),
            f"target.{self.unified_id_key} = source.{self.unified_id_key}"
        ).whenMatchedUpdate(set={
            f"master_{self.id_key}": f"source.master_{self.id_key}",
            "record_status": "source.record_status"
        }).execute()

        self.logger.info(f"  Unified table updated")
        self.logger.info(f"  Records updated: {unified_updates_count}")

        return {
            'unified_updates_count': unified_updates_count
        }

    @step(order=14, name="Write Steward Decision", returns="decision_id")
    def step_write_steward_decision(self) -> Dict[str, Any]:
        """Write frozen record snapshots to steward_decisions Delta table."""
        sk = self.context.state.get('not_match_surrogate_keys', [])
        master_attrs = getattr(self, '_sd_master_attrs', {})
        match_attrs = getattr(self, '_sd_match_attrs', {})
        match_source = match_attrs.get("source_path", "") if match_attrs else ""
        decision_id = write_steward_decision(
            spark=self.context.spark, catalog_name=self.context.catalog_name,
            entity_name=self.context.entity, entity_id=str(self.context.entity_id or ""),
            action_type="MANUAL_NOT_A_MATCH", master_id=self.context.master_id,
            match_id=sk[0] if sk else "", master_attrs=master_attrs, match_attrs=match_attrs,
            match_source=match_source, created_by=self.context.params.get("created_by", ""),
            logger=self.logger,
        )
        return {"decision_id": decision_id}

    def execute(self) -> TaskResult:
        """Execute the manual not match workflow."""
        master_id = self.context.master_id

        # Step 1: Validate master record exists
        self.step_validate_master_exists()

        # Step 2: Validate records exist and get source paths
        self.step_validate_records_and_get_source_paths()

        # Step 3: Log MANUAL_NOT_A_MATCH activities
        self.step_log_not_match_activities()

        # Step 4: Check for other potential matches
        self.step_check_other_potential_matches()

        # Step 5: Decision point
        self.step_decision_point()

        # Check if we should exit early
        if self.early_exit_result is not None:
            return self.early_exit_result

        # Step 6: Fetch full records for insertion
        self.step_fetch_full_records()

        # Step 7: Generate new lakefusion IDs
        self.step_generate_lakefusion_ids()

        # Step 8: Prepare records for master insert
        self.step_prepare_master_insert()

        # Step 9: Insert into master table
        self.step_insert_into_master()

        # Step 10: Prepare attribute version sources
        self.step_prepare_attribute_version_sources()

        # Step 11: Update attribute version sources
        self.step_update_attribute_version_sources()

        # Step 12: Log JOB_INSERT activities
        self.step_log_job_insert_activities()

        # Step 13: Update unified table
        self.step_update_unified_table()

        # Step 14: Write steward decision
        self.step_write_steward_decision()

        return TaskResult.success(
            message="Manual not match processing completed - new masters created",
            task_name=self.context.task_name,
            metrics={
                'master_id': master_id,
                'records_marked_not_match': self.activities_count,
                'records_with_other_matches': self.with_other_count,
                'records_without_other_matches': self.without_other_count,
                'new_masters_created': len(self.new_lakefusion_ids),
                'new_lakefusion_ids': list(self.new_lakefusion_ids.values()),
                'master_version': int(self.new_master_version),
                'action': 'not_a_match_and_inserted'
            },
            task_values={
                'manual_not_match_complete': True,
                'action': 'not_a_match_and_inserted',
                'records_marked_not_match': self.activities_count,
                'new_masters_created': len(self.new_lakefusion_ids),
                'new_lakefusion_ids': list(self.new_lakefusion_ids.values())
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=self.activities_count > 0,
            message="NOT_A_MATCH activities logged",
            expected="> 0",
            actual=self.activities_count
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*80)
        self.logger.info("MANUAL NOT A MATCH PROCESSING COMPLETE")
        self.logger.info("="*80)

        if result.is_success:
            metrics = result.metrics
            self.logger.info(f"\nSummary:")
            self.logger.info(f"  Records marked as NOT A MATCH: {metrics.get('records_marked_not_match')}")
            self.logger.info(f"  Records with other potential matches: {metrics.get('records_with_other_matches')}")
            self.logger.info(f"  Records without other potential matches: {metrics.get('records_without_other_matches')}")
            self.logger.info(f"  New individual masters created: {metrics.get('new_masters_created')}")

            if metrics.get('master_version'):
                self.logger.info(f"  Master table version: {metrics.get('master_version')}")

            if self.new_lakefusion_ids:
                self.logger.info(f"\n  New lakefusion IDs created:")
                for sk, lf_id in self.new_lakefusion_ids.items():
                    self.logger.info(f"    {sk} -> {lf_id}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Manual not match failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.info(f"  Error: {error}")
