"""
Process Auto Merge Executor for normal deduplication.

Handles automatic merging of MATCH records from the processed unified table
into the master table using survivorship rules.

Workflow:
1. Initialize survivorship engine
2. Extract MATCH records
3. Handle duplicate matches (keep highest score)
4. Group records by target master
5. Fetch all contributors for each master
6. Group contributors by master
7. Apply survivorship engine
8. Update master table
9. Update attribute version sources
10. Log merge activities
11. Update unified table
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame, Window
from pyspark.sql.functions import (
    col, lit, collect_list, struct, count, row_number,
    max as spark_max, current_timestamp, udf, concat_ws, coalesce
)
from pyspark.sql.types import (
    StructType, StructField, StringType, MapType, ArrayType
)
from delta.tables import DeltaTable

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult

from lakefusion_core_engine.utils import merged_record_column


class ProcessAutoMergeExecutor(BaseStepTask):
    """
    Executor for automatic merge processing.

    Merges MATCH records into masters using survivorship rules.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.id_key = context.master_id_key
        self.unified_id_key = context.unified_id_key
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Will be set during execution
        self.total_match_count = 0
        self.final_match_count = 0
        self.master_count = 0
        self.merge_activities_count = 0
        self.new_master_version = 0

        # Intermediate results stored across steps
        self.engine: Optional[Any] = None
        self.match_records_df: Optional[DataFrame] = None
        self.match_records_unique: Optional[DataFrame] = None
        self.grouped_by_master: Optional[DataFrame] = None
        self.all_contributors_df: Optional[DataFrame] = None
        self.grouped_contributors: Optional[DataFrame] = None
        self.final_results_df: Optional[DataFrame] = None
        self.master_updates_df: Optional[DataFrame] = None

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*80)
        self.logger.info("PROCESS AUTO MERGE")
        self.logger.info("="*80)
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Master ID Key: {self.id_key}")
        self.logger.info(f"Unified ID Key: {self.unified_id_key}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id or 'None'}")
        self.logger.info(f"Unified Table: {self.context.unified_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Processed Unified Table: {self.context.processed_unified_table}")
        self.logger.info(f"Merge Activities Table: {self.context.merge_activities_table}")
        self.logger.info(f"Attribute Version Sources Table: {self.context.attribute_version_sources_table}")
        self.logger.info("="*80)

    @step(order=1, name="Initialize Survivorship Engine", returns="SurvivorshipEngine instance")
    def step_initialize_survivorship_engine(self) -> Dict[str, Any]:
        """Initialize the survivorship engine with rules and configuration."""
        entity_attributes = self.context.entity_attributes
        entity_attributes_datatype = self.context.entity_attributes_datatype
        default_survivorship_rules = self.context.default_survivorship_rules
        dataset_objects = self.context.dataset_objects

        from lakefusion_core_engine.survivorship import SurvivorshipEngine

        self.logger.info(f"  Survivorship rules: {len(default_survivorship_rules)}")

        self.engine = SurvivorshipEngine(
            survivorship_config=default_survivorship_rules,
            entity_attributes=entity_attributes,
            entity_attributes_datatype=entity_attributes_datatype,
            id_key=self.unified_id_key
        )

        self.logger.info("  Survivorship Engine initialized")

        return {"rules_count": len(default_survivorship_rules)}

    @step(order=2, name="Extract MATCH Records", returns="DataFrame with MATCH records")
    def step_extract_match_records(self) -> Dict[str, Any]:
        """Extract MATCH records from processed unified table."""
        spark = self.context.spark

        match_records_query = f"""
        SELECT
            pu.{self.unified_id_key},
            pu.{self.id_key},
            pu.exploded_result.score as match_score,
            pu.exploded_result.match as match_status
        FROM {self.context.processed_unified_table} pu
        WHERE pu.exploded_result.match = 'MATCH'
        """

        self.match_records_df = spark.sql(match_records_query)
        self.total_match_count = self.match_records_df.count()

        self.logger.info(f"  Found {self.total_match_count} MATCH records")

        return {"total_match_count": self.total_match_count}

    @step(order=3, name="Handle Duplicate Matches", returns="DataFrame with unique matches")
    def step_handle_duplicate_matches(self) -> Dict[str, Any]:
        """Handle records matching multiple masters by keeping highest score."""
        window_spec = Window.partitionBy(self.unified_id_key).orderBy(col("match_score").desc())

        match_records_ranked = self.match_records_df.withColumn(
            "rank",
            row_number().over(window_spec)
        )

        duplicates_count = match_records_ranked.filter(col("rank") > 1).count()
        self.logger.info(f"  Records matching multiple masters: {duplicates_count}")

        self.match_records_unique = match_records_ranked.filter(col("rank") == 1).drop("rank")

        self.final_match_count = self.match_records_unique.count()
        self.logger.info(f"  After keeping highest score: {self.final_match_count}")
        self.logger.info(f"  Dropped: {self.total_match_count - self.final_match_count}")

        return {
            "duplicates_count": duplicates_count,
            "final_match_count": self.final_match_count
        }

    @step(order=4, name="Group Records by Target Master", returns="DataFrame grouped by master")
    def step_group_records_by_master(self) -> Dict[str, Any]:
        """Group match records by their target master."""
        spark = self.context.spark

        self.grouped_by_master = (
            self.match_records_unique
            .groupBy(self.id_key)
            .agg(
                collect_list(self.unified_id_key).alias("unified_keys_to_merge"),
                count("*").alias("merge_count")
            )
        )

        self.master_count = self.grouped_by_master.count()
        max_merge_count = self.grouped_by_master.select(spark_max("merge_count")).collect()[0][0]

        self.logger.info(f"  Masters receiving merges: {self.master_count}")
        self.logger.info(f"  Max records merging to single master: {max_merge_count}")

        self.logger.info("\n  Merge distribution:")
        self.grouped_by_master.groupBy("merge_count").count().orderBy("merge_count").show()

        return {
            "master_count": self.master_count,
            "max_merge_count": max_merge_count
        }

    @step(order=5, name="Fetch All Contributors", returns="DataFrame with all contributors")
    def step_fetch_all_contributors(self) -> Dict[str, Any]:
        """Fetch existing and new contributors for each master."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes

        attribute_cols = ", ".join([f"u.{attr}" for attr in entity_attributes])

        self.match_records_unique.createOrReplaceTempView("match_records_temp")

        all_contributors_query = f"""
        WITH masters_to_update AS (
            SELECT DISTINCT {self.id_key}
            FROM match_records_temp
        ),
        existing_contributors AS (
            SELECT
                u.{self.unified_id_key},
                u.source_path,
                u.master_{self.id_key},
                {attribute_cols}
            FROM {self.context.unified_table} u
            INNER JOIN masters_to_update m
                ON u.master_{self.id_key} = m.{self.id_key}
            WHERE u.record_status = 'MERGED'
        ),
        new_contributors AS (
            SELECT
                u.{self.unified_id_key},
                u.source_path,
                mr.{self.id_key} as master_{self.id_key},
                {attribute_cols}
            FROM {self.context.unified_table} u
            INNER JOIN match_records_temp mr
                ON u.{self.unified_id_key} = mr.{self.unified_id_key}
            WHERE u.record_status = 'ACTIVE'
        )
        SELECT * FROM existing_contributors
        UNION ALL
        SELECT * FROM new_contributors
        """

        self.all_contributors_df = spark.sql(all_contributors_query)
        total_contributors = self.all_contributors_df.count()

        self.logger.info(f"  Total contributors (existing + new): {total_contributors}")

        contributors_by_master = self.all_contributors_df.groupBy(f"master_{self.id_key}").count()
        self.logger.info(f"  Contributors grouped by master:")
        contributors_by_master.orderBy(col("count").desc()).show(10, truncate=False)

        return {"total_contributors": total_contributors}

    @step(order=6, name="Group Contributors by Master", returns="DataFrame with grouped contributors")
    def step_group_contributors_by_master(self) -> Dict[str, Any]:
        """Aggregate contributors into arrays grouped by master."""
        self.grouped_contributors = (
            self.all_contributors_df
            .groupBy(f"master_{self.id_key}")
            .agg(
                collect_list(
                    struct([col(c) for c in self.all_contributors_df.columns if c != f"master_{self.id_key}"])
                ).alias("unified_records")
            )
            .withColumnRenamed(f"master_{self.id_key}", self.id_key)
        )

        grouped_count = self.grouped_contributors.count()
        self.logger.info(f"  Grouped into {grouped_count} masters")

        return {"grouped_count": grouped_count}

    @step(order=7, name="Apply Survivorship Engine", returns="DataFrame with survivorship results")
    def step_apply_survivorship_engine(self) -> Dict[str, Any]:
        """Apply survivorship rules to determine winning attribute values."""
        engine = self.engine

        def apply_survivorship_wrapper(unified_records):
            records_list = [r.asDict() for r in unified_records]
            result = engine.apply_survivorship(unified_records=records_list)
            return result.to_dict()

        udf_output_schema = StructType([
            StructField("resultant_record", MapType(StringType(), StringType())),
            StructField("resultant_master_attribute_source_mapping", ArrayType(StructType([
                StructField("attribute_name", StringType()),
                StructField("attribute_value", StringType()),
                StructField("source", StringType())
            ])))
        ])

        survivorship_udf = udf(apply_survivorship_wrapper, udf_output_schema)
        self.logger.info("  UDF registered")

        result_df = self.grouped_contributors.withColumn(
            "survivorship_result",
            survivorship_udf(col("unified_records"))
        )

        self.final_results_df = result_df.select(
            col(self.id_key),
            col("survivorship_result.resultant_record").alias("merged_record"),
            col("survivorship_result.resultant_master_attribute_source_mapping").alias("attribute_sources")
        )

        survivorship_count = self.final_results_df.count()
        self.logger.info(f"  Survivorship applied to {survivorship_count} masters")

        return {"survivorship_count": survivorship_count}

    @step(order=8, name="Update Master Table", returns="Master table update metrics")
    def step_update_master_table(self) -> Dict[str, Any]:
        """Update master table with merged attribute values."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes
        entity_attributes_datatype = self.context.entity_attributes_datatype
        match_attributes = self.context.match_attributes

        master_updates_cols = [col(self.id_key)]

        for attr in entity_attributes:
            if attr == self.id_key:
                continue

            target_type = entity_attributes_datatype.get(attr, "string")
            master_updates_cols.append(merged_record_column(attr, target_type))

        # Add attributes_combined
        if match_attributes:
            concat_cols = []
            for attr in match_attributes:
                if attr in entity_attributes and attr != self.id_key:
                    concat_cols.append(coalesce(col(f"merged_record.{attr}").cast("string"), lit("")))

            if concat_cols:
                master_updates_cols.append(
                    concat_ws(" | ", *concat_cols).alias("attributes_combined")
                )
            else:
                master_updates_cols.append(lit("").alias("attributes_combined"))
        else:
            master_updates_cols.append(lit("").alias("attributes_combined"))

        self.master_updates_df = self.final_results_df.select(*master_updates_cols)

        self.logger.info(f"  Prepared master updates with attributes_combined")
        self.logger.info(f"  Match attributes used: {len([a for a in match_attributes if a in entity_attributes and a != self.id_key])}")

        current_master_version = spark.sql(f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1").select("version").collect()[0][0]
        self.logger.info(f"  Current master table version: {current_master_version}")

        master_delta_table = DeltaTable.forName(spark, self.context.master_table)

        update_dict = {attr: f"source.{attr}" for attr in entity_attributes if attr != self.id_key}
        update_dict["attributes_combined"] = "source.attributes_combined"

        master_delta_table.alias("target").merge(
            self.master_updates_df.alias("source"),
            f"target.{self.id_key} = source.{self.id_key}"
        ).whenMatchedUpdate(set=update_dict).execute()

        self.new_master_version = spark.sql(f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1").select("version").collect()[0][0]

        records_updated = self.master_updates_df.count()
        self.logger.info(f"  Master table updated")
        self.logger.info(f"  New version: {self.new_master_version}")
        self.logger.info(f"  Records updated: {records_updated}")

        return {
            "previous_version": current_master_version,
            "new_version": int(self.new_master_version),
            "records_updated": records_updated
        }

    @step(order=9, name="Update Attribute Version Sources", returns="Attribute sources update count")
    def step_update_attribute_version_sources(self) -> Dict[str, Any]:
        """Update attribute version sources table with provenance info."""
        spark = self.context.spark

        attribute_sources_update_df = self.final_results_df.select(
            col(self.id_key),
            lit(self.new_master_version).alias("version"),
            col("attribute_sources").alias("attribute_source_mapping")
        )

        attr_sources_delta_table = DeltaTable.forName(spark, self.context.attribute_version_sources_table)

        attr_sources_delta_table.alias("target").merge(
            attribute_sources_update_df.alias("source"),
            f"target.{self.id_key} = source.{self.id_key} AND target.version = source.version"
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

        records_updated = attribute_sources_update_df.count()
        self.logger.info(f"  Attribute version sources updated")
        self.logger.info(f"  Records updated: {records_updated}")

        return {"records_updated": records_updated}

    @step(order=10, name="Log Merge Activities", returns="Merge activities logged count")
    def step_log_merge_activities(self) -> Dict[str, Any]:
        """Log merge activities for audit trail."""
        spark = self.context.spark

        merge_activities_query = f"""
        SELECT
            mr.{self.id_key} as master_id,
            mr.{self.unified_id_key} as match_id,
            u.source_path as source,
            {self.new_master_version} as version,
            'JOB_MERGE' as action_type,
            current_timestamp() as created_at
        FROM match_records_temp mr
        INNER JOIN {self.context.unified_table} u
            ON mr.{self.unified_id_key} = u.{self.unified_id_key}
        WHERE u.record_status = 'ACTIVE'
        """

        merge_activities_df = spark.sql(merge_activities_query)
        self.merge_activities_count = merge_activities_df.count()

        self.logger.info(f"  Prepared {self.merge_activities_count} merge activities")

        self.logger.info("\n  Sample merge activities:")
        merge_activities_df.show(5, truncate=False)

        if self.merge_activities_count > 0:
            merge_activities_delta_table = DeltaTable.forName(spark, self.context.merge_activities_table)

            merge_activities_delta_table.alias("target").merge(
                merge_activities_df.alias("source"),
                f"""target.match_id = source.match_id
                    AND target.master_id = source.master_id
                    AND target.version = source.version
                    AND target.action_type = source.action_type"""
            ).whenNotMatchedInsertAll().execute()

            self.logger.info(f"  Merge activities logged")
            self.logger.info(f"  New merge activities: {self.merge_activities_count}")
        else:
            self.logger.info("  No new merge activities to log")

        return {"merge_activities_count": self.merge_activities_count}

    @step(order=11, name="Update Unified Table", returns="Unified table update count")
    def step_update_unified_table(self) -> Dict[str, Any]:
        """Update unified table to mark records as MERGED."""
        spark = self.context.spark

        merged_unified_keys = (
            self.match_records_unique
            .select(
                col(self.unified_id_key),
                col(self.id_key).alias(f"master_{self.id_key}")
            )
        )

        unified_updates_df = merged_unified_keys.select(
            col(self.unified_id_key),
            col(f"master_{self.id_key}"),
            lit("MERGED").alias("record_status")
        )

        unified_delta_table = DeltaTable.forName(spark, self.context.unified_table)

        unified_delta_table.alias("target").merge(
            unified_updates_df.alias("source"),
            f"target.{self.unified_id_key} = source.{self.unified_id_key}"
        ).whenMatchedUpdate(set={
            f"master_{self.id_key}": f"source.master_{self.id_key}",
            "record_status": "source.record_status"
        }).execute()

        records_updated = unified_updates_df.count()
        self.logger.info(f"  Unified table updated")
        self.logger.info(f"  Records updated: {records_updated}")

        return {"records_updated": records_updated}

    def execute(self) -> TaskResult:
        """Execute the auto merge workflow."""
        # Step 1: Initialize survivorship engine
        self.step_initialize_survivorship_engine()

        # Step 2: Extract MATCH records
        self.step_extract_match_records()

        if self.total_match_count == 0:
            self.logger.info("\nNo MATCH records to process")
            return TaskResult.success(
                message="No MATCH records to process",
                task_name=self.context.task_name,
                metrics={'records_processed': 0}
            )

        # Step 3: Handle duplicate matches
        self.step_handle_duplicate_matches()

        # Step 4: Group records by target master
        self.step_group_records_by_master()

        # Step 5: Fetch all contributors
        self.step_fetch_all_contributors()

        # Step 6: Group contributors by master
        self.step_group_contributors_by_master()

        # Step 7: Apply survivorship engine
        self.step_apply_survivorship_engine()

        # Step 8: Update master table
        self.step_update_master_table()

        # Step 9: Update attribute version sources
        self.step_update_attribute_version_sources()

        # Step 10: Log merge activities
        self.step_log_merge_activities()

        # Step 11: Update unified table
        self.step_update_unified_table()

        return TaskResult.success(
            message="Merge processing completed successfully",
            task_name=self.context.task_name,
            metrics={
                'records_processed': self.final_match_count,
                'masters_updated': self.master_count,
                'merge_activities_logged': self.merge_activities_count,
                'master_version': int(self.new_master_version)
            },
            task_values={
                'merge_complete': True,
                'records_merged': self.final_match_count,
                'masters_updated': self.master_count
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Auto merge completed",
            actual=self.final_match_count
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*80)
        self.logger.info("MERGE PROCESSING COMPLETE")
        self.logger.info("="*80)

        if result.is_success:
            metrics = result.metrics
            self.logger.info(f"\nSummary:")
            self.logger.info(f"  Records processed: {metrics.get('records_processed')}")
            self.logger.info(f"  Masters updated: {metrics.get('masters_updated')}")
            self.logger.info(f"  Merge activities logged: {metrics.get('merge_activities_logged')}")
            self.logger.info(f"  Master table version: {metrics.get('master_version')}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Auto merge failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.info(f"  Error: {error}")
