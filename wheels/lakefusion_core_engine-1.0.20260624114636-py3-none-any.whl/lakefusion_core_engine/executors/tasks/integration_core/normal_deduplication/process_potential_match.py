"""
Process Potential Match Executor for normal deduplication.

Builds the potential match table that shows all masters with their potential
matches (both MERGED and PENDING) including scores and reasons.

Workflow:
1. Check processed unified table existence
2. Build potential match query
3. Execute query
4. Add column tags
5. Write to Delta table
"""

from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql.functions import lit, create_map

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ProcessPotentialMatchExecutor(BaseStepTask):
    """
    Executor for building the potential match table.

    Aggregates all potential matches per master including both
    MERGED contributors and PENDING potential matches.
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        super().__init__(context, override_instance=override_instance)
        self.id_key = context.master_id_key
        self.unified_id_key = context.unified_id_key
        self.total_count = 0
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Instance variables for intermediate results
        self._processed_unified_exists: bool = False
        self._query: str = None
        self._potential_match_df: DataFrame = None
        self._potential_match_with_tags_df: DataFrame = None
        self._table_exists: bool = False

    @property
    def potential_match_table(self) -> str:
        """Get the potential match table name."""
        base = f"{self.context.catalog_name}.gold.{self.context.entity}_master_potential_match"
        if self.context.experiment_id:
            base += f"_{self.context.experiment_id}"
        return base

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*80)
        self.logger.info("PROCESS POTENTIAL MATCH")
        self.logger.info("="*80)
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Master ID Key: {self.id_key}")
        self.logger.info(f"Unified ID Key: {self.unified_id_key}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id or 'None'}")
        self.logger.info(f"Unified Table: {self.context.unified_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Processed Unified Table: {self.context.processed_unified_table}")
        self.logger.info(f"Potential Match Table: {self.potential_match_table}")
        self.logger.info(f"Merge Activities Table: {self.context.merge_activities_table}")
        self.logger.info("="*80)

    @step(order=1, name="Check Processed Unified Table Existence", returns="processed_unified_exists flag")
    def step_check_processed_unified_exists(self) -> Dict[str, Any]:
        """Check if the processed_unified_table exists."""
        spark = self.context.spark

        self._processed_unified_exists = spark.catalog.tableExists(self.context.processed_unified_table)
        self.logger.info(f"Processed Unified Table Exists: {self._processed_unified_exists}")

        return {'processed_unified_exists': self._processed_unified_exists}

    @step(order=2, name="Build Potential Match Query", returns="SQL query string")
    def step_build_query(self) -> Dict[str, Any]:
        """Build the potential match SQL query."""
        entity_attributes = self.context.entity_attributes

        # Build select clause for master attributes
        master_select_list = [f"m.{self.id_key} as {self.id_key}"] + [f"m.{attr} as {attr}" for attr in entity_attributes]
        master_select = ", ".join(master_select_list)

        # Build named_struct for potential matches
        named_struct_parts = []

        for attr in entity_attributes:
            named_struct_parts.append(f"'{attr}', u.{attr}")

        named_struct_parts.extend([
            "'__score__', match_info.score",
            "'__reason__', match_info.reason",
            "'__source_path__', u.source_path",
            "'__source_id__', u.source_id",
            f"'{self.unified_id_key}', u.{self.unified_id_key}",
            "'__mergestatus__', match_info.merge_status"
        ])

        named_struct_expr = f"named_struct({', '.join(named_struct_parts)})"

        # Build CTEs conditionally
        if self._processed_unified_exists:
            pending_matches_ctes = f"""
pending_matches_raw AS (
    SELECT
        pu.{self.id_key} as original_master_{self.id_key},
        pu.{self.unified_id_key},
        pu.exploded_result.score as score,
        pu.exploded_result.reason as reason
    FROM {self.context.processed_unified_table} pu
    WHERE pu.exploded_result.match = 'POTENTIAL_MATCH'
),
pending_matches_resolved AS (
    SELECT
        COALESCE(mmf.final_master_id, pm.original_master_{self.id_key}) as master_{self.id_key},
        pm.{self.unified_id_key},
        pm.score,
        pm.reason
    FROM pending_matches_raw pm
    LEFT JOIN master_merge_final mmf
        ON pm.original_master_{self.id_key} = mmf.old_master_id
),
pending_matches_from_processed AS (
    SELECT
        pmr.master_{self.id_key},
        pmr.{self.unified_id_key},
        u.source_path,
        'POTENTIAL_MATCH' as action_type,
        pmr.score,
        pmr.reason,
        'PENDING' as merge_status
    FROM pending_matches_resolved pmr
    INNER JOIN {self.context.unified_table} u
        ON pmr.{self.unified_id_key} = u.{self.unified_id_key}
    LEFT JOIN not_a_match_pairs nam
        ON pmr.master_{self.id_key} = nam.master_{self.id_key}
        AND pmr.{self.unified_id_key} = nam.{self.unified_id_key}
    WHERE u.record_status = 'ACTIVE'
        AND nam.{self.unified_id_key} IS NULL
        AND EXISTS (
            SELECT 1 FROM {self.context.master_table} m
            WHERE m.{self.id_key} = pmr.master_{self.id_key}
        )
),"""

            all_matches_union = f"""
    UNION ALL

    SELECT
        master_{self.id_key},
        {self.unified_id_key},
        source_path,
        score,
        reason,
        merge_status
    FROM pending_matches_from_processed"""

            self.logger.info("Including pending matches from processed_unified table")
        else:
            pending_matches_ctes = ""
            all_matches_union = ""
            self.logger.info("Processed unified table does not exist - skipping pending matches")

        # Build the complete query
        self._query = f"""
WITH current_contributors AS (
    SELECT
        u.master_{self.id_key},
        u.{self.unified_id_key},
        u.source_path,
        u.source_id,
        u.record_status,
        u.scoring_results,
        {', '.join([f'u.{attr}' for attr in entity_attributes])}
    FROM {self.context.unified_table} u
    WHERE u.master_{self.id_key} IS NOT NULL
        AND u.record_status IN ('MERGED', 'ACTIVE')
),
master_merge_chain AS (
    SELECT DISTINCT
        ma.match_id as old_master_id,
        ma.master_id as intermediate_master_id
    FROM {self.context.merge_activities_table} ma
    WHERE ma.action_type IN ('MASTER_JOB_MERGE', 'MASTER_MANUAL_MERGE', 'MASTER_FORCE_MERGE')
),
master_merge_final AS (
    SELECT DISTINCT
        mmc1.old_master_id,
        COALESCE(mmc2.intermediate_master_id, mmc1.intermediate_master_id) as final_master_id
    FROM master_merge_chain mmc1
    LEFT JOIN master_merge_chain mmc2
        ON mmc1.intermediate_master_id = mmc2.old_master_id
),
not_a_match_pairs AS (
    SELECT DISTINCT
        ma.master_id as master_{self.id_key},
        ma.match_id as {self.unified_id_key}
    FROM {self.context.merge_activities_table} ma
    WHERE ma.action_type = 'MANUAL_NOT_A_MATCH'
),
{pending_matches_ctes}
-- Latest merge-establishing action (INITIAL_LOAD/JOB_INSERT/JOB_MERGE/MANUAL_MERGE)
-- per contributor. Excludes SOURCE_UPDATE/MANUAL_UNMERGE/MANUAL_NOT_A_MATCH/SOURCE_DELETE
-- so an attribute-only update doesn't relabel a merged contributor's merge_status.
original_merge_activity AS (
    SELECT
        ma.match_id as {self.unified_id_key},
        ma.master_id as original_master_id,
        ma.action_type as original_action_type,
        ROW_NUMBER() OVER (
            PARTITION BY ma.match_id
            ORDER BY ma.version DESC, ma.created_at DESC
        ) as rn
    FROM {self.context.merge_activities_table} ma
    WHERE ma.match_id IS NOT NULL
      AND ma.match_id LIKE 'sk_%'
      AND ma.action_type IN ('INITIAL_LOAD', 'JOB_INSERT', 'JOB_MERGE', 'MANUAL_MERGE')
),
original_merge AS (
    SELECT {self.unified_id_key}, original_master_id, original_action_type
    FROM original_merge_activity
    WHERE rn = 1
),

unmerged_records AS (
    -- Identify records unmerged and promoted to their own master.
    -- Use ROW_NUMBER to keep only the LATEST unmerge event per surrogate_key,
    -- so that re-unmerge cycles don't produce duplicate rows.
    SELECT
        {self.unified_id_key},
        old_master_id,
        new_master_id
    FROM (
        SELECT
            unmerge.match_id     AS {self.unified_id_key},
            unmerge.master_id    AS old_master_id,
            insert_evt.master_id AS new_master_id,
            ROW_NUMBER() OVER (
                PARTITION BY unmerge.match_id
                ORDER BY unmerge.version DESC, unmerge.created_at DESC
            ) AS rn
        FROM {self.context.merge_activities_table} unmerge
        INNER JOIN {self.context.merge_activities_table} insert_evt
            ON  unmerge.match_id  = insert_evt.match_id
            AND unmerge.version   = insert_evt.version
            AND insert_evt.action_type = 'JOB_INSERT'
        WHERE unmerge.action_type = 'MANUAL_UNMERGE'
          AND unmerge.match_id IS NOT NULL
          AND unmerge.match_id LIKE 'sk_%'
    )
    WHERE rn = 1
),
-- Determine where each promoted master ended up after a subsequent merge
promoted_master_fate AS (
    -- For each unmerged record, check if its promoted new master was
    -- subsequently merged, and if so, into which final master.
    SELECT
        ur.{self.unified_id_key},
        ur.old_master_id,
        ur.new_master_id,
        mmf.final_master_id AS merged_into_master_id,
        ma_latest.action_type AS merge_into_action_type
    FROM unmerged_records ur
    LEFT JOIN master_merge_final mmf
        ON ur.new_master_id = mmf.old_master_id
    -- Get the actual action_type of the master-to-master merge
    -- so we can distinguish MASTER_FORCE_MERGE vs MASTER_MANUAL_MERGE
    LEFT JOIN (
        SELECT
            match_id,
            action_type,
            ROW_NUMBER() OVER (
                PARTITION BY match_id
                ORDER BY version DESC, created_at DESC
            ) AS rn
        FROM {self.context.merge_activities_table}
        WHERE action_type IN ('MASTER_FORCE_MERGE', 'MASTER_MANUAL_MERGE', 'MASTER_JOB_MERGE')
    ) ma_latest
        ON ur.new_master_id = ma_latest.match_id
        AND ma_latest.rn = 1
),
-- - If promoted master was merged back into this old master → MASTER_FORCE_MERGE
-- - If promoted master was merged into a DIFFERENT master → keep MANUAL_UNMERGE
-- - If promoted master was never merged → MANUAL_UNMERGE
unmerged_as_match AS (
    SELECT
        pmf.old_master_id                        AS master_{self.id_key},
        pmf.{self.unified_id_key},
        u.source_path,
        '1.0'                                    AS score,
        CASE
            WHEN pmf.merged_into_master_id = pmf.old_master_id
                AND pmf.merge_into_action_type = 'MASTER_MANUAL_MERGE'
                THEN 'Masters merged manually'
            WHEN pmf.merged_into_master_id = pmf.old_master_id
                AND pmf.merge_into_action_type = 'MASTER_JOB_MERGE'
                THEN 'Masters merged automatically'
            WHEN pmf.merged_into_master_id = pmf.old_master_id
                THEN 'Force merged'
            ELSE 'Record unmerged'
        END                                      AS reason,
        CASE
            WHEN pmf.merged_into_master_id = pmf.old_master_id
                AND pmf.merge_into_action_type = 'MASTER_MANUAL_MERGE'
                THEN 'MASTER_MANUAL_MERGE'
            WHEN pmf.merged_into_master_id = pmf.old_master_id
                AND pmf.merge_into_action_type = 'MASTER_JOB_MERGE'
                THEN 'MASTER_JOB_MERGE'
            WHEN pmf.merged_into_master_id = pmf.old_master_id
                THEN 'MASTER_FORCE_MERGE'
            ELSE 'MANUAL_UNMERGE'
        END                                      AS merge_status
    FROM promoted_master_fate pmf
    INNER JOIN {self.context.unified_table} u
        ON pmf.{self.unified_id_key} = u.{self.unified_id_key}
),
-- One row for the NEW promoted master or the DIFFERENT master
-- it was subsequently merged into.
-- - If still active (not merged away) → show under new_master_id as PROMOTED_TO_MASTER
-- - If merged into a DIFFERENT master → show under that master as MASTER_FORCE_MERGE
-- - If merged back into OLD master → handled by unmerged_as_match above, skip here
promoted_masters AS (
    SELECT
        CASE
            WHEN pmf.merged_into_master_id IS NOT NULL
                AND pmf.merged_into_master_id != pmf.old_master_id
                THEN pmf.merged_into_master_id
            ELSE pmf.new_master_id
        END                                      AS master_{self.id_key},
        pmf.{self.unified_id_key},
        u.source_path,
        '1.0'                                    AS score,
        CASE
            WHEN pmf.merged_into_master_id IS NOT NULL
                AND pmf.merged_into_master_id != pmf.old_master_id
                AND pmf.merge_into_action_type = 'MASTER_MANUAL_MERGE'
                THEN 'Masters merged manually'
            WHEN pmf.merged_into_master_id IS NOT NULL
                AND pmf.merged_into_master_id != pmf.old_master_id
                AND pmf.merge_into_action_type = 'MASTER_JOB_MERGE'
                THEN 'Masters merged automatically'
            WHEN pmf.merged_into_master_id IS NOT NULL
                AND pmf.merged_into_master_id != pmf.old_master_id
                THEN 'Force merged'
            ELSE 'Record unmerged and promoted to master'
        END                                      AS reason,
        CASE
            WHEN pmf.merged_into_master_id IS NOT NULL
                AND pmf.merged_into_master_id != pmf.old_master_id
                AND pmf.merge_into_action_type = 'MASTER_MANUAL_MERGE'
                THEN 'MASTER_MANUAL_MERGE'
            WHEN pmf.merged_into_master_id IS NOT NULL
                AND pmf.merged_into_master_id != pmf.old_master_id
                AND pmf.merge_into_action_type = 'MASTER_JOB_MERGE'
                THEN 'MASTER_JOB_MERGE'
            WHEN pmf.merged_into_master_id IS NOT NULL
                AND pmf.merged_into_master_id != pmf.old_master_id
                THEN 'MASTER_FORCE_MERGE'
            ELSE 'PROMOTED_TO_MASTER'
        END                                      AS merge_status
    FROM promoted_master_fate pmf
    INNER JOIN {self.context.unified_table} u
        ON pmf.{self.unified_id_key} = u.{self.unified_id_key}
    -- Skip when merged back into old master — already handled by unmerged_as_match
    WHERE pmf.merged_into_master_id IS NULL
       OR pmf.merged_into_master_id != pmf.old_master_id
),
-- Parse scoring_results JSON to extract score/reason for each target lakefusion_id
scoring_results_exploded AS (
    SELECT
        cc.{self.unified_id_key},
        EXPLODE(FROM_JSON(cc.scoring_results, 'ARRAY<STRUCT<id:STRING, match:STRING, score:DOUBLE, reason:STRING, lakefusion_id:STRING>>')) as sr
    FROM current_contributors cc
    WHERE cc.scoring_results IS NOT NULL
      AND cc.scoring_results != ''
      AND cc.scoring_results != '[]'
),
scoring_results_parsed AS (
    SELECT
        {self.unified_id_key},
        sr.lakefusion_id as target_lakefusion_id,
        CAST(sr.score AS STRING) as score,
        sr.reason as reason
    FROM scoring_results_exploded
),
-- Best (max-score) match per contributor across all targets.
-- Used to surface the LLM/rule reason that drove a MASTER_JOB_MERGE
-- chain for contributors of an absorbed master.
best_match_per_contributor AS (
    SELECT
        {self.unified_id_key},
        score AS best_match_score,
        reason AS best_match_reason
    FROM (
        SELECT
            {self.unified_id_key},
            score,
            reason,
            ROW_NUMBER() OVER (
                PARTITION BY {self.unified_id_key}
                ORDER BY CAST(score AS DOUBLE) DESC NULLS LAST
            ) AS rn
        FROM scoring_results_parsed
        WHERE score IS NOT NULL
    ) ranked
    WHERE rn = 1
),
-- Exclude unmerged records entirely from merged_contributors_enriched
-- (they are handled by unmerged_as_match / promoted_masters).
-- Detect force-merge chains via master_merge_final to override reason/status.
merged_contributors_enriched AS (
    SELECT
        cc.master_{self.id_key},
        cc.{self.unified_id_key},
        cc.source_path,
        CASE
            WHEN force_merge_chain.final_master_id IS NOT NULL
                AND force_merge_chain.action_type = 'MASTER_JOB_MERGE'
                THEN COALESCE(bmpc.best_match_score, '1.0')
            WHEN om.original_action_type IN ('INITIAL_LOAD', 'JOB_INSERT') THEN '1.0'
            WHEN om.original_action_type IN ('JOB_MERGE', 'MANUAL_MERGE')  THEN COALESCE(srp.score, '1.0')
            ELSE '1.0'
        END AS score,
        CASE
            WHEN force_merge_chain.final_master_id IS NOT NULL
                AND force_merge_chain.action_type = 'MASTER_MANUAL_MERGE'
                THEN 'Masters merged manually'
            WHEN force_merge_chain.final_master_id IS NOT NULL
                AND force_merge_chain.action_type = 'MASTER_JOB_MERGE'
                THEN CONCAT('Masters merged automatically - ',
                            COALESCE(bmpc.best_match_reason, 'high confidence match'))
            WHEN force_merge_chain.final_master_id IS NOT NULL
                THEN 'Force merged'
            WHEN om.original_action_type = 'INITIAL_LOAD'  THEN 'Record initially loaded'
            WHEN om.original_action_type = 'JOB_INSERT'    THEN 'Record inserted'
            WHEN om.original_action_type = 'JOB_MERGE'
                THEN COALESCE(CONCAT('Record merged automatically - ', srp.reason), 'Merged contributor')
            WHEN om.original_action_type = 'MANUAL_MERGE'  THEN 'Record merged manually'
            ELSE 'Unknown'
        END AS reason,
        CASE
            WHEN force_merge_chain.final_master_id IS NOT NULL
                AND force_merge_chain.action_type = 'MASTER_MANUAL_MERGE'
                THEN 'MASTER_MANUAL_MERGE'
            WHEN force_merge_chain.final_master_id IS NOT NULL
                AND force_merge_chain.action_type = 'MASTER_JOB_MERGE'
                THEN 'MASTER_JOB_MERGE'
            WHEN force_merge_chain.final_master_id IS NOT NULL
                THEN 'MASTER_FORCE_MERGE'
            ELSE COALESCE(om.original_action_type, 'MERGED')
        END AS merge_status
    FROM current_contributors cc
    -- Exclude records that have been unmerged; they are fully
    -- handled by unmerged_as_match and promoted_masters in all scenarios.
    LEFT JOIN unmerged_records ur_excl
        ON cc.{self.unified_id_key} = ur_excl.{self.unified_id_key}
    LEFT JOIN original_merge om
        ON cc.{self.unified_id_key} = om.{self.unified_id_key}
    LEFT JOIN scoring_results_parsed srp
        ON  cc.{self.unified_id_key}   = srp.{self.unified_id_key}
        AND om.original_master_id = srp.target_lakefusion_id
    LEFT JOIN best_match_per_contributor bmpc
        ON cc.{self.unified_id_key} = bmpc.{self.unified_id_key}
    -- Detect force-merge only for records NOT currently in an unmerged state.
    -- If the record is currently unmerged, unmerged_as_match owns it — we must
    -- not let the stale force_merge_chain join produce a duplicate row.
    LEFT JOIN (
        SELECT
            match_id       AS old_master_id,
            master_id      AS final_master_id,
            action_type
        FROM (
            SELECT
                match_id,
                master_id,
                action_type,
                ROW_NUMBER() OVER (
                    PARTITION BY match_id
                    ORDER BY version DESC, created_at DESC
                ) AS rn
            FROM {self.context.merge_activities_table}
            WHERE action_type IN ('MASTER_FORCE_MERGE', 'MASTER_MANUAL_MERGE', 'MASTER_JOB_MERGE')
        )
        WHERE rn = 1
    ) force_merge_chain
        ON  om.original_master_id = force_merge_chain.old_master_id
        AND cc.master_{self.id_key}    = force_merge_chain.final_master_id
        AND ur_excl.{self.unified_id_key} IS NULL   -- only apply when not currently unmerged
    WHERE cc.record_status = 'MERGED'
      AND ur_excl.{self.unified_id_key} IS NULL   -- FIX 1: drop unmerged records
),
all_matches AS (
    -- Combine MERGED contributors, PENDING matches, unmerged views,
    -- and promoted master views.
    SELECT master_{self.id_key}, {self.unified_id_key}, source_path, score, reason, merge_status
    FROM merged_contributors_enriched

    UNION ALL

    -- Old master sees the record as 'Record unmerged' / MANUAL_UNMERGE
    SELECT master_{self.id_key}, {self.unified_id_key}, source_path, score, reason, merge_status
    FROM unmerged_as_match

    UNION ALL

    -- New promoted master sees 'Record unmerged and promoted to master'
    SELECT master_{self.id_key}, {self.unified_id_key}, source_path, score, reason, merge_status
    FROM promoted_masters

    {all_matches_union}
),
matches_with_details AS (
    SELECT
        am.master_{self.id_key},
        u.{self.unified_id_key},
        u.source_path,
        u.source_id,
        {', '.join([f'u.{attr}' for attr in entity_attributes])},
        STRUCT(
            am.score as score,
            am.reason as reason,
            am.merge_status as merge_status
        ) as match_info
    FROM all_matches am
    INNER JOIN {self.context.unified_table} u
        ON am.{self.unified_id_key} = u.{self.unified_id_key}
),
aggregated_matches AS (
    SELECT
        master_{self.id_key},
        COLLECT_SET({named_struct_expr}) as potential_matches
    FROM matches_with_details u
    GROUP BY master_{self.id_key}
)
SELECT
    {master_select},
    m.attributes_combined as attributes_combined,
    COALESCE(am.potential_matches, ARRAY()) as potential_matches
FROM {self.context.master_table} m
LEFT JOIN aggregated_matches am
    ON m.{self.id_key} = am.master_{self.id_key}
ORDER BY m.{self.id_key}
"""

        self.logger.info("Query built successfully")
        self.logger.info(f"Master columns: {self.id_key}, {', '.join(entity_attributes)}, attributes_combined, potential_matches")

        return {'query_built': True, 'processed_unified_included': self._processed_unified_exists}

    @step(order=3, name="Execute Potential Match Query", returns="potential_match_df with total count")
    def step_execute_query(self) -> Dict[str, Any]:
        """Execute the potential match query."""
        spark = self.context.spark

        self._potential_match_df = spark.sql(self._query)
        self.total_count = self._potential_match_df.count()

        self.logger.info(f"Generated potential match table")
        self.logger.info(f"Total master records: {self.total_count}")

        return {'total_count': self.total_count}

    @step(order=4, name="Add Column Tags", returns="potential_match_with_tags_df")
    def step_add_column_tags(self) -> Dict[str, Any]:
        """Add column tags to the potential match DataFrame."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes

        try:
            schema_name = self.context.master_table.split('.')[1]
            table_name = self.context.master_table.split('.')[2]

            tags_query = f"""
            SELECT
                column_name,
                map_from_arrays(collect_list(tag_name), collect_list(tag_value)) AS tags_map
            FROM {self.context.catalog_name}.information_schema.column_tags
            WHERE schema_name = '{schema_name}'
                AND table_name = '{table_name}'
            GROUP BY column_name
            """

            column_tags_df = spark.sql(tags_query)

            if column_tags_df.count() > 0:
                tags_expr = []
                for attr in entity_attributes:
                    tags_expr.append(
                        f"'{attr}', (SELECT tags_map FROM column_tags WHERE column_name = '{attr}')"
                    )

                map_clause = f"map({', '.join(tags_expr)}) AS tags"

                self._potential_match_with_tags_df = spark.sql(f"""
                    WITH column_tags AS (
                        {tags_query}
                    ),
                    pot_match AS (
                        {self._query}
                    )
                    SELECT
                        pot_match.*,
                        {map_clause}
                    FROM pot_match
                """)

                self.logger.info("Column tags added successfully")
            else:
                self.logger.info("No column tags found, using empty tags map")
                tag_columns = []
                for attr in entity_attributes:
                    tag_columns.extend([lit(attr), lit(None).cast("map<string,string>")])

                self._potential_match_with_tags_df = self._potential_match_df.withColumn(
                    "tags",
                    create_map(*tag_columns)
                )

        except Exception as e:
            self.logger.info(f"Error adding tags: {e}")
            self.logger.info("Proceeding with empty tags column")

            tag_columns = []
            for attr in entity_attributes:
                tag_columns.extend([lit(attr), lit(None).cast("map<string,string>")])

            self._potential_match_with_tags_df = self._potential_match_df.withColumn(
                "tags",
                create_map(*tag_columns)
            )

        return {'tags_added': True}

    @step(order=5, name="Write to Delta Table", returns="table creation/update status")
    def step_write_to_delta_table(self) -> Dict[str, Any]:
        """Write the potential match DataFrame to Delta table."""
        spark = self.context.spark

        self._table_exists = spark.catalog.tableExists(self.potential_match_table)

        self.logger.info(f"{'Updating' if self._table_exists else 'Creating'} table: {self.potential_match_table}")

        self._potential_match_with_tags_df.write \
            .format("delta") \
            .option("mergeSchema", "true") \
            .mode("overwrite") \
            .saveAsTable(self.potential_match_table)

        self.logger.info("Table written successfully")

        return {'table_created': not self._table_exists, 'table_name': self.potential_match_table}

    def execute(self) -> TaskResult:
        """Execute the potential match workflow."""
        # Step 1: Check if processed_unified_table exists
        self.step_check_processed_unified_exists()

        # Step 2: Build the potential match query
        self.step_build_query()

        # Step 3: Execute the query
        self.step_execute_query()

        # Step 4: Add column tags
        self.step_add_column_tags()

        # Step 5: Write to Delta table
        self.step_write_to_delta_table()

        return TaskResult.success(
            message=f"Potential match table built with {self.total_count} master records",
            task_name=self.context.task_name,
            metrics={
                'total_masters': self.total_count,
                'table_created': not self._table_exists
            },
            task_values={
                'potential_match_complete': True,
                'total_masters': self.total_count
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Potential match table built",
            actual=self.total_count
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*80)
        self.logger.info("PROCESS POTENTIAL MATCH COMPLETE")
        self.logger.info("="*80)

        if result.is_success:
            metrics = result.metrics
            self.logger.info(f"\nSummary:")
            self.logger.info(f"  Total master records: {metrics.get('total_masters')}")
            self.logger.info(f"  Table created: {metrics.get('table_created')}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Process potential match failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.info(f"  Error: {error}")
