"""
Process Unmatched Records Executor for normal deduplication.

Creates new individual master records for ACTIVE unified records that have
no MATCH or POTENTIAL_MATCH in processed_unified (only NO_MATCH or no entries).

Workflow:
1. Find unmatched records (ACTIVE with only NO_MATCH or no entries)
2. Generate lakefusion_ids
3. Prepare master records with attributes_combined
4. Insert into master table (avoiding duplicates)
5. Collect data for serverless compatibility
6. Update unified table (set master_lakefusion_id and record_status = MERGED)
7. Prepare attribute version sources
8. Insert attribute version sources
9. Log merge activities (JOB_INSERT)
"""

from typing import Any, Dict, List, Optional
from datetime import datetime

from pyspark.sql import DataFrame
from pyspark.sql.functions import (
    col, lit, current_timestamp, udf, array, struct, concat_ws
)
from pyspark.sql.types import StringType
from delta.tables import DeltaTable

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ProcessUnmatchedRecordsExecutor(BaseStepTask):
    """
    Executor for processing unmatched records.

    Creates new individual master records for ACTIVE unified records
    that have no MATCH or POTENTIAL_MATCH in processed_unified.
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        super().__init__(context, override_instance=override_instance)
        self.id_key = context.master_id_key
        self.unified_id_key = context.unified_id_key
        self.records_inserted = 0
        self.records_skipped = 0
        self.new_master_version = 0
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Instance variables for intermediate results
        self._unmatched_df: DataFrame = None
        self._unmatched_count = 0
        self._unmatched_with_id_df: DataFrame = None
        self._new_masters_df: DataFrame = None
        self._new_masters_to_insert: DataFrame = None
        self._id_mapping_data = None
        self._id_mapping_schema = None
        self._actual_records_to_process = 0
        self._attr_sources_df: DataFrame = None

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*80)
        self.logger.info("PROCESS UNMATCHED RECORDS")
        self.logger.info("="*80)
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Master ID Key: {self.id_key}")
        self.logger.info(f"Unified ID Key: {self.unified_id_key}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id or 'None'}")
        self.logger.info(f"Unified Table: {self.context.unified_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Processed Unified Table: {self.context.processed_unified_table}")
        self.logger.info(f"Merge Activities Table: {self.context.merge_activities_table}")
        self.logger.info(f"Attribute Version Sources Table: {self.context.attribute_version_sources_table}")
        self.logger.info("="*80)

    @step(order=1, name="Find Unmatched Records", returns="unmatched_count")
    def step_find_unmatched_records(self) -> Dict[str, Any]:
        """Find ACTIVE unified records with no MATCH or POTENTIAL_MATCH."""
        spark = self.context.spark

        unmatched_query = f"""
WITH active_records AS (
    SELECT {self.unified_id_key}
    FROM {self.context.unified_table}
    WHERE record_status = 'ACTIVE'
),
records_with_match_or_potential AS (
    SELECT DISTINCT pu.{self.unified_id_key}
    FROM {self.context.processed_unified_table} pu
    WHERE pu.exploded_result.match IN ('MATCH', 'POTENTIAL_MATCH')
)
SELECT u.*
FROM {self.context.unified_table} u
INNER JOIN active_records ar
    ON u.{self.unified_id_key} = ar.{self.unified_id_key}
LEFT ANTI JOIN records_with_match_or_potential rmp
    ON u.{self.unified_id_key} = rmp.{self.unified_id_key}
WHERE u.record_status = 'ACTIVE'
"""

        self._unmatched_df = spark.sql(unmatched_query)
        self._unmatched_count = self._unmatched_df.count()

        self.logger.info(f"  Found {self._unmatched_count} unmatched ACTIVE records")
        self.logger.info(f"  These records have NO 'MATCH' or 'POTENTIAL_MATCH' in processed_unified")
        self.logger.info(f"  (They may have only 'NO_MATCH' entries or no entries at all)")

        # Verification stats
        self.logger.info("\nVerification:")
        total_active = spark.sql(f"""
            SELECT COUNT(*) as cnt
            FROM {self.context.unified_table}
            WHERE record_status = 'ACTIVE'
        """).collect()[0]['cnt']

        records_with_match_or_potential = spark.sql(f"""
            SELECT COUNT(DISTINCT {self.unified_id_key}) as cnt
            FROM {self.context.processed_unified_table}
            WHERE exploded_result.match IN ('MATCH', 'POTENTIAL_MATCH')
        """).collect()[0]['cnt']

        self.logger.info(f"  Total ACTIVE records: {total_active}")
        self.logger.info(f"  Records with MATCH or POTENTIAL_MATCH: {records_with_match_or_potential}")
        self.logger.info(f"  Unmatched (only NO_MATCH or no entries): {self._unmatched_count}")

        return {'unmatched_count': self._unmatched_count}

    @step(order=2, name="Generate LakeFusion IDs", returns="records with IDs")
    def step_generate_lakefusion_ids(self) -> Dict[str, Any]:
        """Generate lakefusion_ids for unmatched records."""
        from lakefusion_core_engine.identifiers import generate_lakefusion_id

        generate_lakefusion_id_udf = udf(
            lambda source_path, source_id: generate_lakefusion_id(source_path, str(source_id)),
            StringType()
        )

        self._unmatched_with_id_df = self._unmatched_df.withColumn(
            self.id_key,
            generate_lakefusion_id_udf(col("source_path"), col("source_id"))
        )

        self.logger.info(f"  Generated lakefusion_ids for {self._unmatched_count} records")
        self.logger.info(f"  IDs are deterministic - same source_path + source_id = same lakefusion_id")

        return {'records_with_ids': self._unmatched_count}

    @step(order=3, name="Prepare Master Records", returns="new_masters_df")
    def step_prepare_master_records(self) -> Dict[str, Any]:
        """Prepare master records with attributes_combined."""
        entity_attributes = self.context.entity_attributes
        match_attributes = self.context.match_attributes

        master_columns = [self.id_key] + [attr for attr in entity_attributes if attr != self.id_key]
        combine_attrs = [attr for attr in match_attributes]

        self._new_masters_df = self._unmatched_with_id_df.select(*master_columns) \
            .withColumn(
                "attributes_combined",
                concat_ws(" | ", *[col(attr) for attr in combine_attrs])
            )

        self.logger.info(f"  Prepared {self._unmatched_count} new master records")
        self.logger.info(f"  Columns: {', '.join(master_columns + ['attributes_combined'])}")

        return {'masters_prepared': self._unmatched_count}

    @step(order=4, name="Insert Into Master Table", returns="records_inserted")
    def step_insert_into_master_table(self) -> Dict[str, Any]:
        """Insert new master records (avoiding duplicates)."""
        spark = self.context.spark

        current_master_version = spark.sql(
            f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1"
        ).select("version").collect()[0][0]

        self.logger.info(f"  Current master table version: {current_master_version}")

        # Check for existing lakefusion_ids to avoid duplicates
        existing_ids = spark.sql(f"""
            SELECT {self.id_key}
            FROM {self.context.master_table}
        """).select(self.id_key)

        # Filter out records that already exist
        self._new_masters_to_insert = self._new_masters_df.join(
            existing_ids,
            on=self.id_key,
            how="left_anti"
        )

        records_to_insert = self._new_masters_to_insert.count()
        self.records_skipped = self._unmatched_count - records_to_insert

        if records_to_insert == 0:
            self.logger.info(f"  All {self._unmatched_count} records already exist in master table")
            self.logger.info(f"  Skipping insert to avoid duplicates")
            return {'records_inserted': 0, 'records_skipped': self._unmatched_count}

        if records_to_insert < self._unmatched_count:
            self.logger.info(f"  {self.records_skipped} records already exist, inserting only {records_to_insert} new records")

        # Insert only new masters
        self._new_masters_to_insert.write.mode("append").saveAsTable(self.context.master_table)

        self.new_master_version = spark.sql(
            f"DESCRIBE HISTORY {self.context.master_table} LIMIT 1"
        ).select("version").collect()[0][0]

        self.records_inserted = records_to_insert

        self.logger.info(f"  Inserted {records_to_insert} new master records")
        self.logger.info(f"  New master table version: {self.new_master_version}")

        return {'records_inserted': records_to_insert, 'new_master_version': int(self.new_master_version)}

    @step(order=5, name="Collect Data Before Unified Update", returns="collected records count")
    def step_collect_data_before_update(self) -> Dict[str, Any]:
        """Collect data into memory for serverless compatibility."""
        entity_attributes = self.context.entity_attributes

        # CRITICAL FOR SERVERLESS: Collect data into memory BEFORE updating unified table
        id_mapping_df_select = self._unmatched_with_id_df.select(
            col(self.id_key),
            col(self.unified_id_key),
            col("source_path"),
            col("source_id"),
            *[col(attr) for attr in entity_attributes if attr != self.id_key]
        )

        # Collect the data into Python list (materializes in driver memory)
        self._id_mapping_data = id_mapping_df_select.collect()
        self._id_mapping_schema = id_mapping_df_select.schema

        self._actual_records_to_process = len(self._id_mapping_data)

        self.logger.info(f"  Collected {self._actual_records_to_process} records into memory")
        self.logger.info(f"  Schema preserved for recreating DataFrames")

        return {'collected_records': self._actual_records_to_process}

    @step(order=6, name="Update Unified Table", returns="unified records updated")
    def step_update_unified_table(self) -> Dict[str, Any]:
        """Update unified table with master IDs and MERGED status."""
        spark = self.context.spark

        id_mapping_df_for_unified = spark.createDataFrame(self._id_mapping_data, self._id_mapping_schema)

        unified_updates_df = id_mapping_df_for_unified.select(
            col(self.unified_id_key),
            col(self.id_key).alias(f"master_{self.id_key}"),
            lit("MERGED").alias("record_status")
        )

        unified_delta_table = DeltaTable.forName(spark, self.context.unified_table)

        unified_delta_table.alias("target").merge(
            unified_updates_df.alias("source"),
            f"target.{self.unified_id_key} = source.{self.unified_id_key}"
        ).whenMatchedUpdate(set={
            f"master_{self.id_key}": f"source.master_{self.id_key}",
            "record_status": "source.record_status"
        }).execute()

        self.logger.info(f"  Updated unified table")
        self.logger.info(f"  Records updated: {self._actual_records_to_process}")
        self.logger.info(f"  Set master_lakefusion_id and record_status = MERGED")

        return {'unified_records_updated': self._actual_records_to_process}

    @step(order=7, name="Prepare Attribute Version Sources", returns="attr_sources_df")
    def step_prepare_attribute_version_sources(self) -> Dict[str, Any]:
        """Prepare attribute version sources for insertion."""
        spark = self.context.spark
        entity_attributes = self.context.entity_attributes

        id_mapping_df_for_attrs = spark.createDataFrame(self._id_mapping_data, self._id_mapping_schema)

        attribute_mappings = []
        for attr in entity_attributes:
            if attr != self.id_key:
                attribute_mappings.append(
                    struct(
                        lit(attr).alias("attribute_name"),
                        col(attr).cast("string").alias("attribute_value"),
                        col("source_path").alias("source")
                    )
                )

        self._attr_sources_df = id_mapping_df_for_attrs.select(
            col(self.id_key),
            lit(int(self.new_master_version)).alias("version"),
            array(*attribute_mappings).alias("attribute_source_mapping")
        )

        self.logger.info(f"  Prepared attribute version sources")
        self.logger.info(f"  Records: {self._actual_records_to_process}")
        self.logger.info(f"  Attributes per record: {len(entity_attributes) - 1}")

        return {'attr_sources_prepared': self._actual_records_to_process}

    @step(order=8, name="Insert Attribute Version Sources", returns="attr sources inserted")
    def step_insert_attribute_version_sources(self) -> Dict[str, Any]:
        """Insert attribute version sources into table."""
        self._attr_sources_df.write.mode("append").saveAsTable(
            self.context.attribute_version_sources_table
        )

        self.logger.info(f"  Inserted attribute version sources")
        self.logger.info(f"  Records inserted: {self._actual_records_to_process}")

        return {'attr_sources_inserted': self._actual_records_to_process}

    @step(order=9, name="Log Merge Activities", returns="merge activities logged")
    def step_log_merge_activities(self) -> Dict[str, Any]:
        """Log merge activities with JOB_INSERT action type."""
        spark = self.context.spark

        id_mapping_df_for_activities = spark.createDataFrame(self._id_mapping_data, self._id_mapping_schema)

        merge_activities_df = id_mapping_df_for_activities.select(
            col(self.id_key).alias("master_id"),
            col(self.unified_id_key).alias("match_id"),
            col("source_path").alias("source"),
            lit(int(self.new_master_version)).alias("version"),
            lit("JOB_INSERT").alias("action_type"),
            current_timestamp().alias("created_at")
        )

        merge_activities_df.write.mode("append").saveAsTable(
            self.context.merge_activities_table
        )

        self.logger.info(f"  Logged merge activities")
        self.logger.info(f"  Records logged: {self._actual_records_to_process}")
        self.logger.info(f"  Action_type: JOB_INSERT")

        return {'merge_activities_logged': self._actual_records_to_process}

    def execute(self) -> TaskResult:
        """Execute the unmatched records workflow."""
        # Step 1: Find unmatched records
        result = self.step_find_unmatched_records()

        if self._unmatched_count == 0:
            self.logger.info("\n  No unmatched records to process")
            return TaskResult.success(
                message="No unmatched records to process",
                task_name=self.context.task_name,
                metrics={
                    'records_inserted': 0,
                    'records_skipped': 0,
                    'unmatched_found': 0
                },
                task_values={
                    'unmatched_complete': True,
                    'records_inserted': 0,
                    'new_masters_created': 0,
                    'records_skipped': 0
                }
            )

        # Step 2: Generate lakefusion IDs
        self.step_generate_lakefusion_ids()

        # Step 3: Prepare master records
        self.step_prepare_master_records()

        # Step 4: Insert into master table
        insert_result = self.step_insert_into_master_table()

        if insert_result['records_inserted'] == 0:
            return TaskResult.success(
                message="No new records to insert - all already exist",
                task_name=self.context.task_name,
                metrics={
                    'records_inserted': 0,
                    'records_skipped': self._unmatched_count
                },
                task_values={
                    'unmatched_complete': True,
                    'records_inserted': 0,
                    'new_masters_created': 0,
                    'records_skipped': self._unmatched_count
                }
            )

        # Step 5: Collect data before unified update
        self.step_collect_data_before_update()

        # Step 6: Update unified table
        self.step_update_unified_table()

        # Step 7: Prepare attribute version sources
        self.step_prepare_attribute_version_sources()

        # Step 8: Insert attribute version sources
        self.step_insert_attribute_version_sources()

        # Step 9: Log merge activities
        self.step_log_merge_activities()

        return TaskResult.success(
            message=f"Processed {self.records_inserted} unmatched records",
            task_name=self.context.task_name,
            metrics={
                'unmatched_found': self._unmatched_count,
                'records_inserted': self.records_inserted,
                'records_skipped': self.records_skipped,
                'master_version': int(self.new_master_version)
            },
            task_values={
                'unmatched_complete': True,
                'records_inserted': self.records_inserted,
                'new_masters_created': self.records_inserted,
                'records_skipped': self.records_skipped
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Unmatched records processed",
            actual=self.records_inserted
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*80)
        self.logger.info("UNMATCHED RECORDS PROCESSING COMPLETE")
        self.logger.info("="*80)

        if result.is_success:
            metrics = result.metrics
            self.logger.info(f"\n  Summary:")
            self.logger.info(f"    Unmatched records found: {metrics.get('unmatched_found', 0)}")
            self.logger.info(f"    New masters created: {metrics.get('records_inserted', 0)}")
            self.logger.info(f"    Records skipped (already exist): {metrics.get('records_skipped', 0)}")
            if metrics.get('master_version'):
                self.logger.info(f"    Master table version: {metrics.get('master_version')}")
            self.logger.info(f"    Unified table updated")
            self.logger.info(f"    Attribute version sources logged")
            self.logger.info(f"    Merge activities logged (JOB_INSERT)")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Process unmatched records failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.info(f"  Error: {error}")
