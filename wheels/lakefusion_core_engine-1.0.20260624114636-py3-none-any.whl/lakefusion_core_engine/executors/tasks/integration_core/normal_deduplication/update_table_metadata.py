"""
Update Table Metadata Executor for normal deduplication.

Updates the table_meta_info tracking table with the latest processed
versions for the unified table and all dataset tables.

Workflow:
1. Get latest version of unified table and update metadata
2. Get latest version of each dataset table and update metadata
"""

from typing import Any, Dict, List, Optional

from pyspark.sql.functions import current_timestamp
from delta.tables import DeltaTable

from ....step_task import BaseStepTask
from ....decorators import step
from ....models import TaskContext, TaskResult, TaskStatus, ValidationResult


class UpdateTableMetadataExecutor(BaseStepTask):
    """
    Executor for updating table metadata tracking.

    Updates last_processed_version for unified table and all dataset tables.
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        super().__init__(context, override_instance=override_instance)
        self.tables_updated = 0

        # Instance variables for intermediate results
        self.updated_tables: List[Dict[str, Any]] = []
        self.unified_table_version: int = None
        self.dataset_table_versions: Dict[str, int] = {}
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    @property
    def meta_info_table(self) -> str:
        """Get the metadata info table name."""
        return f"{self.context.catalog_name}.silver.table_meta_info"

    @property
    def dataset_tables(self) -> List[str]:
        """Get the list of dataset tables from params."""
        tables = self.context.params.get('dataset_tables', [])
        if isinstance(tables, str):
            import json
            return json.loads(tables)
        return tables

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*80)
        self.logger.info("UPDATE TABLE METADATA")
        self.logger.info("="*80)
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id or 'None'}")
        self.logger.info(f"Unified Table: {self.context.unified_table}")
        self.logger.info(f"Meta Info Table: {self.meta_info_table}")
        self.logger.info(f"Dataset Tables: {len(self.dataset_tables)} tables")
        for table in self.dataset_tables:
            self.logger.info(f"  - {table}")
        self.logger.info("="*80)

    def _update_last_processed_version(self, table_name: str, version: int) -> None:
        """
        Update or insert last processed version into metadata table.

        Args:
            table_name: The table whose version is being tracked
            version: The latest version of the table
        """
        spark = self.context.spark

        if not spark.catalog.tableExists(self.meta_info_table):
            # Create the meta info table
            schema = "table_name STRING, entity_name STRING, last_processed_version LONG, last_processed_timestamp TIMESTAMP"
            spark.sql(f"CREATE TABLE {self.meta_info_table} ({schema}) USING DELTA")
            self.logger.info(f"  Created meta info table: {self.meta_info_table}")

        # Create DataFrame to upsert
        new_row = spark.createDataFrame(
            [(table_name, self.context.entity, version)],
            ["table_name", "entity_name", "last_processed_version"]
        )
        new_row = new_row.withColumn("last_processed_timestamp", current_timestamp())

        delta_meta = DeltaTable.forName(spark, self.meta_info_table)

        # Merge
        delta_meta.alias("target").merge(
            new_row.alias("source"),
            condition="target.table_name = source.table_name AND target.entity_name = source.entity_name"
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

    @step(order=1, name="Update Unified Table Metadata", returns="unified table version")
    def step_update_unified_table_metadata(self) -> Dict[str, Any]:
        """Get latest version of unified table and update metadata."""
        spark = self.context.spark

        # Get latest version of unified table
        self.unified_table_version = spark.sql(
            f"DESCRIBE HISTORY {self.context.unified_table}"
        ).selectExpr("max(version)").first()[0]

        self._update_last_processed_version(self.context.unified_table, self.unified_table_version)
        self.updated_tables.append({
            'table': self.context.unified_table,
            'version': self.unified_table_version
        })
        self.tables_updated += 1

        self.logger.info(f"  Updated unified table: {self.context.unified_table}")
        self.logger.info(f"  Version: {self.unified_table_version}")

        return {
            'table': self.context.unified_table,
            'version': int(self.unified_table_version)
        }

    @step(order=2, name="Update Dataset Tables Metadata", returns="dataset tables versions")
    def step_update_dataset_tables_metadata(self) -> Dict[str, Any]:
        """Get latest version of each dataset table and update metadata."""
        spark = self.context.spark

        # Update all dataset tables
        for dataset in self.dataset_tables:
            latest_version = spark.sql(
                f"DESCRIBE HISTORY {dataset}"
            ).selectExpr("max(version)").first()[0]

            self._update_last_processed_version(dataset, latest_version)
            self.updated_tables.append({
                'table': dataset,
                'version': latest_version
            })
            self.dataset_table_versions[dataset] = latest_version
            self.tables_updated += 1

            self.logger.info(f"  Updated table: {dataset}")
            self.logger.info(f"  Version: {latest_version}")

        return {
            'dataset_tables_updated': len(self.dataset_tables),
            'versions': self.dataset_table_versions
        }

    def execute(self) -> TaskResult:
        """Execute the metadata update workflow."""
        # Step 1: Update unified table metadata
        self.step_update_unified_table_metadata()

        # Step 2: Update dataset tables metadata
        self.step_update_dataset_tables_metadata()

        return TaskResult.success(
            message=f"Updated metadata for {self.tables_updated} tables",
            task_name=self.context.task_name,
            metrics={
                'tables_updated': self.tables_updated,
                'updated_tables': self.updated_tables
            },
            task_values={
                'metadata_update_complete': True,
                'tables_updated': self.tables_updated
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Table metadata updated",
            actual=self.tables_updated
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*80)
        self.logger.info("UPDATE TABLE METADATA COMPLETE")
        self.logger.info("="*80)

        if result.is_success:
            metrics = result.metrics
            self.logger.info(f"\n  Summary:")
            self.logger.info(f"    Tables updated: {metrics.get('tables_updated')}")
            for table_info in metrics.get('updated_tables', []):
                self.logger.info(f"    - {table_info['table']}: version {table_info['version']}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Update table metadata failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.info(f"  Error: {error}")
