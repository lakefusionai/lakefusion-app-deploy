"""
Parse Entity & Model JSON Executor for integration core.

Parses entity and model JSON configuration files and extracts all
necessary parameters for downstream pipeline tasks.

Workflow:
1. Read entity JSON file from Volume
2. Parse entity configuration (attributes, datasets, survivorship rules)
3. Read model JSON file from Volume
4. Parse model configuration (LLM settings, embedding settings, thresholds)
5. Set all task values for downstream tasks
"""

import json
from typing import Any, Dict, List, Optional

from ...base import BaseTask
from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult

# Import SDK utilities
from lakefusion_core_engine.utils.parse_utils import (
    get_primary_dataset_path,
    get_dataset_tables,
    parse_attributes_mapping_json,
    get_default_survivorship_rules,
    transform_survivorship_rules,
)
from lakefusion_core_engine.utils.taskvalues_enum import TaskValueKey


class ParseEntityModelJsonExecutor(BaseStepTask):
    """
    Executor for parsing entity and model JSON configurations.

    Reads JSON configuration files and extracts all parameters needed
    for the entity processing pipeline.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.entity_json = {}
        self.model_json = {}
        self.parsed_values = {}
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

        # Intermediate results from entity parsing
        self.entity = None
        self.master_table = None
        self.primary_table = None
        self.dataset_tables = None
        self.dataset_objects = None
        self.entity_attributes = None
        self.attributes_mapping = None
        self.entity_attributes_datatype = None
        self.rdm_flag = 0
        self.primary_key = None
        self.id_key = None
        self.default_survivorship_rules = None
        self.validation_functions = None
        self.dataset_tables_len = 0
        self.is_single_source = False
        self.is_entity_dnb_enabled = False
        self.entity_dnb_settings = {}
        self.entity_created_by = None
        self.reference_attribute_config = {}

        # Intermediate results from model parsing
        self.llm_model_source = None
        self.llm_model_source_str = None
        self.llm_model = None
        self.llm_model_endpoint = None
        self.llm_provisionless = False
        self.llm_temperature = 0.0
        self.embedding_model_source = None
        self.embedding_model_source_str = None
        self.embedding_model = None
        self.embedding_model_endpoint = None
        self.embedding_provisionless = False
        self.match_attributes = None
        self.config_thresholds = None
        self.vs_endpoint = None
        self.additional_instructions = None
        self.max_potential_matches = None
        self.base_prompt = None
        self.pt_models_config = {}
        self.deterministic_rules=None
        self.model_created_by = None

    @property
    def entity_id(self) -> str:
        """Get entity ID from params."""
        return self.context.params.get('entity_id', '')

    @property
    def experiment_id(self) -> str:
        """Get experiment ID from params."""
        return self.context.params.get('experiment_id', '')

    @property
    def process_records(self) -> str:
        """Get process records limit from params."""
        return self.context.params.get('process_records', '')

    @property
    def is_integration_hub(self) -> str:
        """Get integration hub flag from params."""
        return self.context.params.get('is_integration_hub', '')

    @property
    def experiment_path(self) -> str:
        """Get experiment path based on experiment_id."""
        if self.experiment_id and self.experiment_id != 'prod':
            return f'experiment_{self.experiment_id}'
        return 'prod'

    @property
    def entity_json_path(self) -> str:
        """Get entity JSON file path."""
        return f'/Volumes/{self.context.catalog_name}/metadata/metadata_files/entity_{self.entity_id}_{self.experiment_path}_entity.json'

    @property
    def model_json_path(self) -> str:
        """Get model JSON file path."""
        return f'/Volumes/{self.context.catalog_name}/metadata/metadata_files/entity_{self.entity_id}_{self.experiment_path}_model.json'

    @property
    def pt_config_path(self) -> str:
        """Get PT models config JSON file path."""
        return f"/Volumes/{self.context.catalog_name}/metadata/metadata_files/pt_models_config.json"

    @property
    def meta_info_table(self) -> str:
        """Get meta info table name."""
        return f"{self.context.catalog_name}.silver.table_meta_info"

    def _load_pt_models_config(self) -> None:
        """Load provisioned throughput models config from Volume JSON file."""
        self.pt_models_config = {}
        try:
            with open(self.pt_config_path, 'r') as f:
                pt_data = json.load(f)

            self.pt_models_config = {
                model["entity_name"]: {
                    "pt_type": model["pt_type"],
                    "entity_version": model.get("entity_version", "1"),
                    "chunk_size": model["chunk_size"],
                    "provisioned_model_units": model.get("provisioned_model_units"),
                    "min_provisioned_throughput": model.get("min_provisioned_throughput"),
                    "max_provisioned_throughput": model.get("max_provisioned_throughput"),
                }
                for model in pt_data.get("pt_models", [])
                if model.get("is_active")
            }
            self.logger.info(f"  Loaded {len(self.pt_models_config)} active PT model configs")
        except FileNotFoundError:
            self.logger.info(f"  No PT config file found, all models will use pay-per-token mode")
        except Exception as e:
            self.logger.info(f"  Failed to load PT config: {e}. All models will use pay-per-token mode.")

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*80)
        self.logger.info("PARSING ENTITY AND MODEL JSON")
        self.logger.info("="*80)
        self.logger.info(f"Entity ID: {self.entity_id}")
        self.logger.info(f"Experiment ID: {self.experiment_id or 'prod'}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Entity JSON Path: {self.entity_json_path}")
        self.logger.info(f"Model JSON Path: {self.model_json_path}")
        self.logger.info("="*80)

    @step(order=1, name="Read Entity JSON", returns="dict - entity JSON configuration")
    def step_read_entity_json(self) -> Dict[str, Any]:
        """Read and parse the entity JSON file from Volume."""
        try:
            with open(self.entity_json_path, 'r') as f:
                entity_json_str = f.read()
            self.entity_json = json.loads(entity_json_str)
            self.logger.info(f"  Entity JSON loaded successfully")
            return self.entity_json
        except Exception as e:
            raise ValueError(f"Failed to read entity JSON: {e}")

    @step(order=2, name="Parse Entity Configuration", returns="dict - parsed entity values")
    def step_parse_entity_config(self) -> Dict[str, Any]:
        """Parse entity configuration from the loaded JSON."""
        self.entity = self.entity_json.get("name", "entity").lower().replace(" ", "_")
        self.master_table = self.entity_json.get("path")
        dataset_mappings = self.entity_json.get("dataset_mappings", [])

        # Use SDK parse_utils functions
        self.primary_table = get_primary_dataset_path(dataset_mappings)
        self.dataset_tables, self.dataset_objects = get_dataset_tables(dataset_mappings)
        self.entity_attributes = [item["name"] for item in self.entity_json.get("attributes", [])]
        self.attributes_mapping = parse_attributes_mapping_json(dataset_mappings)
        self.entity_attributes_datatype = {
            item["name"]: item["type"]
            for item in self.entity_json.get("attributes", [])
        }
        self.rdm_flag = 1 if any(v == "REFERENCE_ENTITY" for v in self.entity_attributes_datatype.values()) else 0
        self.primary_key = next(
            (attr['name'] for attr in self.entity_json.get("attributes", [])
             if attr.get('is_primary_key') == True),
            self.entity_attributes[0] if self.entity_attributes else ''
        )
        self.id_key = "lakefusion_id"
        self.default_survivorship_rules = get_default_survivorship_rules(
            self.entity_json.get("survivorship", [])
        )
        # Transform survivorship rules: resolve dataset IDs to actual table paths
        # This ensures paths include _cleaned suffix when DQ cleaned tables are used
        self.default_survivorship_rules = transform_survivorship_rules(
            self.default_survivorship_rules, self.dataset_objects
        )
        self.validation_functions = self.entity_json.get("validation_functions")
        self.dataset_tables_len = len(self.dataset_tables)

        # D&B integration settings
        dnb_integration = self.entity_json.get("dnb_integration") or {}
        self.is_entity_dnb_enabled = dnb_integration.get("is_active", False) if dnb_integration else False
        self.entity_dnb_settings = self.entity_json.get("dnb_integration", {})

        # Entity metadata
        self.entity_created_by = self.entity_json.get("created_by", "")

        # Check if single source
        self.is_single_source = self.dataset_tables_len == 1

        print(f"  Entity: {self.entity}")
        print(f"  Master Table: {self.master_table}")
        print(f"  Primary Table: {self.primary_table}")
        print(f"  Dataset Tables: {self.dataset_tables_len}")
        print(f"  Entity Attributes: {len(self.entity_attributes)}")
        print(f"  Is Single Source: {self.is_single_source}")
        print(f"  Is D&B Enabled: {self.is_entity_dnb_enabled}")

        # Store entity parsed values
        entity_values = {
            'entity': self.entity,
            'master_table': self.master_table,
            'primary_table': self.primary_table,
            'id_key': self.id_key,
            'primary_key': self.primary_key,
            'dataset_tables': json.dumps(self.dataset_tables),
            'dataset_objects': json.dumps(self.dataset_objects),
            'entity_attributes': json.dumps(self.entity_attributes),
            'attributes_mapping': json.dumps(self.attributes_mapping),
            'entity_attributes_datatype': json.dumps(self.entity_attributes_datatype),
            'rdm_flag': self.rdm_flag,
            'default_survivorship_rules': json.dumps(self.default_survivorship_rules),
            'validation_functions': json.dumps(self.validation_functions),
            'is_golden_deduplication': self.dataset_tables_len,
            'is_single_source': self.is_single_source,
            'is_entity_dnb_enabled': self.is_entity_dnb_enabled,
            'entity_dnb_settings': json.dumps(self.entity_dnb_settings),
            'catalog_name': self.context.catalog_name,
            'meta_info_table': self.meta_info_table,
            'entity_created_by': self.entity_created_by,
        }
        self.parsed_values.update(entity_values)

        return entity_values

    @step(order=3, name="Read Model JSON", returns="dict - model JSON configuration")
    def step_read_model_json(self) -> Dict[str, Any]:
        """Read and parse the model JSON file from Volume."""
        try:
            with open(self.model_json_path, 'r') as f:
                model_json_str = f.read()
            self.model_json = json.loads(model_json_str)
            self.logger.info(f"  Model JSON loaded successfully")
            return self.model_json
        except Exception as e:
            raise ValueError(f"Failed to read model JSON: {e}")

    @step(order=4, name="Parse Model Configuration", returns="dict - parsed model values")
    def step_parse_model_config(self) -> Dict[str, Any]:
        """Parse model configuration from the loaded JSON."""
        self.llm_model_source = self.model_json.get('llm_model_source', 'databricks_foundation')
        self.llm_model_source_str = self.llm_model_source
        self.embedding_model_source = self.model_json.get('embedding_model_source', 'databricks_foundation')
        self.embedding_model_source_str = self.embedding_model_source

        attribute_objects = self.model_json.get('attributes', [])
        self.match_attributes = [attr.get('name') for attr in attribute_objects]
        self.config_thresholds = self.model_json.get('config_thresold')
        self.vs_endpoint = self.model_json.get('vs_endpoint')
        self.additional_instructions = self.model_json.get('additional_instructions', '').replace("'", "''")
        self.max_potential_matches = self.model_json.get('max_potential_matches')

        self.base_prompt = self.model_json.get('base_prompt', {})
        if not self.base_prompt:
            self.base_prompt = None
        else:
            self.base_prompt = self.base_prompt.get('content', '')

        # Parse LLM model
        self.llm_model = ''
        self.llm_model_endpoint = ''
        self.llm_provisionless = False
        self.llm_temperature = 0.0

        if self.llm_model_source == 'databricks_foundation':
            foundation_config = self.model_json.get("llm_model", {}).get("databricks_foundation", {})
            self.llm_model = foundation_config.get("foundation_model_name", '')
            self.llm_provisionless = foundation_config.get("provisionless", False)
            self.llm_temperature = foundation_config.get("temperature", 0.0)

            if not self.llm_model:
                raise ValueError("Missing 'foundation_model_name' in databricks_foundation config")

            if self.llm_provisionless:
                self.llm_model_endpoint = self.llm_model
                self.logger.info(f"  Using provisionless Databricks foundation model: {self.llm_model_endpoint}")
        elif self.llm_model_source == 'databricks_custom':
            custom_model = self.model_json.get('llm_model', {})
            self.llm_model_source_str = f"databricks_custom_{custom_model.get('databricks_custom', {}).get('modeltype', '')}"
            self.llm_model = custom_model.get('databricks_custom', {}).get('modelname', '')
            self.llm_temperature = custom_model.get('databricks_custom', {}).get('temperature', 0.0)

        # Parse embedding model
        self.embedding_model = ''
        self.embedding_model_endpoint = ''
        self.embedding_provisionless = False

        if self.embedding_model_source == 'databricks_foundation':
            foundation_config = self.model_json.get('embedding_model', {}).get('databricks_foundation', {})
            self.embedding_model = foundation_config.get('foundation_model_name', '')
            self.embedding_provisionless = foundation_config.get('provisionless', False)
            if self.embedding_provisionless:
                self.embedding_model_endpoint = self.embedding_model
                self.logger.info(f"  Using provisionless Databricks foundation embedding model: {self.embedding_model_endpoint}")
        elif self.embedding_model_source == 'databricks_custom':
            custom_model_embedding = self.model_json.get('embedding_model', {})
            self.embedding_model_source_str = f"databricks_custom_{custom_model_embedding.get('databricks_custom', {}).get('modeltype', '')}"
            self.embedding_model = custom_model_embedding.get('databricks_custom', {}).get('modelname', '')

        # Model metadata
        self.model_created_by = self.model_json.get("created_by", "")

        # Compute deduplicated RBAC owner emails from entity + model creators
        owner_set = set()
        if self.entity_created_by:
            owner_set.add(self.entity_created_by)
        if self.model_created_by:
            owner_set.add(self.model_created_by)
        self.rbac_owner_emails = sorted(owner_set)

        # Load PT models config from Volume
        self._load_pt_models_config()

        print(f"  LLM Model: {self.llm_model}")
        print(f"  LLM Model Source: {self.llm_model_source_str}")
        print(f"  LLM Provisionless: {self.llm_provisionless}")
        print(f"  LLM Temperature: {self.llm_temperature}")
        print(f"  Embedding Model: {self.embedding_model}")
        print(f"  Embedding Model Source: {self.embedding_model_source_str}")
        print(f"  Embedding Provisionless: {self.embedding_provisionless}")
        print(f"  Match Attributes: {len(self.match_attributes)}")
        print(f"  VS Endpoint: {self.vs_endpoint}")

        # Store model parsed values
        model_values = {
            'llm_model_source': self.llm_model_source_str,
            'llm_model': self.llm_model,
            'llm_model_endpoint': self.llm_model_endpoint,
            'llm_provisionless': self.llm_provisionless,
            'llm_temperature': self.llm_temperature,
            'embedding_model_source': self.embedding_model_source_str,
            'embedding_model': self.embedding_model,
            'embedding_model_endpoint': self.embedding_model_endpoint,
            'embedding_provisionless': self.embedding_provisionless,
            'match_attributes': json.dumps(self.match_attributes),
            'config_thresholds': json.dumps(self.config_thresholds),
            'process_records': self.process_records,
            'vs_endpoint': self.vs_endpoint,
            'additional_instructions': self.additional_instructions,
            'max_potential_matches': self.max_potential_matches,
            'base_prompt': self.base_prompt,
            'pt_models_config': json.dumps(self.pt_models_config),
            'model_created_by': self.model_created_by,
            'rbac_owner_emails': json.dumps(self.rbac_owner_emails),
        }
        self.parsed_values.update(model_values)

        return model_values

    def execute(self) -> TaskResult:
        """Execute the parse entity model JSON workflow."""
        # Execute steps in sequence
        self.step_read_entity_json()
        self.step_parse_entity_config()
        self.step_read_model_json()
        self.step_parse_model_config()

        return TaskResult.success(
            message=f"Parsed entity '{self.entity}' configuration successfully",
            task_name=self.context.task_name,
            metrics={
                'entity': self.entity,
                'entity_attributes_count': len(self.entity_attributes),
                'match_attributes_count': len(self.match_attributes),
                'dataset_tables_count': self.dataset_tables_len,
                'is_single_source': self.is_single_source
            },
            task_values=self.parsed_values
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message="Entity and model JSON parsed successfully",
            actual=self.parsed_values.get('entity', '')
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*80)
        self.logger.info("PARSE ENTITY & MODEL JSON - COMPLETE")
        self.logger.info("="*80)

        if result.is_success:
            metrics = result.metrics
            self.logger.info(f"\n  Summary:")
            self.logger.info(f"    Entity: {metrics.get('entity')}")
            self.logger.info(f"    Entity Attributes: {metrics.get('entity_attributes_count')}")
            self.logger.info(f"    Match Attributes: {metrics.get('match_attributes_count')}")
            self.logger.info(f"    Dataset Tables: {metrics.get('dataset_tables_count')}")
            self.logger.info(f"    Is Single Source: {metrics.get('is_single_source')}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution using TaskValueKey enum."""
        if self.context.dbutils:
            dbutils = self.context.dbutils
            tv = result.task_values

            # Entity configuration
            dbutils.jobs.taskValues.set(TaskValueKey.ENTITY.value, tv.get('entity'))
            dbutils.jobs.taskValues.set(TaskValueKey.MASTER_TABLE.value, tv.get('master_table'))
            dbutils.jobs.taskValues.set(TaskValueKey.PRIMARY_TABLE.value, tv.get('primary_table'))
            dbutils.jobs.taskValues.set(TaskValueKey.ID_KEY.value, tv.get('id_key'))
            dbutils.jobs.taskValues.set(TaskValueKey.PRIMARY_KEY.value, tv.get('primary_key'))
            dbutils.jobs.taskValues.set(TaskValueKey.DATASET_TABLES.value, tv.get('dataset_tables'))
            dbutils.jobs.taskValues.set(TaskValueKey.DATASET_OBJECTS.value, tv.get('dataset_objects'))
            dbutils.jobs.taskValues.set(TaskValueKey.ENTITY_ATTRIBUTES.value, tv.get('entity_attributes'))
            dbutils.jobs.taskValues.set(TaskValueKey.ATTRIBUTES_MAPPING.value, tv.get('attributes_mapping'))
            dbutils.jobs.taskValues.set(TaskValueKey.ENTITY_ATTRIBUTES_DATATYPE.value, tv.get('entity_attributes_datatype'))
            dbutils.jobs.taskValues.set(TaskValueKey.RDM_FLAG.value, tv.get('rdm_flag'))
            dbutils.jobs.taskValues.set(TaskValueKey.DEFAULT_SURVIVORSHIP_RULES.value, tv.get('default_survivorship_rules'))
            dbutils.jobs.taskValues.set(TaskValueKey.VALIDATION_FUNCTIONS.value, tv.get('validation_functions'))
            dbutils.jobs.taskValues.set(TaskValueKey.IS_GOLDEN_DEDUPLICATION.value, tv.get('is_golden_deduplication'))
            dbutils.jobs.taskValues.set(TaskValueKey.IS_SINGLE_SOURCE.value, tv.get('is_single_source'))
            dbutils.jobs.taskValues.set(TaskValueKey.IS_ENTITY_DNB_ENABLED.value, tv.get('is_entity_dnb_enabled'))
            dbutils.jobs.taskValues.set(TaskValueKey.ENTITY_DNB_SETTINGS.value, tv.get('entity_dnb_settings'))
            dbutils.jobs.taskValues.set(TaskValueKey.CATALOG_NAME.value, tv.get('catalog_name'))
            dbutils.jobs.taskValues.set(TaskValueKey.META_INFO_TABLE.value, tv.get('meta_info_table'))
            dbutils.jobs.taskValues.set(TaskValueKey.ENTITY_CREATED_BY.value, tv.get('entity_created_by'))

            # Model configuration
            dbutils.jobs.taskValues.set(TaskValueKey.LLM_MODEL_SOURCE.value, tv.get('llm_model_source'))
            dbutils.jobs.taskValues.set(TaskValueKey.LLM_MODEL.value, tv.get('llm_model'))
            dbutils.jobs.taskValues.set(TaskValueKey.LLM_MODEL_ENDPOINT.value, tv.get('llm_model_endpoint'))
            dbutils.jobs.taskValues.set(TaskValueKey.EMBEDDING_MODEL_SOURCE.value, tv.get('embedding_model_source'))
            dbutils.jobs.taskValues.set(TaskValueKey.EMBEDDING_MODEL.value, tv.get('embedding_model'))
            dbutils.jobs.taskValues.set(TaskValueKey.EMBEDDING_MODEL_ENDPOINT.value, tv.get('embedding_model_endpoint'))
            dbutils.jobs.taskValues.set(TaskValueKey.MATCH_ATTRIBUTES.value, tv.get('match_attributes'))
            dbutils.jobs.taskValues.set(TaskValueKey.CONFIG_THRESHOLDS.value, tv.get('config_thresholds'))
            dbutils.jobs.taskValues.set(TaskValueKey.PROCESS_RECORDS.value, tv.get('process_records'))
            dbutils.jobs.taskValues.set(TaskValueKey.VS_ENDPOINT.value, tv.get('vs_endpoint'))
            dbutils.jobs.taskValues.set(TaskValueKey.ADDITIONAL_INSTRUCTIONS.value, tv.get('additional_instructions'))
            dbutils.jobs.taskValues.set(TaskValueKey.MAX_POTENTIAL_MATCHES.value, tv.get('max_potential_matches'))
            dbutils.jobs.taskValues.set(TaskValueKey.LLM_PROVISIONLESS.value, tv.get('llm_provisionless'))
            dbutils.jobs.taskValues.set(TaskValueKey.LLM_TEMPERATURE.value, tv.get('llm_temperature'))
            dbutils.jobs.taskValues.set(TaskValueKey.EMBEDDING_PROVISIONLESS.value, tv.get('embedding_provisionless'))
            dbutils.jobs.taskValues.set(TaskValueKey.BASE_PROMPT.value, tv.get('base_prompt'))
            dbutils.jobs.taskValues.set(TaskValueKey.PT_MODELS_CONFIG.value, tv.get('pt_models_config'))
            dbutils.jobs.taskValues.set(TaskValueKey.MODEL_CREATED_BY.value, tv.get('model_created_by'))
            dbutils.jobs.taskValues.set(TaskValueKey.RBAC_OWNER_EMAILS.value, tv.get('rbac_owner_emails'))

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.info(f"Parse entity model JSON failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.error(f"  Error: {error}")
