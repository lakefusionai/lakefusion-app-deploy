"""
Process Crosswalk Task.

Creates the crosswalk view that maps source records to master records.
"""

from typing import Any, Dict, List, Optional

from ...base import BaseTask
from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, ValidationResult


class ProcessCrosswalkTask(BaseStepTask):
    """
    Task to create and validate the crosswalk view.

    The crosswalk view provides a mapping between source system records
    and their corresponding master records, tracking the lineage of
    how records were merged.

    External Override Support:
        Users can provide a ProcessCrosswalkExtended class to customize
        pre_execute() and post_execute() without modifying this core logic.
    """

    def __init__(self, context: TaskContext, override_instance: Any = None):
        """
        Initialize the crosswalk task.

        Args:
            context: TaskContext with entity and catalog configuration
            override_instance: Optional user-provided override class instance
        """
        super().__init__(context, override_instance=override_instance)
        # Instance variables for intermediate results
        self._source_mapping: Dict[str, Dict[str, str]] = {}
        self._stats: Dict[str, Any] = {}
        self._crosswalk_query: str = ""
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """Log task initialization."""
        self.print_header("PROCESS CROSSWALK TASK")
        self.logger.info("PROCESS CROSSWALK TASK")
        self.logger.info(f"Entity: {self.context.entity}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.context.experiment_id or 'None'}")
        self.logger.info(f"Unified Table: {self.context.unified_table}")
        self.logger.info(f"Master Table: {self.context.master_table}")
        self.logger.info(f"Crosswalk View: {self.context.crosswalk_view}")

    @step(order=1, name="Build Source Mapping", returns="source_mapping dict with source paths and metadata")
    def step_build_source_mapping(self) -> Dict[str, Any]:
        """Build mapping from source_path to friendly name and ID column."""
        self._build_source_mapping()
        return {
            'source_count': len(self._source_mapping),
            'source_paths': list(self._source_mapping.keys())
        }

    @step(order=2, name="Create Crosswalk View", returns="crosswalk view name")
    def step_create_crosswalk_view(self) -> Dict[str, Any]:
        """Build and execute the crosswalk query."""
        self._crosswalk_query = self._build_crosswalk_query()
        self.spark.sql(self._crosswalk_query)
        return {
            'crosswalk_view': self.context.crosswalk_view
        }

    @step(order=3, name="Collect Statistics", returns="statistics dict with counts and averages")
    def step_collect_statistics(self) -> Dict[str, Any]:
        """Collect statistics about the crosswalk."""
        self._collect_stats()
        return self._stats.copy()

    def execute(self) -> TaskResult:
        """
        Create the crosswalk view.

        Returns:
            TaskResult with execution status and metrics
        """
        try:
            # Step 1: Build source mapping from dataset objects
            self.step_build_source_mapping()

            # Step 2: Build and execute the crosswalk query
            self.step_create_crosswalk_view()

            # Step 3: Collect statistics
            self.step_collect_statistics()

            return TaskResult.success(
                message=f"Crosswalk view created: {self.context.crosswalk_view}",
                metrics=self._stats,
                artifacts={
                    'crosswalk_view': self.context.crosswalk_view,
                    'unified_table': self.context.unified_table,
                    'master_table': self.context.master_table
                },
                task_values={
                    'crosswalk_complete': True,
                    'unique_masters': self._stats.get('unique_masters', 0),
                    'total_contributions': self._stats.get('total_contributions', 0)
                }
            )

        except Exception as e:
            raise RuntimeError(f"Failed to create crosswalk view: {str(e)}") from e

    def validate(self, result: TaskResult) -> TaskResult:
        """
        Validate the crosswalk view.

        Checks that all master records are represented in the crosswalk.

        Args:
            result: TaskResult from execute()

        Returns:
            TaskResult with validation results added
        """
        if result.is_failed:
            return result

        try:
            master_count = self.spark.sql(
                f"SELECT COUNT(*) as cnt FROM {self.context.master_table}"
            ).collect()[0]['cnt']

            unique_masters = self._stats.get('unique_masters', 0)

            validation = ValidationResult(
                passed=unique_masters == master_count,
                message="All master records represented in crosswalk",
                expected=master_count,
                actual=unique_masters
            )
            result.add_validation(validation)

            if not validation.passed:
                result.status = result.status  # Keep current status
                self.logger.info(f"\nValidation Warning: Master count mismatch!")
                self.logger.info(f"  Master table: {master_count}")
                self.logger.info(f"  Crosswalk unique masters: {unique_masters}")
                self.logger.info(f"  Difference: {abs(master_count - unique_masters)}")

        except Exception as e:
            result.add_validation(ValidationResult(
                passed=False,
                message=f"Validation failed: {str(e)}"
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Print summary and sample data."""
        self._print_validation_results()
        self._print_sample_data()
        self.print_summary(result)

    def on_success(self, result: TaskResult) -> None:
        """Set task values on successful completion."""
        self.dbutils.jobs.taskValues.set("crosswalk_complete", True)
        self.dbutils.jobs.taskValues.set("unique_masters", self._stats.get('unique_masters', 0))
        self.dbutils.jobs.taskValues.set("total_contributions", self._stats.get('total_contributions', 0))

    def _build_source_mapping(self) -> None:
        """Build mapping from source_path to friendly name and ID column."""
        self.print_header("CREATING SOURCE SYSTEM MAPPING")

        for dataset_id, dataset_info in self.context.dataset_objects.items():
            source_path = dataset_info.get('path', '')
            source_name = dataset_info.get('name', source_path)
            id_column = dataset_info.get('id', 'id')

            self._source_mapping[source_path] = {
                'name': source_name,
                'id_column': id_column,
                'path': source_path
            }

        self.logger.info(f"Created mapping for {len(self._source_mapping)} source systems:")
        for path, info in self._source_mapping.items():
            self.logger.info(f"  {path}")
            self.logger.info(f"    Name: {info['name']}")
            self.logger.info(f"    ID Column: {info['id_column']}")

    def _build_values_clause(self) -> str:
        """Build the VALUES clause for source mapping."""
        values = []
        for path, info in self._source_mapping.items():
            escaped_path = path.replace("'", "''")
            escaped_name = info['name'].replace("'", "''")
            escaped_id = str(info['id_column']).replace("'", "''")
            values.append(f"('{escaped_path}', '{escaped_name}', '{escaped_id}')")
        return ",\n        ".join(values)

    def _build_crosswalk_query(self) -> str:
        """Build the complete crosswalk SQL query."""
        self.print_header("BUILDING CROSSWALK QUERY")

        values_clause = self._build_values_clause()

        query = f"""
CREATE OR REPLACE VIEW {self.context.crosswalk_view} AS
WITH source_system_mapping AS (
    -- Mapping of source paths to friendly names and ID columns
    SELECT
        source_path,
        source_name,
        id_column_name
    FROM VALUES
        {values_clause}
    AS t(source_path, source_name, id_column_name)
),
master_merge_chain AS (
    -- Build mapping of merged masters to their survivors
    -- This helps trace contributors through master merges
    SELECT DISTINCT
        ma.match_id as old_master_id,
        ma.master_id as final_master_id,
        ma.action_type as merge_type,
        ma.version as merge_version,
        ma.created_at as merge_timestamp
    FROM {self.context.merge_activities_table} ma
    WHERE ma.action_type IN ('MASTER_JOB_MERGE', 'MASTER_MANUAL_MERGE','MASTER_FORCE_MERGE')
),
unified_contributors AS (
    -- Get all MERGED records from unified table
    -- These are the actual source records that contribute to masters
    SELECT
        u.master_lakefusion_id as lakefusion_id,
        u.source_path,
        u.source_id,
        u.surrogate_key,
        u.record_status
    FROM {self.context.unified_table} u
    WHERE u.record_status = 'MERGED'
        AND u.master_lakefusion_id IS NOT NULL
),
merge_activity_direct AS (
    -- Get merge activity for direct contributors (normal merge/insert)
    SELECT
        ma.master_id as lakefusion_id,
        ma.match_id as surrogate_key,
        ma.source as source_path,
        ma.action_type as merge_activity_id,
        ma.version,
        ma.created_at,
        'DIRECT' as match_type
    FROM {self.context.merge_activities_table} ma
    WHERE ma.action_type IN ('INITIAL_LOAD', 'JOB_MERGE', 'JOB_INSERT', 'MANUAL_MERGE')
        AND ma.master_id IS NOT NULL
        AND ma.match_id IS NOT NULL
),
merge_activity_inherited AS (
    -- Get merge activity for contributors inherited through master merges
    -- These are contributors that belonged to a merged master
    SELECT
        mmc.final_master_id as lakefusion_id,
        ma.match_id as surrogate_key,
        ma.source as source_path,
        ma.action_type as merge_activity_id,
        ma.version,
        ma.created_at,
        'INHERITED' as match_type
    FROM {self.context.merge_activities_table} ma
    INNER JOIN master_merge_chain mmc
        ON ma.master_id = mmc.old_master_id
    WHERE ma.action_type IN ('INITIAL_LOAD', 'JOB_MERGE', 'JOB_INSERT', 'MANUAL_MERGE')
        AND ma.master_id IS NOT NULL
        AND ma.match_id IS NOT NULL
),
merge_activity_combined AS (
    -- Combine direct and inherited, prioritizing direct matches
    SELECT
        lakefusion_id,
        surrogate_key,
        source_path,
        merge_activity_id,
        version,
        created_at,
        match_type,
        ROW_NUMBER() OVER (
            PARTITION BY lakefusion_id, surrogate_key
            ORDER BY
                CASE match_type
                    WHEN 'DIRECT' THEN 1
                    WHEN 'INHERITED' THEN 2
                END,
                version DESC
        ) as rn
    FROM (
        SELECT * FROM merge_activity_direct
        UNION ALL
        SELECT * FROM merge_activity_inherited
    )
),
merge_activity_metadata AS (
    -- Get the best match for each contributor
    SELECT
        lakefusion_id,
        surrogate_key,
        source_path,
        merge_activity_id,
        version,
        created_at
    FROM merge_activity_combined
    WHERE rn = 1
),
master_history AS (
    -- Get timestamp for each master table version
    SELECT
        version,
        timestamp as created_timestamp
    FROM (DESCRIBE HISTORY {self.context.master_table})
),
crosswalk_data AS (
    -- Join everything together
    SELECT
        uc.lakefusion_id,
        COALESCE(ssm.source_name, uc.source_path) as source_system_name,
        uc.source_path as source_table_name,
        uc.source_id as source_record_id,
        mam.merge_activity_id,
        COALESCE(mam.created_at, mh.created_timestamp) as created_timestamp,
        mam.version,
        ROW_NUMBER() OVER (
            PARTITION BY uc.lakefusion_id, uc.source_path, uc.source_id
            ORDER BY COALESCE(mam.version, 0) DESC
        ) as rn
    FROM unified_contributors uc
    LEFT JOIN source_system_mapping ssm
        ON uc.source_path = ssm.source_path
    LEFT JOIN merge_activity_metadata mam
        ON uc.lakefusion_id = mam.lakefusion_id
        AND uc.surrogate_key = mam.surrogate_key
    LEFT JOIN master_history mh
        ON mam.version = mh.version
)
SELECT
    lakefusion_id,
    source_system_name,
    source_table_name,
    source_record_id,
    merge_activity_id,
    created_timestamp
FROM crosswalk_data
WHERE rn = 1
ORDER BY lakefusion_id, created_timestamp DESC
"""
        self.logger.info("Query built successfully")
        return query

    def _collect_stats(self) -> None:
        """Collect statistics about the crosswalk."""
        self.print_header("COLLECTING STATISTICS")

        stats_query = f"""
SELECT
    COUNT(DISTINCT lakefusion_id) as unique_masters,
    COUNT(*) as total_contributions,
    AVG(contributions_per_master) as avg_contributions_per_master
FROM (
    SELECT
        lakefusion_id,
        COUNT(*) as contributions_per_master
    FROM {self.context.crosswalk_view}
    GROUP BY lakefusion_id
)
"""
        stats = self.spark.sql(stats_query).collect()[0]

        unique_sources = self.spark.sql(f"""
            SELECT COUNT(DISTINCT source_table_name) as cnt
            FROM {self.context.crosswalk_view}
        """).collect()[0]['cnt']

        self._stats = {
            'unique_masters': int(stats['unique_masters']),
            'total_contributions': int(stats['total_contributions']),
            'avg_contributions_per_master': float(stats['avg_contributions_per_master'] or 0),
            'unique_sources': int(unique_sources)
        }

        self.logger.info(f"Unique masters: {self._stats['unique_masters']}")
        self.logger.info(f"Total contributions: {self._stats['total_contributions']}")
        self.logger.info(f"Unique sources: {self._stats['unique_sources']}")
        self.logger.info(f"Avg contributions per master: {self._stats['avg_contributions_per_master']:.2f}")

    def _print_validation_results(self) -> None:
        """Print validation results."""
        self.print_header("VALIDATING CROSSWALK")

        master_count = self.spark.sql(
            f"SELECT COUNT(*) as cnt FROM {self.context.master_table}"
        ).collect()[0]['cnt']

        self.logger.info(f"\nValidation Results:")
        self.logger.info(f"  Master table records: {master_count}")
        self.logger.info(f"  Unique masters in crosswalk: {self._stats.get('unique_masters', 0)}")
        self.logger.info(f"  Total source contributions: {self._stats.get('total_contributions', 0)}")
        self.logger.info(f"  Unique source systems: {self._stats.get('unique_sources', 0)}")
        self.logger.info(f"  Average contributions per master: {self._stats.get('avg_contributions_per_master', 0):.2f}")

        if self._stats.get('unique_masters', 0) == master_count:
            self.logger.info(f"\nVALIDATION PASSED: All master records represented in crosswalk")
        else:
            self.logger.info(f"\nVALIDATION WARNING: Master count mismatch!")
            self.logger.info(f"   Master table: {master_count}")
            self.logger.info(f"   Crosswalk unique masters: {self._stats.get('unique_masters', 0)}")
            self.logger.info(f"   Difference: {abs(master_count - self._stats.get('unique_masters', 0))}")

    def _print_sample_data(self) -> None:
        """Print sample data from the crosswalk."""
        self.print_header("SAMPLE CROSSWALK DATA")

        self.logger.info("Contributions by source system:")
        self.spark.sql(f"""
            SELECT
                source_system_name,
                COUNT(*) as contribution_count,
                COUNT(DISTINCT lakefusion_id) as unique_masters
            FROM {self.context.crosswalk_view}
            GROUP BY source_system_name
            ORDER BY contribution_count DESC
        """).show(truncate=False)

        self.logger.info("Contributions by merge activity type:")
        self.spark.sql(f"""
            SELECT
                merge_activity_id,
                COUNT(*) as contribution_count,
                COUNT(DISTINCT lakefusion_id) as unique_masters
            FROM {self.context.crosswalk_view}
            GROUP BY merge_activity_id
            ORDER BY contribution_count DESC
        """).show(truncate=False)
