"""
Embedding Foundational Executor for Maven Core.

Creates or validates a model serving endpoint for Databricks Foundational
embedding models.

Workflow:
1. Get embedding model name from task values or params
2. Look up the served entity path from model mappings
3. Check if endpoint already exists
4. Create serving endpoint if it doesn't exist
5. Set task values for downstream tasks
"""

import json
from typing import Any, Dict, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class EmbeddingFoundationalExecutor(BaseStepTask):
    """
    Executor for deploying Databricks Foundational embedding models.

    Creates a model serving endpoint for foundational embedding models
    using the Databricks serving infrastructure. Supports both
    provisioned and provisionless (pay-per-token) configurations.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.embedding_model = ""
        self.embedding_provisionless = False
        self.served_entity = ""
        self.embedding_endpoint_name = ""
        self.endpoint_exists = False
        self.pt_models_config = {}
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    @property
    def is_provisionless(self) -> bool:
        """Check if using provisionless (pay-per-token) mode."""
        value = self.context.params.get('embedding_provisionless', False)
        if isinstance(value, str):
            return value.lower() == 'true'
        return bool(value)

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        # Get embedding model from params
        self.embedding_model = self.context.params.get('embedding_model', '')
        self.embedding_provisionless = self.is_provisionless

        self.logger.info("="*60)
        self.logger.info("EMBEDDING FOUNDATIONAL")
        self.logger.info("="*60)
        self.logger.info(f"Embedding Model: {self.embedding_model}")
        self.logger.info(f"Provisionless: {self.embedding_provisionless}")

        if not self.embedding_model:
            raise ValueError("embedding_model is required in params")

        # Resolve served entity name via SDK
        from lakefusion_core_engine.utils.model_serving import resolve_entity_name

        self.served_entity = resolve_entity_name(self.embedding_model)
        self.logger.info(f"Served Entity: {self.served_entity}")

        # Load PT models config from task values
        pt_models_config_str = self.context.params.get('pt_models_config', '{}')
        self.pt_models_config = json.loads(pt_models_config_str)
        self.logger.info(f"Loaded PT config for {len(self.pt_models_config)} models")

        # Compute endpoint name based on provisionless setting
        if self.embedding_provisionless:
            self.embedding_endpoint_name = self.embedding_model
        else:
            self.embedding_endpoint_name = f"lakefusion-{self.embedding_model}"

        self.logger.info(f"Endpoint Name: {self.embedding_endpoint_name}")
        self.logger.info("="*60)

    @step(order=1, name="Check Endpoint Exists", returns="endpoint_exists flag or provisionless status")
    def step_check_endpoint_exists(self) -> Dict[str, Any]:
        """Check if the serving endpoint already exists (or skip if provisionless)."""
        if self.embedding_provisionless:
            self.logger.info(f"  Using provisionless endpoint: {self.embedding_endpoint_name}")
            self.logger.info("  No endpoint existence check required.")
            return {
                'provisionless': True,
                'endpoint_name': self.embedding_endpoint_name,
                'endpoint_exists': True  # Provisionless endpoints always "exist"
            }

        from lakefusion_core_engine.utils.model_serving import check_and_cleanup_failed_endpoint

        should_create = check_and_cleanup_failed_endpoint(self.embedding_endpoint_name)
        self.endpoint_exists = not should_create

        if self.endpoint_exists:
            self.logger.info(f"  Endpoint '{self.embedding_endpoint_name}' already exists and is healthy")
        else:
            self.logger.info(f"  Endpoint '{self.embedding_endpoint_name}' needs to be created")

        return {
            'provisionless': False,
            'endpoint_exists': self.endpoint_exists,
            'endpoint_name': self.embedding_endpoint_name
        }

    @step(order=2, name="Create Endpoint", returns="endpoint creation status")
    def step_create_endpoint(self) -> Dict[str, Any]:
        """Create the model serving endpoint if needed."""
        if self.embedding_provisionless:
            self.logger.info("  Provisionless mode - no endpoint creation required.")
            return {
                'endpoint_created': False,
                'endpoint_name': self.embedding_endpoint_name,
                'reason': 'provisionless_mode'
            }

        if self.endpoint_exists:
            self.logger.info("  Endpoint already exists, skipping creation.")
            return {
                'endpoint_created': False,
                'endpoint_name': self.embedding_endpoint_name,
                'reason': 'already_exists'
            }

        from lakefusion_core_engine.utils.model_serving import create_serving_endpoint_foundational

        # Get PT config for this model
        pt_config = self.pt_models_config.get(self.served_entity)
        if pt_config:
            self.logger.info(f"  PT config found for {self.served_entity}: {pt_config}")
        else:
            # No PT config → fall back to pay-per-token (provisionless) mode
            self.logger.info(f"  WARNING: No PT config found for {self.served_entity}.")
            self.logger.info(f"  Falling back to pay-per-token mode without provisioned throughput.")
            self.embedding_provisionless = True
            self.embedding_endpoint_name = self.embedding_model  # Remove lakefusion- prefix
            self.logger.info(f"  Updated endpoint name to: {self.embedding_endpoint_name}")
            return {
                'endpoint_created': False,
                'endpoint_name': self.embedding_endpoint_name,
                'reason': 'no_pt_config_fallback_to_pay_per_token'
            }

        create_serving_endpoint_foundational(
            endpoint_name=self.embedding_endpoint_name,
            serving_entity=self.served_entity,
            pt_config=pt_config
        )

        self.logger.info(f"  Endpoint '{self.embedding_endpoint_name}' created successfully")
        return {
            'endpoint_created': True,
            'endpoint_name': self.embedding_endpoint_name
        }

    def execute(self) -> TaskResult:
        """Execute the embedding foundational deployment workflow."""
        try:
            self.logger.info(f"Starting embedding foundational deployment for model '{self.embedding_model}' (mode: {'provisionless' if self.embedding_provisionless else 'provisioned'})")

            # Step 1: Check if endpoint exists
            self.step_check_endpoint_exists()

            # Step 2: Create endpoint if needed
            self.step_create_endpoint()

            self.logger.info(f"Embedding foundational deployment completed successfully — endpoint '{self.embedding_endpoint_name}' is ready")
            return TaskResult.success(
                message=f"Embedding endpoint '{self.embedding_endpoint_name}' ready",
                task_name=self.context.task_name,
                metrics={
                    'provisionless': self.embedding_provisionless,
                    'endpoint_created': not self.embedding_provisionless and not self.endpoint_exists,
                    'endpoint_name': self.embedding_endpoint_name
                },
                task_values={
                    'served_entity': self.served_entity,
                    'embedding_model_endpoint': self.embedding_endpoint_name
                }
            )

        except Exception as e:
            error_msg = f"Failed to deploy embedding foundational endpoint: {str(e)}"
            self.logger.error(error_msg)
            raise RuntimeError(error_msg) from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        if not self.embedding_endpoint_name:
            result.add_validation(ValidationResult(
                passed=False,
                message="Embedding endpoint name is empty",
                actual=self.embedding_endpoint_name
            ))
        else:
            result.add_validation(ValidationResult(
                passed=True,
                message="Embedding endpoint configured",
                actual=self.embedding_endpoint_name
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*60)
        self.logger.info("EMBEDDING FOUNDATIONAL - COMPLETE")
        self.logger.info("="*60)

        if result.is_success:
            self.logger.info(f"\n  Summary:")
            self.logger.info(f"    Served Entity: {self.served_entity}")
            self.logger.info(f"    Embedding Endpoint: {self.embedding_endpoint_name}")
            self.logger.info(f"    Mode: {'Provisionless' if self.embedding_provisionless else 'Provisioned'}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Embedding foundational deployment failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.error(f"  Error: {error}")
