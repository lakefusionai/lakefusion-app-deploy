"""
Embedding Hugging Face Executor for Maven Core.

Registers and deploys a Hugging Face embedding model as a model serving endpoint.

Workflow:
1. Get embedding model name from task values or params
2. Check if model is already registered in Unity Catalog
3. If not registered, download and register the model using MLflow
4. Check if serving endpoint exists
5. Create serving endpoint if it doesn't exist
6. Set task values for downstream tasks
"""

from typing import Any, Dict, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class EmbeddingHuggingFaceExecutor(BaseStepTask):
    """
    Executor for deploying Hugging Face embedding models.

    Downloads, registers, and deploys Hugging Face embedding models
    as model serving endpoints in Databricks.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.embedding_model = ""
        self.catalog_name = ""
        self.embedding_endpoint_name = ""
        self.mlflow_model_name = ""
        self.latest_version = ""
        self.endpoint_exists = False
        self.model_registered = False
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        # Get params
        self.embedding_model = self.context.params.get('embedding_model', '')
        self.catalog_name = self.context.params.get('catalog_name', '')

        self.logger.info("="*60)
        self.logger.info("EMBEDDING HUGGING FACE")
        self.logger.info("="*60)
        self.logger.info(f"Embedding Model: {self.embedding_model}")
        self.logger.info(f"Catalog Name: {self.catalog_name}")

        if not self.embedding_model:
            raise ValueError("embedding_model is required in params")
        if not self.catalog_name:
            raise ValueError("catalog_name is required in params")

        # Compute endpoint name and MLflow model name
        # Sanitize: replace / with -, . with _, and lowercase for UC compatibility
        sanitized = self.embedding_model.replace('/', '-').replace('.', '_').lower()
        self.embedding_endpoint_name = sanitized
        self.mlflow_model_name = f"{self.catalog_name}.embedding.{sanitized}"

        self.logger.info(f"Endpoint Name: {self.embedding_endpoint_name}")
        self.logger.info(f"MLflow Model Name: {self.mlflow_model_name}")
        self.logger.info("="*60)

    @step(order=1, name="Register Model in Unity Catalog", returns="model registration status and version")
    def step_register_model(self) -> Dict[str, Any]:
        """Check if model exists in UC, register if not."""
        import mlflow
        mlflow.set_registry_uri("databricks-uc")

        try:
            client = mlflow.MlflowClient()
            get_model = client.get_registered_model(self.mlflow_model_name)
            versions = client.search_model_versions(f"name='{self.mlflow_model_name}'")
            self.latest_version = max(versions, key=lambda mv: int(mv.version)).version
            self.model_registered = True
            self.logger.info(f"  Model already registered: {self.mlflow_model_name}")
            self.logger.info(f"  Latest version: {self.latest_version}")

            return {
                'model_registered': True,
                'model_name': self.mlflow_model_name,
                'latest_version': self.latest_version,
                'newly_registered': False
            }

        except Exception as err:
            if "RESOURCE_DOES_NOT_EXIST" in str(err):
                self.logger.info(f"  Model not found, registering: {self.mlflow_model_name}")
                self._register_new_model()
                self.model_registered = True
                return {
                    'model_registered': True,
                    'model_name': self.mlflow_model_name,
                    'latest_version': self.latest_version,
                    'newly_registered': True
                }
            else:
                self.logger.info(f"  Error checking model: {str(err)}")
                raise

    def _register_new_model(self) -> None:
        """Register a new Hugging Face embedding model."""
        import mlflow
        from sentence_transformers import SentenceTransformer

        # Get resource tags
        try:
            from lakefusion_core_engine.utils.parse_utils import get_resource_tags, apply_tags_to_uc_resource
            tags = get_resource_tags() or {}
        except Exception:
            tags = {}

        model_path = self.embedding_model.replace("/", "-").replace(".", "_").lower()
        artifact_path = model_path

        self.logger.info(f"  Downloading model: {self.embedding_model}")
        try:
            model = SentenceTransformer(self.embedding_model)
        except Exception as e:
            raise RuntimeError(
                f"Failed to download/load HuggingFace embedding model '{self.embedding_model}': {str(e)}"
            ) from e

        self.logger.info(f"  Logging model to MLflow...")
        try:
            with mlflow.start_run():
                model_info = mlflow.sentence_transformers.log_model(
                    model=model,
                    artifact_path=artifact_path,
                    input_example="The capital of France is",
                    registered_model_name=self.mlflow_model_name,
                    pip_requirements=[
                        "mlflow>=2.0", "torch>=2.0", "transformers>=4.51.0,<5.0.0",
                        "accelerate>=1.12.0", "torchvision", "sentence_transformers"
                    ],
                )
        except Exception as e:
            raise RuntimeError(
                f"Failed to register embedding model '{self.mlflow_model_name}' in MLflow: {str(e)}"
            ) from e

        # Resource Tagging
        if tags:
            try:
                apply_tags_to_uc_resource(self.context.spark, "models", self.mlflow_model_name, tags)
                self.logger.info(f"  Applied resource tags to model")
            except Exception as e:
                self.logger.info(f"  Warning: Could not apply tags: {str(e)}")

        self.latest_version = model_info.registered_model_version
        self.logger.info(f"  Model registered successfully, version: {self.latest_version}")

    @step(order=2, name="Check Endpoint Exists", returns="endpoint_exists flag")
    def step_check_endpoint_exists(self) -> Dict[str, Any]:
        """Check if the serving endpoint already exists and is healthy."""
        from lakefusion_core_engine.utils.model_serving import check_and_cleanup_failed_endpoint

        should_create = check_and_cleanup_failed_endpoint(self.embedding_endpoint_name)
        self.endpoint_exists = not should_create

        if self.endpoint_exists:
            self.logger.info(f"  Endpoint '{self.embedding_endpoint_name}' already exists and is healthy")
        else:
            self.logger.info(f"  Endpoint '{self.embedding_endpoint_name}' needs to be created")

        return {
            'endpoint_exists': self.endpoint_exists,
            'endpoint_name': self.embedding_endpoint_name
        }

    @step(order=3, name="Create Endpoint", returns="endpoint creation status")
    def step_create_endpoint(self) -> Dict[str, Any]:
        """Create the model serving endpoint if it doesn't exist."""
        if self.endpoint_exists:
            self.logger.info("  Endpoint already exists and is healthy, skipping creation.")
            return {
                'endpoint_created': False,
                'endpoint_name': self.embedding_endpoint_name
            }

        from lakefusion_core_engine.utils.model_serving import create_serving_endpoint

        try:
            endpoint = create_serving_endpoint(
                self.embedding_endpoint_name,
                self.mlflow_model_name,
                entity_version=self.latest_version,
            )
            self.logger.info(f"  Endpoint '{self.embedding_endpoint_name}' is ready")
            return {
                'endpoint_created': True,
                'endpoint_name': self.embedding_endpoint_name
            }
        except Exception as e:
            raise RuntimeError(
                f"Failed to create serving endpoint '{self.embedding_endpoint_name}': {str(e)}"
            ) from e

    def execute(self) -> TaskResult:
        """Execute the embedding Hugging Face deployment workflow."""
        try:
            # Step 1: Check/Register model in Unity Catalog
            self.step_register_model()

            # Step 2: Check if endpoint exists
            self.step_check_endpoint_exists()

            # Step 3: Create endpoint if needed
            self.step_create_endpoint()

            return TaskResult.success(
                message=f"Embedding HuggingFace endpoint '{self.embedding_endpoint_name}' ready",
                task_name=self.context.task_name,
                metrics={
                    'endpoint_created': not self.endpoint_exists,
                    'endpoint_name': self.embedding_endpoint_name,
                    'model_version': self.latest_version
                },
                task_values={
                    'served_entity': self.mlflow_model_name,
                    'served_entity_version': self.latest_version,
                    'embedding_model_endpoint': self.embedding_endpoint_name
                }
            )

        except Exception as e:
            error_msg = f"Failed to deploy embedding HuggingFace endpoint: {str(e)}"
            self.logger.info(f"ERROR: {error_msg}")
            raise RuntimeError(error_msg) from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        if not self.embedding_endpoint_name:
            result.add_validation(ValidationResult(
                passed=False,
                message="Embedding endpoint name is empty",
                actual=self.embedding_endpoint_name
            ))
        else:
            result.add_validation(ValidationResult(
                passed=True,
                message="Embedding endpoint configured",
                actual=self.embedding_endpoint_name
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*60)
        self.logger.info("EMBEDDING HUGGING FACE - COMPLETE")
        self.logger.info("="*60)

        if result.is_success:
            self.logger.info(f"\n  Summary:")
            self.logger.info(f"    Served Entity: {self.mlflow_model_name}")
            self.logger.info(f"    Model Version: {self.latest_version}")
            self.logger.info(f"    Embedding Endpoint: {self.embedding_endpoint_name}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Embedding Hugging Face deployment failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.error(f"  Error: {error}")