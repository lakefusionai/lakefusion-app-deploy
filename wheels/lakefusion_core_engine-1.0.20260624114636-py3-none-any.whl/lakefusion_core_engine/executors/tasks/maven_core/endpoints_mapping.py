"""
Endpoints Mapping Executor for Maven Core.

Maps model names to endpoint names based on the model source configuration.
This is the Maven Core version which has the same logic as the integration core
version but is scoped to the Maven Core pipeline context.

Workflow:
1. Get embedding model and source
2. Get LLM model and source
3. Compute endpoint names based on source type and provisionless setting
4. Set task values for downstream tasks
"""

from typing import Any, Dict, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class MavenEndpointsMappingExecutor(BaseStepTask):
    """
    Executor for mapping model names to endpoint names in Maven Core.

    Computes endpoint names based on model source (databricks_foundation,
    databricks_custom_hugging_face) and provisionless settings.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.embedding_endpoint_name = ""
        self.llm_endpoint_name = ""
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    @property
    def embedding_model(self) -> str:
        """Get the embedding model name from params."""
        return self.context.params.get('embedding_model', '')

    @property
    def embedding_model_source(self) -> str:
        """Get the embedding model source from params."""
        return self.context.params.get('embedding_model_source', 'databricks_foundation')

    @property
    def llm_model(self) -> str:
        """Get the LLM model name from params."""
        return self.context.params.get('llm_model', '')

    @property
    def llm_model_source(self) -> str:
        """Get the LLM model source from params."""
        return self.context.params.get('llm_model_source', 'databricks_foundation')

    @property
    def llm_provisionless(self) -> bool:
        """Get the LLM provisionless setting from params."""
        value = self.context.params.get('llm_provisionless', False)
        if isinstance(value, str):
            return value.lower() == 'true'
        return bool(value)

    @property
    def embedding_provisionless(self) -> bool:
        """Get the embedding provisionless setting from params."""
        value = self.context.params.get('embedding_provisionless', False)
        if isinstance(value, str):
            return value.lower() == 'true'
        return bool(value)

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        self.logger.info("="*60)
        self.logger.info("MAVEN ENDPOINTS MAPPING")
        self.logger.info("="*60)
        self.logger.info(f"Embedding Model: {self.embedding_model}")
        self.logger.info(f"Embedding Model Source: {self.embedding_model_source}")
        self.logger.info(f"Embedding Provisionless: {self.embedding_provisionless}")
        self.logger.info(f"LLM Model: {self.llm_model}")
        self.logger.info(f"LLM Model Source: {self.llm_model_source}")
        self.logger.info(f"LLM Provisionless: {self.llm_provisionless}")
        self.logger.info("="*60)

    @step(order=1, name="Compute Embedding Endpoint", returns="str - embedding endpoint name")
    def step_compute_embedding_endpoint(self) -> Dict[str, Any]:
        """Compute the embedding endpoint name based on source configuration."""
        from lakefusion_core_engine.utils.model_serving import is_endpoint_healthy

        if self.embedding_model_source == 'databricks_foundation':
            if self.embedding_provisionless:
                self.embedding_endpoint_name = self.embedding_model
            else:
                pt_endpoint = f"lakefusion-{self.embedding_model}"
                if is_endpoint_healthy(pt_endpoint):
                    self.embedding_endpoint_name = pt_endpoint
                else:
                    self.logger.info(f"  PT endpoint '{pt_endpoint}' not found or failed — falling back to pay-per-token")
                    self.embedding_endpoint_name = self.embedding_model
        elif self.embedding_model_source == 'databricks_custom_hugging_face':
            self.embedding_endpoint_name = self.embedding_model.replace('/', '-').replace('.', '_').lower()
        else:
            self.embedding_endpoint_name = self.embedding_model

        self.logger.info(f"  Embedding Model Source: {self.embedding_model_source}")
        self.logger.info(f"  Embedding Provisionless: {self.embedding_provisionless}")
        self.logger.info(f"  Embedding Endpoint: {self.embedding_endpoint_name}")

        return {'embedding_endpoint': self.embedding_endpoint_name}

    @step(order=2, name="Compute LLM Endpoint", returns="str - LLM endpoint name")
    def step_compute_llm_endpoint(self) -> Dict[str, Any]:
        """Compute the LLM endpoint name based on source configuration."""
        from lakefusion_core_engine.utils.model_serving import is_endpoint_healthy

        if self.llm_model_source == 'databricks_foundation':
            if self.llm_provisionless:
                self.llm_endpoint_name = self.llm_model
            else:
                pt_endpoint = f"lakefusion-{self.llm_model}"
                if is_endpoint_healthy(pt_endpoint):
                    self.llm_endpoint_name = pt_endpoint
                else:
                    self.logger.info(f"  PT endpoint '{pt_endpoint}' not found or failed — falling back to pay-per-token")
                    self.llm_endpoint_name = self.llm_model
        elif self.llm_model_source == 'databricks_custom_hugging_face':
            self.llm_endpoint_name = self.llm_model.replace('/', '-').replace('.', '_').lower()
        else:
            self.llm_endpoint_name = self.llm_model

        self.logger.info(f"  LLM Model Source: {self.llm_model_source}")
        self.logger.info(f"  LLM Provisionless: {self.llm_provisionless}")
        self.logger.info(f"  LLM Endpoint: {self.llm_endpoint_name}")

        return {'llm_endpoint': self.llm_endpoint_name}

    def execute(self) -> TaskResult:
        """Execute the endpoints mapping workflow."""
        self.logger.info("\n" + "="*60)
        self.logger.info("COMPUTING ENDPOINT NAMES")
        self.logger.info("="*60)

        # Execute steps in sequence
        self.step_compute_embedding_endpoint()
        self.step_compute_llm_endpoint()

        return TaskResult.success(
            message=f"Endpoints mapped successfully",
            task_name=self.context.task_name,
            metrics={
                'embedding_endpoint': self.embedding_endpoint_name,
                'llm_endpoint': self.llm_endpoint_name
            },
            task_values={
                'embedding_model_endpoint': self.embedding_endpoint_name,
                'llm_model_endpoint': self.llm_endpoint_name
            }
        )

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        # Validate endpoints are not empty
        if not self.embedding_endpoint_name:
            result.add_validation(ValidationResult(
                passed=False,
                message="Embedding endpoint name is empty",
                actual=self.embedding_endpoint_name
            ))
        else:
            result.add_validation(ValidationResult(
                passed=True,
                message="Embedding endpoint mapped",
                actual=self.embedding_endpoint_name
            ))

        if not self.llm_endpoint_name:
            result.add_validation(ValidationResult(
                passed=False,
                message="LLM endpoint name is empty",
                actual=self.llm_endpoint_name
            ))
        else:
            result.add_validation(ValidationResult(
                passed=True,
                message="LLM endpoint mapped",
                actual=self.llm_endpoint_name
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*60)
        self.logger.info("MAVEN ENDPOINTS MAPPING - COMPLETE")
        self.logger.info("="*60)

        if result.is_success:
            self.logger.info(f"\n  Summary:")
            self.logger.info(f"    Embedding Model Endpoint: {self.embedding_endpoint_name}")
            self.logger.info(f"    LLM Model Endpoint: {self.llm_endpoint_name}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Maven endpoints mapping failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.error(f"  Error: {error}")
