"""
LLM Foundational Executor for Maven Core.

Creates or validates a model serving endpoint for Databricks Foundational
LLM models.

Workflow:
1. Get LLM model name and provisionless setting from task values or params
2. Look up the served entity path from model mappings
3. If not provisionless, check if endpoint already exists
4. Create serving endpoint if it doesn't exist (non-provisionless only)
5. Set task values for downstream tasks
"""

import json
from typing import Any, Dict, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class LLMFoundationalExecutor(BaseStepTask):
    """
    Executor for deploying Databricks Foundational LLM models.

    Creates a model serving endpoint for foundational LLM models
    using the Databricks serving infrastructure. Supports both
    provisioned and provisionless (pay-per-token) configurations.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.llm_model = ""
        self.llm_provisionless = False
        self.served_entity = ""
        self.llm_endpoint_name = ""
        self.endpoint_exists = False
        self.llm_temperature = 0.0
        self.pt_models_config = {}
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    @property
    def is_provisionless(self) -> bool:
        """Check if using provisionless (pay-per-token) mode."""
        value = self.context.params.get('llm_provisionless', False)
        if isinstance(value, str):
            return value.lower() == 'true'
        return bool(value)

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        # Get LLM model from params
        self.llm_model = self.context.params.get('llm_model', '')
        self.llm_provisionless = self.is_provisionless
        self.llm_temperature = float(self.context.params.get('llm_temperature', 0.0))

        self.logger.info("="*60)
        self.logger.info("LLM FOUNDATIONAL")
        self.logger.info("="*60)
        self.logger.info(f"LLM Model: {self.llm_model}")
        self.logger.info(f"Provisionless: {self.llm_provisionless}")
        self.logger.info(f"LLM Temperature: {self.llm_temperature}")

        if not self.llm_model:
            raise ValueError("llm_model is required in params")

        # Resolve served entity name via SDK
        from lakefusion_core_engine.utils.model_serving import resolve_entity_name

        self.served_entity = resolve_entity_name(self.llm_model)
        self.logger.info(f"Served Entity: {self.served_entity}")

        # Load PT models config from task values
        pt_models_config_str = self.context.params.get('pt_models_config', '{}')
        self.pt_models_config = json.loads(pt_models_config_str)
        self.logger.info(f"Loaded PT config for {len(self.pt_models_config)} models")

        # Compute endpoint name based on provisionless setting
        if self.llm_provisionless:
            self.llm_endpoint_name = self.llm_model
        else:
            self.llm_endpoint_name = f"lakefusion-{self.llm_model}"

        self.logger.info(f"Endpoint Name: {self.llm_endpoint_name}")
        self.logger.info("="*60)

    @step(order=1, name="Check Endpoint Exists", returns="endpoint_exists flag or provisionless status")
    def step_check_endpoint_exists(self) -> Dict[str, Any]:
        """Check if the serving endpoint already exists (or skip if provisionless)."""
        if self.llm_provisionless:
            self.logger.info(f"  Using provisionless endpoint: {self.llm_endpoint_name}")
            self.logger.info("  No endpoint existence check required.")
            return {
                'provisionless': True,
                'endpoint_name': self.llm_endpoint_name,
                'endpoint_exists': True  # Provisionless endpoints always "exist"
            }

        from lakefusion_core_engine.utils.model_serving import check_and_cleanup_failed_endpoint

        should_create = check_and_cleanup_failed_endpoint(self.llm_endpoint_name)
        self.endpoint_exists = not should_create

        if self.endpoint_exists:
            self.logger.info(f"  Endpoint '{self.llm_endpoint_name}' already exists and is healthy")
        else:
            self.logger.info(f"  Endpoint '{self.llm_endpoint_name}' needs to be created")

        return {
            'provisionless': False,
            'endpoint_exists': self.endpoint_exists,
            'endpoint_name': self.llm_endpoint_name
        }

    @step(order=2, name="Create Endpoint", returns="endpoint creation status")
    def step_create_endpoint(self) -> Dict[str, Any]:
        """Create the model serving endpoint if needed."""
        if self.llm_provisionless:
            self.logger.info("  Provisionless mode - no endpoint creation required.")
            return {
                'endpoint_created': False,
                'endpoint_name': self.llm_endpoint_name,
                'reason': 'provisionless_mode'
            }

        if self.endpoint_exists:
            self.logger.info("  Endpoint already exists, skipping creation.")
            return {
                'endpoint_created': False,
                'endpoint_name': self.llm_endpoint_name,
                'reason': 'already_exists'
            }

        from lakefusion_core_engine.utils.model_serving import create_serving_endpoint_foundational

        # Get PT config for this model
        pt_config = self.pt_models_config.get(self.served_entity)
        if pt_config:
            self.logger.info(f"  PT config found for {self.served_entity}: {pt_config}")
        else:
            # No PT config → fall back to pay-per-token (provisionless) mode
            self.logger.info(f"  WARNING: No PT config found for {self.served_entity}.")
            self.logger.info(f"  Falling back to pay-per-token mode without provisioned throughput.")
            self.llm_provisionless = True
            self.llm_endpoint_name = self.llm_model  # Remove lakefusion- prefix
            self.logger.info(f"  Updated endpoint name to: {self.llm_endpoint_name}")
            return {
                'endpoint_created': False,
                'endpoint_name': self.llm_endpoint_name,
                'reason': 'no_pt_config_fallback_to_pay_per_token'
            }

        create_serving_endpoint_foundational(
            endpoint_name=self.llm_endpoint_name,
            serving_entity=self.served_entity,
            pt_config=pt_config
        )

        self.logger.info(f"  Endpoint '{self.llm_endpoint_name}' created successfully")
        return {
            'endpoint_created': True,
            'endpoint_name': self.llm_endpoint_name
        }

    def execute(self) -> TaskResult:
        """Execute the LLM foundational deployment workflow."""
        try:
            self.logger.info(f"Starting LLM foundational deployment for model '{self.llm_model}' (mode: {'provisionless' if self.llm_provisionless else 'provisioned'})")

            # Step 1: Check if endpoint exists (or provisionless mode)
            self.step_check_endpoint_exists()

            # Step 2: Create endpoint if needed
            self.step_create_endpoint()

            self.logger.info(f"LLM foundational deployment completed successfully — endpoint '{self.llm_endpoint_name}' is ready")
            return TaskResult.success(
                message=f"LLM endpoint '{self.llm_endpoint_name}' ready",
                task_name=self.context.task_name,
                metrics={
                    'provisionless': self.llm_provisionless,
                    'endpoint_created': not self.llm_provisionless and not self.endpoint_exists,
                    'endpoint_name': self.llm_endpoint_name
                },
                task_values={
                    'served_entity': self.served_entity,
                    'llm_model_endpoint': self.llm_endpoint_name,
                    'llm_temperature': self.llm_temperature
                }
            )

        except Exception as e:
            error_msg = f"Failed to deploy LLM foundational endpoint: {str(e)}"
            self.logger.error(f"ERROR: {error_msg}")
            raise RuntimeError(error_msg) from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        if not self.llm_endpoint_name:
            result.add_validation(ValidationResult(
                passed=False,
                message="LLM endpoint name is empty",
                actual=self.llm_endpoint_name
            ))
        else:
            result.add_validation(ValidationResult(
                passed=True,
                message="LLM endpoint configured",
                actual=self.llm_endpoint_name
            ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*60)
        self.logger.info("LLM FOUNDATIONAL - COMPLETE")
        self.logger.info("="*60)

        if result.is_success:
            self.logger.info(f"\n  Summary:")
            self.logger.info(f"    Served Entity: {self.served_entity}")
            self.logger.info(f"    LLM Endpoint: {self.llm_endpoint_name}")
            self.logger.info(f"    Mode: {'Provisionless' if self.llm_provisionless else 'Provisioned'}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"LLM foundational deployment failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.error(f"  Error: {error}")
