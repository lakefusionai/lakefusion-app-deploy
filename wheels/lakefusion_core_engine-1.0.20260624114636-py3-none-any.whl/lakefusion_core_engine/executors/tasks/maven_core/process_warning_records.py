"""
Process Warning Records Executor for Maven Core.

Processes validation warnings on master records and writes to warning table.

Workflow:
1. Get entity and validation functions from params
2. Filter validation functions for warning level
3. Read master table and select relevant attributes
4. Apply validation functions to identify warnings
5. Transform results and merge into master_warning table
"""

import json
from typing import Any, Dict, List, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ProcessWarningRecordsExecutor(BaseStepTask):
    """
    Executor for processing warning-level validation records.

    Applies warning-level validation functions to master table records
    and writes the results to a dedicated warning table.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.entity = ""
        self.catalog_name = ""
        self.id_key = "lakefusion_id"
        self.validation_functions = []
        self.validation_function_warnings = []
        self.records_processed = 0
        self.warnings_found = 0
        # DataFrames for intermediate results
        self.df_master = None
        self.df_validated = None
        self.df_warnings = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        # Get params
        self.entity = self.context.entity or self.context.params.get('entity', '')
        self.catalog_name = self.context.catalog_name or self.context.params.get('catalog_name', '')
        # Always use lakefusion_id as the ID key (matches production behavior)
        self.id_key = 'lakefusion_id'

        # Get validation functions
        validation_functions_raw = self.context.params.get('validation_functions', '[]')

        # Parse if string
        if isinstance(validation_functions_raw, str):
            try:
                self.validation_functions = json.loads(validation_functions_raw)
            except json.JSONDecodeError:
                self.validation_functions = []
        else:
            self.validation_functions = validation_functions_raw or []

        self.logger.info("="*60)
        self.logger.info("PROCESS WARNING RECORDS")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Catalog: {self.catalog_name}")
        self.logger.info(f"ID Key: {self.id_key}")
        self.logger.info(f"Total Validation Functions: {len(self.validation_functions)}")

        # Filter for warning-level validations
        self._filter_warning_validations()

        self.logger.info(f"Warning-Level Validations: {len(self.validation_function_warnings)}")
        self.logger.info("="*60)

    def _filter_warning_validations(self) -> None:
        """Filter validation functions to only include warning level."""
        for item in self.validation_functions:
            if item.get("validation_level") == "warning":
                func_def = item.get("function_definition", "")

                # Clean up function definition formatting
                func_def_cleaned = func_def.replace("     ", "\n    ").replace('"""     ', '"""\n    ').strip()

                self.validation_function_warnings.append({
                    "attribute_name": item.get("attribute_name"),
                    "function_name": item.get("function_name"),
                    "validation_id": item.get("validation_id"),
                    "function_definition": func_def_cleaned,
                    "validation_message": item.get("validation_message")
                })

    @step(order=1, name="Read Master Table", returns="DataFrame - master table records")
    def step_read_master_table(self) -> Dict[str, Any]:
        """Read master table and select relevant columns."""
        spark = self.context.spark
        master_table = f"{self.catalog_name}.gold.{self.entity}_master_prod"

        self.logger.info(f"  Reading: {master_table}")

        self.df_master = spark.read.table(master_table)
        self.records_processed = self.df_master.count()

        # Select id_key and all attributes that have warning validations
        attribute_cols = [v['attribute_name'] for v in self.validation_function_warnings]
        select_cols = [self.id_key] + attribute_cols

        self.df_master = self.df_master.select(*select_cols)
        self.logger.info(f"  Read {self.records_processed} records")
        self.logger.info(f"  Columns selected: {select_cols}")

        return {'records_processed': self.records_processed, 'columns': select_cols}

    @step(order=2, name="Apply Validation Functions", returns="DataFrame - validated records")
    def step_apply_validations(self) -> Dict[str, Any]:
        """Apply validation functions to the dataframe."""
        try:
            from lakefusion_core_engine.utils.parse_utils import validation_function_exec

            self.df_validated = validation_function_exec(
                self.validation_function_warnings,
                self.df_master
            )
            self.logger.info(f"  Applied {len(self.validation_function_warnings)} validation functions")
            return {'validation_functions_applied': len(self.validation_function_warnings)}

        except Exception as e:
            self.logger.info(f"  Error applying validations: {e}")
            raise

    @step(order=3, name="Transform to Warning Records", returns="DataFrame - warning records")
    def step_transform_to_warnings(self) -> Dict[str, Any]:
        """Transform validated records into warning format."""
        from pyspark.sql import functions as F

        # Build array of structs for each validation column
        validation_exprs = []
        for v in self.validation_function_warnings:
            attr = v["attribute_name"]
            if attr == "lakefusion_id":
                continue

            flag_col = f"is_valid_{attr}"
            validation_exprs.append(
                F.when(
                    F.col(flag_col) == True,
                    F.struct(
                        F.col("lakefusion_id").alias("lakefusion_id"),
                        F.lit(attr).alias("attribute_name"),
                        F.lit(v["validation_id"]).alias("validation_function_id"),
                        F.lit(v.get("status", "REVIEW")).alias("status")
                    )
                )
            )

        if not validation_exprs:
            self.logger.info("  No validation expressions to process")
            self.df_warnings = self.df_validated.limit(0)
            return {'warnings_found': 0}

        # Create array column of all possible failures
        df_with_array = self.df_validated.withColumn(
            "validation_failures",
            F.array(*validation_exprs)
        )

        # Explode array into rows, filter out nulls (valid cases)
        self.df_warnings = (
            df_with_array
            .withColumn("failure", F.explode("validation_failures"))
            .select("failure.*")
            .filter(F.col("attribute_name").isNotNull())
        )

        self.warnings_found = self.df_warnings.count()
        self.logger.info(f"  Found {self.warnings_found} warning records")

        return {'warnings_found': self.warnings_found}

    @step(order=4, name="Merge to Warning Table", returns="Dict - merge result")
    def step_merge_to_warning_table(self) -> Dict[str, Any]:
        """Merge warning records into the warning table."""
        from delta.tables import DeltaTable

        spark = self.context.spark
        warning_table = f"{self.catalog_name}.gold.{self.entity}_master_warning_prod"

        self.logger.info(f"  Target table: {warning_table}")

        # Check if table exists
        table_exists = spark.catalog.tableExists(warning_table)

        if not table_exists:
            # Create new table
            self.logger.info("  Creating new warning table...")
            self.df_warnings.write.mode('overwrite').saveAsTable(warning_table)
            self.logger.info(f"  Created warning table with {self.warnings_found} records")
            return {'table_created': True, 'records_written': self.warnings_found}
        else:
            # Merge into existing table
            self.logger.info("  Merging into existing warning table...")
            delta_table = DeltaTable.forName(spark, warning_table)

            id_cols = ["lakefusion_id", "attribute_name", "validation_function_id", "status"]
            merge_condition = " AND ".join([f"target.{c} = source.{c}" for c in id_cols])

            (
                delta_table.alias("target")
                .merge(
                    source=self.df_warnings.alias("source"),
                    condition=merge_condition
                )
                .whenMatchedUpdateAll()
                .whenNotMatchedInsertAll()
                .whenNotMatchedBySourceUpdate(set={"status": "'DONE'"})
                .execute()
            )
            self.logger.info(f"  Merged {self.warnings_found} warning records")
            return {'table_created': False, 'records_merged': self.warnings_found}

    def execute(self) -> TaskResult:
        """Execute the process warning records workflow."""
        try:
            # Check if we have any warning validations
            if not self.validation_function_warnings:
                return TaskResult.skipped(
                    message="No warning-level validation functions configured",
                    task_name=self.context.task_name,
                    task_values={
                        'warnings_processed': 0
                    }
                )

            # Execute steps in sequence
            self.step_read_master_table()
            self.step_apply_validations()
            self.step_transform_to_warnings()
            self.step_merge_to_warning_table()

            return TaskResult.success(
                message=f"Processed {self.warnings_found} warning records",
                task_name=self.context.task_name,
                metrics={
                    'records_processed': self.records_processed,
                    'warnings_found': self.warnings_found,
                    'validation_functions_applied': len(self.validation_function_warnings)
                },
                task_values={
                    'warnings_processed': self.warnings_found
                }
            )

        except Exception as e:
            error_msg = f"Failed to process warning records: {str(e)}"
            self.logger.error(f"ERROR: {error_msg}")
            raise RuntimeError(error_msg) from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message=f"Processed {self.warnings_found} warning records",
            actual={
                'records_processed': self.records_processed,
                'warnings_found': self.warnings_found
            }
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*60)
        self.logger.info("PROCESS WARNING RECORDS - COMPLETE")
        self.logger.info("="*60)

        if result.is_success:
            self.logger.info(f"\n  Summary:")
            self.logger.info(f"    Records Processed: {self.records_processed}")
            self.logger.info(f"    Warnings Found: {self.warnings_found}")
            self.logger.info(f"    Validation Functions: {len(self.validation_function_warnings)}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Process warning records failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.error(f"  Error: {error}")
