"""
Resource Tagging Executor for Maven Core.

Applies resource tags to all schemas and tables associated with an entity.

Workflow:
1. Get entity name and catalog name from params
2. Query information_schema to find all tables for the entity
3. Get resource tags configuration
4. Apply tags to all schemas containing entity tables
5. Apply tags to all entity tables
"""

from typing import Any, Dict, List, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ResourceTaggingExecutor(BaseStepTask):
    """
    Executor for applying resource tags to Unity Catalog resources.

    Queries the information_schema to find all tables and schemas
    associated with an entity, then applies the configured resource tags.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.entity = ""
        self.catalog_name = ""
        self.experiment_id = ""
        self.schemas_tagged = 0
        self.tables_tagged = 0
        self.tags = {}
        self.entity_tables = None
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        # Get params
        self.catalog_name = self.context.catalog_name or self.context.params.get('catalog_name', '')
        self.entity = self.context.entity or self.context.params.get('entity', '')
        self.experiment_id = self.context.experiment_id or self.context.params.get('experiment_id', '')

        # Normalize experiment_id
        if self.experiment_id:
            self.experiment_id = self.experiment_id.replace("-", "")

        # Normalize entity name
        self.entity = self.entity.lower().replace(' ', '_')

        self.logger.info("="*60)
        self.logger.info("RESOURCE TAGGING")
        self.logger.info("="*60)
        self.logger.info(f"Catalog: {self.catalog_name}")
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Experiment ID: {self.experiment_id if self.experiment_id else 'N/A'}")

        if not self.catalog_name:
            raise ValueError("catalog_name is required in params")
        if not self.entity:
            raise ValueError("entity is required in params")

        self.logger.info("="*60)

    @step(order=1, name="Get Resource Tags", returns="Dict - resource tags configuration")
    def step_get_resource_tags(self) -> Dict[str, Any]:
        """Get resource tags configuration."""
        try:
            from lakefusion_core_engine.utils.parse_utils import get_resource_tags
            self.tags = get_resource_tags() or {}
        except Exception as e:
            self.logger.info(f"  Warning: Could not get resource tags: {e}")
            self.tags = {}

        if self.tags:
            self.logger.info(f"  Found {len(self.tags)} resource tags")
            for key, value in self.tags.items():
                self.logger.info(f"    {key}: {value}")
        else:
            self.logger.info("  No resource tags configured")

        return {'tags': self.tags, 'tag_count': len(self.tags)}

    @step(order=2, name="Find Entity Tables", returns="DataFrame - entity tables from information_schema")
    def step_find_entity_tables(self) -> Dict[str, Any]:
        """Find all tables associated with the entity."""
        spark = self.context.spark

        # Build query to find entity tables
        query = f"""
        SELECT
          table_catalog,
          table_schema,
          concat(table_catalog, '.', table_schema) as schema_path,
          table_name,
          concat(table_catalog, '.', table_schema, '.', table_name) as table_path
        FROM system.information_schema.tables
        WHERE table_catalog = '{self.catalog_name}'
          AND table_name LIKE '%{self.entity}%{self.experiment_id}%'
        ORDER BY table_schema
        """

        self.entity_tables = spark.sql(query)
        table_count = self.entity_tables.count()

        self.logger.info(f"  Found {table_count} tables for entity '{self.entity}'")

        if table_count > 0:
            # Show sample of tables found
            sample = self.entity_tables.select("table_path").limit(5).collect()
            self.logger.info("  Sample tables:")
            for row in sample:
                self.logger.info(f"    - {row['table_path']}")
            if table_count > 5:
                self.logger.info(f"    ... and {table_count - 5} more")

        return {'table_count': table_count}

    @step(order=3, name="Tag Schemas", returns="int - number of schemas tagged")
    def step_tag_schemas(self) -> Dict[str, Any]:
        """Apply tags to all schemas containing entity tables."""
        if not self.tags:
            self.logger.info("  No tags to apply, skipping schema tagging")
            return {'schemas_tagged': 0}

        try:
            from lakefusion_core_engine.utils.parse_utils import apply_tags_to_uc_resource
        except ImportError:
            self.logger.info("  Warning: apply_tags_to_uc_resource not available")
            return {'schemas_tagged': 0}

        schemas = self.entity_tables.select("schema_path").distinct().collect()
        self.logger.info(f"  Found {len(schemas)} unique schemas to tag")

        for schema_row in schemas:
            schema_path = schema_row['schema_path']
            try:
                apply_tags_to_uc_resource("schemas", schema_path, self.tags)
                self.schemas_tagged += 1
                self.logger.info(f"    Tagged schema: {schema_path}")
            except Exception as e:
                self.logger.info(f"    Could not tag schema {schema_path}: {e}")

        return {'schemas_tagged': self.schemas_tagged}

    @step(order=4, name="Tag Tables", returns="int - number of tables tagged")
    def step_tag_tables(self) -> Dict[str, Any]:
        """Apply tags to all entity tables."""
        if not self.tags:
            self.logger.info("  No tags to apply, skipping table tagging")
            return {'tables_tagged': 0}

        try:
            from lakefusion_core_engine.utils.parse_utils import apply_tags_to_uc_resource
        except ImportError:
            self.logger.info("  Warning: apply_tags_to_uc_resource not available")
            return {'tables_tagged': 0}

        tables = self.entity_tables.select("table_path").distinct().collect()
        self.logger.info(f"  Found {len(tables)} tables to tag")

        for table_row in tables:
            table_path = table_row['table_path']
            try:
                apply_tags_to_uc_resource("tables", table_path, self.tags)
                self.tables_tagged += 1
                self.logger.info(f"    Tagged table: {table_path}")
            except Exception as e:
                self.logger.info(f"    Could not tag table {table_path}: {e}")

        return {'tables_tagged': self.tables_tagged}

    def execute(self) -> TaskResult:
        """Execute the resource tagging workflow."""
        try:
            # Execute steps in sequence
            self.step_get_resource_tags()
            self.step_find_entity_tables()
            self.step_tag_schemas()
            self.step_tag_tables()

            return TaskResult.success(
                message=f"Resource tagging completed for entity '{self.entity}'",
                task_name=self.context.task_name,
                metrics={
                    'schemas_tagged': self.schemas_tagged,
                    'tables_tagged': self.tables_tagged,
                    'tags_applied': len(self.tags)
                },
                task_values={
                    'resource_tagging_complete': True
                }
            )

        except Exception as e:
            error_msg = f"Failed to apply resource tags: {str(e)}"
            self.logger.info(f"ERROR: {error_msg}")
            raise RuntimeError(error_msg) from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message=f"Tagged {self.schemas_tagged} schemas and {self.tables_tagged} tables",
            actual={
                'schemas_tagged': self.schemas_tagged,
                'tables_tagged': self.tables_tagged
            }
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*60)
        self.logger.info("RESOURCE TAGGING - COMPLETE")
        self.logger.info("="*60)

        if result.is_success:
            self.logger.info(f"\n  Summary:")
            self.logger.info(f"    Entity: {self.entity}")
            self.logger.info(f"    Catalog: {self.catalog_name}")
            self.logger.info(f"    Schemas Tagged: {self.schemas_tagged}")
            self.logger.info(f"    Tables Tagged: {self.tables_tagged}")
            self.logger.info(f"    Tags Applied: {len(self.tags)}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Resource tagging failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.error(f"  Error: {error}")
