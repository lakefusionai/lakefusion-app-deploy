"""
Send Email Notification Executor for Maven Core.

Sends email notifications about potential matches requiring review.

Workflow:
1. Get entity, catalog, and recipient email addresses
2. Query to find potential matches requiring review
3. Generate HTML email body with count of reviewable records
4. Send email via SendGrid (or other SMTP provider)
"""

from typing import Any, Dict, List, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class SendEmailNotificationExecutor(BaseStepTask):
    """
    Executor for sending email notifications about potential matches.

    Queries the merge activities and potential matches to find records
    requiring review, then sends email notifications to specified recipients.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.entity = ""
        self.catalog_name = ""
        self.experiment_id = ""
        self.id_key = ""
        self.to_emails = []
        self.smtp_type = "SendGrid"
        self.job_id = ""
        self.run_id = ""
        self.total_reviewable_records = 0
        self.email_sent = False
        # Table names (set in step 1)
        self.unified_table = ""
        self.master_table = ""
        self.processed_unified_table = ""
        self.merge_activities_table = ""
        # get logger from context params
        self.logger = context.params.get("logger") or self.logger

    def pre_execute(self) -> None:
        """Validate inputs and prepare for execution."""
        # Get params
        self.entity = self.context.entity or self.context.params.get('entity', '')
        self.catalog_name = self.context.catalog_name or self.context.params.get('catalog_name', '')
        self.experiment_id = self.context.experiment_id or self.context.params.get('experiment_id', '')
        self.id_key = self.context.params.get('id_key', '')
        to_emails_str = self.context.params.get('to_emails', '')
        self.smtp_type = self.context.params.get('smtp_type', 'SendGrid')
        self.job_id = self.context.params.get('job_id', '')
        self.run_id = self.context.params.get('run_id', '')

        # Parse email addresses
        if to_emails_str:
            self.to_emails = [e.strip() for e in to_emails_str.split(',') if e.strip()]

        self.logger.info("="*60)
        self.logger.info("SEND EMAIL NOTIFICATION")
        self.logger.info("="*60)
        self.logger.info(f"Entity: {self.entity}")
        self.logger.info(f"Catalog: {self.catalog_name}")
        self.logger.info(f"Experiment ID: {self.experiment_id if self.experiment_id else 'N/A'}")
        self.logger.info(f"ID Key: {self.id_key}")
        self.logger.info(f"Recipients: {len(self.to_emails)} email(s)")
        self.logger.info(f"SMTP Type: {self.smtp_type}")
        self.logger.info("="*60)

        if not self.to_emails:
            self.logger.info("No recipient emails provided - will skip email notification")

    @step(order=1, name="Build Table Names", returns="Dict - table name references")
    def step_build_table_names(self) -> Dict[str, Any]:
        """Build table names based on entity and experiment."""
        base_unified = f"{self.catalog_name}.silver.{self.entity}_unified"
        base_master = f"{self.catalog_name}.gold.{self.entity}_master"
        base_processed = f"{self.catalog_name}.silver.{self.entity}_processed_unified"

        if self.experiment_id:
            self.unified_table = f"{base_unified}_{self.experiment_id}"
            self.master_table = f"{base_master}_{self.experiment_id}"
            self.processed_unified_table = f"{base_processed}_{self.experiment_id}"
        else:
            self.unified_table = base_unified
            self.master_table = base_master
            self.processed_unified_table = base_processed

        self.merge_activities_table = f"{self.master_table}_merge_activities"

        self.logger.info(f"  Unified: {self.unified_table}")
        self.logger.info(f"  Master: {self.master_table}")
        self.logger.info(f"  Processed Unified: {self.processed_unified_table}")
        self.logger.info(f"  Merge Activities: {self.merge_activities_table}")

        return {
            'unified_table': self.unified_table,
            'master_table': self.master_table,
            'processed_unified_table': self.processed_unified_table,
            'merge_activities_table': self.merge_activities_table
        }

    @step(order=2, name="Query Reviewable Records", returns="int - count of reviewable records")
    def step_query_reviewable_records(self) -> Dict[str, Any]:
        """Query to find potential matches requiring review."""
        spark = self.context.spark
        id_key = self.id_key

        query = f"""
            WITH no_match AS (
                SELECT *
                FROM {self.merge_activities_table}
                WHERE action_type IN ('MANUAL_NOT_A_MATCH', 'JOB_NOT_A_MATCH')
            ),
            merges AS (
                SELECT *
                FROM {self.merge_activities_table}
                WHERE action_type IN ('MANUAL_MERGE', 'JOB_MERGE')
            ),
            pot_match AS (
                SELECT ma.*, pu.potential_matches
                FROM (
                    SELECT
                        u.master_{id_key},
                        collect_set(struct(u.*)) AS potential_matches
                    FROM (
                        SELECT pu.*, uo.* EXCEPT ({id_key})
                        FROM {self.processed_unified_table} pu
                        INNER JOIN {self.unified_table} uo
                        ON pu.{id_key} = uo.{id_key}
                    ) u
                    JOIN {self.master_table} m ON m.{id_key} = u.master_{id_key}
                    LEFT ANTI JOIN no_match ON (
                        u.master_{id_key} = no_match.master_{id_key}
                        AND u.{id_key} = no_match.{id_key}
                        AND u.dataset.path = no_match.`source`
                    )
                    LEFT ANTI JOIN merges ON (
                        u.master_{id_key} = merges.master_{id_key}
                        AND u.{id_key} = merges.{id_key}
                        AND u.dataset.path = merges.`source`
                    )
                    WHERE u.exploded_result.match = 'MATCH'
                    GROUP BY u.master_{id_key}
                ) pu,
                {self.master_table} ma
                WHERE pu.master_{id_key} = ma.{id_key}
            )
            SELECT * FROM pot_match
        """

        df_potential_matches = spark.sql(query)
        self.total_reviewable_records = df_potential_matches.count()

        self.logger.info(f"  Found {self.total_reviewable_records} records requiring review")

        return {'total_reviewable_records': self.total_reviewable_records}

    @step(order=3, name="Send Email Notification", returns="bool - email sent status")
    def step_send_email(self) -> Dict[str, Any]:
        """Send email notification via configured SMTP provider."""
        if self.total_reviewable_records <= 0:
            self.logger.info("  No reviewable records found - skipping email")
            return {'email_sent': False}

        if self.smtp_type == 'SendGrid':
            self._send_sendgrid_email()
        else:
            self.logger.info(f"  Unsupported SMTP type: {self.smtp_type}")

        return {'email_sent': self.email_sent}

    def _send_sendgrid_email(self) -> None:
        """Send email using SendGrid."""
        try:
            from sendgrid import SendGridAPIClient
            from sendgrid.helpers.mail import Mail, From, To, Content

            # Get API key from secrets
            dbutils = self.context.dbutils
            _scope = self.context.params.get('secret_scope_name', 'lakefusion')
            api_key = dbutils.secrets.get(scope=_scope, key="sendgrid_api_key")
            from_email = dbutils.secrets.get(scope=_scope, key="sendgrid_from_email")

            sg = SendGridAPIClient(api_key)

            # Build HTML body
            html_body = self._build_email_html()

            # Create recipient list
            to_emails_list = [To(email) for email in self.to_emails]

            message = Mail(
                from_email=From(from_email),
                to_emails=to_emails_list,
                subject="Attention Needed: Resolve Critical Entities",
                html_content=Content('text/html', html_body)
            )

            response = sg.send(message)
            self.email_sent = True
            self.logger.info(f"  Email sent successfully to {len(self.to_emails)} recipient(s)")

        except Exception as e:
            self.logger.info(f"  Error sending email: {e}")
            self.email_sent = False

    def _build_email_html(self) -> str:
        """Build HTML email body."""
        return f"""
<!DOCTYPE html>
<html>
<head>
  <title>Attention Needed: Review Critical Entities</title>
  <style>
    .button {{
      background-color: #750f11;
      color: white !important;
      padding: 10px 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 12px;
      margin: 10px 0;
      cursor: pointer;
      border-radius: 8px;
    }}
    .container {{
      font-family: Arial, sans-serif;
      line-height: 1.6;
      max-width: 600px;
      margin: 0 auto;
      padding: 10px;
    }}
    h1 {{ color: #333; }}
    p {{ color: #555; }}
  </style>
</head>
<body>
  <div class="container">
    <h1>Attention Needed: Review Critical Entities</h1>
    <p>Dear User,</p>
    <p>LakeFusion has detected <strong>{self.total_reviewable_records} entities</strong> that require your review. These entities have been flagged as potential matches and need your attention to confirm or resolve their statuses.</p>
    <p>These flagged entities may indicate:</p>
    <ul>
      <li>Potential duplicate records.</li>
      <li>Unresolved entity relationships.</li>
      <li>Inconsistent data points requiring alignment.</li>
    </ul>
    <p><strong>Next Steps:<BR />Review Entities: </strong>Click below to access the list of flagged entities and take appropriate actions.</p>
    <a href="http://localhost:3000/entity-search" class="button">Review Critical Entities</a>
    <p>Addressing these flagged entities promptly ensures data accuracy and optimal system performance.</p>
    <p>Best Regards,<BR />The LakeFusion Team</p>
  </div>
</body>
</html>
"""

    def execute(self) -> TaskResult:
        """Execute the email notification workflow."""
        try:
            # Check if we have recipients
            if not self.to_emails:
                return TaskResult.skipped(
                    message="No recipient emails provided",
                    task_name=self.context.task_name,
                    task_values={
                        'email_sent': False,
                        'total_reviewable_records': 0
                    }
                )

            # Execute steps in sequence
            self.step_build_table_names()
            self.step_query_reviewable_records()
            self.step_send_email()

            return TaskResult.success(
                message=f"Email notification {'sent' if self.email_sent else 'skipped'}",
                task_name=self.context.task_name,
                metrics={
                    'total_reviewable_records': self.total_reviewable_records,
                    'recipients_count': len(self.to_emails),
                    'email_sent': self.email_sent
                },
                task_values={
                    'email_sent': self.email_sent,
                    'total_reviewable_records': self.total_reviewable_records
                }
            )

        except Exception as e:
            error_msg = f"Failed to send email notification: {str(e)}"
            print(f"ERROR: {error_msg}")
            raise RuntimeError(error_msg) from e

    def validate(self, result: TaskResult) -> TaskResult:
        """Validate the execution result."""
        if result.is_failed:
            return result

        result.add_validation(ValidationResult(
            passed=True,
            message=f"Email notification processed",
            actual={
                'email_sent': self.email_sent,
                'reviewable_records': self.total_reviewable_records
            }
        ))

        return result

    def post_execute(self, result: TaskResult) -> None:
        """Log final summary."""
        self.logger.info("\n" + "="*60)
        self.logger.info("SEND EMAIL NOTIFICATION - COMPLETE")
        self.logger.info("="*60)

        if result.is_success:
            self.logger.info(f"\n  Summary:")
            self.logger.info(f"    Reviewable Records: {self.total_reviewable_records}")
            self.logger.info(f"    Email Sent: {self.email_sent}")
            self.logger.info(f"    Recipients: {len(self.to_emails)}")

    def on_success(self, result: TaskResult) -> None:
        """Handle successful execution."""
        if self.context.dbutils:
            for key, value in result.task_values.items():
                self.context.dbutils.jobs.taskValues.set(key, value)

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Send email notification failed: {result.message}")
        if result.errors:
            for error in result.errors:
                self.logger.error(f"  Error: {error}")
