"""
Relationship pipeline tasks (Story 2).

Materializes the production ``{rel}_edges`` Delta table from configured source
datasets via the existing entity ID crosswalks. Failures and cardinality
conflicts land in ``{rel}_edges_dlq``.
"""

from .materialize_edges import MaterializeEdgesTask
from .parse_relationship_json import ParseRelationshipJsonTask
from .relationship_job_status import RelationshipJobStatusTask

__all__ = [
    "MaterializeEdgesTask",
    "ParseRelationshipJsonTask",
    "RelationshipJobStatusTask",
]
