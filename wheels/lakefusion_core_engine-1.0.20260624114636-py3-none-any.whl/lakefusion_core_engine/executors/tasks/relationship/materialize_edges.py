"""
Materialize Edges task (Story 2).

For every relationship configured in the IntHub task:

1. Read each configured source dataset.
2. Resolve ``source_pk_column`` → ``src_node_id`` and ``target_pk_column`` →
   ``dst_node_id`` via the existing entity crosswalk views.
3. Apply cardinality enforcement (1:1 / 1:N / N:1) with three resolution
   layers — source priority, then recency, then steward queue (DLQ).
4. Apply attribute survivorship (default: highest-priority source wins; ties
   broken by most recent effective_date).
5. Layer steward overrides from Postgres on top.
6. MERGE into ``{rel}_edges`` with schema matching the LakeGraph mandatory
   contract.
7. Reconcile orphans — rows whose endpoint master_id no longer exists in the
   relevant ``_master_prod`` table are flipped to ``status='inactive'``.
8. Append failure / conflict rows to ``{rel}_edges_dlq``.

Note: this is the v1 transactional skeleton. The Spark expressions below use
PySpark DataFrame API. The merge_config (``on_match`` / ``on_new_record``) is
honoured at MERGE time.
"""

from typing import Any, Dict, List, Optional

from ...base import BaseTask
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


# Reserved column names mirror RESERVED_ATTRIBUTE_NAMES in the Pydantic model
# layer — kept in sync because Story 1 already validates designers can't name
# attributes after these.
MANDATORY_COLUMNS = [
    "src_node_id",
    "dst_node_id",
    "src_node_type",
    "dst_node_type",
    "edge_type",
]
BUILTIN_COLUMNS = [
    "start_date",
    "end_date",
    "status",
    "contributing_sources",
    "origin",
    "created_at",
    "updated_at",
    "created_by",
    "updated_by",
]


# Spark SQL type mapping for designer-defined attribute data_type values.
_ATTR_TYPE_TO_SPARK = {
    "STRING": "STRING",
    "BIGINT": "BIGINT",
    "INT": "INT",
    "SMALLINT": "SMALLINT",
    "TINYINT": "TINYINT",
    "DOUBLE": "DOUBLE",
    "FLOAT": "FLOAT",
    "BOOLEAN": "BOOLEAN",
    "DATE": "DATE",
    "TIMESTAMP": "TIMESTAMP",
}


class MaterializeEdgesTask(BaseTask):
    """Single transformational task — handles read → resolve → MERGE → reconcile."""

    def __init__(self, context: TaskContext, override_instance: Any = None):
        super().__init__(context, override_instance=override_instance)
        self.logger = context.params.get("logger") or self.logger
        self._summary: Dict[str, Any] = {
            "relationships": [],
            "rows_promoted": 0,
            "rows_dlq": 0,
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _entity_crosswalk(self, entity_name: str) -> str:
        """Return the crosswalk view name for an entity, honouring experiment_id."""
        base = f"{self.context.catalog_name}.gold.{entity_name}_crosswalk"
        if self.context.experiment_id:
            base += f"_{self.context.experiment_id}"
        return base

    def _entity_master(self, entity_name: str) -> str:
        return f"{self.context.catalog_name}.gold.{entity_name}_master_prod"

    def _edges_table(self, relationship_name: str) -> str:
        base = f"{self.context.catalog_name}.gold.{relationship_name}_edges"
        if self.context.experiment_id:
            base += f"_{self.context.experiment_id}"
        return base

    def _dlq_table(self, relationship_name: str) -> str:
        base = f"{self.context.catalog_name}.gold.{relationship_name}_edges_dlq"
        if self.context.experiment_id:
            base += f"_{self.context.experiment_id}"
        return base

    def _ensure_edges_table(
        self,
        relationship: Dict[str, Any],
        attributes: List[Dict[str, Any]],
    ) -> str:
        """Create the {rel}_edges Delta table if missing. Schema includes
        mandatory + built-in + designer-defined attribute columns. CDF enabled.
        """
        spark = self.context.spark
        rel_name = relationship["name"]
        table = self._edges_table(rel_name)

        attr_cols = []
        for a in attributes:
            sp_type = _ATTR_TYPE_TO_SPARK.get(a["data_type"], "STRING")
            attr_cols.append(f"`{a['name']}` {sp_type}")
        attr_sql = ",\n  ".join(attr_cols) if attr_cols else ""

        ddl = f"""
        CREATE TABLE IF NOT EXISTS {table} (
            src_node_id     STRING NOT NULL,
            dst_node_id     STRING NOT NULL,
            src_node_type   STRING NOT NULL,
            dst_node_type   STRING NOT NULL,
            edge_type       STRING NOT NULL,
            start_date      DATE,
            end_date        DATE,
            status          STRING,
            contributing_sources ARRAY<STRING>,
            origin          STRING,
            {attr_sql + ',' if attr_sql else ''}
            created_at      TIMESTAMP,
            updated_at      TIMESTAMP,
            created_by      STRING,
            updated_by      STRING
        )
        USING DELTA
        PARTITIONED BY (edge_type)
        TBLPROPERTIES (delta.enableChangeDataFeed = true)
        """
        spark.sql(ddl)

        # Ensure DLQ exists too.
        dlq = self._dlq_table(rel_name)
        spark.sql(
            f"""
            CREATE TABLE IF NOT EXISTS {dlq} (
                src_node_id   STRING,
                dst_node_id   STRING,
                edge_type     STRING,
                failure_reason STRING,
                failure_detail STRING,
                src_source_pk STRING,
                dst_source_pk STRING,
                source_system STRING,
                raw_payload   STRING,
                ingested_at   TIMESTAMP
            )
            USING DELTA
            TBLPROPERTIES (delta.enableChangeDataFeed = true)
            """
        )
        return table

    # ------------------------------------------------------------------
    # Core pipeline per relationship
    # ------------------------------------------------------------------

    def _process_relationship(
        self,
        rel_entry: Dict[str, Any],
        merge_config: Dict[str, str],
    ) -> Dict[str, Any]:
        from pyspark.sql import functions as F
        from pyspark.sql.window import Window

        relationship = rel_entry["relationship"]
        attributes = rel_entry["attributes"]
        mappings = rel_entry["mappings"]

        spark = self.context.spark
        rel_name = relationship["name"]
        edge_type = rel_name
        src_type = relationship["source_entity_name"]
        dst_type = relationship["target_entity_name"]

        table = self._ensure_edges_table(relationship, attributes)
        dlq_table = self._dlq_table(rel_name)

        src_crosswalk = self._entity_crosswalk(src_type.lower().replace(" ", "_"))
        dst_crosswalk = self._entity_crosswalk(dst_type.lower().replace(" ", "_"))

        all_resolved = None
        dlq_rows = None

        for mapping in mappings:
            dataset_path = mapping["dataset_path"]
            source_system = mapping["source_system_tag"]
            priority = int(mapping.get("priority", 100))
            src_pk = mapping["source_pk_column"]
            tgt_pk = mapping["target_pk_column"]
            start_col = mapping.get("start_date_column")
            end_col = mapping.get("end_date_column")
            status_col = mapping.get("status_column")
            attr_maps = mapping.get("attribute_mappings", [])

            self.logger.info(
                f"[{rel_name}] reading {dataset_path} via {source_system} (priority={priority})"
            )
            src_df = spark.read.table(dataset_path)

            # Resolve endpoint IDs via the existing entity crosswalk view.
            # The crosswalk maps (source_record_id, source_table_name) → lakefusion_id.
            # We join on source_record_id only; PK values are wide enough across
            # NPI / DUNS / SFDC_ID etc. that collisions are not a concern, and the
            # join must work across whichever entity source the relationship row's
            # PK happens to come from.
            src_cw = spark.read.table(src_crosswalk).select(
                F.col("source_record_id").alias("_src_lookup"),
                F.col("lakefusion_id").alias("src_node_id"),
            )
            dst_cw = spark.read.table(dst_crosswalk).select(
                F.col("source_record_id").alias("_dst_lookup"),
                F.col("lakefusion_id").alias("dst_node_id"),
            )
            joined = (
                src_df.alias("s")
                .join(src_cw, F.col(f"s.{src_pk}") == F.col("_src_lookup"), "left")
                .join(dst_cw, F.col(f"s.{tgt_pk}") == F.col("_dst_lookup"), "left")
            )

            # Splice failed-resolution rows to DLQ.
            failed = joined.filter(
                F.col("src_node_id").isNull() | F.col("dst_node_id").isNull()
            ).select(
                F.col("src_node_id"),
                F.col("dst_node_id"),
                F.lit(edge_type).alias("edge_type"),
                F.when(F.col("src_node_id").isNull(), F.lit("src_not_resolved"))
                .when(F.col("dst_node_id").isNull(), F.lit("dst_not_resolved"))
                .otherwise(F.lit("unknown")).alias("failure_reason"),
                F.lit(None).cast("string").alias("failure_detail"),
                F.col(f"s.{src_pk}").cast("string").alias("src_source_pk"),
                F.col(f"s.{tgt_pk}").cast("string").alias("dst_source_pk"),
                F.lit(source_system).alias("source_system"),
                F.to_json(F.struct("s.*")).alias("raw_payload"),
                F.current_timestamp().alias("ingested_at"),
            )
            dlq_rows = failed if dlq_rows is None else dlq_rows.unionByName(failed)

            resolved = joined.filter(
                F.col("src_node_id").isNotNull() & F.col("dst_node_id").isNotNull()
            )
            # Self-reference check.
            resolved = resolved.filter(F.col("src_node_id") != F.col("dst_node_id"))

            # Build the resolved frame with mandatory + built-in + attribute columns.
            select_cols = [
                F.col("src_node_id"),
                F.col("dst_node_id"),
                F.lit(src_type).alias("src_node_type"),
                F.lit(dst_type).alias("dst_node_type"),
                F.lit(edge_type).alias("edge_type"),
                (F.to_date(F.col(f"s.{start_col}")) if start_col else F.lit(None).cast("date")).alias("start_date"),
                (F.to_date(F.col(f"s.{end_col}")) if end_col else F.lit(None).cast("date")).alias("end_date"),
                (F.col(f"s.{status_col}").cast("string") if status_col else F.lit("active")).alias("status"),
                F.array(F.lit(source_system)).alias("contributing_sources"),
                F.lit(f"source_{source_system}").alias("origin"),
            ]
            for am in attr_maps:
                attr_def = next(
                    (a for a in attributes if a["id"] == am["attribute_id"]), None
                )
                if not attr_def:
                    continue
                spark_type = _ATTR_TYPE_TO_SPARK.get(attr_def["data_type"], "STRING")
                col_expr = F.col(f"s.{am['column_name']}").cast(spark_type)
                select_cols.append(col_expr.alias(attr_def["name"]))

            # Annotate priority + ingest time for survivorship.
            resolved = resolved.select(*select_cols).withColumn(
                "_priority", F.lit(priority)
            ).withColumn("_source_system", F.lit(source_system))

            all_resolved = (
                resolved
                if all_resolved is None
                else all_resolved.unionByName(resolved, allowMissingColumns=True)
            )

        if all_resolved is None:
            self.logger.warning(f"[{rel_name}] no rows resolved across all mappings")
            return {
                "relationship": rel_name,
                "promoted": 0,
                "conflicts": 0,
                "dlq": 0,
            }

        # ------------- Cardinality enforcement (Layer A/B/C) ----------
        cardinality = relationship["cardinality"]
        cardinality_conflicts = None
        winners = all_resolved

        if cardinality in ("1:1", "N:1"):
            # Each src must have at most 1 distinct dst.
            grp = Window.partitionBy("src_node_id")
            winners = winners.withColumn("_n_dst", F.size(F.collect_set("dst_node_id").over(grp)))
            conflicts = winners.filter(F.col("_n_dst") > 1)
            winners = winners.filter(F.col("_n_dst") == 1).drop("_n_dst")
            # Apply Layer A (priority): keep min priority; then Layer B (recency).
            grp2 = Window.partitionBy("src_node_id").orderBy(
                F.col("_priority").asc(),
                F.col("start_date").desc_nulls_last(),
            )
            picked = (
                conflicts.withColumn("_rank", F.row_number().over(grp2))
                .filter(F.col("_rank") == 1)
                .drop("_rank", "_n_dst")
            )
            losers = (
                conflicts.withColumn("_rank", F.row_number().over(grp2))
                .filter(F.col("_rank") > 1)
            )
            winners = winners.unionByName(picked, allowMissingColumns=True)
            cardinality_conflicts = losers.select(
                F.col("src_node_id"),
                F.col("dst_node_id"),
                F.lit(edge_type).alias("edge_type"),
                F.lit(f"cardinality_{cardinality.replace(':','_')}_violation").alias("failure_reason"),
                F.lit("Lost to higher-priority/most-recent claim").alias("failure_detail"),
                F.lit(None).cast("string").alias("src_source_pk"),
                F.lit(None).cast("string").alias("dst_source_pk"),
                F.col("_source_system").alias("source_system"),
                F.lit(None).cast("string").alias("raw_payload"),
                F.current_timestamp().alias("ingested_at"),
            )

        if cardinality in ("1:1", "1:N"):
            # Each dst must have at most 1 distinct src.
            grp = Window.partitionBy("dst_node_id")
            winners = winners.withColumn("_n_src", F.size(F.collect_set("src_node_id").over(grp)))
            extra = winners.filter(F.col("_n_src") > 1)
            winners = winners.filter(F.col("_n_src") == 1).drop("_n_src")
            grp3 = Window.partitionBy("dst_node_id").orderBy(
                F.col("_priority").asc(),
                F.col("start_date").desc_nulls_last(),
            )
            picked2 = (
                extra.withColumn("_rank", F.row_number().over(grp3))
                .filter(F.col("_rank") == 1)
                .drop("_rank", "_n_src")
            )
            winners = winners.unionByName(picked2, allowMissingColumns=True)

        # ------------- Survivorship + multi-source collapse ----------
        # For each (src, dst, edge_type) — pick the row with lowest _priority,
        # then most recent start_date. Collect all source systems into the
        # contributing_sources array.
        grp = Window.partitionBy("src_node_id", "dst_node_id", "edge_type")
        with_array = winners.withColumn(
            "contributing_sources", F.collect_set("_source_system").over(grp)
        ).withColumn(
            "_winner_rank",
            F.row_number().over(
                grp.orderBy(F.col("_priority").asc(), F.col("start_date").desc_nulls_last())
            ),
        )
        final = with_array.filter(F.col("_winner_rank") == 1).drop(
            "_winner_rank", "_priority", "_source_system"
        )

        final = (
            final.withColumn("created_at", F.current_timestamp())
            .withColumn("updated_at", F.current_timestamp())
            .withColumn("created_by", F.lit("system_pipeline"))
            .withColumn("updated_by", F.lit("system_pipeline"))
        )

        # ------------- MERGE into edges table ------------------------
        from delta.tables import DeltaTable

        target = DeltaTable.forName(spark, table)
        merge_on_match = merge_config.get("on_match", "source_wins")
        merge_on_insert = merge_config.get("on_new_record", "auto_insert")

        merge_builder = target.alias("t").merge(
            final.alias("s"),
            "t.src_node_id = s.src_node_id AND t.dst_node_id = s.dst_node_id AND t.edge_type = s.edge_type",
        )

        # Update branch
        if merge_on_match == "source_wins":
            merge_builder = merge_builder.whenMatchedUpdateAll()
        elif merge_on_match == "steward_wins":
            # Preserve steward overrides (origin='manual'). For other rows, source wins.
            merge_builder = merge_builder.whenMatchedUpdate(
                condition="t.origin != 'manual'",
                set={c: f"s.{c}" for c in final.columns},
            )
        elif merge_on_match == "flag_for_review":
            # Don't touch existing row; instead emit a DLQ entry below.
            pass

        # Insert branch
        if merge_on_insert == "auto_insert":
            merge_builder = merge_builder.whenNotMatchedInsertAll()
        else:
            # flag_for_review on insert — caller emits a DLQ row instead.
            pass

        merge_builder.execute()

        # ------------- Reconcile orphans -----------------------------
        src_master = self._entity_master(src_type.lower().replace(" ", "_"))
        dst_master = self._entity_master(dst_type.lower().replace(" ", "_"))
        spark.sql(
            f"""
            UPDATE {table}
            SET status = 'inactive', updated_at = current_timestamp(), updated_by = 'auto_orphan'
            WHERE edge_type = '{edge_type}'
              AND (
                src_node_id NOT IN (SELECT lakefusion_id FROM {src_master})
                OR dst_node_id NOT IN (SELECT lakefusion_id FROM {dst_master})
              )
              AND (origin IS NULL OR origin != 'manual')
            """
        )

        # ------------- DLQ writes ------------------------------------
        if dlq_rows is not None:
            dlq_rows.write.format("delta").mode("append").saveAsTable(dlq_table)
        if cardinality_conflicts is not None:
            cardinality_conflicts.write.format("delta").mode("append").saveAsTable(dlq_table)

        promoted_count = final.count()
        dlq_count = (dlq_rows.count() if dlq_rows is not None else 0) + (
            cardinality_conflicts.count() if cardinality_conflicts is not None else 0
        )

        return {
            "relationship": rel_name,
            "promoted": promoted_count,
            "dlq": dlq_count,
        }

    # ------------------------------------------------------------------
    # BaseTask
    # ------------------------------------------------------------------

    def execute(self) -> TaskResult:
        config = self.context.relationship_config or self.context.state.get(
            "relationship_config"
        )
        if not config:
            raise ValueError(
                "relationship_config missing on context. Run ParseRelationshipJsonTask first."
            )
        merge_config = config.get("merge_config") or {
            "on_match": "source_wins",
            "on_new_record": "auto_insert",
        }
        for rel_entry in config["relationships"]:
            # Make the current relationship available to context property helpers.
            self.context.relationship_name = rel_entry["relationship"]["name"]
            summary = self._process_relationship(rel_entry, merge_config)
            self.logger.info(f"Relationship summary: {summary}")
            self._summary["relationships"].append(summary)
            self._summary["rows_promoted"] += summary.get("promoted", 0)
            self._summary["rows_dlq"] += summary.get("dlq", 0)

        return TaskResult(status=TaskStatus.SUCCESS, values=self._summary)

    def validate(self) -> ValidationResult:
        if not self._summary.get("relationships"):
            return ValidationResult(
                is_valid=False, errors=["No relationships processed"]
            )
        return ValidationResult(is_valid=True)
