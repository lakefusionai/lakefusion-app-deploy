"""
Parse Relationship Sync configuration JSON (Story 2).

Reads the snapshot uploaded to the UC Volume by the middlelayer at task-create
time, validates it, and populates ``TaskContext.relationship_config`` so the
downstream Materialize Edges task can iterate the configured relationships +
mappings without an extra round-trip to the application database.
"""

import json
from typing import Any, Dict

from ...base import BaseTask
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class ParseRelationshipJsonTask(BaseTask):
    """Load the relationship_sync.json snapshot from the entity's UC Volume."""

    def __init__(self, context: TaskContext, override_instance: Any = None):
        super().__init__(context, override_instance=override_instance)
        self.logger = context.params.get("logger") or self.logger

    def execute(self) -> TaskResult:
        spark = self.context.spark
        catalog = self.context.catalog_name
        entity_id = self.context.entity_id
        experiment_id = self.context.experiment_id or "prod"

        # Volume layout matches what CatalogService.create_volume_folder() returns.
        volume_path = (
            f"/Volumes/{catalog}/integration_hub/{entity_id}/{experiment_id}/"
            "relationship_sync.json"
        )
        self.logger.info(f"Reading relationship sync config from {volume_path}")

        df = spark.read.text(volume_path, wholetext=True)
        raw = df.collect()[0][0]
        config: Dict[str, Any] = json.loads(raw)

        if not config.get("relationships"):
            raise ValueError(
                f"relationship_sync.json at {volume_path} contains no relationships"
            )

        self.context.relationship_config = config
        # Persist into TaskContext.state so downstream tasks can read it
        # without re-reading the file.
        self.context.state["relationship_config"] = config
        self.context.state["relationship_count"] = len(config["relationships"])

        return TaskResult(
            status=TaskStatus.SUCCESS,
            values={
                "relationship_count": len(config["relationships"]),
                "task_name": config.get("task_name"),
            },
        )

    def validate(self) -> ValidationResult:
        cfg = self.context.relationship_config
        if not cfg or not cfg.get("relationships"):
            return ValidationResult(
                is_valid=False,
                errors=["relationship_config missing on context"],
            )
        return ValidationResult(is_valid=True)
