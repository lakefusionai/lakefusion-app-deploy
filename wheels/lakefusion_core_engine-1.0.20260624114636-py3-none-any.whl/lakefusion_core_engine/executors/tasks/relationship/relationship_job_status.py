"""
Relationship Job Status task (Story 2).

Final notebook in the relationship sync DAG. Logs run summary and emits a
TaskResult that surface to the IntHub UI. Run-time analytics (rows promoted /
DLQ / failures per relationship) come from ``TaskContext.state``.
"""

from typing import Any

from ...base import BaseTask
from ...models import TaskContext, TaskResult, TaskStatus, ValidationResult


class RelationshipJobStatusTask(BaseTask):
    def __init__(self, context: TaskContext, override_instance: Any = None):
        super().__init__(context, override_instance=override_instance)
        self.logger = context.params.get("logger") or self.logger

    def execute(self) -> TaskResult:
        summary = self.context.state.get("materialize_summary") or {
            "relationships": [],
            "rows_promoted": 0,
            "rows_dlq": 0,
        }
        self.logger.info("=" * 60)
        self.logger.info(
            f"RELATIONSHIP SYNC SUMMARY (task={self.context.task_name})"
        )
        self.logger.info(
            f"  relationships processed: {len(summary.get('relationships', []))}"
        )
        self.logger.info(f"  rows promoted: {summary.get('rows_promoted', 0)}")
        self.logger.info(f"  rows DLQ: {summary.get('rows_dlq', 0)}")
        self.logger.info("=" * 60)
        return TaskResult(status=TaskStatus.SUCCESS, values=summary)

    def validate(self) -> ValidationResult:
        return ValidationResult(is_valid=True)
