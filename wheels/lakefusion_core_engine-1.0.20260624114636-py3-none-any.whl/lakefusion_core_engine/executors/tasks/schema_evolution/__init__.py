"""
Schema Evolution tasks module.

Contains task executors for schema evolution pipeline operations:
    - ParseSchemaEvolutionJsonExecutor: Parse evolution JSON configuration
    - AlterTablesExecutor: Add columns to master/unified tables
    - BackfillFromSourcesExecutor: Backfill new columns from source data
    - SyncDerivedTablesExecutor: Sync derived tables (potential_match, unified_dedup)
    - UpdateMatchConfigExecutor: Update match config (attributes_combined, VS index)
    - ValidateSchemaEvolutionExecutor: Validate columns exist after evolution
    - RollbackSchemaEvolutionExecutor: Rollback (drop) columns added by evolution

Usage:
------
    from lakefusion_core_engine.executors.tasks.schema_evolution import ParseSchemaEvolutionJsonExecutor
    executor = ParseSchemaEvolutionJsonExecutor(context)
"""

from .parse_schema_evolution_json import ParseSchemaEvolutionJsonExecutor
from .alter_tables import AlterTablesExecutor
from .backfill_from_sources import BackfillFromSourcesExecutor
from .sync_derived_tables import SyncDerivedTablesExecutor
from .update_match_config import UpdateMatchConfigExecutor
from .validate_schema_evolution import ValidateSchemaEvolutionExecutor
from .rollback_schema_evolution import RollbackSchemaEvolutionExecutor

__all__ = [
    'ParseSchemaEvolutionJsonExecutor',
    'AlterTablesExecutor',
    'BackfillFromSourcesExecutor',
    'SyncDerivedTablesExecutor',
    'UpdateMatchConfigExecutor',
    'ValidateSchemaEvolutionExecutor',
    'RollbackSchemaEvolutionExecutor',
]
