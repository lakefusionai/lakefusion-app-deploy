"""
Parse Schema Evolution JSON Executor.

Reads the schema evolution JSON configuration file from Volume and
extracts all parameters for downstream schema evolution tasks.

Workflow:
1. Read JSON file from Volume path
2. Extract configuration (edits, table names, entity info)
3. Set task values for downstream tasks via on_success()
"""

import json
from typing import Any, Dict, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult, ValidationResult
from lakefusion_core_engine.utils.taskvalues_enum import TaskValueKey


class ParseSchemaEvolutionJsonExecutor(BaseStepTask):
    """
    Executor for parsing schema evolution JSON configuration.

    Reads the evolution JSON file and extracts all parameters needed
    for the Alter, Backfill, Validate, and Rollback tasks.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.evolution_json = {}
        self.parsed_values = {}
        self.logger = context.params.get("logger") or self.logger

    @property
    def job_id(self) -> str:
        """Get schema evolution job ID from params."""
        return self.context.params.get('job_id', '')

    @property
    def entity_id(self) -> str:
        """Get entity ID from params."""
        return self.context.params.get('entity_id', '')

    @property
    def json_path(self) -> str:
        """Get the schema evolution JSON file path."""
        file_name = f"entity_{self.entity_id}_schema_evolution_{self.job_id}.json"
        return f"/Volumes/{self.context.catalog_name}/metadata/metadata_files/{file_name}"

    def pre_execute(self) -> None:
        """Validate inputs and log configuration."""
        self.logger.info("=" * 80)
        self.logger.info("PARSING SCHEMA EVOLUTION JSON")
        self.logger.info("=" * 80)
        self.logger.info(f"Job ID: {self.job_id}")
        self.logger.info(f"Entity ID: {self.entity_id}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"JSON Path: {self.json_path}")
        self.logger.info("=" * 80)

    @step(order=1, name="Read JSON File", returns="dict - parsed evolution JSON")
    def step_read_json_file(self) -> Dict[str, Any]:
        """Read and parse the schema evolution JSON file from Volume."""
        try:
            with open(self.json_path, 'r') as f:
                evolution_json_str = f.read()
            self.evolution_json = json.loads(evolution_json_str)
            self.logger.info(f"  Schema evolution JSON loaded from: {self.json_path}")
            return self.evolution_json
        except Exception as e:
            raise ValueError(f"Failed to read schema evolution JSON: {e}")

    @step(order=2, name="Extract Configuration", returns="dict - extracted config values")
    def step_extract_config(self) -> Dict[str, Any]:
        """Extract all configuration fields from the parsed JSON."""
        self.parsed_values = {
            'schema_evolution_job_id': str(self.evolution_json['job_id']),
            'schema_evolution_edits': json.dumps(self.evolution_json['edits']),
            'schema_evolution_master_table': self.evolution_json['master_table'],
            'schema_evolution_unified_table': self.evolution_json['unified_table'],
            'schema_evolution_avs_table': self.evolution_json['attribute_version_sources_table'],
            'schema_evolution_entity_name': self.evolution_json['entity_name'],
            'schema_evolution_catalog_name': self.evolution_json['catalog_name'],
            'schema_evolution_id_key': self.evolution_json['id_key'],
            'schema_evolution_experiment_id': self.evolution_json['experiment_id'],
        }

        self.logger.info(f"  Entity: {self.parsed_values['schema_evolution_entity_name']}")
        self.logger.info(f"  Job ID: {self.parsed_values['schema_evolution_job_id']}")
        self.logger.info(f"  Edits: {len(self.evolution_json['edits'])}")
        self.logger.info(f"  Master Table: {self.parsed_values['schema_evolution_master_table']}")
        self.logger.info(f"  Unified Table: {self.parsed_values['schema_evolution_unified_table']}")
        self.logger.info(f"  AVS Table: {self.parsed_values['schema_evolution_avs_table']}")

        return self.parsed_values

    def execute(self) -> TaskResult:
        """Execute the parse schema evolution JSON workflow."""
        self.step_read_json_file()
        self.step_extract_config()

        return TaskResult.success(
            message=f"Parsed schema evolution JSON for entity '{self.parsed_values.get('schema_evolution_entity_name')}'",
            task_name=self.context.task_name,
            metrics={
                'entity_name': self.parsed_values.get('schema_evolution_entity_name'),
                'job_id': self.parsed_values.get('schema_evolution_job_id'),
                'edits_count': len(self.evolution_json.get('edits', [])),
            },
            task_values=self.parsed_values,
        )

    def on_success(self, result: TaskResult) -> None:
        """Set task values for downstream schema evolution tasks."""
        if self.context.dbutils:
            dbutils = self.context.dbutils
            tv = result.task_values

            dbutils.jobs.taskValues.set(TaskValueKey.SCHEMA_EVOLUTION_JOB_ID.value, tv.get('schema_evolution_job_id'))
            dbutils.jobs.taskValues.set(TaskValueKey.SCHEMA_EVOLUTION_EDITS.value, tv.get('schema_evolution_edits'))
            dbutils.jobs.taskValues.set(TaskValueKey.SCHEMA_EVOLUTION_MASTER_TABLE.value, tv.get('schema_evolution_master_table'))
            dbutils.jobs.taskValues.set(TaskValueKey.SCHEMA_EVOLUTION_UNIFIED_TABLE.value, tv.get('schema_evolution_unified_table'))
            dbutils.jobs.taskValues.set(TaskValueKey.SCHEMA_EVOLUTION_AVS_TABLE.value, tv.get('schema_evolution_avs_table'))
            dbutils.jobs.taskValues.set(TaskValueKey.SCHEMA_EVOLUTION_ENTITY_NAME.value, tv.get('schema_evolution_entity_name'))
            dbutils.jobs.taskValues.set(TaskValueKey.SCHEMA_EVOLUTION_CATALOG_NAME.value, tv.get('schema_evolution_catalog_name'))
            dbutils.jobs.taskValues.set(TaskValueKey.SCHEMA_EVOLUTION_ID_KEY.value, tv.get('schema_evolution_id_key'))
            dbutils.jobs.taskValues.set(TaskValueKey.SCHEMA_EVOLUTION_EXPERIMENT_ID.value, tv.get('schema_evolution_experiment_id'))

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Parse schema evolution JSON failed: {result.message}")
        if result.errors:
            for err in result.errors:
                self.logger.error(f"  Error: {err}")
