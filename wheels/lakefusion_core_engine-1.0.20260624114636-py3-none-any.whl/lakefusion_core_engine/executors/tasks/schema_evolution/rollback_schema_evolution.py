"""
Rollback Schema Evolution Executor.

Rolls back a schema evolution job by dropping columns that were added
to master, unified, and unified_deduplicate Delta tables, then rebuilds
potential_match tables to remove rolled-back attributes from nested structs.
If any rolled-back edits were match attributes, recomputes attributes_combined
on master and unified tables to exclude them.

Standalone executor — reads the evolution JSON directly from Volume
(not from task values) since rollback is a one-time operation.

Workflow:
1. Read schema evolution JSON from Volume
2. For each ADD_ATTRIBUTE edit, DROP COLUMN from master, unified, and unified_deduplicate
3. Rebuild potential_match and potential_match_deduplicate tables (if they exist)
   so the ARRAY<STRUCT> no longer contains the rolled-back attributes
4. Revert match config — recompute attributes_combined if any rolled-back edit
   was a match attribute (skips if none)
"""

import json
from typing import Any, Dict, List, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult


class RollbackSchemaEvolutionExecutor(BaseStepTask):
    """
    Executor for rolling back schema evolution changes.

    Drops columns added by ADD_ATTRIBUTE edits from master, unified, and
    unified_deduplicate tables. Then rebuilds potential_match tables so the
    nested ARRAY<STRUCT> reflects the rolled-back schema.
    Idempotent — skips columns that don't exist, skips tables that don't exist.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.logger = context.params.get("logger") or self.logger
        self.edits = []
        self.master_table_name = ''
        self.unified_table_name = ''
        self.entity_name = ''
        self.experiment_id = 'prod'
        self.rollback_count = 0

    @property
    def job_id(self) -> str:
        """Get schema evolution job ID from params."""
        return self.context.params.get('job_id', '')

    @property
    def entity_id(self) -> str:
        """Get entity ID from params."""
        return self.context.params.get('entity_id', '')

    @property
    def json_path(self) -> str:
        """Get the schema evolution JSON file path."""
        return f"/Volumes/{self.context.catalog_name}/metadata/metadata_files/entity_{self.entity_id}_schema_evolution_{self.job_id}.json"

    @property
    def entity_json_path(self) -> str:
        """Get entity JSON file path for reading entity_attributes."""
        return f"/Volumes/{self.context.catalog_name}/metadata/metadata_files/entity_{self.entity_id}_prod_entity.json"

    @property
    def model_json_path(self) -> str:
        """Get model JSON file path for reading match attributes."""
        return f"/Volumes/{self.context.catalog_name}/metadata/metadata_files/entity_{self.entity_id}_{self.experiment_id}_model.json"

    @property
    def unified_dedup_table(self) -> str:
        """Get unified_deduplicate table name."""
        if not self.entity_name:
            return ""
        suffix = f"_{self.experiment_id}" if self.experiment_id else ""
        return f"{self.context.catalog_name}.silver.{self.entity_name}_unified_deduplicate{suffix}"

    @property
    def potential_match_table(self) -> str:
        """Get potential_match table name."""
        if not self.entity_name:
            return ""
        suffix = f"_{self.experiment_id}" if self.experiment_id else ""
        return f"{self.context.catalog_name}.gold.{self.entity_name}_master_potential_match{suffix}"

    @property
    def potential_match_dedup_table(self) -> str:
        """Get potential_match_deduplicate table name."""
        if not self.entity_name:
            return ""
        suffix = f"_{self.experiment_id}" if self.experiment_id else ""
        return f"{self.context.catalog_name}.gold.{self.entity_name}_master_potential_match_deduplicate{suffix}"

    def pre_execute(self) -> None:
        """Log configuration."""
        self.logger.info("=" * 80)
        self.logger.info("SCHEMA EVOLUTION - ROLLBACK")
        self.logger.info("=" * 80)
        self.logger.info(f"Job ID: {self.job_id}")
        self.logger.info(f"Entity ID: {self.entity_id}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"JSON Path: {self.json_path}")
        self.logger.info("=" * 80)

    @step(order=1, name="Read Evolution JSON", returns="dict - edits, master_table, unified_table")
    def step_read_evolution_json(self) -> Dict[str, Any]:
        """Read schema evolution JSON from Volume."""
        evolution_json_str = self.dbutils.fs.head(self.json_path)
        config = json.loads(evolution_json_str)

        self.edits = config.get('edits', [])
        self.master_table_name = config.get('master_table', '')
        self.unified_table_name = config.get('unified_table', '')
        self.entity_name = config.get('entity_name', '')
        self.experiment_id = config.get('experiment_id', 'prod')

        self.logger.info(f"  Entity name: {self.entity_name}")
        self.logger.info(f"  Experiment ID: {self.experiment_id}")
        self.logger.info(f"  Master table: {self.master_table_name}")
        self.logger.info(f"  Unified table: {self.unified_table_name}")
        self.logger.info(f"  Edits to rollback: {len(self.edits)}")

        return {
            'edits_count': len(self.edits),
            'master_table': self.master_table_name,
            'unified_table': self.unified_table_name,
            'entity_name': self.entity_name,
        }

    def _enable_column_mapping(self, table_name: str) -> None:
        """Enable Delta column mapping on a table so DROP COLUMN is supported.
        Idempotent — safe to call on tables that already have it enabled."""
        try:
            self.spark.sql(f"""
                ALTER TABLE {table_name} SET TBLPROPERTIES (
                    'delta.columnMapping.mode' = 'name',
                    'delta.minReaderVersion' = '2',
                    'delta.minWriterVersion' = '5'
                )
            """)
            self.logger.info(f"  Enabled column mapping on {table_name}")
        except Exception as e:
            if "already enabled" in str(e).lower() or "already set" in str(e).lower():
                self.logger.info(f"  Column mapping already enabled on {table_name}")
            else:
                raise

    @step(order=2, name="Drop Columns", returns="int - rollback count")
    def step_drop_columns(self) -> int:
        """Drop columns from master, unified, and unified_deduplicate tables."""
        self.rollback_count = 0

        # Enable column mapping on all target tables (required for DROP COLUMN)
        self.logger.info("  Enabling column mapping on target tables...")
        self._enable_column_mapping(self.master_table_name)
        self._enable_column_mapping(self.unified_table_name)
        if self.unified_dedup_table and self.spark.catalog.tableExists(self.unified_dedup_table):
            self._enable_column_mapping(self.unified_dedup_table)

        for edit in self.edits:
            if edit.get('action_type') != 'ADD_ATTRIBUTE':
                continue

            attr_name = edit['attribute_name']
            self.logger.info(f"\n  Rolling back attribute: `{attr_name}`")

            # ── Drop from master table (idempotent) ──
            master_cols = [f.name for f in self.spark.table(self.master_table_name).schema]
            if attr_name in master_cols:
                self.spark.sql(f"ALTER TABLE {self.master_table_name} DROP COLUMN (`{attr_name}`)")
                self.logger.info(f"  Dropped `{attr_name}` from master table")
            else:
                self.logger.info(f"  `{attr_name}` not found in master table - already removed")

            # ── Drop from unified table (idempotent) ──
            unified_cols = [f.name for f in self.spark.table(self.unified_table_name).schema]
            if attr_name in unified_cols:
                self.spark.sql(f"ALTER TABLE {self.unified_table_name} DROP COLUMN (`{attr_name}`)")
                self.logger.info(f"  Dropped `{attr_name}` from unified table")
            else:
                self.logger.info(f"  `{attr_name}` not found in unified table - already removed")

            # ── Drop from unified_deduplicate table (if exists, idempotent) ──
            if self.unified_dedup_table and self.spark.catalog.tableExists(self.unified_dedup_table):
                dedup_cols = [f.name for f in self.spark.table(self.unified_dedup_table).schema]
                if attr_name in dedup_cols:
                    self.spark.sql(f"ALTER TABLE {self.unified_dedup_table} DROP COLUMN (`{attr_name}`)")
                    self.logger.info(f"  Dropped `{attr_name}` from unified_deduplicate table")
                else:
                    self.logger.info(f"  `{attr_name}` not found in unified_deduplicate table - already removed")

            self.rollback_count += 1

        return self.rollback_count

    @step(order=3, name="Rebuild Derived Tables", returns="dict - rebuild results")
    def step_rebuild_derived_tables(self) -> Dict[str, Any]:
        """Rebuild potential_match tables so the ARRAY<STRUCT> excludes rolled-back attrs."""
        if not self.entity_name:
            self.logger.info("  No entity_name available - skipping derived table rebuild")
            return {'skipped': True}

        # Get the rolled-back attribute names
        rolled_back_attrs = {
            edit['attribute_name']
            for edit in self.edits
            if edit.get('action_type') == 'ADD_ATTRIBUTE'
        }

        if not rolled_back_attrs:
            return {'skipped': True, 'reason': 'no_add_attribute_edits'}

        # Read entity.json to get the current entity_attributes
        # Subtract rolled-back attrs to get the post-rollback list
        entity_attributes = self._get_post_rollback_entity_attributes(rolled_back_attrs)
        self.logger.info(f"  Post-rollback entity attributes: {len(entity_attributes)}")

        results = {}

        # ── Rebuild potential_match (if exists) ──
        if self.potential_match_table and self.spark.catalog.tableExists(self.potential_match_table):
            self.logger.info(f"  Dropping potential_match table for clean rebuild: {self.potential_match_table}")
            self.spark.sql(f"DROP TABLE IF EXISTS {self.potential_match_table}")
            self.logger.info(f"  Rebuilding potential_match table: {self.potential_match_table}")
            results['potential_match'] = self._rebuild_potential_match(entity_attributes)
        else:
            self.logger.info(f"  Potential match table does not exist - skipping")
            results['potential_match'] = 'skipped'

        # ── Rebuild potential_match_deduplicate (if exists — golden dedup may not be enabled) ──
        if self.potential_match_dedup_table and self.spark.catalog.tableExists(self.potential_match_dedup_table):
            try:
                self.logger.info(f"  Dropping potential_match_dedup table for clean rebuild: {self.potential_match_dedup_table}")
                self.spark.sql(f"DROP TABLE IF EXISTS {self.potential_match_dedup_table}")
                self.logger.info(f"  Rebuilding potential_match_deduplicate table: {self.potential_match_dedup_table}")
                results['potential_match_dedup'] = self._rebuild_potential_match_dedup(entity_attributes)
            except Exception as e:
                self.logger.warning(f"  Golden dedup potential_match rebuild failed (golden dedup may not be enabled): {e}")
                results['potential_match_dedup'] = 'skipped_error'
        else:
            self.logger.info(f"  Potential match dedup table does not exist - skipping")
            results['potential_match_dedup'] = 'skipped'

        return results

    def _get_post_rollback_entity_attributes(self, rolled_back_attrs: set) -> List[str]:
        """Read entity.json and subtract rolled-back attributes to get the post-rollback list."""
        try:
            with open(self.entity_json_path, 'r') as f:
                entity_json = json.loads(f.read())
            all_attrs = [item["name"] for item in entity_json.get("attributes", [])]
        except Exception as e:
            self.logger.warning(f"  Could not read entity.json: {e}. Falling back to master table schema.")
            # Fallback: derive from master table schema (post-drop), excluding system columns
            system_cols = {
                'lakefusion_id', 'attributes_combined', 'source_path', 'source_id',
                'record_status', 'scoring_results', 'search_results', 'master_lakefusion_id',
                'surrogate_key', 'created_at', 'updated_at', 'version',
            }
            all_attrs = [
                f.name for f in self.spark.table(self.master_table_name).schema
                if f.name not in system_cols
            ]

        # Subtract the rolled-back attributes
        return [attr for attr in all_attrs if attr not in rolled_back_attrs]

    def _rebuild_potential_match(self, entity_attributes: List[str]) -> str:
        """Rebuild the potential_match table using ProcessPotentialMatchExecutor."""
        from ..integration_core.normal_deduplication.process_potential_match import ProcessPotentialMatchExecutor

        sub_context = TaskContext(
            task_name="Process_Potential_Match_Rollback",
            entity=self.entity_name,
            experiment_id=self.experiment_id,
            catalog_name=self.context.catalog_name,
            spark=self.context.spark,
            dbutils=self.context.dbutils,
            params={
                'entity_attributes': entity_attributes,
                'logger': self.logger,
            }
        )

        executor = ProcessPotentialMatchExecutor(sub_context, override_instance=None)
        result = executor.run()
        self.logger.info(f"  Potential match rebuild: {result.status.value} - {result.message}")
        return result.status.value

    def _rebuild_potential_match_dedup(self, entity_attributes: List[str]) -> str:
        """Rebuild the potential_match_deduplicate table using GoldenProcessPotentialMatchExecutor."""
        from ..integration_core.golden_deduplication.process_potential_match import GoldenProcessPotentialMatchExecutor

        sub_context = TaskContext(
            task_name="Process_Potential_Match_Dedup_Rollback",
            entity=self.entity_name,
            experiment_id=self.experiment_id,
            catalog_name=self.context.catalog_name,
            spark=self.context.spark,
            dbutils=self.context.dbutils,
            params={
                'entity_attributes': entity_attributes,
                'logger': self.logger,
            }
        )

        executor = GoldenProcessPotentialMatchExecutor(sub_context, override_instance=None)
        result = executor.run()
        self.logger.info(f"  Potential match dedup rebuild: {result.status.value} - {result.message}")
        return result.status.value

    @step(order=4, name="Revert Match Config", returns="dict - revert results")
    def step_revert_match_config(self) -> Dict[str, Any]:
        """Always recompute attributes_combined during rollback.

        The forward SE path (Update_Match_Config) may have modified attributes_combined
        even for non-match attributes (e.g. when the job was cancelled mid-execution).
        Always recompute from model.json to ensure consistency.
        """
        rolled_back_attrs = {
            edit['attribute_name']
            for edit in self.edits
            if edit.get('action_type') == 'ADD_ATTRIBUTE'
        }

        # Read model.json to get current match attributes
        # model.json was NOT updated (job failed/cancelled before complete_job ran)
        current_match_attrs = []
        try:
            with open(self.model_json_path, 'r') as f:
                model_json = json.loads(f.read())
            attribute_objects = model_json.get('attributes', [])
            current_match_attrs = [attr.get('name') for attr in attribute_objects if attr.get('name')]
            self.logger.info(f"  Current match attributes from model.json: {current_match_attrs}")
        except FileNotFoundError:
            self.logger.warning(f"  Model JSON not found at {self.model_json_path} — clearing attributes_combined")
        except Exception as e:
            self.logger.warning(f"  Failed to read model JSON: {e} — clearing attributes_combined")

        # Filter out any rolled-back attrs (safety — model.json should already exclude them)
        final_match_attrs = [a for a in current_match_attrs if a not in rolled_back_attrs]
        self.logger.info(f"  Final match attributes after rollback: {final_match_attrs}")

        if final_match_attrs:
            match_cols = ", ".join([f"CAST(`{a}` AS STRING)" for a in final_match_attrs])
            concat_expr = f"concat_ws(' | ', {match_cols})"
        else:
            concat_expr = "''"

        # Update master table
        tables_updated = []
        self.logger.info(f"  Recomputing attributes_combined on master table: {self.master_table_name}")
        self.spark.sql(f"UPDATE {self.master_table_name} SET attributes_combined = {concat_expr}")
        tables_updated.append(self.master_table_name)

        # Update unified table
        self.logger.info(f"  Recomputing attributes_combined on unified table: {self.unified_table_name}")
        self.spark.sql(f"UPDATE {self.unified_table_name} SET attributes_combined = {concat_expr}")
        tables_updated.append(self.unified_table_name)

        # Update unified_deduplicate table (if exists)
        if self.unified_dedup_table and self.spark.catalog.tableExists(self.unified_dedup_table):
            self.logger.info(f"  Recomputing attributes_combined on unified_dedup table: {self.unified_dedup_table}")
            self.spark.sql(f"UPDATE {self.unified_dedup_table} SET attributes_combined = {concat_expr}")
            tables_updated.append(self.unified_dedup_table)

        return {
            'rolled_back_attrs': list(rolled_back_attrs),
            'final_match_attrs': final_match_attrs,
            'tables_updated': tables_updated,
        }

    @step(order=5, name="Drop Vector Search Index", returns="dict - drop result")
    def step_drop_vs_index(self) -> Dict[str, Any]:
        """Drop the VS index after column drops to avoid CDF schema incompatibility.

        Column drops change the Delta table schema. The VS index uses CDF to track
        changes and cannot reconcile schema changes across versions. Dropping the
        index forces the normal pipeline to recreate it with the correct schema.
        """
        index_name = f"{self.master_table_name}_index"
        self.logger.info(f"  Dropping VS index: {index_name}")

        try:
            from databricks.sdk import WorkspaceClient
            w = WorkspaceClient()
            w.vector_search_indexes.delete_index(index_name=index_name)
            self.logger.info(f"  VS index dropped successfully: {index_name}")
            return {'dropped': True, 'index_name': index_name}
        except Exception as e:
            error_msg = str(e).lower()
            if "not found" in error_msg or "does not exist" in error_msg or "resource_does_not_exist" in error_msg:
                self.logger.info(f"  VS index does not exist — skipping: {index_name}")
                return {'dropped': False, 'reason': 'not_found'}
            else:
                self.logger.warning(f"  Failed to drop VS index (non-fatal): {e}")
                return {'dropped': False, 'reason': str(e)}

    def execute(self) -> TaskResult:
        """Execute the rollback workflow."""
        self.step_read_evolution_json()
        self.step_drop_columns()
        self.step_rebuild_derived_tables()
        self.step_revert_match_config()
        self.step_drop_vs_index()

        return TaskResult.success(
            message=f"Rollback completed: {self.rollback_count} attribute(s) rolled back",
            task_name=self.context.task_name,
            metrics={
                'attributes_rolled_back': self.rollback_count,
            },
        )

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Rollback failed: {result.message}")
        if result.errors:
            for err in result.errors:
                self.logger.error(f"  Error: {err}")
