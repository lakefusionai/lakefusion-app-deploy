"""
Sync Derived Tables Executor for Schema Evolution.

After schema evolution adds new attributes to master and unified tables,
this executor syncs all derived tables so everything is consistent:

1. unified_deduplicate — full clone from master (INSERT OVERWRITE)
2. potential_match — rebuilt via ProcessPotentialMatchExecutor
3. potential_match_deduplicate — rebuilt via GoldenProcessPotentialMatchExecutor

Only processes tables that already exist. Tables that don't exist are skipped
(they will be created naturally on the next pipeline run).

Note: entity.json is NOT updated until complete_job() (after the Databricks job),
so pre_execute() augments entity_attributes with new attributes from the SE edits.

Workflow:
1. Read entity.json + augment with SE edits to get full entity_attributes
2. Full clone master → unified_deduplicate (INSERT OVERWRITE)
3. Rebuild potential_match table (if exists)
4. Rebuild potential_match_deduplicate table (if exists)
"""

import json
from typing import Any, Dict, List, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult


class SyncDerivedTablesExecutor(BaseStepTask):
    """
    Executor for syncing derived tables after schema evolution.

    Ensures unified_deduplicate, potential_match, and potential_match_deduplicate
    tables are updated with the new schema after ALTER TABLE operations.
    Only processes tables that already exist.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.logger = context.params.get("logger") or self.logger
        self.entity_json = {}
        self.entity_name = ""
        self.entity_attributes = []
        self.new_se_attrs = []
        self.id_key = "lakefusion_id"
        self._stats = {}

    @property
    def entity_id(self) -> str:
        """Get entity ID from params."""
        return self.context.params.get('entity_id', '')

    @property
    def experiment_id(self) -> str:
        """Get experiment ID from context."""
        return self.context.experiment_id or 'prod'

    @property
    def entity_json_path(self) -> str:
        """Get entity JSON file path (same as ParseEntityModelJsonExecutor)."""
        return f"/Volumes/{self.context.catalog_name}/metadata/metadata_files/entity_{self.entity_id}_prod_entity.json"

    @property
    def unified_dedup_table(self) -> str:
        """Get unified_deduplicate table name."""
        suffix = f"_{self.experiment_id}" if self.experiment_id else ""
        return f"{self.context.catalog_name}.silver.{self.entity_name}_unified_deduplicate{suffix}"

    @property
    def potential_match_table(self) -> str:
        """Get potential_match table name."""
        suffix = f"_{self.experiment_id}" if self.experiment_id else ""
        return f"{self.context.catalog_name}.gold.{self.entity_name}_master_potential_match{suffix}"

    @property
    def potential_match_dedup_table(self) -> str:
        """Get potential_match_deduplicate table name."""
        suffix = f"_{self.experiment_id}" if self.experiment_id else ""
        return f"{self.context.catalog_name}.gold.{self.entity_name}_master_potential_match_deduplicate{suffix}"

    def pre_execute(self) -> None:
        """Read entity.json and extract configuration."""
        self.logger.info("=" * 80)
        self.logger.info("SCHEMA EVOLUTION - SYNC DERIVED TABLES")
        self.logger.info("=" * 80)
        self.logger.info(f"Entity ID: {self.entity_id}")
        self.logger.info(f"Catalog: {self.context.catalog_name}")
        self.logger.info(f"Experiment ID: {self.experiment_id}")
        self.logger.info(f"Entity JSON Path: {self.entity_json_path}")
        self.logger.info("=" * 80)

        # Read entity.json
        try:
            with open(self.entity_json_path, 'r') as f:
                self.entity_json = json.loads(f.read())
        except Exception as e:
            raise ValueError(f"Failed to read entity JSON: {e}")

        self.entity_name = self.entity_json.get("name", "").lower().replace(" ", "_")
        self.entity_attributes = [item["name"] for item in self.entity_json.get("attributes", [])]
        self.id_key = "lakefusion_id"

        # entity.json hasn't been updated yet (happens at complete_job()),
        # so augment entity_attributes with new attributes from SE edits
        edits_raw = self.context.params.get('edits', '[]')
        edits = json.loads(edits_raw) if isinstance(edits_raw, str) else edits_raw
        self.new_se_attrs = []
        for edit in edits:
            if edit.get('action_type') == 'ADD_ATTRIBUTE':
                attr_name = edit['attribute_name']
                if attr_name not in self.entity_attributes:
                    self.entity_attributes.append(attr_name)
                    self.new_se_attrs.append(attr_name)

        self.logger.info(f"Entity Name: {self.entity_name}")
        self.logger.info(f"Entity Attributes (from entity.json): {len(self.entity_attributes) - len(self.new_se_attrs)}")
        self.logger.info(f"New SE Attributes (from edits): {self.new_se_attrs}")
        self.logger.info(f"Total Entity Attributes: {len(self.entity_attributes)}")
        self.logger.info(f"Unified Dedup Table: {self.unified_dedup_table}")
        self.logger.info(f"Potential Match Table: {self.potential_match_table}")
        self.logger.info(f"Potential Match Dedup Table: {self.potential_match_dedup_table}")

    @step(order=1, name="Sync Unified Dedup From Master", returns="dict - sync result")
    def step_sync_unified_dedup_from_master(self) -> Dict[str, Any]:
        """Sync unified_deduplicate from master, preserving dedup-only columns.

        Uses MERGE to update all columns that exist in master (entity attributes,
        attributes_combined, new SE columns) while preserving columns that only
        exist in unified_dedup (search_results, scoring_results, etc.).
        """
        if not self.spark.catalog.tableExists(self.unified_dedup_table):
            self.logger.info(f"  Unified dedup table does not exist — skipping: {self.unified_dedup_table}")
            self._stats['unified_dedup_synced'] = False
            return {'synced': False, 'reason': 'table_not_found'}

        suffix = f"_{self.experiment_id}" if self.experiment_id else ""
        master_table = f"{self.context.catalog_name}.gold.{self.entity_name}_master{suffix}"

        self.logger.info(f"  Syncing unified_dedup from master (preserving dedup-only columns)")
        self.logger.info(f"  Source: {master_table}")
        self.logger.info(f"  Target: {self.unified_dedup_table}")

        # Columns in both tables → update from master
        # Columns only in dedup (search_results, scoring_results, etc.) → preserved
        dedup_col_set = set(f.name for f in self.spark.table(self.unified_dedup_table).schema)
        master_col_set = set(f.name for f in self.spark.table(master_table).schema)
        shared_cols = dedup_col_set & master_col_set
        dedup_only_cols = dedup_col_set - master_col_set

        # Don't include lakefusion_id in SET clause (it's the join key)
        update_cols = [c for c in shared_cols if c != 'lakefusion_id']

        self.logger.info(f"  Columns to update from master: {len(update_cols)}")
        self.logger.info(f"  Columns preserved in dedup: {dedup_only_cols}")

        set_clause = ", ".join([f"t.`{c}` = s.`{c}`" for c in update_cols])

        self.spark.sql(f"""
            MERGE INTO {self.unified_dedup_table} t
            USING {master_table} s
            ON t.lakefusion_id = s.lakefusion_id
            WHEN MATCHED THEN UPDATE SET {set_clause}
        """)

        self.logger.info(f"  Unified dedup synced from master (dedup-only columns preserved)")
        self._stats['unified_dedup_synced'] = True
        return {'synced': True}

    @step(order=2, name="Rebuild Potential Match", returns="dict - rebuild result")
    def step_rebuild_potential_match(self) -> Dict[str, Any]:
        """Rebuild potential_match table (if it exists)."""
        if not self.spark.catalog.tableExists(self.potential_match_table):
            self.logger.info(f"  Potential match table does not exist - skipping: {self.potential_match_table}")
            self._stats['potential_match_rebuilt'] = False
            return {'rebuilt': False, 'reason': 'table_not_found'}

        self.logger.info(f"  Rebuilding potential_match table: {self.potential_match_table}")

        from ..integration_core.normal_deduplication.process_potential_match import ProcessPotentialMatchExecutor

        sub_context = TaskContext(
            task_name="Process_Potential_Match_SE",
            entity=self.entity_name,
            experiment_id=self.experiment_id,
            catalog_name=self.context.catalog_name,
            spark=self.context.spark,
            dbutils=self.context.dbutils,
            params={
                'entity_attributes': self.entity_attributes,
                'logger': self.logger,
            }
        )

        executor = ProcessPotentialMatchExecutor(sub_context, override_instance=None)
        result = executor.run()

        self.logger.info(f"  Potential match rebuild result: {result.status.value} - {result.message}")
        self._stats['potential_match_rebuilt'] = True
        return {'rebuilt': True, 'status': result.status.value}

    @step(order=3, name="Rebuild Potential Match Deduplicate", returns="dict - rebuild result")
    def step_rebuild_potential_match_dedup(self) -> Dict[str, Any]:
        """Rebuild potential_match_deduplicate table (if it exists)."""
        if not self.spark.catalog.tableExists(self.potential_match_dedup_table):
            self.logger.info(f"  Potential match dedup table does not exist - skipping: {self.potential_match_dedup_table}")
            self._stats['potential_match_dedup_rebuilt'] = False
            return {'rebuilt': False, 'reason': 'table_not_found'}

        self.logger.info(f"  Rebuilding potential_match_deduplicate table: {self.potential_match_dedup_table}")

        from ..integration_core.golden_deduplication.process_potential_match import GoldenProcessPotentialMatchExecutor

        sub_context = TaskContext(
            task_name="Process_Potential_Match_Dedup_SE",
            entity=self.entity_name,
            experiment_id=self.experiment_id,
            catalog_name=self.context.catalog_name,
            spark=self.context.spark,
            dbutils=self.context.dbutils,
            params={
                'entity_attributes': self.entity_attributes,
                'logger': self.logger,
            }
        )

        executor = GoldenProcessPotentialMatchExecutor(sub_context, override_instance=None)
        result = executor.run()

        self.logger.info(f"  Potential match dedup rebuild result: {result.status.value} - {result.message}")
        self._stats['potential_match_dedup_rebuilt'] = True
        return {'rebuilt': True, 'status': result.status.value}

    def execute(self) -> TaskResult:
        """Execute the sync derived tables workflow."""
        # Step 1: Full clone of master → unified_dedup
        self.step_sync_unified_dedup_from_master()

        # Step 2: Rebuild potential_match
        self.step_rebuild_potential_match()

        # Step 3: Rebuild potential_match_deduplicate
        self.step_rebuild_potential_match_dedup()

        synced_count = sum(1 for v in [
            self._stats.get('unified_dedup_synced'),
            self._stats.get('potential_match_rebuilt'),
            self._stats.get('potential_match_dedup_rebuilt'),
        ] if v)

        return TaskResult.success(
            message=f"Sync derived tables completed: {synced_count} table(s) synced/rebuilt",
            task_name=self.context.task_name,
            metrics=self._stats,
        )

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Sync derived tables failed: {result.message}")
        if result.errors:
            for err in result.errors:
                self.logger.error(f"  Error: {err}")
