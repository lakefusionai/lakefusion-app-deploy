"""
Update Match Config Executor for Schema Evolution.

When a schema evolution job includes match attributes (is_match_attribute=true),
this executor:
1. Reads model.json to get current match attributes and VS config
2. Updates attributes_combined on master and unified tables for ALL records
3. Drops the Vector Search index (the VS notebook recreates it on next pipeline run)

If no edits have is_match_attribute=true, this executor skips entirely (no-op).

Workflow:
1. Check edits for match attributes — skip if none
2. Read model.json for current match attrs and VS endpoint
3. Recompute attributes_combined on master + unified tables
4. Drop the Vector Search index
"""

import json
from typing import Any, Dict, List, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult


class UpdateMatchConfigExecutor(BaseStepTask):
    """
    Executor for updating match configuration after schema evolution.

    Updates attributes_combined and drops the VS index when new match
    attributes are added. Skips entirely if no match attributes in edits.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.logger = context.params.get("logger") or self.logger
        self.edits = []
        self.new_match_attrs = []
        self.all_match_attrs = []
        self.vs_endpoint = ''
        self._has_match_attrs = False

    @property
    def entity_id(self) -> str:
        """Get entity ID from params."""
        return self.context.params.get('entity_id', '')

    @property
    def experiment_id(self) -> str:
        """Get experiment ID from context."""
        return self.context.experiment_id or 'prod'

    @property
    def edits_json(self) -> str:
        """Get edits JSON string from params."""
        return self.context.params.get('edits', '[]')

    @property
    def master_table(self) -> str:
        """Get master table name from params."""
        return self.context.params.get('master_table', '')

    @property
    def unified_table(self) -> str:
        """Get unified table name from params."""
        return self.context.params.get('unified_table', '')

    @property
    def unified_dedup_table(self) -> str:
        """Get unified_deduplicate table name (derived from unified table name)."""
        # unified = catalog.silver.entity_unified_exp → dedup = catalog.silver.entity_unified_deduplicate_exp
        return self.unified_table.replace('_unified_', '_unified_deduplicate_')

    @property
    def model_json_path(self) -> str:
        """Get model JSON file path."""
        return f"/Volumes/{self.context.catalog_name}/metadata/metadata_files/entity_{self.entity_id}_{self.experiment_id}_model.json"

    def pre_execute(self) -> None:
        """Parse edits and check for match attributes."""
        edits_raw = self.edits_json
        self.edits = json.loads(edits_raw) if isinstance(edits_raw, str) else edits_raw

        self.new_match_attrs = [
            edit['attribute_name']
            for edit in self.edits
            if edit.get('action_type') == 'ADD_ATTRIBUTE' and edit.get('is_match_attribute')
        ]

        self._has_match_attrs = len(self.new_match_attrs) > 0

        self.logger.info("=" * 80)
        self.logger.info("SCHEMA EVOLUTION - UPDATE MATCH CONFIG")
        self.logger.info("=" * 80)
        self.logger.info(f"Entity ID: {self.entity_id}")
        self.logger.info(f"Master Table: {self.master_table}")
        self.logger.info(f"Unified Table: {self.unified_table}")
        self.logger.info(f"New match attributes: {self.new_match_attrs}")
        self.logger.info(f"Has match attributes: {self._has_match_attrs}")
        self.logger.info("=" * 80)

    @step(order=1, name="Read Model Config", returns="dict - model config")
    def step_read_model_config(self) -> Dict[str, Any]:
        """Read model.json to get current match attributes and VS endpoint."""
        if not self._has_match_attrs:
            self.logger.info("  No match attributes in edits — skipping")
            return {'skipped': True}

        existing_match_attrs = []
        self.vs_endpoint = ''

        try:
            with open(self.model_json_path, 'r') as f:
                model_json = json.loads(f.read())

            attribute_objects = model_json.get('attributes', [])
            existing_match_attrs = [
                attr.get('name') for attr in attribute_objects if attr.get('name')
            ]
            self.vs_endpoint = model_json.get('vs_endpoint', '')

            self.logger.info(f"  Existing match attributes: {existing_match_attrs}")
            self.logger.info(f"  VS endpoint: {self.vs_endpoint}")

        except FileNotFoundError:
            self.logger.warning(f"  Model JSON not found at {self.model_json_path} — using only new match attrs")
        except Exception as e:
            self.logger.warning(f"  Failed to read model JSON: {e} — using only new match attrs")

        # Build full match attribute list: existing + new (deduped, preserving order)
        self.all_match_attrs = list(existing_match_attrs)
        for attr in self.new_match_attrs:
            if attr not in self.all_match_attrs:
                self.all_match_attrs.append(attr)

        self.logger.info(f"  All match attributes (combined): {self.all_match_attrs}")

        return {
            'existing_match_attrs': existing_match_attrs,
            'new_match_attrs': self.new_match_attrs,
            'all_match_attrs': self.all_match_attrs,
            'vs_endpoint': self.vs_endpoint,
        }

    @step(order=2, name="Update Attributes Combined", returns="dict - update result")
    def step_update_attributes_combined(self) -> Dict[str, Any]:
        """Recompute attributes_combined on master and unified tables for ALL records."""
        if not self._has_match_attrs:
            self.logger.info("  No match attributes — skipping")
            return {'skipped': True}

        if not self.all_match_attrs:
            self.logger.warning("  No match attributes to combine — skipping")
            return {'skipped': True, 'reason': 'no_match_attrs'}

        # Use COALESCE to preserve null positions as empty strings between separators
        match_cols = ", ".join([f"COALESCE(CAST(`{a}` AS STRING), '')" for a in self.all_match_attrs])

        # Update master table
        self.logger.info(f"  Updating attributes_combined on master table: {self.master_table}")
        master_sql = f"UPDATE {self.master_table} SET attributes_combined = concat_ws(' | ', {match_cols})"
        self.spark.sql(master_sql)
        self.logger.info(f"  Master table attributes_combined updated")

        # Update unified table
        self.logger.info(f"  Updating attributes_combined on unified table: {self.unified_table}")
        self.spark.sql(f"UPDATE {self.unified_table} SET attributes_combined = concat_ws(' | ', {match_cols})")
        self.logger.info(f"  Unified table attributes_combined updated")

        # Update unified_deduplicate table (if exists)
        tables_updated = [self.master_table, self.unified_table]
        if self.unified_dedup_table and self.spark.catalog.tableExists(self.unified_dedup_table):
            self.logger.info(f"  Updating attributes_combined on unified_dedup table: {self.unified_dedup_table}")
            self.spark.sql(f"UPDATE {self.unified_dedup_table} SET attributes_combined = concat_ws(' | ', {match_cols})")
            self.logger.info(f"  Unified dedup table attributes_combined updated")
            tables_updated.append(self.unified_dedup_table)

        return {
            'tables_updated': tables_updated,
            'match_attrs_count': len(self.all_match_attrs),
        }

    @step(order=3, name="Drop Vector Search Index", returns="dict - drop result")
    def step_drop_vs_index(self) -> Dict[str, Any]:
        """Drop the Vector Search index so it's recreated on next pipeline run."""
        if not self._has_match_attrs:
            self.logger.info("  No match attributes — skipping")
            return {'skipped': True}

        index_name = f"{self.master_table}_index"

        if not self.vs_endpoint:
            self.logger.warning(f"  No VS endpoint configured — skipping index drop")
            return {'skipped': True, 'reason': 'no_vs_endpoint'}

        self.logger.info(f"  Dropping VS index: {index_name} (endpoint: {self.vs_endpoint})")

        try:
            from databricks.sdk import WorkspaceClient

            w = WorkspaceClient()
            w.vector_search_indexes.delete_index(index_name=index_name)
            self.logger.info(f"  VS index dropped successfully: {index_name}")
            return {'dropped': True, 'index_name': index_name}

        except Exception as e:
            error_msg = str(e).lower()
            if "not found" in error_msg or "does not exist" in error_msg or "resource_does_not_exist" in error_msg:
                self.logger.info(f"  VS index does not exist — skipping: {index_name}")
                return {'dropped': False, 'reason': 'not_found'}
            else:
                self.logger.error(f"  Failed to drop VS index: {e}")
                raise

    def execute(self) -> TaskResult:
        """Execute the match config update workflow."""
        if not self._has_match_attrs:
            return TaskResult.success(
                message="No match attributes in edits — skipped",
                task_name=self.context.task_name,
                metrics={'skipped': True},
            )

        self.step_read_model_config()
        self.step_update_attributes_combined()
        self.step_drop_vs_index()

        return TaskResult.success(
            message=f"Match config updated: {len(self.new_match_attrs)} new match attribute(s), attributes_combined recomputed, VS index dropped",
            task_name=self.context.task_name,
            metrics={
                'new_match_attrs': len(self.new_match_attrs),
                'total_match_attrs': len(self.all_match_attrs),
            },
        )

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Update match config failed: {result.message}")
        if result.errors:
            for err in result.errors:
                self.logger.error(f"  Error: {err}")
