"""
Validate Schema Evolution Executor.

Validates that all ADD_ATTRIBUTE columns have been successfully added
to master, unified, and derived tables (unified_deduplicate, potential_match).

Workflow:
1. For each ADD_ATTRIBUTE edit, verify column exists in master and unified schemas
2. If entity_name is available, also validate derived tables:
   - unified_deduplicate: new columns present as top-level columns
   - potential_match: new columns present in the potential_matches ARRAY<STRUCT>
   - potential_match_deduplicate: same struct validation
3. Return FAILED if any columns are missing, SUCCESS if all present
"""

import json
from typing import Any, Dict, List, Optional

from ...step_task import BaseStepTask
from ...decorators import step
from ...models import TaskContext, TaskResult


class ValidateSchemaEvolutionExecutor(BaseStepTask):
    """
    Executor for validating schema evolution results.

    Checks that all expected columns exist in master, unified, and derived tables.
    Returns FAILED result if any columns are missing, causing Databricks
    to mark the task as FAILED.
    """

    def __init__(self, context: TaskContext):
        super().__init__(context)
        self.logger = context.params.get("logger") or self.logger
        self.edits = []
        self.validation_errors = []

    @property
    def entity_name(self) -> str:
        """Get entity name from params or context."""
        return self.context.params.get('entity_name', '') or self.context.entity

    @property
    def edits_json(self) -> str:
        """Get edits JSON string from params."""
        return self.context.params.get('edits', '[]')

    @property
    def master_table(self) -> str:
        """Get master table name from params."""
        return self.context.params.get('master_table', '')

    @property
    def unified_table(self) -> str:
        """Get unified table name from params."""
        return self.context.params.get('unified_table', '')

    def pre_execute(self) -> None:
        """Parse edits and log configuration."""
        edits_raw = self.edits_json
        self.edits = json.loads(edits_raw) if isinstance(edits_raw, str) else edits_raw

        self.logger.info("=" * 80)
        self.logger.info("SCHEMA EVOLUTION - VALIDATE")
        self.logger.info("=" * 80)
        self.logger.info(f"Entity Name: {self.entity_name}")
        self.logger.info(f"Master Table: {self.master_table}")
        self.logger.info(f"Unified Table: {self.unified_table}")
        self.logger.info(f"Edits count: {len(self.edits)}")
        self.logger.info("=" * 80)

    @step(order=1, name="Validate Columns", returns="dict - validation result")
    def step_validate_columns(self) -> Dict[str, Any]:
        """Verify all ADD_ATTRIBUTE columns exist in master and unified tables."""
        for edit in self.edits:
            if edit.get('action_type') != 'ADD_ATTRIBUTE':
                continue

            attr_name = edit['attribute_name']

            # Verify column exists in master table (schema-only, no data scan)
            master_col_names = {f.name for f in self.spark.table(self.master_table).schema}
            if attr_name not in master_col_names:
                self.validation_errors.append(
                    f"Column '{attr_name}' missing from master table '{self.master_table}'"
                )

            # Verify column exists in unified table (schema-only, no data scan)
            unified_col_names = {f.name for f in self.spark.table(self.unified_table).schema}
            if attr_name not in unified_col_names:
                self.validation_errors.append(
                    f"Column '{attr_name}' missing from unified table '{self.unified_table}'"
                )

        return {
            'errors_so_far': len(self.validation_errors),
        }

    @step(order=2, name="Validate Derived Tables", returns="dict - derived validation result")
    def step_validate_derived_tables(self) -> Dict[str, Any]:
        """Verify new columns exist in derived tables (if they exist)."""
        entity = self.entity_name
        if not entity:
            self.logger.info("  No entity_name available - skipping derived table validation")
            return {'skipped': True}

        catalog = self.context.catalog_name
        experiment_id = self.context.experiment_id
        suffix = f"_{experiment_id}" if experiment_id else ""

        add_attrs = [
            edit['attribute_name']
            for edit in self.edits
            if edit.get('action_type') == 'ADD_ATTRIBUTE'
        ]

        if not add_attrs:
            return {'skipped': True, 'reason': 'no_add_attribute_edits'}

        # ── Validate unified_deduplicate (if exists) ──
        unified_dedup = f"{catalog}.silver.{entity}_unified_deduplicate{suffix}"
        if self.spark.catalog.tableExists(unified_dedup):
            dedup_cols = {f.name for f in self.spark.table(unified_dedup).schema}
            for attr_name in add_attrs:
                if attr_name not in dedup_cols:
                    self.validation_errors.append(
                        f"Column '{attr_name}' missing from unified_deduplicate table '{unified_dedup}'"
                    )
            self.logger.info(f"  Validated unified_deduplicate table: {unified_dedup}")
        else:
            self.logger.info(f"  Unified dedup table does not exist - skipping: {unified_dedup}")

        # ── Validate potential_match struct includes new attrs (if exists) ──
        pm_table = f"{catalog}.gold.{entity}_master_potential_match{suffix}"
        if self.spark.catalog.tableExists(pm_table):
            self._validate_potential_match_struct(pm_table, add_attrs)
            self.logger.info(f"  Validated potential_match table: {pm_table}")
        else:
            self.logger.info(f"  Potential match table does not exist - skipping: {pm_table}")

        # ── Validate potential_match_deduplicate struct (if exists) ──
        pm_dedup_table = f"{catalog}.gold.{entity}_master_potential_match_deduplicate{suffix}"
        if self.spark.catalog.tableExists(pm_dedup_table):
            self._validate_potential_match_struct(pm_dedup_table, add_attrs)
            self.logger.info(f"  Validated potential_match_deduplicate table: {pm_dedup_table}")
        else:
            self.logger.info(f"  Potential match dedup table does not exist - skipping: {pm_dedup_table}")

        return {'derived_tables_validated': True}

    def _validate_potential_match_struct(self, table_name: str, attr_names: List[str]) -> None:
        """Validate that new attributes exist in the potential_matches ARRAY<STRUCT> field."""
        from pyspark.sql.types import ArrayType, StructType

        schema = self.spark.table(table_name).schema

        for field in schema:
            if field.name == "potential_matches":
                # Navigate into ARRAY<STRUCT>
                if isinstance(field.dataType, ArrayType) and isinstance(field.dataType.elementType, StructType):
                    struct_fields = {sf.name for sf in field.dataType.elementType.fields}
                    for attr_name in attr_names:
                        if attr_name not in struct_fields:
                            self.validation_errors.append(
                                f"Column '{attr_name}' missing from potential_matches struct in '{table_name}'"
                            )
                break

    def execute(self) -> TaskResult:
        """Execute the validation workflow."""
        self.validation_errors = []

        # Step 1: Validate master and unified columns
        self.step_validate_columns()

        # Step 2: Validate derived tables
        self.step_validate_derived_tables()

        passed = len(self.validation_errors) == 0

        if passed:
            self.logger.info("  All validations passed - all columns present in all tables")
        else:
            for err in self.validation_errors:
                self.logger.error(f"  VALIDATION ERROR: {err}")

        if not passed:
            error_msg = "; ".join(self.validation_errors)
            # Return FAILED result - BaseTask.run() will call on_failure and re-raise
            raise Exception(f"Schema evolution validation failed: {error_msg}")

        return TaskResult.success(
            message="Schema evolution validation passed - all columns present",
            task_name=self.context.task_name,
            metrics={
                'validations_passed': True,
                'columns_validated': len([
                    e for e in self.edits if e.get('action_type') == 'ADD_ATTRIBUTE'
                ]),
            },
        )

    def on_failure(self, result: TaskResult, error: Optional[Exception] = None) -> None:
        """Handle failed execution."""
        self.logger.error(f"Schema evolution validation failed: {result.message}")
        if result.errors:
            for err in result.errors:
                self.logger.error(f"  Error: {err}")
