"""
Lakefusion ID Generation for MDM Pipeline.

Generates unique lakefusion IDs for master records.
"""

import hashlib
import uuid
import re


def generate_lakefusion_id(source_path: str = None, source_id: str = None) -> str:
    """
    Generate a unique lakefusion_id for master records.
    
    If source_path and source_id are provided, generates deterministic ID.
    Otherwise generates random UUID.
    
    Args:
        source_path: Optional source table path for deterministic generation
        source_id: Optional source record ID for deterministic generation
        
    Returns:
        lakefusion_id string (without 'lf_' prefix)
    """
    if source_path and source_id:
        # Deterministic: hash of source_path + source_id
        composite = f"lf_{source_path}_{source_id}"
        return hashlib.md5(composite.encode()).hexdigest()
    else:
        # Random UUID (for backward compatibility)
        return str(uuid.uuid4()).replace("-", "")


def generate_lakefusion_id_with_prefix(prefix: str = "") -> str:
    """
    Generate a lakefusion ID with an optional prefix.
    
    Note: Currently not used in the standard pipeline, but available for
    future extensions or special use cases.
    
    Args:
        prefix: Optional prefix to prepend to the ID
        
    Returns:
        Lakefusion ID with prefix
        
    Examples:
        >>> id1 = generate_lakefusion_id_with_prefix("test_")
        >>> id1.startswith("test_")
        True
    """
    base_id = generate_lakefusion_id()
    return f"{prefix}{base_id}" if prefix else base_id


def validate_lakefusion_id(lakefusion_id: str) -> bool:
    """
    Validate that a lakefusion ID has the correct format.
    
    Args:
        lakefusion_id: The lakefusion ID to validate
        
    Returns:
        True if valid, False otherwise
        
    Examples:
        >>> validate_lakefusion_id("a7c829c674f54664a2c9dd7b1f2363fc")
        True
        
        >>> validate_lakefusion_id("a7c829c6-74f5-4664-a2c9-dd7b1f2363fc")
        False
        
        >>> validate_lakefusion_id("invalid")
        False
    """
    if not isinstance(lakefusion_id, str):
        return False
    
    # Should be exactly 32 characters (UUID4 without dashes)
    if len(lakefusion_id) != 32:
        return False
    
    # Should only contain hexadecimal characters
    hex_pattern = re.compile(r'^[0-9a-f]{32}$', re.IGNORECASE)
    return bool(hex_pattern.match(lakefusion_id))


def format_lakefusion_id(lakefusion_id: str, with_dashes: bool = False) -> str:
    """
    Format a lakefusion ID with or without dashes.
    
    Useful for display purposes or when interfacing with systems that expect
    standard UUID format.
    
    Args:
        lakefusion_id: The lakefusion ID to format
        with_dashes: If True, format as standard UUID with dashes
        
    Returns:
        Formatted lakefusion ID
        
    Examples:
        >>> format_lakefusion_id("a7c829c674f54664a2c9dd7b1f2363fc", with_dashes=True)
        'a7c829c6-74f5-4664-a2c9-dd7b1f2363fc'
        
        >>> format_lakefusion_id("a7c829c6-74f5-4664-a2c9-dd7b1f2363fc", with_dashes=False)
        'a7c829c674f54664a2c9dd7b1f2363fc'
    """
    # Remove any existing dashes
    clean_id = lakefusion_id.replace('-', '')
    
    if not validate_lakefusion_id(clean_id):
        raise ValueError(f"Invalid lakefusion_id: {lakefusion_id}")
    
    if with_dashes:
        # Format as: 8-4-4-4-12
        return f"{clean_id[:8]}-{clean_id[8:12]}-{clean_id[12:16]}-{clean_id[16:20]}-{clean_id[20:]}"
    else:
        return clean_id


def batch_generate_lakefusion_ids(count: int) -> list[str]:
    """
    Generate multiple lakefusion IDs efficiently.
    
    Args:
        count: Number of IDs to generate
        
    Returns:
        List of lakefusion IDs
        
    Examples:
        >>> ids = batch_generate_lakefusion_ids(5)
        >>> len(ids)
        5
        >>> len(set(ids))  # All should be unique
        5
    """
    return [generate_lakefusion_id() for _ in range(count)]


def is_surrogate_key(identifier: str) -> bool:
    """
    Check if an identifier is a surrogate key (vs lakefusion ID).
    
    Useful when handling mixed identifier types.
    
    Args:
        identifier: The identifier to check
        
    Returns:
        True if it's a surrogate key, False if it's a lakefusion ID (or invalid)
        
    Examples:
        >>> is_surrogate_key("sk_a7c829c674f54664a2c9dd7b1f2363fc")
        True
        
        >>> is_surrogate_key("a7c829c674f54664a2c9dd7b1f2363fc")
        False
    """
    return isinstance(identifier, str) and identifier.startswith("sk_")