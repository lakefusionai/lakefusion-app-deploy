"""
LakebasePgClient — lightweight psycopg2 adapter for Lakebase Autoscaling
Postgres, designed for FastAPI / middlelayer use (no Spark dependency).

Auth + host resolution use the native `w.postgres.*` SDK service (Lakebase
Autoscaling: projects / branches / endpoints). The surface is plain SQL that
takes Python primitives instead of Spark DataFrames. Use as a context manager
so the connection is closed at the end of the FastAPI request:

    with LakebasePgClient.from_db_config(db_config_service) as pg:
        pg.execute("INSERT INTO ...", (val1, val2))
        rows = pg.query("SELECT * FROM ... WHERE id = %s", (id,))

Connection-health probe (SELECT 1) is done before each statement so a
stale connection (server-side close, token expiration) is detected and
rebuilt transparently.

--------------------------------------------------------------------------
SDK alignment (databricks.sdk.service.postgres.PostgresAPI, stable):

  * Resources use hierarchical resource names. `name` is output-only and
    holds the full path projects/{project_id}/branches/{branch_id}/
    endpoints/{endpoint_id}. lakebase_instance_id is the project_id.
  * Endpoint resolution: w.postgres.get_endpoint(name=<endpoint path>)
    returns an Endpoint whose host is at status.hosts.host.
  * Credentials: w.postgres.generate_database_credential(endpoint=<path>)
    -> DatabaseCredential.token. The endpoint arg is the full endpoint
    resource path.

This client is autoscaling-only. It requires databricks-sdk new enough to
expose `w.postgres` (upgrade with: pip install --upgrade databricks-sdk).
--------------------------------------------------------------------------
"""

import logging
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("LakebasePgClient")


def _attr(obj, *path):
    """Safe nested getattr — returns None if any link is missing."""
    for a in path:
        if obj is None:
            return None
        obj = getattr(obj, a, None)
    return obj


def _endpoint_host(ep) -> Optional[str]:
    """Pull the connection host off an Endpoint. Per the stable SDK the host
    lives at status.hosts.host; the other candidates are defensive for SDK
    point-release field drift."""
    return (
        _attr(ep, "status", "hosts", "host")
        or _attr(ep, "status", "host")
        or _attr(ep, "hosts", "host")
        or _attr(ep, "host")
    )


def _resolve_lakebase(ws, instance_id, branch_id="production", endpoint_id="primary"):
    """Resolve Lakebase Autoscaling connection info via the native w.postgres
    SDK service.

    lakebase_instance_id IS the project_id (last segment of the project
    resource name projects/{project_id}). The endpoint resource path is built
    directly as:
        projects/{instance_id}/branches/{branch_id}/endpoints/{endpoint_id}
    and resolved with w.postgres.get_endpoint(name=...).

    Returns:
      {"kind": "postgres", "host": <dns>, "endpoint_name": <resource path>}

    Raises RuntimeError with the available projects if resolution fails.
    """
    if not hasattr(ws, "postgres"):
        raise RuntimeError(
            "w.postgres service unavailable — the installed databricks-sdk is "
            "too old for Lakebase Autoscaling. Upgrade it "
            "(pip install --upgrade databricks-sdk) and restart Python."
        )

    endpoint_name = (
        f"projects/{instance_id}/branches/{branch_id}/endpoints/{endpoint_id}"
    )

    try:
        ep = ws.postgres.get_endpoint(name=endpoint_name)
    except Exception as e:
        logger.warning(
            f"[lakebase-resolve] get_endpoint('{endpoint_name}') failed: {e}"
        )
        ep = None

    if ep is not None:
        host = _endpoint_host(ep)
        if host and "." in host:
            logger.info(
                f"[lakebase-resolve] resolved '{instance_id}' "
                f"({branch_id}/{endpoint_id}) -> {host}"
            )
            return {"kind": "postgres", "host": host, "endpoint_name": endpoint_name}
        logger.warning(
            f"[lakebase-resolve] endpoint '{endpoint_name}' returned no usable "
            f"host (status.hosts.host missing). Endpoint state: "
            f"{_attr(ep, 'status', 'current_state')}"
        )

    # Resolution failed — surface what projects ARE available so a misconfigured
    # lakebase_instance_id / branch_id / endpoint_id is obvious.
    try:
        projects = [
            (p.name, getattr(p, "display_name", None))
            for p in ws.postgres.list_projects()
        ]
    except Exception as e:
        projects = f"<list_projects failed: {e}>"

    raise RuntimeError(
        f"Lakebase Autoscaling endpoint '{endpoint_name}' could not be "
        f"resolved. Check lakebase_instance_id (must equal the project_id), "
        f"lakebase_branch_id ('{branch_id}'), and lakebase_endpoint_id "
        f"('{endpoint_id}'). Available projects (name, display_name): {projects}"
    )


def _mint_lakebase_token(ws, conn: dict) -> str:
    """Mint a fresh OAuth JWT for a resolved Lakebase connection.

    w.postgres.generate_database_credential(endpoint=<endpoint resource path>)
    -> DatabaseCredential.token. The `endpoint` is the full endpoint path, not
    the project.
    """
    cred = ws.postgres.generate_database_credential(
        endpoint=conn["endpoint_name"]
    )
    return cred.token


def _pg_user_from_token(token: str, ws=None) -> Optional[str]:
    """Extract the Postgres role name from a Lakebase OAuth JWT.

    The role is the token's `sub` claim. Decoded from the JWT payload directly
    (base64, no signature check) to avoid a hard PyJWT dependency. Falls back
    to the workspace current-user name if decoding fails.
    """
    try:
        import base64
        import json as _json

        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)  # pad to a multiple of 4
        sub = _json.loads(base64.urlsafe_b64decode(payload.encode())).get("sub")
        if sub:
            return sub
    except Exception:
        pass
    return ws.current_user.me().user_name if ws is not None else None


class LakebasePgClient:
    """Lakebase Autoscaling Postgres adapter for non-Spark contexts.

    Resolves the endpoint host and mints OAuth-JWT credentials via the native
    `w.postgres.*` SDK service, then talks plain SQL through psycopg2.

    Lifecycle:
      - Construct via LakebasePgClient(...) or LakebasePgClient.from_db_config(...).
      - Use as a context manager OR call close() explicitly.
      - The connection is built lazily on first use and recycled on
        health-probe failure (which catches stale connections from
        idle timeout / token expiry).
    """

    # ---- Construction --------------------------------------------------------

    def __init__(
        self,
        instance_id: str,
        branch_id: str = "production",
        endpoint_id: str = "primary",
        database: str = "databricks_postgres",
        user: Optional[str] = None,
        endpoint_name: Optional[str] = None,
        workspace_client=None,
    ):
        """
        Args:
            instance_id:   Lakebase Autoscaling project_id (last segment of the
                           project resource name projects/{project_id}). Used to
                           build the endpoint path
                           projects/{instance_id}/branches/{branch_id}/endpoints/{endpoint_id}.
            branch_id:     branch_id segment of the endpoint path. Default "production".
            endpoint_id:   endpoint_id segment of the endpoint path. Default "primary".
            database:      Postgres logical database. Default "databricks_postgres".
            user:          Postgres role override. Defaults to the credential's
                           JWT `sub` claim (the role the token authenticates as).
            endpoint_name: Optional explicit full endpoint resource path override
                           (projects/{p}/branches/{b}/endpoints/{e}). When set,
                           instance_id/branch_id/endpoint_id are ignored for path
                           construction.
            workspace_client: Pre-authenticated databricks.sdk.WorkspaceClient.
                           Required where the default SDK auth chain can't resolve
                           credentials (e.g. the FastAPI middlelayer). When omitted,
                           a bare WorkspaceClient() is constructed (works inside
                           notebooks / Databricks Apps).
        """
        self._instance_id = instance_id
        self._branch_id = branch_id
        self._endpoint_id = endpoint_id
        self._database = database
        self._user_override = user
        self._endpoint_name_override = endpoint_name

        # Lazy state — resolved on first use
        self._ws = workspace_client
        self._conn_info = None        # resolver result (kind/host/endpoint_name)
        self._host = None
        self._user = None
        self._pg_conn = None

    @classmethod
    def from_db_config(
        cls,
        db_config_service,
        user: Optional[str] = None,
        database: Optional[str] = None,
        workspace_client=None,
    ):
        """Construct from db_config_properties keys.

        Reads:
          - lakebase_instance_id (required; the project_id)
          - lakebase_branch_id  (default "production")
          - lakebase_endpoint_id (default "primary")
          - lakebase_database   (default "databricks_postgres")
          - lakebase_endpoint_name (optional full endpoint path override)

        Args:
            database: Optional explicit Postgres database name. Overrides the
                `lakebase_database` config key — used by callers that route
                per-entity (database == sanitized entity name).
            workspace_client: Pre-authenticated WorkspaceClient (see __init__).
        """
        return cls(
            instance_id   = db_config_service.getDBConfigProperties(
                "lakebase_instance_id", required=True
            ),
            branch_id     = db_config_service.getDBConfigProperties(
                "lakebase_branch_id"
            ) or "production",
            endpoint_id   = db_config_service.getDBConfigProperties(
                "lakebase_endpoint_id"
            ) or "primary",
            database      = database or db_config_service.getDBConfigProperties(
                "lakebase_database"
            ) or "databricks_postgres",
            endpoint_name = db_config_service.getDBConfigProperties(
                "lakebase_endpoint_name"
            ),
            user          = user,
            workspace_client = workspace_client,
        )

    # ---- Endpoint / auth resolution -----------------------------------------

    def _ensure_workspace(self):
        if self._ws is None:
            from databricks.sdk import WorkspaceClient
            self._ws = WorkspaceClient()
        return self._ws

    def trigger_synced_table_sync(self, synced_table_name: str) -> None:
        """Trigger a refresh of a Databricks Lakebase synced table so
        PostgreSQL re-materializes from the latest Delta state.

        Used after a UI write has been reverse-synced into Delta: the synced
        table is the Databricks-managed mirror of Delta, so re-running its
        backing pipeline reconciles Postgres with the authoritative Delta
        state (and keeps the sync's commit bookkeeping current).

        Non-fatal: Delta is the source of truth, so a failed trigger leaves
        Postgres briefly stale but loses no data. start_update is
        non-blocking — it kicks the pipeline and returns.

        Args:
            synced_table_name: Full 3-part UC name of the synced table,
                e.g. "catalog.gold.acme_reference_prod_synced".
        """
        try:
            ws = self._ensure_workspace()
            synced = ws.postgres.get_synced_table(
                name=f"synced_tables/{synced_table_name}"
            )
            pipeline_id = (
                _attr(synced, "data_synchronization_status", "pipeline_id")
                or _attr(synced, "status", "pipeline_id")
            )
            if not pipeline_id:
                logger.warning(
                    f"No backing pipeline_id on synced table "
                    f"{synced_table_name}; cannot trigger sync."
                )
                return
            ws.pipelines.start_update(pipeline_id=pipeline_id)
            logger.info(
                f"Triggered sync for {synced_table_name} (pipeline={pipeline_id})"
            )
        except Exception as e:
            logger.warning(f"Failed to trigger sync for {synced_table_name}: {e}")

    def _resolve_endpoint(self):
        """Populate self._conn_info, self._host, self._user on first use."""
        if self._host is not None:
            return

        ws = self._ensure_workspace()

        if self._endpoint_name_override:
            # Caller supplied the full endpoint resource path directly.
            try:
                ep = ws.postgres.get_endpoint(name=self._endpoint_name_override)
            except Exception as e:
                raise RuntimeError(
                    f"endpoint_name override '{self._endpoint_name_override}' "
                    f"could not be resolved via w.postgres.get_endpoint: {e}"
                )
            host = _endpoint_host(ep)
            if not host or "." not in host:
                raise RuntimeError(
                    f"endpoint_name override '{self._endpoint_name_override}' "
                    f"returned no usable host."
                )
            self._conn_info = {
                "kind": "postgres",
                "host": host,
                "endpoint_name": self._endpoint_name_override,
            }
        else:
            self._conn_info = _resolve_lakebase(
                ws, self._instance_id, self._branch_id, self._endpoint_id
            )

        self._host = self._conn_info["host"]
        if not self._host or "." not in self._host:
            raise RuntimeError(
                f"Lakebase instance {self._instance_id} returned no usable host."
            )

        # The Postgres role must match the credential's principal — the JWT
        # `sub` claim — which is the reliable role name for both users and
        # service principals (current_user can differ for an SP).
        self._user = self._user_override or _pg_user_from_token(
            self._fresh_token(), ws
        )
        logger.info(
            f"Lakebase ready: {self._instance_id} ({self._conn_info['kind']}) "
            f"@ {self._host} as {self._user}"
        )

    def _fresh_token(self) -> str:
        """Mint a fresh OAuth JWT for the Postgres connection.

        Uses the SAME (possibly injected/authenticated) WorkspaceClient as
        the rest of the client. The middlelayer injects a token-authenticated
        client; building a bare WorkspaceClient() here would ignore that auth
        and fall back to default credentials (which don't exist in the
        middlelayer), so credential minting must go through _ensure_workspace.
        """
        ws = self._ensure_workspace()
        return _mint_lakebase_token(ws, self._conn_info)

    # ---- Connection management ----------------------------------------------

    def _get_pg_connection(self):
        """Return a live psycopg2 connection. Health-probes a cached
        connection first; rebuilds on any probe failure (stale conn,
        expired token, server-side disconnect)."""
        import psycopg2

        self._resolve_endpoint()

        # 1. Try reusing the cached connection
        if self._pg_conn is not None and not self._pg_conn.closed:
            try:
                with self._pg_conn.cursor() as cur:
                    cur.execute("SELECT 1")
                return self._pg_conn
            except (psycopg2.OperationalError, psycopg2.InterfaceError):
                try:
                    self._pg_conn.close()
                except Exception:
                    pass
                self._pg_conn = None

        # 2. Build a fresh connection
        self._pg_conn = psycopg2.connect(
            host=self._host,
            dbname=self._database,
            user=self._user,
            password=self._fresh_token(),
            sslmode="require",
        )
        # Default to autocommit so each statement is its own transaction.
        # Failed statements don't leave the connection in aborted state.
        # transaction() context manager toggles this off when explicit
        # multi-statement transactions are needed.
        self._pg_conn.autocommit = True
        return self._pg_conn

    def close(self):
        """Close the underlying psycopg2 connection if open."""
        if self._pg_conn is not None and not self._pg_conn.closed:
            try:
                self._pg_conn.close()
            except Exception:
                pass
        self._pg_conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # ---- Low-level SQL surface ----------------------------------------------

    def execute(self, sql: str, params: Optional[Tuple] = None) -> int:
        """Execute a DDL/DML statement. Returns affected row count.

        Retries once on InterfaceError / OperationalError so a stale-cursor
        failure (which can sneak past the health probe in rare timing
        windows) is handled transparently.
        """
        import psycopg2

        for attempt in (1, 2):
            try:
                conn = self._get_pg_connection()
                with conn.cursor() as cur:
                    cur.execute(sql, params)
                    rowcount = cur.rowcount
                return rowcount
            except (psycopg2.OperationalError, psycopg2.InterfaceError) as e:
                logger.info(
                    f"Postgres connection issue ({type(e).__name__}), "
                    f"attempt {attempt}: {e}"
                )
                try:
                    if self._pg_conn and not self._pg_conn.closed:
                        self._pg_conn.close()
                except Exception:
                    pass
                self._pg_conn = None
                if attempt == 2:
                    raise

    def query(
        self, sql: str, params: Optional[Tuple] = None
    ) -> List[Dict[str, Any]]:
        """Execute a SELECT and return rows as a list of dicts."""
        import psycopg2

        for attempt in (1, 2):
            try:
                conn = self._get_pg_connection()
                with conn.cursor() as cur:
                    cur.execute(sql, params)
                    cols = [d[0] for d in cur.description] if cur.description else []
                    rows = cur.fetchall()
                return [dict(zip(cols, r)) for r in rows]
            except (psycopg2.OperationalError, psycopg2.InterfaceError) as e:
                logger.info(
                    f"Postgres connection issue ({type(e).__name__}), "
                    f"attempt {attempt}: {e}"
                )
                try:
                    if self._pg_conn and not self._pg_conn.closed:
                        self._pg_conn.close()
                except Exception:
                    pass
                self._pg_conn = None
                if attempt == 2:
                    raise

    def execute_many(
        self, sql: str, rows: List[Tuple], page_size: int = 1000
    ) -> int:
        """Bulk insert/update via psycopg2.extras.execute_values.

        `sql` must have a single `%s` placeholder for the VALUES list, e.g.
            "INSERT INTO foo (a, b) VALUES %s"
        """
        from psycopg2.extras import execute_values

        if not rows:
            return 0

        conn = self._get_pg_connection()
        with conn.cursor() as cur:
            execute_values(cur, sql, rows, page_size=page_size)
        return len(rows)

    # ---- High-level helpers (used by entity_search_service writes) ----------

    def insert_row(
        self,
        schema: str,
        table: str,
        values: Dict[str, Any],
        returning: Optional[List[str]] = None,
    ) -> Optional[Dict[str, Any]]:
        """Insert a single row. Returns the RETURNING projection as a dict
        if `returning` is provided, else None.
        """
        if not values:
            raise ValueError("insert_row requires at least one column")

        cols = list(values.keys())
        col_list = ", ".join(f'"{c}"' for c in cols)
        placeholders = ", ".join(["%s"] * len(cols))
        sql = (
            f'INSERT INTO "{schema}"."{table}" ({col_list}) '
            f'VALUES ({placeholders})'
        )

        if returning:
            ret_list = ", ".join(f'"{c}"' for c in returning)
            sql += f" RETURNING {ret_list}"
            rows = self.query(sql, tuple(values[c] for c in cols))
            return rows[0] if rows else None

        self.execute(sql, tuple(values[c] for c in cols))
        return None

    def update_where(
        self,
        schema: str,
        table: str,
        set_values: Dict[str, Any],
        where: str,
        where_params: Tuple = (),
    ) -> int:
        """UPDATE rows. `where` is a SQL fragment without the WHERE keyword,
        with %s placeholders. Returns affected row count."""
        if not set_values:
            return 0
        set_clause = ", ".join(f'"{c}" = %s' for c in set_values.keys())
        sql = (
            f'UPDATE "{schema}"."{table}" SET {set_clause} '
            f'WHERE {where}'
        )
        return self.execute(
            sql, tuple(set_values.values()) + tuple(where_params)
        )

    def delete_where(
        self,
        schema: str,
        table: str,
        where: str,
        where_params: Tuple = (),
    ) -> int:
        """DELETE rows. Returns affected row count."""
        sql = f'DELETE FROM "{schema}"."{table}" WHERE {where}'
        return self.execute(sql, tuple(where_params))

    # ---- Transactions --------------------------------------------------------

    def transaction(self):
        """Context manager for multi-statement atomic operations.

            with pg.transaction() as tx:
                tx.execute("UPDATE master SET ...", (...))
                tx.execute("INSERT INTO audit ...", (...))
            # auto-commit on clean exit, auto-rollback on exception

        The returned object is `self` — same interface, just inside a txn.
        """
        return _LakebaseTransaction(self)


class _LakebaseTransaction:
    """Internal helper for LakebasePgClient.transaction()."""

    def __init__(self, client: LakebasePgClient):
        self._client = client
        self._prev_autocommit = None

    def __enter__(self):
        conn = self._client._get_pg_connection()
        self._prev_autocommit = conn.autocommit
        conn.autocommit = False
        return self._client

    def __exit__(self, exc_type, exc_val, exc_tb):
        conn = self._client._pg_conn
        if conn is None or conn.closed:
            return False
        try:
            if exc_type is None:
                conn.commit()
            else:
                conn.rollback()
        finally:
            conn.autocommit = (
                True if self._prev_autocommit is None
                else self._prev_autocommit
            )
        return False  # propagate exceptions