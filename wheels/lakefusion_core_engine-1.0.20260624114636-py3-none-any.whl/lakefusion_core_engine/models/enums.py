"""
Enums for MDM Pipeline

This module defines all the enumeration types used throughout the MDM pipeline
for record status tracking and merge activity logging.
"""

from enum import Enum


class RecordStatus(Enum):
    """
    Status values for records in the Unified table.
    
    Tracks the lifecycle state of source records throughout the deduplication process.
    """
    ACTIVE = "ACTIVE"
    """New unprocessed record from secondary sources or updated records ready for matching"""
    
    MERGED = "MERGED"
    """Record has been matched and merged into a master record"""
    
    UPDATED = "UPDATED"
    """Existing record received an update from source system"""
    
    DELETED = "DELETED"
    """Source system deleted this record (soft delete)"""
    
    UNMERGED = "UNMERGED"
    """Previously merged record that was manually unmerged"""

    def __str__(self) -> str:
        return self.value


class ActionType(Enum):
    """
    Action types for tracking merge activities.

    These distinguish between different pipeline contexts and user actions
    in the merge_activities table.
    """
    INITIAL_LOAD = "INITIAL_LOAD"
    """Record first entered system during initial load"""

    JOB_INSERT = "JOB_INSERT"
    """Record added to master after initial load (no merge, standalone)"""

    JOB_MERGE = "JOB_MERGE"
    """Source record auto-merged to master via normal deduplication pipeline"""

    JOB_NOT_A_MATCH = "JOB_NOT_A_MATCH"
    """Pipeline determined record is not a match"""

    MANUAL_MERGE = "MANUAL_MERGE"
    """User manually merged source record to master"""

    MANUAL_UNMERGE = "MANUAL_UNMERGE"
    """User manually unmerged a record from master"""

    MANUAL_NOT_A_MATCH = "MANUAL_NOT_A_MATCH"
    """User marked a suggested match as incorrect"""

    MANUAL_EDIT = "MANUAL_EDIT"
    """User manually edited a record"""

    MANUAL_UPDATE = "MANUAL_UPDATE"
    """User manually updated a record"""

    MASTER_JOB_MERGE = "MASTER_JOB_MERGE"
    """Master record auto-merged to another master via golden deduplication"""

    MASTER_MANUAL_MERGE = "MASTER_MANUAL_MERGE"
    """User manually merged two master records together"""

    MASTER_FORCE_MERGE = "MASTER_FORCE_MERGE"
    """Force merge of master records"""

    SOURCE_DELETE = "SOURCE_DELETE"
    """Source system deleted this record"""

    SOURCE_UPDATE = "SOURCE_UPDATE"
    """Source system updated this record"""

    UNMERGE = "UNMERGE"
    """User manually unmerged a record from master"""

    DELETE = "DELETE"
    """Record unmerged due to source deletion"""

    def __str__(self) -> str:
        return self.value

    @property
    def is_normal_dedup(self) -> bool:
        """Returns True if this action is from normal deduplication pipeline"""
        return self in (ActionType.JOB_MERGE, ActionType.MANUAL_MERGE)

    @property
    def is_golden_dedup(self) -> bool:
        """Returns True if this action is from golden deduplication pipeline"""
        return self in (ActionType.MASTER_JOB_MERGE, ActionType.MASTER_MANUAL_MERGE)

    @property
    def is_merge_action(self) -> bool:
        """Returns True if this action represents a merge"""
        return self in (
            ActionType.JOB_MERGE,
            ActionType.MANUAL_MERGE,
            ActionType.MASTER_JOB_MERGE,
            ActionType.MASTER_MANUAL_MERGE
        )

    @property
    def is_incremental_action(self) -> bool:
        """Returns True if this action is from incremental load processing"""
        return self in (ActionType.SOURCE_DELETE, ActionType.SOURCE_UPDATE)


class MatchStatus(Enum):
    """
    Match status from LLM/Vector search matching.
    
    Used to classify the confidence level of a potential match.
    """
    MATCH = "MATCH"
    """High confidence match - suitable for auto-merge"""
    
    POTENTIAL = "POTENTIAL"
    """Medium confidence - requires manual review"""
    
    NO_MATCH = "NO_MATCH"
    """Low confidence - not a match"""

    def __str__(self) -> str:
        return self.value