from enum import Enum
from typing import Optional

from .base import ReadOperations
from .delta_ops import DeltaReadOps
from .lakebase_ops import LakebaseReadOps


class ReadMode(str, Enum):
    """Mirror of WriteMode for symmetric (mode, params) factory usage."""
    DELTA = "delta"
    LAKEBASE = "lakebase"


def create_read_ops(
    entity=None,
    spark=None,
    db_config_service=None,
    *,
    mode: Optional[str] = None,
    params: Optional[dict] = None,
) -> ReadOperations:
    """
    Two construction modes — pick whichever fits your call site:

    1. New / Notebook (mode + params), symmetric to create_write_ops:
           create_read_ops(mode="lakebase", spark=spark, params={
               "lakebase_instance_id": "lakefusion-dev",
               "lakebase_branch_id": "production",
               "lakebase_database": "databricks_postgres",
           })

    2. Legacy / FastAPI (entity object):
           create_read_ops(entity, spark=spark, db_config_service=svc)
       `entity` exposes `.storage_type`. Lakebase connection params are
       looked up via `db_config_service`.

    Returns:
        ReadOperations instance.
    """
    # New (mode, params) path — used when caller passes `mode=` keyword.
    if mode is not None:
        if mode == ReadMode.LAKEBASE:
            return LakebaseReadOps(spark, params or {})
        return DeltaReadOps(spark)

    # Legacy (entity object) path — preserved for the FastAPI middlelayer.
    if entity is None:
        raise ValueError(
            "create_read_ops requires either `entity` (legacy form) or "
            "`mode=...` keyword (notebook form)."
        )

    if getattr(entity, "storage_type", None) == ReadMode.LAKEBASE:
        lb_params = {
            "lakebase_instance_id": db_config_service.getDBConfigProperties(
                "lakebase_instance_id", required=True
            ),
            "lakebase_branch_id": db_config_service.getDBConfigProperties(
                "lakebase_branch_id"
            ) or "production",
            "lakebase_database": db_config_service.getDBConfigProperties(
                "lakebase_database"
            ) or "databricks_postgres",
        }
        return LakebaseReadOps(spark, lb_params)

    return DeltaReadOps(spark)