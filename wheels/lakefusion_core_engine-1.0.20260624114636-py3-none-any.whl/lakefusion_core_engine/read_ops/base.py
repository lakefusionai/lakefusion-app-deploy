from abc import ABC, abstractmethod


class ReadOperations(ABC):
    """
    Abstract base for storage read operations.

    Symmetric to WriteOperations. Two impls:

      - DeltaReadOps:    reads UC Delta tables directly. Used for master and
                         product entities whose canonical store is Delta.
      - LakebaseReadOps: reads the `lb_<table>_history` SCD-2 Delta table
                         produced by Lakehouse Sync in UC. Used for reference
                         entities whose canonical store is Lakebase Postgres.
                         We intentionally do NOT read Postgres for UI traffic
                         — the synced Delta history table is the read source.

    Most callers want a SQL table reference they can drop into a FROM clause
    (warehouse SQL execution). For Spark callers, `read()` returns a
    DataFrame.
    """

    @abstractmethod
    def table_ref(self, table_name: str, current_only: bool = True) -> str:
        """
        Return a fully-qualified UC table reference (or subquery) usable in
        a SQL FROM/JOIN clause.

        Args:
            table_name: UC table name in the source layer. For master/product
                this is the actual UC path. For reference, this is the
                logical name; the impl rewrites it to the synced
                lb_<table>_history.
            current_only: When True (default), the returned reference yields
                only currently-active rows. For Delta tables this is a no-op
                (they already hold current state). For lb_*_history tables
                this wraps the reference in a SELECT that filters out
                superseded SCD-2 rows.
        """
        ...

    @abstractmethod
    def read(self, table_name: str, current_only: bool = True):
        """
        Return a Spark DataFrame for the table. Same semantics as
        `table_ref` but returns a DataFrame instead of a SQL string.
        """
        ...
