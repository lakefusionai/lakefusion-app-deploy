import logging

from .base import ReadOperations

logger = logging.getLogger("ReadOps.Delta")


class DeltaReadOps(ReadOperations):
    """
    Reads UC Delta tables directly.

    Used for master and product entities — their canonical store is Delta in
    Unity Catalog, so we return the table name as-is. `current_only` is a
    no-op here because Delta tables already hold current state.
    """

    def __init__(self, spark):
        self._spark = spark

    def table_ref(self, table_name: str, current_only: bool = True) -> str:
        return table_name

    def read(self, table_name: str, current_only: bool = True):
        return self._spark.table(table_name)
