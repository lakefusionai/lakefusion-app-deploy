import logging
import time

from .base import ReadOperations
from ..lakebase_client import (
    _pg_user_from_token,
    _resolve_lakebase,
    _mint_lakebase_token,
)

logger = logging.getLogger("ReadOps.Lakebase")


class LakebaseReadOps(ReadOperations):
    """
    Read operations against Lakebase Postgres synced tables.

    Synced tables (created by LakebaseWriteOps.create_table) mirror UC Delta
    tables into Postgres. This class reads those Postgres tables directly via
    JDBC for low-latency UI / API access.

    UC → PG name mapping (Lakebase synced table convention):
        catalog.schema.table  →  "schema"."table_synced"

    Host + credential resolution is delegated to the shared helpers in
    lakebase_client, which support BOTH Lakebase instance kinds:
      - `database`  — standard Lakebase database instances (w.database.*)
      - `postgres`  — autoscaling instances exposed via the projects/
                      branches/endpoints API (w.postgres.*)
    """

    def __init__(self, spark, params: dict):
        self._spark = spark
        self._instance_id = params.get("lakebase_instance_id", "")
        self._branch_id = params.get("lakebase_branch_id", "production")
        self._endpoint_id = params.get("lakebase_endpoint_id", "primary")
        self._database = params.get("lakebase_database", "databricks_postgres")

        # Connection state — lazily initialized on first read
        self._host = None
        self._user = None
        self._token = None
        self._token_expiry = 0
        self._ws = None
        self._conn_info = None  # dual-API resolver result (kind/host/...)

    # ---- Connection setup --------------------------------------------------

    def _init_connection(self):
        """Resolve host + user, supporting both Lakebase instance kinds
        (standard `database` instances and autoscaling `postgres`/projects
        instances) via _resolve_lakebase.

        For autoscaling instances, _resolve_lakebase locates the project via
        w.postgres.list_projects() (matched by project_id / display_name) and
        builds the endpoint resource path
        projects/{project_id}/branches/{branch_id}/endpoints/{endpoint_id},
        which is what the credential minting in _mint_lakebase_token requires.
        """
        from databricks.sdk import WorkspaceClient

        # Which databricks-sdk is actually loaded in THIS Python process, and
        # does it expose the Lakebase services? If a %pip upgrade hasn't taken
        # effect yet (no restartPython), the stale SDK lacks w.postgres and this
        # makes the cause obvious instead of a cryptic resolution failure.
        try:
            from databricks.sdk.version import __version__ as _sdk_ver
        except Exception:
            _sdk_ver = "unknown"
        diag = (
            f"[lakebase-sdk] databricks-sdk={_sdk_ver} "
            f"w.postgres={hasattr(WorkspaceClient, 'postgres')} "
            f"w.database={hasattr(WorkspaceClient, 'database')}"
        )
        logger.info(diag)
        print(diag)  # also surface in notebook cell output, not just driver logs

        self._ws = WorkspaceClient()

        self._conn_info = _resolve_lakebase(
            self._ws, self._instance_id, self._branch_id, self._endpoint_id
        )
        self._host = self._conn_info["host"]
        if not self._host:
            raise RuntimeError(
                f"Cannot resolve Lakebase host for instance {self._instance_id}"
            )

        # Mint the credential first; the Postgres role is its JWT `sub` claim
        # (reliable for both users and service principals).
        self._refresh_token()
        self._user = _pg_user_from_token(self._token, self._ws)
        resolved = (
            f"[lakebase-sdk] resolved kind={self._conn_info['kind']} "
            f"host={self._host} db={self._database}"
        )
        logger.info(resolved)
        print(resolved)

    def _refresh_token(self):
        self._token = _mint_lakebase_token(self._ws, self._conn_info)
        self._token_expiry = time.time() + 3500  # refresh 100s before 1h expiry

    def _ensure_connection(self):
        if self._host is None:
            self._init_connection()
        elif time.time() >= self._token_expiry:
            self._refresh_token()

    @property
    def _jdbc_url(self) -> str:
        return f"jdbc:postgresql://{self._host}:5432/{self._database}?sslmode=require"

    @property
    def _jdbc_props(self) -> dict:
        self._ensure_connection()
        return {
            "user": self._user,
            "password": self._token,
            "driver": "org.postgresql.Driver",
            "ssl": "true",
            "sslmode": "require",
        }

    # ---- Name resolution ---------------------------------------------------

    def _to_pg_table(self, uc_table_name: str) -> str:
        """UC `catalog.schema.table` → PG `"schema"."table_synced"`."""
        parts = uc_table_name.split(".")
        if len(parts) != 3:
            raise ValueError(
                f"Expected 3-part UC table name (catalog.schema.table), got: {uc_table_name}"
            )
        _, schema, table = parts
        return f'"{schema}"."{table}_synced"'

    # ---- ReadOperations interface ------------------------------------------

    def table_ref(self, table_name: str, current_only: bool = True) -> str:
        """Return the UC reference for the Lakebase synced table.

        Synced database tables are registered in Unity Catalog as
        `catalog.schema.table_synced`, so this 3-part name is usable in a SQL
        FROM/JOIN clause. `current_only` is a no-op — a synced table mirrors the
        current Delta/Postgres state (no SCD-2 history rows to filter).
        """
        parts = table_name.split(".")
        if len(parts) != 3:
            raise ValueError(
                f"Expected 3-part UC table name (catalog.schema.table), got: {table_name}"
            )
        catalog, schema, table = parts
        return f"{catalog}.{schema}.{table}_synced"

    def read(self, table_name: str, current_only: bool = True):
        """Read the Postgres synced table via JDBC and return a DataFrame."""
        self._ensure_connection()
        pg_table = self._to_pg_table(table_name)
        return self._spark.read.format("jdbc") \
            .option("url", self._jdbc_url) \
            .option("dbtable", pg_table) \
            .options(**self._jdbc_props) \
            .load()

    def read_raw(self, pg_schema: str, pg_table: str):
        """Read an arbitrary Postgres table by exact schema/table name via JDBC.

        Unlike `read`, this does NOT apply the `_synced` UC→PG mapping — use it
        for plain app-managed tables such as the change-log
        (`gold."{entity}_change_log"`)."""
        self._ensure_connection()
        return self._spark.read.format("jdbc") \
            .option("url", self._jdbc_url) \
            .option("dbtable", f'"{pg_schema}"."{pg_table}"') \
            .options(**self._jdbc_props) \
            .load()