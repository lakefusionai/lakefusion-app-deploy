"""
Generic Migration Runner with Fault Tolerance using dbutils.notebook.run()
Runs upgrade/downgrade operations with error handling and rollback support
"""

import json
import time
import traceback
from typing import Dict, Optional, List
from datetime import datetime
from pyspark.sql import SparkSession
from pathlib import Path
import os
import hashlib


def find_migrations_path(marker_dirs=["src", "versions"]) -> Path:
    """
    Find the migrations path by traversing up from current directory
    until we find a directory that contains both 'src' and 'versions' folders.
    
    Args:
        marker_dirs: List of directory names that should exist at project root
        
    Returns:
        Path to the versions directory
        
    Raises:
        FileNotFoundError: If no directory with both 'src' and 'versions' is found
    """
    current = Path(os.getcwd())
    
    # Keep going up the directory tree
    while current != current.parent:  # Stop at filesystem root (e.g., /)
        # Check if BOTH 'src' AND 'versions' folders exist at this level
        if (current / "src").exists() and (current / "versions").exists():
            versions_path = current / "versions"
            print(f"Found project root: {current}")
            print(f"Migrations path: {versions_path}")
            return versions_path
        
        # Move up one directory level
        current = current.parent
    
    # We've reached the filesystem root without finding the folders
    raise FileNotFoundError(
        f"Could not find any directory containing both 'src' and 'versions' folders. "
        f"Started from: {Path(os.getcwd())}"
    )


def generate_revision_id(title: str) -> str:
    """
    Generate a unique revision ID based on title and timestamp
    Format: <hash>_<sanitized_title>
    """
    timestamp = datetime.utcnow().isoformat()
    hash_input = f"{title}_{timestamp}"
    hash_value = hashlib.sha256(hash_input.encode()).hexdigest()[:12]
    
    # Sanitize title for folder name
    sanitized_title = title.lower().replace(" ", "_").replace("-", "_")
    # Remove any non-alphanumeric characters except underscore
    sanitized_title = ''.join(c for c in sanitized_title if c.isalnum() or c == '_')
    
    return f"{hash_value}_{sanitized_title}"


class MigrationUtils:
    """
    Utility class for migration operations that don't require entity or catalog context
    """
    
    def __init__(self, migrations_base_path: Path):
        """
        Initialize migration utilities
        
        Args:
            migrations_base_path: Path to the versions directory
        """
        self.migrations_base_path = migrations_base_path
    
    def _load_metadata(self, version_folder: Path) -> Dict:
        """
        Load metadata.json from version folder
        
        Args:
            version_folder: Path to version folder
            
        Returns:
            Metadata dictionary
        """
        try:
            print(f"Loading metadata.json from {version_folder}")
            metadata_path = version_folder / "metadata.json"
            with open(metadata_path) as f:
                content = json.load(f)
                return content
        except Exception as e:
            raise FileNotFoundError(f"metadata.json not found at {version_folder}: {str(e)}")
    
    def get_available_migrations(self) -> List[Dict]:
        """
        Read all metadata.json files from version folders and return migration info
        Returns: List of dicts with migration metadata sorted by version
        """
        migrations = []
        
        try:
            # Check if base path exists
            if not self.migrations_base_path.exists():
                print(f"Migrations path does not exist: {self.migrations_base_path}")
                return []
            
            # Iterate through all directories in versions folder
            for folder in self.migrations_base_path.iterdir():
                if folder.is_dir():
                    try:
                        # Load metadata.json
                        metadata = self._load_metadata(folder)
                        
                        # Use 'revision' as the version identifier
                        version = metadata.get("revision")
                        
                        migrations.append({
                            "version": version,
                            "description": metadata.get("description"),
                            "author": metadata.get("author"),
                            "created_at": metadata.get("created_at"),
                            "down_revision": metadata.get("down_revision"),
                            "folder_path": str(folder),
                            "folder_name": folder.name,
                            "metadata": metadata
                        })
                    except FileNotFoundError as e:
                        print(f"Warning: Skipping {folder.name} - {e}")
                    except json.JSONDecodeError as e:
                        print(f"Warning: Invalid JSON in {folder.name}/metadata.json: {e}")
                    except Exception as e:
                        print(f"Warning: Could not read metadata from {folder.name}: {e}")
            
            # Sort by version
            migrations.sort(key=lambda x: self._parse_version(x["version"]))
            
            print(f"Found {len(migrations)} available migrations")
            return migrations
            
        except Exception as e:
            print(f"Error reading migrations from {self.migrations_base_path}: {e}")
            return []
    
    def _parse_version(self, version_str: str) -> tuple:
        """
        Parse version string for sorting (e.g., 'v1.2.3' -> (1, 2, 3))
        Handles both semantic versions and revision hashes
        """
        if not version_str:
            return (0, 0, 0)
        
        try:
            # Remove 'v' prefix if present
            version_str = version_str.lstrip('v')
            
            # Try to parse as semantic version (1.2.3)
            parts = version_str.split('.')
            return tuple(map(int, parts))
        except (ValueError, AttributeError):
            # If not a semantic version, use string comparison
            return (0, 0, 0, version_str)
    
    def get_latest_version(self) -> Optional[Dict]:
        """
        Get the latest available migration version by finding the revision
        that is not referenced as a down_revision by any other migration.
        
        Returns:
            Dictionary containing the latest migration info, or None if no migrations exist
        """
        available_migrations = self.get_available_migrations()
        
        if not available_migrations:
            print("No migrations available")
            return None
        
        if len(available_migrations) == 1:
            print(f"Only one migration found: {available_migrations[0]['version']}")
            return available_migrations[0]
        
        # Collect all down_revision values (these are parent revisions)
        down_revisions = set()
        for migration in available_migrations:
            down_rev = migration.get('down_revision')
            if down_rev is not None:
                down_revisions.add(down_rev)
        
        # Find the revision that is NOT in down_revisions (it's the latest)
        latest_migration = None
        for migration in available_migrations:
            if migration['version'] not in down_revisions:
                if latest_migration is not None:
                    print(f"Warning: Multiple head revisions found:")
                    print(f"  - {latest_migration['version']}")
                    print(f"  - {migration['version']}")
                    print(f"This indicates a branched migration history!")
                latest_migration = migration
        
        if latest_migration:
            print(f"Latest migration version: {latest_migration['version']}")
            print(f"Description: {latest_migration['description']}")
            print(f"Folder: {latest_migration['folder_name']}")
        else:
            print("Warning: Could not determine latest version (circular dependency?)")
        
        return latest_migration


class MigrationRunner:
    """
    Fault-tolerant migration runner for entity-specific migration operations
    Uses dbutils.notebook.run() to execute migration notebooks
    """
    
    def __init__(self, spark: SparkSession, catalog: str, entity_id: str, params: dict, dbutils: any = None):
        """
        Initialize migration runner
        
        Args:
            spark: SparkSession instance
            catalog: Databricks catalog name
            entity_id: Entity identifier for tracking
        """
        self.spark = spark
        self.catalog = catalog
        self.entity_id = entity_id
        self.metadata_schema = f"{catalog}.metadata"
        self.versions_table = f"{self.metadata_schema}.alembic_versions"
        self.migrations_base_path = find_migrations_path()
        self.dbutils = dbutils
        self.params = params
        
        # Initialize utility class
        self.utils = MigrationUtils(self.migrations_base_path)

        # Validate dbutils is provided
        if self.dbutils is None:
            raise ValueError("dbutils is required for MigrationRunner. Pass it from your notebook.")
    
    def _execute_migration_notebook(self, version_folder: str, function_name: str, 
                                     timeout_seconds: int = 10800) -> Dict:
        """
        Execute migration notebook using dbutils.notebook.run()
        
        Args:
            version_folder: Path to version folder
            function_name: 'upgrade' or 'downgrade'
            timeout_seconds: Timeout for notebook execution
            
        Returns:
            Dictionary with execution results
        """
        migration_notebook = f"{version_folder}/migration"
        
        result = {
            'success': False,
            'execution_time': 0.0,
            'error': None,
            'output': None
        }
        
        print(f"\n[DEBUG] Preparing to execute migration notebook")
        print(f"[DEBUG] Notebook path: {migration_notebook}")
        print(f"[DEBUG] Function: {function_name}")
        print(f"[DEBUG] Timeout: {timeout_seconds}s")
        print(f"[DEBUG] Parameters:")
        print(f"[DEBUG]   - catalog: {self.catalog}")
        print(f"[DEBUG]   - entity_id: {self.entity_id}")
        print(f"[DEBUG]   - function: {function_name}")
        
        start_time = time.time()
        
        try:
            print(f"\n[INFO] Executing notebook: {migration_notebook}")
            print(f"[INFO] Function: {function_name}")
            print(f"[INFO] Catalog: {self.catalog}")
            print(f"[INFO] Entity: {self.entity_id}")
            print("=" * 80)
            
            print(f"[DEBUG] Calling dbutils.notebook.run()...")
            # Run the notebook with parameters
            output = self.dbutils.notebook.run(
                migration_notebook,
                timeout_seconds,
                {
                    **self.params,
                    "function": function_name
                }
            )
            
            execution_time = time.time() - start_time
            
            print(f"[DEBUG] ✓ Notebook execution returned")
            print(f"[DEBUG] Output: {output}")
            print(f"[DEBUG] Execution time: {execution_time:.2f}s")
            
            result['success'] = True
            result['execution_time'] = execution_time
            result['output'] = output
            
            print("=" * 80)
            print(f"[INFO] ✓ Notebook execution completed in {execution_time:.2f}s")
            
        except Exception as e:
            execution_time = time.time() - start_time
            result['execution_time'] = execution_time
            result['error'] = f"{type(e).__name__}: {str(e)}\n{traceback.format_exc()}"
            
            print(f"[ERROR] Notebook execution failed")
            print(f"[ERROR] Execution time before failure: {execution_time:.2f}s")
            print(f"[ERROR] Exception type: {type(e).__name__}")
            print(f"[ERROR] Exception message: {str(e)}")
            print(f"[ERROR] Full traceback:")
            traceback.print_exc()
            print("=" * 80)
            print(f"[ERROR] ✗ Notebook execution failed after {execution_time:.2f}s")
            print(f"[ERROR] Error details: {result['error']}")
        
        return result
    
    def _ensure_tracking_table(self):
        """
        Ensure the alembic_versions tracking table exists
        Creates the schema and table if they don't exist
        """
        print(f"\n[DEBUG] Ensuring tracking table exists...")
        print(f"[DEBUG] Target schema: {self.metadata_schema}")
        print(f"[DEBUG] Target table: {self.versions_table}")
        
        try:
            # Create metadata schema if it doesn't exist
            print(f"[DEBUG] Creating schema if not exists: {self.metadata_schema}")
            self.spark.sql(f"""
                CREATE SCHEMA IF NOT EXISTS {self.metadata_schema}
                COMMENT 'Schema for storing migration and metadata'
            """)
            print(f"[DEBUG] ✓ Schema check completed")
            
            # Create alembic_versions table if it doesn't exist
            print(f"[DEBUG] Creating table if not exists: {self.versions_table}")
            self.spark.sql(f"""
                CREATE TABLE IF NOT EXISTS {self.versions_table} (
                    entity_id STRING NOT NULL COMMENT 'Entity identifier',
                    version_num STRING NOT NULL COMMENT 'Migration revision ID',
                    applied_at TIMESTAMP COMMENT 'When migration was applied',
                    applied_by STRING COMMENT 'User who applied migration',
                    execution_time_seconds DOUBLE COMMENT 'Migration execution time',
                    migration_name STRING COMMENT 'Migration description',
                    CONSTRAINT pk_entity_version PRIMARY KEY (entity_id, version_num)
                )
                USING DELTA
                COMMENT 'Entity-specific migration version tracking'
                TBLPROPERTIES (
                    'delta.enableChangeDataFeed' = 'true'
                )
            """)
            print(f"[DEBUG] ✓ Table check completed")
            print(f"[DEBUG] ✓ Tracking table is ready")
            return True
            
        except Exception as e:
            print(f"[ERROR] Failed to ensure tracking table exists")
            print(f"[ERROR] Exception type: {type(e).__name__}")
            print(f"[ERROR] Exception message: {str(e)}")
            print(f"[ERROR] Stack trace:")
            traceback.print_exc()
            return False
    
    def _record_success(self, metadata: Dict, execution_time: float):
        """
        Record successful migration in tracking table (fault-tolerant)
        
        Args:
            metadata: Migration metadata
            execution_time: Execution time in seconds
        """
        print(f"\n[DEBUG] Recording migration success...")
        print(f"[DEBUG] Revision: {metadata.get('revision', 'N/A')}")
        print(f"[DEBUG] Execution time: {execution_time:.2f}s")
        
        try:
            # Ensure tracking table exists
            print(f"[DEBUG] Ensuring tracking table exists...")
            if not self._ensure_tracking_table():
                print(f"[WARNING] Could not create tracking table, skipping record")
                return
            
            print(f"[DEBUG] Tracking table confirmed to exist")
            
            # Get current user
            print(f"[DEBUG] Getting current user...")
            try:
                current_user = self.spark.sql("SELECT current_user() as user").collect()[0]['user']
                print(f"[DEBUG] Current user: {current_user}")
            except Exception as e:
                current_user = "unknown"
                print(f"[WARNING] Could not get current user, using 'unknown'")
                print(f"[WARNING] Error: {str(e)}")
            
            # Escape single quotes in description to prevent SQL injection
            description = metadata.get('description', '').replace("'", "''")
            print(f"[DEBUG] Description (escaped): {description}")
            
            # Record the migration
            print(f"[DEBUG] Executing MERGE statement...")
            print(f"[DEBUG] Target table: {self.versions_table}")
            print(f"[DEBUG] Entity ID: {self.entity_id}")
            print(f"[DEBUG] Revision: {metadata['revision']}")
            
            self.spark.sql(f"""
                MERGE INTO {self.versions_table} AS target
                USING (
                    SELECT 
                        '{self.entity_id}' as entity_id,
                        '{metadata['revision']}' as version_num,
                        CURRENT_TIMESTAMP() as applied_at,
                        '{current_user}' as applied_by,
                        {execution_time} as execution_time_seconds,
                        '{description}' as migration_name
                ) AS source
                ON target.entity_id = source.entity_id 
                   AND target.version_num = source.version_num
                WHEN MATCHED THEN UPDATE SET *
                WHEN NOT MATCHED THEN INSERT *
            """)
            
            print(f"[DEBUG] ✓ MERGE statement executed successfully")
            print(f"[INFO] ✓ Recorded migration in tracking table: {self.versions_table}")
            
        except Exception as e:
            print(f"[ERROR] Failed to record migration")
            print(f"[ERROR] Exception type: {type(e).__name__}")
            print(f"[ERROR] Exception message: {str(e)}")
            print(f"[ERROR] Stack trace:")
            traceback.print_exc()
            print(f"[WARNING] Migration still succeeded, but tracking record may be missing")
    
    def _remove_record(self, revision: str):
        """
        Remove migration record from tracking table (fault-tolerant)
        
        Args:
            revision: Revision to remove
        """
        try:
            # Ensure tracking table exists first
            if not self._ensure_tracking_table():
                print(f"⚠ Warning: Tracking table doesn't exist, nothing to remove")
                return
            
            # Check if record exists
            record_exists = self.spark.sql(f"""
                SELECT COUNT(*) as cnt
                FROM {self.versions_table}
                WHERE entity_id = '{self.entity_id}' 
                AND version_num = '{revision}'
            """).collect()[0]['cnt'] > 0
            
            if not record_exists:
                print(f"⚠ No record found for revision {revision}, nothing to remove")
                return
            
            # Remove the record
            self.spark.sql(f"""
                DELETE FROM {self.versions_table}
                WHERE entity_id = '{self.entity_id}' 
                AND version_num = '{revision}'
            """)
            print(f"✓ Removed migration record from tracking table: {revision}")
            
        except Exception as e:
            print(f"⚠ Warning: Could not remove migration record: {str(e)}")
            print(f"   Migration still succeeded, but tracking record may remain")
    
    def get_applied_versions(self) -> set:
        """
        Get all applied versions for the current entity.
        Returns a set of version_num strings.
        """
        try:
            applied_df = self.spark.sql(f"""
                SELECT version_num 
                FROM {self.versions_table} 
                WHERE entity_id = '{self.entity_id}'
            """)
            
            rows = applied_df.collect()
            if rows:
                applied_versions = {row.version_num for row in rows}
                print(f"Entity {self.entity_id} has {len(applied_versions)} applied versions: {applied_versions}")
                return applied_versions
            else:
                print(f"Entity {self.entity_id} has no applied versions (fresh entity)")
                return set()
                
        except Exception as e:
            print(f"No applied versions found (table may not exist): {e}")
            return set()
    
    def _get_ancestor_revisions(self, revision: str, available_migrations: List[Dict]) -> set:
        """
        Get all ancestor revisions for a given revision by traversing the down_revision chain.
        
        Args:
            revision: The revision to find ancestors for
            available_migrations: List of all available migrations
            
        Returns:
            Set of all ancestor revision IDs (including the revision itself)
        """
        # Build a lookup map: revision -> migration info
        revision_map = {m['version']: m for m in available_migrations}
        
        ancestors = set()
        current = revision
        
        while current:
            ancestors.add(current)
            migration = revision_map.get(current)
            if migration:
                current = migration.get('down_revision')
            else:
                break
        
        return ancestors

    def get_pending_migrations(self) -> List[Dict]:
        """
        Get list of migrations that need to be applied for the current entity.
        Returns migrations that have NOT been applied yet and are NOT ancestors
        of already applied versions.
        """
        applied_versions = self.get_applied_versions()
        available_migrations = self.utils.get_available_migrations()
        
        if not applied_versions:
            # No versions applied yet - all migrations are pending
            pending = available_migrations
            print(f"Entity {self.entity_id}: Fresh entity, all {len(pending)} migrations pending")
        else:
            # Get all ancestors of applied versions (these are implicitly applied)
            implicitly_applied = set()
            for applied_version in applied_versions:
                ancestors = self._get_ancestor_revisions(applied_version, available_migrations)
                implicitly_applied.update(ancestors)
            
            print(f"Entity {self.entity_id}: {len(applied_versions)} explicitly applied, "
                f"{len(implicitly_applied)} total (including ancestors)")
            
            # Filter out migrations that have been applied OR are ancestors of applied versions
            pending = [
                migration for migration in available_migrations 
                if migration["version"] not in implicitly_applied
            ]
            print(f"Entity {self.entity_id}: {len(pending)} pending")
        
        if pending:
            print("Pending migrations:")
            for migration in pending:
                print(f"  - {migration['version']}: {migration['description']}")
        else:
            print("No pending migrations - entity is up to date")
        
        return pending
    
    def run_upgrade(self, version_folder: str, record_success: bool = True, 
                    timeout_seconds: int = 10800) -> Dict:
        """
        Run upgrade migration for a specific version
        
        Args:
            version_folder: Path to version folder
            record_success: Whether to record success in tracking table
            timeout_seconds: Timeout for notebook execution
            
        Returns:
            Dictionary with execution results
        """
        result = {
            'success': False,
            'revision': None,
            'description': None,
            'execution_time': 0.0,
            'error': None,
            'recorded': False
        }
        
        try:
            # Load metadata
            metadata = self.utils._load_metadata(Path(version_folder))
            result['revision'] = metadata['revision']
            result['description'] = metadata.get('description', 'N/A')
            
            print("\n" + "=" * 80)
            print(f"MIGRATION UPGRADE")
            print("=" * 80)
            print(f"Revision: {metadata['revision']}")
            print(f"Description: {metadata.get('description', 'N/A')}")
            print(f"Entity: {self.entity_id}")
            print(f"Catalog: {self.catalog}")
            print("=" * 80)
            
            # Execute upgrade via notebook
            exec_result = self._execute_migration_notebook(
                version_folder, 
                'upgrade',
                timeout_seconds
            )
            
            result['success'] = exec_result['success']
            result['execution_time'] = exec_result['execution_time']
            result['error'] = exec_result['error']
            
            if exec_result['success']:
                print(f"\n✓ Migration upgrade completed successfully in {exec_result['execution_time']:.2f}s")
                
                # Record success if requested
                if record_success:
                    self._record_success(metadata, exec_result['execution_time'])
                    result['recorded'] = True
            else:
                print(f"\n✗ Migration upgrade failed after {exec_result['execution_time']:.2f}s")
                print(f"Error: {exec_result['error']}")
                
        except Exception as e:
            result['error'] = f"{type(e).__name__}: {str(e)}\n{traceback.format_exc()}"
            print(f"\n✗ Migration upgrade failed with exception")
            print(f"Error: {result['error']}")
        
        print("=" * 80 + "\n")
        return result
    
    def run_downgrade(self, version_folder: str, remove_record: bool = True,
                      timeout_seconds: int = 10800) -> Dict:
        """
        Run downgrade migration for a specific version
        
        Args:
            version_folder: Path to version folder
            remove_record: Whether to remove record from tracking table
            timeout_seconds: Timeout for notebook execution
            
        Returns:
            Dictionary with execution results
        """
        result = {
            'success': False,
            'revision': None,
            'description': None,
            'execution_time': 0.0,
            'error': None,
            'removed': False
        }
        
        try:
            # Load metadata
            metadata = self.utils._load_metadata(Path(version_folder))
            result['revision'] = metadata['revision']
            result['description'] = metadata.get('description', 'N/A')
            
            print("\n" + "=" * 80)
            print(f"MIGRATION DOWNGRADE")
            print("=" * 80)
            print(f"Revision: {metadata['revision']}")
            print(f"Description: {metadata.get('description', 'N/A')}")
            print(f"Entity: {self.entity_id}")
            print(f"Catalog: {self.catalog}")
            print("=" * 80)
            
            # Execute downgrade via notebook
            exec_result = self._execute_migration_notebook(
                version_folder,
                'downgrade',
                timeout_seconds
            )
            
            result['success'] = exec_result['success']
            result['execution_time'] = exec_result['execution_time']
            result['error'] = exec_result['error']
            
            if exec_result['success']:
                print(f"\n✓ Migration downgrade completed successfully in {exec_result['execution_time']:.2f}s")
                
                # Remove record if requested
                if remove_record:
                    self._remove_record(metadata['revision'])
                    result['removed'] = True
            else:
                print(f"\n✗ Migration downgrade failed after {exec_result['execution_time']:.2f}s")
                print(f"Error: {exec_result['error']}")
                
        except Exception as e:
            result['error'] = f"{type(e).__name__}: {str(e)}\n{traceback.format_exc()}"
            print(f"\n✗ Migration downgrade failed with exception")
            print(f"Error: {result['error']}")
        
        print("=" * 80 + "\n")
        return result
    
    def run_upgrade_with_rollback(self, version_folder: str, 
                                   timeout_seconds: int = 10800) -> Dict:
        """
        Run upgrade with automatic rollback on failure
        
        Args:
            version_folder: Path to version folder
            timeout_seconds: Timeout for notebook execution
            
        Returns:
            Dictionary with execution results including rollback info
        """
        result = {
            'upgrade_success': False,
            'rollback_attempted': False,
            'rollback_success': False,
            'revision': None,
            'upgrade_time': 0.0,
            'rollback_time': 0.0,
            'error': None,
            'rollback_error': None
        }
        
        # Attempt upgrade
        upgrade_result = self.run_upgrade(version_folder, record_success=True, 
                                         timeout_seconds=timeout_seconds)
        result['upgrade_success'] = upgrade_result['success']
        result['revision'] = upgrade_result['revision']
        result['upgrade_time'] = upgrade_result['execution_time']
        result['error'] = upgrade_result['error']
        
        # If upgrade failed, attempt rollback
        if not upgrade_result['success']:
            print("\n⚠ Upgrade failed - attempting automatic rollback...")
            result['rollback_attempted'] = True
            
            downgrade_result = self.run_downgrade(version_folder, remove_record=True,
                                                  timeout_seconds=timeout_seconds)
            result['rollback_success'] = downgrade_result['success']
            result['rollback_time'] = downgrade_result['execution_time']
            result['rollback_error'] = downgrade_result['error']
            
            if downgrade_result['success']:
                print("✓ Automatic rollback completed successfully")
            else:
                print("✗ Automatic rollback failed - manual intervention required!")
        
        return result
    
    def create_alembic_initial_load_entry(self, version_info: Dict) -> Dict:
        """
        Create an alembic_versions entry for initial load without executing migrations.
        Used for the initial load / execution of the integration task for the entity and you want to mark it at a specific version
        without running the actual migration code.
        
        Args:
            version_info: Dictionary containing migration metadata (from get_latest_version or get_available_migrations)
                        Must have keys: 'version', 'metadata' (with 'revision', 'description')
            
        Returns:
            Dictionary with operation results
        """
        print(f"\n{'='*80}")
        print(f"[INFO] Creating alembic initial load entry")
        print(f"{'='*80}")
        
        result = {
            'success': False,
            'revision': None,
            'description': None,
            'recorded': False,
            'error': None
        }
        
        try:
            # Extract version and metadata
            version = version_info.get('version')
            metadata = version_info.get('metadata', {})
            
            if not version:
                raise ValueError("version_info must contain 'version' key")
            
            if not metadata.get('revision'):
                # If metadata doesn't have revision, use version as revision
                metadata['revision'] = version
            
            result['revision'] = metadata['revision']
            result['description'] = metadata.get('description', 'N/A')
            
            print(f"[INFO] Revision: {metadata['revision']}")
            print(f"[INFO] Description: {metadata.get('description', 'N/A')}")
            print(f"[INFO] Entity: {self.entity_id}")
            print(f"[INFO] Catalog: {self.catalog}")
            print(f"[INFO] Mode: INITIAL LOAD ENTRY (no migration execution)")
            print(f"{'='*80}")
            
            # Ensure tracking table exists (handles new customer/entity scenario)
            print(f"[DEBUG] Ensuring alembic_versions table exists...")
            if not self._ensure_tracking_table():
                raise Exception("Failed to create or verify alembic_versions table")
            
            print(f"[DEBUG] ✓ Alembic_versions table confirmed to exist")
            
            # Check if entry already exists for this entity
            print(f"[DEBUG] Checking if entry already exists for entity '{self.entity_id}'...")
            existing_count = self.spark.sql(f"""
                SELECT COUNT(*) as cnt
                FROM {self.versions_table}
                WHERE entity_id = '{self.entity_id}'
            """).collect()[0]['cnt']
            
            if existing_count > 0:
                print(f"[WARNING] Entity '{self.entity_id}' already has {existing_count} version(s) in alembic_versions")
                print(f"[WARNING] This is NOT a fresh entity - initial load entry may not be appropriate")
                print(f"[WARNING] Consider using regular migration mode instead")
                # Continue anyway but warn the user
            else:
                print(f"[DEBUG] ✓ Entity '{self.entity_id}' has no existing entries (fresh entity)")
            
            # Record with execution_time=0 since we're not actually executing
            print(f"[DEBUG] Creating alembic_versions entry for initial load...")
            self._record_success(metadata, execution_time=0.0)
            
            result['success'] = True
            result['recorded'] = True
            
            print(f"\n[INFO] ✓ Alembic initial load entry created successfully")
            print(f"[INFO] Entity '{self.entity_id}' is now marked at version: {metadata['revision']}")
            
        except Exception as e:
            result['error'] = f"{type(e).__name__}: {str(e)}\n{traceback.format_exc()}"
            print(f"\n[ERROR] Failed to create alembic initial load entry")
            print(f"[ERROR] Exception type: {type(e).__name__}")
            print(f"[ERROR] Exception message: {str(e)}")
            print(f"[ERROR] Stack trace:")
            traceback.print_exc()
        
        print(f"{'='*80}\n")
        return result