from pyspark.sql.functions import lit, current_timestamp
from pyspark.sql.types import StringType
from delta.tables import DeltaTable


class UnifiedErrorHandler:
    """
    Captures per-record pipeline errors and routes them to an append-only
    error table in the silver layer.

    Table: {catalog}.silver.{entity}_unified_error_{experiment_id}
    """

    def __init__(self, spark, unified_table):
        """
        Args:
            spark: SparkSession
            unified_table: Full unified table name, e.g.
                {catalog}.silver.{entity}_unified_{experiment_id}
                {catalog}.silver.{entity}_unified_deduplicate_{experiment_id}

        Error table name is derived by inserting '_error' before the experiment_id suffix.
        e.g. {catalog}.silver.{entity}_unified_error_{experiment_id}
             {catalog}.silver.{entity}_unified_deduplicate_error_{experiment_id}
        """
        self.spark = spark
        # Split: catalog.schema.table_name
        parts = unified_table.rsplit(".", 1)  # ['catalog.schema', 'table_name']
        prefix = parts[0]  # catalog.schema
        table_name = parts[1]  # e.g. entity_unified_prod or entity_unified_deduplicate_prod

        # Find the last '_' before experiment_id and insert '_error'
        # unified table pattern: {entity}_unified_{experiment_id} or {entity}_unified_deduplicate_{experiment_id}
        # We insert _error before the last segment (experiment_id)
        last_underscore = table_name.rfind("_")
        if last_underscore > 0:
            error_table_name = table_name[:last_underscore] + "_error" + table_name[last_underscore:]
        else:
            error_table_name = table_name + "_error"

        self.full_table_name = f"{prefix}.{error_table_name}"

    def ensure_table(self):
        """Idempotently create the error table with the canonical schema.

        Safe under concurrent runs (single CREATE TABLE IF NOT EXISTS statement).
        Call this at the start of each scoring phase so downstream log_errors()
        calls can rely on the table existing even when the caller has nothing
        to write.
        """
        self.spark.sql(f"""
            CREATE TABLE IF NOT EXISTS {self.full_table_name} (
                surrogate_key   STRING,
                error_message   STRING,
                error_stage     STRING,
                error_timestamp TIMESTAMP,
                run_id          STRING
            ) USING DELTA
        """)

    def log_errors(self, df_errors, stage, run_id=None):
        """
        Write errored records to the error table.

        Args:
            df_errors: DataFrame with columns ``surrogate_key`` and ``error_message``.
            stage: Pipeline stage name (e.g. "VECTOR_SEARCH", "LLM_SCORING").
            run_id: Optional pipeline run identifier.
        """
        if df_errors.isEmpty():
            return

        df_to_write = (
            df_errors
            .withColumn("error_stage", lit(stage))
            .withColumn("error_timestamp", current_timestamp())
            .withColumn("run_id", lit(run_id).cast(StringType()))
        )

        if not self.spark.catalog.tableExists(self.full_table_name):
            df_to_write.write.format("delta").saveAsTable(self.full_table_name)
        else:
            # Merge by surrogate_key + stage to avoid dupes within the same run,
            # but allow the same key to appear for different stages or runs.
            delta_table = DeltaTable.forName(self.spark, self.full_table_name)
            delta_table.alias("target").merge(
                source=df_to_write.alias("source"),
                condition=(
                    "target.surrogate_key = source.surrogate_key "
                    "AND target.error_stage = source.error_stage "
                    "AND target.run_id <=> source.run_id"
                ),
            ).whenMatchedUpdate(
                set={
                    "error_message": "source.error_message",
                    "error_timestamp": "source.error_timestamp",
                }
            ).whenNotMatchedInsertAll().execute()
