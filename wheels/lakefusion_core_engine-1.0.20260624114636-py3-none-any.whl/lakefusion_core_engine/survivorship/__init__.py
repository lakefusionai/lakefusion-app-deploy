"""
LakeFusion Survivorship Engine

A flexible, extensible engine for applying survivorship rules during record merging.
"""

from .engine import SurvivorshipEngine
from .models.config import SurvivorshipConfig, RuleConfig
from .models.result import SurvivorshipResult, AttributeSourceMapping, StrategyContext

__version__ = "2.0.0"

__all__ = [
    "SurvivorshipEngine",
    "SurvivorshipConfig",
    "RuleConfig", 
    "SurvivorshipResult",
    "AttributeSourceMapping",
    "StrategyContext",
    "__version__"
]