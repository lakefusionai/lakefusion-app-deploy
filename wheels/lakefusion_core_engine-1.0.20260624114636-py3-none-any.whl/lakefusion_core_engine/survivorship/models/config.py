"""
Configuration models for survivorship engine.
"""

from dataclasses import dataclass, field
from typing import Any, Optional, List


# Allowed values for the per-rule tie-breaker direction.
TIE_BREAKER_LATEST = "latest"
TIE_BREAKER_EARLIEST = "earliest"
VALID_TIE_BREAKERS = {TIE_BREAKER_LATEST, TIE_BREAKER_EARLIEST}


@dataclass
class RuleConfig:
    """
    Configuration for a single survivorship rule.

    Attributes:
        attribute: The attribute name this rule applies to
        strategy: The strategy type ("Recency", "Source System", "Aggregation")
        strategyRule: Strategy-specific configuration (optional)
                     - For Recency: date attribute name (e.g., "updated_at")
                     - For Source System: list of table paths in priority order
                     - For Aggregation: None or aggregation settings
        ignoreNull: Whether to ignore null/empty values (default: False)
                   - When True: Skip null values and find next valid value
                   - When False: Return null if highest priority source has null
        aggregateUniqueOnly: For Aggregation strategy, whether to aggregate
            unique values only (default: False)
        tieBreaker: Tie-break direction when multiple records compete for the
            same slot under this rule (default: "latest"). One of
            "latest" | "earliest". Engine uses ``__lf_modified_at`` to order
            candidates; "latest" picks max, "earliest" picks min.
    """
    attribute: str
    strategy: str
    strategyRule: Optional[Any] = None
    ignoreNull: bool = False
    aggregateUniqueOnly: bool = False
    tieBreaker: str = TIE_BREAKER_LATEST

    @classmethod
    def from_dict(cls, data: dict) -> 'RuleConfig':
        """
        Create RuleConfig from dictionary.

        Ensures proper defaults are applied when keys are missing.
        """
        raw_tie_breaker = str(data.get('tieBreaker', TIE_BREAKER_LATEST) or TIE_BREAKER_LATEST).lower()
        tie_breaker = raw_tie_breaker if raw_tie_breaker in VALID_TIE_BREAKERS else TIE_BREAKER_LATEST
        return cls(
            attribute=data.get('attribute', ''),
            strategy=data.get('strategy', ''),
            strategyRule=data.get('strategyRule'),
            # CRITICAL: Default to False if not explicitly set
            ignoreNull=bool(data.get('ignoreNull', False)),
            aggregateUniqueOnly=bool(data.get('aggregateUniqueOnly', False)),
            tieBreaker=tie_breaker,
        )

    def __post_init__(self):
        """Ensure boolean fields are properly typed after initialization."""
        # Convert to bool in case they were passed as strings or other types
        self.ignoreNull = bool(self.ignoreNull) if self.ignoreNull else False
        self.aggregateUniqueOnly = bool(self.aggregateUniqueOnly) if self.aggregateUniqueOnly else False
        # Normalize tieBreaker
        tb = str(self.tieBreaker or TIE_BREAKER_LATEST).lower()
        self.tieBreaker = tb if tb in VALID_TIE_BREAKERS else TIE_BREAKER_LATEST


@dataclass
class SurvivorshipConfig:
    """
    Complete survivorship configuration for an entity.
    
    Attributes:
        rules: List of survivorship rules
        entity_attributes: List of all entity attributes
        entity_attributes_datatype: Mapping of attribute names to data types
        id_key: Primary key attribute name
    """
    rules: List[RuleConfig]
    entity_attributes: List[str]
    entity_attributes_datatype: dict
    id_key: str
    
    def get_rule_for_attribute(self, attribute: str) -> Optional[RuleConfig]:
        """
        Get the survivorship rule for a specific attribute.
        
        Args:
            attribute: Attribute name
            
        Returns:
            RuleConfig if found, None otherwise
        """
        return next((rule for rule in self.rules if rule.attribute == attribute), None)
    
    def get_datatype(self, attribute: str) -> str:
        """
        Get the datatype for a specific attribute.
        
        Args:
            attribute: Attribute name
            
        Returns:
            Datatype string, defaults to 'string' if not found
        """
        return self.entity_attributes_datatype.get(attribute, 'string')
    
    @classmethod
    def from_config(cls, survivorship_rules: List[dict], entity_attributes: List[str],
                    entity_attributes_datatype: dict, id_key: str) -> 'SurvivorshipConfig':
        """
        Create SurvivorshipConfig from raw configuration.
        
        Args:
            survivorship_rules: List of rule dictionaries from entity model
            entity_attributes: List of entity attribute names
            entity_attributes_datatype: Dict mapping attributes to datatypes
            id_key: Primary key attribute name
            
        Returns:
            SurvivorshipConfig instance
        """
        rules = [RuleConfig.from_dict(rule_dict) for rule_dict in survivorship_rules]
        return cls(
            rules=rules,
            entity_attributes=entity_attributes,
            entity_attributes_datatype=entity_attributes_datatype,
            id_key=id_key
        )