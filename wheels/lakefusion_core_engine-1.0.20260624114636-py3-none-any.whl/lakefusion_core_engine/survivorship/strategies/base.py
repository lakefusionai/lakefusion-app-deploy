"""
Base strategy class for survivorship rules.
All strategy implementations must inherit from this class.
"""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Tuple, Any, List, Dict, Optional

from ..models.config import TIE_BREAKER_EARLIEST, TIE_BREAKER_LATEST
from ..models.result import StrategyContext
from ..utils.helpers import is_null_or_empty
from ...utils.constants import LF_MODIFIED_AT_COL


class BaseStrategy(ABC):
    """
    Abstract base class for all survivorship strategies.
    
    Each strategy must implement the apply() method which processes
    the attribute according to its specific logic and returns the
    survived value and its source.
    """
    
    def __init__(self):
        """Initialize the strategy."""
        pass
    
    @abstractmethod
    def apply(self, context: StrategyContext) -> Tuple[Any, str]:
        """
        Apply the survivorship strategy.
        
        Args:
            context: StrategyContext containing all necessary data
            
        Returns:
            Tuple of (value, source) where:
                - value: The survived value for the attribute
                - source: The source table path that won (comma-separated for aggregation)
                Returns (None, None) if no valid value found
        """
        pass
    
    def _pick_by_tie_breaker(
        self,
        records: List[Dict[str, Any]],
        tie_breaker: str = TIE_BREAKER_LATEST,
    ) -> Optional[Dict[str, Any]]:
        """Pick the record that wins under ``tie_breaker`` direction.

        Uses ``LF_MODIFIED_AT_COL`` as the ordering key. The column is
        optional — if any candidate is missing it, falls back to the first
        record so legacy callers stay unaffected.

        Args:
            records: Candidate records.
            tie_breaker: ``"latest"`` (default) picks the record with the
                greatest timestamp. ``"earliest"`` picks the smallest.
        """
        if not records:
            return None
        if len(records) == 1:
            return records[0]

        winner = records[0]
        winner_ts = winner.get(LF_MODIFIED_AT_COL)
        if winner_ts is None:
            return records[0]

        earliest = tie_breaker == TIE_BREAKER_EARLIEST
        for candidate in records[1:]:
            ts = candidate.get(LF_MODIFIED_AT_COL)
            if ts is None:
                # Mixed presence — bail out, behave as before.
                return records[0]
            try:
                if (earliest and ts < winner_ts) or (not earliest and ts > winner_ts):
                    winner = candidate
                    winner_ts = ts
            except TypeError:
                # Types not directly comparable (e.g. mix of str and datetime)
                # — give up on tie-breaking.
                return records[0]
        return winner

    # Backwards-compatible alias. New callers should use ``_pick_by_tie_breaker``.
    def _pick_latest(
        self,
        records: List[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        return self._pick_by_tie_breaker(records, TIE_BREAKER_LATEST)

    def _should_ignore_value(self, value: Any, ignore_null: bool) -> bool:
        """
        Helper method to determine if a value should be ignored based on ignoreNull setting.
        
        IMPORTANT: This method is used to determine whether to SKIP a value and continue
        looking for another value. It is NOT used to determine whether to return a value.
        
        Args:
            value: The value to check
            ignore_null: Whether to ignore null/empty values (from rule config)
            
        Returns:
            True if value should be SKIPPED (ignored), False otherwise
            - When ignore_null=True and value is null/empty: return True (skip this value)
            - When ignore_null=False: return False (never skip, even if null)
        """
        if ignore_null:
            return is_null_or_empty(value)
        # When ignoreNull is False, we NEVER skip - we accept whatever value we find
        # including null values
        return False
    
    def _get_fallback_value(
        self,
        attribute_name: str,
        unified_records: List[Dict[str, Any]],
        priority_sources: Optional[List[str]] = None,
        ignore_null: bool = False,
        tie_breaker: str = TIE_BREAKER_LATEST,
    ) -> Tuple[Any, Optional[str]]:
        """
        Get a fallback value from any available source.
        
        This is a comprehensive fallback that tries:
        1. First, iterate through priority sources (if provided) in order
        2. Then, try any remaining sources in the order they appear
        
        This ensures we always return a value if one exists in ANY source.
        
        Args:
            attribute_name: The attribute name to get value for
            unified_records: List of unified records
            priority_sources: Optional list of source paths in priority order
            ignore_null: Whether to skip null values in fallback
            
        Returns:
            Tuple of (value, source) or (None, None) if no value found
        """
        # Build a set of sources we've already checked
        checked_sources = set()

        # First, try priority sources in order (if provided and valid)
        if priority_sources:
            for source in priority_sources:
                if source is None:
                    continue
                checked_sources.add(source)

                # Gather every record from this source whose value qualifies,
                # then tie-break by LF_MODIFIED_AT_COL so the result is
                # deterministic across Spark re-evaluations.
                candidates = [
                    r for r in unified_records
                    if r.get("source_path") == source
                    and not (ignore_null and is_null_or_empty(r.get(attribute_name)))
                ]
                winner = self._pick_by_tie_breaker(candidates, tie_breaker)
                if winner is not None:
                    return winner.get(attribute_name), source

        # Second, try any remaining sources not in priority list
        remaining_sources = []
        for record in unified_records:
            source = record.get("source_path")
            if source in checked_sources:
                continue
            if source not in remaining_sources:
                remaining_sources.append(source)

        for source in remaining_sources:
            candidates = [
                r for r in unified_records
                if r.get("source_path") == source
                and not (ignore_null and is_null_or_empty(r.get(attribute_name)))
            ]
            winner = self._pick_latest(candidates)
            if winner is not None:
                return winner.get(attribute_name), source

        # No value found anywhere
        return None, None