"""
Frequency Strategy Implementation.
Selects the value that appears most or least frequently across sources.
"""

from typing import Tuple, Any, Optional
from collections import Counter

from .base import BaseStrategy
from ..models.result import StrategyContext
from ..utils.helpers import is_null_or_empty


class FrequencyStrategy(BaseStrategy):
    """
    Frequency strategy: Select the value that appears most or least frequently.
    
    Configuration:
        strategyRule: Frequency mode
            - "most_frequent" (default): Select the value that appears most often
            - "least_frequent": Select the value that appears least often
        ignoreNull: If True, skip null/empty values when counting frequency
                   If False, include null values in frequency count (can return None if most frequent)
    
    Example:
        {
            "attribute": "customer_status",
            "strategy": "Frequency",
            "strategyRule": "most_frequent",
            "ignoreNull": True
        }
    
    Behavior:
        - Counts occurrences of each unique value across all source records
        - When ignoreNull=False: NULL values are counted and can win if most/least frequent
        - When ignoreNull=True: NULL values are skipped entirely
        - Returns the value with highest/lowest count based on mode
        - In case of tie, returns the first value encountered with that count
        - Source returned is the first source where the winning value was found
    """
    
    # Default mode if not specified
    DEFAULT_MODE = "most_frequent"
    
    # Sentinel value to represent None in the counter (since Counter can't use None as key reliably)
    _NULL_SENTINEL = "__LAKEFUSION_NULL_VALUE__"
    
    def apply(self, context: StrategyContext) -> Tuple[Any, Optional[str]]:
        """
        Apply frequency strategy to select the most/least frequent value.
        
        Args:
            context: StrategyContext with unified records
            
        Returns:
            Tuple of (value, source) for the most/least frequent value,
            or (None, None) if no valid values found
        """
        ignore_null = context.rule_config.ignoreNull
        attribute_name = context.attribute_name
        
        # Get frequency mode from strategyRule
        mode = self._get_frequency_mode(context.rule_config.strategyRule)
        
        # Collect values and track which source each value came from
        value_counts = Counter()
        value_sources = {}  # Maps normalized_value -> (original_value, first_source)
        
        for record in context.unified_records:
            value = record.get(attribute_name)
            source = record.get("source_path")
            
            # Handle null/empty values based on ignoreNull setting
            if is_null_or_empty(value):
                if ignore_null:
                    # ignoreNull=True: Skip null/empty values entirely
                    continue
                else:
                    # ignoreNull=False: Count null values using sentinel
                    # This allows NULL to win if it's the most/least frequent
                    value_counts[self._NULL_SENTINEL] += 1
                    if self._NULL_SENTINEL not in value_sources:
                        value_sources[self._NULL_SENTINEL] = (None, source)
                    continue
            
            # Normalize value for counting (handle type differences)
            normalized_value = self._normalize_value(value)
            
            # Count the value
            value_counts[normalized_value] += 1
            
            # Track the first source where this value was found
            if normalized_value not in value_sources:
                value_sources[normalized_value] = (value, source)  # Store original value
        
        if not value_counts:
            # No values found - use fallback
            return self._get_fallback_value(
                attribute_name=attribute_name,
                unified_records=context.unified_records,
                priority_sources=context.all_priority_sources,
                ignore_null=ignore_null
            )
        
        # Select value based on mode
        if mode == "least_frequent":
            winning_normalized = min(value_counts.keys(), key=lambda k: value_counts[k])
        else:  # most_frequent (default)
            winning_normalized = max(value_counts.keys(), key=lambda k: value_counts[k])
        
        # Get original value and source
        original_value, source = value_sources[winning_normalized]
        
        return original_value, source
    
    def _get_frequency_mode(self, strategy_rule: Any) -> str:
        """
        Extract frequency mode from strategyRule.
        
        Args:
            strategy_rule: The strategyRule from config
            
        Returns:
            "most_frequent" or "least_frequent"
        """
        if strategy_rule in ("most_frequent", "least_frequent"):
            return strategy_rule
        
        # Default to most_frequent
        return self.DEFAULT_MODE
    
    def _normalize_value(self, value: Any) -> str:
        """
        Normalize a value for counting purposes.
        
        This ensures that values like "Test" and "test" or 1 and "1" 
        are counted as the same value.
        
        Args:
            value: The value to normalize
            
        Returns:
            Normalized string representation
        """
        if value is None:
            return self._NULL_SENTINEL

        # STRUCT (dict) and ARRAY (list) values can reach this path when the
        # operator runs Frequency over a complex attribute. Use a canonical
        # JSON form (sorted keys) so equality is order-stable across
        # Python versions.
        if isinstance(value, (dict, list)):
            try:
                import json
                return json.dumps(value, sort_keys=True, default=str)
            except Exception:
                pass

        # Convert to string and normalize
        str_value = str(value).strip()
        
        # For case-insensitive comparison of strings
        # Keep numbers as-is to preserve precision
        try:
            # Check if it's a number
            float(str_value)
            return str_value
        except (ValueError, TypeError):
            # It's a string - normalize case
            return str_value.lower()