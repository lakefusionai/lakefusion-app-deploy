"""
Recency Strategy Implementation.
Selects the value from the most recently updated record.
"""

from typing import Tuple, Any, Optional
from datetime import datetime

from .base import BaseStrategy
from ..models.result import StrategyContext
from ..utils.helpers import is_null_or_empty


class RecencyStrategy(BaseStrategy):
    """
    Recency strategy: Select value from the most recently updated record.
    
    Configuration:
        strategyRule: Name of the date/timestamp attribute to use for comparison (e.g., "updated_at")
        ignoreNull: If True, skip records with null values for this attribute
                   If False, include records with null attribute values (still need valid date)
    
    Example:
        {
            "attribute": "phone",
            "strategy": "Recency",
            "strategyRule": "updated_at",
            "ignoreNull": True
        }
    """
    
    def apply(self, context: StrategyContext) -> Tuple[Any, Optional[str]]:
        """
        Apply recency strategy to select the most recent value.
        
        Args:
            context: StrategyContext with unified records
            
        Returns:
            Tuple of (value, source) from most recent record, or (None, None) if no valid record
        """
        date_attr = context.rule_config.strategyRule
        ignore_null = context.rule_config.ignoreNull
        attribute_name = context.attribute_name
        
        if not date_attr:
            # No date attribute specified - use fallback
            return self._get_fallback_value(
                attribute_name=attribute_name,
                unified_records=context.unified_records,
                priority_sources=context.all_priority_sources,
                ignore_null=ignore_null
            )
        
        # Collect valid records with parseable dates
        valid_records = []
        
        for record in context.unified_records:
            attr_value = record.get(attribute_name)
            date_value = record.get(date_attr)
            
            # Skip if ignoreNull is True and attribute value is null
            if ignore_null and is_null_or_empty(attr_value):
                continue
            
            # Skip if no date value to compare (always need a date for recency)
            if date_value is None:
                continue
            
            # Try to parse the date
            try:
                parsed_date = self._parse_date(date_value)
                valid_records.append((record, parsed_date))
            except (ValueError, TypeError):
                # Can't parse date - skip this record
                continue
        
        if not valid_records:
            # No valid records - use fallback
            return self._get_fallback_value(
                attribute_name=attribute_name,
                unified_records=context.unified_records,
                priority_sources=context.all_priority_sources,
                ignore_null=ignore_null
            )
        
        # Find record with most recent date
        most_recent_record, _ = max(valid_records, key=lambda x: x[1])
        
        return (
            most_recent_record.get(attribute_name),
            most_recent_record.get("source_path")
        )
    
    def _parse_date(self, date_value: Any) -> datetime:
        """
        Parse date value to datetime for comparison.
        
        Args:
            date_value: Date value (string, datetime, or timestamp)
            
        Returns:
            datetime object
            
        Raises:
            ValueError: If date cannot be parsed
        """
        if isinstance(date_value, datetime):
            return date_value
        
        if isinstance(date_value, str):
            # Try common date formats
            formats = [
                "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%d %H:%M:%S.%f",
                "%Y-%m-%d",
                "%Y-%m-%dT%H:%M:%S",
                "%Y-%m-%dT%H:%M:%S.%f",
                "%Y-%m-%dT%H:%M:%SZ",
                "%Y-%m-%dT%H:%M:%S.%fZ",
                "%d/%m/%Y",
                "%m/%d/%Y",
                "%d-%m-%Y",
                "%m-%d-%Y",
            ]
            
            for fmt in formats:
                try:
                    return datetime.strptime(date_value, fmt)
                except ValueError:
                    continue
            
            # Try ISO format with timezone
            try:
                return datetime.fromisoformat(date_value.replace('Z', '+00:00'))
            except ValueError:
                pass
        
        # Handle date objects
        from datetime import date
        if isinstance(date_value, date):
            return datetime.combine(date_value, datetime.min.time())
        
        # Try to convert to string and parse
        try:
            return datetime.fromisoformat(str(date_value))
        except (ValueError, TypeError):
            raise ValueError(f"Cannot parse date: {date_value}")