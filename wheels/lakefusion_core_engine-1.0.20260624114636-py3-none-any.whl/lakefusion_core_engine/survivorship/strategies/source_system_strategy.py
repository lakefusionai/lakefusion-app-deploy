"""
Source System Strategy Implementation.
Prioritizes values based on source system hierarchy.
"""

from typing import Tuple, Any, Optional

from .base import BaseStrategy
from ..models.result import StrategyContext
from ..utils.helpers import is_null_or_empty


class SourceSystemStrategy(BaseStrategy):
    """
    Source System strategy: Prioritize values based on source system hierarchy.
    
    Configuration:
        strategyRule: List of source table paths in priority order (highest to lowest)
        ignoreNull: If True, skip null values and move to next priority source
                   If False, return null if highest priority source has null (default)
    
    Behavior:
        - When ignoreNull=False (default): Returns the value from the highest priority
          source that exists in the unified records, even if that value is null.
        - When ignoreNull=True: Skips null/empty values and returns the first non-null
          value from the priority list.
    
    Example:
        {
            "attribute": "fname",
            "strategy": "Source System",
            "strategyRule": [
                "internal_dev.bronze.customer_primary",
                "internal_dev.bronze.customer_secondary",
                "internal_dev.bronze.customer_legacy"
            ],
            "ignoreNull": True  # Will skip nulls and find first non-null value
        }
    """
    
    def apply(self, context: StrategyContext) -> Tuple[Any, Optional[str]]:
        """
        Apply source system priority to select winning value.

        Args:
            context: StrategyContext with unified records

        Returns:
            Tuple of (value, source) from highest priority source,
            or (None, None) if no valid value found
        """
        priority_sources = context.rule_config.strategyRule
        ignore_null = context.rule_config.ignoreNull
        tie_breaker = context.rule_config.tieBreaker
        attribute_name = context.attribute_name

        # Validate priority sources
        if not priority_sources or not isinstance(priority_sources, list):
            # No priority list specified - use fallback
            return self._get_fallback_value(
                attribute_name=attribute_name,
                unified_records=context.unified_records,
                priority_sources=context.all_priority_sources,
                ignore_null=ignore_null,
                tie_breaker=tie_breaker,
            )

        # Filter out None values from priority sources (can happen from failed ID-to-path conversion)
        valid_priority_sources = [s for s in priority_sources if s is not None]

        if not valid_priority_sources:
            # All sources were None - use fallback
            return self._get_fallback_value(
                attribute_name=attribute_name,
                unified_records=context.unified_records,
                priority_sources=context.all_priority_sources,
                ignore_null=ignore_null,
                tie_breaker=tie_breaker,
            )

        # Check each priority source in order. When multiple records come from
        # the same priority source, tie-break by ``LF_MODIFIED_AT_COL`` with
        # the direction configured on the rule (``latest`` | ``earliest``).
        # If that column is not provided by the caller, falls back to the
        # legacy first-encountered behaviour (handled inside
        # ``_pick_by_tie_breaker``).
        for priority_source in valid_priority_sources:
            candidates = [
                r for r in context.unified_records
                if r.get("source_path") == priority_source
                and not (ignore_null and is_null_or_empty(r.get(attribute_name)))
            ]
            winner = self._pick_by_tie_breaker(candidates, tie_breaker)
            if winner is not None:
                return winner.get(attribute_name), priority_source

        # No value found from any priority source - use comprehensive fallback
        return self._get_fallback_value(
            attribute_name=attribute_name,
            unified_records=context.unified_records,
            priority_sources=context.all_priority_sources,
            ignore_null=ignore_null,
            tie_breaker=tie_breaker,
        )