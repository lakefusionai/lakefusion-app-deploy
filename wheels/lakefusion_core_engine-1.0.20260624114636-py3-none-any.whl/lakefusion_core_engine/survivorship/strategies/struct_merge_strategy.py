"""
Struct Merge Strategy.

Merges STRUCT sub-fields field-by-field from multiple contributing sources.
Each sub-field is resolved independently using coalesce-with-priority:

    1. Walk contributors in the configured source-priority order
       (``strategyRule`` list, same shape as Source System).
    2. For each sub-field, pick the first non-null value from the first
       priority source that has it.
    3. If no priority list is configured, walk contributors in their
       natural order (first non-null wins per sub-field).

Differs from Source System (which picks one whole struct from one source):
- Source System returns the priority-1 struct AS-IS, including its null
  sub-fields, even when a lower-priority source has a non-null value.
- Struct Merge fills every sub-field independently — Source A may
  contribute ``street`` and ``city`` while Source B contributes ``zip``.

Source provenance returned as a comma-separated list of all sources that
contributed at least one winning sub-field, in priority order.

Configuration:
    strategy: "Struct Merge"
    strategyRule: ["DatasetA", "DatasetB", ...]  # optional, like Source System
    ignoreNull: bool  (default False) — when True, treat empty / null
                                        sub-fields as missing so the next
                                        priority source can win that field.

Example:
    {
        "attribute": "address",
        "strategy": "Struct Merge",
        "strategyRule": ["DatasetA", "DatasetB"],
        "ignoreNull": True
    }
"""
from typing import Any, Dict, List, Optional, Tuple

from .base import BaseStrategy
from ..models.result import StrategyContext
from ..utils.helpers import is_null_or_empty


class StructMergeStrategy(BaseStrategy):
    """Per-sub-field merge of STRUCT contributors."""

    def apply(self, context: StrategyContext) -> Tuple[Any, Optional[str]]:
        """Build a merged STRUCT value from contributors.

        Returns ``(merged_struct, sources)`` where ``sources`` is a
        comma-separated, deduplicated list of source paths that won at
        least one sub-field. Returns ``(None, None)`` when no contributor
        has any struct value for the attribute.
        """
        attribute_name = context.attribute_name
        ignore_null = context.rule_config.ignoreNull
        priority_sources = context.rule_config.strategyRule

        # Build {source -> struct dict} keeping only contributors that have
        # a struct shape (dict) value. None / non-dict values are ignored
        # because per-sub-field merge requires the dict to walk.
        struct_by_source: Dict[str, Dict[str, Any]] = {}
        all_sub_fields: List[str] = []
        seen_sub_fields = set()

        for record in context.unified_records:
            source = record.get("source_path")
            value = record.get(attribute_name)
            if not source:
                continue
            if not isinstance(value, dict):
                continue
            # Last-write-wins per source if there are multiple records from
            # the same priority source — mirrors Source System pre-tie-break
            # behaviour for simple deterministic output. (Recency-style
            # tie-breaks left for a v2 enhancement.)
            struct_by_source[source] = value
            for sf in value.keys():
                if sf not in seen_sub_fields:
                    seen_sub_fields.add(sf)
                    all_sub_fields.append(sf)

        if not struct_by_source:
            return self._get_fallback_value(
                attribute_name=attribute_name,
                unified_records=context.unified_records,
                priority_sources=context.all_priority_sources,
                ignore_null=ignore_null,
            )

        # Build the walk order. Priority list first (only the sources we
        # actually have a struct for), then any remaining contributors in
        # natural record order so out-of-priority sources still contribute
        # when the priority list is incomplete.
        walk_order: List[str] = []
        if isinstance(priority_sources, list):
            for src in priority_sources:
                if src in struct_by_source and src not in walk_order:
                    walk_order.append(src)
        for src in struct_by_source:
            if src not in walk_order:
                walk_order.append(src)

        merged: Dict[str, Any] = {}
        winning_sources: List[str] = []

        for sub_field in all_sub_fields:
            for src in walk_order:
                candidate = struct_by_source[src].get(sub_field)
                if candidate is None:
                    # null sub-field: skip unless ignoreNull=False AND this
                    # is the lowest-priority candidate (handled by falling
                    # through to the final assignment below).
                    if ignore_null:
                        continue
                    # ignoreNull=False: only accept null if NO non-null
                    # contributor exists (handled below). Continue walking.
                    continue
                if is_null_or_empty(candidate):
                    if ignore_null:
                        continue
                merged[sub_field] = candidate
                if src not in winning_sources:
                    winning_sources.append(src)
                break
            else:
                # No non-null candidate found. Honor ignoreNull semantics:
                # leave key absent vs explicit None on the merged struct.
                if ignore_null:
                    merged[sub_field] = None
                else:
                    merged[sub_field] = None

        # Emit sources in the same order they were walked (priority list
        # first, then natural-order tail) — operators reading the audit
        # row see priority-source contributions before fallback ones.
        ordered_winners = [s for s in walk_order if s in winning_sources]
        return merged, ",".join(ordered_winners) if ordered_winners else None
