"""
Utilities module for lakefusion_core_engine.

Provides common utility functions for model serving, logging, parsing, and constants.

Backend-safe submodules are imported eagerly. Pipeline-only submodules that pull
in pyspark are imported lazily — backend services install only the SDK side of
core_engine, so importing pyspark-dependent helpers there would raise
ModuleNotFoundError at startup.
"""

from .constants import Constants, LF_CREATED_AT_COL, LF_MODIFIED_AT_COL
from .validation_functions_constant import (
    EMAIL_REGEX,
    validate_email,
    check_dob_suspicious,
    is_string_null_or_empty,
    is_contains_numbers,
)
from .taskvalues_enum import TaskValueKey
from .databricks_groups import (
    ensure_account_group,
    get_job_owner_id,
    grant_uc_object_permissions,
    set_job_permissions_with_owner,
    grant_serving_endpoint_permissions,
    grant_uc_model_privileges,
    add_group_members_by_email,
)

# pyspark-dependent helpers — skipped when pyspark is not installed.
try:
    from .model_serving import (
        MODEL_PATH_MAPPINGS,
        wait_until_serving_endpoint_ready,
        wait_until_vector_search_ready,
        sync_index_with_retry,
        warm_up_llm_endpoint,
        get_serving_endpoint_status,
        wait_for_serving_endpoint,
        create_serving_endpoint,
        create_serving_endpoint_foundational,
        create_and_sync_vector_index,
    )
    from .parse_utils import (
        get_primary_dataset_path,
        get_dataset_tables,
        parse_attributes_mapping,
        parse_attributes_mapping_json,
        get_default_survivorship_rules,
        get_primary_attr_mapping,
        remove_primary_from_attr_mapping,
        get_spark_data_type,
        create_schema_fields,
        validation_function_exec,
        get_version_info,
        get_custom_tags,
        get_resource_tags,
        get_user_agent_header_sql,
        append_schema_tags,
        append_table_tags,
        apply_tags_to_uc_resource,
    )
    from .survivorship_cast import cast_merged_value, merged_record_column
except ModuleNotFoundError as _e:
    if _e.name != "pyspark":
        raise

__all__ = [
    # Constants
    'Constants',
    'LF_CREATED_AT_COL',
    'LF_MODIFIED_AT_COL',
    # Model Serving
    'MODEL_PATH_MAPPINGS',
    'wait_until_serving_endpoint_ready',
    'wait_until_vector_search_ready',
    'sync_index_with_retry',
    'warm_up_llm_endpoint',
    'get_serving_endpoint_status',
    'wait_for_serving_endpoint',
    'create_serving_endpoint',
    'create_serving_endpoint_foundational',
    'create_and_sync_vector_index',
    # Parse Utilities
    'get_primary_dataset_path',
    'get_dataset_tables',
    'parse_attributes_mapping',
    'parse_attributes_mapping_json',
    'get_default_survivorship_rules',
    'get_primary_attr_mapping',
    'remove_primary_from_attr_mapping',
    'get_spark_data_type',
    'create_schema_fields',
    'validation_function_exec',
    'get_version_info',
    'get_custom_tags',
    'get_resource_tags',
    'get_user_agent_header_sql',
    'append_schema_tags',
    'append_table_tags',
    'apply_tags_to_uc_resource',
    # Validation Functions
    'EMAIL_REGEX',
    'validate_email',
    'check_dob_suspicious',
    'is_string_null_or_empty',
    'is_contains_numbers',
    # Task Value Keys
    'TaskValueKey',
    # Survivorship cast helpers
    'cast_merged_value',
    'merged_record_column',
    # Databricks Groups
    'ensure_account_group',
    'get_job_owner_id',
    'grant_uc_object_permissions',
    'set_job_permissions_with_owner',
    'grant_serving_endpoint_permissions',
    'grant_uc_model_privileges',
    'add_group_members_by_email',
]
