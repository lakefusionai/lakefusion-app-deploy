"""Attribute description helpers for LLM prompt enrichment.

The LLM matching prompts list match attributes in a fixed pipe-delimited
order. For scalar attributes the bare name is sufficient. For STRUCT /
ARRAY attributes the bare name leaves the model guessing what the
serialized value contains — leading to lower scoring quality.

This module produces an enriched, human-readable descriptor per attribute
so the prompt becomes self-documenting without requiring sub-field
selection on the model config (intentionally OUT OF SCOPE for MVP per PRD).

Examples
--------
Given attribute records:
    [
        {"name": "first_name", "type": "STRING", "is_array": False},
        {"name": "alternate_names", "type": "STRING", "is_array": True},
        {"name": "address", "type": "STRUCT", "is_array": False,
         "struct_definition": {"name": "Address",
                               "fields": [{"name": "street"}, {"name": "city"}]}},
        {"name": "phone_numbers", "type": "STRUCT", "is_array": True,
         "struct_definition": {"fields": [{"name": "type"}, {"name": "number"}]}},
    ]

Then `build_attribute_descriptors(["first_name", "alternate_names",
"address", "phone_numbers"], records)` returns:

    "first_name | alternate_names (array of strings) | "
    "address (street, city) | phone_numbers (array of: type, number)"
"""
from __future__ import annotations

from typing import Any, Iterable, List, Mapping, Sequence


def _normalize_type(t: Any) -> str:
    return str(t or "").strip().upper()


def _records_by_name(records: Iterable[Mapping[str, Any]]) -> dict:
    out: dict = {}
    for r in records or []:
        if isinstance(r, Mapping) and r.get("name"):
            out[r["name"]] = r
    return out


def _struct_field_names(record: Mapping[str, Any]) -> List[str]:
    """Return the struct sub-field names in ordinal_position order.

    Honors ``selected_sub_fields`` when present on the record (filters and
    re-orders to that subset). When it is missing or empty, returns every
    field on the struct in ordinal_position order.
    """
    sd = record.get("struct_definition") or {}
    fields = list((sd.get("fields") if isinstance(sd, Mapping) else None) or [])
    fields.sort(
        key=lambda f: f.get("ordinal_position", 0)
        if isinstance(f, Mapping)
        else 0
    )
    all_names = [
        f["name"]
        for f in fields
        if isinstance(f, Mapping) and f.get("name")
    ]

    selected = record.get("selected_sub_fields")
    if selected:
        wanted = list(selected)
        wanted_set = set(wanted)
        # Preserve struct's ordinal order; filter to selection; append any
        # selected names that aren't on the struct so the prompt still
        # documents the user's intent even if the entity drifted.
        ordered = [n for n in all_names if n in wanted_set]
        extras = [n for n in wanted if n not in set(all_names)]
        return ordered + extras
    return all_names


# Render scalar types into singular nouns used inside "array of ..." phrases.
# Mapping intentionally narrow — anything not listed falls back to lowercased
# type name so unknown scalar types still produce readable output.
_SCALAR_ARRAY_NOUN = {
    "STRING": "strings",
    "INT": "ints",
    "BIGINT": "longs",
    "DOUBLE": "doubles",
    "FLOAT": "floats",
    "DECIMAL": "decimals",
    "BOOLEAN": "booleans",
    "DATE": "dates",
    "TIMESTAMP": "timestamps",
}


def _array_scalar_noun(type_str: str) -> str:
    return _SCALAR_ARRAY_NOUN.get(_normalize_type(type_str), _normalize_type(type_str).lower() + "s")


def build_attribute_descriptor(
    attribute_name: str,
    record: Mapping[str, Any] | None,
) -> str:
    """Build a single enriched descriptor for one attribute.

    Returns the bare attribute name when:
    - `record` is None (legacy callers / scalar attribute not in records list)
    - `record` describes a plain scalar (no is_array, type != STRUCT)
    """
    if not record:
        return attribute_name

    raw_type = _normalize_type(record.get("type"))
    is_array = bool(record.get("is_array", False))

    # Scalar (non-array, non-struct) -> bare name. Keeps scalar prompt output
    # byte-identical to the legacy `' | '.join(attributes)` for entities that
    # carry no complex types.
    if not is_array and raw_type != "STRUCT":
        return attribute_name

    # ARRAY<STRUCT>
    if is_array and raw_type == "STRUCT":
        field_names = _struct_field_names(record)
        if field_names:
            return f"{attribute_name} (array of: {', '.join(field_names)})"
        return f"{attribute_name} (array of structs)"

    # ARRAY<scalar>
    if is_array:
        return f"{attribute_name} (array of {_array_scalar_noun(raw_type)})"

    # STRUCT (non-array)
    field_names = _struct_field_names(record)
    if field_names:
        return f"{attribute_name} ({', '.join(field_names)})"
    return f"{attribute_name} (struct)"


def merge_selected_sub_fields(
    attribute_records: Iterable[Mapping[str, Any]],
    selected_sub_fields_by_attr: Mapping[str, Sequence[str]] | None,
) -> List[Dict[str, Any]]:
    """Return a copy of ``attribute_records`` with ``selected_sub_fields``
    copied onto each matching record.

    Sub-field selection lives on the model experiment's attribute list, not
    on the entity attribute. Use this helper to fold the model-config
    selection into the entity-level records before passing them to
    :func:`build_attribute_descriptors`.
    """
    selection = selected_sub_fields_by_attr or {}
    out: List[Dict[str, Any]] = []
    for rec in attribute_records or []:
        if not isinstance(rec, Mapping):
            continue
        copy = dict(rec)
        name = copy.get("name")
        if name and name in selection:
            sel = selection[name]
            if sel:
                copy["selected_sub_fields"] = list(sel)
        out.append(copy)
    return out


def build_attribute_descriptors(
    attribute_names: Sequence[str],
    attribute_records: Iterable[Mapping[str, Any]] | None = None,
    separator: str = " | ",
) -> str:
    """Build the full pipe-delimited descriptor string used in LLM prompts.

    Args:
        attribute_names: ordered list of match attribute names (the names
            that appear in `attributes_combined`, in the same order).
        attribute_records: optional list of full entity attribute records
            (name + type + is_array + struct_definition). When None or
            empty, every attribute renders as its bare name — identical to
            the pre- `' | '.join(attributes)` output.
        separator: between-attribute separator. Defaults to ` | ` to match
            the legacy prompt format.
    """
    by_name = _records_by_name(attribute_records or [])
    parts = [build_attribute_descriptor(name, by_name.get(name)) for name in attribute_names]
    return separator.join(parts)
