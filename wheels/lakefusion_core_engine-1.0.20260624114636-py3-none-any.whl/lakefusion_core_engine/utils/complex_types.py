"""Complex-type (STRUCT / ARRAY) helpers for schema-evolution executors.

The pipeline notebooks load `utils/spark_types.py` and `utils/complex_type_mapping.py`
via Databricks `%run`, which puts those symbols in the notebook global namespace.
The schema-evolution tasks run as importable executor classes inside the
`lakefusion_core_engine` package and cannot `%run`, so this module re-homes the
exact same logic (Spark type resolution + source->target projection) as a normal
import. Keep it in sync with:

    dbx_pipeline_artifacts/src/utils/spark_types.py
    dbx_pipeline_artifacts/src/utils/complex_type_mapping.py
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

import pyspark.sql.functions as F
from pyspark.sql import Column, DataFrame
from pyspark.sql.types import (
    ArrayType,
    BooleanType,
    ByteType,
    DataType,
    DateType,
    DecimalType,
    DoubleType,
    FloatType,
    IntegerType,
    LongType,
    ShortType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)


# ─── Scalar type resolution (mirror of spark_types._SCALAR_TYPE_MAP) ──────────
_SCALAR_TYPE_MAP: Dict[str, DataType] = {
    "BIGINT": LongType(),
    "BOOLEAN": BooleanType(),
    "DATE": DateType(),
    "DOUBLE": DoubleType(),
    "FLOAT": FloatType(),
    "INT": IntegerType(),
    "SMALLINT": ShortType(),
    "STRING": StringType(),
    "TINYINT": ByteType(),
    "TIMESTAMP": TimestampType(),
    "DECIMAL": DecimalType(10, 2),
    # Legacy lowercase / verbose variants
    "bigint": LongType(),
    "boolean": BooleanType(),
    "char": StringType(),
    "varchar": StringType(),
    "date": DateType(),
    "double precision": DoubleType(),
    "double": DoubleType(),
    "integer": IntegerType(),
    "int": IntegerType(),
    "long": LongType(),
    "numeric": FloatType(),
    "real": FloatType(),
    "smallint": ShortType(),
    "text": StringType(),
    "string": StringType(),
    "timestamp": TimestampType(),
    "float": FloatType(),
    "decimal": DecimalType(10, 2),
}


def get_spark_data_type(dtype_str: Any) -> DataType:
    """Resolve a scalar type name to a Spark DataType (StringType fallback)."""
    if dtype_str is None:
        return StringType()
    if dtype_str in _SCALAR_TYPE_MAP:
        return _SCALAR_TYPE_MAP[dtype_str]
    return _SCALAR_TYPE_MAP.get(str(dtype_str).lower(), StringType())


def _normalize_type(t: Any) -> str:
    return str(t or "").strip().upper()


def _struct_type_from_fields(fields: Iterable[Mapping[str, Any]]) -> StructType:
    """Build a StructType from struct-field records, respecting ordinal_position."""
    sorted_fields = sorted(
        list(fields),
        key=lambda f: f.get("ordinal_position", 0) if isinstance(f, Mapping) else 0,
    )
    return StructType(
        [
            StructField(f["name"], get_spark_data_type(f.get("data_type")), True)
            for f in sorted_fields
            if isinstance(f, Mapping) and f.get("name")
        ]
    )


def get_complex_spark_data_type(attribute: Mapping[str, Any]) -> DataType:
    """Resolve any attribute record (scalar or complex) to a Spark DataType.

    Honours `is_array` (orthogonal) and `struct_definition.fields` for STRUCT.
    """
    if not isinstance(attribute, Mapping):
        return StringType()

    raw_type = attribute.get("type")
    type_norm = _normalize_type(raw_type)
    is_array = bool(attribute.get("is_array", False))

    if type_norm == "STRUCT":
        struct_def = attribute.get("struct_definition") or {}
        fields = (struct_def.get("fields") if isinstance(struct_def, Mapping) else None) or []
        struct_type = _struct_type_from_fields(fields)
        return ArrayType(struct_type) if is_array else struct_type

    scalar_type = get_spark_data_type(raw_type)
    return ArrayType(scalar_type) if is_array else scalar_type


def is_complex_attr(record: Optional[Mapping[str, Any]]) -> bool:
    """True when an attribute record is STRUCT or any is_array=True."""
    if not isinstance(record, Mapping):
        return False
    return bool(record.get("is_array")) or _normalize_type(record.get("type")) == "STRUCT"


def complex_column_ddl(attribute: Mapping[str, Any]) -> str:
    """Render the Spark DDL type string for an attribute (e.g. "array<struct<a:string>>").

    Used by ALTER TABLE ADD COLUMNS. `simpleString()` emits valid Databricks DDL
    for scalar, ARRAY<...>, STRUCT<...> and ARRAY<STRUCT<...>>.
    """
    return get_complex_spark_data_type(attribute).simpleString()


def parse_engine_complex_value(value: Any) -> Any:
    """Parse a survivorship-engine complex value back to native dict / list.

    SurvivorshipEngine.apply_survivorship runs every value through safe_str(),
    which JSON-serializes STRUCT / ARRAY values. Parse them back so a typed
    Spark schema accepts them as nested columns. Mirrors the driver-side helper
    in Incremental_Load_To_Unified.py.
    """
    import json

    if value is None or isinstance(value, (dict, list)):
        return value
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        try:
            return json.loads(s)
        except (ValueError, TypeError):
            return None
    return value


# ─── Source -> target projection (mirror of complex_type_mapping.py) ──────────

class StructSchemaMismatchError(RuntimeError):
    """Raised when a source struct column does not match the target struct definition."""


# Keep in sync with EntityAttributeTypeCompatibility (portal) and
# complex_type_mapping._TYPE_COMPATIBILITY.
_SOURCE_TYPE_ALIASES: Dict[str, str] = {
    "TIMESTAMP_NTZ": "TIMESTAMP",
    "TIMESTAMP_LTZ": "TIMESTAMP",
}

_TYPE_COMPATIBILITY: Dict[str, set] = {
    "STRING": {"STRING", "CHAR", "VARCHAR", "TEXT", "BOOLEAN", "BIGINT", "LONG", "INT", "INTEGER", "SMALLINT", "TINYINT", "SHORT", "BYTE", "DOUBLE", "FLOAT", "DECIMAL", "NUMERIC", "DATE", "TIMESTAMP"},
    "BOOLEAN": {"BOOLEAN", "BIGINT", "LONG", "INT", "INTEGER", "SMALLINT", "TINYINT", "SHORT", "BYTE"},
    "BIGINT": {"BIGINT", "LONG", "INT", "INTEGER", "SMALLINT", "TINYINT", "SHORT", "BYTE", "BOOLEAN"},
    "LONG": {"BIGINT", "LONG", "INT", "INTEGER", "SMALLINT", "TINYINT", "SHORT", "BYTE", "BOOLEAN"},
    "INT": {"INT", "INTEGER", "SMALLINT", "TINYINT", "SHORT", "BYTE", "BOOLEAN", "BIGINT", "LONG"},
    "INTEGER": {"INT", "INTEGER", "SMALLINT", "TINYINT", "SHORT", "BYTE", "BOOLEAN", "BIGINT", "LONG"},
    "SMALLINT": {"SMALLINT", "SHORT", "TINYINT", "BYTE", "BOOLEAN", "INT", "INTEGER", "BIGINT", "LONG"},
    "SHORT": {"SHORT", "SMALLINT", "TINYINT", "BYTE", "BOOLEAN", "INT", "INTEGER", "BIGINT", "LONG"},
    "TINYINT": {"TINYINT", "BYTE", "BOOLEAN", "SMALLINT", "SHORT", "INT", "INTEGER", "BIGINT", "LONG"},
    "BYTE": {"BYTE", "TINYINT", "BOOLEAN", "SHORT", "SMALLINT", "INT", "INTEGER", "BIGINT", "LONG"},
    "DOUBLE": {"DOUBLE", "FLOAT", "DECIMAL", "NUMERIC", "BIGINT", "LONG", "INT", "INTEGER", "SMALLINT", "TINYINT", "SHORT", "BYTE", "BOOLEAN"},
    "FLOAT": {"FLOAT", "DOUBLE", "DECIMAL", "NUMERIC", "BIGINT", "LONG", "INT", "INTEGER", "SMALLINT", "TINYINT", "SHORT", "BYTE", "BOOLEAN"},
    "DATE": {"DATE", "TIMESTAMP"},
    "TIMESTAMP": {"TIMESTAMP", "DATE"},
}


def _spark_dtype_name(dt: DataType) -> str:
    return dt.simpleString().upper()


def _expected_struct_fields(struct_definition: Mapping[str, Any]) -> List[Dict[str, str]]:
    fields = list((struct_definition or {}).get("fields") or [])
    fields.sort(key=lambda f: f.get("ordinal_position", 0) if isinstance(f, Mapping) else 0)
    return [
        {"name": f["name"], "data_type": _normalize_type(f.get("data_type"))}
        for f in fields
        if isinstance(f, Mapping) and f.get("name")
    ]


def _scalar_compat(target_type: str, source_type: str) -> bool:
    compat = _TYPE_COMPATIBILITY.get((target_type or "").upper())
    if not compat:
        return True
    src = (source_type or "").upper().split("(")[0].strip()
    return (_SOURCE_TYPE_ALIASES.get(src, src)) in compat


def _validate_struct_schema_match(
    source_struct_type: StructType,
    expected_fields: Sequence[Mapping[str, str]],
    source_column: str,
    target_attr_name: str,
    target_struct_name: str,
) -> None:
    expected_by_name = {f["name"]: f["data_type"] for f in expected_fields}
    source_by_name = {f.name: _spark_dtype_name(f.dataType) for f in source_struct_type.fields}

    if set(expected_by_name) != set(source_by_name):
        raise StructSchemaMismatchError(
            f"Source column '{source_column}' struct schema does not match "
            f"target struct definition '{target_struct_name}' for attribute "
            f"'{target_attr_name}'. Expected fields: {sorted(expected_by_name)}. "
            f"Found: {sorted(source_by_name)}."
        )

    type_mismatches = [
        (name, expected_by_name[name], source_by_name[name])
        for name in expected_by_name
        if not _scalar_compat(expected_by_name[name], source_by_name[name])
    ]
    if type_mismatches:
        details = ", ".join(f"{n}: expected {e}, got {a}" for n, e, a in type_mismatches)
        raise StructSchemaMismatchError(
            f"Source column '{source_column}' struct field types do not match "
            f"target struct definition '{target_struct_name}' for attribute "
            f"'{target_attr_name}'. Mismatches: {details}."
        )


def _struct_target_type(struct_definition: Mapping[str, Any]) -> StructType:
    spark_t = get_complex_spark_data_type(
        {"type": "STRUCT", "is_array": False, "struct_definition": struct_definition}
    )
    assert isinstance(spark_t, StructType)
    return spark_t


def _resolve_source_struct_type(df: DataFrame, source_column: str) -> StructType:
    schema = df.schema
    if source_column not in schema.fieldNames():
        raise StructSchemaMismatchError(
            f"Source column '{source_column}' not found in dataset. "
            f"Available columns: {schema.fieldNames()}."
        )
    src_field = schema[source_column].dataType
    inner = src_field.elementType if isinstance(src_field, ArrayType) else src_field
    if not isinstance(inner, StructType):
        raise StructSchemaMismatchError(
            f"Source column '{source_column}' is not a STRUCT or ARRAY<STRUCT> — "
            f"cannot be used with mode='direct_column'."
        )
    return inner


def _direct_column_expr(df: DataFrame, source_column: str, target_record: Mapping[str, Any]) -> Column:
    target_is_array = bool(target_record.get("is_array"))
    expected_fields = _expected_struct_fields(target_record.get("struct_definition") or {})

    src_dt = df.schema[source_column].dataType
    source_struct = _resolve_source_struct_type(df, source_column)

    _validate_struct_schema_match(
        source_struct,
        expected_fields,
        source_column=source_column,
        target_attr_name=target_record.get("name", "?"),
        target_struct_name=(target_record.get("struct_definition") or {}).get("name") or "(unnamed)",
    )

    def _reorder(struct_col: Column) -> Column:
        return F.struct(
            *[
                struct_col.getField(f["name"]).cast(get_spark_data_type(f["data_type"])).alias(f["name"])
                for f in expected_fields
            ]
        )

    src_col = F.col(source_column)
    if isinstance(src_dt, ArrayType):
        reordered = F.transform(src_col, lambda elem: _reorder(elem))
        return reordered if target_is_array else reordered.getItem(0)
    reordered = _reorder(src_col)
    return F.array(reordered) if target_is_array else reordered


def _subfield_assembly_expr(sub_field_map: Mapping[str, str], target_record: Mapping[str, Any]) -> Column:
    expected_fields = _expected_struct_fields(target_record.get("struct_definition") or {})
    target_is_array = bool(target_record.get("is_array"))

    pieces: List[Column] = []
    for f in expected_fields:
        target_name = f["name"]
        target_type = f["data_type"]
        src_col_name = sub_field_map.get(target_name)
        if src_col_name:
            pieces.append(F.col(src_col_name).cast(get_spark_data_type(target_type)).alias(target_name))
        else:
            pieces.append(F.lit(None).cast(get_spark_data_type(target_type)).alias(target_name))

    struct_expr = F.struct(*pieces)
    return F.array(struct_expr) if target_is_array else struct_expr


def _scalar_to_array_expr(source_column: str, target_record: Mapping[str, Any]) -> Column:
    element_dtype = get_spark_data_type(target_record.get("type") or "STRING")
    return F.array(F.col(source_column).cast(element_dtype))


def project_attribute_expr(
    df: DataFrame,
    mapping_record: Mapping[str, Any],
    target_record: Mapping[str, Any],
) -> Optional[Column]:
    """Build the typed Column for a single attribute from one source mapping.

    Returns None when the mapping cannot be projected (missing source column).
    Handles all modes: direct_column / subfield_assembly STRUCT, scalar ARRAY
    auto-wrap or pass-through, and plain scalar cast.
    """
    mode = mapping_record.get("mode")
    target_is_struct = _normalize_type(target_record.get("type")) == "STRUCT"
    target_is_array = bool(target_record.get("is_array"))

    if target_is_struct and mode == "direct_column":
        src_col = mapping_record.get("dataset_attribute")
        return _direct_column_expr(df, src_col, target_record)

    if target_is_struct and mode == "subfield_assembly":
        sub_map = mapping_record.get("sub_field_map") or {}
        return _subfield_assembly_expr(sub_map, target_record)

    if (not target_is_struct) and target_is_array:
        src_col_name = mapping_record.get("dataset_attribute")
        if not src_col_name:
            return None
        src_dt = df.schema[src_col_name].dataType if src_col_name in df.schema.fieldNames() else None
        if isinstance(src_dt, ArrayType):
            element_dtype = get_spark_data_type(target_record.get("type") or "STRING")
            return F.transform(F.col(src_col_name), lambda x: x.cast(element_dtype))
        return _scalar_to_array_expr(src_col_name, target_record)

    src_col_name = mapping_record.get("dataset_attribute")
    if not src_col_name:
        return None
    return F.col(src_col_name).cast(get_spark_data_type(target_record.get("type") or "STRING"))
