"""Engine-wide constants."""


# Reserved system columns on the `*_unified` table. Double-underscore prefix
# avoids collision with user-defined entity attributes (which can legitimately
# be named `created_at`, `updated_at`, `modified_at`, etc.).
#
# `LF_CREATED_AT_COL`  - first time the record landed in the unified table.
# `LF_MODIFIED_AT_COL` - last time the record's attribute values were changed.
#                        Used by the survivorship engine as a tie-breaker when
#                        multiple records compete for the same priority slot.
LF_CREATED_AT_COL = "__lf_created_at"
LF_MODIFIED_AT_COL = "__lf_modified_at"


class Constants:
    CONSTANT_ONE = "TEST"
