"""
Utility for updating the golden dedup potential_match_deduplicate table
after a source record unmerge. Performs a targeted update of the affected
merged master's entry rather than rebuilding the entire table.
"""


def update_golden_dedup_after_unmerge(
    spark,
    catalog_name,
    entity,
    experiment_id,
    survivor_id,
    unmerged_sks,
    entity_attributes,
    unified_id_key="surrogate_key",
    logger=None,
):
    """
    After a source record is unmerged from a master, update the golden dedup
    potential_match_deduplicate table to reflect the current merge health of
    any affected absorbed masters.

    Args:
        spark: SparkSession
        catalog_name: Catalog name (e.g. "lakefusion_ai")
        entity: Entity name (lowercase)
        experiment_id: Experiment ID or empty string
        survivor_id: The master lakefusion_id from which records were unmerged
        unmerged_sks: List of surrogate_keys that were unmerged
        entity_attributes: List of entity attribute names
        unified_id_key: Column name for the unified table's primary key (default: surrogate_key)
        logger: Optional logger
    """
    def _log(msg):
        if logger:
            logger.info(msg)

    # Build table names
    master_table = f"{catalog_name}.gold.{entity}_master"
    unified_table = f"{catalog_name}.silver.{entity}_unified"
    potential_match_dedup_table = f"{catalog_name}.gold.{entity}_master_potential_match_deduplicate"
    if experiment_id:
        master_table += f"_{experiment_id}"
        unified_table += f"_{experiment_id}"
        potential_match_dedup_table += f"_{experiment_id}"
    merge_activities_table = f"{master_table}_merge_activities"

    # Check if golden dedup table exists
    if not spark.catalog.tableExists(potential_match_dedup_table):
        _log("  Golden dedup table does not exist, skipping health update")
        return

    id_key = "lakefusion_id"
    sk_list_sql = ", ".join(f"'{sk}'" for sk in unmerged_sks)

    # Step 1: Find which merged masters the unmerged sks originally belonged to
    # These are masters that are NOT currently active (they were absorbed)
    affected_query = f"""
    SELECT DISTINCT ma.master_id AS original_master
    FROM {merge_activities_table} ma
    WHERE ma.match_id IN ({sk_list_sql})
      AND ma.action_type IN ('JOB_INSERT', 'JOB_MERGE', 'MANUAL_MERGE', 'INITIAL_LOAD')
      AND ma.master_id != '{survivor_id}'
      AND ma.master_id NOT IN (SELECT {id_key} FROM {master_table})
    """

    affected_rows = spark.sql(affected_query).collect()
    affected_masters = [row['original_master'] for row in affected_rows]

    if not affected_masters:
        _log("  No affected merged masters found in golden dedup, skipping")
        return

    _log(f"  Affected merged masters: {affected_masters}")

    # Step 2: For each affected master, compute health
    for merged_master_id in affected_masters:
        health_query = f"""
        WITH source_records AS (
            SELECT DISTINCT ma.match_id AS source_sk
            FROM {merge_activities_table} ma
            WHERE ma.master_id = '{merged_master_id}'
              AND ma.action_type IN ('JOB_INSERT', 'JOB_MERGE', 'MANUAL_MERGE', 'INITIAL_LOAD')
              AND ma.match_id LIKE 'sk_%'
        )
        SELECT
            COUNT(DISTINCT sr.source_sk) AS total,
            COUNT(DISTINCT CASE
                WHEN u.master_{id_key} = '{survivor_id}'
                 AND u.record_status != 'DELETED'
                THEN sr.source_sk
            END) AS remaining
        FROM source_records sr
        LEFT JOIN {unified_table} u
            ON u.{unified_id_key} = sr.source_sk
        """

        health = spark.sql(health_query).collect()[0]
        remaining = health['remaining']
        total = health['total']

        _log(f"  Master {merged_master_id}: remaining={remaining}, total={total}")

        if total == 0:
            _log(f"  No source records found for {merged_master_id}, skipping")
            continue

        if remaining == 0:
            # Fully unmerged — remove from potential_matches array
            _log(f"  Fully unmerged — removing {merged_master_id} from golden dedup")
            filter_sql = f"""
            UPDATE {potential_match_dedup_table}
            SET potential_matches = FILTER(potential_matches, x -> x.{id_key} != '{merged_master_id}')
            WHERE {id_key} = '{survivor_id}'
            """
            spark.sql(filter_sql)

        elif remaining < total:
            # Partially merged — update __mergestatus__ and counts
            _log(f"  Partially merged — updating {merged_master_id} to MASTER_PARTIAL_MERGE ({remaining}/{total})")

            # Build NAMED_STRUCT that preserves all existing fields but overrides status fields
            struct_parts = []
            for attr in entity_attributes:
                struct_parts.append(f"'{attr}', x.{attr}")
            struct_parts.extend([
                "'__score__', x.__score__",
                "'__reason__', x.__reason__",
                f"'{id_key}', x.{id_key}",
                "'__mergestatus__', 'MASTER_PARTIAL_MERGE'",
                f"'__merge_remaining__', CAST({remaining} AS STRING)",
                f"'__merge_total__', CAST({total} AS STRING)",
                "'__attributes_combined__', x.__attributes_combined__",
            ])
            named_struct_expr = f"named_struct({', '.join(struct_parts)})"

            transform_sql = f"""
            UPDATE {potential_match_dedup_table}
            SET potential_matches = TRANSFORM(potential_matches, x ->
                IF(x.{id_key} = '{merged_master_id}',
                    {named_struct_expr},
                    x
                )
            )
            WHERE {id_key} = '{survivor_id}'
            """
            spark.sql(transform_sql)

        else:
            _log(f"  Still fully merged ({remaining}/{total}), no update needed")

    _log("  Golden dedup health update complete")
