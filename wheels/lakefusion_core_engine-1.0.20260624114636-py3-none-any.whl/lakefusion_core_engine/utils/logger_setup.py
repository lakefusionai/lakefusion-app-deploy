from lakefusion_core_engine.utils.logging_utils import DatabricksLogger


def init_logger(task_name, run_id, task_run_id, pipeline_type, job_id, catalog_name):
    """
    Creates and returns (logger_instance, logger)

    catalog_name is optional if you want catalog-specific volume logging.
    """

   

    logger_instance = DatabricksLogger(
        logger_name=task_name,
        run_id=run_id,
        task_name=task_name,
        task_run_id=task_run_id,
        pipeline_type=pipeline_type,
        job_id=job_id,
        catalog_name=catalog_name,
        log_directory=None
    )

    logger = logger_instance.get_logger()
    return logger_instance, logger