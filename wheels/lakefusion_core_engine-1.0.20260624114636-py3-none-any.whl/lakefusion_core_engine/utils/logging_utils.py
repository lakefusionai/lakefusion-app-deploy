import logging
import os
import shutil
import tempfile
import threading
from datetime import datetime, timezone


class RunTaskFilter(logging.Filter):
    """Filter that adds run_id and task_run_id to log records."""
    
    def __init__(self, run_id, task_run_id):
        super().__init__()
        self.run_id = run_id
        self.task_run_id = task_run_id

    def filter(self, record):
        record.run_id = self.run_id
        record.task_run_id = self.task_run_id
        return True


class SafeStreamHandler(logging.StreamHandler):
    """Stream handler that silently ignores non-seekable stream errors.
    
    Databricks notebooks have non-seekable stdout streams that can cause
    OSError when handlers try to flush. This handler catches and ignores
    those errors.
    """
    
    def flush(self):
        try:
            super().flush()
        except (OSError, ValueError):
            pass

    def emit(self, record):
        try:
            super().emit(record)
        except (OSError, ValueError):
            pass


class DatabricksLogger:
    """Logger that writes to LOCAL disk and copies to UC Volume every 30s.

    Features:
    - Writes to process-specific /tmp directory (no permission conflicts)
    - Auto-syncs to UC Volume every 30 seconds
    - Handles MLflow and other library conflicts
    - Automatic handler repair if corrupted

    Architecture:
    - File handler → /tmp/lakefusion_logs_<user>_<pid>/ (local temp)
    - Background timer → copies to UC Volume every 30s
    - shutdown() → final copy to Volume
    
    The key fix: Each process gets its own temp directory to avoid
    permission conflicts when multiple tasks run concurrently.
    """

    CONFLICTING_LOGGERS = [
        "mlflow",
        "mlflow.tracking",
        "mlflow.utils",
        "mlflow.store",
        "mlflow.sklearn",
        "mlflow.spark",
        "mlflow.models",
        "mlflow.data",
        "mlflow.pyfunc",
        "py4j",
        "py4j.java_gateway",
        "databricks",
        "databricks.sdk",
    ]

    def __init__(
        self,
        logger_name,
        run_id,
        task_name,
        task_run_id,
        pipeline_type,
        job_id,
        catalog_name,
        log_directory=None,
    ):
        # Set default Volume log directory if not provided
        if log_directory is None:
            log_directory = f"/Volumes/{catalog_name}/default/pipeline_logs/"

        # Suppress conflicting third-party loggers
        self._suppress_conflicting_loggers()

        # Create or get logger instance
        self.logger = logging.getLogger(logger_name)
        self.logger.setLevel(logging.DEBUG)
        self.logger.propagate = False  # Don't propagate to root logger

        # Initialize sync attributes (must be set before early return)
        self._sync_interval = 30  # seconds
        self._sync_timer = None
        self._sync_lock = threading.Lock()
        self.log_file_path = None       # Final Volume path
        self._local_log_path = None     # Local temp path
        self._local_log_dir = None      # Local temp directory
        self._formatter = None
        self._run_task_filter = None

        # Prevent duplicate handlers if notebook is re-run
        if self.logger.handlers:
            print(f"Logger {logger_name} already initialized with {len(self.logger.handlers)} handlers")
            return

        print(
            f"Starting logger for {logger_name} "
            f"with job run id {run_id} for task {task_name} "
            f"and task run id {task_run_id}"
        )

        # Generate timestamp and date for log paths
        rundate = datetime.now().strftime("%Y-%m-%d")
        timestamp = int(datetime.now(timezone.utc).timestamp())
        log_filename = f"{task_name}_{timestamp}.log"

        # ══════════════════════════════════════════════════════════════
        # CRITICAL FIX: Create unique temp directory per process
        # This prevents "Permission denied" errors when multiple tasks
        # try to write to the same /tmp/lakefusion_logs directory
        # ══════════════════════════════════════════════════════════════
        
        local_log_dir = self._create_unique_temp_directory(task_name)
        self._local_log_dir = local_log_dir
        self._local_log_path = os.path.join(local_log_dir, log_filename)
        
        print(f"Local temp log: {self._local_log_path}")

        # ══════════════════════════════════════════════════════════════
        # Create Volume destination path
        # ══════════════════════════════════════════════════════════════
        
        try:
            volume_folder = os.path.join(
                log_directory,
                f"pipeline={pipeline_type}",
                f"date={rundate}_job_id={job_id}_run_id={run_id}/",
            )
            os.makedirs(volume_folder, mode=0o777, exist_ok=True)
            self.log_file_path = os.path.join(volume_folder, log_filename)
            print(f"Volume log path: {self.log_file_path}")
            
        except Exception as e:
            print(f"⚠ Warning: Could not create Volume directory: {e}")
            print(f"  Logs will only be available locally at: {self._local_log_path}")
            self.log_file_path = None

        # ══════════════════════════════════════════════════════════════
        # Setup log formatter
        # ══════════════════════════════════════════════════════════════
        
        log_format = (
            "%(asctime)s | %(levelname)s | [%(name)s] | "
            "%(run_id)s | %(task_run_id)s | %(message)s"
        )
        formatter = logging.Formatter(fmt=log_format, datefmt="%Y-%m-%d %H:%M:%S")
        self._formatter = formatter

        # ══════════════════════════════════════════════════════════════
        # Write header to log file
        # ══════════════════════════════════════════════════════════════
        
        header = "TIMESTAMP | LEVEL | LOGGER | JOB_RUN_ID | TASK_RUN_ID | MESSAGE"
        separator = "-" * 100
        
        try:
            with open(self._local_log_path, 'w') as f:
                f.write(f"{header}\n{separator}\n")
        except Exception as e:
            print(f"✗ Failed to write log header: {e}")

        # ══════════════════════════════════════════════════════════════
        # Create and attach file handler (writes to local temp)
        # ══════════════════════════════════════════════════════════════
        
        file_handler = logging.FileHandler(self._local_log_path, mode='a')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.INFO)
        file_handler.addFilter(RunTaskFilter(run_id, task_run_id))
        self.logger.addHandler(file_handler)

        # ══════════════════════════════════════════════════════════════
        # Create and attach stream handler (writes to stdout)
        # ══════════════════════════════════════════════════════════════
        
        stream_handler = SafeStreamHandler()
        stream_handler.setFormatter(formatter)
        stream_handler.setLevel(logging.INFO)
        stream_handler.addFilter(RunTaskFilter(run_id, task_run_id))
        self.logger.addHandler(stream_handler)

        # Store filter for handler repair
        self._run_task_filter = RunTaskFilter(run_id, task_run_id)

        # ══════════════════════════════════════════════════════════════
        # Start background sync timer (if Volume path available)
        # ══════════════════════════════════════════════════════════════
        
        if self.log_file_path:
            self._start_sync_timer()
            print(f"✓ Auto-sync enabled (every {self._sync_interval}s)")
        else:
            print(f"✓ Auto-sync disabled (Volume path not available)")

        print(f"✓ Logger initialization complete\n")

    def _create_unique_temp_directory(self, task_name):
        """Create a unique, writable temp directory for this task.
        
        This is the CRITICAL FIX for permission errors. Each process gets
        its own directory, preventing conflicts when multiple tasks run.
        
        Strategy:
        1. Try user-specific directory: /tmp/lakefusion_logs_<user>_<pid>
        2. Test write access to ensure it's actually writable
        3. If that fails, use Python's mkdtemp (guaranteed writable)
        
        Args:
            task_name: Name of the current task (used in fallback path)
            
        Returns:
            str: Path to the created temp directory
        """
        # Get username (fallback to 'spark' if unavailable)
        try:
            import getpass
            username = getpass.getuser()
        except Exception:
            username = "spark"
        
        # Get current process ID for uniqueness
        pid = os.getpid()
        
        # Method 1: Try predictable user/process-specific directory
        # This creates paths like: /tmp/lakefusion_logs_spark_12345/
        local_log_dir = os.path.join(
            tempfile.gettempdir(),
            f"lakefusion_logs_{username}_{pid}"
        )
        
        try:
            # Create directory with world-writable permissions
            os.makedirs(local_log_dir, mode=0o777, exist_ok=True)
            
            # CRITICAL: Test write access before using
            # This ensures we don't get permission errors later
            test_file = os.path.join(local_log_dir, ".write_test")
            with open(test_file, 'w') as f:
                f.write("test")
            os.remove(test_file)
            
            print(f"✓ Using temp directory: {local_log_dir}")
            return local_log_dir
            
        except (OSError, PermissionError) as e:
            # Method 1 failed - fall back to guaranteed-writable temp
            print(f"⚠ Cannot use {local_log_dir}: {e}")
            
            # Method 2: Use Python's mkdtemp (always works)
            # This creates paths like: /tmp/lakefusion_Embedding_HF_xyz123/
            local_log_dir = tempfile.mkdtemp(prefix=f"lakefusion_{task_name}_")
            print(f"✓ Using fallback temp directory: {local_log_dir}")
            return local_log_dir

    def _start_sync_timer(self):
        """Start the periodic sync timer (runs in background thread)."""
        if self._sync_timer is not None:
            self._sync_timer.cancel()
        
        self._sync_timer = threading.Timer(self._sync_interval, self._auto_sync)
        self._sync_timer.daemon = True  # Don't block program exit
        self._sync_timer.start()

    def _auto_sync(self):
        """Called by timer: copy local log to Volume, then schedule next sync."""
        self._copy_to_volume()
        self._start_sync_timer()  # Schedule next sync

    def _copy_to_volume(self):
        """Copy the local log file to UC Volume (background operation).
        
        This runs in a background thread and swallows errors to avoid
        interrupting the main logging flow. Errors are silently ignored
        because:
        1. Volume might be temporarily unavailable
        2. We don't want to crash the logger due to sync issues
        3. Local logs are still preserved
        """
        if not self.log_file_path:
            return  # Volume path not available
        
        with self._sync_lock:
            try:
                # Flush file handlers before copying
                for handler in self.logger.handlers[:]:
                    if isinstance(handler, logging.FileHandler):
                        handler.flush()
                
                # Copy local file to Volume
                if os.path.exists(self._local_log_path):
                    shutil.copy2(self._local_log_path, self.log_file_path)
                    
            except Exception:
                # Silently ignore sync errors to avoid interrupting logging
                # Local logs are still preserved even if sync fails
                pass

    @classmethod
    def _suppress_conflicting_loggers(cls):
        """Prevent third-party libraries from hijacking Python's logging.
        
        Libraries like MLflow, py4j, and databricks.sdk often reconfigure
        the root logger, which can interfere with our handlers. This method
        suppresses their logging and prevents propagation.
        """
        for name in cls.CONFLICTING_LOGGERS:
            lib_logger = logging.getLogger(name)
            lib_logger.setLevel(logging.WARNING)  # Only show warnings/errors
            lib_logger.propagate = False          # Don't bubble up to root
            # Note: We don't clear handlers here as it might break library internals

    def _ensure_handlers(self):
        """Verify handlers exist and recreate if missing.
        
        MLflow and other libraries sometimes remove handlers during their
        initialization. This method checks for missing handlers and recreates
        them if needed.
        
        Call this method:
        - Before MLflow operations
        - After MLflow operations
        - If you suspect handlers were corrupted
        """
        # Re-suppress conflicting loggers
        self._suppress_conflicting_loggers()

        if not self._formatter or not self._run_task_filter:
            return  # Not fully initialized yet

        # Check for missing handlers
        has_file = any(isinstance(h, logging.FileHandler) for h in self.logger.handlers)
        has_stream = any(isinstance(h, SafeStreamHandler) for h in self.logger.handlers)

        # Recreate file handler if missing
        if not has_file and self._local_log_path:
            try:
                fh = logging.FileHandler(self._local_log_path, mode='a')
                fh.setFormatter(self._formatter)
                fh.setLevel(logging.INFO)
                fh.addFilter(self._run_task_filter)
                self.logger.addHandler(fh)
                print(f"[DatabricksLogger] Repaired file handler → {self._local_log_path}")
            except Exception as e:
                print(f"[DatabricksLogger] Failed to repair file handler: {e}")

        # Recreate stream handler if missing
        if not has_stream:
            try:
                sh = SafeStreamHandler()
                sh.setFormatter(self._formatter)
                sh.setLevel(logging.INFO)
                sh.addFilter(self._run_task_filter)
                self.logger.addHandler(sh)
                print("[DatabricksLogger] Repaired stream handler")
            except Exception as e:
                print(f"[DatabricksLogger] Failed to repair stream handler: {e}")

    def get_logger(self):
        """Return the configured logger instance.
        
        Returns:
            logging.Logger: The configured logger
            
        Example:
            logger = logger_instance.get_logger()
            logger.info("Processing started")
        """
        return self.logger

    def check_health(self):
        """Verify and repair handler state.
        
        Call this method:
        - Before MLflow operations
        - After MLflow operations
        - If you suspect handlers were corrupted
        
        Example:
            logger_instance.check_health()
            # Now safe to use MLflow
            mlflow.log_metric("accuracy", 0.95)
            logger_instance.check_health()
        """
        self._ensure_handlers()

    def shutdown(self):
        """Stop sync timer, perform final copy to Volume, and close handlers.
        
        This should be called at the end of your notebook to ensure:
        1. Background sync timer is stopped
        2. Final logs are copied to Volume
        3. All handlers are properly closed
        
        Example:
            try:
                logger_instance.shutdown()
            except Exception as e:
                print(f"Logger shutdown error: {e}")
        """
        # Stop the sync timer
        if self._sync_timer is not None:
            self._sync_timer.cancel()
            self._sync_timer = None

        # Final copy to Volume
        self._copy_to_volume()

        # Close all handlers
        for handler in self.logger.handlers[:]:
            try:
                handler.flush()
                handler.close()
            except Exception:
                pass
            self.logger.removeHandler(handler)

        print(f"✓ Logger shutdown complete")
        if self.log_file_path:
            print(f"  Final log location: {self.log_file_path}")
        if self._local_log_path:
            print(f"  Local copy: {self._local_log_path}")