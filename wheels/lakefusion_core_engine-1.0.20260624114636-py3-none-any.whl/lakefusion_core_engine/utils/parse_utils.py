"""
Parse Utilities for lakefusion_core_engine.

Provides common parsing and utility functions for dataset mappings, entity attributes,
and configuration files used across the entity processing pipeline.

Migrated from: dbx_pipeline_artifacts/src/utils/parse_utils.py
"""

import re
from typing import Any, Dict, List, Optional, Tuple

from pyspark.sql.types import (
    StringType, IntegerType, LongType, DoubleType, FloatType,
    BooleanType, DateType, TimestampType, DecimalType, DataType,
    StructField, StructType
)

# Import validation functions so they're available in globals() for validation_function_exec
from .validation_functions_constant import (
    validate_email,
    check_dob_suspicious,
    is_string_null_or_empty,
    is_contains_numbers,
)


def get_spark_data_type(dtype_str: str) -> DataType:
    """
    Convert string data type to Spark DataType.

    Supports standard SQL types and legacy mappings for backward compatibility.

    Args:
        dtype_str: String representation of data type (e.g., 'string', 'integer', 'bigint')

    Returns:
        Spark DataType object (defaults to StringType if unknown)
    """
    dtype_map = {
        # Standard SQL types
        'bigint': LongType(),
        'boolean': BooleanType(),
        'char': StringType(),
        'varchar': StringType(),
        'date': DateType(),
        'double precision': DoubleType(),
        'integer': IntegerType(),
        'numeric': FloatType(),
        'real': FloatType(),
        'smallint': IntegerType(),
        'text': StringType(),
        'timestamp': TimestampType(),
        # Legacy mappings (keep for backward compatibility)
        'string': StringType(),
        'int': IntegerType(),
        'long': LongType(),
        'double': DoubleType(),
        'float': FloatType(),
        'decimal': DecimalType(10, 2),
    }
    return dtype_map.get(dtype_str.lower(), StringType())


def create_schema_fields(
    attributes_list: List[str],
    attributes_datatype_dict: Dict[str, str],
    id_key: str = "lakefusion_id",
    include_lakefusion_id: bool = True
) -> List[StructField]:
    """
    Create StructFields for a schema.

    Args:
        attributes_list: List of attribute names (EXACT names from entity)
        attributes_datatype_dict: Dict mapping attribute name to data type
        id_key: The ID key column name (default: 'lakefusion_id')
        include_lakefusion_id: Whether to include lakefusion_id field

    Returns:
        List of StructField objects
    """
    fields = []

    # Add lakefusion_id if requested (only for master table)
    if include_lakefusion_id:
        fields.append(StructField(id_key, StringType(), True))

    # Add all entity attributes with EXACT names
    for attr_name in attributes_list:
        if attr_name == id_key:  # Skip if it's lakefusion_id
            continue

        dtype_str = attributes_datatype_dict.get(attr_name, 'string')
        spark_dtype = get_spark_data_type(dtype_str)
        fields.append(StructField(attr_name, spark_dtype, True))

    return fields


def get_primary_dataset_path(dataset_mappings: List[Dict]) -> str:
    """
    Get the primary dataset path from dataset mappings.

    Args:
        dataset_mappings: List of dataset mapping objects

    Returns:
        Path to the primary dataset, or empty string if not found
    """
    for dataset in dataset_mappings:
        if dataset.get("is_primary"):
            return dataset.get("dataset", {}).get("path", "")
    return ""


def get_dataset_tables(dataset_mappings: List[Dict]) -> Tuple[List[str], Dict[str, Dict]]:
    """
    Get dataset tables and objects from mappings.

    Args:
        dataset_mappings: List of dataset mapping objects

    Returns:
        Tuple of (list of dataset paths, dict mapping path to dataset info)
    """
    dataset_objects = {}
    dataset_paths = []

    for dataset in dataset_mappings:
        dataset_info = dataset.get("dataset", {})
        path = dataset_info.get("path", "")
        dataset_paths.append(path)
        dataset_objects[path] = dataset_info

    return dataset_paths, dataset_objects


def parse_attributes_mapping(dataset_mappings: List[Dict]) -> List[Dict[str, Dict]]:
    """
    Parse attribute mappings from dataset_mappings.

    Creates mapping: {dataset_attribute: entity_attribute}

    Args:
        dataset_mappings: List of dataset mapping objects from entity JSON

    Returns:
        List of dicts: [{table_path: {dataset_attr: entity_attr, ...}}, ...]
    """
    attribute_mappings = []

    for dataset in dataset_mappings:
        attr_map = {}
        for attr in dataset.get("attributes", []):
            dataset_attr = attr.get("dataset_attribute", "")
            entity_attr = attr.get("entity_attribute", "")
            attr_map[dataset_attr] = entity_attr

        dataset_path = dataset.get("dataset", {}).get("path", "")
        attribute_mappings.append({dataset_path: attr_map})

    return attribute_mappings


def parse_attributes_mapping_json(dataset_mappings: List[Dict]) -> List[Dict[str, Dict]]:
    """
    Parse attribute mappings from dataset_mappings with entity_attribute as key.

    Creates mapping: {entity_attribute: dataset_attribute}
    This handles cases where multiple entity attributes map from the same dataset column.

    Args:
        dataset_mappings: List of dataset mapping objects from entity JSON

    Returns:
        List of dicts: [{table_path: {entity_attr: dataset_attr, ...}}, ...]
    """
    attribute_mappings = []

    for dataset in dataset_mappings:
        attr_map = {}

        # Build mapping with entity_attribute as key
        for attr in dataset.get("attributes", []):
            entity_attr = attr.get("entity_attribute", "")
            dataset_attr = attr.get("dataset_attribute", "")
            attr_map[entity_attr] = dataset_attr

        dataset_path = dataset.get("dataset", {}).get("path", "")
        attribute_mappings.append({dataset_path: attr_map})

    return attribute_mappings


def get_default_survivorship_rules(survivorship_groups: List[Dict]) -> List[Dict]:
    """
    Get default survivorship rules from survivorship groups.

    Args:
        survivorship_groups: List of survivorship group objects

    Returns:
        List of rules from the default group, or empty list if none found
    """
    for survivorship_group in survivorship_groups:
        if survivorship_group.get('is_default', False):
            return survivorship_group.get('rules', [])
    return []


def transform_survivorship_rules(
    survivorship_rules: List[Dict],
    dataset_objects: Dict[str, Dict]
) -> List[Dict]:
    """
    Transform survivorship rules by resolving dataset IDs to actual table paths.

    For Source System strategy, the strategyRule stores dataset IDs (integers).
    This function maps those IDs to the actual table paths from dataset_objects,
    which already include the _cleaned suffix when DQ cleaned tables are used.

    Args:
        survivorship_rules: List of survivorship rule dicts (from entity JSON)
        dataset_objects: Dict mapping table path -> dataset info dict (with 'id' key)

    Returns:
        New list of rules with dataset IDs replaced by resolved table paths
    """
    if not survivorship_rules or not dataset_objects:
        return survivorship_rules

    # Build dataset ID to path mapping
    dataset_id_to_path = {}
    for path, dataset_info in dataset_objects.items():
        dataset_id = dataset_info.get('id')
        if dataset_id is not None:
            dataset_id_to_path[dataset_id] = path

    # Transform each rule (create new list to avoid mutating input)
    transformed_rules = []
    for rule in survivorship_rules:
        transformed_rule = rule.copy()
        if (rule.get('strategy') == 'Source System'
                and rule.get('strategyRule')
                and isinstance(rule['strategyRule'], list)):
            transformed_rule['strategyRule'] = [
                dataset_id_to_path.get(dataset_id)
                for dataset_id in rule['strategyRule']
                if dataset_id_to_path.get(dataset_id) is not None
            ]
        transformed_rules.append(transformed_rule)

    return transformed_rules


def get_primary_attr_mapping(
    attributes_mapping_json: List[Dict],
    primary_table: str
) -> Optional[Dict]:
    """
    Get attribute mapping for the primary table.

    Args:
        attributes_mapping_json: List of attribute mapping dicts
        primary_table: Full path to the primary table

    Returns:
        Attribute mapping dict for primary table, or None if not found
    """
    for attr_map in attributes_mapping_json:
        for dataset_path, mapping in attr_map.items():
            if primary_table.startswith(dataset_path):
                return mapping
    return None


def remove_primary_from_attr_mapping(
    attributes_mapping_json: List[Dict],
    primary_table: str
) -> List[Dict]:
    """
    Remove primary table from attribute mappings.

    Args:
        attributes_mapping_json: List of attribute mapping dicts
        primary_table: Full path to the primary table

    Returns:
        Filtered list without the primary table mapping
    """
    new_attr_mapping_json = []
    for attr_map in attributes_mapping_json:
        for dataset_path, mapping in attr_map.items():
            if not primary_table.startswith(dataset_path):
                new_attr_mapping_json.append(attr_map)
    return new_attr_mapping_json


def validation_function_exec(validation_function_list: List[Dict], df: Any) -> Any:
    """
    Execute validation functions on a DataFrame.

    Args:
        validation_function_list: List of validation function definitions
        df: PySpark DataFrame

    Returns:
        DataFrame with validation columns added and original columns dropped
    """
    from pyspark.sql.functions import col, udf
    from pyspark.sql.types import BooleanType

    for rule in validation_function_list:
        # Dynamically define the function
        exec(rule["function_definition"], globals())
        validation_function = globals()[rule["function_name"]]

        # Register the function as a UDF
        validate_udf = udf(validation_function, BooleanType())

        # Apply the UDF to the DataFrame
        df = df.withColumn(
            f"is_valid_{rule['attribute_name']}", validate_udf(col(rule["attribute_name"]))
        )

    df = df.drop(*[i['attribute_name'] for i in validation_function_list])
    return df


def get_version_info() -> Dict:
    """
    Loads product version info from version.json file.

    Searches for version.json by traversing up the directory tree until
    it finds the dbx_pipeline_artifacts folder.

    Returns:
        dict containing version info, or empty dict if file not found.
    """
    import os
    import json
    from pathlib import Path

    # Start from current working directory
    current_path = Path(os.getcwd())

    # Traverse up the directory tree to find dbx_pipeline_artifacts
    for parent in [current_path] + list(current_path.parents):
        # Check if we're in or under dbx_pipeline_artifacts
        if 'dbx_pipeline_artifacts' in parent.parts:
            # Find the dbx_pipeline_artifacts directory
            parts = parent.parts
            dbx_index = None
            for i, part in enumerate(parts):
                if part == 'dbx_pipeline_artifacts':
                    dbx_index = i
                    break

            if dbx_index is not None:
                # Construct path to dbx_pipeline_artifacts
                dbx_path = Path(*parts[:dbx_index + 1])
                version_file = dbx_path / "version.json"

                if version_file.exists():
                    try:
                        with open(version_file) as f:
                            return json.load(f)
                    except json.JSONDecodeError:
                        return dict()

    # If not found, return empty dict
    return dict()


def get_custom_tags() -> Dict:
    """
    Loads custom tags from custom_tags.json as a dictionary.

    Fault tolerant:
      - If file doesn't exist -> {}
      - If file is empty -> {}
      - If JSON invalid -> {}
      - If JSON is not a dict -> {}

    Returns:
        dict of custom tags
    """
    import json
    from pathlib import Path

    TAGS_FILE = Path("../../custom_tags.json")

    if not TAGS_FILE.exists():
        return {}

    try:
        content = TAGS_FILE.read_text().strip()
        if not content:
            return {}

        data = json.loads(content)

        # Ensure it's actually a dict
        return data if isinstance(data, dict) else {}

    except Exception:
        return {}


def get_resource_tags(as_list: bool = False) -> Any:
    """
    Get the resource tags for the Databricks API requests.

    Args:
        as_list: If True, return tags as a list of {"key", "value"}.
                 If False, return as a dictionary. Defaults to False.

    Returns:
        dict | list: Resource tags in the specified format.
    """
    version = get_version_info()
    custom_tags = get_custom_tags()

    # Base tags
    tags_dict = {
        "product": version.get("productName", "LakeFusion"),
        "version": version.get("productVersion", "1.0.0"),
        "partner": version.get("partner", version.get("productName", "LakeFusion")),
        "environment": version.get("environment", "production"),
    }

    # Merge custom tags (custom overrides defaults if conflict)
    if isinstance(custom_tags, dict):
        tags_dict.update(custom_tags)

    if as_list:
        return [{"key": k, "value": v} for k, v in tags_dict.items()]

    return tags_dict


def get_user_agent_header_sql() -> str:
    """
    Get the user agent header for the Databricks SQL API requests.

    This function retrieves the user agent string that includes product and version information.

    Returns:
        User agent string in format "ProductName/Version"
    """
    version = get_version_info()
    product_name = version.get("productName", "LakeFusion")
    product_version = version.get("productVersion", "1.0.0")

    print(f"Setting user agent with product name: {product_name} & product version: {product_version}")

    return f"{product_name}/{product_version}"


def append_schema_tags(spark: Any, catalog: str, schema: str, new_tags: Dict) -> None:
    """
    Append tags to a Unity Catalog schema without overwriting existing ones.

    Args:
        spark: SparkSession
        catalog: The catalog name (e.g., "lakefusion_ai").
        schema: The schema (database) name (e.g., "demo_schema").
        new_tags: Tags to append, e.g. {"env": "staging", "team": "mlops"}.
    """
    # Construct SQL to set all tags
    tags_sql = ", ".join([f"'{k}' = '{v}'" for k, v in new_tags.items()])
    sql_stmt = f"ALTER SCHEMA {catalog}.{schema} SET TAGS ({tags_sql})"

    # Execute the SQL to update tags
    spark.sql(sql_stmt)


def append_table_tags(spark: Any, catalog: str, schema: str, table: str, new_tags: Dict) -> None:
    """
    Append tags to a Unity Catalog table without overwriting existing ones.

    Args:
        spark: SparkSession
        catalog: The catalog name (e.g., "lakefusion_ai").
        schema: The schema (database) name (e.g., "demo_schema").
        table: The table name (e.g., "building_demo").
        new_tags: Tags to append, e.g. {"quality": "gold", "owner": "mlops"}.
    """
    # Construct SQL to set all tags
    tags_sql = ", ".join([f"'{k}' = '{v}'" for k, v in new_tags.items()])
    sql_stmt = f"ALTER TABLE {catalog}.{schema}.{table} SET TAGS ({tags_sql})"

    # Execute the SQL to update tags
    spark.sql(sql_stmt)


def apply_tags_to_uc_resource(
    spark: Any,
    resource_type: str,
    full_name: str,
    tags: Dict
) -> None:
    """
    Apply tags to a Unity Catalog resource.

    Args:
        spark: SparkSession
        resource_type: Type of resource ('catalogs', 'schemas', 'tables', 'volumes', 'functions', 'models')
        full_name: Full name of resource (e.g., 'catalog.schema.table')
        tags: Dictionary of tags to apply
    """
    if not tags:
        return

    from databricks.sdk import WorkspaceClient
    w = WorkspaceClient()

    if resource_type == "catalogs":
        w.catalogs.update(name=full_name, properties=tags)
    elif resource_type == "schemas":
        parts = full_name.split(".")
        append_schema_tags(spark, parts[0], parts[1], tags)
        w.schemas.update(full_name, properties=tags)
    elif resource_type == "tables":
        parts = full_name.split(".")
        append_table_tags(spark, parts[0], parts[1], parts[2], tags)
    elif resource_type == "volumes":
        w.volumes.update(full_name, properties=tags)
    elif resource_type == "functions":
        w.functions.update(full_name, properties=tags)
    elif resource_type == "models":
        from mlflow.tracking import MlflowClient
        client = MlflowClient()
        for key, value in tags.items():
            client.set_registered_model_tag(
                name=full_name,
                key=key,
                value=value
            )
