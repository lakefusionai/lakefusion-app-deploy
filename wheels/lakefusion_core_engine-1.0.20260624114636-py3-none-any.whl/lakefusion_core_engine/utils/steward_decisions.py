"""
Steward Decisions utility for capturing record attribute snapshots
before stewardship operations (merge, unmerge, not-a-match, force merge).

Writes frozen snapshots to {catalog}.silver.{entity}_steward_decisions Delta table
so the Stewardship History page can display both records even after destructive operations.
"""

import uuid
import json


STEWARD_DECISIONS_SCHEMA = """(
    decision_id STRING,
    entity_id STRING,
    action_type STRING,
    master_id STRING,
    match_id STRING,
    reason STRING,
    reason_category STRING,
    master_record_attributes STRING,
    match_record_attributes STRING,
    master_record_source STRING,
    match_record_source STRING,
    steward STRING,
    decided_at TIMESTAMP,
    aml_status STRING
)"""


def _stringify(d: dict) -> dict:
    """Convert all values to strings for JSON serialization."""
    return {k: str(v) if v is not None else None for k, v in d.items()}


def write_steward_decision(
    spark,
    catalog_name: str,
    entity_name: str,
    entity_id: str,
    action_type: str,
    master_id: str,
    match_id: str,
    master_attrs: dict,
    match_attrs: dict,
    master_source: str = "",
    match_source: str = "",
    created_by: str = "",
    logger=None,
) -> str:
    """
    Write a steward decision row with pre-captured attribute snapshots to the Delta table.

    Args:
        spark: SparkSession
        catalog_name: Unity Catalog name
        entity_name: Entity name (lowercase, underscored)
        entity_id: Entity ID
        action_type: MANUAL_MERGE, MANUAL_NOT_A_MATCH, MANUAL_UNMERGE, MASTER_MANUAL_MERGE, etc.
        master_id: Master record lakefusion_id
        match_id: Match record ID (surrogate_key or lakefusion_id)
        master_attrs: Pre-captured master record attributes dict
        match_attrs: Pre-captured match record attributes dict
        master_source: Source path of master record
        match_source: Source path of match record
        created_by: Steward username
        logger: Optional logger

    Returns:
        decision_id (str) or None if failed
    """
    decisions_table = f"{catalog_name}.silver.{entity_name}_steward_decisions"
    decision_id = str(uuid.uuid4()).replace("-", "")

    try:
        # Create table if not exists
        spark.sql(f"CREATE TABLE IF NOT EXISTS {decisions_table} {STEWARD_DECISIONS_SCHEMA} USING DELTA")

        # Serialize attributes to JSON and escape for SQL (double single quotes)
        def _sql_str(val):
            if val is None:
                return 'NULL'
            return "'" + str(val).replace("'", "''") + "'"

        master_attrs_json = json.dumps(_stringify(master_attrs)) if master_attrs else None
        match_attrs_json = json.dumps(_stringify(match_attrs)) if match_attrs else None

        # Insert — all string fields go through _sql_str to prevent SQL injection
        spark.sql(f"""
            INSERT INTO {decisions_table} VALUES (
                {_sql_str(decision_id)},
                {_sql_str(entity_id)},
                {_sql_str(action_type)},
                {_sql_str(master_id)},
                {_sql_str(match_id)},
                NULL,
                NULL,
                {_sql_str(master_attrs_json)},
                {_sql_str(match_attrs_json)},
                {_sql_str(master_source) if master_source else 'NULL'},
                {_sql_str(match_source) if match_source else 'NULL'},
                {_sql_str(created_by)},
                current_timestamp(),
                {_sql_str('PENDING')}
            )
        """)

        if logger:
            logger.info(f"Steward decision written: {decision_id} ({action_type})")

        return decision_id

    except Exception as e:
        if logger:
            logger.warning(f"Could not write steward decision: {e}")
        return None
