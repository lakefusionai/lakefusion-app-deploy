"""
Cast helpers for survivorship engine output.

The survivorship UDF returns ``MapType(StringType(), StringType())`` — every
value arrives as a string. Before writing the merged record back to the master
table we cast each attribute back to its declared Spark type. This module
centralises that cast logic so all notebooks and executors agree on the rules.

Why this exists
---------------
The naive ``string -> double -> long`` cast (used previously to handle decimal
strings like ``"28.0"``) silently truncates integers above 2^53 because IEEE-754
doubles only have a 52-bit mantissa. For ``bigint`` IDs in the 10^16 range the
gap between consecutive representable doubles is 8, so e.g.
``"60000000002028803"`` collapses to ``60000000002028800``. ``decimal(38,0)``
preserves the full precision and still accepts ``"28.0"`` (truncates the
fractional part).
"""

from typing import Any, Mapping, Optional

from pyspark.sql import Column
from pyspark.sql.functions import col, from_json


_INTEGER_TYPES = {"int", "integer", "long", "bigint", "smallint", "tinyint"}
_FLOAT_TYPES = {"float", "double", "decimal"}
_TIMESTAMP_TYPES = {"timestamp", "date", "datetime"}
_BOOLEAN_TYPES = {"boolean", "bool"}

# Scalar Spark DDL names used inside STRUCT field declarations.
_SCALAR_DDL = {
    "STRING": "STRING",
    "INT": "INT",
    "INTEGER": "INT",
    "BIGINT": "BIGINT",
    "LONG": "BIGINT",
    "SMALLINT": "SMALLINT",
    "TINYINT": "TINYINT",
    "DOUBLE": "DOUBLE",
    "FLOAT": "FLOAT",
    "DECIMAL": "DECIMAL(38,18)",
    "BOOLEAN": "BOOLEAN",
    "DATE": "DATE",
    "TIMESTAMP": "TIMESTAMP",
}


def _scalar_ddl(t: str) -> str:
    return _SCALAR_DDL.get((t or "STRING").strip().upper(), "STRING")


def _struct_ddl(attr_record: Mapping[str, Any]) -> str:
    sd = attr_record.get("struct_definition") or {}
    fields = sd.get("fields") or []
    parts = []
    for f in fields:
        if not isinstance(f, Mapping):
            continue
        parts.append(f"`{f.get('name')}`:{_scalar_ddl(f.get('data_type'))}")
    return f"STRUCT<{','.join(parts)}>"


def complex_ddl(attr_record: Mapping[str, Any]) -> Optional[str]:
    """Return a Spark DDL string for a STRUCT / ARRAY / ARRAY<STRUCT> attr,
    suitable for ``from_json(value, ddl)``. Returns None for scalar attrs."""
    if not attr_record:
        return None
    is_array = bool(attr_record.get("is_array", False))
    atype = (attr_record.get("type") or "").strip().upper()
    if atype == "STRUCT":
        inner = _struct_ddl(attr_record)
        return f"ARRAY<{inner}>" if is_array else inner
    if is_array:
        return f"ARRAY<{_scalar_ddl(atype)}>"
    return None


def cast_merged_value(
    value_col: Column,
    target_type: str,
    attr_record: Optional[Mapping[str, Any]] = None,
) -> Column:
    """Cast a stringified ``merged_record`` value to its target Spark type.

    When ``attr_record`` describes a STRUCT / ARRAY / ARRAY<STRUCT> attr,
    the value (a JSON string emitted by the survivorship engine) is parsed
    via ``from_json`` with the matching DDL. Scalar paths unchanged.
    """
    ddl = complex_ddl(attr_record) if attr_record else None
    if ddl:
        return from_json(value_col, ddl)

    t = (target_type or "string").lower()

    if t in _TIMESTAMP_TYPES:
        return value_col.cast("timestamp")
    if t in _INTEGER_TYPES:
        # decimal(38,0) preserves bigint precision (double truncates above
        # 2^53) while still accepting decimal strings like "28.0".
        return value_col.cast("decimal(38,0)").cast("long")
    if t in _FLOAT_TYPES:
        return value_col.cast("double")
    if t in _BOOLEAN_TYPES:
        return value_col.cast("boolean")
    return value_col


def merged_record_column(
    attr: str,
    target_type: str,
    attr_record: Optional[Mapping[str, Any]] = None,
) -> Column:
    """Convenience wrapper: produce a typed, aliased column for ``attr``."""
    return cast_merged_value(
        col(f"merged_record.{attr}"), target_type, attr_record
    ).alias(attr)
