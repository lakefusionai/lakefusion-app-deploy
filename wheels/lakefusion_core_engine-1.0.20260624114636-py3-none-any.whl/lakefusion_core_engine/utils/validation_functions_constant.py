"""
Validation Functions for Entity Data Quality.

Common validation functions for checking data quality in entity records.
These can be used with validation_function_exec() in parse_utils.py.
"""

import re
from datetime import datetime
from typing import Optional


# Regular Expressions
EMAIL_REGEX = r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'


def validate_email(input_str: Optional[str]) -> bool:
    """
    Validate Email Format.

    Args:
        input_str: Email string to validate

    Returns:
        True if valid email format, False otherwise
    """
    if input_str is None:
        return False
    return bool(re.match(EMAIL_REGEX, str(input_str)))


def check_dob_suspicious(input_str, min_age: int = 0, max_age: int = 130) -> bool:
    """
    Check if date of birth (DOB) is suspicious.

    Args:
        input_str: Date of birth (datetime object or parseable string)
        min_age: Minimum acceptable age (default 0)
        max_age: Maximum acceptable age (default 130)

    Returns:
        True if DOB is suspicious, False otherwise
    """
    try:
        # Convert the DOB string to a datetime object
        dob_date = input_str
        today = datetime.today()

        # Check if DOB is in the future
        if dob_date > today:
            return True  # DOB is in the future (suspicious)

        # Calculate the person's age
        age = (today - dob_date).days // 365  # Approximate age in years

        # Check if the age is out of the acceptable range
        if age < min_age or age > max_age:
            return True  # Suspicious if the age is too low or too high

        return False  # DOB is not suspicious

    except (ValueError, TypeError):
        # Handle invalid date formats
        return True  # Consider invalid format as suspicious


def is_string_null_or_empty(input_str: Optional[str]) -> bool:
    """
    Check if the value is None or an empty string.

    Args:
        input_str: String to check

    Returns:
        True if None or empty string, False otherwise
    """
    return input_str is None or str(input_str).strip() == ""


def is_contains_numbers(input_str: Optional[str]) -> bool:
    """
    Check if the string contains any numbers.

    Args:
        input_str: String to check

    Returns:
        True if contains numbers, False otherwise
    """
    if input_str is None:
        return False
    return any(char.isdigit() for char in str(input_str))
