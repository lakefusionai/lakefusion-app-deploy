from .base import WriteOperations, WriteMode
from .delta_ops import DeltaWriteOps
from .lakebase_ops import LakebaseWriteOps
from .table_name_resolver import resolve_table_name, resolve_staging_table, to_pg_qualified


def create_write_ops(mode: str, spark, params: dict = None) -> WriteOperations:
    """
    Factory to create the appropriate WriteOperations implementation.

    Args:
        mode: "delta" or "lakebase"
        spark: SparkSession
        params: Additional params (lakebase connection config, etc.)

    Returns:
        WriteOperations instance
    """
    if mode == WriteMode.LAKEBASE:
        return LakebaseWriteOps(spark, params or {})
    return DeltaWriteOps(spark)