from abc import ABC, abstractmethod
from enum import Enum
from typing import Dict, List, Optional


class WriteMode(str, Enum):
    DELTA = "delta"
    LAKEBASE = "lakebase"


class WriteOperations(ABC):
    """
    Abstract base for storage write operations.

    Both DeltaWriteOps and LakebaseWriteOps implement this interface.
    Notebooks call these methods with a Spark DataFrame — the implementation
    handles the rest:

      - DeltaWriteOps:    Spark/Delta saveAsTable + DeltaTable.merge()
      - LakebaseWriteOps: Spark JDBC + psycopg INSERT ... ON CONFLICT, with
                          tables made Lakehouse-Sync-ready (REPLICA IDENTITY
                          FULL) so a one-time UI-enabled sync replicates them
                          to UC as `lb_<table>_history` SCD Type 2 tables.
    """

    @abstractmethod
    def create_table(
        self,
        df,
        table_name: str,
        enable_cdf: bool = False,
        primary_key: Optional[List[str]] = None,
        synced_table_id: Optional[str] = None,
    ) -> None:
        """
        Create table from DataFrame schema if it does not already exist.
        Implementations are create-if-not-exists (no drop/overwrite) — use
        overwrite() / append() / merge() to change data in an existing table.

        Args:
            df: Source DataFrame whose schema becomes the table schema.
            table_name: Target table (UC 3-part name).
            enable_cdf: Make the table CDC-ready
                        (Delta CDF / Postgres REPLICA IDENTITY FULL).
            primary_key: List of columns to mark as PRIMARY KEY. Required for
                         LakebaseWriteOps (the synced table needs a PK);
                         optional but recommended for DeltaWriteOps.
            synced_table_id: Lakebase only — target synced-table id in UC.
                         Defaults to "{table_name}_synced". Ignored by
                         DeltaWriteOps (accepted for signature parity).
        """
        ...

    @abstractmethod
    def overwrite(self, df, table_name: str) -> None:
        """Replace all data in the table with the DataFrame contents."""
        ...

    @abstractmethod
    def append(self, df, table_name: str) -> None:
        """Append DataFrame rows to the table."""
        ...

    @abstractmethod
    def merge(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        when_matched: Optional[Dict] = None,
        when_not_matched: str = "insert",
    ) -> None:
        """
        Upsert: insert new rows, update existing rows matched by merge_keys.

        Args:
            df: Source DataFrame
            table_name: Target table (UC path for Delta, resolved for Lakebase)
            merge_keys: Columns to match on (e.g. ["lakefusion_id"])
            when_matched: Dict of {col: expr} for UPDATE SET. None = update all.
            when_not_matched: "insert" (default) or "skip"
        """
        ...

    @abstractmethod
    def merge_with_delete(
        self,
        df,
        table_name: str,
        merge_keys: List[str],
        delete_condition: str,
    ) -> None:
        """Merge with conditional delete for rows not in source."""
        ...

    @abstractmethod
    def sql_merge(
        self,
        sql_string: str,
        table_name: str,
        source_df=None,
        merge_keys: Optional[List[str]] = None,
    ) -> None:
        """
        Execute a raw MERGE INTO statement.

        For Delta: runs sql_string directly via spark.sql().
        For Lakebase: writes source_df to staging table, translates to
                      INSERT ... ON CONFLICT using merge_keys.
        """
        ...

    @abstractmethod
    def update_by_keys(
        self,
        df,
        table_name: str,
        key_columns: List[str],
        set_expressions: Dict[str, str],
        extra_predicate: Optional[str] = None,
    ) -> None:
        """
        UPDATE rows in target whose key_columns match rows in df.

        Args:
            df: DataFrame holding the keys to match. Only key_columns are read.
            table_name: Target table (UC 3-part name).
            key_columns: Columns that form the match key.
            set_expressions: {column: sql_expression}. Expressions are injected
                             verbatim, so use forms valid in both Spark SQL and
                             PostgreSQL: 'CURRENT_TIMESTAMP', 'TRUE'/'FALSE',
                             numeric/quoted literals.
            extra_predicate: Optional extra WHERE clause AND-ed with the key
                             match. Reference target columns unqualified
                             (no aliases) so it works in both engines.
        """
        ...

    @abstractmethod
    def delete_by_keys(
        self,
        df,
        table_name: str,
        key_columns: List[str],
    ) -> None:
        """DELETE rows from target whose key_columns match rows in df."""
        ...

    @abstractmethod
    def table_exists(self, table_name: str) -> bool:
        """Check if the target table exists."""
        ...

    @abstractmethod
    def optimize(self, table_name: str) -> None:
        """
        Optimize table storage.
          - Delta: OPTIMIZE
          - Lakebase: ANALYZE (refreshes planner statistics)
        """
        ...

    @abstractmethod
    def enable_cdf(self, table_name: str) -> None:
        """
        Make the table CDC-ready.

          - Delta: ALTER TABLE ... SET TBLPROPERTIES (delta.enableChangeDataFeed = true)
          - Lakebase: ALTER TABLE ... REPLICA IDENTITY FULL — the Postgres-side
                      prerequisite for Lakehouse Sync (Postgres -> UC). Without
                      this, the sync silently skips the table because Postgres
                      would not write full before/after row state to the WAL.
        """
        ...

    def begin_transaction(self) -> None:
        """Begin a write transaction. No-op for Delta."""
        pass

    def commit_transaction(self) -> None:
        """Commit current transaction. No-op for Delta."""
        pass

    def rollback_transaction(self) -> None:
        """Rollback current transaction. No-op for Delta."""
        pass