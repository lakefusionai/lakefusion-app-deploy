"""
Resolves Unity Catalog 3-level table names to Lakebase (PostgreSQL) 2-level names.

One schema per entity. The UC table name is preserved verbatim as the PG
table name so that Lakehouse Sync emits a UC path symmetric to the original:

  UC write target:   catalog.gold.acme_master_prod
  PG table:          "acme"."acme_master_prod"
  Synced UC read:    <sync_catalog>.gold.lb_acme_master_prod_history
                                         ↑
                                  PG table name → lb_<pg_table>_history
"""


def resolve_table_name(uc_table_name: str, entity: str) -> tuple:
    """
    Convert a Unity Catalog table path to (pg_schema, pg_table).

    The UC table portion is kept whole — no entity-prefix stripping —
    so the PG table name matches what Lakehouse Sync expects to source
    from when emitting `lb_<pg_table>_history` in UC.

    Args:
        uc_table_name: Full UC path, e.g. "lakefusion_ai_staging.gold.acme_master_prod"
        entity: Entity name, e.g. "acme". Used as the PG schema.

    Returns:
        Tuple of (pg_schema=entity, pg_table=full UC table name).

    Example:
        resolve_table_name("lakefusion_dev.gold.acme_master_prod", "acme")
        -> ("acme", "acme_master_prod")
    """
    parts = uc_table_name.split(".")
    if len(parts) != 3:
        raise ValueError(
            f"Expected 3-part UC table name (catalog.schema.table), got: {uc_table_name}"
        )

    return (entity, parts[2])


def resolve_staging_table(uc_table_name: str, entity: str) -> tuple:
    """
    Get staging table name for merge operations.

    Args:
        uc_table_name: Full UC path
        entity: Entity name

    Returns:
        Tuple of (schema_name, staging_table_name)
    """
    schema, table = resolve_table_name(uc_table_name, entity)
    return (schema, f"_stg_{table}")


def to_pg_qualified(schema: str, table: str) -> str:
    """Build a fully qualified PostgreSQL table reference."""
    return f'"{schema}"."{table}"'