# config_defaults.py
# CONFIG_DEFAULTS = {
#     "catalog_name": "lakefusion_ai",
#     "dbx_cloud": "azure",
#     "enable_read_only": "False",
#     "lakefusion_spn": "",
#     "notebook_path":"/Workspace/Lakefusion_Notebooks/match-maven-notebooks",
#     "processable_records": "2000",
#     "whitelisted_readonly_routes": '''
#     {
#         "POST": [
#             "/api/middle-layer/dataset/",
#             "/api/auth/generate-auth-token",
#             "/api/auth/refresh-auth-token"
#         ],
#         "PUT": [""]
#     }
#     ''',
#     "default_prompt": '''You are an expert in classifying two entities as matching or not matching.
# You will be provided with a query entity and a list of possible entities.
# You need to find the closest matching entity with a similarity score to indicate how similar they are.
# Take into account:
# 1. The attributes are not mutually exclusive.
# 2. The attributes are not exhaustive.
# 3. The attributes are not consistent.
# 4. The attributes are not complete.
# 5. The attributes can have typos.
# 6. The entity type that is being considered here is - {entity}.
# 7. Do not consider scores in the search results / query entities. Generate scores by yourself.
# 8. If additional instructions are provided below, apply it alongside these core guidelines.'''
# }
from enum import Enum

class ConfigType(str, Enum):
    BOOLEAN = "boolean"
    STRING = "string"
    INT = "int"
    FLOAT = "float"
    JSON = "json"
    KEY = "key"

class ConfigCategory(str, Enum):
    GENERAL = "GENERAL"
    LFTAGS = "LFTAGS"
    DNB = "DNB"
    SPN = "SPN"


CONFIG_DEFAULTS = [
    {
        "config_key": "catalog_name",
        "config_value": "lakefusion_ai",
        "config_value_type": ConfigType.STRING,
        "config_label": "Catalog Name",
        "config_desc": "Defines the unique name of the master data catalog within the LakeFusion platform. This catalog serves as the central repository for organizing and managing all entity datasets.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "cron_warehouse_id",
        "config_value": "",
        "config_value_type": ConfigType.STRING,
        "config_label": "Cron Warehouse ID",
        "config_desc": "Specifies the unique identifier for the connected data warehouse from Databricks where scheduled jobs and synchronization tasks are executed.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "dbx_cloud",
        "config_value": "aws",
        "config_value_type": ConfigType.STRING,
        "config_label": "DBX Cloud",
        "config_desc": "Indicates the configured Databricks cloud environment (e.g., AWS, Azure, GCP) where the LakeFusion workloads and data operations are deployed.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "default_prompt",
        "config_value": '''You are an expert in classifying two records as matching or not matching.
You will be provided with a golden record and a list of potential matches.
You need to find the closest matching record with a similarity score to indicate how similar they are.
Take into account:
1. The attributes are not mutually exclusive.
2. The attributes are not exhaustive.
3. The attributes are not consistent.
4. The attributes are not complete.
5. The attributes can have typos.
6. The entity type being considered is: {entity}.
7. Do not consider scores in the search results. Generate your own similarity scores.
8. If additional instructions are present, consider them too.{additional_instructions_clause}
Follow these rules for input and output:
**Input:**
- Golden Record Format:
  The golden record will be provided as a single string in the following format:
  {attributes}
  Each field is separated by a vertical bar (|).
  Note: Some columns can have aggregated values separated by (bullet)
- List of Potential Matches:
  A string containing comma-separated entries in this EXACT format:
  [match_record, lakefusion_id, score], [match_record, lakefusion_id, score], ...
  Example: [John | Smith | john@email.com | 555-1234, abc123def456, 0.85], [Jane | Doe | jane@email.com | 555-5678, xyz789ghi012, 0.75], ...
  WHERE:
  - match_record: Pipe-separated fields (BEFORE first comma inside brackets)
  - lakefusion_id: 32-character hexadecimal string (BETWEEN first and second comma)
  - score: Decimal number (AFTER second comma, before closing bracket)
**CRITICAL EXTRACTION RULES:**
- For EACH entry in the list, you MUST extract the lakefusion_id
- The lakefusion_id is ALWAYS between the FIRST comma and SECOND comma inside each bracket
- If you cannot find a valid lakefusion_id, DO NOT return that entry
- lakefusion_id format: 32 lowercase hexadecimal characters (a-f, 0-9)
- Example valid lakefusion_id: d728dead49f8c4bbbf0be3dcdc65d215
**Output:**
Only return a plain JSON list of objects:
1. No extra text, no headers, no introductory phrases, and no comments.
2. Do not use code blocks, markdown, or any other formatting.
3. The JSON list MUST contain EXACTLY {max_potential_matches} objects (one for each potential match in the input list).
4. Each object must have these keys:
    a. id: String (the match_record - text BEFORE first comma in brackets).
    b. score: Float (YOUR similarity score from 0.0 to 1.0 - NOT the vector score).
    c. reason: String (brief explanation for YOUR score, comparing to the golden record).
    d. lakefusion_id: String (COPY the 32-char hex string between 1st and 2nd comma EXACTLY).
5. VERIFY each lakefusion_id is exactly 32 characters of a-f and 0-9.
6. Return EXACTLY {max_potential_matches} results, no more, no less.
7. Ensure scores are in descending order (highest similarity first).''',
        "config_value_type": ConfigType.STRING,
        "config_label": "Default Prompt",
        "config_desc": "Provides the base instruction for entity matching and similarity scoring. This prompt guides the AI model in evaluating and classifying entities based on predefined attributes and rules.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "enable_read_only",
        "config_value": "False",
        "config_value_type": ConfigType.BOOLEAN,
        "config_label": "Enable Read Only",
        "config_desc": "When enabled, restricts modifications to configuration settings and data records. Useful for audit or view-only environments.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 0,
    },
    {
        "config_key": "lakefusion_spn",
        "config_value": "",
        "config_value_type": ConfigType.STRING,
        "config_label": "Service Principal Client ID",
        "config_desc": "The Application (Client) ID of the Service Principal used for secure authentication between LakeFusion and Databricks, including job execution (run_as) and workflow OAuth flows such as the Vector Search network-optimized route.",
        "config_category": ConfigCategory.SPN,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "notebook_path",
        "config_value": "/Workspace/Lakefusion_Notebooks/match-maven-notebooks-universe",
        "config_value_type": ConfigType.STRING,
        "config_label": "Notebook Path",
        "config_desc": "Specifies the absolute path in Databricks workspace where MDM-related notebooks and processing workflows are stored.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "processable_records",
        "config_value": "2000",
        "config_value_type": ConfigType.INT,
        "config_label": "Processable Records",
        "config_desc": "Indicates the maximum number of records the system can process in a single batch for match maven tasks.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "sync_tables",
        "config_value": "datasets,entity,entityattributes,entitydatasetmapping,model_experiments,profiling_tasks,quality_tasks,survivorshiprule,validationfunctions,validationuserdefinedfunctions",
        "config_value_type": ConfigType.STRING,
        "config_label": "Sync Tables",
        "config_desc": "Lists of tables that are configured for synchronization between LakeFusion and the associated Databricks workspace.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "whitelisted_readonly_routes",
        "config_value": '''{ "POST": ["/api/middle-layer/dataset/","/api/auth/generate-auth-token","/api/auth/refresh-auth-token"],     "PUT": [""] }''',
        "config_value_type": ConfigType.STRING,
        "config_label": "Whitelisted Readonly Routes",
        "config_desc": "List of API routes that are exempt from read-only restrictions, allowing specific operations to be performed even when read-only mode is enabled.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 0,
    },
    {
        "config_key": "resource_tagging",
        "config_value": '''{}''',
        "config_value_type": ConfigType.JSON,
        "config_label": "Resource Tagging",
        "config_desc": "Allows users to assign key–value pairs to system resources for better organization, filtering, and access control within the Databricks environment.",
        "config_category": ConfigCategory.LFTAGS,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "dnb_integration_enabled",
        "config_value": "False",
        "config_value_type": ConfigType.BOOLEAN,
        "config_label": "Enable Dun & Bradstreet (DnB) Integration",
        "config_desc": "Activate or deactivate the Dun & Bradstreet (DnB) integration. When DnB integration is enabled, the DnB configuration panel within the Entities module becomes available. Users can then manage and customize Dun & Bradstreet enrichment settings for entity records.",
        "config_category": ConfigCategory.DNB,
        "extended_values": '{"dnb_api_key_length": ""}',
        "config_show": 1,
    },
    {
        "config_key": "lakefusion_spn_secret",
        "config_value": "",
        "config_value_type": ConfigType.KEY,
        "config_label": "Service Principal Client Secret",
        "config_desc": "The client secret for the Service Principal used for all workflow OAuth flows, including the Vector Search network-optimized route.",
        "config_category": ConfigCategory.SPN,
        "extended_values": '{"spn_client_secret_length": ""}',
        "config_show": 1,
    },
    {
        "config_key": "pipeline_base_version",
        "config_value": "4.0.0",
        "config_value_type": ConfigType.STRING,
        "config_label": "Pipeline Base Version",
        "config_desc": "Base version of MDM pipeline",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 0,
    },
]

