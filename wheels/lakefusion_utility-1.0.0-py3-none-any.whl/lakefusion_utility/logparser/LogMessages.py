from enum import Enum


class LogMessages(Enum):
    # General
    INTERNAL_SERVER_ERROR_OCCURRED = "An internal server error occurred. Exception message - {exception}"
    INTERNAL_SERVER_ERROR_GENERIC = "An internal server error occurred. "

    # Token Validation Messages
    TOKEN_VALIDATION_SESSION_TOKEN = 'Validating session token.'
    TOKEN_VALIDATION_USER_PROFILE = 'Session token valid. Validating user profile.'
    TOKEN_VALIDATION_INVALID_USER_PROFILE = 'Invalid user profile.'
    TOKEN_VALIDATION_INVOKE_APIROUTE = 'User profile valid. Invoking API route.'
    TOKEN_VALIDATION_SESSION_TOKEN_EXCEPTION = 'Exception {exception} occured while validating session token'
    TOKEN_VALIDATION_APIEXECUTION_SUCCESSFUL = 'API executed successfully. Returning response to the caller.'
    TOKEN_VALIDATION_USERSERVICE_VALIDATEUSER = 'Invoking User get graph API for the user - {user_oid}'
    TOKEN_VALIDATION_USERSERVICE_VALIDATEUSER_RESPONSE_MGRAPH = 'Response from Microsoft Graph API for user get - {resp}'
    TOKEN_VALIDATION_USERSERVICE_VALIDATEUSER_EXCEPTION_MGRAPH = 'Microsoft Graph raised an exception while getting user details - {exception}'