# lakefusion_utility/models/__init__.py
import pkgutil
import importlib

# List of modules you want to exclude from Alembic
EXCLUDE_MODULES = {"data_quality"}

for _, module_name, _ in pkgutil.iter_modules(__path__):
    if module_name in EXCLUDE_MODULES:
        continue
    importlib.import_module(f"{__name__}.{module_name}")