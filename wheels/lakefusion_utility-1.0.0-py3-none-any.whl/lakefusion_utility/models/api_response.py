from typing import TypeVar, Generic, Optional, Union, List
from pydantic import BaseModel
from pydantic.generics import GenericModel

T = TypeVar("T")

class ApiResponse(GenericModel, Generic[T]):
    status: str
    message: str
    data: Optional[T] = None
