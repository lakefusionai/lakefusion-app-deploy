import datetime

from sqlalchemy import Column, Integer, String, Text, DateTime, Float
from sqlalchemy.ext.hybrid import hybrid_property

from lakefusion_utility.utils.app_db import Base


class AuditLog(Base):
    """
    Model for storing API request audit logs.

    Captures all API requests with masked sensitive data for security compliance.
    """
    __tablename__ = 'audit_logs'

    id = Column('audit_logs_id', Integer, primary_key=True, autoincrement=True)
    username = Column(String(255), nullable=False, index=True)
    created_date = Column(DateTime, default=datetime.datetime.utcnow, nullable=False, index=True)
    api_path = Column(Text, nullable=False)
    request_method = Column(String(10), nullable=True)  # GET, POST, PUT, DELETE, etc.
    request_payload = Column(Text, nullable=True)
    response_payload = Column(Text, nullable=True)  # Masked response body (for errors)
    response_status = Column(Integer, nullable=True, index=True)
    client_ip = Column(String(45), nullable=True)  # IPv6 can be up to 45 chars
    user_agent = Column(String(512), nullable=True)
    execution_time_ms = Column(Float, nullable=True)  # Request duration in milliseconds

    @hybrid_property
    def getCreatedDate(self):
        return self.created_date.strftime('%Y-%m-%d')

    def __init__(
        self,
        username: str = None,
        api_path: str = None,
        request_method: str = None,
        request_payload: str = None,
        response_payload: str = None,
        response_status: int = None,
        client_ip: str = None,
        user_agent: str = None,
        execution_time_ms: float = None
    ):
        self.username = username
        self.api_path = api_path
        self.request_method = request_method
        self.request_payload = request_payload
        self.response_payload = response_payload
        self.response_status = response_status
        self.client_ip = client_ip
        self.user_agent = user_agent
        self.execution_time_ms = execution_time_ms

    def as_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'date': str(self.created_date),
            'api_path': self.api_path,
            'request_method': self.request_method,
            'request_payload': self.request_payload,
            'response_payload': self.response_payload,
            'response_status': self.response_status,
            'client_ip': self.client_ip,
            'user_agent': self.user_agent,
            'execution_time_ms': self.execution_time_ms
        }
