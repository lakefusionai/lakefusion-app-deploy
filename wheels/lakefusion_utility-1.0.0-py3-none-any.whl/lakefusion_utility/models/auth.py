from pydantic import BaseModel

class AuthUrlResponse(BaseModel):
    auth_url: str

class AuthTokenResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    refresh_token: str
    scope: str
    username: str