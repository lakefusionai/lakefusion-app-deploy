from typing import Optional
from pydantic import BaseModel

class AuthTokenRequest(BaseModel):
    code: str
    state: str
    redirect_uri: Optional[str] = None

class AuthTokenRequestM2M(BaseModel):
    client_id: str
    client_secret: str

class RefreshTokenRequest(BaseModel):
    refresh_token: str
