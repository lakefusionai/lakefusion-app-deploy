from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text
from sqlalchemy.dialects.mysql import MEDIUMTEXT
from lakefusion_utility.utils.app_db import Base
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional
from sqlalchemy.orm import relationship




class BasePrompt(Base):
    __tablename__ = 'base_prompts'

    id = Column(Integer, primary_key=True, autoincrement=True)
    prompt_name = Column(String(255), nullable=False)
    version = Column(Integer,default=1, nullable=False)
    content = Column(Text().with_variant(MEDIUMTEXT(charset='utf8mb4', collation='utf8mb4_unicode_ci'), 'mysql'), nullable=False)
    description = Column(String(500),nullable=True)
    tags = Column(String(255),nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(String(255), nullable=False)
    updated_by = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    model_experiments = relationship(
        "Model_Experiment",
        back_populates="base_prompt",
    )

    def __init__(
        self,
        prompt_name,
        version,
        content,
        created_by,
        updated_by,
        description=None,
        tags=None,
        created_at=None,
        is_active=True
    ):
        self.prompt_name = prompt_name
        self.version = version
        self.content = content
        self.description = description
        self.tags = tags
        self.created_by = created_by
        self.updated_by = updated_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.is_active = is_active

    def __repr__(self):
        return (
            f"<BasePrompt(id={self.id}, prompt_name={self.prompt_name}, "
            f"version={self.version}, created_by={self.created_by}, updated_by={self.updated_by}, "
            f"is_active={self.is_active})>"
        )
    
    def to_dict(self):
        return {
            "id": self.id,
            "prompt_name": self.prompt_name,
            "version": self.version,
            "content": self.content,
            "description": self.description,
            "tags": self.tags,
            "created_at": str(self.created_at) if self.created_at else None,
            "updated_at": str(self.updated_at) if self.updated_at else None,
            "created_by": self.created_by,
            "updated_by": self.updated_by,
            "is_active": self.is_active,
        }
    


# Request model for creating a prompt
class BasePromptCreate(BaseModel):
    prompt_name: str = Field(..., example="Summarization Base Prompt")
    version: int = Field(..., example="1")
    content: str = Field(..., example="You are an assistant that summarizes text...")
    description: Optional[str] = Field(None, example="Used for text summarization models")
    tags: Optional[str] = Field(None, example="summarization, base, text")
    is_active: Optional[bool] = True
    created_by: Optional[str] = Field(None, example="user@example.com") 

# Response model
from typing import List
class ModelExperimentSummary(BaseModel):
    id: int
    entity_id: int
    modelname: str
    created_by: str
    class Config:
        from_attributes = True 

class BasePromptResponse(BaseModel):
    id: int
    prompt_name: str
    version: int
    content: str
    description: Optional[str]
    tags: Optional[str]
    created_at: datetime
    updated_at: datetime
    created_by: str
    updated_by: str
    is_active: bool
    total_model_experiments: Optional[int] = None
    model_experiments: Optional[List[ModelExperimentSummary]] = None

    class Config:
        from_attributes = True

