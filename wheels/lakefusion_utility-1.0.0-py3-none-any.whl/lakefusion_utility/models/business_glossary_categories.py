from sqlalchemy import Column, Integer, String, DateTime
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
from pydantic import BaseModel
from typing import Optional

class BusinessGlossaryCategories(Base):
    __tablename__ = 'business_glossary_categories'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), unique=True ,nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    description = Column(String(255))
    created_by = Column(String(255), nullable=False)
    table_name = Column(String(255), nullable=False)
    
    def __init__(self, name, description, created_by, created_at=None, table_name=None):
        self.name = name
        self.description = description
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.table_name = table_name
    
    def __repr__(self):
        return f"<BusinessGlossaryCategories(id={self.id}, name={self.name}, created_at={self.created_at}, description={self.description}, created_by={self.created_by}, table_name={self.table_name})>"

# Pydantic model for request and response
class BusinessGlossaryCategoriesCreate(BaseModel):
    name: str
    table_name: str
    description: Optional[str] = None
    created_by: Optional[str] = ''

class BusinessGlossaryCategoriesResponse(BaseModel):
    id: int
    name: str
    table_count: int
