from sqlalchemy import Column, Integer, String, JSON, ForeignKey, DateTime, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime

from lakefusion_utility.utils.app_db import Base

class DiagramBase(BaseModel):
    name: str
    description: Optional[str] = None
    dataset_id: int
    flow_data: Dict[str, Any]  # ReactFlow nodes and edges
    transformations: List[Dict[str, Any]]  # Transformation configurations

class DiagramCreate(DiagramBase):
    pass

class DiagramUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    flow_data: Optional[Dict[str, Any]] = None
    transformations: Optional[List[Dict[str, Any]]] = None
    is_active: Optional[bool] = None

class DiagramResponse(DiagramBase):
    id: int
    created_by: str
    created_at: datetime
    updated_at: Optional[datetime]
    is_active: bool
    job_info: Optional[Dict[str, Any]]

    class Config:
        orm_mode = True  # For compatibility with older versions
        from_attributes = True  # For newer versions

class ExecutionLogBase(BaseModel):
    diagram_id: int
    status: str
    execution_details: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None

class ExecutionLogCreate(ExecutionLogBase):
    pass

class ExecutionLogResponse(ExecutionLogBase):
    id: int
    start_time: datetime
    end_time: Optional[datetime]
    created_by: str

    class Config:
        orm_mode = True  # For compatibility with older versions
        from_attributes = True  # For newer versions

class QualityDiagram(Base):
    __tablename__ = "quality_diagrams"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(String(255))
    dataset_id = Column(Integer, ForeignKey("datasets.id"), nullable=False)
    flow_data = Column(JSON, nullable=False)  # Stores ReactFlow nodes and edges
    transformations = Column(JSON, nullable=False)  # Stores transformation configurations
    created_by = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, onupdate=func.now())
    is_active = Column(Boolean, default=True, nullable=False)
    job_info = Column(JSON)  # Stores Databricks job information

    # Relationship with Dataset
    dataset = relationship(
        "Dataset",
        back_populates="quality_diagrams",
        foreign_keys=[dataset_id]
    )

    # Relationship with execution logs
    execution_logs = relationship(
        "DiagramExecutionLog",
        back_populates="diagram",
        cascade="all, delete-orphan"
    )

    def __init__(self, name, dataset_id, flow_data, transformations, created_by, description=None, is_active=True):
        self.name = name
        self.dataset_id = dataset_id
        self.flow_data = flow_data
        self.transformations = transformations
        self.created_by = created_by
        self.description = description
        self.is_active = is_active

class DiagramExecutionLog(Base):
    __tablename__ = "diagram_execution_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    diagram_id = Column(Integer, ForeignKey("quality_diagrams.id"), nullable=False)
    status = Column(String(50), nullable=False)  # 'running', 'completed', 'failed'
    start_time = Column(DateTime, default=datetime.utcnow, nullable=False)
    end_time = Column(DateTime)
    execution_details = Column(JSON)  # Stores detailed execution information
    error_message = Column(String(500))
    created_by = Column(String(255), nullable=False)

    # Relationship with QualityDiagram
    diagram = relationship(
        "QualityDiagram",
        back_populates="execution_logs",
        foreign_keys=[diagram_id]
    )

    def __init__(self, diagram_id, status, created_by, execution_details=None, error_message=None):
        self.diagram_id = diagram_id
        self.status = status
        self.created_by = created_by
        self.execution_details = execution_details
        self.error_message = error_message