from lakefusion_utility.models.match_maven import Model_Experiment
from lakefusion_utility.models.entity import Entity
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, JSON
from datetime import datetime
from lakefusion_utility.utils.app_db import Base
from pydantic import BaseModel
from typing import Optional, Any, Dict, Union, List
from sqlalchemy.orm import relationship

class Model_Databricks_Job(Base):
    __tablename__ = 'match_maven_job'
    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(Integer,ForeignKey('entity.id'), nullable=False)
    modelid = Column(Integer, ForeignKey('model_experiments.id'), nullable=False)
    job_id= Column(String(255), nullable=False)
    job_run_id= Column(String(255), nullable=False)
    job_repair_run_id=Column(String(255), nullable=True)
    experiment_status= Column(String(255), nullable=True)
    job_run_status=Column(JSON, nullable=False)
    existing_cluster_id=Column(String(255), nullable=True)
    processed_record=Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=True)    
    created_by = Column(String(255), nullable=False)
    model = relationship("Model_Experiment")
    entity = relationship("Entity")
    historical_jobs = Column(JSON, nullable=True, default=None)

    def __init__(self,entity_id,modelid,job_id,job_run_id,job_repair_run_id,experiment_status,job_run_status,existing_cluster_id,processed_record,created_by,created_at=None, historical_jobs=None):
        self.entity_id=entity_id
        self.modelid=modelid
        self.job_id=job_id
        self.job_run_id=job_run_id
        self.job_repair_run_id=job_repair_run_id
        self.experiment_status=experiment_status
        self.job_run_status=job_run_status
        self.existing_cluster_id=existing_cluster_id
        self.processed_record=processed_record
        self.created_by = created_by
        self.created_at=created_at
        self.historical_jobs = historical_jobs
    def __repr__(self):
        return f"<Model_Databricks_Job(entity_id={self.entity_id}, modelid={self.modelid},job_run_id={self.job_run_id},job_repair_run_id={self.job_repair_run_id},experiment_status={self.experiment_status},created_by={self.created_by}>"

class Model_Databricks_Job_Create(BaseModel):
    entity_id:int
    modelid: int
    created_by: Optional[str] = ''

class TaskStatus(BaseModel):
    task_name: str
    task_status: str
    task_result_state: Optional[str]  # Use Optional to allow for None values

# Define the model for the overall job status
class JobStatusResponse(BaseModel):
    job_run_status: str
    tasks: List[TaskStatus] 
    class Config:
        orm_mode=True



class Model_Databricks_Entity_Search_Job(Base):
    __tablename__ = 'entity_search_databricks_job'

    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(Integer, ForeignKey('entity.id'), nullable=False)
    master_id = Column(String(255), nullable=False)
    profile_id= Column(String(255), nullable=False)
    operation_type= Column(String(255), nullable=False)
    job_run_id=Column(String(255), nullable=False)
    status= Column(String(255), nullable=True)
    job_run_status=Column(JSON, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=True)    
    created_by = Column(String(255), nullable=False)
    entity = relationship("Entity")

    def __init__(self,entity_id,master_id,profile_id,operation_type,job_run_id,status,job_run_status,created_by,created_at=None):
        self.entity_id=entity_id
        self.master_id=master_id
        self.profile_id=profile_id
        self.operation_type=operation_type
        self.job_run_id=job_run_id
        self.status=status
        self.job_run_status=job_run_status
        self.created_by = created_by
        self.created_at=created_at
    def __repr__(self):
        return f"<Model_Databricks_Entity_Search_Job(id={self.id}, entity_id={self.entity_id},profile_id={self.profile_id},operation_type={self.operation_type},job_run_id={self.job_run_id},status={self.status},created_by={self.created_by}>"


class Model_Databricks_Entity_Search_Job_Create(BaseModel):
    entity_id: int
    profile_id:str
    operation_type: str
    created_by: Optional[str] = ''