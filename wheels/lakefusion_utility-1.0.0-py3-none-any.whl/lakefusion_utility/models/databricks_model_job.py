# from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, JSON
# from datetime import datetime
# from lakefusion_utility.utils.app_db import Base
# from pydantic import BaseModel
# from typing import Optional, Any, Dict, Union, List
# from sqlalchemy.orm import relationship
# from app.models.match_maven import Model_Experiment,Entity

# class Model_Databricks_Job(Base):
#     __tablename__ = 'match_maven_job'
#     id = Column(Integer, primary_key=True, autoincrement=True)
#     entity_id = Column(Integer,ForeignKey('entity.id'), nullable=False)
#     modelid = Column(Integer, ForeignKey('model_experiments.id'), nullable=False)
#     job_id= Column(String(255), nullable=False)
#     job_run_id= Column(String(255), nullable=False)
#     job_repair_run_id=Column(String(255), nullable=True)
#     experiment_status= Column(String(255), nullable=True)
#     job_run_status=Column(JSON, nullable=False)
#     existing_cluster_id=Column(String(255), nullable=True)
#     processed_record=Column(Integer, nullable=True)
#     historical_jobs=Column(JSON, nullable=True, default=None)
#     created_at = Column(DateTime, default=datetime.utcnow, nullable=True)    
#     created_by = Column(String(255), nullable=False)
#     model = relationship("Model_Experiment")
#     entity = relationship("Entity")

#     def __init__(self,entity_id,modelid,job_id,job_run_id,job_repair_run_id,experiment_status,job_run_status,existing_cluster_id,processed_record,created_by,created_at=None):
#         self.entity_id=entity_id
#         self.modelid=modelid
#         self.job_id=job_id
#         self.job_run_id=job_run_id
#         self.job_repair_run_id=job_repair_run_id
#         self.experiment_status=experiment_status
#         self.job_run_status=job_run_status
#         self.existing_cluster_id=existing_cluster_id
#         self.processed_record=processed_record
#         self.created_by = created_by
#         self.created_at=created_at
#     def __repr__(self):
#         return f"<Model_Databricks_Job(entity_id={self.entity_id}, modelid={self.modelid},job_run_id={self.job_run_id},job_repair_run_id={self.job_repair_run_id},experiment_status={self.experiment_status},created_by={self.created_by}>"

# class Model_Databricks_Job_Create(BaseModel):
#     entity_id:int
#     modelid: int
#     created_by: Optional[str] = ''

# class TaskStatus(BaseModel):
#     task_name: str
#     task_status: str
#     task_result_state: Optional[str]  # Use Optional to allow for None values

# # Define the model for the overall job status
# class JobStatusResponse(BaseModel):
#     job_run_status: str
#     tasks: List[TaskStatus] 
#     class Config:
#         orm_mode=True

