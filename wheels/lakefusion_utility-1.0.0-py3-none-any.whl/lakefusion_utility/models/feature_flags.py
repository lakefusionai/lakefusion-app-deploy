# models/feature_flag.py
from sqlalchemy import Column, Integer, String, DateTime, Enum, Text
from datetime import datetime
from lakefusion_utility.utils.database import Base
import enum

class FeatureFlagStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"        # Currently in use
    INACTIVE = "INACTIVE"    # Disabled, not serving traffic
    DEPRECATED = "DEPRECATED" # Should be removed soon
    DELETED = "DELETED"      # Soft deleted

class FeatureFlag(Base):
    __tablename__ = "feature_flags"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), unique=True, index=True, nullable=False)
    status = Column(Enum(FeatureFlagStatus), default=FeatureFlagStatus.INACTIVE, nullable=False)

    description = Column(Text, nullable=True)
    owner_team = Column(String(100), nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    expires_at = Column(DateTime, nullable=True)

    def __repr__(self):
        return f"<FeatureFlag(name={self.name}, status={self.status})>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "status": self.status.value if self.status else None,
            "description": self.description,
            "owner_team": self.owner_team,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
        }
