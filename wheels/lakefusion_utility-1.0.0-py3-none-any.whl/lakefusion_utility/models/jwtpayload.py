class JWTPayload:
    preferred_username: str
    roles: list
    oid: str
    iss: str
    okta_app_id: str

    def __init__(self, preferred_username: str, roles: list, oid: str, iss: str, okta_app_id: str):
        self.preferred_username = preferred_username
        self.roles = roles
        self.oid = oid
        self.iss = iss,
        self.okta_app_id = okta_app_id