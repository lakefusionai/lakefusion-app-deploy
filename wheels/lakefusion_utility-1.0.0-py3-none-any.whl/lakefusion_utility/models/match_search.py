from pydantic import BaseModel, Field
from typing import Dict, Any, Optional, List
from datetime import datetime


class MatchSearchRequestBody(BaseModel):
    """Request body for match and search endpoints"""
    attributes: Dict[str, Any] = Field(
        ...,
        description="Dictionary of entity attributes to match/search"
    )


class GoldenRecordMatch(BaseModel):
    """Golden record information for match response"""
    lakefusion_id: str = Field(..., description="Unique identifier for the golden record")
    golden_record_attributes: Dict[str, Any] = Field(
        ...,
        description="Attributes of the matched golden record"
    )


class MatchResponse(BaseModel):
    """Response for match endpoint"""
    entity_type: str = Field(..., description="Name of the entity type")
    match_status: str = Field(
        ...,
        description="Match status: ExactMatch, PotentialMatch, or NoMatch"
    )
    score: Optional[float] = Field(None, description="Similarity score from LLM")
    reason: Optional[str] = Field(None, description="Explanation from LLM for why this is or isn't a match")
    matched_golden_record: Optional[GoldenRecordMatch] = Field(
        None,
        description="Details of the matched golden record if match found"
    )


class SearchResultItem(BaseModel):
    """Single result item for search response"""
    lakefusion_id: str = Field(..., description="Unique identifier for the golden record")
    score: float = Field(..., description="Vector similarity score")
    golden_record_attributes: Dict[str, Any] = Field(
        ...,
        description="Attributes of the golden record"
    )


class SearchResponse(BaseModel):
    """Response for search endpoint"""
    entity_type: str = Field(..., description="Name of the entity type")
    results: List[SearchResultItem] = Field(
        ...,
        description="List of similar golden records ranked by score"
    )


class ErrorResponse(BaseModel):
    """Error response model"""
    error_type: str = Field(..., description="Type of error")
    message: str = Field(..., description="Error message")
    detail: Optional[Dict[str, Any]] = Field(None, description="Additional error details")