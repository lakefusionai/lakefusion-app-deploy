import datetime
from sqlalchemy import Column, String, DateTime
from sqlalchemy.dialects.mysql import CHAR as MYSQL_CHAR
import uuid
from lakefusion_utility.utils.app_db import Base

class OIDCRequest(Base):
    __tablename__ = 'oidc_requests'

    id = Column(String(36).with_variant(MYSQL_CHAR(36), 'mysql'), primary_key=True, default=lambda: str(uuid.uuid4()))
    code_verifier = Column(String(128), nullable=False)
    code_challenge = Column(String(128), nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    def __init__(self, code_verifier: str, code_challenge: str):
        self.code_verifier = code_verifier
        self.code_challenge = code_challenge

    def __repr__(self):
        return (f"<OIDCRequest(id={self.id}, code_verifier={self.code_verifier}, code_challenge={self.code_challenge}, created_at={self.created_at})>")

    def as_dict(self):
        return {
            'id': str(self.id),
            'code_verifier': self.code_verifier,
            'code_challenge': self.code_challenge,
            'created_at': str(self.created_at)
        }