from sqlalchemy import Column, Integer, String, DateTime, JSON
from sqlalchemy.orm import relationship
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
from typing import Optional, Dict, Any, List
from pydantic import BaseModel

class QualityAsset(Base):
    __tablename__ = 'quality_assets'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(String(500))
    asset_type = Column(String(50), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    created_by = Column(String(255), nullable=False)
    
    configuration = Column(JSON)

class AssetBase(BaseModel):
    name: str
    description: Optional[str] = None
    asset_type: str

class AssetCreate(AssetBase):
    configuration: Dict[str, Any]

class AssetUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    configuration: Optional[Dict[str, Any]] = None

class ReferenceTableConfig(BaseModel):
    table_path: str

class AssetResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    asset_type: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    created_by: str
    configuration: Dict[str, Any]
    
    class Config:
        from_attributes = True