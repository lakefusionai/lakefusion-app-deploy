from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, JSON, Text, CheckConstraint, Enum as SQLEnum, BigInteger
from sqlalchemy.orm import relationship
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
import os
from enum import Enum
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field

class TaskType(str, Enum):
    NOTEBOOK = "NOTEBOOK"
    DIAGRAM = "DIAGRAM"

class TaskStatus(str, Enum):
    DRAFT = "DRAFT"
    CONFIGURED = "CONFIGURED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"

class QualityTask(Base):
    __tablename__ = 'quality_tasks'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(String(255))
    task_type = Column(SQLEnum(TaskType), nullable=False)
    status = Column(SQLEnum(TaskStatus), default=TaskStatus.DRAFT, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    created_by = Column(String(255), nullable=False)
    
    # Scheduling fields
    quartz_cron_expression = Column(String(255))
    timezone_id = Column(String(255))
    
    # Task specific fields
    notebook_path = Column(Text)
    flow_data = Column(JSON)
    transformations = Column(JSON)
    
    # Configuration and results
    config_parameters = Column(JSON)
    databricks_job_id = Column(BigInteger)  # Store Databricks job ID separately
    job_info = Column(JSON)  # Store full job configuration
    
    # Foreign keys to either Dataset or Entity, one can be null
    dataset_id = Column(Integer, ForeignKey('datasets.id'), nullable=True)
    entity_id = Column(Integer, ForeignKey('entity.id'), nullable=True)
    
    # Relationships
    dataset = relationship("Dataset")
    entity = relationship("Entity")

    @property
    def job_url(self):
        try:
            if self.databricks_job_id:
                base_url = os.environ.get('DATABRICKS_HOST', 'https://databricks.com')
                return f"{base_url}/jobs/{self.databricks_job_id}"
            return None
        except (TypeError, AttributeError):
            return None
        
    def as_dict(self):
        """
        Convert QualityTask instance to dictionary for JSON serialization.
        Converts datetime fields to ISO strings and includes job URL.
        """
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "task_type": self.task_type.name if self.task_type else None,
            "status": self.status.name if self.status else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "created_by": self.created_by,
            "quartz_cron_expression": self.quartz_cron_expression,
            "timezone_id": self.timezone_id,
            "notebook_path": self.notebook_path,
            "flow_data": self.flow_data,
            "transformations": self.transformations,
            "config_parameters": self.config_parameters,
            "databricks_job_id": self.databricks_job_id,
            "job_info": self.job_info,
            "dataset_id": self.dataset_id,
            "entity_id": self.entity_id,
            "job_url": self.job_url
        }

# Pydantic Models for API
class TaskBase(BaseModel):
    name: str
    description: Optional[str] = None
    dataset_id: Optional[int] = None
    entity_id: Optional[int] = None
    quartz_cron_expression: Optional[str] = None
    timezone_id: Optional[str] = None

class TaskCreate(TaskBase):
    task_type: TaskType

class NotebookConfigUpdate(BaseModel):
    notebook_path: str
    config_parameters: Optional[Dict[str, Any]] = None

class DiagramConfigUpdate(BaseModel):
    flow_data: Dict[str, Any]
    transformations: List[Dict[str, Any]]
    config_parameters: Optional[Dict[str, Any]] = None

class ScheduleUpdate(BaseModel):
    quartz_cron_expression: str
    timezone_id: str

class TaskStatusUpdate(BaseModel):
    status: TaskStatus
        
class DatasetInfo(BaseModel):
    id: int
    name: str
    path: str
    description: Optional[str] = None
    color_code: Optional[str] = None
    created_by: str
    is_active: bool
    quality_task_enabled: bool

    class Config:
        from_attributes = True

class TaskResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    task_type: TaskType
    status: TaskStatus
    created_at: datetime
    updated_at: Optional[datetime]
    created_by: str
    dataset_id: Optional[int]
    entity_id: Optional[int]
    notebook_path: Optional[str]
    flow_data: Optional[Dict[str, Any]]
    transformations: Optional[List[Dict[str, Any]]]
    config_parameters: Optional[Dict[str, Any]]
    databricks_job_id: Optional[int]
    job_info: Optional[Dict[str, Any]]
    quartz_cron_expression: Optional[str]
    timezone_id: Optional[str]
    job_url: Optional[str]
    dataset: Optional[DatasetInfo] = None

    class Config:
        from_attributes = True