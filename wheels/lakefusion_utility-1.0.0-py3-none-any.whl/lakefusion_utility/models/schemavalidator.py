from lakefusion_utility.models.httpresponse import HttpResponse


class SchemaValidator:
    is_valid_schema: bool
    http_response: HttpResponse

    def __init__(self):
        super(self).__init__()

    def __init__(self, is_valid_schema, http_response):
        self.is_valid_schema = is_valid_schema
        self.http_response = http_response