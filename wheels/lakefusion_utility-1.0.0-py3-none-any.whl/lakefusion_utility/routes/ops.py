from fastapi import APIRouter, HTTPException, Depends
from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from app.utils.app_db import token_required_wrapper

ops_router = APIRouter(prefix="/ops", tags=["ops"])

@ops_router.post("/clear-db-config-cache")
def clear_db_config_cache(check: dict = Depends(token_required_wrapper)):
    """
    Clears DB Config cache for all backend services.
    Requires valid token.
    """
    try:
        DBConfigPropertiesService.clear_cache()
        FeatureFlagService.clear_cache()
        return {"message": "DB caches cleared successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to clear cache: {str(e)}")
