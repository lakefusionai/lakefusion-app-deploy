from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from lakefusion_utility.models.dataset import DatasetResponse

class ProfilingTaskBase(BaseModel):
    # Base schema for profiling task creation
    name: str
    description: Optional[str] = None
    dataset_id: Optional[int] = None
    entity_id: Optional[int] = None
    refresh_type: Optional[str] = None  # e.g., 'onSchedule', 'manually'

class ProfilingTaskCreate(ProfilingTaskBase):
    # Schema for creating a monitor with optional fields
    quartz_cron_expression: Optional[str] = "0 0 0 * * ?"  # Default to daily
    timezone_id: Optional[str] = "UTC"  # Default to UTC
    warehouse_id: Optional[str] = None

class CreateMonitorRequest(ProfilingTaskBase):
    # Schema for creating a monitor with optional fields
    quartz_cron_expression: Optional[str] = "0 0 0 * * ?"  # Default to daily
    timezone_id: Optional[str] = "UTC"  # Default to UTC
    notifications: Optional[List[str]] = None  # List of email notifications

class ProfilingTaskRefreshInfo(BaseModel):
    refresh_id:int
    status: str  # e.g., 'SUCCESS', 'FAILED', 'IN_PROGRESS'
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    message: Optional[str] = None
    
    class Config:
        orm_mode = True


class ProfilingTaskResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    created_at: datetime
    created_by: str
    dataset_id: Optional[int] = None
    entity_id: Optional[int] = None
    refresh_type: Optional[str] = None  # e.g., 'onSchedule', 'manually'
    monitor_info: Optional[dict] = None
    dashboard_url: Optional[str] = None
    dataset: DatasetResponse
    refresh_info: Optional[ProfilingTaskRefreshInfo] = None  # Additional field for refresh info
    class Config:
        orm_mode = True