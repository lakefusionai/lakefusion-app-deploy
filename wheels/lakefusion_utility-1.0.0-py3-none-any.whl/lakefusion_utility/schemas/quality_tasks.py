from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from lakefusion_utility.models.dataset import DatasetResponse

class QualityTaskBase(BaseModel):
    # Base schema for quality task creation
    name: str
    description: Optional[str] = None
    dataset_id: Optional[int] = None
    entity_id: Optional[int] = None
    notebook_path: str

class QualityTaskCreate(QualityTaskBase):
    # Schema for creating a quality task with optional fields
    quartz_cron_expression: Optional[str] = "0 0 0 * * ?"  # Default to daily
    timezone_id: Optional[str] = "UTC"  # Default to UTC

class QualityTaskUpdate(QualityTaskBase):
    # Schema for creating a quality task with optional fields
    quartz_cron_expression: Optional[str] = "0 0 0 * * ?"  # Default to daily
    timezone_id: Optional[str] = "UTC"  # Default to UTC

class QualityTaskResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    created_at: datetime
    created_by: str
    dataset_id: Optional[int] = None
    entity_id: Optional[int] = None
    notebook_path: str
    job_info: Optional[dict] = None
    job_url: Optional[str] = None
    dataset: DatasetResponse
    quartz_cron_expression: Optional[str] = None
    
    class Config:
        orm_mode = True
