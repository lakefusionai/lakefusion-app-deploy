import traceback
from typing import Optional, List
from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from sqlalchemy import func
from lakefusion_utility.models.base_prompt import BasePrompt
from lakefusion_utility.models.httpresponse import HttpResponse
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.references_checker_utility import is_value_referenced_elsewhere
from lakefusion_utility.models.match_maven import Model_Experiment
from lakefusion_utility.models.base_prompt import BasePromptResponse, ModelExperimentSummary

# Set up logging
app_logger = get_logger(__name__)


class BasePromptService:
    def __init__(self, db: Session):
        """Initializes the BasePromptService with a database session."""
        self.db = db

    # ----------------------------------------------------------------------
    # CREATE BasePrompt
    # ----------------------------------------------------------------------
    def create_base_prompt(self, prompt_create):
        try:
           app_logger.info(
               f"Starting base prompt creation with name: {getattr(prompt_create, 'prompt_name', 'N/A')}"
           )

           with self.db.begin_nested():
               prompt_data = prompt_create.dict()
               prompt_data['updated_by'] = prompt_data.get('created_by', '')

               # ✅ Required fields (no version check needed)
               required_fields = ["prompt_name", "content", "created_by"]
               for field in required_fields:
                   field_value = prompt_data.get(field)
                   if not field_value or not str(field_value).strip():
                       raise HTTPException(
                           status_code=status.HTTP_400_BAD_REQUEST,
                           detail={
                               "status": "error",
                               "message": f"Missing required field: {field}",
                               "data": None,
                           },
                       )

               # Normalize inputs
               prompt_data["prompt_name"] = prompt_data["prompt_name"].strip()
               prompt_data["version"] = 1  # ✅ hardcoded version

               # ✅ Check for duplicate prompt name (ignore version)
               existing_prompt = (
                   self.db.query(BasePrompt)
                   .filter(BasePrompt.prompt_name == prompt_data["prompt_name"])
                   .first()
               )

               if existing_prompt:
                   app_logger.warning(
                       f"Duplicate prompt found for name '{prompt_data['prompt_name']}'"
                   )
                   raise HTTPException(
                       status_code=status.HTTP_409_CONFLICT,
                       detail={
                           "status": "error",
                           "message": f"Prompt '{prompt_data['prompt_name']}' already exists",
                           "data": {
                               "existing_prompt_id": existing_prompt.id,
                               "existing_prompt_name": existing_prompt.prompt_name,
                           },
                       },
                   )

               # ✅ Create new BasePrompt
               new_prompt = BasePrompt(**prompt_data)
               self.db.add(new_prompt)
               self.db.flush()

               if not new_prompt.id:
                   raise HTTPException(
                       status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                       detail={
                           "status": "error",
                           "message": "Failed to generate prompt ID",
                           "data": None,
                       },
                   )

           db_commit_auto_rollback(db=self.db)
           self.db.refresh(new_prompt)

           app_logger.info(
               f"Successfully created BasePrompt (ID={new_prompt.id}, Name={new_prompt.prompt_name})"
           )

           return HttpResponse(
               status="success",
               message=f"BasePrompt '{new_prompt.prompt_name}' created successfully",
               data=new_prompt,
           )

        except HTTPException as he:
           app_logger.warning(f"HTTP error during prompt creation: {he.detail}")
           raise he
        except Exception as e:
           message = traceback.format_exc()
           app_logger.exception(f"Failed to create BasePrompt: {message}")
           raise HTTPException(
               status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
               detail={
                   "status": "error",
                   "message": f"Failed to create BasePrompt: {str(e)}",
                   "data": None,
               },
           )


    # ----------------------------------------------------------------------
    # READ BasePrompts
    # ----------------------------------------------------------------------

    def read_base_prompts(
        self,
        is_active: Optional[bool] = True,
        sort_by: str = "created_at",
        sort_order: str = "desc",
        limit: Optional[int] = None,
        offset: int = 0,
    ) -> List[BasePrompt]:
        """Retrieve base prompts with total model experiment count and top 15 experiment summaries."""
        try:
            # --- Validate sort fields ---
            if sort_order.lower() not in ["asc", "desc"]:
                raise HTTPException(
                    status_code=400,
                    detail="sort_order must be either 'asc' or 'desc'",
                )

            if not hasattr(BasePrompt, sort_by):
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid sort field: {sort_by}",
                )

            # --- Base Prompt Query ---
            query = self.db.query(BasePrompt)
            if is_active is not None:
                query = query.filter(BasePrompt.is_active == is_active)

            sort_field = getattr(BasePrompt, sort_by)
            query = query.order_by(
                sort_field.desc()
                if sort_order.lower() == "desc"
                else sort_field.asc()
            )

            if offset > 0:
                query = query.offset(offset)
            if limit is not None and limit > 0:
                query = query.limit(limit)

            prompts = query.all()
            if not prompts:
                return []

            prompt_ids = [p.id for p in prompts]

            # --- Get total count of model experiments per base prompt ---
            experiment_counts = (
                self.db.query(
                    Model_Experiment.base_prompt_id,
                    func.count(Model_Experiment.id).label("total"),
                )
                .filter(Model_Experiment.base_prompt_id.in_(prompt_ids))
                .group_by(Model_Experiment.base_prompt_id)
                .all()
            )
            count_map = {c.base_prompt_id: c.total for c in experiment_counts}

            # --- Fetch top 15 model experiments (id, entity_id, modelname, created_by) ---
            top_experiments = (
                self.db.query(
                    Model_Experiment.base_prompt_id,
                    Model_Experiment.id,
                    Model_Experiment.entity_id,
                    Model_Experiment.modelname,
                    Model_Experiment.created_by,
                )
                .filter(Model_Experiment.base_prompt_id.in_(prompt_ids))
                .order_by(Model_Experiment.created_at.desc())
                .all()
            )

            # Group top 15 per prompt manually
            experiment_map = {}
            for exp in top_experiments:
                prompt_id = exp.base_prompt_id
                if prompt_id not in experiment_map:
                    experiment_map[prompt_id] = []
                if len(experiment_map[prompt_id]) < 15:
                    experiment_map[prompt_id].append(
                        {
                            "id": exp.id,
                            "entity_id": exp.entity_id,
                            "model_name": exp.modelname,
                            "created_by": exp.created_by,
                        }
                    )

            # --- Attach data to BasePrompt objects ---
            for p in prompts:
                p.total_model_experiments = count_map.get(p.id, 0)
                p.top_model_experiments = experiment_map.get(p.id, [])

            app_logger.info(
                f"Retrieved {len(prompts)} base prompts with experiment summaries."
            )
            return prompts

        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Unable to fetch base prompts. Reason - {message}")
            raise HTTPException(
                status_code=500, detail=f"Failed to fetch base prompts: {str(e)}"
            )
        
    # ----------------------------------------------------------------------
    # DELETE BasePrompt
    # ----------------------------------------------------------------------
    def delete_base_prompt(self, prompt_id: int):
        """Deletes a base prompt by ID with strict service-level reference validation."""
    
        try:
            if not isinstance(prompt_id, int) or prompt_id <= 0:
                raise HTTPException(
                    status_code=400,
                    detail="Invalid prompt ID. Must be a positive integer.",
                )
    
            # Fetch the prompt
            db_prompt = (
                self.db.query(BasePrompt).filter(BasePrompt.id == prompt_id).first()
            )
    
            if db_prompt is None:
                raise HTTPException(
                    status_code=404,
                    detail=f"BasePrompt with ID {prompt_id} not found",
                )
    
            # ✔ SERVICE-LEVEL PROTECTION (business rule)
            # Check if referenced in model_experiments
            is_used = (
                self.db.query(Model_Experiment)
                .filter(Model_Experiment.base_prompt_id == prompt_id)
                .first()
            )
    
            if is_used:
                raise HTTPException(
                    status_code=409,
                    detail=(
                        f"BasePrompt '{db_prompt.prompt_name}' cannot be deleted "
                        f"because it is used in Model_Experiment ID {is_used.id}."
                    ),
                )
    
            # Proceed to delete
            self.db.delete(db_prompt)
            db_commit_auto_rollback(self.db)
    
            return f"BasePrompt '{db_prompt.prompt_name}' deleted successfully"
    
        except HTTPException:
            raise
        except Exception as e:
            app_logger.exception(f"Unexpected error while deleting BasePrompt {prompt_id}")
            raise HTTPException(
                status_code=500,
                detail=f"Unexpected error occurred: {str(e)}",
            )

    # ----------------------------------------------------------------------
    # GET by ID
    # ----------------------------------------------------------------------
    def get_base_prompt_by_id(self, prompt_id: int) -> BasePromptResponse:
        """Fetch a BasePrompt by ID with total count and top 15 related ModelExperiments."""
        try:
            # ✅ Fetch the BasePrompt
            prompt = (
                self.db.query(BasePrompt)
                .filter(BasePrompt.id == prompt_id)
                .first()
            )
    
            if not prompt:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"BasePrompt with ID {prompt_id} not found"
                )
    
            # ✅ Get total count of related Model Experiments
            total_count = (
                self.db.query(Model_Experiment)
                .filter(Model_Experiment.base_prompt_id == prompt_id)
                .count()
            )
    
            # ✅ Fetch top 15 experiments (id, entity_id, modelname, created_by)
            top_experiments = (
                self.db.query(
                    Model_Experiment.id,
                    Model_Experiment.entity_id,
                    Model_Experiment.modelname,
                    Model_Experiment.created_by,
                )
                .filter(Model_Experiment.base_prompt_id == prompt_id)
                .order_by(Model_Experiment.created_at.desc())
                .limit(15)
                .all()
            )
    
            # ✅ Construct response
            response = BasePromptResponse(
                **prompt.__dict__,
                total_model_experiments=total_count,
                model_experiments=[
                    ModelExperimentSummary(
                        id=exp.id,
                        entity_id=exp.entity_id,
                        modelname=exp.modelname,
                        created_by=exp.created_by
                    )
                    for exp in top_experiments
                ]
            )
    
            return response
    
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(
                f"Unable to fetch BasePrompt with ID {prompt_id}. Reason - {message}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to fetch BasePrompt: {str(e)}"
            )

    
    # ----------------------------------------------------------------------
    # TOGGLE ACTIVE
    # ----------------------------------------------------------------------
    def toggle_base_prompt_active(self, prompt_id: int):
        """
        Toggles the active status of a BasePrompt.
        If the BasePrompt is used in any model_experiments row, DO NOT update.
        """
        try:
            # Fetch the prompt
            db_prompt = (
                self.db.query(BasePrompt)
                .filter(BasePrompt.id == prompt_id)
                .first()
            )
    
            if db_prompt is None:
                raise HTTPException(
                    status_code=404,
                    detail=f"BasePrompt with ID {prompt_id} not found"
                )
    
            # --- NEW RULE: Prevent toggling if referenced in model_experiments ---
            usage_count = (
                self.db.query(Model_Experiment)
                .filter(Model_Experiment.base_prompt_id == prompt_id)
                .count()
            )
    
            if usage_count > 0:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"BasePrompt {prompt_id} is used in {usage_count} experiment(s). "
                        "Cannot toggle active status."
                    )
                )
    
            # Safe to toggle
            db_prompt.is_active = not db_prompt.is_active
            db_commit_auto_rollback(db=self.db)
    
            app_logger.info(
                f"Toggled BasePrompt {db_prompt.id} active status to {db_prompt.is_active}"
            )
    
            return db_prompt
    
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(
                f"Unable to toggle BasePrompt active status. Reason - {message}"
            )
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update BasePrompt active status: {str(e)}",
            )

        
    def update_base_prompt(self, prompt_id: int, update_data):
        try:
            app_logger.info(f"Starting BasePrompt update for ID: {prompt_id}")
    
            if not isinstance(prompt_id, int) or prompt_id <= 0:
                raise HTTPException(
                    status_code=400,
                    detail="Invalid BasePrompt ID. Must be a positive integer."
                )
    
            db_prompt = (
                self.db.query(BasePrompt)
                .filter(BasePrompt.id == prompt_id)
                .first()
            )
    
            if db_prompt is None:
                raise HTTPException(
                    status_code=404,
                    detail=f"BasePrompt with ID {prompt_id} not found"
                )
    
            # 🚨 STRICT RULE: If used in ANY model_experiment, no updates allowed
            is_used = (
                self.db.query(Model_Experiment.id)
                .filter(Model_Experiment.base_prompt_id == prompt_id)
                .first()
            )
    
            if is_used:
                raise HTTPException(
                    status_code=409,
                    detail=(
                        f"BasePrompt '{db_prompt.prompt_name}' cannot be updated "
                        f"because it is currently being used in one or more model_experiments."
                    ),
                )
    
            # If not used → update normally
            update_fields = update_data.dict(exclude_unset=True)
    
            # Remove version if passed
            update_fields.pop("version", None)
    
            # Check duplicate name
            if "prompt_name" in update_fields:
                new_name = update_fields["prompt_name"].strip()
                existing_prompt = (
                    self.db.query(BasePrompt)
                    .filter(
                        BasePrompt.prompt_name == new_name,
                        BasePrompt.id != prompt_id
                    )
                    .first()
                )
                if existing_prompt:
                    raise HTTPException(
                        status_code=409,
                        detail={
                            "status": "error",
                            "message": (
                                f"Another BasePrompt with name '{new_name}' already exists."
                            ),
                            "data": {
                                "existing_prompt_id": existing_prompt.id,
                                "existing_prompt_name": existing_prompt.prompt_name,
                            },
                        }
                    )
    
            # Apply updates
            for key, value in update_fields.items():
                if hasattr(db_prompt, key):
                    setattr(db_prompt, key, value)
    
            db_commit_auto_rollback(self.db)
            self.db.refresh(db_prompt)
    
            return HttpResponse(
                status="success",
                message=f"BasePrompt '{db_prompt.prompt_name}' updated successfully",
                data=db_prompt
            )
    
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(
                f"Failed to update BasePrompt ID {prompt_id}. Reason - {message}"
            )
            raise HTTPException(
                status_code=500,
                detail={
                    "status": "error",
                    "message": f"Failed to update BasePrompt: {str(e)}",
                    "data": None,
                }
            )
    
    # ----------------------------------------------------------------------
    # GET by name
    # ----------------------------------------------------------------------
    def get_base_prompt_by_name(self, prompt_name: str) -> Optional[BasePrompt]:
        """Fetch a BasePrompt by its name."""
        try:
            prompt = (
                self.db.query(BasePrompt)
                .filter(BasePrompt.prompt_name == prompt_name)
                .first()
            )
    
            if not prompt:
                app_logger.info(f"BasePrompt with name '{prompt_name}' not found.")
                return None
    
            app_logger.info(f"BasePrompt with name '{prompt_name}' retrieved successfully.")
            return prompt
    
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(
                f"Unable to fetch BasePrompt with name '{prompt_name}'. Reason - {message}"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to fetch BasePrompt: {str(e)}"
            )