import traceback
from fastapi import HTTPException
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.databricks_util import DatabricksJobManager,CatalogService

# Set up logging
app_logger = get_logger(__name__)

class BusinessGlossary_Service:
    token: str

    # Constructor method to initialize ComputeService with an authentication token.
    # The token is used to authenticate against the Databricks API.
    # Args:
    #     token (str): The Databricks API authentication token
    def __init__(self, token: str) -> None:
        self.token = token

    def upload_file(self,path):

        try:
            CatalogService_service = CatalogService(self.token)
            msg, file_path = CatalogService_service.upload_data_as_xlsx(path)
            return msg, file_path  # Return the created entity
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to upload file. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")
    
    def create_run_job(self,file_path):

        try:
            notebook_path = "/Workspace/Shared/business_glossary_insert"
            job_name = "Business_Glossary_Update"
            DatabricksJobManager_service = DatabricksJobManager(self.token)
            job_id = DatabricksJobManager_service.create_job_without_schedule(file_path, notebook_path, job_name)
            job_response = DatabricksJobManager_service.run_job(job_id)
            return job_response 
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create or run job. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create or run job: {str(e)}")