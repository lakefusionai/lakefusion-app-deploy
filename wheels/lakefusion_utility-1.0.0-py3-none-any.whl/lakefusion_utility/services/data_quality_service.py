import traceback
from sqlalchemy.orm import Session
from datetime import datetime
from fastapi import HTTPException
from typing import List, Optional
from lakefusion_utility.utils.databricks_util import JobService
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.models.data_quality import QualityDiagram, DiagramExecutionLog, DiagramCreate, DiagramUpdate, DiagramResponse, ExecutionLogResponse
import json

app_logger = get_logger(__name__)

class QualityDiagramService:
    def __init__(self, db: Session):
        self.db = db

    def create_diagram(self, diagram: DiagramCreate, created_by: str) -> DiagramResponse:
        """Create a new quality diagram."""
        try:
            db_diagram = QualityDiagram(
                **diagram.model_dump(),
                created_by=created_by
            )
            self.db.add(db_diagram)
            self.db.commit()
            self.db.refresh(db_diagram)
            return db_diagram
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create diagram. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to create diagram: {str(e)}")

    def get_diagram(self, diagram_id: int) -> Optional[DiagramResponse]:
        """Get a diagram by ID."""
        try:
            diagram = self.db.query(QualityDiagram).filter(
                QualityDiagram.id == diagram_id,
                QualityDiagram.is_active == True
            ).first()
            if not diagram:
                raise HTTPException(status_code=404, detail="Diagram not found")
            return diagram
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to retrieve diagram. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to retrieve diagram: {str(e)}")

    def get_all_diagrams(self) -> List[DiagramResponse]:
        """Get all active diagrams."""
        try:
            return self.db.query(QualityDiagram).filter(
                QualityDiagram.is_active == True
            ).all()
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to retrieve diagrams. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to retrieve diagrams: {str(e)}")

    def update_diagram(self, diagram_id: int, diagram: DiagramUpdate) -> DiagramResponse:
        """Update an existing diagram."""
        try:
            db_diagram = self.get_diagram(diagram_id)
            
            for key, value in diagram.model_dump(exclude_unset=True).items():
                setattr(db_diagram, key, value)
            
            self.db.commit()
            self.db.refresh(db_diagram)
            return db_diagram
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update diagram. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to update diagram: {str(e)}")

    def delete_diagram(self, diagram_id: int) -> bool:
        """Soft delete a diagram."""
        try:
            diagram = self.get_diagram(diagram_id)
            diagram.is_active = False
            self.db.commit()
            return True
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete diagram. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to delete diagram: {str(e)}")

    def execute_diagram(self, diagram_id: int, created_by: str, token: str) -> ExecutionLogResponse:
        """Execute a diagram's transformations."""
        try:
            diagram = self.get_diagram(diagram_id)
            job_service = JobService(token)

            # Create execution log
            execution_log = DiagramExecutionLog(
                diagram_id=diagram_id,
                status="running",
                created_by=created_by
            )
            self.db.add(execution_log)
            self.db.flush()

            try:
                # Prepare job parameters
                job_params = {
                    "input_table": diagram.dataset.path,
                    "table_primary_key": "PatientID",
                    "transformations_config": json.dumps(diagram.transformations)
                }

                # Create or update Databricks job
                if diagram.job_info and diagram.job_info.get('job_id'):
                    job_id = diagram.job_info['job_id']
                    job_response = job_service.update_single_task_job(
                        job_id=job_id,
                        job_name=f"Quality_Diagram_{diagram_id}",
                        notebook_path="/Users/shridharelango@friscoanalytics.com/DQnotebook",
                        job_parameters=job_params,
                        failure_notification_emails=[created_by],
                        quartz_cron_expression="0 0 0 1/1 * ? *",
                        timezone_id="UTC"
                    )
                else:
                    job_response = job_service.create_single_task_job(
                        job_name=f"Quality_Diagram_{diagram_id}",
                        notebook_path="/Users/shridharelango@friscoanalytics.com/DQnotebook",
                        job_parameters=job_params,
                        failure_notification_emails=[created_by],
                        quartz_cron_expression="0 0 0 1/1 * ? *",
                        timezone_id="UTC"
                    )
                    # Store job_id in diagram.job_info
                    diagram.job_info = {"job_id": job_response.job_id}

                # Run the job
                run_response = job_service.run_job(job_id=diagram.job_info['job_id'])
                
                # Update execution log with run details
                execution_log.execution_details = {
                    "job_id": diagram.job_info['job_id'],
                    "run_id": run_response.run_id
                }
                execution_log.status = "running"
                
                self.db.commit()
                return execution_log

            except Exception as job_error:
                message = traceback.format_exc()
                app_logger.exception(f'Job creation/execution error. Reason - {message}')
                execution_log.status = "failed"
                execution_log.error_message = str(job_error)
                execution_log.end_time = datetime.utcnow()
                self.db.commit()
                raise HTTPException(
                    status_code=500,
                    detail=f"Failed to execute job: {str(job_error)}"
                )

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to execute diagram. Reason - {message}')
            self.db.rollback()
            raise HTTPException(
                status_code=500,
                detail=f"Failed to execute diagram: {str(e)}"
            )