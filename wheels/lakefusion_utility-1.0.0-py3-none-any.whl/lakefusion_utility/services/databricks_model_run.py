import traceback
from sqlalchemy.orm import Session
from typing import List
from lakefusion_utility.utils.logging_utils import get_logger
from fastapi import HTTPException
from databricks.sdk.errors import PermissionDenied
import os,json
from sqlalchemy import or_, func, JSON
from lakefusion_utility.models.match_maven import *
from lakefusion_utility.models.databricks_model import *
from lakefusion_utility.utils.databricks_util import DatabricksJobManager
from sqlalchemy import and_
app_logger = get_logger(__name__)

lakefusion_databricks_dapi = os.environ.get('LAKEFUSION_DATABRICKS_DAPI', '')

class Monitor_Model_Databricks_Job:
    def __init__(self, db: Session):
        self.db = db

    def get_experiment_status(self, job_run_data: List[Dict], job_run_id) -> str:
        """
        Update experiment status based on job run tasks states
        
        Args:
            job_run_data: List of job run task data.
            job_run_id: Job run identifier.
            
        Returns:
            Experiment status string.
        
        Raises:
            HTTPException: If there's an error during status determination.
        """
        try:
            # Convert list to dict for easier lookup
            if not job_run_data:
                return 'experiment_preparetables'
            task_states = {task['task_key']: task for task in job_run_data}
            
            
            # Check conditions in order of priority
            
            # 1. Check for any failures first
            failed_tasks = [task for task in job_run_data 
                           if task['result_state'] in ['FAILED', 'UPSTREAM_FAILED']]
            if failed_tasks:
                # Update database
                job_record = self.db.query(Model_Databricks_Job).filter(
                    Model_Databricks_Job.job_run_id == job_run_id
                ).first()
                if job_record:
                    return 'experiment_failed'
                
            cancelled_tasks = [task for task in job_run_data 
                           if task['result_state'] in ['CANCELED', 'UPSTREAM_CANCELED']]
            if cancelled_tasks:
                # Update database
                job_record = self.db.query(Model_Databricks_Job).filter(
                    Model_Databricks_Job.job_run_id == job_run_id
                ).first()
                if job_record:
                    return 'experiment_cancelled'
                
        
            # 2. Check if all tasks are complete successfully
            all_success = all(
                (task['state'] == 'TERMINATED' and task['result_state'] == 'SUCCESS') or (task['result_state'] == 'EXCLUDED')
                for task in job_run_data
            )
            if all_success:
                job_record = self.db.query(Model_Databricks_Job).filter(
                    Model_Databricks_Job.job_run_id == job_run_id
                ).first()
                if job_record:
                    return 'review'
            
            if task_states.get('Entity_Matching_LLM_Experiment', {}).get('state') == 'RUNNING':
                return 'experiment_computematches_llm'
            
            if task_states.get('Entity_Matching_Vector_Search_Experiment', {}).get('state') == 'RUNNING':
                return 'experiment_computematches_vs'
        
            # 3. Check other states in sequence
            if task_states['Parse_Entity_Model_JSON']['state'] == 'TERMINATED' and \
               task_states['Parse_Entity_Model_JSON']['result_state'] == 'SUCCESS':
                return 'experiment_prepareenv'
            
            # If none of the above conditions match, return preparetables status
            return 'experiment_preparetables'
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to get experiment status. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to get experiment status: {str(e)}")  # ✅ Added
    
    def get_pending_tasks(self):
        """
        Retrieve all rows where task_status is 'pending' from the Model_Databricks_Job table.

        Returns:
            List[Model_Databricks_Job]: List of jobs with task_status as 'pending'.
        
        Raises:
            HTTPException: If there's an error during database query.
        """
        try:
            pending_tasks = self.db.query(Model_Databricks_Job).filter(
                and_(
                    (or_(Model_Databricks_Job.experiment_status.contains('experiment'),Model_Databricks_Job.experiment_status=='prepare')),
                    Model_Databricks_Job.experiment_status.not_in(['experiment_failed','experiment_cancelled'])
                )
            ).all()
            return pending_tasks
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch pending tasks. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch pending tasks: {str(e)}")
   

    def update_job_run_status(self, job_run_id: str,new_job_run_status,new_experiment_status:str):
        """
        Update the task_status in the job_run_status JSON column for a specific job_run_id.
        
        Args:
            job_run_id (str): The job run ID to filter the records.
            new_job_run_status: The new job run status.
            new_experiment_status (str): The new experiment status to set.
    
        Returns:
            Updated job entry.
        
        Raises:
            HTTPException: If there's an error during status update.
        """
        try:
            # Update the job_run_status JSON field's task_status for the given job_run_id
           
            job_entry = self.db.query(Model_Databricks_Job).filter(Model_Databricks_Job.job_run_id == job_run_id).first()
            #job_entry = self.db.query(Model_Databricks_Job).filter(Model_Databricks_Job.job_run_id == job_run_id).filter().first()
            if not job_entry:
               raise ValueError(f"No job found with run_id: {job_run_id}")
            
            model_entry = self.db.query(Model_Experiment).filter(Model_Experiment.id == job_entry.modelid).first()
            if not model_entry:
               raise ValueError(f"No model found with id: {job_entry.modelid}")
            # Update the job_run_status field with the new status
            if new_job_run_status is not None and new_job_run_status != []:
                job_entry.job_run_status=new_job_run_status
            self.db.commit()  # Commit changes to the database
            self.db.refresh(job_entry)
            job_entry.experiment_status=new_experiment_status
            self.db.commit()  # Commit changes to the database
            self.db.refresh(job_entry) # Refresh the object to get the updated values

            model_entry.status=new_experiment_status
            #model_entry.processed_records=process_records
            self.db.commit()  # Commit changes to the database
            self.db.refresh(model_entry) # Refresh the object to get the updated values
            return job_entry  # Return the updated job entry
        
        except ValueError:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update job run status. Reason - {message}')
            self.db.rollback()  # Rollback in case of an error
            raise HTTPException(status_code=500, detail=f"Failed to update job run status: {str(e)}")

def check_job_monitor_status(db: Session):
    """
    Check and update the monitor status of pending profiling tasks.

    Returns:
        None: This function does not return a value.

    Raises:
        HTTPException: If there is an issue with the database query or 
          fetching monitor information.
    """
    app_logger.info("Starting check_monitor_status function execution.")
    
    try:
        # Initialize the ProfilingTaskService with the database session.
        monitor_model_job_service = Monitor_Model_Databricks_Job(db)
        
        # Attempt to fetch tasks that have a pending monitor status.
        try:
            pending_job_run_tasks = monitor_model_job_service.get_pending_tasks()
        except Exception as e:
            # Log any errors that occur while fetching pending tasks.
            message = traceback.format_exc()
            app_logger.exception(f'Error fetching pending tasks. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch pending tasks: {str(e)}")
            
        # Iterate over each pending task to check its monitor status.
        for job_run in pending_job_run_tasks:
            try:
                # Fetch the latest monitor information for the task's dataset.
                job_status=DatabricksJobManager(token=lakefusion_databricks_dapi)
                latest_job_run_info = job_status.get_job_run_status(job_run.job_run_id)
                new_experiment_status=monitor_model_job_service.get_experiment_status(latest_job_run_info,job_run.job_run_id)
                monitor_model_job_service.update_job_run_status(job_run.job_run_id,latest_job_run_info,new_experiment_status)

            except Exception as task_error:
                # Log any errors that occur while processing each individual task.
                message = traceback.format_exc()
                app_logger.exception(f'Error processing job run with ID {job_run.job_run_id}. Reason - {message}')
                raise HTTPException(status_code=500, detail=f"Failed to process job run {job_run.job_run_id}: {str(task_error)}")

    except Exception as function_error:
        # Log any errors that occur at the function level.
        message = traceback.format_exc()
        app_logger.exception(f'Error in check_job_monitor_status function. Reason - {message}')
        raise HTTPException(status_code=500, detail=f"Failed to check job monitor status: {str(function_error)}")
    
    # Log the completion of the function execution.
    app_logger.info("Finished check_job_monitor_status function execution.")
