import json
from datetime import datetime
from decimal import Decimal
import uuid
from databricks.sdk import WorkspaceClient
from lakefusion_utility.utils.databricks_util import DataSetSQLService, DBFSService
from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
from sqlalchemy.orm import Session
from lakefusion_utility.utils.logging_utils import get_logger
import traceback
from sqlalchemy import text
from lakefusion_utility.utils.databricks_util import NotebookService
import os
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
import tempfile
from databricks.sdk.service.workspace import ObjectInfo
from databricks.sdk.service.iam import PermissionLevel
import base64
from databricks.sdk.service import workspace as ws

app_logger = get_logger(__name__)

lakefusion_databricks_dapi = os.environ.get('LAKEFUSION_DATABRICKS_DAPI', '')

# Custom JSON Encoder to handle different types
class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()  # Convert datetime to ISO 8601 string
        elif isinstance(obj, Decimal):
            return float(obj)  # Convert Decimal to float
        elif isinstance(obj, uuid.UUID):
            return str(obj)  # Convert UUID to string
        elif isinstance(obj, dict):
            # Handle nested JSON objects (you can expand this if needed)
            return {key: self.default(value) for key, value in obj.items()}
        else:
            # Call the base class's default method to handle other types
            return super().default(obj)

def sync_all_tables(db: Session):
    """Sync all tables from MySQL to Databricks.
    
    This function fetches all tables from the MySQL database, retrieves their data, 
    and uploads it to Databricks as a JSON file.
    """
    app_logger.info("Starting sync process for all tables from MySQL to Databricks.")

    # Fetch the list of all tables from the MySQL database
    db_config_properties_service = DBConfigPropertiesService(db=db)
    tables = db_config_properties_service.getDBConfigProperties('sync_tables')
    table_names = tables.split(',')
    
    # Dictionary to hold data for all tables
    db_data = {}

    cursor = db.get_bind().connect()

    # Iterate through all the tables and fetch their data
    for table_name in table_names:
        app_logger.info(f"Syncing table: {table_name}")

        try:
            # Fetch all rows from the current table
            query = text(f"SELECT * FROM {table_name}")
            result = cursor.execute(query)
            rows = result.fetchall()
            
            # Store the fetched data in the db_data dictionary
            db_data[table_name] = rows
            app_logger.info(f"Successfully fetched {len(rows)} rows from table: {table_name}")

        except Exception as e:
            # Log the error with detailed information if table sync fails
            message = traceback.format_exc()
            app_logger.exception(f'Unable to sync table - {table_name}. Reason - {message}')
    
    # Convert the db_data dictionary into a JSON string
    json_content = json.dumps(db_data, cls=CustomJSONEncoder)

    # Define the file path for saving to DBFS in Databricks
    dbfs_file_path = f"/dbfs/lakefusion_ai/transactional_db.json"
    app_logger.info(f"Uploading data to DBFS at path: {dbfs_file_path}")

    # Create a DBFS service instance to handle the file upload
    dbfs_service = DBFSService(token=lakefusion_databricks_dapi)
    
    # Upload the JSON content to DBFS
    try:
        dbfs_service.upload_to_dbfs_stream(dbfs_file_path, json_content)
        app_logger.info("Successfully uploaded data to DBFS.")
    except Exception as e:
        # Log any error encountered during file upload
        message = traceback.format_exc()
        app_logger.exception(f"Failed to upload data to DBFS. Reason - {message}")

def import_custom_tags_file(db: Session):
    """
    Writes JSON string to a temp custom_tags.json file,
    uploads it to Databricks workspace,
    and applies CAN_MANAGE permission to the SPN.
    """
    db_config_properties_service = DBConfigPropertiesService(db=db)
    target_path = db_config_properties_service.getDBConfigProperties('notebook_path', required=True)
    lakefusion_spn = db_config_properties_service.getDBConfigProperties('lakefusion_spn', required=True)
    lakefusion_custom_tags = db_config_properties_service.getDBConfigProperties('resource_tagging', required=True)
    notebook_service = NotebookService(token=lakefusion_databricks_dapi)

    # ✅ Parse JSON string safely
    try:
        custom_tags_dict = json.loads(lakefusion_custom_tags)
    except Exception:
        app_logger.error("❌ Invalid JSON string for custom_tags.json")
        raise

    # ✅ Write to custom_tags.json
    temp_json = tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".json")
    json.dump(custom_tags_dict, temp_json, indent=2)
    temp_json.close()
    app_logger.info(f"📝 custom_tags.json written to: {temp_json.name}")

    # ✅ Upload to workspace
    json_workspace_path = f"{target_path}/custom_tags.json"

    notebook_service.import_single_file(
        source_file_path=temp_json.name,
        target_path=json_workspace_path,
        overwrite=True
    )
    app_logger.info(f"📤 custom_tags.json uploaded to workspace: {json_workspace_path}")

    # ✅ Fetch object info
    json_info: ObjectInfo = notebook_service.get_object_info(json_workspace_path)

    # ✅ Apply permissions
    notebook_service.set_permissions(
        workspace_object=json_info,
        principal_id=lakefusion_spn,
        permission=PermissionLevel.CAN_MANAGE,
        is_service_principal=True,
    )

    app_logger.info("🔐 Permissions applied on custom_tags.json to Service Principal")

def import_lakefusion_artifacts(db: Session):
    """
    Cron job function that imports Lakefusion dbx pipeline artifacts into Databricks.
    - Notebook files (.py, .sql, .scala, .r, .ipynb) → Imported as notebooks (extension removed)
    - Non-notebook files (.whl, .json, .sh, .md, etc.) → Uploaded as files (extension preserved)
    """
    db_config_properties_service = DBConfigPropertiesService(db=db)
    target_path = db_config_properties_service.getDBConfigProperties('notebook_path', required=True)
    lakefusion_spn = db_config_properties_service.getDBConfigProperties('lakefusion_spn', required=True)
    artifacts_dir = "dbx_pipeline_artifacts"

    # Define notebook extensions - these will be imported as notebooks (extension removed)
    notebook_extensions = {
        '.py': (ws.Language.PYTHON, ws.ImportFormat.SOURCE),
        '.sql': (ws.Language.SQL, ws.ImportFormat.SOURCE),
        '.scala': (ws.Language.SCALA, ws.ImportFormat.SOURCE),
        '.r': (ws.Language.R, ws.ImportFormat.SOURCE),
        '.ipynb': (ws.Language.PYTHON, ws.ImportFormat.JUPYTER),
    }
    
    # Define file extensions that should be uploaded as regular files (extension preserved)
    regular_file_extensions = {'.whl', '.jar', '.egg', '.json', '.sh', '.bash', '.md', 
                               '.txt', '.yaml', '.yml', '.conf', '.properties', '.xml',
                               '.csv', '.tsv', '.parquet', '.avro', '.orc'}

    try:
        notebook_service = NotebookService(token=lakefusion_databricks_dapi)

        app_logger.info(
            f"🚀 Starting import of artifacts from {artifacts_dir} → {target_path}"
        )

        # Walk through the artifacts directory
        for root, dirs, files in os.walk(artifacts_dir):
            # Skip hidden directories and common non-artifact directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in {'__pycache__', 'node_modules', '.git'}]
            
            # Calculate relative path for current directory
            relative_path = os.path.relpath(root, artifacts_dir)
            ws_subdir = (
                target_path if relative_path == "." 
                else os.path.join(target_path, relative_path).replace("\\", "/")
            )
            
            # Ensure the workspace directory exists
            notebook_service.w.workspace.mkdirs(ws_subdir)
            
            for file in files:
                file_path = os.path.join(root, file)
                file_name = os.path.basename(file)
                file_ext = os.path.splitext(file_name)[1].lower()
                
                # Skip hidden files
                if file_name.startswith('.'):
                    app_logger.info(f"⏭️  Skipping hidden file: {file_path}")
                    continue
                
                try:
                    # Check if file is a notebook - import as notebook (remove extension)
                    if file_ext in notebook_extensions:
                        # Remove extension for notebook import
                        file_name_without_ext = os.path.splitext(file_name)[0]
                        workspace_path = os.path.join(ws_subdir, file_name_without_ext).replace('\\', '/')
                        
                        # Get language and format for this notebook type
                        language, import_format = notebook_extensions[file_ext]
                        
                        app_logger.info(
                            f"📓 Importing notebook: {file_path} → {workspace_path} "
                            f"(language: {language.name}, format: {import_format.name})"
                        )
                        
                        # Read file content and encode as base64
                        with open(file_path, "rb") as f:
                            content = base64.b64encode(f.read()).decode("utf-8")
                        
                        # Import as notebook using workspace.import_()
                        notebook_service.w.workspace.import_(
                            path=workspace_path,
                            content=content,
                            format=import_format,
                            language=language,
                            overwrite=True,
                        )
                        
                    # Check if file should be uploaded as regular file (preserve extension)
                    elif file_ext in regular_file_extensions:
                        # Keep extension for regular file upload
                        workspace_path = os.path.join(ws_subdir, file_name).replace('\\', '/')
                        
                        app_logger.info(f"📦 Uploading file (preserving extension): {file_path} → {workspace_path}")
                        
                        # Use import_single_file for regular files
                        notebook_service.import_single_file(
                            source_file_path=file_path,
                            target_path=workspace_path,
                            overwrite=True
                        )
                        
                    else:
                        # Unknown file type - treat as regular file (preserve extension)
                        workspace_path = os.path.join(ws_subdir, file_name).replace('\\', '/')
                        
                        app_logger.warning(
                            f"⚠️  Unknown file type '{file_ext}', uploading as regular file: "
                            f"{file_path} → {workspace_path}"
                        )
                        
                        notebook_service.import_single_file(
                            source_file_path=file_path,
                            target_path=workspace_path,
                            overwrite=True
                        )
                        
                except Exception as e:
                    app_logger.warning(f"⚠️  Failed to import {file_path}: {str(e)}")
                    continue

        app_logger.info("✅ Successfully imported all artifacts")

        info: ObjectInfo = notebook_service.get_object_info(target_path)

        # Grant manage permission to a service principal
        notebook_service.set_permissions(
            workspace_object=info,
            principal_id=lakefusion_spn,
            permission=PermissionLevel.CAN_MANAGE,
            is_service_principal=True,
        )

        # ✅ Feature flag logic
        if FeatureFlagService._is_feature_flag_enabled(db=db, name="ENABLE_LAKEFUSION_TAG_USAGE"):
            app_logger.info("✅ Feature flag ENABLE_LAKEFUSION_TAG_USAGE is ACTIVE — importing custom_tags.json")
            import_custom_tags_file(
                db=db
            )
        else:
            app_logger.info("Feature flag ENABLE_LAKEFUSION_TAG_USAGE is INACTIVE — skipping custom_tags.json")

    except Exception as e:
        app_logger.error(
            f"❌ Failed to import artifacts from {artifacts_dir} → {target_path}. Error: {str(e)}",
            exc_info=True,  # logs traceback as well
        )
        raise  # re-raise so caller can handle if needed
