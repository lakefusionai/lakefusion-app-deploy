import traceback
from typing import Optional
from sqlalchemy.orm import Session
from lakefusion_utility.models.dataset import Dataset
from lakefusion_utility.models.httpresponse import HttpResponse
from fastapi import HTTPException, status
from lakefusion_utility.utils.app_db import db_commit_auto_rollback  # Import the db_commit_auto_rollback function
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.databricks_util import CatalogService
from lakefusion_utility.utils.references_checker_utility import is_value_referenced_elsewhere
from lakefusion_utility.utils.databricks_util import CatalogService

# Set up logging
app_logger = get_logger(__name__)

class DatasetService:
    def __init__(self, db: Session):
        """Initializes the DatasetService with a database session.
        
        Args:
            db: SQLAlchemy session object.
        """
        self.db = db

    def create_dataset(self, dataset_create):
        """
        Create a new dataset and save it to the database.
        
        This method handles:
        1. Validating required fields (name and path)
        2. Checking for duplicate name-path combinations
        3. Creating a new dataset with validated data
        4. Ensuring atomic transactions and proper error handling
        
        Args:
            dataset_create: Pydantic model containing the dataset data
            
        Returns:
            HttpResponse with:
                - status: Success status
                - message: Detailed success message
                - data: Created Dataset object with metadata
                
        Raises:
            HTTPException: 
                - 400 for missing required fields or duplicate combinations
                - 500 for system errors
        """
        try:
            app_logger.info(f"Starting dataset creation with name: {getattr(dataset_create, 'name', 'N/A')}")
            
            # Start a nested transaction for atomicity
            with self.db.begin_nested():
                # Validate and prepare dataset data
                dataset_data = dataset_create.dict()
                
                # Validate required fields
                required_fields = ['name', 'path']
                for field in required_fields:
                    field_value = dataset_data.get(field)
                    if not field_value or not str(field_value).strip():
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": f"Missing required field: {field}",
                                "data": None
                            }
                        )
                
                # Normalize field values by stripping whitespace
                dataset_data['name'] = dataset_data['name'].strip()
                dataset_data['path'] = dataset_data['path'].strip()
                
                app_logger.debug(f"Validated dataset data: name='{dataset_data['name']}', path='{dataset_data['path']}'")
                
                # Check for existing dataset with same name and path combination
                existing_dataset = self.db.query(Dataset).filter(
                    Dataset.name == dataset_data['name'],
                    Dataset.path == dataset_data['path']
                ).first()
                
                if existing_dataset:
                    app_logger.warning(f"Dataset with name '{dataset_data['name']}' and path '{dataset_data['path']}' already exists (ID: {existing_dataset.id})")
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail={
                            "status": "error",
                            "message": f"Dataset with name '{dataset_data['name']}' and path '{dataset_data['path']}' already exists",
                            "data": {
                                "existing_dataset_id": existing_dataset.id,
                                "existing_dataset_name": existing_dataset.name,
                                "existing_dataset_path": existing_dataset.path
                            }
                        }
                    )
                
                # Create new dataset instance
                new_dataset = Dataset(**dataset_data)
                app_logger.debug(f"Created dataset instance: {dataset_data['name']}")
                
                # Add and flush to get ID
                self.db.add(new_dataset)
                self.db.flush()
                
                # Verify ID generation
                if not new_dataset.id:
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail={
                            "status": "error",
                            "message": "Failed to generate dataset ID",
                            "data": None
                        }
                    )
                
                app_logger.debug(f"Dataset flushed with ID: {new_dataset.id}")
            
            # Commit changes
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(new_dataset)
            
            app_logger.info(f"Successfully created dataset {new_dataset.id} with name '{new_dataset.name}'")
            
            # Prepare response with metadata
            return HttpResponse(
                status="success",
                message=f"Dataset '{new_dataset.name}' created successfully",
                data=new_dataset
            )
            
        except HTTPException as he:
            app_logger.warning(f"HTTP error during dataset creation: {he.detail}")
            raise he
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to create dataset: {message}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "status": "error",
                    "message": f"Failed to create dataset: {str(e)}",
                    "data": None
                }
            )

    def read_datasets(self, is_active: Optional[bool] = None, sort_by: str = "created_at", sort_order: str = "desc", limit: Optional[int] = None, offset: int = 0):
        """Retrieves datasets from the database with filtering, sorting, and pagination options.
        
        Args:
            is_active: Filter datasets by their active status. If None, returns all datasets.
            sort_by: Field to sort by (e.g., 'id', 'name', 'created_at', 'updated_at'). Default is 'created_at'.
            sort_order: Sort order, either 'asc' or 'desc'. Default is 'desc'.
            limit: Maximum number of records to return. If None, returns all matching records.
            offset: Number of records to skip for pagination. Default is 0.
            
        Returns:
            A list of datasets based on the specified filters and sorting.
            
        Raises:
            HTTPException: If there's an error during retrieval or invalid parameters.
        """
        try:
            # Validate sort_order parameter
            if sort_order.lower() not in ['asc', 'desc']:
                raise HTTPException(status_code=400, detail="sort_order must be either 'asc' or 'desc'")
            
            # Validate sort_by field exists on the Dataset model
            if not hasattr(Dataset, sort_by):
                raise HTTPException(status_code=400, detail=f"Invalid sort field: {sort_by}")
            
            # Start building the query
            dataset_q = self.db.query(Dataset)
            
            # Apply active filter if specified
            if is_active is not None:
                dataset_q = dataset_q.filter(Dataset.is_active == is_active)
            
            # Apply sorting
            sort_field = getattr(Dataset, sort_by)
            if sort_order.lower() == 'desc':
                dataset_q = dataset_q.order_by(sort_field.desc())
            else:
                dataset_q = dataset_q.order_by(sort_field.asc())
            
            # Apply pagination if specified
            if offset > 0:
                dataset_q = dataset_q.offset(offset)
            
            if limit is not None and limit > 0:
                dataset_q = dataset_q.limit(limit)
            
            # Execute query and return results
            datasets = dataset_q.all()
            
            app_logger.info(f"Successfully retrieved {len(datasets)} datasets with filters: is_active={is_active}, sort_by={sort_by}, sort_order={sort_order}")
            return datasets
            
        except HTTPException:
            # Re-raise HTTP exceptions (validation errors)
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch datasets. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch datasets: {str(e)}")
    
    def delete_dataset(self, dataset_id: int):
        """Deletes a dataset by ID permanently with comprehensive validation and safety checks.
        
        Args:
            dataset_id: The ID of the dataset to delete.
            
        Returns:
            A confirmation message with dataset information.
            
        Raises:
            HTTPException: If the dataset is not found, is referenced elsewhere, 
                          has invalid input, or an error occurs during deletion.
        """
        try:
            # Input validation
            if not isinstance(dataset_id, int) or dataset_id <= 0:
                app_logger.warning(f"Invalid dataset_id provided for deletion: {dataset_id}")
                raise HTTPException(
                    status_code=400, 
                    detail="Invalid dataset ID. Must be a positive integer."
                )

            # First, check if the dataset exists before checking references
            app_logger.info(f"Attempting to delete dataset with ID: {dataset_id}")
            db_dataset = self.db.query(Dataset).filter(Dataset.id == dataset_id).first()
            
            if db_dataset is None:
                app_logger.warning(f"Dataset with ID {dataset_id} not found")
                raise HTTPException(
                    status_code=404,
                    detail=f"Dataset with ID {dataset_id} not found"
                )
            
            # Store dataset info for logging before deletion
            dataset_name = getattr(db_dataset, 'name', 'Unknown')
            dataset_info = {
                'id': db_dataset.id,
                'name': dataset_name,
                'is_active': getattr(db_dataset, 'is_active', None)
            }
            
            # Check for references in other tables
            app_logger.info(f"Checking references for dataset {dataset_id} before deletion")
            referencing_tables = is_value_referenced_elsewhere(
                    db=self.db,
                    table_name="datasets",
                    column_name="dataset_id",
                    value=dataset_id,
            )
                
            if referencing_tables:
                app_logger.warning(f"Cannot delete dataset {dataset_id}. Referenced in tables: {', '.join(referencing_tables)}")
                raise HTTPException(
                    status_code=409,  # Conflict status code for referential integrity
                    detail=f"Cannot delete dataset '{dataset_name}' as it is referenced elsewhere."
                )

            # Perform the deletion with transaction safety
            app_logger.info(f"Proceeding with deletion of dataset: {dataset_info}")
            self.db.delete(db_dataset)
            db_commit_auto_rollback(db=self.db)
                
            # Log successful deletion
            app_logger.info(f"Successfully deleted dataset: {dataset_info}")
                
            return {
                "detail": "Dataset successfully deleted",
                "deleted_dataset": {
                    "id": dataset_info['id'],
                    "name": dataset_info['name'],
                    "was_active": dataset_info['is_active']
                }
            }
                
        except HTTPException:
            # Re-raise HTTP exceptions (validation/business logic errors)
            raise
        except Exception as e:
            # Handle unexpected errors
            message = traceback.format_exc()
            app_logger.exception(f'Unexpected error while deleting dataset {dataset_id}. Reason - {message}')
            raise HTTPException(
                status_code=500, 
                detail=f"An unexpected error occurred while deleting dataset: {str(e)}"
            )
    
    def update_dataset_primary_field(self, dataset_id: int, primary_field: str):
        """Updates the primary_field field of a dataset by ID.
        
        Args:
            dataset_id: The ID of the dataset to update.
            primary_field: The new primary key value to set.
            
        Returns:
            A confirmation message with the updated dataset information.
            
        Raises:
            HTTPException: If the dataset is not found or an error occurs during update.
        """
        try:
            # Fetch the dataset by ID
            db_dataset = self.db.query(Dataset).filter(Dataset.id == dataset_id).first()
            if db_dataset is None:
                return {"detail": "Dataset not found"}
            
            # Update the primary_field field
            db_dataset.primary_field = primary_field
            db_commit_auto_rollback(db=self.db)  # Commit changes and handle rollback on failure
            
            return {
                "detail": "Dataset primary key successfully updated",
                "dataset_id": dataset_id,
                "new_primary_field": db_dataset.primary_field
            }
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update dataset primary key. Reason - {message}')
            raise HTTPException(status_code=500, detail="An internal server error occurred while updating the dataset primary key.")
        

    def get_dataset_by_id(self, dataset_id: int):
        """Retrieves a dataset object by its ID.
        
        Args:
            dataset_id: The ID of the dataset to retrieve.
            
        Returns:
            The dataset object.
        
        Raises:
            HTTPException: If the dataset is not found.
        """
        try:
            # Fetch the dataset by ID
            db_dataset = self.db.query(Dataset).filter(Dataset.id == dataset_id).first()
            if db_dataset is None:
                return None
            return db_dataset  # Return the found dataset
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch dataset with ID {dataset_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch dataset: {str(e)}")
        
    def toggle_dataset_active(self, dataset_id: int):
        """Toggles the `is_active` flag of a dataset.
        
        Args:
            dataset_id: The ID of the dataset to update.
            is_active: The new `is_active` status.
            
        Returns:
            The updated dataset object.
        """
        try:
            db_dataset = self.db.query(Dataset).filter(Dataset.id == dataset_id).first()
            if db_dataset is None:
                return None
            
            db_dataset.is_active = not db_dataset.is_active
            db_commit_auto_rollback(db=self.db)
            return db_dataset
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update dataset active status. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to update dataset active status: {str(e)}")
        
    def get_dataset_by_path(self, path: str):
        """Fetch a dataset by its path"""
        return self.db.query(Dataset).filter(Dataset.path == path).first()
    
    def check_cleaned_table_exists(self, token: str, dataset_id: int, dataset_path: str) -> bool:
        """Check if a cleaned table exists for the given dataset ID."""
        try:
            catalog_service = CatalogService(token, self.db)
            
            # Prepare table name
            cleaned_table_name = dataset_path.lower() + f"_cleaned"
            
            return {
                "cleaned_table_exists": catalog_service.check_table_exists(cleaned_table_name),
                "table_name": cleaned_table_name,
            }
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to check cleaned table existence. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to check cleaned table existence: {str(e)}")
    def check_dataset_path_exists(self, token: str,  dataset_path: str) -> dict:   
        try:
            catalog_service = CatalogService(token, self.db)
                 
            return {
                "dataset_path_exists": catalog_service.check_table_exists(dataset_path),
                "table_name": dataset_path,
            }
        except Exception as e:
            app_logger.exception(f"Failed to check {dataset_path} path: {e}")
            raise HTTPException(
                status_code=500, 
                detail=f"Error checking table existence: {str(e)}"
            )
        
