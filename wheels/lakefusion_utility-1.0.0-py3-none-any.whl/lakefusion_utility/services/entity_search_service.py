import traceback
from sqlalchemy.orm import Session
from lakefusion_utility.models.dataset import Dataset
from lakefusion_utility.models.integration_hub import Integration_Hub
from fastapi import HTTPException
from lakefusion_utility.utils.app_db import db_commit_auto_rollback  # Import the db_commit_auto_rollback function
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.databricks_util import DataSetSQLService, CommonUtilities
from lakefusion_utility.services.entity_service import EntityService, EntityAttributeService
from lakefusion_utility.models.entity import Entity, EntityAttributes
from sqlalchemy import and_
from databricks.sdk.service import jobs
from lakefusion_utility.models.databricks_model import *
from databricks.sdk.service.compute import ClusterSpec, RuntimeEngine,AwsAttributes,AwsAvailability,AutoScale,DataSecurityMode,AzureAttributes
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from lakefusion_utility.utils.databricks_util import DatabricksJobManager, DataSetSQLService, get_resource_tags
from lakefusion_utility.models.httpresponse import HttpResponse
from databricks.sdk.service.jobs import Task, NotebookTask, TaskEmailNotifications, RunIf, Source, CronSchedule, JobParameterDefinition, CreateResponse, Job, JobSettings,TaskDependency,ConditionTask,ConditionTaskOp,JobParameter,SubmitTask,SqlTask,SqlTaskQuery

from typing import List,Literal,Dict, Any, Tuple, Optional
from lakefusion_utility.utils.logging_utils import get_logger
from databricks.sdk.errors import PermissionDenied
import os,json
from sqlalchemy import or_, func, JSON
from lakefusion_utility.models.match_maven import *
from lakefusion_utility.models.databricks_model import *
from lakefusion_utility.models.entity import EntityAttributes  # re-import after wildcard to override match_maven.EntityAttributes
from lakefusion_utility.utils.databricks_util import DatabricksJobManager
from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
import math
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.notebook_path_utils import get_notebook_folder
from decimal import Decimal
from datetime import date, datetime
import re

# Set up logging
app_logger = get_logger(__name__)

def serialize_row_data(row_dict: dict) -> dict:
    """
    Serialize row data with proper numeric precision handling.
    Converts float/Decimal types to properly formatted strings to preserve precision.
    
    Args:
        row_dict: Dictionary containing row data
    
    Returns:
        Processed dictionary with proper numeric precision
    """
    processed = {}
    for key, value in row_dict.items():
        if isinstance(value, Decimal):
            # Convert Decimal to float, round, then format
            rounded = round(float(value), 2)
            # Use g format to avoid trailing zeros, then convert to float for JSON
            processed[key] = float(rounded)
        elif isinstance(value, float):
            # Round to 2 decimal places
            rounded = round(value, 2)
            processed[key] = rounded
        elif isinstance(value, (date, datetime)):
            # Keep datetime objects as-is
            processed[key] = value
        else:
            processed[key] = value
    return processed

def compare_versions(version1: str, version2: str) -> int:
    """
    Compare two version strings.
    Returns:
        -1 if version1 < version2
         0 if version1 == version2
         1 if version1 > version2
    """
    if not version1:
        version1 = "1.0.0"
    if not version2:
        version2 = "1.0.0"
    
    v1_parts = [int(x) for x in version1.split('.')]
    v2_parts = [int(x) for x in version2.split('.')]
    
    # Pad shorter version with zeros
    while len(v1_parts) < len(v2_parts):
        v1_parts.append(0)
    while len(v2_parts) < len(v1_parts):
        v2_parts.append(0)
    
    for i in range(len(v1_parts)):
        if v1_parts[i] < v2_parts[i]:
            return -1
        elif v1_parts[i] > v2_parts[i]:
            return 1
    return 0


def is_version_gte(version: str, target: str) -> bool:
    """Check if version is greater than or equal to target version."""
    return compare_versions(version, target) >= 0


NEW_PIPELINE_MIN_VERSION = "4.0.0"


class AttributeValidationError(Exception):
    """Custom exception for attribute validation errors."""
    def __init__(self, errors: List[str]):
        self.errors = errors
        super().__init__(f"Validation failed: {'; '.join(errors)}")


class AttributeValidator:
    """Validates update attributes against entity attribute definitions."""
    
    # Mapping of common Spark/SQL types to Python validation
    TYPE_VALIDATORS = {
        'string': lambda v: isinstance(v, str),
        'str': lambda v: isinstance(v, str),
        'varchar': lambda v: isinstance(v, str),
        'text': lambda v: isinstance(v, str),
        'int': lambda v: AttributeValidator._is_int(v),
        'integer': lambda v: AttributeValidator._is_int(v),
        'bigint': lambda v: AttributeValidator._is_int(v),
        'smallint': lambda v: AttributeValidator._is_int(v),
        'tinyint': lambda v: AttributeValidator._is_int(v),
        'long': lambda v: AttributeValidator._is_int(v),
        'float': lambda v: AttributeValidator._is_numeric(v),
        'double': lambda v: AttributeValidator._is_numeric(v),
        'decimal': lambda v: AttributeValidator._is_numeric(v),
        'numeric': lambda v: AttributeValidator._is_numeric(v),
        'boolean': lambda v: AttributeValidator._is_boolean(v),
        'bool': lambda v: AttributeValidator._is_boolean(v),
        'date': lambda v: AttributeValidator._is_date(v),
        'timestamp': lambda v: AttributeValidator._is_timestamp(v),
        'datetime': lambda v: AttributeValidator._is_timestamp(v),
    }
    
    @staticmethod
    def _is_int(value: Any) -> bool:
        """Check if value can be converted to int."""
        if isinstance(value, bool):
            return False
        if isinstance(value, int):
            return True
        if isinstance(value, str):
            try:
                int(value)
                return True
            except ValueError:
                return False
        return False
    
    @staticmethod
    def _is_numeric(value: Any) -> bool:
        """Check if value can be converted to float."""
        if isinstance(value, bool):
            return False
        if isinstance(value, (int, float)):
            return True
        if isinstance(value, str):
            try:
                float(value)
                return True
            except ValueError:
                return False
        return False
    
    @staticmethod
    def _is_boolean(value: Any) -> bool:
        """Check if value is a valid boolean representation."""
        if isinstance(value, bool):
            return True
        if isinstance(value, str):
            return value.lower() in ('true', 'false', '1', '0', 'yes', 'no')
        if isinstance(value, int):
            return value in (0, 1)
        return False
    
    @staticmethod
    def _is_date(value: Any) -> bool:
        """Check if value is a valid date string."""
        if isinstance(value, str):
            # Common date formats
            date_patterns = [
                r'^\d{4}-\d{2}-\d{2}$',  # YYYY-MM-DD
                r'^\d{2}/\d{2}/\d{4}$',  # MM/DD/YYYY
                r'^\d{2}-\d{2}-\d{4}$',  # DD-MM-YYYY
            ]
            for pattern in date_patterns:
                if re.match(pattern, value):
                    return True
        return False
    
    @staticmethod
    def _is_timestamp(value: Any) -> bool:
        """Check if value is a valid timestamp string."""
        if isinstance(value, str):
            # Common timestamp formats
            timestamp_patterns = [
                r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}',  # ISO format
                r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}',  # YYYY-MM-DD HH:MM:SS
            ]
            for pattern in timestamp_patterns:
                if re.match(pattern, value):
                    return True
        return False
    
    @classmethod
    def validate(
        cls,
        update_attributes: Dict[str, Any],
        entity_attributes: List[Any]
    ) -> Tuple[bool, List[str]]:
        """
        Validate update attributes against entity attribute definitions.
        
        Args:
            update_attributes: Dict of attribute_name -> new_value
            entity_attributes: List of attribute objects or dicts with 'name' and 'data_type'
        
        Returns:
            Tuple of (is_valid, list_of_error_messages)
        """
        errors = []
        
        # Build lookup dict for entity attributes
        attr_definitions = {}
        for attr in entity_attributes:
            # Handle both dict and object types
            if isinstance(attr, dict):
                name = attr.get('name') or attr.get('column_name')
                data_type = attr.get('data_type') or attr.get('type') or 'string'
            else:
                # Handle attribute objects
                name = getattr(attr, 'name', None) or getattr(attr, 'column_name', None)
                data_type = getattr(attr, 'data_type', None) or getattr(attr, 'type', None) or 'string'
            
            if name:
                attr_definitions[name] = data_type.lower() if data_type else 'string'
        
        # Validate each update attribute
        for attr_name, attr_value in update_attributes.items():
            # Check if attribute exists in entity definition
            if attr_name not in attr_definitions:
                errors.append(f"Unknown attribute '{attr_name}'. Valid attributes: {list(attr_definitions.keys())}")
                continue
            
            # Skip null/None values - they're allowed
            if attr_value is None:
                continue
            
            # Get expected type
            expected_type = attr_definitions[attr_name]
            
            # Find validator for this type
            validator = None
            for type_key, type_validator in cls.TYPE_VALIDATORS.items():
                if type_key in expected_type:
                    validator = type_validator
                    break
            
            # If no specific validator found, default to string (most permissive)
            if validator is None:
                validator = cls.TYPE_VALIDATORS['string']
            
            # Validate
            if not validator(attr_value):
                errors.append(
                    f"Invalid value for '{attr_name}': expected {expected_type}, "
                    f"got {type(attr_value).__name__} with value '{attr_value}'"
                )
        
        return (len(errors) == 0, errors)
    
    @classmethod
    def validate_or_raise(
        cls,
        update_attributes: Dict[str, Any],
        entity_attributes: List[Any]
    ) -> None:
        """Validate and raise AttributeValidationError if validation fails."""
        is_valid, errors = cls.validate(update_attributes, entity_attributes)
        if not is_valid:
            raise AttributeValidationError(errors)


class EntitySearchService:
    def __init__(self, db: Session):
        """Initializes the entityService with a database session.
        
        Args:
            db: SQLAlchemy session object.
        """
        self.db = db
        self.catalog_name = (
        self.db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == "catalog_name")
        .first().config_value )
        self.db_config_service = DBConfigPropertiesService(db=self.db)
        self.notebook_folder_path=self.db_config_service.getDBConfigProperties(key="notebook_path")

    def get_integration_hub_task_version(self, entity_id: int) -> Optional[str]:
        """
        Get the version from the Integration_Hub table for a given entity.
        Each entity can have only one integration task associated with it.
        """
        try:
            row = (
                self.db.query(Integration_Hub.version)
                .filter(Integration_Hub.entity_id == entity_id)
                .order_by(Integration_Hub.created_at.desc())
                .first()
            )
            if not row:
                app_logger.warning(f"No integration hub record found for entity_id: {entity_id}")
                return None
            version = row.version
            app_logger.info(f"Fetched integration hub version {version} for entity_id: {entity_id}")
            return version
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Unable to get entity version for entity_id {entity_id}. Reason: {message}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity version: {str(e)}"
            )
    

    def get_job_run_status(self,job_run_id:str,token:str):
        try:
            job_service = DatabricksJobManager(token)
            job_response=job_service.get_job_run_status(job_run_id)
            return job_response

        except Exception as e:
            app_logger.exception(f'Unable to create model databricks job. Reason - {str(e)}')
 
    
    def read_entity_search_profile(self,entity_id:int,warehouse_id:str,token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            columns_to_select = ["lakefusion_id"]
            for attr in entity.attributes:
                if attr.name and attr.name != "lakefusion_id" and attr.show_in_ui:
                    columns_to_select.append(attr.name)
            select_clause = ", ".join(columns_to_select)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            query=f"select {select_clause} from {self.catalog_name}.gold.{entity_name}_master_prod"
            data=sqlservice_conn.execute_dataset(query=query)
            return data

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile: {str(e)}"
            )
        finally:
            # Ensure the session is closed properly
            self.db.close()

    def read_entity_search_profile_id(self,entity_id:int,id_value:str,warehouse_id:str,token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            entity_primary="lakefusion_id"
            columns_to_select = ["lakefusion_id"]
            for attr in entity.attributes:
                if attr.name and attr.name != "lakefusion_id" and attr.show_in_ui:
                    columns_to_select.append(attr.name)
            select_clause = ", ".join(columns_to_select)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            query=f"select {select_clause} from {self.catalog_name}.gold.{entity_name}_master_prod where {entity_primary}='{id_value}' "
            data=sqlservice_conn.execute_dataset(query=query)
            if not data:
                app_logger.info(f'No data found for entity {entity_id} with {entity_primary}={id_value}')
                raise HTTPException(
                    status_code=404,
                    detail=f"No profile found for the given ID value: {id_value}"
                )
            
            if len(data) == 0:
                app_logger.info(f'Empty result set for entity {entity_id} with {entity_primary}={id_value}')
                raise HTTPException(
                    status_code=404,
                    detail=f"No profile found for the given ID value: {id_value}"
                )
            result = data[0]
            if isinstance(result, dict) and 'attributes_combined' in result:
                result.pop('attributes_combined', None)

            # Map attribute names to labels    
            entity_attribute_conn = EntityAttributeService(db=self.db)  
            for res in list(result.keys()):
                attribute_label = entity_attribute_conn.get_attributelabel_by_attributename(entity_id, res)
                if attribute_label:
                    result[attribute_label] = result.pop(res)
            
            # Ensure proper numeric precision in the result
            result = serialize_row_data(result)

            return result

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile: {str(e)}"
            )
        finally:
            # Ensure the session is closed properly
            self.db.close()

    def build_filter_clauses(self, filters, table_prefix=None):
        try:
            if isinstance(filters, str):
                if '%' in filters:
                    try:
                        import urllib.parse
                        filters = urllib.parse.unquote(filters)
                    except Exception as e:
                        app_logger.error(f"Error URL-decoding filters: {str(e)}")
                
                if filters.strip():
                    try:
                        filters = json.loads(filters)
                    except json.JSONDecodeError as e:
                        app_logger.error(f"Invalid JSON filter string: {e}")
                        return "", []
                else:
                    return "", []
                
            if not filters or not isinstance(filters, list):
                return "", []
                
            filter_clauses = []
            for i, filter_item in enumerate(filters):
                # attributeId is the actual column name; attributeName is the display label.
                # Prefer attributeId to ensure correct SQL column references.
                attribute_name = filter_item.get('attributeId') or filter_item.get('attributeName')
                operator = filter_item.get('operator')
                value = filter_item.get('value')
                conjunction = filter_item.get('conjunction', 'AND')

                if not attribute_name or not operator:
                    continue
                    
                column = f"{table_prefix}.{attribute_name}" if table_prefix else attribute_name
                
                sql_clause = ""
                
                # Text/String operators
                if operator == 'eq':  # is equal to
                    sql_clause = f"UPPER({column}) = UPPER('{value}')"
                elif operator == 'neq':  # is not equal to
                    sql_clause = f"UPPER({column}) != UPPER('{value}')"
                elif operator == 'contains':  # contains
                    sql_clause = f"UPPER({column}) LIKE UPPER('%{value}%')"
                elif operator == 'not_contains':  # does not contain
                    sql_clause = f"UPPER({column}) NOT LIKE UPPER('%{value}%')"
                elif operator == 'starts_with':  # starts with
                    sql_clause = f"UPPER({column}) LIKE UPPER('{value}%')"
                elif operator == 'ends_with':  # ends with
                    sql_clause = f"UPPER({column}) LIKE UPPER('%{value}')"
                
                # Numeric operators
                elif operator == 'gt':  # is greater than
                    sql_clause = f"{column} > {value}"
                elif operator == 'lt':  # is less than
                    sql_clause = f"{column} < {value}"
                elif operator == 'gte':  # is greater than or equal to
                    sql_clause = f"{column} >= {value}"
                elif operator == 'lte':  # is less than or equal to
                    sql_clause = f"{column} <= {value}"
                
                # Null operators
                elif operator == 'is_null':  # is null
                    sql_clause = f"{column} IS NULL"
                elif operator == 'is_not_null':  # is not null
                    sql_clause = f"{column} IS NOT NULL"
                
                # Boolean operators
                elif operator == 'eq_true':  # is true
                    sql_clause = f"{column} = TRUE"
                elif operator == 'eq_false':  # is false
                    sql_clause = f"{column} = FALSE"
                
                if sql_clause:
                    if i > 0:
                        filter_clauses.append(conjunction)
                    filter_clauses.append(sql_clause)
            
            if filter_clauses:
                return " ".join(filter_clauses), []
            return "", []
        except Exception as e:
            app_logger.error(f"Error building filter clauses: {str(e)}")
            return "", []
            
    def get_all_records(self, entity_id: int, warehouse_id: str, token: str, page: int = 1, page_size: int = 1000, filters=None):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            
            name_to_label = {}
            columns_to_select = []
            
            has_lakefusion_id = any(attr.name == "lakefusion_id" for attr in entity.attributes)
        
            if not has_lakefusion_id:
                columns_to_select.append("lakefusion_id")
            
            for attr in entity.attributes:
                if attr.name and (attr.show_in_ui or attr.is_label or attr.is_primary_key):
                    if attr.name not in columns_to_select:
                        columns_to_select.append(attr.name)
                        if attr.label:
                            name_to_label[attr.name] = attr.label
            
            if not columns_to_select:
                return {
                    "data": [],
                    "pagination": {
                        "page": page,
                        "page_size": page_size,
                        "total_count": 0,
                        "total_pages": 0
                    }
                }
            
            offset = (page - 1) * page_size

            sqlservice_conn = DataSetSQLService(token, warehouse_id)

            has_dnb = entity.dnb_integration is not None and entity.dnb_integration.is_active
            primary_key_attr = next((attr for attr in entity.attributes if attr.is_primary_key), None)

            if has_dnb and primary_key_attr:
                dnb_table = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"
                select_clause_prefixed = ", ".join([f"m.{col}" for col in columns_to_select])

                where_clause = ""
                if filters:
                    filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
                    if filter_clause:
                        where_clause = f"WHERE {filter_clause}"

                query = f"""
                    SELECT
                        {select_clause_prefixed},
                        COALESCE(d.dnb_status, 'NONE') AS dnb_status,
                        COUNT(*) OVER() AS total_count
                    FROM {self.catalog_name}.gold.{entity_name}_master_prod m
                    LEFT JOIN (
                        SELECT lakefusion_id AS dnb_lf_id,
                            CASE
                                WHEN MAX(CASE WHEN merge_status = 'ACCEPTED' THEN 1 ELSE 0 END) = 1 THEN 'ACCEPTED'
                                WHEN MAX(CASE WHEN merge_status = 'AUTO_MERGED' THEN 1 ELSE 0 END) = 1 THEN 'MATCHED'
                                WHEN MAX(CASE WHEN merge_status = 'IN_REVIEW' THEN 1 ELSE 0 END) = 1 THEN 'IN_REVIEW'
                                ELSE 'NONE'
                            END AS dnb_status
                        FROM {dnb_table}
                        GROUP BY lakefusion_id
                    ) d ON m.lakefusion_id = d.dnb_lf_id
                    {where_clause}
                    LIMIT {page_size} OFFSET {offset}
                """
            else:
                select_clause = ", ".join(columns_to_select)

                where_clause = ""
                if filters:
                    filter_clause, _ = self.build_filter_clauses(filters)
                    if filter_clause:
                        where_clause = f"WHERE {filter_clause}"

                query = f"""
                    SELECT
                        {select_clause},
                        COUNT(*) OVER() AS total_count
                    FROM {self.catalog_name}.gold.{entity_name}_master_prod
                    {where_clause}
                    LIMIT {page_size} OFFSET {offset}
                """
            
            raw_data = sqlservice_conn.execute_dataset(query=query)
            for i, record in enumerate(raw_data):
                if isinstance(record, dict):
                    raw_data[i] = serialize_row_data(record)

            total_count = raw_data[0]['total_count'] if raw_data and 'total_count' in raw_data[0] else 0
            
            if raw_data:
                for record in raw_data:
                    record_dict = dict(record) if not isinstance(record, dict) else record.copy()
                    
                    if 'total_count' in record_dict:
                        del record_dict['total_count']
            
            total_pages = math.ceil(total_count / page_size) if page_size > 0 else 0
            
            response_data = {
                "data": raw_data,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total_count": total_count,
                    "total_pages": total_pages
                }
            }
            
            return response_data

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch master records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch master records: {str(e)}"
            )
        finally:
            # Ensure the session is closed properly
            self.db.close()

    def create_not_match_tasks_and_job(self,parameters):
        try:
            job_parameters_list = [i for i in parameters]
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Match_Merge",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Manual Not A Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Manual Not A Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Potential Match Table",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
        
    def create_not_match_tasks_and_job_updated(self,parameters):
        try:
            job_parameters_list = [i for i in parameters]
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Not_Match",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Manual_Not_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Manual_Not_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )

    def create_match_merge_tasks_and_job(self,parameters):
        try:
            
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            
            job_parameters_list = [i for i in parameters]
            
            
            
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Match_Merge",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Manual Merge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Manual Merge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Potential Match Table",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create task: {str(e)}"
            )
        
    def create_match_merge_tasks_and_job_updated(self,parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}
           
            job_parameters_list = [i for i in parameters]
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Manual_Merge",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Manual_Merge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Manual_Merge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Manual_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Manual_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create task: {str(e)}"
            )

    def create_match_merge_tasks_and_job_dnbintegration(self,parameters):
        try:
            dbx_cloud=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "dbx_cloud").first().config_value)
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            if(dbx_cloud=='azure'):
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                cluster_name="",
                spark_version="16.0.x-cpu-ml-scala2.12",
                azure_attributes=AzureAttributes(
                    first_on_demand=1
                ),  # Corrected Azure Attributes
                node_type_id="Standard_DS12_v2",
                driver_node_type_id="Standard_DS12_v2",  # Correct Azure instance type
                spark_env_vars={
                    "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                },
                enable_elastic_disk=False,
                data_security_mode=DataSecurityMode.SINGLE_USER,
                runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                autoscale=AutoScale(
                    min_workers=1,  # Updated worker count
                    max_workers=1   # Updated worker count
                ),
                custom_tags=tags  # Add custom tags
                ))
            else:
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    aws_attributes=AwsAttributes(
                        first_on_demand=1,
                        availability=AwsAvailability.SPOT_WITH_FALLBACK,
                        zone_id="us-west-2d",
                        spot_bid_price_percent=100,
                        ebs_volume_count=0
                    ),
                    node_type_id="r5d.4xlarge",  # Updated instance type
                    spark_env_vars={
                        "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                    },
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                    autoscale=AutoScale(
                        min_workers=2,  # Updated worker count
                        max_workers=4   # Updated worker count
                    ),
                    custom_tags=tags  # Add custom tags
                    ))
            tasks_list = [
            SubmitTask(
                task_key="Entity_Match_Merge",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/dnb_integration/Manual Merge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('dnb_integration', self.db)}/Manual Merge",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
    
    def run_match_merge(self,entity_id:int,potential_record,token,created_by):
        try:
            job_parameters=[{"entity_id": str(entity_id),"experiment_id": str('prod') , "catalog_name":self.catalog_name },{"catalog_name":self.catalog_name,"experiment_id":str('prod'),"master_id":str(potential_record.master_id),"unified_dataset_ids": json.dumps([{"id": i.id,"dataset_id": i.dataset_id} for i in potential_record.unified_dataset_ids])}]
            if(potential_record.operation_type in ['MERGE','MERGE_ALL']):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_match_merge_tasks_and_job(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_MERGE",task_list_response)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status='prepare',
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
            elif(potential_record.operation_type=='NOT_A_MATCH'):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_not_match_tasks_and_job(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_Not_A_Match",task_list_response)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type='NOT_A_MATCH',
                        job_run_id=job_create_response.run_id,
                        status='prepare',
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
        
    def run_match_merge_updated(self,entity_id:int,potential_record,token,created_by):
        try:
            job_parameters=[{"entity_id": str(entity_id),"experiment_id": str('prod') , "catalog_name":self.catalog_name },{"catalog_name":self.catalog_name,"experiment_id":str('prod'),"master_id":str(potential_record.master_id),"unified_dataset_ids": json.dumps([{"id": i.id,"dataset_id": i.dataset_id} for i in potential_record.unified_dataset_ids])}]
            if(potential_record.operation_type in ['MERGE','MERGE_ALL']):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_match_merge_tasks_and_job_updated(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_MERGE",task_list_response)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status='prepare',
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
            elif(potential_record.operation_type=='NOT_A_MATCH'):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_not_match_tasks_and_job_updated(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_Not_A_Match",task_list_response)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type='NOT_A_MATCH',
                        job_run_id=job_create_response.run_id,
                        status='prepare',
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )

    def run_match_merge_dnbintegration(self,entity_id:int,potential_record,token,created_by):
        try:
            entity_conn = EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            unified_ids = [str(i.id) for i in potential_record.unified_dataset_ids]
            dnb_duns_value=unified_ids[0]
            job_parameters = {
                    "entity_name":entity_name,
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "id_value": str(potential_record.master_id),
                    "dnb_duns_value": dnb_duns_value
                }
            if(potential_record.operation_type in ['MERGE']):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_match_merge_tasks_and_job_dnbintegration(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_Match_Merge_DNB",task_list_response)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=potential_record.master_id,
                    profile_id=dnb_duns_value,
                    operation_type="MERGE",
                    job_run_id=job_create_response.run_id,
                    status='prepare',
                    job_run_status=job_run_response,
                    created_by=created_by)
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs        
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )

    def accept_dnb_candidate(self, entity_id, master_id, dnb_duns_value, warehouse_id, token):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            dnb_table = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"

            query = f"""
                UPDATE {dnb_table}
                SET merge_status = CASE
                    WHEN dnb_duns = '{dnb_duns_value}' THEN 'ACCEPTED'
                    ELSE 'REJECTED'
                END
                WHERE lakefusion_id = '{master_id}' AND merge_status = 'IN_REVIEW'
            """
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            sqlservice_conn.execute_insert_query(query=query)
            return {"message": "D&B candidate accepted successfully"}
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to accept D&B candidate. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to accept D&B candidate: {str(e)}"
            )

    def reject_all_dnb_candidates(self, entity_id, master_id, warehouse_id, token):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            dnb_table = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"

            query = f"""
                UPDATE {dnb_table}
                SET merge_status = 'REJECTED'
                WHERE lakefusion_id = '{master_id}' AND merge_status = 'IN_REVIEW'
            """
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            sqlservice_conn.execute_insert_query(query=query)
            return {"message": "All D&B candidates rejected successfully"}
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to reject D&B candidates. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to reject D&B candidates: {str(e)}"
            )

    def create_match_merge_tasks_and_job_deduplication(self, parameters):
        try:
            
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Match_Merge_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Manual Merge",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )
            ]
            return tasks_list
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
    
    def create_not_match_tasks_and_job_deduplication(self, parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Not_Match_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Manual Not A Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )

    def create_match_merge_tasks_and_job_deduplication_updated(self, parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Merge_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Manual_Merge",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Manual_Merge",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Potential_Match_Table",
                    #new_cluster=job_cluster.new_cluster,
                    depends_on=[TaskDependency(task_key="Entity_Merge_Deduplication")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Process_Potential_Match",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Potential_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Potential_Match_Normal",
                    #new_cluster=job_cluster.new_cluster,
                    depends_on=[TaskDependency(task_key="Entity_Merge_Deduplication")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_CrossWalk",
                    #new_cluster=job_cluster.new_cluster,
                    depends_on=[TaskDependency(task_key="Entity_Merge_Deduplication")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Normal"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
    
    def create_not_match_tasks_and_job_deduplication_updated(self, parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}   
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Not_Match_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Manual_Not_Match",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Manual_Not_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table"),TaskDependency(task_key="Process_CrossWalk")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )

    def run_match_merge_deduplication(self, entity_id: int, potential_record, token, created_by):
        try:
            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str(potential_record.operation_type),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type in ['MERGE', 'MERGE_ALL']:
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status='prepare',
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
            elif potential_record.operation_type == 'NOT_A_MATCH':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_not_match_tasks_and_job_deduplication(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_Not_A_Match", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type="NOT_A_MATCH",
                        job_run_id=job_create_response.run_id,
                        status='prepare',
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
        
    def run_match_merge_deduplication_updated(self, entity_id: int, potential_record, token, created_by):
        try:
            if potential_record.operation_type in ['MERGE','MERGE_ALL']:
                operation_type='MASTER_MANUAL_MERGE'
            else:
                operation_type='MANUAL_NOT_A_MATCH'


            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str(operation_type),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type in ['MERGE', 'MERGE_ALL']:
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication_updated(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status='prepare',
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
            elif potential_record.operation_type == 'NOT_A_MATCH':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_not_match_tasks_and_job_deduplication_updated(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_Not_A_Match", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type="NOT_A_MATCH",
                        job_run_id=job_create_response.run_id,
                        status='prepare',
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
        

    def run_force_merge_deduplication(self, entity_id: int, potential_record, token, created_by):
        try:
            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str('MASTER_FORCE_MERGE'),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type=='FORCE_MERGE':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status='prepare',
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
           
                
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to force merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
        
    def run_force_merge_deduplication_updated(self, entity_id: int, potential_record, token, created_by):
        try:
            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str('MASTER_FORCE_MERGE'),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type=='FORCE_MERGE':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication_updated(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status='prepare',
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to force merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
    def create_unmerge_tasks_and_job(self, parameters):
        try:
            dbx_cloud=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "dbx_cloud").first().config_value)
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            if(dbx_cloud=='azure'):
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                cluster_name="",
                spark_version="16.0.x-cpu-ml-scala2.12",
                azure_attributes=AzureAttributes(
                    first_on_demand=1
                ),  # Corrected Azure Attributes
                node_type_id="Standard_DS12_v2",
                driver_node_type_id="Standard_DS12_v2",  # Correct Azure instance type
                spark_env_vars={
                    "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                },
                enable_elastic_disk=False,
                data_security_mode=DataSecurityMode.SINGLE_USER,
                runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                autoscale=AutoScale(
                    min_workers=1,  # Updated worker count
                    max_workers=1   # Updated worker count
                ),
                custom_tags=tags  # Add custom tags
                ))
            else:
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    aws_attributes=AwsAttributes(
                        first_on_demand=1,
                        availability=AwsAvailability.SPOT_WITH_FALLBACK,
                        zone_id="us-west-2d",
                        spot_bid_price_percent=100,
                        ebs_volume_count=0
                    ),
                    node_type_id="r5d.4xlarge",  # Updated instance type
                    spark_env_vars={
                        "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                    },
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                    autoscale=AutoScale(
                        min_workers=2,  # Updated worker count
                        max_workers=4   # Updated worker count
                    ),
                    custom_tags=tags  # Add custom tags
                    ))
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Unmerge",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Manual Unmerge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Manual Unmerge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Potential Match Table",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create unmerge tasks. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create unmerge tasks: {str(e)}"
            )

    def create_unmerge_tasks_and_job_updated(self, parameters):
        try:

            tags = get_resource_tags()
            if tags is None:
                tags = {}

            job_parameters_list = [i for i in parameters]

            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Unmerge",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Manual_Unmerge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Manual_Unmerge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create unmerge tasks. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create unmerge tasks: {str(e)}"
            )

    def run_unmerge(self, entity_id: int, unmerge_record, token, created_by):
        try:
            job_parameters=[
                {"entity_id": str(entity_id), "experiment_id": str('prod'), "catalog_name": self.catalog_name},
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "master_id": str(unmerge_record.master_id),
                    "unified_dataset_ids": json.dumps([{"id": i.id, "dataset_id": i.dataset_id} for i in unmerge_record.unified_dataset_ids])
                }
            ]
            
            job_service = DatabricksJobManager(token)
            task_list_response = self.create_unmerge_tasks_and_job(job_parameters)
            job_create_response = job_service.create_and_submit_job("Entity_UNMERGE", task_list_response)
            job_run_response = job_service.get_job_run_status(job_create_response.run_id)
            
            entity_search_jobs_list = []
            for i in unmerge_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=unmerge_record.master_id,
                    profile_id=i.id,
                    operation_type='UNMERGE',
                    job_run_id=job_create_response.run_id,
                    status='prepare',
                    job_run_status=job_run_response,
                    created_by=created_by)
                self.db.add(entity_search_jobs)
                entity_search_jobs_list.append(entity_search_jobs)
                
            self.db.commit()
            for job in entity_search_jobs_list:
                self.db.refresh(job)
                
            return entity_search_jobs_list[0] if entity_search_jobs_list else None
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to unmerge. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to unmerge records: {str(e)}"
            )
        
    def run_unmerge_updated(self, entity_id: int, unmerge_record, token, created_by):
        try:
            job_parameters=[
                {"entity_id": str(entity_id), "experiment_id": str('prod'), "catalog_name": self.catalog_name},
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "master_id": str(unmerge_record.master_id),
                    "unified_dataset_ids": json.dumps([{"id": i.id, "dataset_id": i.dataset_id} for i in unmerge_record.unified_dataset_ids])
                }
            ]
            
            job_service = DatabricksJobManager(token)
            task_list_response = self.create_unmerge_tasks_and_job_updated(job_parameters)
            job_create_response = job_service.create_and_submit_job("Entity_UNMERGE", task_list_response)
            job_run_response = job_service.get_job_run_status(job_create_response.run_id)
            
            entity_search_jobs_list = []
            for i in unmerge_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=unmerge_record.master_id,
                    profile_id=i.id,
                    operation_type='UNMERGE',
                    job_run_id=job_create_response.run_id,
                    status='prepare',
                    job_run_status=job_run_response,
                    created_by=created_by)
                self.db.add(entity_search_jobs)
                entity_search_jobs_list.append(entity_search_jobs)
                
            self.db.commit()
            for job in entity_search_jobs_list:
                self.db.refresh(job)
                
            return entity_search_jobs_list[0] if entity_search_jobs_list else None
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to unmerge. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to unmerge records: {str(e)}"
            )

    def create_tasks_and_job(self, parameters):
        """Legacy job creation for update profile (versions < 4.0.0)."""
        dbx_cloud = (self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "dbx_cloud").first().config_value)
        tags = get_resource_tags()
        if tags is None:
            tags = {}
        if dbx_cloud == 'azure':
            job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    azure_attributes=AzureAttributes(first_on_demand=1),
                    node_type_id="Standard_DS12_v2",
                    driver_node_type_id="Standard_DS12_v2",
                    spark_env_vars={"PYSPARK_PYTHON": "/databricks/python3/bin/python3"},
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,
                    autoscale=AutoScale(min_workers=1, max_workers=1),
                    custom_tags=tags
                )
            )
        else:
            job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    aws_attributes=AwsAttributes(
                        first_on_demand=1,
                        availability=AwsAvailability.SPOT_WITH_FALLBACK,
                        zone_id="us-west-2d",
                        spot_bid_price_percent=100,
                        ebs_volume_count=0
                    ),
                    node_type_id="r5d.4xlarge",
                    spark_env_vars={"PYSPARK_PYTHON": "/databricks/python3/bin/python3"},
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,
                    autoscale=AutoScale(min_workers=2, max_workers=4),
                    custom_tags=tags
                )
            )

        if len(parameters) == 1:
            tasks_list = [
                Task(
                    task_key="UpdateEntityDnBIntegration",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Update Entity Search Profile",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Update Entity Search Profile",
                        base_parameters={"query_1": str(parameters[0])},
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                )
            ]
        else:
            tasks_list = [
                Task(
                    task_key="UpdateEntityProfile",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Update Entity Search Profile",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Update Entity Search Profile",
                        base_parameters={
                            "query_1": str(parameters[0]),
                            "query_2": str(parameters[1]),
                            "query_3": str(parameters[2])
                        },
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                )
            ]

        return [tasks_list, job_cluster]
    
    def _create_manual_update_job_config(self, notebook_params: dict):
        """
        Create the job configuration for the v4.0.0+ Manual_Update notebook.
        Uses serverless compute (no cluster specification).
        """
        tasks_list = [
             SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
             SubmitTask(
                task_key="ManualUpdateProfile",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Manual_Update",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Manual_Update",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
             SubmitTask(
                task_key="Process_Warning_Records",
                depends_on=[TaskDependency(task_key="ManualUpdateProfile")],
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Warning Records",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Warning Records",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_Warning_Records")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
        ]

        return tasks_list
    
    def _process_attribute_updates(self, latest_attributes_result, attributes_values, source):
        """Process attribute updates using NumPy for better performance"""
        import numpy as np
        import json
        
        existing_attributes = []
        try:
            if (latest_attributes_result is not None and 
                len(latest_attributes_result) > 0):
                
                if not isinstance(latest_attributes_result, np.ndarray):
                    result_array = np.array(latest_attributes_result)
                else:
                    result_array = latest_attributes_result
                
                if (result_array.size > 0 and 
                    isinstance(result_array[0], dict) and
                    'attribute_source_mapping' in result_array[0] and 
                    result_array[0]['attribute_source_mapping'] is not None):
                    
                    existing_attributes = result_array[0]['attribute_source_mapping']
                    
                    if isinstance(existing_attributes, str):
                        try:
                            existing_attributes = json.loads(existing_attributes)
                        except:
                            existing_attributes = []
                    elif isinstance(existing_attributes, np.ndarray):
                        existing_attributes = existing_attributes.tolist()
                    elif not isinstance(existing_attributes, list):
                        existing_attributes = []
                        
        except (TypeError, IndexError, KeyError, ValueError) as e:
            print(f"Debug: Error processing attributes: {e}")
            existing_attributes = []
        
        attributes_dict = {}
        
        if isinstance(existing_attributes, list):
            for attr in existing_attributes:
                if isinstance(attr, dict) and attr.get('attribute_name'):
                    attr_name = attr.get('attribute_name')
                    attributes_dict[attr_name] = {
                        'attribute_name': attr_name,
                        'attribute_value': attr.get('attribute_value', ''),
                        'source': attr.get('source', source)
                    }
        
        for key, value in attributes_values.items():
            safe_value = str(value) if value is not None else ''
            attributes_dict[key] = {
                'attribute_name': key,
                'attribute_value': safe_value,
                'source': 'MANUAL_UPDATE'
            }
        
        final_attributes = list(attributes_dict.values())
        
        return final_attributes

    def _convert_attributes_to_sql_array(self, attribute_values):
        """Convert Python attribute list to SQL array format"""
        
        if not attribute_values:
            return "array()"
        
        attribute_structs = []
        for attr in attribute_values:
            safe_name = str(attr['attribute_name']).replace("'", "''")
            safe_value = str(attr['attribute_value']).replace("'", "''")
            safe_source = str(attr['source']).replace("'", "''")
            
            struct = f"named_struct('attribute_name', '{safe_name}', 'attribute_value', '{safe_value}', 'source', '{safe_source}')"
            attribute_structs.append(struct)
        
        return f"array({', '.join(attribute_structs)})"
    
    def _get_entity_attributes_with_types(self, entity) -> List[Any]:
        """
        Extract entity attributes with their data types from the entity model.
        Returns the list of attribute objects or dicts.
        """
        if hasattr(entity, 'attributes') and entity.attributes:
            return entity.attributes
        return []

    def _update_profile_v4(
        self,
        entity_name: str,
        entity_id:int,
        id_value: str,
        update_attributes: dict,
        entity_attributes: List[str],
        token: str,
        created_by
    ):
        """
        New v4.0.0+ update flow using Manual_Update notebook.
        All logic is handled in the notebook. Uses serverless compute.
        """
        # Prepare parameters for the notebook
        notebook_params = {
            "catalog_name": self.catalog_name,
            "entity_name": entity_name,
            "entity_id": entity_id,
            "lakefusion_id": id_value,
            "update_attributes": json.dumps(update_attributes),
            "entity_attributes": json.dumps(entity_attributes)
        }
        
        app_logger.info(f"Triggering Manual_Update job (v4.0.0+) with params: {notebook_params}")
        
        # Create and run the job using serverless (same pattern as other methods)
        job_service = DatabricksJobManager(token)
        tasks_list = self._create_manual_update_job_config(notebook_params)
        
        # Use create_and_submit_job (serverless) instead of create_job + run_job
        job_create_response = job_service.create_and_submit_job(
            f"Manual_Update_Profile-{entity_name}-{id_value[:8]}",
            tasks_list
        )
        
        job_run_response = job_service.get_job_run_status(job_create_response.run_id)
        entity_update_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=id_value,
                    profile_id=id_value,
                    operation_type='MANUAL_UPDATE',
                    job_run_id=job_create_response.run_id,
                    status='prepare',
                    job_run_status=job_run_response,
                    created_by=created_by)
        self.db.add(entity_update_jobs)
        self.db.commit()
        self.db.refresh(entity_update_jobs)
        
        app_logger.info(f"Manual_Update job triggered successfully: run_id={job_create_response.run_id}")
        return job_run_response

    def _update_profile_legacy(
        self,
        entity_name: str,
        id_value: str,
        update_attributes: dict,
        warehouse_id: str,
        token: str,
        entity
    ):
        """
        Legacy update flow for versions < 4.0.0.
        Uses the old query-based approach.
        """
        source = entity.path
        entity_primary = "lakefusion_id"
        
        get_attributes_and_version_query = f"""
        with global_max as (
            select coalesce(max(version), 0) as global_max_version
            from {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources
        ),
        latest_attrs as (
            select 
                version,
                attribute_source_mapping
            from {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources 
            where {entity_primary}='{id_value}'
            order by version desc
            limit 1
        )
        select 
            coalesce(la.version, 0) as record_version,
            la.attribute_source_mapping,
            gm.global_max_version
        from global_max gm
        left join latest_attrs la on 1=1
        """
        
        sqlservice_conn = DataSetSQLService(token, warehouse_id)
        combined_result = sqlservice_conn.execute_dataset(get_attributes_and_version_query)
        
        global_max_version = combined_result[0]['global_max_version'] if combined_result else 0
        next_version = global_max_version + 1
        
        attributes_data = [{
            'attribute_source_mapping': combined_result[0]['attribute_source_mapping'] if combined_result else None
        }] if combined_result else []
        
        new_attribute_values = self._process_attribute_updates(
            attributes_data, 
            update_attributes, 
            source
        )
        
        attribute_values_sql = self._convert_attributes_to_sql_array(new_attribute_values)
        
        update_query = ", ".join([f"{k} = '{v}'" for k, v in update_attributes.items()])
        query_1 = f"update {self.catalog_name}.gold.{entity_name}_master_prod set {update_query} where {entity_primary}='{id_value}'"

        query_2 = f"""
        insert into {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources 
        values (
            '{id_value}',
            {next_version},
            {attribute_values_sql}
        )
        """
        
        query_3 = f"""
        insert into {self.catalog_name}.gold.{entity_name}_master_prod_merge_activities 
        values (
            '{id_value}',
            Null,
            'MANUAL_UPDATE',
            {next_version},
            'MANUAL_UPDATE'
        )
        """

        parameters = [query_1, query_2, query_3]
        job_service = DatabricksJobManager(token)
        task_job = self.create_tasks_and_job(parameters)
        job_create_response = job_service.create_job(
            f"Update_Profile-{entity_name}",
            job_clusters=task_job[1],
            tasks_list=task_job[0]
        )
        job_response = job_service.run_job(job_create_response)
        return job_response
        
    def update_entity_search_profile(self, entity_id, id_value: str, attributes_values, warehouse_id, token,created_by):
        """
        Update an entity profile with version-based routing.
        
        For v4.0.0+: Routes to new Manual_Update notebook
        For < v4.0.0: Routes to legacy query-based flow
        
        Includes pre-flight validation of attributes before starting any job.
        """
        try:
            # Get entity information
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            
            # Get version from Integration_Hub table instead of entity table
            entity_version = self.get_integration_hub_task_version(entity_id) or "1.0.0"
            
            # Get entity attributes (for validation and passing to notebook)
            entity_attributes = self._get_entity_attributes_with_types(entity)
            entity_attribute_names = []
            for attr in entity_attributes:
                if isinstance(attr, dict):
                    name = attr.get('name') or attr.get('column_name')
                else:
                    name = getattr(attr, 'name', None) or getattr(attr, 'column_name', None)
                if name and name != 'attributes_combined':
                    entity_attribute_names.append(name)
            
            app_logger.info(
                f"Processing update for entity '{entity_name}' (version {entity_version}), "
                f"lakefusion_id '{id_value}'"
            )
            
            # ===== VALIDATION =====
            # Validate attributes before starting any job
            try:
                AttributeValidator.validate_or_raise(attributes_values, entity_attributes)
                app_logger.info("✓ Attribute validation passed")
            except AttributeValidationError as e:
                app_logger.warning(f"Attribute validation failed: {e.errors}")
                raise HTTPException(
                    status_code=400,
                    detail={
                        "error": "Validation failed",
                        "messages": e.errors
                    }
                )
            
            # ===== VERSION-BASED ROUTING =====
            if is_version_gte(entity_version, NEW_PIPELINE_MIN_VERSION):
                # New v4.0.0+ flow
                app_logger.info(f"Using NEW pipeline flow (version {entity_version} >= {NEW_PIPELINE_MIN_VERSION})")
                return self._update_profile_v4(
                    entity_name=entity_name,
                    entity_id=entity_id,
                    id_value=id_value,
                    update_attributes=attributes_values,
                    entity_attributes=entity_attribute_names,
                    token=token,
                    created_by=created_by
                )
            else:
                # Legacy flow
                app_logger.info(f"Using LEGACY pipeline flow (version {entity_version} < {NEW_PIPELINE_MIN_VERSION})")
                return self._update_profile_legacy(
                    entity_name=entity_name,
                    id_value=id_value,
                    update_attributes=attributes_values,
                    warehouse_id=warehouse_id,
                    token=token,
                    entity=entity
                )
             
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update entity gold table: {str(e)}"
            )
    
    def get_merge_statuses(self, entity_id: int, master_id: str) -> List[dict]:
        """
        Get all merge operation statuses for a given master_id.
        
        Args:
            entity_id: The entity ID
            master_id: The master record ID to check statuses for
        
        Returns:
            List of status objects containing profile_id and status
        """
        try:
            results = self.db.query(Model_Databricks_Entity_Search_Job).filter(
                and_(
                    Model_Databricks_Entity_Search_Job.entity_id == entity_id,
                    Model_Databricks_Entity_Search_Job.master_id == master_id
                )
            ).order_by(Model_Databricks_Entity_Search_Job.created_at.desc()).all()
            
            # Group by profile_id and get latest status
            status_map = {}
            for result in results:
                if result.profile_id not in status_map:
                    status_map[result.profile_id] = {
                        "profile_id": result.profile_id,
                        "status": result.status,
                        "operation_type": result.operation_type,
                        "created_at": result.created_at.isoformat()
                    }
            
            return list(status_map.values())
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch merge statuses for master_id {master_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed fetching merge statuses: {str(e)}")
        
    def get_force_merge_status(self, entity_id: int, master_id: str, match_id: str) -> list[dict]:
        """Retrieves latest force merge job status from the database."""
        try:
            result = (
                self.db.query(Model_Databricks_Entity_Search_Job)
                .filter(
                    Model_Databricks_Entity_Search_Job.entity_id == entity_id,
                    Model_Databricks_Entity_Search_Job.operation_type == "FORCE_MERGE",
                    or_(
                        or_(
                            Model_Databricks_Entity_Search_Job.master_id == master_id,
                            Model_Databricks_Entity_Search_Job.profile_id == match_id,
                        ),
                        or_(
                            Model_Databricks_Entity_Search_Job.master_id == match_id,
                            Model_Databricks_Entity_Search_Job.profile_id == master_id,
                        ),
                    ),
                )
                .order_by(Model_Databricks_Entity_Search_Job.created_at.desc())
                .first()
            )

            if result is None:
                return []

            return [{
                "master_id": result.master_id,
                "profile_id": result.profile_id,
                "status": result.status,
                "job_run_id": result.job_run_id,
                "job_run_status": result.job_run_status,
                "created_at": result.created_at.isoformat(),
            }]

        except Exception as e:
            app_logger.exception("Unable to fetch force merge status")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch force merge status: {str(e)}",
            )
        
    def read_entity_search_profile_validation_id(self,entity_id:int,id_value:str,warehouse_id:str,validation_type:str,token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            
            entity_primary="lakefusion_id"
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            if(validation_type=='error'):
               query=f"""WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'gold'
      AND table_name = '{entity_name}_master_validation_error_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)
SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.gold.{entity_name}_unified_prod p' ||
  ' LEFT JOIN {self.catalog_name}.gold.{entity_name}_unified_validation_error_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN 
      ' WHERE p.{entity_primary} = ''{id_value}'' AND ' || where_conditions
    ELSE ' WHERE p.{entity_primary} = ''{id_value}'' '
  END AS generated_query
FROM validation_columns;"""
            else:
                query=f"""WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'silver'
      AND table_name = '{entity_name}_unified_validation_warning_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)
SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.silver.{entity_name}_unified_prod p' ||
  ' LEFT JOIN {self.catalog_name}.silver.{entity_name}_unified_validation_warning_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN 
      ' WHERE p.{entity_primary} = ''{id_value}'' AND ' || where_conditions
    ELSE ' WHERE p.{entity_primary} = ''{id_value}'' '
  END AS generated_query
FROM validation_columns;"""
            data=sqlservice_conn.execute_dataset(query=query)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            data=sqlservice_conn.execute_dataset(query=data[0]['generated_query'])
            return [serialize_row_data(row) for row in data]

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile with validation records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile with validation records: {str(e)}"
            )

    def read_entity_search_profile_validation(self,entity_id:int,warehouse_id:str,validation_type:str,token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            #entity_name='Patients'
            entity_primary="lakefusion_id"
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            if(validation_type=='error'):
               query=f"""WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'gold'
      AND table_name = '{entity_name}_master_validation_error_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)

SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.gold.{entity_name}_master_prod p' ||
  ' LEFT JOIN {self.catalog_name}.gold.{entity_name}_master_validation_error_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN ' WHERE ' || where_conditions
    ELSE ''
  END AS generated_query
FROM validation_columns;"""
            else:
                query=f"""
WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'silver'
      AND table_name = '{entity_name}_unified_validation_warning_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)

SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.silver.{entity_name}_unified_prod p' ||
  ' LEFT JOIN {self.catalog_name}.silver.{entity_name}_unified_validation_warning_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN ' WHERE ' || where_conditions
    ELSE ''
  END AS generated_query
FROM validation_columns;"""
            data=sqlservice_conn.execute_dataset(query=query)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            return_data=sqlservice_conn.execute_dataset(query=data[0]['generated_query'])
            return [serialize_row_data(row) for row in return_data]

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile with validation records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile with validation records: {str(e)}"
            )

    def get_attribute_sources(self, entity_id: int, profile_id: str, warehouse_id: str, token: str):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            entity_primary = "lakefusion_id"
            hidden_attrs = {attr.name for attr in entity.attributes if attr.name and not attr.show_in_ui}
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            query = f"select * from {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources where {entity_primary}='{profile_id}'"
            data = sqlservice_conn.execute_dataset(query=query)

            def convert_to_string(value):
                if value is None:
                    return ""
                if isinstance(value, (int, float, bool)):
                    return str(value)
                if isinstance(value, (list, dict)):
                    return json.dumps(value)
                return str(value)

            # Convert the data to a list of dictionaries with string values
            if data:
                formatted_data = []
                for row in data:
                    if hasattr(row, '_asdict'):
                        # Handle named tuples
                        row_dict = row._asdict()
                    elif hasattr(row, '__dict__'):
                        # Handle objects
                        row_dict = row.__dict__
                    elif isinstance(row, dict):
                        row_dict = row
                    else:
                        # Handle tuples/lists
                        columns = [col[0] if isinstance(col, tuple) else col for col in data[0]._fields] if hasattr(data[0], '_fields') else data[0].keys()
                        row_dict = dict(zip(columns, row))
                    
                    # Convert all values to strings, excluding hidden attributes
                    formatted_row = {key: convert_to_string(value) for key, value in row_dict.items() if key not in hidden_attrs}
                    formatted_data.append(formatted_row)
                
                return formatted_data
            
            return []

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch profile sources. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch profile sources: {str(e)}"
            )

    def get_merge_activities(self, entity_id: int, profile_id: str, warehouse_id: str, token: str):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)

            entity_name = entity.name.lower().replace(' ', '_')
            entity_primary = "lakefusion_id"
            table_name = f"{entity_name}_master_prod_merge_activities"

            # ---------- 1st Connection (check columns) ----------
            sqlservice_conn = DataSetSQLService(token, warehouse_id)

            column_check_query = f"""
                SELECT column_name
                FROM {self.catalog_name}.information_schema.columns
                WHERE table_schema = 'gold'
                AND table_name = '{table_name}'
                AND column_name IN ('master_{entity_primary}', 'master_id');
            """

            cols = sqlservice_conn.execute_dataset(query=column_check_query)
            col_names = set()
            for row in cols or []:
                if isinstance(row, dict):
                    col_names.add(row.get("column_name") or row.get("COLUMN_NAME"))
                else:
                    col_names.add(row[0])

            if f"master_{entity_primary}" in col_names:
                master_col = f"master_{entity_primary}"
            elif "master_id" in col_names:
                master_col = "master_id"
            else:
                raise Exception(f"No valid master column found in table {table_name}")
            
            print("master col", master_col)

            # ---------- 2nd Connection (main data query) ----------
            sqlservice_conn = DataSetSQLService(token, warehouse_id)

            query = f"""
                SELECT *
                FROM {self.catalog_name}.gold.{table_name}
                WHERE {master_col} = '{profile_id}';
            """

            data = sqlservice_conn.execute_dataset(query=query)
            return data

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch merge activities. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch merge activities: {str(e)}"
            )

    def read_entity_validation_data(self,entity_id:int,warehouse_id:str,validation_type:Literal["error","warning"],token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            validation_function_warning_enabled = FeatureFlagService._is_feature_flag_enabled(
                self.db,
                'ENABLE_VALIDATION_FUNCTION_WARNING_FEATURE'
            )
            if not validation_function_warning_enabled:
                # Hide the API as if it does not exist
                raise HTTPException(
                    status_code=404,
                    detail="This API is disabled."
                )
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            validation_funcs = [attr for attr in entity.validation_functions
                               if attr.validation_level == validation_type]
            attribute_names = [attr.attribute_name for attr in validation_funcs]
            entity_name = entity.name.lower().replace(" ", "_")
            entity_primary = "lakefusion_id"
            select_b = [f"b.{entity_primary}"]
            # Build dynamic SELECT parts
            select_b += [
            f"b.{attr.name}" for attr in entity.attributes
            if attr.name != "attributes_combined" and attr.name not in attribute_names]
            select_a = ', '.join([f"'{attr}'" for attr in attribute_names])
            
            where_conditions = [f"t.{attr} IS NOT NULL" for attr in attribute_names]

            where_clause = " OR ".join(where_conditions)
            select_attrs = []
           
            for attr in attribute_names:
                # alias: FullName -> FullName_obj
                select_attrs.append(
                        f"named_struct('value', b.{attr}, 'status', t.{attr}) AS {attr}"
                    )
                

            # Join select parts
            select_clause = ", ".join(select_b + select_attrs)
            
            # Build pivot list for SQL
            select_a = ', '.join([f"'{attr}'" for attr in attribute_names])
            
            

            query = f"""
                SELECT {select_clause}
                FROM (SELECT * FROM
                         (SELECT distinct lakefusion_id,attribute_name,status FROM {self.catalog_name}.gold.{entity_name}_master_{validation_type}_prod ) a
                         PIVOT (
                             FIRST(status)
                             FOR attribute_name IN ({select_a})
                         ) ) t
                JOIN {self.catalog_name}.gold.{entity_name}_master_prod b
                  ON t.{entity_primary} = b.{entity_primary} WHERE {where_clause}
            """
            print(query)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            data = sqlservice_conn.execute_dataset(query=query)
            return [serialize_row_data(row) for row in data]


        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity validation {validation_type} records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity validation {validation_type} records: {str(e)}"
            )
        
        finally:
            # Ensure the session is closed properly
            self.db.close()

    # ═══════════════════════════════════════════════════════════════════════════
    # Reference Entity Methods
    # ═══════════════════════════════════════════════════════════════════════════

    _common_utils = CommonUtilities()

    _ATTR_TYPE_MAP = {
        "string": "STRING", "text": "STRING",
        "integer": "BIGINT", "int": "BIGINT",
        "float": "DOUBLE", "double": "DOUBLE",
        "decimal": "DECIMAL(38,10)",
        "boolean": "BOOLEAN", "bool": "BOOLEAN",
        "date": "DATE",
        "timestamp": "TIMESTAMP", "datetime": "TIMESTAMP",
    }

    REVIEW_STATUSES = ("PENDING", "NO_MATCH")
    APPROVED_STATUSES = ("AUTO_APPROVED", "APPROVED", "MANUALLY_ADDED")
    REJECTED_STATUSES = ("REJECTED",)

    def _get_ref_catalog_and_entity(self, entity_id: int):
        entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
        if not entity:
            raise HTTPException(status_code=404, detail=f"Entity {entity_id} not found")
        catalog_config = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
        )
        catalog = catalog_config.config_value if catalog_config else "hive_metastore"
        return catalog, entity.name.lower().replace(" ", "_")

    def get_primary_field_for_entity(self, entity_id: int) -> str | None:
        pk_attr = (
            self.db.query(EntityAttributes)
            .filter(EntityAttributes.entity_id == entity_id, EntityAttributes.is_primary_key == True)
            .first()
        )
        return pk_attr.name if pk_attr else None

    def _attr_type_to_sql(self, attr_type: str) -> str:
        return self._ATTR_TYPE_MAP.get((attr_type or "string").lower(), "STRING")

    def _check_ref_table_exists(self, token: str, warehouse_id: str, table_path: str) -> bool:
        try:
            parts = table_path.split(".")
            if len(parts) == 3:
                catalog, schema, table_name = parts
                query = (
                    f"SELECT COUNT(*) FROM {catalog}.information_schema.tables "
                    f"WHERE table_schema = '{schema}' AND table_name = '{table_name}'"
                )
                return DataSetSQLService(token, warehouse_id).execute_count_query(query) > 0
            DataSetSQLService(token, warehouse_id).execute_dataset(
                f"SELECT 1 FROM {self._common_utils.apply_tilde(table_path)} LIMIT 1"
            )
            return True
        except Exception:
            return False

    def _build_ref_filter_clauses(self, filters):
        try:
            if isinstance(filters, str):
                if '%' in filters:
                    import urllib.parse
                    try:
                        filters = urllib.parse.unquote(filters)
                    except Exception:
                        pass
                if filters.strip():
                    try:
                        filters = json.loads(filters)
                    except json.JSONDecodeError:
                        return "", []
                else:
                    return "", []
            if not filters or not isinstance(filters, list):
                return "", []
            filter_clauses = []
            for i, f in enumerate(filters):
                # attributeId is the actual column name; attributeName is the display label.
                # Prefer attributeId to ensure correct SQL column references.
                attr = f.get('attributeId') or f.get('attributeName')
                op = f.get('operator')
                val = f.get('value')
                conj = f.get('conjunction', 'AND')
                if not attr or not op:
                    continue
                sql_clause = ""
                if op == 'eq':            sql_clause = f"{attr} = '{val}'"
                elif op == 'neq':         sql_clause = f"{attr} != '{val}'"
                elif op == 'contains':    sql_clause = f"{attr} LIKE '%{val}%'"
                elif op == 'icontains':   sql_clause = f"{attr} ILIKE '%{val}%'"
                elif op == 'not_contains': sql_clause = f"{attr} NOT LIKE '%{val}%'"
                elif op == 'starts_with': sql_clause = f"{attr} LIKE '{val}%'"
                elif op == 'ends_with':   sql_clause = f"{attr} LIKE '%{val}'"
                elif op == 'gt':          sql_clause = f"{attr} > {val}"
                elif op == 'lt':          sql_clause = f"{attr} < {val}"
                elif op == 'gte':         sql_clause = f"{attr} >= {val}"
                elif op == 'lte':         sql_clause = f"{attr} <= {val}"
                elif op == 'is_null':     sql_clause = f"{attr} IS NULL"
                elif op == 'is_not_null': sql_clause = f"{attr} IS NOT NULL"
                elif op == 'eq_true':     sql_clause = f"{attr} = TRUE"
                elif op == 'eq_false':    sql_clause = f"{attr} = FALSE"
                if sql_clause:
                    if i > 0:
                        filter_clauses.append(conj)
                    filter_clauses.append(sql_clause)
            return (" ".join(filter_clauses), []) if filter_clauses else ("", [])
        except Exception as e:
            app_logger.error(f"Error building filter clauses: {str(e)}")
            return "", []

    # ── Reference Table ───────────────────────────────────────────────────────

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # PATH HELPERS
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def get_reference_table_path(self, entity_id: int) -> tuple[str, str]:
        """Returns the DATA table path (business columns only)."""
        catalog, entity_name_snake = self._get_ref_catalog_and_entity(entity_id)
        return f"{catalog}.gold.{entity_name_snake}_reference_prod", entity_name_snake

    def get_reference_meta_table_path(self, entity_id: int) -> tuple[str, str]:
        """Returns the META table path (steward/lifecycle columns)."""
        catalog, entity_name_snake = self._get_ref_catalog_and_entity(entity_id)
        return f"{catalog}.gold.{entity_name_snake}_reference_meta_prod", entity_name_snake

    def get_reference_view_path(self, entity_id: int) -> tuple[str, str]:
        """Returns the unified VIEW path (data LEFT JOIN meta)."""
        catalog, entity_name_snake = self._get_ref_catalog_and_entity(entity_id)
        return f"{catalog}.gold.{entity_name_snake}_reference_full_vw", entity_name_snake

    def get_reference_review_table_path(self, entity_id: int) -> tuple[str, str]:
        catalog, entity_name_snake = self._get_ref_catalog_and_entity(entity_id)
        return f"{catalog}.gold.{entity_name_snake}_reference_conflict_queue_prod", entity_name_snake

    def get_reference_mappings_table_path(self, entity_id: int) -> tuple[str, str]:
        catalog, entity_name_snake = self._get_ref_catalog_and_entity(entity_id)
        return f"{catalog}.gold.{entity_name_snake}_reference_mappings", entity_name_snake

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # TABLE EXISTENCE CHECK
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def check_reference_entity_tables_existence(self, token: str, entity_id: int, warehouse_id: str) -> dict:
        data_path, _     = self.get_reference_table_path(entity_id)
        view_path, _     = self.get_reference_view_path(entity_id)
        meta_path, _     = self.get_reference_meta_table_path(entity_id)
        review_path, _   = self.get_reference_review_table_path(entity_id)
        mappings_path, _ = self.get_reference_mappings_table_path(entity_id)
        return {
            "reference_data_table_exists":     self._check_ref_table_exists(token, warehouse_id, data_path),
            "reference_view_exists":           self._check_ref_table_exists(token, warehouse_id, view_path),
            "reference_meta_table_exists":     self._check_ref_table_exists(token, warehouse_id, meta_path),
            "reference_review_table_exists":   self._check_ref_table_exists(token, warehouse_id, review_path),
            "reference_mappings_table_exists": self._check_ref_table_exists(token, warehouse_id, mappings_path),
        }

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # CREATE TABLES  (data + meta + view)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def _create_reference_table(self, token: str, entity_id: int, warehouse_id: str):
        """Creates the DATA table, META table, and the unified VIEW."""

        data_path, _ = self.get_reference_table_path(entity_id)
        meta_path, _ = self.get_reference_meta_table_path(entity_id)

        attrs = (
            self.db.query(EntityAttributes)
            .filter(EntityAttributes.entity_id == entity_id, EntityAttributes.is_active == True)
            .all()
        )
        if not attrs:
            raise HTTPException(status_code=400, detail="Entity has no active attributes; cannot create table.")

        pk_attr = next((a for a in attrs if a.is_primary_key), None)
        tilde = self._common_utils.apply_tilde

        # ── 1. DATA table — business columns + minimal audit ──────────────────
        col_defs = ", ".join(
            f"{tilde(a.name)} {self._attr_type_to_sql(a.type)}" for a in attrs
        )
        pk_constraint = (
            f", CONSTRAINT pk_{data_path.split('.')[-1]} PRIMARY KEY ({tilde(pk_attr.name)})"
            if pk_attr else ""
        )

        data_ddl = (
            f"CREATE TABLE IF NOT EXISTS {tilde(data_path)} "
            f"({col_defs}{pk_constraint}) USING DELTA"
        )
        app_logger.info(f"Creating reference DATA table '{data_path}': {data_ddl}")
        DataSetSQLService(token, warehouse_id).execute_dataset(data_ddl)

        # ── 2. META table — steward/lifecycle columns, keyed by PK ────────────
        if not pk_attr:
            raise HTTPException(
                status_code=400,
                detail="Entity has no primary key attribute; cannot create meta table."
            )

        pk_col_def = f"{tilde(pk_attr.name)} {self._attr_type_to_sql(pk_attr.type)} NOT NULL"
        meta_cols = (
            f"{pk_col_def}"
            ", `is_active` BOOLEAN"
            ", `steward_locked` BOOLEAN"
            ", `steward_edited_cols` ARRAY<STRING>"
            ", `steward_edited_by` STRING"
            ", `steward_edited_at` TIMESTAMP"
            ", `created_at` TIMESTAMP"
            ", `updated_at` TIMESTAMP"
            ", `action_type` STRING"
        )

        meta_ddl = (
            f"CREATE TABLE IF NOT EXISTS {tilde(meta_path)} "
            f"({meta_cols}) USING DELTA"
        )
        app_logger.info(f"Creating reference META table '{meta_path}': {meta_ddl}")
        DataSetSQLService(token, warehouse_id).execute_dataset(meta_ddl)

        # ── 3. Unified VIEW — data LEFT JOIN meta ────────────────────────────
        view_path, _ = self.get_reference_view_path(entity_id)
        pk_name = tilde(pk_attr.name)

        view_ddl = f"""
            CREATE OR REPLACE VIEW {tilde(view_path)} AS
            SELECT
                d.*,
                m.`is_active`,
                m.`steward_locked`,
                m.`steward_edited_cols`,
                m.`steward_edited_by`,
                m.`steward_edited_at`,
                m.`created_at`
            FROM {tilde(data_path)}  d
            LEFT JOIN {tilde(meta_path)}  m
              ON d.{pk_name} = m.{pk_name}
        """
        app_logger.info(f"Creating reference VIEW '{view_path}'")
        DataSetSQLService(token, warehouse_id).execute_dataset(view_ddl)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # FETCH RECORDS  (reads through the unified view)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def _apply_filters_where(self, filters) -> str:
        if not filters:
            return ""
        if isinstance(filters, str):
            import urllib.parse as _up
            if "%" in filters:
                try:
                    filters = _up.unquote(filters)
                except Exception:
                    pass
            try:
                filters = json.loads(filters)
            except json.JSONDecodeError:
                return ""
        if isinstance(filters, list) and filters:
            filter_clause, _ = self._build_ref_filter_clauses(filters)
            if filter_clause:
                return f"WHERE {filter_clause}"
        return ""

    def fetch_reference_records(
        self, token: str, entity_id: int, warehouse_id: str,
        page: int = 1, page_size: int = 50, filters=None
    ):
        """
        Reads from the unified VIEW (data + meta joined).
        Filters on is_active from the meta side automatically.
        """
        view_path, _ = self.get_reference_view_path(entity_id)
        view_table   = self._common_utils.apply_tilde(view_path)

        filter_clause = self._apply_filters_where(filters)

        # is_active lives in the META table, surfaced through the view
        if filter_clause:
            where_clause = filter_clause + " AND `is_active` = true"
        else:
            where_clause = "WHERE `is_active` = true"

        primary_field = self.get_primary_field_for_entity(entity_id)
        order_clause = (
            f"ORDER BY {self._common_utils.apply_tilde(primary_field)}"
            if primary_field else ""
        )

        sql_service = DataSetSQLService(token, warehouse_id)
        total_count = sql_service.execute_count_query(
            f"SELECT COUNT(*) FROM {view_table} {where_clause}"
        )

        offset = (page - 1) * page_size
        rows = sql_service.execute_dataset(
            f"SELECT * FROM {view_table} {where_clause} {order_clause} "
            f"LIMIT {page_size} OFFSET {offset}"
        )

        has_more = (offset + len(rows)) < total_count
        return HttpResponse(status=200, data=rows, totalCount=total_count, has_more=has_more)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # RESOLVE CONFLICT  (writes to correct table per column ownership)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

   
    def resolve_conflict(
        self, token: str, warehouse_id: str, entity_id: int,
        conflict_id: str, decision: str, resolved_by: str
    ):
        valid_decisions = {"KEEP_RDM", "USE_SOURCE", "APPROVED", "REJECTED"}
        if decision not in valid_decisions:
            raise ValueError(f"Invalid decision '{decision}'. Must be one of {valid_decisions}")
    
        sql_service = DataSetSQLService(token, warehouse_id)
        tilde       = self._common_utils.apply_tilde
    
        conflict_table_path, _ = self.get_reference_review_table_path(entity_id)
        data_table_path, _     = self.get_reference_table_path(entity_id)
        meta_table_path, _     = self.get_reference_meta_table_path(entity_id)
    
        conflict_table = tilde(conflict_table_path)
        data_table     = tilde(data_table_path)
        meta_table     = tilde(meta_table_path)
    
        primary_field = self.get_primary_field_for_entity(entity_id)
        tilde_pk      = tilde(primary_field)
    
        now = datetime.utcnow().isoformat()
    
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # STEP 1: Fetch the pending conflict row
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        rows = DataSetSQLService(token, warehouse_id).execute_dataset(f"""
            SELECT *
            FROM {conflict_table}
            WHERE conflict_id = '{conflict_id}'
              AND status = 'PENDING'
            LIMIT 1
        """)
    
        if not rows:
            raise HTTPException(
                status_code=404,
                detail=f"Conflict '{conflict_id}' not found or already resolved."
            )
    
        row           = rows[0]
        conflict_type = row["conflict_type"]
        field_name    = row["field_name"]
        source_value  = row["source_value"]
        entity_key    = row["entity_key_value"]
    
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # STEP 2: Apply decision
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    
        # ── Case A: UPDATE_CONFLICT + USE_SOURCE ──────────────────────────────
        # DATA table  → update business column only
        # META table  → unlock + stamp updated_at + set action_type
        if conflict_type == "UPDATE_CONFLICT" and decision == "USE_SOURCE":
            tilde_field = tilde(field_name)
    
            # ✅ DATA: business column only — no updated_at/updated_by (those live in META)
            DataSetSQLService(token, warehouse_id).execute_dataset(f"""
                UPDATE {data_table}
                SET {tilde_field} = '{source_value}'
                WHERE {tilde_pk}  = '{entity_key}'
            """)
    
            # ✅ META: unlock + stamp + action_type
            DataSetSQLService(token, warehouse_id).execute_dataset(f"""
                UPDATE {meta_table}
                SET `steward_locked`   = false,
                    `steward_edited_at` = '{now}',
                    `steward_edited_by` = '{resolved_by}',
                    `updated_at`        = '{now}',
                    `action_type`       = 'CONFLICT_RESOLVED'
                WHERE {tilde_pk}        = '{entity_key}'
            """)
    
        # ── Case B: PENDING_INSERT + APPROVED ─────────────────────────────────
        # DATA table  → insert business columns only
        # META table  → seed full meta row
        elif conflict_type == "PENDING_INSERT" and decision == "APPROVED":
            import json as _json
            try:
                data: dict = _json.loads(source_value)
            except _json.JSONDecodeError:
                raise HTTPException(
                    status_code=400,
                    detail=f"source_value for PENDING_INSERT is not valid JSON: {source_value}"
                )
    
            # ✅ DATA: business columns only — no meta columns
            col_names  = ", ".join(tilde(k) for k in data.keys())
            col_values = ", ".join(
                f"'{v}'" if not isinstance(v, bool) else str(v).lower()
                for v in data.values()
            )
            DataSetSQLService(token, warehouse_id).execute_dataset(f"""
                INSERT INTO {data_table} ({col_names})
                VALUES ({col_values})
            """)
    
            # ✅ META: seed full meta row with all required columns
            pk_value = data.get(primary_field, entity_key)
            DataSetSQLService(token, warehouse_id).execute_dataset(f"""
                INSERT INTO {meta_table} (
                    {tilde_pk},
                    `is_active`,
                    `steward_locked`,
                    `steward_edited_cols`,
                    `steward_edited_by`,
                    `steward_edited_at`,
                    `created_at`,
                    `updated_at`,
                    `action_type`
                )
                VALUES (
                    '{pk_value}',
                    true,
                    false,
                    null,
                    null,
                    null,
                    '{now}',
                    '{now}',
                    'CONFLICT_RESOLVED'
                )
            """)
    
        # ── Case C: KEEP_RDM ──────────────────────────────────────────────────
        # META only → re-stamp steward timestamp, no DATA change
        elif decision == "KEEP_RDM":
            DataSetSQLService(token, warehouse_id).execute_dataset(f"""
                UPDATE {meta_table}
                SET `steward_edited_at` = '{now}',
                    `updated_at`        = '{now}',
                    `action_type`       = 'KEEP_RDM'
                WHERE {tilde_pk}        = '{entity_key}'
            """)
    
        # ── Case D: REJECTED ──────────────────────────────────────────────────
        # No DATA or META change — just close the queue row below
        elif conflict_type == "PENDING_INSERT" and decision == "REJECTED":
            pass
    
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # STEP 3: Close the conflict queue row
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        DataSetSQLService(token, warehouse_id).execute_dataset(f"""
            UPDATE {conflict_table}
            SET status      = '{decision}',
                resolved_by = '{resolved_by}',
                resolved_at = '{now}'
            WHERE conflict_id = '{conflict_id}'
        """)
    
        return HttpResponse(
            status=200,
            message=f"Conflict '{conflict_id}' resolved as '{decision}' by '{resolved_by}'."
        )
    def fetch_conflict_records(self, token: str, entity_id: int, warehouse_id: str, page: int = 1, page_size: int = 50, filters=None):
        conflict_table_path, _ = self.get_reference_review_table_path(entity_id)
        data_path, _ = self.get_reference_table_path(entity_id)
        primary_field = self.get_primary_field_for_entity(entity_id)

        tilde = self._common_utils.apply_tilde
        conflict_table = tilde(conflict_table_path)

        conflict_cols_str = ", ".join(
            f"c.{tilde(col)}" for col in [
                "conflict_id", "conflict_type", "entity_key_value", "field_name",
                "rdm_value", "source_value", "edited_by", "status",
                "resolved_by", "resolved_at", "created_at",
            ]
        )

        # LEFT JOIN data table to embed full reference record as JSON — avoids per-row hover fetches on the frontend
        join_clause = ""
        ref_select = ", NULL AS `ref_record`"
        if primary_field and self._check_ref_table_exists(token, warehouse_id, data_path):
            pk_col = tilde(primary_field)
            join_clause = f"LEFT JOIN {tilde(data_path)} r ON CAST(c.`entity_key_value` AS STRING) = CAST(r.{pk_col} AS STRING)"
            ref_select = f", CASE WHEN r.{pk_col} IS NOT NULL THEN to_json(struct(r.*)) ELSE NULL END AS `ref_record`"

        where_clause = "WHERE c.`status` = 'PENDING'"
        order_clause = "ORDER BY c.`created_at` DESC"
        from_clause = f"FROM {conflict_table} c {join_clause}"

        sql_service = DataSetSQLService(token, warehouse_id)
        total_count = sql_service.execute_count_query(f"SELECT COUNT(*) {from_clause} {where_clause}")

        offset = (page - 1) * page_size
        rows = sql_service.execute_dataset(
            f"SELECT {conflict_cols_str}{ref_select} {from_clause} {where_clause} {order_clause} LIMIT {page_size} OFFSET {offset}"
        )

        has_more = (offset + len(rows)) < total_count

        return HttpResponse(status=200, data=rows, totalCount=total_count, has_more=has_more)
    
    def create_reference_record(self, token: str, entity_id: int, warehouse_id: str, data_object: dict):
        data_path, _ = self.get_reference_table_path(entity_id)
        meta_path, _ = self.get_reference_meta_table_path(entity_id)
        primary_field = self.get_primary_field_for_entity(entity_id)
        if primary_field is None:
            raise HTTPException(status_code=400, detail="No primary key attribute is set for this reference entity.")

        # Validate provided columns against entity attributes
        valid_attr_names = {
            a.name for a in self.db.query(EntityAttributes)
            .filter(EntityAttributes.entity_id == entity_id, EntityAttributes.is_active == True)
            .all()
        }
        invalid_cols = set(data_object.keys()) - valid_attr_names
        if invalid_cols:
            raise HTTPException(status_code=400, detail=f"Unknown column(s): {', '.join(sorted(invalid_cols))}")

        primary_value = data_object.get(primary_field)
        if primary_value is None:
            raise HTTPException(status_code=400, detail=f"Primary field '{primary_field}' is missing from the provided data.")

        if not self._check_ref_table_exists(token, warehouse_id, data_path) or not self._check_ref_table_exists(token, warehouse_id, meta_path):
            self._create_reference_table(token, entity_id, warehouse_id)
        sqlservice = DataSetSQLService(token, warehouse_id)

        tilde = self._common_utils.apply_tilde
        data_table = tilde(data_path)
        meta_table = tilde(meta_path)
        pk_col = tilde(primary_field)

        if sqlservice.execute_count_query(f"SELECT COUNT(*) FROM {data_table} WHERE {pk_col} = '{primary_value}'") > 0:
            raise HTTPException(status_code=409, detail=f"A record with {primary_field} = '{primary_value}' already exists.")

        # 1. Insert business columns into DATA table
        user_cols_str = ", ".join(tilde(c) for c in data_object.keys())
        user_placeholders = ", ".join(["?"] * len(data_object))
        data_insert_sql = (
            f"INSERT INTO {data_table} ({user_cols_str}) "
            f"VALUES ({user_placeholders})"
        )
        affected = sqlservice.execute_insert_query(data_insert_sql, list(data_object.values()))

        # 2. Insert corresponding meta row into META table (system cols as literals)
        meta_insert_sql = (
            f"INSERT INTO {meta_table} "
            f"({pk_col}, `is_active`, `steward_locked`, `steward_edited_cols`, "
            f"`steward_edited_by`, `steward_edited_at`, `created_at`, `updated_at`, `action_type`) "
            f"VALUES ('{primary_value}', true, false, null, null, null, current_timestamp(), null, 'MANUAL_INSERT')"
        )
        sqlservice.execute_insert_query(meta_insert_sql, [])

        return HttpResponse(status=200, message="Record inserted successfully!", data={"affected_rows": affected, "created_record": [data_object]})


    def update_reference_record(self, token: str, entity_id: int, warehouse_id: str, primary_field: str, updates: list, edited_by: str = ""):
    
        # ── Resolve table paths ──────────────────────────────────────────────────
        table_path, _ = self.get_reference_table_path(entity_id)
        meta_table_path, _ = self.get_reference_meta_table_path(entity_id)

        table      = self._common_utils.apply_tilde(table_path)
        meta_table = self._common_utils.apply_tilde(meta_table_path)
        pk_col     = self._common_utils.apply_tilde(primary_field)

        valid_updates = [u.model_dump() if hasattr(u, "model_dump") else dict(u) for u in updates]
        if not valid_updates:
            raise HTTPException(status_code=400, detail="No updates provided")

        sql_service = DataSetSQLService(token, warehouse_id)
        pv_list     = [u["primary_field_value"] for u in valid_updates]
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # STEP 1: UPDATE DATA TABLE  (actual field values only)
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        all_cols = set()
        for u in valid_updates:
            all_cols.update(u.get("data", {}).keys())
        
        # ✅ Never update the primary key column itself
        all_cols.discard(primary_field)
        
        if not all_cols:
            raise HTTPException(status_code=400, detail="No valid fields to update")
        
        set_clauses_data = []
        
        for u in valid_updates:
            for col, val in u.get("data", {}).items():
                if col == primary_field:
                    continue  # ✅ skip PK
        
                # ✅ inline value directly — no ? needed
                safe_val = str(val).replace("'", "''")  # escape single quotes
                set_clauses_data.append(f"{self._common_utils.apply_tilde(col)} = '{safe_val}'")
        
        # ✅ deduplicate SET clauses
        seen = set()
        unique_set_clauses = []
        for clause in set_clauses_data:
            if clause not in seen:
                seen.add(clause)
                unique_set_clauses.append(clause)
        
        # ✅ inline pv_list for WHERE
        pv_in_clause = ", ".join(f"'{pv}'" for pv in pv_list)
        
        data_update_query = f"""
            UPDATE {table}
            SET {', '.join(unique_set_clauses)}
            WHERE {pk_col} IN ({pv_in_clause})
        """
        # ✅ No params needed — everything is inlined
        affected_data = sql_service.execute_update_query(data_update_query, [])
        
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # STEP 2: UPDATE META TABLE  (steward tracking only)
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        edited_cols_cases = []

        for u in valid_updates:
            cols = [c for c in u.get("data", {}).keys() if c != primary_field]
            if cols:
                arr_literal = "ARRAY(" + ", ".join(f"'{c}'" for c in cols) + ")"
                pv = u["primary_field_value"]
                # ✅ inline the value directly — no ? needed
                edited_cols_cases.append(f"WHEN {pk_col} = '{pv}' THEN {arr_literal}")
        
        set_clauses_meta = []
        
        if edited_cols_cases:
            set_clauses_meta.append(
                f"`steward_edited_cols` = CASE {' '.join(edited_cols_cases)} ELSE `steward_edited_cols` END"
            )
        
        # ✅ inline pv_list for WHERE as well
        pv_in_clause = ", ".join(f"'{pv}'" for pv in pv_list)
        
        set_clauses_meta.extend([
            "`steward_locked`     = true",
            f"`steward_edited_by` = '{edited_by}'",
            "`steward_edited_at`  = current_timestamp()",
            "`updated_at`         = current_timestamp()",
            "`action_type`        = 'STEWARD_EDIT'",
        ])
        
        meta_update_query = f"""
            UPDATE {meta_table}
            SET {', '.join(set_clauses_meta)}
            WHERE {pk_col} IN ({pv_in_clause})
        """
        # ✅ No params needed — everything is inlined
        affected_meta = sql_service.execute_update_query(meta_update_query, [])

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # RESPONSE
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        return {
            "status": 200,
            "data": {
                "message":                  "Reference records updated successfully",
                "total_updates_requested":  len(updates),
                "successful_updates":       len(valid_updates),
                "data_table_affected_rows": affected_data,
                "meta_table_affected_rows": affected_meta,
            }
        }

    def delete_reference_record(self, token: str, entity_id: int, warehouse_id: str, primary_field: str, primary_field_value):
        data_path, _ = self.get_reference_table_path(entity_id)
        meta_path, _ = self.get_reference_meta_table_path(entity_id)

        tilde = self._common_utils.apply_tilde
        data_table = tilde(data_path)
        meta_table = tilde(meta_path)
        pk_col = tilde(primary_field)
        sanitized = str(primary_field_value).replace("'", "''")

        sql_service = DataSetSQLService(token, warehouse_id)
        sql_service.execute_delete_query(f"DELETE FROM {data_table} WHERE {pk_col} = '{sanitized}'")
        sql_service.execute_delete_query(f"DELETE FROM {meta_table} WHERE {pk_col} = '{sanitized}'")

    # ── Reference Review Table ────────────────────────────────────────────────

    def fetch_reference_review_records(self, token: str, entity_id: int, warehouse_id: str, page: int = 1, page_size: int = 50, filters=None):
        table_path, _ = self.get_reference_review_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        where_clause = self._apply_filters_where(filters)
        primary_field = self.get_primary_field_for_entity(entity_id)
        order_clause = f"ORDER BY {self._common_utils.apply_tilde(primary_field)}" if primary_field else ""
        total_count = DataSetSQLService(token, warehouse_id).execute_count_query(f"SELECT COUNT(*) FROM {table} {where_clause}")
        offset = (page - 1) * page_size
        has_more = (page * page_size) < total_count
        rows = DataSetSQLService(token, warehouse_id).execute_dataset(f"SELECT * FROM {table} {where_clause} {order_clause} LIMIT {page_size} OFFSET {offset}")
        return HttpResponse(status=200, data=rows, totalCount=total_count, has_more=has_more)

    def update_reference_review_record(self, token: str, entity_id: int, warehouse_id: str, primary_field: str, updates: list):
        table_path, _ = self.get_reference_review_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        pk_col = self._common_utils.apply_tilde(primary_field)
        valid_updates = [u.model_dump() if hasattr(u, "model_dump") else dict(u) for u in updates]
        if not valid_updates:
            raise HTTPException(status_code=400, detail="No updates provided")
        all_cols = set()
        for u in valid_updates:
            all_cols.update(u.get("data", {}).keys())
        set_clauses = []
        params = []
        for col in all_cols:
            case_parts = []
            for u in valid_updates:
                if col in u.get("data", {}):
                    case_parts.append(f"WHEN {pk_col} = ? THEN ?")
                    params.extend([u["primary_field_value"], u["data"][col]])
            if case_parts:
                set_clauses.append(f"{self._common_utils.apply_tilde(col)} = CASE {' '.join(case_parts)} ELSE {self._common_utils.apply_tilde(col)} END")
        if not set_clauses:
            raise HTTPException(status_code=400, detail="No valid fields to update")
        pv_list = [u["primary_field_value"] for u in valid_updates]
        params.extend(pv_list)
        update_query = f"UPDATE {table} SET {', '.join(set_clauses)} WHERE {pk_col} IN ({', '.join(['?'] * len(pv_list))})"
        affected = DataSetSQLService(token, warehouse_id).execute_update_query(update_query, params)
        return {"status": 200, "data": {"message": "Reference review records updated successfully", "total_updates_requested": len(updates), "successful_updates": len(valid_updates), "total_affected_rows": affected}}

    def delete_reference_review_record(self, token: str, entity_id: int, warehouse_id: str, primary_field: str, primary_field_value):
        table_path, _ = self.get_reference_review_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        pk_col = self._common_utils.apply_tilde(primary_field)
        sanitized = str(primary_field_value).replace("'", "''")
        return DataSetSQLService(token, warehouse_id).execute_delete_query(f"DELETE FROM {table} WHERE {pk_col} = '{sanitized}'")

    def approve_reference_review_record(self, token: str, entity_id: int, warehouse_id: str, primary_field_value):
        primary_field = self.get_primary_field_for_entity(entity_id)
        if not primary_field:
            raise HTTPException(status_code=400, detail="No primary key attribute set for this entity.")
        review_path, _ = self.get_reference_review_table_path(entity_id)
        ref_path, _ = self.get_reference_table_path(entity_id)
        review_table = self._common_utils.apply_tilde(review_path)
        ref_table = self._common_utils.apply_tilde(ref_path)
        pk_col = self._common_utils.apply_tilde(primary_field)
        sanitized = str(primary_field_value).replace("'", "''")
        rows = DataSetSQLService(token, warehouse_id).execute_dataset(
            f"SELECT * FROM {review_table} WHERE {pk_col} = '{sanitized}' LIMIT 1"
        )
        if not rows:
            raise HTTPException(status_code=404, detail=f"No review record found with {primary_field} = '{primary_field_value}'")
        row = rows[0]
        if not self._check_ref_table_exists(token, warehouse_id, ref_path):
            self._create_reference_table(token, entity_id, warehouse_id)
        columns = list(row.keys())
        values = list(row.values())
        columns_str = ", ".join(self._common_utils.apply_tilde(c) for c in columns)
        placeholders = ", ".join(["?"] * len(values))
        existing = DataSetSQLService(token, warehouse_id).execute_count_query(
            f"SELECT COUNT(*) FROM {ref_table} WHERE {pk_col} = '{sanitized}'"
        )
        if existing > 0:
            non_pk_cols = [c for c in columns if c != primary_field]
            set_clauses = ", ".join(f"{self._common_utils.apply_tilde(c)} = ?" for c in non_pk_cols)
            update_vals = [row[c] for c in non_pk_cols] + [primary_field_value]
            DataSetSQLService(token, warehouse_id).execute_update_query(
                f"UPDATE {ref_table} SET {set_clauses} WHERE {pk_col} = ?", update_vals
            )
        else:
            DataSetSQLService(token, warehouse_id).execute_insert_query(
                f"INSERT INTO {ref_table} ({columns_str}) VALUES ({placeholders})", values
            )
        DataSetSQLService(token, warehouse_id).execute_delete_query(
            f"DELETE FROM {review_table} WHERE {pk_col} = '{sanitized}'"
        )
        return HttpResponse(status=200, message="Record approved and moved to reference table.", data={"approved_record": [row]})

    def approve_all_reference_review_records(self, token: str, entity_id: int, warehouse_id: str):
        primary_field = self.get_primary_field_for_entity(entity_id)
        if not primary_field:
            raise HTTPException(status_code=400, detail="No primary key attribute set for this entity.")
        review_path, _ = self.get_reference_review_table_path(entity_id)
        ref_path, _ = self.get_reference_table_path(entity_id)
        review_table = self._common_utils.apply_tilde(review_path)
        ref_table = self._common_utils.apply_tilde(ref_path)
        pk_col = self._common_utils.apply_tilde(primary_field)
        total = DataSetSQLService(token, warehouse_id).execute_count_query(f"SELECT COUNT(*) FROM {review_table}")
        if total == 0:
            return HttpResponse(status=200, message="No review records to approve.", data={"approved_count": 0})
        if not self._check_ref_table_exists(token, warehouse_id, ref_path):
            self._create_reference_table(token, entity_id, warehouse_id)
        DataSetSQLService(token, warehouse_id).execute_delete_query(
            f"DELETE FROM {ref_table} WHERE {pk_col} IN (SELECT {pk_col} FROM {review_table})"
        )
        DataSetSQLService(token, warehouse_id).execute_insert_query(
            f"INSERT INTO {ref_table} SELECT * FROM {review_table}", []
        )
        DataSetSQLService(token, warehouse_id).execute_delete_query(f"DELETE FROM {review_table}")
        return HttpResponse(status=200, message=f"All {total} review records approved and moved to reference table.", data={"approved_count": total})

    # ── Reference Mappings Table ──────────────────────────────────────────────

    def fetch_reference_mappings_records(self, token: str, entity_id: int, warehouse_id: str, page: int = 1, page_size: int = 50, status_filter: list | None = None, filters=None):
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        where_parts = ["status != 'REJECTED'"]
        if status_filter:
            quoted = ", ".join(f"'{s}'" for s in status_filter)
            where_parts.append(f"status IN ({quoted})")
        if filters:
            extra = self._apply_filters_where(filters)
            if extra.startswith("WHERE "):
                where_parts.append(f"({extra[6:]})")
        where_clause = f"WHERE {' AND '.join(where_parts)}"
        total_count = DataSetSQLService(token, warehouse_id).execute_count_query(f"SELECT COUNT(*) FROM {table} {where_clause}")
        offset = (page - 1) * page_size
        has_more = (page * page_size) < total_count
        rows = DataSetSQLService(token, warehouse_id).execute_dataset(f"SELECT * FROM {table} {where_clause} ORDER BY id LIMIT {page_size} OFFSET {offset}")
        return HttpResponse(status=200, data=rows, totalCount=total_count, has_more=has_more)

    def approve_all_reference_mapping_records(self, token: str, entity_id: int, warehouse_id: str):
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        total = DataSetSQLService(token, warehouse_id).execute_count_query(
            f"SELECT COUNT(*) FROM {table} WHERE status IN ('PENDING', 'NO_MATCH')"
        )
        if total == 0:
            return HttpResponse(status=200, message="No pending mappings to approve.", data={"approved_count": 0})
        DataSetSQLService(token, warehouse_id).execute_update_query(
            f"UPDATE {table} SET status = 'APPROVED' WHERE status IN ('PENDING', 'NO_MATCH')", []
        )
        return HttpResponse(status=200, message=f"All {total} pending mappings approved.", data={"approved_count": total})

    def create_reference_mapping_record(self, token: str, entity_id: int, warehouse_id: str, data_object: dict):
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        if "status" not in data_object:
            data_object["status"] = "MANUALLY_ADDED"
        columns = list(data_object.keys())
        values = list(data_object.values())
        columns_str = ", ".join(self._common_utils.apply_tilde(c) for c in columns)
        placeholders = ", ".join(["?"] * len(values))
        affected = DataSetSQLService(token, warehouse_id).execute_insert_query(
            f"INSERT INTO {table} ({columns_str}) VALUES ({placeholders})", values
        )
        return HttpResponse(status=200, message="Mapping record inserted successfully!", data={"affected_rows": affected, "created_record": [data_object]})

    def import_reference_records(self, token: str, entity_id: int, warehouse_id: str, records: list):
        """Bulk-import records into the reference DATA and META tables using MERGE to skip existing PKs.
        - Raises 400 if any record is missing the primary key field.
        - Deduplicates within the incoming batch (first occurrence wins).
        - Creates the reference tables if they do not yet exist.
        - Skips records whose primary key already exists (no error).
        """
        if not records:
            raise HTTPException(status_code=400, detail="No records provided.")
        primary_field = self.get_primary_field_for_entity(entity_id)
        if primary_field is None:
            raise HTTPException(status_code=400, detail="No primary key attribute is set for this reference entity.")

        # Validate every record has a non-empty primary key
        for i, rec in enumerate(records):
            if not rec.get(primary_field):
                raise HTTPException(status_code=400, detail=f"Record at index {i} is missing primary field '{primary_field}'.")

        # Deduplicate within the incoming batch — keep first occurrence
        seen: set = set()
        unique_records: list = []
        for rec in records:
            pk_val = rec.get(primary_field)
            if pk_val not in seen:
                seen.add(pk_val)
                unique_records.append(rec)
        duplicates_in_batch = len(records) - len(unique_records)

        # Ensure reference tables exist (check both; either missing means we create all)
        data_path, _ = self.get_reference_table_path(entity_id)
        meta_path, _ = self.get_reference_meta_table_path(entity_id)
        if not self._check_ref_table_exists(token, warehouse_id, data_path) or not self._check_ref_table_exists(token, warehouse_id, meta_path):
            self._create_reference_table(token, entity_id, warehouse_id)

        tilde = self._common_utils.apply_tilde
        data_table = tilde(data_path)
        meta_table = tilde(meta_path)
        pk_tilde = tilde(primary_field)
        pk_values = [rec.get(primary_field) for rec in unique_records]

        # ── 1. MERGE into DATA table (business columns only) ──────────────────
        columns = list(unique_records[0].keys())
        col_tilde = [tilde(c) for c in columns]
        columns_str = ", ".join(col_tilde)
        source_vals = ", ".join(f"s.{t}" for t in col_tilde)

        row_ph = "(" + ", ".join(["?"] * len(columns)) + ")"
        all_ph = ", ".join([row_ph] * len(unique_records))
        flat_params = [rec.get(col) for rec in unique_records for col in columns]

        data_merge_sql = (
            f"MERGE INTO {data_table} AS t "
            f"USING (SELECT {columns_str} FROM VALUES {all_ph} AS tmp({columns_str})) AS s "
            f"ON t.{pk_tilde} = s.{pk_tilde} "
            f"WHEN NOT MATCHED THEN INSERT ({columns_str}) VALUES ({source_vals})"
        )

        # Count pre-existing PKs before merge to derive actual inserted count
        pk_placeholders = ", ".join(["?"] * len(pk_values))
        svc = DataSetSQLService(token, warehouse_id)
        pre_existing = svc.execute_count_query(
            f"SELECT COUNT(*) FROM {data_table} WHERE {pk_tilde} IN ({pk_placeholders})", pk_values
        )
        svc.execute_merge_query(data_merge_sql, flat_params)
        inserted = len(unique_records) - pre_existing

        # ── 2. MERGE into META table (pk + system cols, skip if already exists) ─
        meta_all_ph = ", ".join([f"(?)"] * len(unique_records))
        meta_merge_sql = (
            f"MERGE INTO {meta_table} AS t "
            f"USING (SELECT {pk_tilde} FROM VALUES {meta_all_ph} AS tmp({pk_tilde})) AS s "
            f"ON t.{pk_tilde} = s.{pk_tilde} "
            f"WHEN NOT MATCHED THEN INSERT "
            f"({pk_tilde}, `is_active`, `steward_locked`, `steward_edited_cols`, "
            f"`steward_edited_by`, `steward_edited_at`, `created_at`, `updated_at`, `action_type`) "
            f"VALUES (s.{pk_tilde}, true, false, null, null, null, current_timestamp(), null, 'MANUAL_INSERT')"
        )
        svc.execute_merge_query(meta_merge_sql, pk_values)

        return HttpResponse(
            status=200,
            message=f"{inserted} record(s) inserted, {duplicates_in_batch + pre_existing} duplicate(s) skipped.",
            data={"affected_rows": inserted, "submitted_count": len(records), "duplicates_skipped": duplicates_in_batch + pre_existing},
        )

    def import_reference_mapping_records(self, token: str, entity_id: int, warehouse_id: str, records: list):
        """Bulk INSERT mapping records. Raises 400 if the mappings table does not exist."""
        if not records:
            raise HTTPException(status_code=400, detail="No records provided.")
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        if not self._check_ref_table_exists(token, warehouse_id, table_path):
            raise HTTPException(status_code=400, detail="Mappings table does not exist. Run the sync pipeline first to initialise it.")
        for rec in records:
            if not rec.get("status"):
                rec["status"] = "MANUALLY_ADDED"
        table = self._common_utils.apply_tilde(table_path)
        columns = list(records[0].keys())
        columns_str = ", ".join(self._common_utils.apply_tilde(c) for c in columns)
        row_ph = "(" + ", ".join(["?"] * len(columns)) + ")"
        all_ph = ", ".join([row_ph] * len(records))
        flat_params = [rec.get(col) for rec in records for col in columns]
        affected = DataSetSQLService(token, warehouse_id).execute_insert_query(
            f"INSERT INTO {table} ({columns_str}) VALUES {all_ph}", flat_params
        )
        return HttpResponse(status=200, message=f"{len(records)} mapping(s) imported successfully!", data={"affected_rows": affected, "imported_count": len(records)})

    def update_reference_mapping_record(self, token: str, entity_id: int, warehouse_id: str, record_id: int, data_object: dict):
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        if not data_object:
            raise HTTPException(status_code=400, detail="No fields to update")
        set_clauses = ", ".join(f"{self._common_utils.apply_tilde(k)} = ?" for k in data_object.keys())
        params = list(data_object.values()) + [record_id]
        affected = DataSetSQLService(token, warehouse_id).execute_update_query(
            f"UPDATE {table} SET {set_clauses} WHERE id = ?", params
        )
        return {"status": 200, "data": {"message": "Mapping record updated successfully", "total_affected_rows": affected}}

    def delete_reference_mapping_record(self, token: str, entity_id: int, warehouse_id: str, record_id: int):
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        return DataSetSQLService(token, warehouse_id).execute_delete_query(f"DELETE FROM {table} WHERE id = {record_id}")

lakefusion_databricks_dapi = os.environ.get('LAKEFUSION_DATABRICKS_DAPI', '')
class Monitor_Entity_Search_Databricks_Job:
    def __init__(self, db: Session):
        self.db = db

    def get_experiment_status(self, job_run_data: List[Dict], job_run_id) -> str:
        """
        Update experiment status based on job run tasks states
        """

        # ✅ ALWAYS return a string
        if not job_run_data:
            return 'match_merge_pending'

        # Convert list to dict (exclude manual testing)
        task_states = {
            task['task_key']: task
            for task in job_run_data
            if task.get('task_key') != 'Entity_Manual_Testing'
        }

        # 1️⃣ Failures first
        if any(
            task.get('result_state') in ('FAILED', 'UPSTREAM_FAILED')
            for task in job_run_data
        ):
            return 'match_merge_failed'

        # 2️⃣ Cancelled
        if any(
            task.get('result_state') in ('CANCELED', 'UPSTREAM_CANCELED')
            for task in job_run_data
        ):
            return 'match_merge_cancelled'

        # 3️⃣ Success detection (REAL merge tasks)
        merge_task = (
            task_states.get('Process_Entity_Job_Status')
            # or task_states.get('Process_CrossWalk')
            # or task_states.get('Entity_Match_Merge')  # backward compatibility
        )

        if (
            merge_task
            and merge_task.get('state') == 'TERMINATED'
            and merge_task.get('result_state') == 'SUCCESS'
        ):
            return 'match_merge_successed'

        # 4️⃣ Default
        return 'match_merge_pending'

    
    def get_pending_tasks(self):
        """
        Retrieve all rows where task_status is 'pending' from the Model_Databricks_Job table.

        Args:
            db (Session): SQLAlchemy database session.

        Returns:
            List[Model_Databricks_Job]: List of jobs with task_status as 'pending'.
        """
        try:
            pending_tasks = self.db.query(Model_Databricks_Entity_Search_Job).filter(
                Model_Databricks_Entity_Search_Job.status.in_(['match_merge_pending','prepare'])
            ).all()
            return pending_tasks
        except Exception as e:
            print(f"Error fetching pending tasks: {e}")
            raise
    


    def update_job_run_status(
        self,
        job_run_id: str,
        new_job_run_status,
        new_status: str
    ):
        try:
            # 🔒 Strong validation (prevents MySQL errors forever)
            if not isinstance(new_status, str):
                raise ValueError(
                    f"Invalid status value: {new_status} (type={type(new_status)})"
                )

            # Get ALL records with this job_run_id (Merge All creates multiple records per job)
            job_entries = (
                self.db.query(Model_Databricks_Entity_Search_Job)
                .filter(
                    Model_Databricks_Entity_Search_Job.job_run_id == job_run_id
                )
                .all()
            )

            if not job_entries:
                raise ValueError(f"No job found with run_id: {job_run_id}")

            # ✅ Update ALL records with this job_run_id
            updated_count = 0
            for job_entry in job_entries:
                job_entry.job_run_status = new_job_run_status
                job_entry.status = new_status
                updated_count += 1

            self.db.commit()
            app_logger.info(f"Updated {updated_count} records for job_run_id={job_run_id} to status={new_status}")

            return job_entries

        except Exception:
            self.db.rollback()
            app_logger.exception(
                f"Failed to update job run status for job_run_id={job_run_id}"
            )
            raise

    
    

def check_entity_search_monitor_status(db: Session):
    """
    Check and update the monitor status of pending profiling tasks.

    Returns:
    - None: This function does not return a value.

    Raises:
    - HTTPException: If there is an issue with the database query or
      fetching monitor information.
    """
    app_logger.info("Starting check_entity_search_monitor_status function execution.")

    try:
        # Initialize the ProfilingTaskService with the database session.
        monitor_model_job_service = Monitor_Entity_Search_Databricks_Job(db)

        # Attempt to fetch tasks that have a pending monitor status.
        try:
            pending_job_run_tasks = monitor_model_job_service.get_pending_tasks()
        except Exception as e:
            # Log any errors that occur while fetching pending tasks.
            app_logger.error(f"Error fetching pending tasks: {str(e)}")
            app_logger.error(f"Traceback: {traceback.format_exc()}")
            return  # Exit the function if an error occurs to prevent further processing.

        # Get unique job_run_ids to avoid redundant Databricks API calls
        # (Merge All creates multiple records with same job_run_id)
        unique_job_run_ids = set()
        job_run_map = {}  # Store first job_run for each job_run_id (for fallback status)
        for job_run in pending_job_run_tasks:
            if job_run.job_run_id not in unique_job_run_ids:
                unique_job_run_ids.add(job_run.job_run_id)
                job_run_map[job_run.job_run_id] = job_run

        app_logger.info(f"Found {len(pending_job_run_tasks)} pending tasks with {len(unique_job_run_ids)} unique job_run_ids")

        # Process each unique job_run_id only once
        for job_run_id in unique_job_run_ids:
            try:
                job_run = job_run_map[job_run_id]

                # Fetch the latest monitor information for the task's dataset.
                job_status = DatabricksJobManager(token=lakefusion_databricks_dapi)
                latest_job_run_info = job_status.get_job_run_status(job_run_id)
                if latest_job_run_info is None:
                    app_logger.warning(f"Using previous job_run_status for job_run_id={job_run_id}")
                    latest_job_run_info = job_run.job_run_status
                new_experiment_status = monitor_model_job_service.get_experiment_status(latest_job_run_info, job_run_id)
                monitor_model_job_service.update_job_run_status(job_run_id, latest_job_run_info, new_experiment_status)

            except Exception as task_error:
                # Log any errors that occur while processing each individual task.
                app_logger.error(f"Error processing job run with ID {job_run_id}: {str(task_error)}")
                app_logger.error(f"Traceback: {traceback.format_exc()}")
                # Optionally, implement retry logic or other error handling here.

    except Exception as function_error:
        # Log any errors that occur at the function level.
        app_logger.error(f"Error in check_monitor_status function: {str(function_error)}")
        app_logger.error(f"Traceback: {traceback.format_exc()}")

    # Log the completion of the function execution.
    app_logger.info("Finished check_entity_search_monitor_status function execution.")
