from typing import List, Optional
from sqlalchemy.orm import Session
from fastapi import HTTPException
from cachetools import TTLCache, cached
from cachetools.keys import hashkey
from lakefusion_utility.models.feature_flags import FeatureFlag, FeatureFlagStatus
from lakefusion_utility.utils.logging_utils import get_logger

# ------------------------------------------------------------------------------
# Cache setup
# ------------------------------------------------------------------------------

# Cache for listing flags by status (e.g., ACTIVE / INACTIVE)
# TTL = 1 hour (3600 seconds)
flags_cache = TTLCache(maxsize=100, ttl=3600)

# Cache for individual feature flags fetched by name
flag_by_name_cache = TTLCache(maxsize=1000, ttl=3600)

# Logger for the service
app_logger = get_logger("feature_flags_service")

# ------------------------------------------------------------------------------
# FeatureFlagService Definition
# ------------------------------------------------------------------------------

class FeatureFlagService:
    """
    Service layer for managing FeatureFlag entities.
    
    Responsibilities:
      - Querying feature flags from the database.
      - Providing cached lookups for flags and their status.
      - Ensuring results are safe to cache (via model.to_dict()).
    """

    def __init__(self, db: Session):
        """
        Initialize the service with a SQLAlchemy session.

        Args:
            db (Session): Active SQLAlchemy session for DB operations.
        """
        self.db = db

    # --------------------------------------------------------------------------
    # Static Cached Queries
    # --------------------------------------------------------------------------

    @staticmethod
    @cached(cache=flags_cache, key=lambda db, status=FeatureFlagStatus.ACTIVE: hashkey(status))
    def _list_feature_flags(db: Session, status: FeatureFlagStatus = FeatureFlagStatus.ACTIVE) -> List[dict]:
        """
        Retrieve all feature flags for a given status and cache them as dicts.
        Cached results avoid repeated DB hits for identical status queries.

        Args:
            db (Session): SQLAlchemy session.
            status (FeatureFlagStatus, optional): Filter flags by status. Defaults to ACTIVE.

        Returns:
            List[dict]: List of feature flags represented as dictionaries.
        """
        flags = db.query(FeatureFlag).filter(FeatureFlag.status == status).all()
        # Convert ORM objects to plain dicts (safe to cache)
        return [flag.to_dict() for flag in flags]

    @staticmethod
    @cached(cache=flag_by_name_cache, key=lambda db, name: hashkey(name))
    def _get_feature_flag(db: Session, name: str) -> Optional[dict]:
        """
        Retrieve a single feature flag by its name and cache it as a dict.

        Args:
            db (Session): SQLAlchemy session.
            name (str): Name of the feature flag.

        Returns:
            Optional[dict]: Feature flag data as a dictionary, or None if not found.
        """
        flag = db.query(FeatureFlag).filter(FeatureFlag.name == name).first()
        return flag.to_dict() if flag else None

    @staticmethod
    def _is_feature_flag_enabled(db: Session, name: str) -> bool:
        """
        Check if a feature flag is enabled (ACTIVE) using the cached result.

        Args:
            db (Session): SQLAlchemy session.
            name (str): Feature flag name.

        Returns:
            bool: True if flag exists and is ACTIVE, False otherwise.
        """
        flag = FeatureFlagService._get_feature_flag(db, name)
        return flag is not None and flag["status"] == FeatureFlagStatus.ACTIVE.value

    # --------------------------------------------------------------------------
    # Instance Wrappers (Convenience Layer)
    # --------------------------------------------------------------------------

    def list_feature_flags(self, status: FeatureFlagStatus = FeatureFlagStatus.ACTIVE) -> List[dict]:
        """
        Public instance method for fetching all feature flags by status.

        Uses cached data if available, otherwise hits the database.

        Args:
            status (FeatureFlagStatus, optional): Flag status filter. Defaults to ACTIVE.

        Returns:
            List[dict]: List of feature flag dictionaries.
        """
        return self._list_feature_flags(self.db, status)

    def get_feature_flag(self, name: str) -> Optional[dict]:
        """
        Public instance method for fetching a feature flag by name.

        Uses cached data if available.

        Args:
            name (str): Feature flag name.

        Returns:
            Optional[dict]: Feature flag dictionary if found, else None.
        """
        return self._get_feature_flag(self.db, name)

    def is_feature_flag_enabled(self, name: str) -> bool:
        """
        Public instance method to check if a specific feature flag is active.

        Args:
            name (str): Feature flag name.

        Returns:
            bool: True if the feature flag is enabled, False otherwise.
        """
        return self._is_feature_flag_enabled(self.db, name)

    # --------------------------------------------------------------------------
    # Cache Management
    # --------------------------------------------------------------------------

    @classmethod
    def clear_cache(cls):
        """
        Clear both the list and individual feature flag caches.

        Useful when flags are modified in the DB to prevent stale reads.
        """
        flags_cache.clear()
        flag_by_name_cache.clear()
        app_logger.info("Feature flags service cache cleared successfully")
