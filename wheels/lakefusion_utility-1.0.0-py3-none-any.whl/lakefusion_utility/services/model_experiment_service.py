from lakefusion_utility.utils.databricks_util import DatabricksJobManager, DataSetSQLService, get_resource_tags, CatalogService
from copy import deepcopy
import json
import math
from collections import Counter
import os

import io
import csv
from fastapi import APIRouter, HTTPException, Query, Depends
from fastapi.responses import StreamingResponse
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from fastapi import HTTPException
from fastapi.responses import JSONResponse
import numpy as np
from sqlalchemy.orm import Session
import traceback
from sqlalchemy import or_, and_
from typing import Union,List,Optional
from databricks.sdk.service import jobs
from lakefusion_utility.models.match_maven import *
#from app.models.match_maven import *
from lakefusion_utility.models.match_maven import Model_GetExperimentResponse, Model_Experiment, Entity
from databricks.sdk.service.compute import ClusterSpec, RuntimeEngine,AwsAttributes,AwsAvailability,AutoScale,DataSecurityMode,AzureAttributes
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
#from app.models.databricks_model_job import *
from lakefusion_utility.models.databricks_model import *
from lakefusion_utility.models.databricks_model import Model_Databricks_Job
from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
from databricks.sdk.service.jobs import Task, NotebookTask, TaskEmailNotifications, RunIf, Source, CronSchedule, JobParameterDefinition, CreateResponse, Job, JobSettings,TaskDependency,ConditionTask,ConditionTaskOp,JobParameter,SubmitTask
import logging
from lakefusion_utility.services.entity_service import EntityService
from lakefusion_utility.models.dbconfig import DBConfigProperties
from datetime import date, datetime
import urllib.parse
from sqlalchemy import func
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.notebook_path_utils import get_notebook_folder
from lakefusion_utility.utils.lf_utils import get_version_info
from decimal import Decimal

app_logger = logging.getLogger(__name__)

DATABRICKS_HOST = os.environ.get('DATABRICKS_HOST', 'https://databricks.com')

def serialize_row_data(row_dict: dict, entity_attributes: List = None) -> dict:
    """
    Serialize row data with proper numeric precision handling.
    Converts float/Decimal types to properly formatted strings to preserve precision.
    
    Args:
        row_dict: Dictionary containing row data
        entity_attributes: List of entity attributes (optional, for type hints)
    
    Returns:
        Processed dictionary with proper numeric precision
    """
    processed = {}
    for key, value in row_dict.items():
        if isinstance(value, Decimal):
            # Convert Decimal to float, round, then format
            rounded = round(float(value), 2)
            # Use g format to avoid trailing zeros, then convert to float for JSON
            processed[key] = float(rounded)
        elif isinstance(value, float):
            # Round to 2 decimal places
            rounded = round(value, 2)
            processed[key] = rounded
        elif isinstance(value, (date, datetime)):
            # Keep datetime objects as-is
            processed[key] = value
        else:
            processed[key] = value
    return processed

def round_floats_in_potential_matches(potential_matches_str: str) -> str:
    """
    Parse the potential_matches JSON string and round any full-precision float
    values (stored as strings or actual floats) to 2 decimal places.
    """
    def _round_value(v):
        if isinstance(v, float):
            return round(v, 2)
        if isinstance(v, str) and '.' in v:
            try:
                return str(round(float(v), 2))
            except (ValueError, TypeError):
                pass
        return v

    try:
        matches = json.loads(potential_matches_str)
        if isinstance(matches, list):
            for item in matches:
                if isinstance(item, dict):
                    for k in item:
                        item[k] = _round_value(item[k])
        return json.dumps(matches)
    except (json.JSONDecodeError, TypeError):
        return potential_matches_str


def compare_versions(version1: str, version2: str) -> int:
    """
    Compare two version strings.
    Returns:
        -1 if version1 < version2
         0 if version1 == version2
         1 if version1 > version2
    """
    if not version1:
        version1 = "1.0.0"
    if not version2:
        version2 = "1.0.0"
    
    v1_parts = [int(x) for x in version1.split('.')]
    v2_parts = [int(x) for x in version2.split('.')]
    
    # Pad shorter version with zeros
    while len(v1_parts) < len(v2_parts):
        v1_parts.append(0)
    while len(v2_parts) < len(v1_parts):
        v2_parts.append(0)
    
    for i in range(len(v1_parts)):
        if v1_parts[i] < v2_parts[i]:
            return -1
        elif v1_parts[i] > v2_parts[i]:
            return 1
    return 0


def is_version_gte(version: str, target: str) -> bool:
    """Check if version is greater than or equal to target version."""
    return compare_versions(version, target) >= 0

NEW_PIPELINE_MIN_VERSION = "4.0.0"

class SimpleEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)

class ExperimentService:

    def __init__(self, db: Session):
        self.db = db
        self.catalog_name = (
        self.db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == "catalog_name")
        .first().config_value
        )
        self.db_config_service = DBConfigPropertiesService(db=self.db)
    

    def create_experiment(self, experiment_create: Model_ExperimentCreate):
        try:
            model_experiment_base_prompt_flag = FeatureFlagService._is_feature_flag_enabled(
                self.db,
                'ENABLE_BASE_PROMPT_MANAGEMENT_FEATURE'
            )
            experiment_data = experiment_create.dict()

            if model_experiment_base_prompt_flag:
                raw_base_prompt_id = experiment_data.get("base_prompt_id")
                base_prompt_id = None if raw_base_prompt_id in (0, "0", "", None) else raw_base_prompt_id
            else:
                base_prompt_id = None
            
            version = get_version_info()["productVersion"]
            
            # Create a new experiment instance
            new_experiment = Model_Experiment(
                entity_id=experiment_data['entity_id'],
                base_prompt_id=base_prompt_id,
                status=experiment_data['status'],
                modelname=experiment_data['modelname'],
                description=experiment_data['description'],
                llm_model_source=experiment_data['llm_model_source'],
                llm_model=experiment_data['llm_model'],
                embedding_model_source=experiment_data['embedding_model_source'],
                embedding_model=experiment_data['embedding_model'],
                max_potential_matches=experiment_data['max_potential_matches'],
                vs_endpoint=experiment_data['vs_endpoint'],
                additional_instructions=experiment_data['additional_instructions'],
                attributes=experiment_data.get('attributes'),
                processed_record=experiment_data.get('processed_record'),
                config_thresold=experiment_data.get('config_thresold'),
                created_by=experiment_data['created_by'],
                version=version,
                deterministic_rules=experiment_data.get('deterministic_rules')
            )
            self.db.add(new_experiment)
            self.db.commit()
            self.db.refresh(new_experiment)
            
            return new_experiment

        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create experiment. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create experiment: {str(e)}")

        finally:
            self.db.close()

    def list_models(
        self, 
        entity: int,
        sort_by: str = "created_at", 
        sort_order: str = "desc", 
        limit: Optional[int] = None, 
        offset: int = 0,
        status_filter: Optional[str] = None
    ) -> List[Model_GetExperimentResponse]:
        """
        Fetches the available models for a given entity with filtering, sorting, and pagination options.
        Calculates is_outdated property based on entity relation_updated_at and model status.

        Args:
            entity: Entity ID (int).
            sort_by: Field to sort by (e.g., 'id', 'modelname', 'created_at', 'updated_at'). Default is 'created_at'.
            sort_order: Sort order, either 'asc' or 'desc'. Default is 'desc'.
            limit: Maximum number of records to return. If None, returns all matching records.
            offset: Number of records to skip for pagination. Default is 0.
            status_filter: Filter by model status (e.g., 'published', 'review', 'approved').

        Returns:
            List of models for the entity with is_outdated property based on filters and sorting.
            
        Raises:
            HTTPException: If there's an error during retrieval or invalid parameters.
        """
        try:
            # Validate sort_order parameter
            if sort_order.lower() not in ['asc', 'desc']:
                raise HTTPException(status_code=400, detail="sort_order must be either 'asc' or 'desc'")
            
            # Validate sort_by field exists on the Model_Experiment model
            if not hasattr(Model_Experiment, sort_by):
                raise HTTPException(status_code=400, detail=f"Invalid sort field: {sort_by}")
            
            # Validate limit and offset parameters
            if limit is not None and limit < 0:
                raise HTTPException(status_code=400, detail="limit must be non-negative")
            
            if offset < 0:
                raise HTTPException(status_code=400, detail="offset must be non-negative")

            outdated_check_statuses = ['published', 'review', 'approved', 'in_progress', 'experiment_failed', 'experiment_cancelled']
            
            # Query models with entity information to get relation_updated_at
            query = (
                self.db.query(
                    Model_Experiment, 
                    Entity.relation_updated_at,
                    func.concat(f"{DATABRICKS_HOST}/jobs/", Model_Databricks_Job.job_id, "/runs/", Model_Databricks_Job.job_run_id, "/#").label("effective_job_link")
                )
                .join(Entity, Model_Experiment.entity_id == Entity.id)
                .outerjoin(Model_Databricks_Job, and_(
                    Model_Experiment.id == Model_Databricks_Job.modelid,
                    Model_Experiment.entity_id == Model_Databricks_Job.entity_id
                ))
                .filter(Model_Experiment.entity_id == entity)
            )
            
            # Apply status filter if specified
            if status_filter is not None:
                query = query.filter(Model_Experiment.status == status_filter)
            
            # Apply sorting
            sort_field = getattr(Model_Experiment, sort_by)
            if sort_order.lower() == 'desc':
                query = query.order_by(sort_field.desc())
            else:
                query = query.order_by(sort_field.asc())
            
            # Apply pagination if specified
            if offset > 0:
                query = query.offset(offset)
            
            if limit is not None and limit > 0:
                query = query.limit(limit)
                
            results = query.all()
            
            # Process results and calculate is_outdated for each model
            model_responses = []
            for model, entity_relation_updated_at, effective_job_link in results:
                # Calculate is_outdated
                is_outdated = False
                if (model.status in outdated_check_statuses and 
                    entity_relation_updated_at and 
                    model.created_at < entity_relation_updated_at):
                    is_outdated = True
                
                # Create response using the updated from_orm method
                model_response = Model_GetExperimentResponse.from_orm(
                    model, 
                    effective_job_link, 
                    is_outdated=is_outdated
                )
                model_responses.append(model_response)

            app_logger.info(
                f"Successfully retrieved {len(model_responses)} models for entity {entity} with filters: "
                f"sort_by={sort_by}, sort_order={sort_order}, status_filter={status_filter}, "
                f"limit={limit}, offset={offset}"
            )
            return model_responses

        except HTTPException:
            # Re-raise HTTP exceptions (validation errors)
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to list models for entity {entity}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to list models for entity {entity}: {str(e)}")
        finally:
            self.db.close()

    def get_model(self, model_id: int) -> Model_ExperimentResponse:
        """
        Fetches details for a specific model based on model_id.

        Args:
            model_id: The ID of the model to fetch.

        Returns:
            The model details as an Experiment object.
        """
        try:
            model = self.db.query(Model_Experiment).filter(Model_Experiment.id == model_id).first()
            if not model:
                raise HTTPException(status_code=404, detail="Model not found")

            return Model_ExperimentResponse.from_orm(model)

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch model with ID {model_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch model {model_id}: {str(e)}")
        finally:
            self.db.close()

    def update_model(self, model_id: int, model_update: Model_ExperimentUpdateRequest) -> Model_ExperimentResponse:
        try:
            model = self.db.query(Model_Experiment).filter(
                Model_Experiment.id == model_id
            ).first()            
            if not model:
                raise HTTPException(status_code=404, detail="Model not found")

            # Get the update data, excluding None values
            update_data = model_update.dict()
           
            if "base_prompt_id" in update_data:
                raw_base_prompt_id = update_data.get("base_prompt_id")
                update_data["base_prompt_id"] = (
                    None if raw_base_prompt_id in (0, "0", "", None)
                    else raw_base_prompt_id
                )
            # Create a new experiment instance

            # Update each field if it exists in the update data
            for field, value in update_data.items():
                if field == "base_prompt_id":
                    setattr(model, "base_prompt_id", value)
                    continue

                # Allow deterministic_rules to be set to None explicitly
                if field == "deterministic_rules":
                    setattr(model, "deterministic_rules", value)
                    continue

                # Skip None for other fields
                if value is None:
                    continue
                #if value is not None:
                    # Handle nested JSON fields
                if field in ['llm_model', 'embedding_model']:
                    current_value = getattr(model, field) or {}
                    # Get the model source (e.g., 'databricks_foundation', 'databricks_custom', 'external_model_api')
                    model_source = getattr(model_update, f"{field}_source")
                    if model_source and model_source in value:
                        current_value = value  # Replace the entire value for the specific source
                    setattr(model, field, current_value)
                elif field in ['config_thresold', 'deterministic_rules']:
                    setattr(model, field, value)  # Direct replacement
                else:
                    setattr(model, field, value)

            self.db.commit()
            self.db.refresh(model)

            return Model_ExperimentResponse.from_orm(model)

        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update model with ID {model_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to update model {model_id}: {str(e)}")
        finally:
            self.db.close()
   
    def delete_model(self, model_id: int) -> dict:
        try:
            model = self.db.query(Model_Experiment).filter(
                Model_Experiment.id == model_id
            ).first()
            
            
            if not model:
                raise HTTPException(status_code=404, detail="Model not found")
            maven_model = self.db.query(Model_Databricks_Job).filter(Model_Databricks_Job.modelid == model_id).all()
            for model_maven_id in maven_model:
                self.db.delete(model_maven_id)
            self.db.delete(model)
            self.db.commit()

            return {"message": f"Model {model_id} successfully deleted"}

        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete model with ID {model_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to delete model {model_id}: {str(e)}")
        finally:
            self.db.close()

    def _generate_csv_response(self, data: list) -> StreamingResponse:
        if not data:
            output = io.StringIO()
            output.write("")
            output.seek(0)
        else:
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=data[0].keys())
            writer.writeheader()
            writer.writerows(data)
            output.seek(0)
    
        return StreamingResponse(
            iter([output.getvalue()]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=potential_matches.csv"}
        )

    def fetch_potential_matches(self, entity_id: int, model_id: int, token: str, warehouse_id: str,
                            page: int = 1, page_size: int = 1000, filters: Optional[str] = None, 
                            scoreFilter: Optional[str] = None):
        """
        fetch_potential_matches retrieves potential record matches for a given entity
        using a specified matching model. Uses version-based routing to determine
        which query structure to use (legacy vs new pipeline).
        """
        try:
            # Validate input parameters
            if page < 1:
                page = 1
            if page_size < 1:
                page_size = 1000
            if page_size > 10000:  # Set reasonable upper limit
                page_size = 10000
            
            # Get model to check version
            model = self.db.query(Model_Experiment).filter(Model_Experiment.id == model_id).first()
            if not model:
                raise HTTPException(status_code=404, detail="Model not found")
            
            model_version = model.version or "1.0.0"
            use_new_pipeline = is_version_gte(model_version, NEW_PIPELINE_MIN_VERSION)
            
            app_logger.info(f"fetch_potential_matches: model_id={model_id}, version={model_version}, use_new_pipeline={use_new_pipeline}")
                
            # Get entity information
            entity_service = EntityService(db=self.db)
            entity: Optional[Entity] = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
                
            entity_full: Entity = entity_service.get_full_entity_by_id(entity_id=entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            
            if not attributes:
                raise HTTPException(status_code=400, detail="Entity has no attributes defined")
            
            # Count unique datasets
            dataset_id_count = len(Counter(mapping.dataset_id for mapping in entity_full.dataset_mappings))
            primary_key_attr = "lakefusion_id"
            
            # Calculate pagination offset
            offset = (page - 1) * page_size
            
            # Always use the deduplicated table for consistency
            # Build the query based on dataset count
            if dataset_id_count == 1:
                if use_new_pipeline:
                    print("new pipeline dataset single query")
                    query = self._build_single_dataset_query(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset, filters, scoreFilter
                    )
                else:
                    query = self._build_single_dataset_query_legacy(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset, filters, scoreFilter
                    )
            else:
                if use_new_pipeline:
                    print("new pipeline dataset multiple query")
                    query = self._build_multiple_dataset_query(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset,filters, scoreFilter
                    )
                else:
                    query = self._build_multiple_dataset_query_legacy(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset, filters, scoreFilter
                    )
            
            # Execute query
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            raw_data = sqlservice_conn.execute_dataset(query)
            
            # Process results
            total_count = raw_data[0]['total_count'] if raw_data and 'total_count' in raw_data[0] else 0
            
            processed_data = []
            for row in raw_data:
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()
                # Serialize row data to handle Decimal precision
                row_dict = serialize_row_data(row_dict)
                
                if 'total_count' in row_dict:
                    del row_dict['total_count']
                processed_data.append(row_dict)
            
            # Return paginated response
            response_data = {
                "data": processed_data,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total_count": total_count,
                    "total_pages": math.ceil(total_count / page_size) if page_size > 0 else 0
                }
            }
           
            
            return response_data
            
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch potential matches. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch potential matches: {str(e)}")
        finally:
            self.db.close()
    

    def fetch_potential_matches_download(self, entity_id: int, model_id: int, token: str, warehouse_id: str, 
                            page: int = 1, page_size: int = 1000, filters: Optional[str] = None, 
                            scoreFilter: Optional[str] = None):
        """
        fetch_potential_matches retrieves potential record matches for a given entity
        using a specified matching model. Uses version-based routing to determine
        which query structure to use (legacy vs new pipeline).
        """
        try:
            # Validate input parameters
            if page < 1:
                page = 1
            if page_size < 1:
                page_size = 1000
            if page_size > 10000:  # Set reasonable upper limit
                page_size = 10000
            
            # Get model to check version
            model = self.db.query(Model_Experiment).filter(Model_Experiment.id == model_id).first()
            if not model:
                raise HTTPException(status_code=404, detail="Model not found")
            
            model_version = model.version or "1.0.0"
            use_new_pipeline = is_version_gte(model_version, NEW_PIPELINE_MIN_VERSION)
            
            app_logger.info(f"fetch_potential_matches: model_id={model_id}, version={model_version}, use_new_pipeline={use_new_pipeline}")
                
            # Get entity information
            entity_service = EntityService(db=self.db)
            entity: Optional[Entity] = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
                
            entity_full: Entity = entity_service.get_full_entity_by_id(entity_id=entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            
            if not attributes:
                raise HTTPException(status_code=400, detail="Entity has no attributes defined")
            
            # Count unique datasets
            dataset_id_count = len(Counter(mapping.dataset_id for mapping in entity_full.dataset_mappings))
            primary_key_attr = "lakefusion_id"
            
            # Calculate pagination offset
            offset = (page - 1) * page_size
            
            # Always use the deduplicated table for consistency
            # Build the query based on dataset count
            if dataset_id_count == 1:
                if use_new_pipeline:
                    query = self._build_single_dataset_query_csv(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset, filters, scoreFilter
                    )
               
            else:
                if use_new_pipeline:
                    query = self._build_multiple_dataset_query_csv(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset, filters, scoreFilter
                    )
                
            
            # Execute query
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            raw_data = sqlservice_conn.execute_dataset(query)
            # Process results
            total_count = raw_data[0]['total_count'] if raw_data and 'total_count' in raw_data[0] else 0
            
            processed_data = []
            for row in raw_data:
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()
                if 'total_count' in row_dict:
                    del row_dict['total_count']
                processed_data.append(row_dict)

            response_data = {"data": processed_data}

            return response_data
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch potential matches. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch potential matches: {str(e)}")
        finally:
            self.db.close()

    def fetch_deterministic_matches(self, entity_id: int, model_id: int,action_type: ActionType, token: str, warehouse_id: str, 
                            page: int = 1, page_size: int = 1000, filters: Optional[str] = None, 
                            scoreFilter: Optional[str] = None):
        """
        fetch_potential_matches retrieves potential record matches for a given entity
        using a specified matching model. Uses version-based routing to determine
        which query structure to use (legacy vs new pipeline).
        """
        try:
            # Validate input parameters
            if page < 1:
                page = 1
            if page_size < 1:
                page_size = 1000
            if page_size > 10000:  # Set reasonable upper limit
                page_size = 10000
            
            # Get model to check version
            model = self.db.query(Model_Experiment).filter(Model_Experiment.id == model_id).first()
            if not model:
                raise HTTPException(status_code=404, detail="Model not found")
            
            model_version = model.version or "1.0.0"
            use_new_pipeline = is_version_gte(model_version, NEW_PIPELINE_MIN_VERSION)
            
            app_logger.info(f"fetch_potential_matches: model_id={model_id}, version={model_version}, use_new_pipeline={use_new_pipeline}")
                
            # Get entity information
            entity_service = EntityService(db=self.db)
            entity: Optional[Entity] = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
                
            entity_full: Entity = entity_service.get_full_entity_by_id(entity_id=entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            
            if not attributes:
                raise HTTPException(status_code=400, detail="Entity has no attributes defined")
            
            # Count unique datasets
            dataset_id_count = len(Counter(mapping.dataset_id for mapping in entity_full.dataset_mappings))
            primary_key_attr = "lakefusion_id"
            
            # Calculate pagination offset
            offset = (page - 1) * page_size
            
            # Always use the deduplicated table for consistency
            # Build the query based on dataset count
            if dataset_id_count == 1:
                if use_new_pipeline:
                    print("new pipeline dataset single query")
                    query = self._build_single_deterministic_dataset_query(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset,action_type, filters, scoreFilter
                    )
                else:
                    query = self._build_single_dataset_query_legacy(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset, filters, scoreFilter
                    )
            else:
                if use_new_pipeline:
                    print("new pipeline new multiple query")
                    query = self._build_multiple_deterministic_dataset_query(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset,action_type, filters, scoreFilter
                    )
                else:
                    query = self._build_multiple_dataset_query_legacy(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset, filters, scoreFilter
                    )
            
            # Execute query
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            raw_data = sqlservice_conn.execute_dataset(query)
            
            # Process results
            total_count = raw_data[0]['total_count'] if raw_data and 'total_count' in raw_data[0] else 0
            
            processed_data = []
            for row in raw_data:
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()
                if 'total_count' in row_dict:
                    del row_dict['total_count']
                processed_data.append(row_dict)
            
            # Return paginated response
            response_data = {
                "data": processed_data,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total_count": total_count,
                    "total_pages": math.ceil(total_count / page_size) if page_size > 0 else 0
                }
            }
            
            return response_data
            
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch potential matches. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch potential matches: {str(e)}")
        finally:
            self.db.close()

    def _build_single_dataset_query_legacy(self, entity_name: str, model_id: int, attributes: list, 
                                primary_key_attr: str, page_size: int, offset: int, 
                                filters: Optional[str] = None, scoreFilter: Optional[str] = None) -> str:
        """Build SQL query for single dataset scenario - LEGACY version (< 4.0.0).
        
        Used for experiments created before the MDM restructuring.
        Table structure uses: master_lakefusion_id, exploded_result.match field
        """
        # Process filters
        where_clause = "WHERE pu.exploded_result.match = 'MATCH'"
        if filters:
            filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
            if filter_clause:
                where_clause = f"WHERE pu.exploded_result.match = 'MATCH' AND {filter_clause}"
        
        # Select clause for master attributes
        select_attributes = [f"m.{primary_key_attr}"] + [f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
        select_clause = ", ".join(select_attributes)
        
        # Build JSON object parts
        json_object_parts = []
        json_object_parts.append(f"'{primary_key_attr}', CAST(unified.{primary_key_attr} AS STRING)")
        for attr in attributes:
            if attr.name != primary_key_attr:
                json_object_parts.append(f"'{attr.name}', CAST(unified.{attr.name} AS STRING)")
        
        # Add scoring fields
        json_object_parts.extend([
            "'__score__', CAST(pu.exploded_result.score AS STRING)",
            "'__sourcename__', CAST(unified.dataset.name AS STRING)",
            "'__reason__', CAST(pu.exploded_result.reason AS STRING)"
        ])
        
        # Create JSON object
        json_object = f"to_json(map({', '.join(json_object_parts)}))"
        
        # Group by clause
        group_by_attributes = [
            f"pu.master_{primary_key_attr}",
            f"m.{primary_key_attr}",
            *[f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
        ]
        group_by_clause = ", ".join(group_by_attributes)

        if scoreFilter:
            score_filter = self.build_filter_clauses(scoreFilter, table_prefix="pu.exploded_result")[0]
            where_clause += f" AND {score_filter}"
        
        return f"""
        SELECT
            {select_clause},
            CONCAT('[', ARRAY_JOIN(COLLECT_LIST({json_object}), ','), ']') AS potential_matches,
            COUNT(1) OVER () AS total_count
        FROM {self.catalog_name}.silver.{entity_name}_processed_unified_deduplicate_{model_id} pu
        JOIN {self.catalog_name}.silver.{entity_name}_unified_deduplicate_{model_id} unified
            ON pu.{primary_key_attr} = unified.{primary_key_attr}
        JOIN {self.catalog_name}.gold.{entity_name}_master_{model_id} m
            ON m.{primary_key_attr} = pu.master_{primary_key_attr}
        {where_clause}
        GROUP BY {group_by_clause}
        LIMIT {page_size} OFFSET {offset}"""


    def _build_multiple_dataset_query_legacy(self, entity_name: str, model_id: int, attributes: list, 
                                    primary_key_attr: str, page_size: int, offset: int, 
                                    filters: Optional[str] = None, scoreFilter: Optional[str] = None) -> str:
        """Build SQL query for multiple dataset scenario - LEGACY version (< 4.0.0).
        
        Used for experiments created before the MDM restructuring.
        Table structure uses: master_lakefusion_id, exploded_result.match field
        """
        # Process filters
        where_clause = "WHERE dd_unified.match = 'MATCH'"
        if filters:
            filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
            if filter_clause:
                where_clause = f"WHERE dd_unified.match = 'MATCH' AND {filter_clause}"
        
        # Select clause for master attributes
        select_attributes = [f"m.{primary_key_attr}"] + [f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
        select_clause = ", ".join(select_attributes)
        
        # Build JSON object parts
        json_object_parts = []
        json_object_parts.append(f"'{primary_key_attr}', CAST(dd_unified.{primary_key_attr} AS STRING)")
        for attr in attributes:
            if attr.name != primary_key_attr:
                json_object_parts.append(f"'{attr.name}', CAST(dd_unified.{attr.name} AS STRING)")
        
        # Add scoring fields
        json_object_parts.extend([
            "'__score__', CAST(dd_unified.score AS STRING)",
            "'__sourcename__', CAST(dd_unified.name AS STRING)",
            "'__reason__', CAST(dd_unified.reason AS STRING)"
        ])
        
        # Create JSON object
        json_object = f"to_json(map({', '.join(json_object_parts)}))"
        
        # Build UNION subquery parts
        select_union_parts = [
            f"unified.{primary_key_attr}",
            *[f"unified.{attr.name}" for attr in attributes if attr.name != primary_key_attr],
            "pu.exploded_result.score",
            "unified.dataset.name",
            "pu.exploded_result.reason",
            "pu.exploded_result.match",
            f"pu.master_{primary_key_attr}"
        ]
        select_union_clause = ", ".join(select_union_parts)
        
        # Group by clause
        group_by_attributes = [
            f"dd_unified.master_{primary_key_attr}",
            f"m.{primary_key_attr}",
            *[f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
        ]
        group_by_clause = ", ".join(group_by_attributes)

        if scoreFilter:
            score_filter = self.build_filter_clauses(scoreFilter, table_prefix="dd_unified")[0]
            where_clause += f" AND {score_filter}"
        
        return f"""
        SELECT
            {select_clause},
            CONCAT('[', ARRAY_JOIN(COLLECT_LIST({json_object}), ','), ']') AS potential_matches,
            COUNT(1) OVER () AS total_count
        FROM (
            SELECT {select_union_clause}
            FROM {self.catalog_name}.silver.{entity_name}_processed_unified_{model_id} pu
            JOIN {self.catalog_name}.silver.{entity_name}_unified_{model_id} unified 
                ON pu.{primary_key_attr} = unified.{primary_key_attr}
            WHERE pu.exploded_result.match = 'MATCH'
        ) dd_unified
        JOIN {self.catalog_name}.gold.{entity_name}_master_{model_id} m
            ON m.{primary_key_attr} = dd_unified.master_{primary_key_attr}
        {where_clause}
        GROUP BY {group_by_clause}
        LIMIT {page_size} OFFSET {offset}"""

    def _build_single_dataset_query(self, entity_name: str, model_id: int, attributes: list, 
                                   primary_key_attr: str, page_size: int, offset: int, 
                                   filters: Optional[str] = None, scoreFilter: Optional[str] = None) -> str:
        """Build SQL query for single dataset scenario (golden dedup, experiment mode).
        
        Table structure:
        - processed_unified_deduplicate: query_lakefusion_id, match_lakefusion_id, exploded_result, exploded_result_id
        - unified_deduplicate: lakefusion_id, attributes...
        - master: lakefusion_id, attributes...
        
        In experiment mode, exploded_result has: id, score, reason, lakefusion_id (NO match field)
        """
        # Process filters - EXPERIMENT MODE: No match field, show all results
        where_clause = "WHERE 1=1"
        if filters:
            filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
            if filter_clause:
                where_clause = f"WHERE {filter_clause}"
        
        # Select clause for master attributes
        select_attributes = [f"m.{primary_key_attr}"] + [f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
        select_clause = ", ".join(select_attributes)
        
        # Build JSON object parts - use unified_deduplicate attributes
        json_object_parts = []
        json_object_parts.append(f"'{primary_key_attr}', CAST(unified.{primary_key_attr} AS STRING)")
        for attr in attributes:
            if attr.name != primary_key_attr:
                json_object_parts.append(f"'{attr.name}', CAST(unified.{attr.name} AS STRING)")
        
        # Add scoring fields - EXPERIMENT MODE: No match field
        json_object_parts.extend([
            "'__score__', CAST(pu.exploded_result.score AS STRING)",
            "'__sourcename__', 'master'",  # Golden dedup - source is master table
            "'__reason__', CAST(pu.exploded_result.reason AS STRING)"
        ])
        
        # Create JSON object
        json_object = f"to_json(map({', '.join(json_object_parts)}))"
        
        # Group by clause
        group_by_attributes = [
            "pu.match_lakefusion_id",
            f"m.{primary_key_attr}",
            *[f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
        ]
        group_by_clause = ", ".join(group_by_attributes)

        if scoreFilter:
            score_filter = self.build_filter_clauses(scoreFilter, table_prefix="pu.exploded_result")[0]
            if where_clause == "WHERE 1=1":
                where_clause = f"WHERE {score_filter}"
            else:
                where_clause += f" AND {score_filter}"
        
        return f"""
        SELECT
            {select_clause},
            CONCAT('[', ARRAY_JOIN(COLLECT_LIST({json_object}), ','), ']') AS potential_matches,
            COUNT(1) OVER () AS total_count
        FROM {self.catalog_name}.silver.{entity_name}_processed_unified_deduplicate_{model_id} pu
        JOIN {self.catalog_name}.silver.{entity_name}_unified_deduplicate_{model_id} unified
            ON pu.query_lakefusion_id = unified.{primary_key_attr}
        JOIN {self.catalog_name}.gold.{entity_name}_master_{model_id} m
            ON m.{primary_key_attr} = pu.match_lakefusion_id
        {where_clause}
        GROUP BY {group_by_clause}
        LIMIT {page_size} OFFSET {offset}"""

    def _build_single_deterministic_dataset_query(self, entity_name: str, model_id: int, attributes: list,
                                       primary_key_attr: str, page_size: int, offset: int, action_type: str,
                                       filters: Optional[str] = None, scoreFilter: Optional[str] = None) -> str:
        """Build SQL query for single dataset scenario (golden dedup, experiment mode).

        Table structure:
        - unified_deterministic_deduplicate: lakefusion_id, exploded_result (struct), ...
        - unified_deduplicate: lakefusion_id, attributes...
        - master: lakefusion_id, attributes...

        In experiment mode, exploded_result has: id, score, reason, lakefusion_id (NO match field)

        Query structure mirrors _build_multiple_deterministic_dataset_query:
        - Subquery: joins pu + unified_deduplicate, applies action_type filter (sub_where_clause)
        - Outer query: joins dd_unified + master, applies filters + scoreFilter (outer_where_clause)
        - JSON/GROUP BY reference dd_unified.* (flattened subquery columns)
        """
        # ---------------------------------
        # OUTER WHERE clause (filters + scoreFilter on outer query)
        # Mirrors multiple dataset pattern exactly
        # ---------------------------------
        outer_conditions = []

        if filters:
            filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
            if filter_clause:
                outer_conditions.append(filter_clause)

        if scoreFilter:
            score_clause, _ = self.build_filter_clauses(
                scoreFilter,
                table_prefix="dd_unified"
            )
            if score_clause:
                outer_conditions.append(score_clause)

        outer_where_clause = ""
        if outer_conditions:
            outer_where_clause = "WHERE " + " AND ".join(outer_conditions)

        # ---------------------------------
        # SUBQUERY WHERE clause
        # action_type filter lives here — mirrors multiple dataset pattern
        # NOTE: No record_status filter — unified_deduplicate has no record_status column
        # ---------------------------------
        sub_conditions = [
            "pu.lakefusion_id IS NOT NULL"
        ]

        if action_type:
            sub_conditions.append(f"pu.exploded_result.match = '{action_type}'")

        sub_where_clause = "WHERE " + " AND ".join(sub_conditions)

        # ---------------------------------
        # Select master attributes (outer SELECT)
        # ---------------------------------
        select_attributes = [f"m.{primary_key_attr}"]
        for attr in attributes:
            if attr.name != primary_key_attr:
                select_attributes.append(f"m.{attr.name}")

        select_clause = ", ".join(select_attributes)

        # ---------------------------------
        # JSON object construction
        # References dd_unified.* (flattened subquery columns)
        # Mirrors multiple dataset pattern — no direct pu.* or unified.* refs here
        # ---------------------------------
        json_object_parts = []

        for attr in attributes:
            json_object_parts.append(
                f"'{attr.name}', CAST(dd_unified.{attr.name} AS STRING)"
            )

        json_object_parts.extend([
            "'__score__', CAST(dd_unified.score AS STRING)",
            "'__sourcename__', 'master'",  # Golden dedup - source is always master
            "'__reason__', CAST(dd_unified.reason AS STRING)",
            "'__match__', CAST(dd_unified.match AS STRING)"
        ])

        json_object = f"to_json(map({', '.join(json_object_parts)}))"

        # ---------------------------------
        # Subquery SELECT
        # Flattens pu.exploded_result.* fields + unified attributes into named columns
        # Uses lakefusion_id (not surrogate_key) — golden dedup / single dataset
        # ---------------------------------
        select_union_parts = [
            "pu.exploded_result.lakefusion_id as master_lakefusion_id",
            *[f"unified.{attr.name}" for attr in attributes],
            "pu.exploded_result.score as score",
            "pu.exploded_result.reason as reason",
            "pu.exploded_result.match as match"
        ]

        select_union_clause = ", ".join(select_union_parts)

        # ---------------------------------
        # GROUP BY
        # References dd_unified.master_lakefusion_id (flattened alias) + master attrs
        # Mirrors multiple dataset pattern exactly
        # ---------------------------------
        group_by_columns = [
            "dd_unified.master_lakefusion_id",
            f"m.{primary_key_attr}",
        ]

        for attr in attributes:
            if attr.name != primary_key_attr:
                group_by_columns.append(f"m.{attr.name}")

        group_by_clause = ", ".join(group_by_columns)

        return f"""
        SELECT
            {select_clause},
            CONCAT('[', ARRAY_JOIN(COLLECT_LIST({json_object}), ','), ']') AS potential_matches,
            COUNT(1) OVER () AS total_count
        FROM (
            SELECT {select_union_clause}
            FROM {self.catalog_name}.silver.{entity_name}_unified_deterministic_deduplicate_{model_id} pu
            JOIN {self.catalog_name}.silver.{entity_name}_unified_deduplicate_{model_id} unified
                ON pu.lakefusion_id = unified.{primary_key_attr}
            {sub_where_clause}
        ) dd_unified
        JOIN {self.catalog_name}.gold.{entity_name}_master_{model_id} m
            ON m.{primary_key_attr} = dd_unified.master_lakefusion_id
        {outer_where_clause}
        GROUP BY {group_by_clause}
        LIMIT {page_size} OFFSET {offset}"""

    def _build_multiple_deterministic_dataset_query(self, entity_name: str, model_id: int, attributes: list,
                                     primary_key_attr: str, page_size: int, offset: int,action_type:str,
                                     filters: Optional[str] = None, scoreFilter: Optional[str] = None) -> str:
        """Build SQL query for multiple dataset scenario (experiment mode).
        
        Table structure:
        - processed_unified: surrogate_key, lakefusion_id, exploded_result (struct), exploded_result_id
        - unified: surrogate_key, source_id, dataset (struct), attributes..., record_status
        - master: lakefusion_id, attributes...
        
        In experiment mode, exploded_result has: id, score, reason, lakefusion_id (NO match field)
        """
        # Process filters - EXPERIMENT MODE: No match field, show all results
        outer_conditions = []

        if filters:
            filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
            if filter_clause:
                outer_conditions.append(filter_clause)
    
        if scoreFilter:
            score_clause, _ = self.build_filter_clauses(
                scoreFilter,
                table_prefix="dd_unified"
            )
            if score_clause:
                outer_conditions.append(score_clause)
    
        outer_where_clause = ""
        if outer_conditions:
            outer_where_clause = "WHERE " + " AND ".join(outer_conditions)
    
        # ---------------------------------
        # SUBQUERY WHERE clause (important for match filtering)
        # ---------------------------------
        sub_conditions = [
            "unified.record_status = 'ACTIVE'",
            "pu.lakefusion_id IS NOT NULL"
        ]
        
        if action_type:
            sub_conditions.append(f"pu.exploded_result.match = '{action_type}'")
    
        sub_where_clause = "WHERE " + " AND ".join(sub_conditions)
    
        # ---------------------------------
        # Select master attributes
        # ---------------------------------
        select_attributes = [f"m.{primary_key_attr}"]
        for attr in attributes:
            if attr.name != primary_key_attr:
                select_attributes.append(f"m.{attr.name}")
    
        select_clause = ", ".join(select_attributes)
    
        # ---------------------------------
        # JSON object construction
        # ---------------------------------
        json_object_parts = []
    
        for attr in attributes:
            json_object_parts.append(
                f"'{attr.name}', CAST(dd_unified.{attr.name} AS STRING)"
            )
    
        json_object_parts.extend([
            "'__score__', CAST(dd_unified.score AS STRING)",
            "'__sourcename__', CAST(dd_unified.source_path AS STRING)",
            "'__reason__', CAST(dd_unified.reason AS STRING)",
            "'__match__', CAST(dd_unified.match AS STRING)"
        ])
    
        json_object = f"to_json(map({', '.join(json_object_parts)}))"
    
        # ---------------------------------
        # Subquery SELECT
        # ---------------------------------
        select_union_parts = [
            "pu.lakefusion_id as master_lakefusion_id",
            *[f"unified.{attr.name}" for attr in attributes],
            "pu.exploded_result.score as score",
            "unified.source_path as source_path",
            "pu.exploded_result.reason as reason",
            "pu.exploded_result.match as match"
        ]
    
        select_union_clause = ", ".join(select_union_parts)
    
        # ---------------------------------
        # GROUP BY
        # ---------------------------------
        group_by_columns = [
            "dd_unified.master_lakefusion_id",
            f"m.{primary_key_attr}"
        ]
    
        for attr in attributes:
            if attr.name != primary_key_attr:
                group_by_columns.append(f"m.{attr.name}")
    
        group_by_clause = ", ".join(group_by_columns)
    
        
        return f"""
        SELECT
            {select_clause},
            CONCAT('[', ARRAY_JOIN(COLLECT_LIST({json_object}), ','), ']') AS potential_matches,
            COUNT(1) OVER () AS total_count
        FROM (
            SELECT {select_union_clause}
            FROM {self.catalog_name}.silver.{entity_name}_unified_deterministic_{model_id} pu
            JOIN {self.catalog_name}.silver.{entity_name}_unified_{model_id} unified 
                ON pu.surrogate_key = unified.surrogate_key
            {sub_where_clause}
        ) dd_unified
        JOIN {self.catalog_name}.gold.{entity_name}_master_{model_id} m
            ON m.{primary_key_attr} = dd_unified.master_lakefusion_id
        {outer_where_clause}
        GROUP BY {group_by_clause}
        LIMIT {page_size} OFFSET {offset}"""

    def _build_multiple_dataset_query(self, entity_name: str, model_id: int, attributes: list, 
                                     primary_key_attr: str, page_size: int, offset: int, 
                                     filters: Optional[str] = None, scoreFilter: Optional[str] = None) -> str:
        """Build SQL query for multiple dataset scenario (experiment mode).
        
        Table structure:
        - processed_unified: surrogate_key, lakefusion_id, exploded_result (struct), exploded_result_id
        - unified: surrogate_key, source_id, dataset (struct), attributes..., record_status
        - master: lakefusion_id, attributes...
        
        In experiment mode, exploded_result has: id, score, reason, lakefusion_id (NO match field)
        """
        # Process filters - EXPERIMENT MODE: No match field, show all results
        where_clause = "WHERE 1=1"
        if filters:
            filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
            if filter_clause:
                where_clause = f"WHERE {filter_clause}"
        
        # Select clause for master attributes
        select_attributes = [f"m.{primary_key_attr}"] + [f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
        select_clause = ", ".join(select_attributes)
        
        # Build JSON object parts - use unified attributes (not lakefusion_id which doesn't exist in unified)
        json_object_parts = []
        for attr in attributes:
            json_object_parts.append(f"'{attr.name}', CAST(dd_unified.{attr.name} AS STRING)")
        
        # Add scoring fields - EXPERIMENT MODE: No match field
        json_object_parts.extend([
            "'__score__', CAST(dd_unified.score AS STRING)",
            "'__sourcename__', CAST(dd_unified.source_path AS STRING)",
            "'__reason__', CAST(dd_unified.reason AS STRING)"
        ])
        
        # Create JSON object
        json_object = f"to_json(map({', '.join(json_object_parts)}))"
        
        # Build subquery select parts
        # Join processed_unified to unified on surrogate_key (not lakefusion_id)
        select_union_parts = [
            "pu.lakefusion_id as master_lakefusion_id",  # The matched master's lakefusion_id
            *[f"unified.{attr.name}" for attr in attributes],  # Attributes from unified table
            "pu.exploded_result.score as score",
            "unified.source_path as source_path",
            "pu.exploded_result.reason as reason"
            # EXPERIMENT MODE: No match field
        ]
        select_union_clause = ", ".join(select_union_parts)
        
        # Group by clause
        group_by_attributes = [
            "dd_unified.master_lakefusion_id",
            f"m.{primary_key_attr}",
            *[f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
        ]
        group_by_clause = ", ".join(group_by_attributes)

        if scoreFilter:
            score_filter = self.build_filter_clauses(scoreFilter, table_prefix="dd_unified")[0]
            if where_clause == "WHERE 1=1":
                where_clause = f"WHERE {score_filter}"
            else:
                where_clause += f" AND {score_filter}"
        
        return f"""
        SELECT
            {select_clause},
            CONCAT('[', ARRAY_JOIN(COLLECT_LIST({json_object}), ','), ']') AS potential_matches,
            COUNT(1) OVER () AS total_count
        FROM (
            SELECT {select_union_clause}
            FROM {self.catalog_name}.silver.{entity_name}_processed_unified_{model_id} pu
            JOIN {self.catalog_name}.silver.{entity_name}_unified_{model_id} unified 
                ON pu.surrogate_key = unified.surrogate_key
            WHERE unified.record_status = 'ACTIVE'
              AND pu.lakefusion_id IS NOT NULL
        ) dd_unified
        JOIN {self.catalog_name}.gold.{entity_name}_master_{model_id} m
            ON m.{primary_key_attr} = dd_unified.master_lakefusion_id
        {where_clause}
        GROUP BY {group_by_clause}
        LIMIT {page_size} OFFSET {offset}"""

    def _build_single_dataset_query_csv(self, entity_name: str, model_id: int, attributes: list,
                                     primary_key_attr: str, page_size: int, offset: int,
                                     filters: Optional[str] = None, scoreFilter: Optional[str] = None) -> str:
        """Build flat SQL query for single dataset CSV download (no JSON aggregation)."""
        where_clause = "WHERE 1=1"
        if filters:
            filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
            if filter_clause:
                where_clause = f"WHERE {filter_clause}"
    
        if scoreFilter:
            score_filter = self.build_filter_clauses(scoreFilter, table_prefix="pu.exploded_result")[0]
            if where_clause == "WHERE 1=1":
                where_clause = f"WHERE {score_filter}"
            else:
                where_clause += f" AND {score_filter}"
    
        # Master columns
        master_cols = [f"m.{primary_key_attr}"] + [f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
    
        # Match columns (from unified) aliased with match_ prefix
        match_cols = [f"unified.{primary_key_attr} AS match_{primary_key_attr}"]
        match_cols += [f"unified.{attr.name} AS match_{attr.name}" for attr in attributes if attr.name != primary_key_attr]
    
        # Score columns
        score_cols = [
            "CAST(pu.exploded_result.score * 100 AS DECIMAL(10,2)) AS match_score",
            "pu.exploded_result.reason AS match_reason"
        ]
    
        select_clause = ", ".join(master_cols + match_cols + score_cols)
    
        return f"""
        SELECT
            {select_clause},
            COUNT(1) OVER () AS total_count
        FROM {self.catalog_name}.silver.{entity_name}_processed_unified_deduplicate_{model_id} pu
        JOIN {self.catalog_name}.silver.{entity_name}_unified_deduplicate_{model_id} unified
            ON pu.query_lakefusion_id = unified.{primary_key_attr}
        JOIN {self.catalog_name}.gold.{entity_name}_master_{model_id} m
            ON m.{primary_key_attr} = pu.match_lakefusion_id
        {where_clause}
        LIMIT {page_size} OFFSET {offset}"""

    
    

    def _build_multiple_dataset_query_csv(self, entity_name: str, model_id: int, attributes: list,
                                               primary_key_attr: str, page_size: int, offset: int,
                                               filters: Optional[str] = None, scoreFilter: Optional[str] = None) -> str:
        """Build flat SQL query for multiple dataset CSV download (no JSON aggregation)."""
        where_clause = "WHERE 1=1"
        if filters:
            filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
            if filter_clause:
                where_clause = f"WHERE {filter_clause}"
    
        if scoreFilter:
            score_filter = self.build_filter_clauses(scoreFilter, table_prefix="dd_unified")[0]
            if where_clause == "WHERE 1=1":
                where_clause = f"WHERE {score_filter}"
            else:
                where_clause += f" AND {score_filter}"
    
        # Master columns
        master_cols = [f"m.{primary_key_attr}"] + [f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
    
        # Match columns from subquery aliased with match_ prefix
        match_cols = [f"dd_unified.{attr.name} AS match_{attr.name}" for attr in attributes]
    
        # Score columns
        score_cols = [
            "dd_unified.score AS match_score",
            "dd_unified.source_path AS match_sourcename",
            "dd_unified.reason AS match_reason"
        ]
    
        select_clause = ", ".join(master_cols + match_cols + score_cols)
    
        # Subquery select parts
        select_union_parts = [
            "pu.lakefusion_id as master_lakefusion_id",
            *[f"unified.{attr.name}" for attr in attributes],
            "CAST(pu.exploded_result.score * 100 AS DECIMAL(10,2)) as score",
            "unified.source_path as source_path",
            "pu.exploded_result.reason as reason"
        ]
        select_union_clause = ", ".join(select_union_parts)
    
        return f"""
        SELECT
            {select_clause},
            COUNT(1) OVER () AS total_count
        FROM (
            SELECT {select_union_clause}
            FROM {self.catalog_name}.silver.{entity_name}_processed_unified_{model_id} pu
            JOIN {self.catalog_name}.silver.{entity_name}_unified_{model_id} unified
                ON pu.surrogate_key = unified.surrogate_key
            WHERE unified.record_status = 'ACTIVE'
              AND pu.lakefusion_id IS NOT NULL
        ) dd_unified
        JOIN {self.catalog_name}.gold.{entity_name}_master_{model_id} m
            ON m.{primary_key_attr} = dd_unified.master_lakefusion_id
        {where_clause}
        LIMIT {page_size} OFFSET {offset}"""

    def build_filter_clauses(self, filters, table_prefix='mp'):
        try:
            if isinstance(filters, str):
                if '%' in filters:
                    try:
                        import urllib.parse
                        filters = urllib.parse.unquote(filters)
                        print(f"URL-decoded filters: {filters}")
                    except Exception as e:
                        app_logger.error(f"Error URL-decoding filters: {str(e)}")
                
                if filters.strip():
                    try:
                        filters = json.loads(filters)
                        print(f"Parsed JSON filters: {filters}")
                    except json.JSONDecodeError as e:
                        app_logger.error(f"Invalid JSON filter string: {e}")
                        return "", []
                else:
                    return "", []
                
            if not filters or not isinstance(filters, list):
                return "", []
            
            def should_quote_value(attribute_type, value):
                """Determine if a value should be quoted based on attribute type"""
                if value is None:
                    return False
                
                attr_type = attribute_type.lower() if attribute_type else ""
                # Date/timestamp types should always be quoted
                date_types = ['date', 'datetime', 'timestamp']
                # Text types should be quoted
                text_types = ['text', 'varchar', 'string', 'char']
                # Numeric types should not be quoted (except for date/timestamp comparisons)
                numeric_types = ['integer', 'numeric', 'number', 'decimal', 'float', 'int', 'bigint', 'double precision']
                
                if attr_type in date_types or attr_type in text_types:
                    return True
                elif attr_type in numeric_types or attr_type == 'boolean':
                    return False
                else:
                    # Default to quoting for safety
                    return True
            
            def format_sql_value(value, attribute_type):
                """Format a value for SQL with proper quoting and escaping"""
                if value is None:
                    return 'NULL'
                
                if should_quote_value(attribute_type, value):
                    # Escape single quotes in the value
                    escaped_val = str(value).replace("'", "''")
                    return f"'{escaped_val}'"
                else:
                    return str(value)
                
            filter_clauses = []
            for i, filter_item in enumerate(filters):
                attribute_name = filter_item.get('attributeName')
                operator = filter_item.get('operator')
                value = filter_item.get('value')
                attribute_type = filter_item.get('attributeType', '')
                conjunction = filter_item.get('conjunction', 'AND')
                
                if not attribute_name or not operator:
                    continue
                    
                column = f"{table_prefix}.{attribute_name}"
                
                sql_clause = ""
                lower_column = f"LOWER({column})"
                lower_value = value.lower() if isinstance(value, str) else value
                
                # Text/String operators - always use quotes for text operations
                if operator == 'eq':  # is equal to
                    sql_clause = f"UPPER({column}) = UPPER('{value}')"
                elif operator == 'neq':  # is not equal to
                    sql_clause = f"UPPER({column}) != UPPER('{value}')"
                elif operator == 'contains':  # contains
                    sql_clause = f"UPPER({column}) LIKE UPPER('%{value}%')"
                elif operator == 'not_contains':  # does not contain
                    sql_clause = f"UPPER({column}) NOT LIKE UPPER('%{value}%')"
                elif operator == 'starts_with':  # starts with
                    sql_clause = f"UPPER({column}) LIKE UPPER('{value}%')"
                elif operator == 'ends_with':  # ends with
                    sql_clause = f"UPPER({column}) LIKE UPPER('%{value}')"
                
                # Numeric/Comparison operators - use proper quoting based on attribute type
                elif operator == 'gt':  # is greater than
                    formatted_value = format_sql_value(value, attribute_type)
                    sql_clause = f"{column} > {formatted_value}"
                elif operator == 'lt':  # is less than
                    formatted_value = format_sql_value(value, attribute_type)
                    sql_clause = f"{column} < {formatted_value}"
                elif operator == 'gte':  # is greater than or equal to
                    formatted_value = format_sql_value(value, attribute_type)
                    sql_clause = f"{column} >= {formatted_value}"
                elif operator == 'lte':  # is less than or equal to
                    formatted_value = format_sql_value(value, attribute_type)
                    sql_clause = f"{column} <= {formatted_value}"
                
                # Null operators
                elif operator == 'is_null':  # is null
                    sql_clause = f"{column} IS NULL"
                elif operator == 'is_not_null':  # is not null
                    sql_clause = f"{column} IS NOT NULL"
                
                # Boolean operators
                elif operator == 'eq_true':  # is true
                    sql_clause = f"{column} = TRUE"
                elif operator == 'eq_false':  # is false
                    sql_clause = f"{column} = FALSE"
                
                if sql_clause:
                    if i > 0:
                        filter_clauses.append(conjunction)
                    filter_clauses.append(sql_clause)
            
            if filter_clauses:
                # Build dynamic filter clause with proper precedence
                # First condition always starts the chain, subsequent conditions build upon it
                if len(filter_clauses) == 1:
                    return filter_clauses[0], []
                
                # For multiple filters, build the expression step by step
                result = filter_clauses[0]  # Start with first condition
                
                for i in range(1, len(filter_clauses), 2):  # Skip every other element (conjunctions)
                    if i + 1 < len(filter_clauses):
                        conjunction = filter_clauses[i]
                        next_clause = filter_clauses[i + 1]
                        
                        if conjunction.upper() == 'OR':
                            # OR creates a new branch: (previous) OR (next)
                            result = f"({result}) OR ({next_clause})"
                        else:
                            # AND extends the current branch: (previous) AND (next)
                            result = f"({result}) AND ({next_clause})"
                
                return result, []
            return "", []
        except Exception as e:
            app_logger.error(f"Error building filter clauses: {str(e)}")
            return "", []
        
    def _is_valid_filter(self, filter_value):
        """Check if filter value is valid (not None, null string, or empty)"""
        if not filter_value:
            return False
        if isinstance(filter_value, str):
            cleaned = filter_value.strip().lower()
            return cleaned and cleaned not in ['null', 'none', 'undefined']
        return True
    
    def fetch_potential_matches_prod(self, entity_id: int, token: str, warehouse_id: str, 
                                    page: int = 1, page_size: int = 1000, 
                                    show_merged: bool = False, filters=None, scoreFilter=None):
        merged_status = (
            "INITIAL_LOAD",
            "JOB_INSERT",
            "JOB_MERGE",
            "MANUAL_MERGE",
            "MASTER_JOB_MERGE",
            "MASTER_MANUAL_MERGE",
            "MASTER_FORCE_MERGE",
            "PROMOTED_TO_MASTER",
            "MERGED",
        )
        try:
            entity_service = EntityService(db=self.db)
            entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
                
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            primary_key_attr = "lakefusion_id"
            if not primary_key_attr:
                raise HTTPException(status_code=400, detail="No primary key attribute found") 

            offset = (page - 1) * page_size
            conn = DataSetSQLService(token, warehouse_id)
            table_name = f"{self.catalog_name}.gold.{entity_name}_master_potential_match_prod"
            
            where_clause = ""
            if self._is_valid_filter(filters):
                filter_clause, _ = self.build_filter_clauses(filters, table_prefix="t")
                if filter_clause:
                    where_clause = f"WHERE {filter_clause}"
            
            if show_merged:
                merge_condition = f"x.__mergestatus__ IN {merged_status}"
                flag_name = "has_merged"
                count_column = "total_merged_count"
            else:
                merge_condition = f"x.__mergestatus__ IS NOT NULL AND x.__mergestatus__ NOT IN {merged_status}"
                flag_name = "has_pending"
                count_column = "total_filtered_count"

            if self._is_valid_filter(scoreFilter):
                score_filter = self.build_filter_clauses(scoreFilter, table_prefix="x")[0]
                merge_condition += f" AND ({score_filter})"            

            base_query = f"""
                WITH filtered_data AS (
                    SELECT 
                        t.*,
                        TO_JSON(t.potential_matches) AS potential_matches_str,
                        CASE 
                            WHEN SIZE(FILTER(t.potential_matches, x -> {merge_condition})) > 0 
                            THEN true ELSE false 
                        END AS {flag_name}
                    FROM {table_name} t
                    {where_clause}
                )
                SELECT fd.*, COUNT(1) OVER () AS {count_column}
                FROM filtered_data fd
                WHERE fd.{flag_name} = true
            """
            print("base_query: ",base_query)
            
            query = f"{base_query} LIMIT {page_size} OFFSET {offset}"
            
            raw_data = conn.execute_dataset(query)
            total_count = raw_data[0][count_column] if raw_data and count_column in raw_data[0] else 0
            
            # Process data
            processed_data = []
            for row in raw_data:
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()
                # Serialize row data to handle Decimal precision
                row_dict = serialize_row_data(row_dict)
                if 'potential_matches_str' in row_dict:
                    row_dict['potential_matches'] = round_floats_in_potential_matches(row_dict['potential_matches_str'])
                    del row_dict['potential_matches_str']
                
                for temp_col in [count_column, flag_name]:
                    if temp_col in row_dict:
                        del row_dict[temp_col]
                    
                processed_data.append(row_dict)
            
            response_data = {
                "data": processed_data,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total_count": total_count,
                    "total_pages": math.ceil(total_count / page_size) if page_size > 0 else 0
                }
            }

            return response_data
            
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch potential matches prod. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch potential matches prod: {str(e)}")
        finally:
            self.db.close()

    def _build_single_dataset_query_csv(self, entity_name: str, model_id: int, attributes: list,
                                     primary_key_attr: str, page_size: int, offset: int,
                                     filters: Optional[str] = None, scoreFilter: Optional[str] = None) -> str:
        """Build flat SQL query for single dataset CSV download (no JSON aggregation)."""
        where_clause = "WHERE 1=1"
        if filters:
            filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
            if filter_clause:
                where_clause = f"WHERE {filter_clause}"
    
        if scoreFilter:
            score_filter = self.build_filter_clauses(scoreFilter, table_prefix="pu.exploded_result")[0]
            if where_clause == "WHERE 1=1":
                where_clause = f"WHERE {score_filter}"
            else:
                where_clause += f" AND {score_filter}"
    
        # Master columns
        master_cols = [f"m.{primary_key_attr}"] + [f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
    
        # Match columns (from unified) aliased with match_ prefix
        match_cols = [f"unified.{primary_key_attr} AS match_{primary_key_attr}"]
        match_cols += [f"unified.{attr.name} AS match_{attr.name}" for attr in attributes if attr.name != primary_key_attr]
    
        # Score columns
        score_cols = [
            "CAST(pu.exploded_result.score * 100 AS DECIMAL(10,2)) AS match_score",
            "pu.exploded_result.reason AS match_reason"
        ]
    
        select_clause = ", ".join(master_cols + match_cols + score_cols)
    
        return f"""
        SELECT
            {select_clause},
            COUNT(1) OVER () AS total_count
        FROM {self.catalog_name}.silver.{entity_name}_processed_unified_deduplicate_{model_id} pu
        JOIN {self.catalog_name}.silver.{entity_name}_unified_deduplicate_{model_id} unified
            ON pu.query_lakefusion_id = unified.{primary_key_attr}
        JOIN {self.catalog_name}.gold.{entity_name}_master_{model_id} m
            ON m.{primary_key_attr} = pu.match_lakefusion_id
        {where_clause}
        LIMIT {page_size} OFFSET {offset}"""

    
    

    def _build_multiple_dataset_query_csv(self, entity_name: str, model_id: int, attributes: list,
                                               primary_key_attr: str, page_size: int, offset: int,
                                               filters: Optional[str] = None, scoreFilter: Optional[str] = None) -> str:
        """Build flat SQL query for multiple dataset CSV download (no JSON aggregation)."""
        where_clause = "WHERE 1=1"
        if filters:
            filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
            if filter_clause:
                where_clause = f"WHERE {filter_clause}"
    
        if scoreFilter:
            score_filter = self.build_filter_clauses(scoreFilter, table_prefix="dd_unified")[0]
            if where_clause == "WHERE 1=1":
                where_clause = f"WHERE {score_filter}"
            else:
                where_clause += f" AND {score_filter}"
    
        # Master columns
        master_cols = [f"m.{primary_key_attr}"] + [f"m.{attr.name}" for attr in attributes if attr.name != primary_key_attr]
    
        # Match columns from subquery aliased with match_ prefix
        match_cols = [f"dd_unified.{attr.name} AS match_{attr.name}" for attr in attributes]
    
        # Score columns
        score_cols = [
            "dd_unified.score AS match_score",
            "dd_unified.source_path AS match_sourcename",
            "dd_unified.reason AS match_reason"
        ]
    
        select_clause = ", ".join(master_cols + match_cols + score_cols)
    
        # Subquery select parts
        select_union_parts = [
            "pu.lakefusion_id as master_lakefusion_id",
            *[f"unified.{attr.name}" for attr in attributes],
            "CAST(pu.exploded_result.score * 100 AS DECIMAL(10,2)) as score",
            "unified.source_path as source_path",
            "pu.exploded_result.reason as reason"
        ]
        select_union_clause = ", ".join(select_union_parts)
    
        return f"""
        SELECT
            {select_clause},
            COUNT(1) OVER () AS total_count
        FROM (
            SELECT {select_union_clause}
            FROM {self.catalog_name}.silver.{entity_name}_processed_unified_{model_id} pu
            JOIN {self.catalog_name}.silver.{entity_name}_unified_{model_id} unified
                ON pu.surrogate_key = unified.surrogate_key
            WHERE unified.record_status = 'ACTIVE'
              AND pu.lakefusion_id IS NOT NULL
        ) dd_unified
        JOIN {self.catalog_name}.gold.{entity_name}_master_{model_id} m
            ON m.{primary_key_attr} = dd_unified.master_lakefusion_id
        {where_clause}
        LIMIT {page_size} OFFSET {offset}"""


    def fetch_potential_matches_download(self, entity_id: int, model_id: int, token: str, warehouse_id: str, 
                            page: int = 1, page_size: int = 1000, filters: Optional[str] = None, 
                            scoreFilter: Optional[str] = None):
        """
        fetch_potential_matches retrieves potential record matches for a given entity
        using a specified matching model. Uses version-based routing to determine
        which query structure to use (legacy vs new pipeline).
        """
        try:
            # Validate input parameters
            if page < 1:
                page = 1
            if page_size < 1:
                page_size = 1000
            if page_size > 10000:  # Set reasonable upper limit
                page_size = 10000
            
            # Get model to check version
            model = self.db.query(Model_Experiment).filter(Model_Experiment.id == model_id).first()
            if not model:
                raise HTTPException(status_code=404, detail="Model not found")
            
            model_version = model.version or "1.0.0"
            use_new_pipeline = is_version_gte(model_version, NEW_PIPELINE_MIN_VERSION)
            
            app_logger.info(f"fetch_potential_matches: model_id={model_id}, version={model_version}, use_new_pipeline={use_new_pipeline}")
                
            # Get entity information
            entity_service = EntityService(db=self.db)
            entity: Optional[Entity] = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
                
            entity_full: Entity = entity_service.get_full_entity_by_id(entity_id=entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            
            if not attributes:
                raise HTTPException(status_code=400, detail="Entity has no attributes defined")
            
            # Count unique datasets
            dataset_id_count = len(Counter(mapping.dataset_id for mapping in entity_full.dataset_mappings))
            primary_key_attr = "lakefusion_id"
            
            # Calculate pagination offset
            offset = (page - 1) * page_size
            
            # Always use the deduplicated table for consistency
            # Build the query based on dataset count
            if dataset_id_count == 1:
                if use_new_pipeline:
                    query = self._build_single_dataset_query_csv(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset, filters, scoreFilter
                    )
               
            else:
                if use_new_pipeline:
                    query = self._build_multiple_dataset_query_csv(
                        entity_name, model_id, attributes, primary_key_attr, 
                        page_size, offset, filters, scoreFilter
                    )
                
            
            # Execute query
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            raw_data = sqlservice_conn.execute_dataset(query)
            # Process results
            total_count = raw_data[0]['total_count'] if raw_data and 'total_count' in raw_data[0] else 0
            
            processed_data = []
            for row in raw_data:
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()
                if 'total_count' in row_dict:
                    del row_dict['total_count']
                processed_data.append(row_dict)

            response_data = {"data": processed_data}

            return response_data
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch potential matches. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch potential matches: {str(e)}")
        finally:
            self.db.close()




    def generate_excel(data: list[dict], sheet_name: str = "Potential Matches") -> io.BytesIO:
        """Convert list of dicts to a styled Excel file in memory."""
        wb = Workbook()
        ws = wb.active
        ws.title = sheet_name
    
        if not data:
            ws.append(["No data found"])
            buf = io.BytesIO()
            wb.save(buf)
            buf.seek(0)
            return buf
    
        # Exclude internal/complex columns if needed
        headers = list(data[0].keys())
    
        # --- Header styling ---
        header_font = Font(bold=True, color="FFFFFF", size=11)
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        thin_border = Border(
            left=Side(style="thin"), right=Side(style="thin"),
            top=Side(style="thin"), bottom=Side(style="thin")
        )
    
        # Write headers
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
            cell.border = thin_border
    
        # Write data rows
        for row_idx, row_data in enumerate(data, 2):
            for col_idx, header in enumerate(headers, 1):
                value = row_data.get(header, "")
                # Serialize complex types (dicts/lists) to JSON strings
                if isinstance(value, (dict, list)):
                    value = json.dumps(value, default=str)
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.border = thin_border
                cell.alignment = Alignment(wrap_text=True)
    
        # Auto-adjust column widths (capped at 50)
        for col_idx, header in enumerate(headers, 1):
            max_len = len(str(header))
            for row in ws.iter_rows(min_row=2, min_col=col_idx, max_col=col_idx):
                for cell in row:
                    if cell.value:
                        max_len = max(max_len, min(len(str(cell.value)), 50))
            ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = max_len + 4
    
        # Freeze header row
        ws.freeze_panes = "A2"
    
        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)
        return buf

    def fetch_dnb_matches_prod(self, entity_id: int, token: str, warehouse_id: str, 
                                    page: int = 1, page_size: int = 1000, 
                                    show_merged: bool = False, filters=None):
        try:
            entity_service = EntityService(db=self.db)
            entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
                
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            primary_key_attr = next((attr for attr in attributes if attr.is_primary_key), None)
            if not primary_key_attr:
                raise HTTPException(status_code=400, detail="No primary key attribute found") 

            offset = (page - 1) * page_size
            conn = DataSetSQLService(token, warehouse_id)
            if(entity.dnb_integration is not None):
                dnb_setting_attributes=entity.dnb_integration.attributesmapping
            else:
                raise HTTPException(status_code=404, detail="DnB Integration is not enabled")
            dnb_table_name = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"
            attribute_names = [attr.name for attr in attributes]
            dnb_table_name=f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"
            master_table_name=f"{self.catalog_name}.gold.{entity_name}_master_prod"
            reverse_mapping = {}
            for source_key, target_value in dnb_setting_attributes.items():
                if target_value == "__none__":
                    reverse_mapping[source_key] = source_key
                else:
                    reverse_mapping[target_value] = source_key
            
            # Step 2: Construct final mapping with all entity attributes
            final_mapping = {
                attr: reverse_mapping.get(attr, None)
                for attr in attribute_names
            }
            select_clause = [
                "a.lakefusion_id",
            ] + [
                f"b.{attr}" if source is None else f"input_{source} AS {attr}"
                for attr, source in final_mapping.items()
            ]
                 
            named_struct_entries =[ "'duns', dnb_duns"]+ [
    f"'{attr}', ifnull(try_cast(dnb_{source} as string), '')" if source is not None else f"'{attr}', ifnull(try_cast(b.{attr} as string), '')"
    for attr, source in final_mapping.items()
    if attr != primary_key_attr.name]
            
            # Add static fields
            named_struct_entries += [
                "'__score__', dnb_confidenceCode",
                "'__mergestatus__', merge_status"
            ]
            
            # Join the struct fields
            named_struct_expr = f"named_struct({', '.join(named_struct_entries)})"
            
            # Wrap in full expression
            json_expr = f"to_json(collect_list(\n    {named_struct_expr}\n)) as potential_matches"
            table_alias = "mp"
            
            where_clause = ""
            if filters:
                filter_clause, _ = self.build_filter_clauses(filters, table_prefix=table_alias)
                if filter_clause:
                    where_clause = f"WHERE {filter_clause}"
            
            if show_merged:

                base_query=f"""SELECT *,COUNT(1) OVER () AS total_count FROM (SELECT {','.join(select_clause)},{json_expr} FROM
                    {dnb_table_name} a LEFT JOIN {master_table_name} b ON a.lakefusion_id = b.lakefusion_id
                    WHERE accepted = true AND merge_status IN ('AUTO_MERGED','MANUAL_MERGE','ACCEPTED') GROUP BY ALL) mp {where_clause}"""

            else:
                base_query=f"""SELECT *,COUNT(1) OVER () AS total_count FROM (SELECT {','.join(select_clause)},{json_expr} FROM
                    {dnb_table_name} a LEFT JOIN {master_table_name} b ON a.lakefusion_id = b.lakefusion_id
                    WHERE accepted = true AND merge_status ='IN_REVIEW' GROUP BY ALL) mp {where_clause}"""
            query = f"{base_query} LIMIT {page_size} OFFSET {offset}"
            
            raw_data = conn.execute_dataset(query)
            
            total_count = raw_data[0]['total_count'] if raw_data and 'total_count' in raw_data[0] else 0
            
            processed_data = []
            for row in raw_data:
                
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()

                # Serialize row data to handle Decimal precision
                row_dict = serialize_row_data(row_dict)
                
                if 'potential_matches_str' in row_dict:
                    row_dict['potential_matches'] = round_floats_in_potential_matches(row_dict['potential_matches_str'])
                    del row_dict['potential_matches_str']
                
                if 'total_count' in row_dict:
                    del row_dict['total_count']
                if 'total_filtered_count' in row_dict:
                    del row_dict['total_filtered_count']
                if 'has_pending' in row_dict:
                    del row_dict['has_pending']
                    
                processed_data.append(row_dict)
                
            
            response_data = {
                "data": processed_data,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total_count": total_count,
                    "total_pages": math.ceil(total_count / page_size) if page_size > 0 else 0
                }
            }
            return response_data
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch DNB matches prod. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch DNB matches prod: {str(e)}")
        finally:
            self.db.close()

    def fetch_potential_matches_deduplicate_prod(self, entity_id: int, token: str, warehouse_id: str, 
                                    page: int = 1, page_size: int = 1000, 
                                    show_merged: bool = False, filters=None, scoreFilter: Optional[str] = None):
        merged_status = (
            "INITIAL_LOAD",
            "JOB_INSERT",
            "JOB_MERGE",
            "MANUAL_MERGE",
            "MASTER_JOB_MERGE",
            "MASTER_MANUAL_MERGE",
            "MASTER_FORCE_MERGE",
            "PROMOTED_TO_MASTER",
            "MERGED",
        )
        try:
            entity_service = EntityService(db=self.db)
            entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
                
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            primary_key_attr = "lakefusion_id"
            if not primary_key_attr:
                raise HTTPException(status_code=400, detail="No primary key attribute found") 

            offset = (page - 1) * page_size
            conn = DataSetSQLService(token, warehouse_id)
            table_name = f"{self.catalog_name}.gold.{entity_name}_master_potential_match_deduplicate_prod"
            
            where_clause = ""
            if filters:
                filter_clause, _ = self.build_filter_clauses(filters, table_prefix="t")
                if filter_clause:
                    where_clause = f"WHERE {filter_clause}"
            
            if show_merged:
                merge_condition = f"x.__mergestatus__ in {merged_status}"
                flag_name = "has_merged"
                count_column = "total_merged_count"
            else:
                merge_condition = f"x.__mergestatus__ IS NOT NULL AND x.__mergestatus__ NOT IN {merged_status}"
                flag_name = "has_pending"
                count_column = "total_filtered_count"

            if self._is_valid_filter(scoreFilter):
                score_filter = self.build_filter_clauses(scoreFilter, table_prefix="x")[0]
                merge_condition += f" AND {score_filter}"

            # Build query
            base_query = f"""
                WITH filtered_data AS (
                    SELECT 
                        t.*,
                        TO_JSON(t.potential_matches) AS potential_matches_str,
                        CASE 
                            WHEN SIZE(FILTER(t.potential_matches, x -> {merge_condition})) > 0 
                            THEN true ELSE false 
                        END AS {flag_name}
                    FROM {table_name} t
                    {where_clause}
                )
                SELECT fd.*, COUNT(1) OVER () AS {count_column}
                FROM filtered_data fd
                WHERE fd.{flag_name} = true
            """
            
            query = f"{base_query} LIMIT {page_size} OFFSET {offset}"
            
            raw_data = conn.execute_dataset(query)
            total_count = raw_data[0][count_column] if raw_data and count_column in raw_data[0] else 0
            
            processed_data = []
            for row in raw_data:
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()

                # Serialize row data to handle Decimal precision
                row_dict = serialize_row_data(row_dict)
                
                if 'potential_matches_str' in row_dict:
                    row_dict['potential_matches'] = round_floats_in_potential_matches(row_dict['potential_matches_str'])
                    del row_dict['potential_matches_str']
                
                for temp_col in [count_column, flag_name]:
                    if temp_col in row_dict:
                        del row_dict[temp_col]
                    
                processed_data.append(row_dict)
            
            response_data = {
                "data": processed_data,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total_count": total_count,
                    "total_pages": math.ceil(total_count / page_size) if page_size > 0 else 0
                }
            }
            return response_data
            
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch potential matches deduplicate prod. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch potential matches deduplicate prod: {str(e)}")
        finally:
            self.db.close()

    def fetch_profile_potential_matches(self, entity_id: int, profile_id: str, token: str, warehouse_id: str):
        try:
            entity_service = EntityService(db=self.db)
            entity: Entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            primary_key_attr = "lakefusion_id"
            if not primary_key_attr:
                raise HTTPException(status_code=400, detail="No primary key attribute found")
                    
            filter_condition = f"WHERE mp.{primary_key_attr}='{profile_id}'"
            attribute_names = [attr.name for attr in attributes if attr.show_in_ui]

            required_fields = set(attribute_names)
            required_fields.add('lakefusion_id')
            
            json_object_parts = []

            for field_name in sorted(required_fields):
                json_object_parts.append(f"'{field_name}', CAST(x.{field_name} AS STRING)")
            
            json_object_parts.extend([
                "'__score__', CAST(x.__score__ AS STRING)",
                "'__sourcename__', CAST(x.__sourcename__ AS STRING)",
                "'__sourceid__', CAST(x.__sourceid__ AS STRING)",
                "'__reason__', CAST(x.__reason__ AS STRING)",
                "'__mergestatus__', CAST(x.__mergestatus__ AS STRING)"
            ])
            
            json_object = f"to_json(map({', '.join(json_object_parts)}))"
            
            query = f"""
                SELECT 
                    mp.*,
                    CONCAT('[', ARRAY_JOIN(TRANSFORM(mp.potential_matches, x -> {json_object}), ','), ']') AS potential_matches_str
                FROM {self.catalog_name}.gold.{entity_name}_master_potential_match_prod mp 
                {filter_condition}
                LIMIT 1
            """
            
            def execute_query(sql):
                conn = DataSetSQLService(token, warehouse_id)
                return conn.execute_dataset(sql)
            
            raw_data = execute_query(query)
            
            processed_data = []
            for row in raw_data:
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()
                # Serialize row data to handle Decimal precision
                row_dict = serialize_row_data(row_dict)
                if 'potential_matches_str' in row_dict:
                    row_dict['potential_matches'] = round_floats_in_potential_matches(row_dict['potential_matches_str'])
                    del row_dict['potential_matches_str']
                            
                processed_data.append(row_dict)
            
            return processed_data
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch profile potential matches. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch profile potential matches: {str(e)}")
        finally:
            self.db.close()

    def fetch_profile_potential_matches_updated(self, entity_id: int, profile_id: str, token: str, warehouse_id: str):
        try:
            entity_service = EntityService(db=self.db)
            entity: Entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            primary_key_attr = "lakefusion_id"
            if not primary_key_attr:
                raise HTTPException(status_code=400, detail="No primary key attribute found")
                    
            filter_condition = f"WHERE mp.{primary_key_attr}='{profile_id}'"
            attribute_names = [attr.name for attr in attributes if attr.show_in_ui]

            # Build select clause for master record columns
            required_fields = set(attribute_names)
            required_fields.add('lakefusion_id')
            
            # Select master record columns
            select_fields = [f"mp.{field}" for field in sorted(required_fields)]
            select_fields.append("mp.attributes_combined")
            select_fields.append("mp.tags")
            
            # Build JSON transformation for potential_matches array
            # NOTE: lakefusion_id is NOT in the array elements, only entity attributes
            json_object_parts = []
            
            # Add only entity attributes (NOT lakefusion_id)
            for field_name in sorted(attribute_names):
                json_object_parts.append(f"'{field_name}', CAST(x.{field_name} AS STRING)")
            
            # Add metadata fields
            json_object_parts.extend([
                "'__score__', CAST(x.__score__ AS STRING)",
                "'__source_path__', CAST(x.__source_path__ AS STRING)",
                "'__source_id__', CAST(x.__source_id__ AS STRING)",
                "'surrogate_key', CAST(x.surrogate_key AS STRING)",
                "'__reason__', CAST(x.__reason__ AS STRING)",
                "'__mergestatus__', CAST(x.__mergestatus__ AS STRING)"
            ])
            
            json_object = f"to_json(map({', '.join(json_object_parts)}))"
            
            query = f"""
                SELECT 
                    {', '.join(select_fields)},
                    CONCAT('[', ARRAY_JOIN(TRANSFORM(mp.potential_matches, x -> {json_object}), ','), ']') AS potential_matches_json
                FROM {self.catalog_name}.gold.{entity_name}_master_potential_match_prod mp 
                {filter_condition}
                LIMIT 1
            """
            
            def execute_query(sql):
                conn = DataSetSQLService(token, warehouse_id)
                return conn.execute_dataset(sql)
            
            raw_data = execute_query(query)
            
            processed_data = []
            for row in raw_data:
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()
                
                # Serialize row data to handle Decimal precision
                row_dict = serialize_row_data(row_dict)
                # Replace potential_matches with the JSON string version
                if 'potential_matches_json' in row_dict:
                    row_dict['potential_matches'] = round_floats_in_potential_matches(row_dict['potential_matches_json'])
                    del row_dict['potential_matches_json']
                            
                processed_data.append(row_dict)
            
            return processed_data
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch profile potential matches. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch profile potential matches: {str(e)}")
        finally:
            self.db.close()

    def fetch_profile_potential_matches_dnbintegration(self, entity_id: int, profile_id: str, token: str, warehouse_id: str):
        try:
            entity_service = EntityService(db=self.db)
            entity: Entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            if(entity.dnb_integration is not None):
                dnb_setting_attributes=entity.dnb_integration.attributesmapping
            else:
                raise HTTPException(status_code=404, detail="DnB Integration is not enabled")
            primary_key_attr = next((attr for attr in attributes if attr.is_primary_key), None)
            if not primary_key_attr:
                raise HTTPException(status_code=400, detail="No primary key attribute found")
                    
            filter_condition = f"WHERE mp.{primary_key_attr.name}='{profile_id}'"
            attribute_names = [attr.name for attr in attributes]
            dnb_table_name=f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"
            master_table_name=f"{self.catalog_name}.gold.{entity_name}_master_prod"
            reverse_mapping = {}
            for source_key, target_value in dnb_setting_attributes.items():
                if target_value == "__none__":
                    reverse_mapping[source_key] = source_key
                else:
                    reverse_mapping[target_value] = source_key
            
            # Step 2: Construct final mapping with all entity attributes
            final_mapping = {
                attr: reverse_mapping.get(attr, None)
                for attr in attribute_names
            }
            select_clause = [
                "a.lakefusion_id",
            ] + [
                f"b.{attr}" if source is None else f"input_{source} AS {attr}"
                for attr, source in final_mapping.items()
            ]
            named_struct_entries =[ "'duns', dnb_duns"]+ [
    f"'{attr}', ifnull(try_cast(dnb_{source} as string), '')" if source is not None else f"'{attr}', ifnull(try_cast(b.{attr} as string), '')"
    for attr, source in final_mapping.items()
    if attr != primary_key_attr.name]
            
            
            # Add static fields
            named_struct_entries += [
                "'__score__', dnb_confidenceCode",
                "'__mergestatus__', merge_status"
            ]
            
            # Join the struct fields
            named_struct_expr = f"named_struct({', '.join(named_struct_entries)})"
            
            # Wrap in full expression
            json_expr = f"to_json(collect_list(\n    {named_struct_expr}\n)) as potential_matches"

            query=f"""SELECT {','.join(select_clause)},{json_expr} FROM
                    {dnb_table_name} a LEFT JOIN {master_table_name} b ON a.lakefusion_id = b.lakefusion_id
                    WHERE accepted = true AND a.lakefusion_id = '{profile_id}' GROUP BY ALL"""
            
            def execute_query(sql):
                conn = DataSetSQLService(token, warehouse_id)
                return conn.execute_dataset(sql)
            
            raw_data = execute_query(query)
            
            processed_data = []
            for row in raw_data:
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()
                # Serialize row data to handle Decimal precision
                row_dict = serialize_row_data(row_dict)
                
                if 'potential_matches_str' in row_dict:
                    row_dict['potential_matches'] = round_floats_in_potential_matches(row_dict['potential_matches_str'])
                    del row_dict['potential_matches_str']
                            
                processed_data.append(row_dict)
            
            return processed_data
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch profile potential matches DNB integration. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch profile potential matches DNB integration: {str(e)}")
        finally:
            self.db.close()

    def fetch_profile_dnb_hierarchy_enrichment(self, entity_id: int, profile_id: str, token: str, warehouse_id: str):
        try:
            entity_service = EntityService(db=self.db)
            entity: Entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
            entity_name = entity.name.lower().replace(' ', '_')
            enrichment_table = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_enrichment"

            query = f"""SELECT enrichment_data, enriched_at
                FROM {enrichment_table}
                WHERE lakefusion_id = '{profile_id}' AND enrichment_type = 'hierarchy'
                ORDER BY enriched_at DESC LIMIT 1"""

            def execute_query(sql):
                conn = DataSetSQLService(token, warehouse_id)
                return conn.execute_dataset(sql)

            raw_data = execute_query(query)

            if raw_data and len(raw_data) > 0:
                row = dict(raw_data[0]) if not isinstance(raw_data[0], dict) else raw_data[0]
                enrichment_data = row.get('enrichment_data', None)
                enriched_at = row.get('enriched_at', None)
                if enrichment_data and isinstance(enrichment_data, str):
                    import json
                    enrichment_data = json.loads(enrichment_data)
                return {"hierarchy": enrichment_data, "enriched_at": str(enriched_at) if enriched_at else None}
            else:
                return {"hierarchy": None, "enriched_at": None}
        except HTTPException:
            raise
        except Exception as e:
            app_logger.warning(f'D&B hierarchy enrichment not available for profile {profile_id}: {str(e)}')
            return {"hierarchy": None, "enriched_at": None}
        finally:
            self.db.close()

    def fetch_profile_potential_matches_deduplicate(self, entity_id: int, profile_id: str, token: str, warehouse_id: str):
        try:
            entity_service = EntityService(db=self.db)
            entity: Entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
            entity_name = entity.name.lower().replace(' ', '_')
            attributes = entity.attributes
            primary_key_attr = "lakefusion_id"
            if not primary_key_attr:
                raise HTTPException(status_code=400, detail="No primary key attribute found")
                    
            filter_condition = f"WHERE mp.{primary_key_attr}='{profile_id}'"
            attribute_names = [attr.name for attr in attributes if attr.show_in_ui]

            json_object_parts = []
            for attr_name in attribute_names:
                json_object_parts.append(f"'{attr_name}', CAST(x.{attr_name} AS STRING)")
            
            json_object_parts.extend([
                "'lakefusion_id', CAST(x.lakefusion_id AS STRING)",
                "'__score__', CAST(x.__score__ AS STRING)",
                "'__reason__', CAST(x.__reason__ AS STRING)",
                "'__mergestatus__', CAST(x.__mergestatus__ AS STRING)"
            ])
            
            json_object = f"to_json(map({', '.join(json_object_parts)}))"
            
            query = f"""
                SELECT 
                    mp.*,
                    CONCAT('[', ARRAY_JOIN(TRANSFORM(mp.potential_matches, x -> {json_object}), ','), ']') AS potential_matches_str
                FROM {self.catalog_name}.gold.{entity_name}_master_potential_match_deduplicate_prod mp 
                {filter_condition}
                LIMIT 1
            """
            
            def execute_query(sql):
                conn = DataSetSQLService(token, warehouse_id)
                return conn.execute_dataset(sql)
            
            raw_data = execute_query(query)
            
            processed_data = []
            for row in raw_data:
                row_dict = dict(row) if not isinstance(row, dict) else row.copy()
                # Serialize row data to handle Decimal precision
                row_dict = serialize_row_data(row_dict)
                
                if 'potential_matches_str' in row_dict:
                    row_dict['potential_matches'] = round_floats_in_potential_matches(row_dict['potential_matches_str'])
                    del row_dict['potential_matches_str']
                            
                processed_data.append(row_dict)
            
            return processed_data
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch profile potential matches deduplicate. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch profile potential matches deduplicate: {str(e)}")
        finally:
            self.db.close()
    
    def get_lineage_link(self, entity_id: int, token: str, warehouse_id: str):
        """
        Get the lineage link for the entity's master table in Databricks.
        
        Args:
            entity_id (int): The ID of the entity
            token (str): Authentication token for databricks
            warehouse_id (str): The ID of the warehouse
            
        Returns:
            dict: A dictionary containing the lineage link
        """
        try:
            entity_service = EntityService(db=self.db)
            entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")
                
            entity_name = entity.name.lower().replace(' ', '_')
            
            # Construct the Databricks lineage link
            lineage_link = f"{DATABRICKS_HOST}/explore/data/{self.catalog_name}/gold/{entity_name}_master_prod?activeTab=lineage"
            
            return {"lineage_link": lineage_link}
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch lineage link. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch lineage link: {str(e)}")
    
    def get_base_instructions(self):
        return self.db_config_service.getDBConfigProperties(key="default_prompt")
        
    
class Model_Databricks_Job_Service:
    def __init__(self, db: Session):
        self.db = db
        self.db_config_service = DBConfigPropertiesService(db=self.db)

    def _construct_job_link(self, job_id: str, job_run_id: str) -> str:
        """
        Construct a Databricks job link for the given job ID and job run ID.
        """
        if not job_id or not job_run_id:
            return None
        return f"{DATABRICKS_HOST}/#job/{job_id}/run/{job_run_id}"

    def _is_mdm_restructuring_enabled(self) -> bool:
        """
        Check if the MDM_RESTRUCTURING feature flag is enabled.
        
        Returns:
            bool: True if the feature flag is enabled, False otherwise.
        """
        return FeatureFlagService._is_feature_flag_enabled(
            self.db,
            'MDM_RESTRUCTURING'
        )

    def get_job_run_status(self,job_run_id:str,token:str):
        try:
            job_service = DatabricksJobManager(token)
            job_response=job_service.get_job_run_status(job_run_id)
            return job_response

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to get job run status. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to get job run status: {str(e)}")

    def create_tasks_and_job_experiment(self, entity_id, model_id, process_records=Optional[list[int]], existing_cluster=None, is_initial_load=True):
        """
        Creates the task list for the NEW experiment pipeline (MDM_RESTRUCTURING enabled).
        
        Uses unified experiment notebooks that handle both single-source and multi-source:
        - Entity_Matching_Vector_Search_Experiment (handles golden/normal dedup internally)
        - Entity_Matching_LLM_Experiment (handles golden/normal dedup internally, no thresholds)
        - Process_Potential_Match_Experiment (shows all matches for analysis)
        
        INITIAL LOAD FLOW (sequential):
        ================================
        Parse → Check_Master → Is_Initial_Load[TRUE] → [Endpoint Creation] → Create_Tables 
            → Load_Data → Endpoints_Mapping → VS_Experiment → LLM_Experiment 
            → Process_Potential_Match_Experiment → Resource_Tagging
        
        INCREMENTAL LOAD FLOW:
        ======================
        Parse → Check_Master → Is_Initial_Load[FALSE] → Load_Data → Endpoints_Mapping 
            → VS_Experiment → LLM_Experiment → Process_Potential_Match_Experiment → Resource_Tagging
        
        Args:
            entity_id: Entity ID
            model_id: Model/Experiment ID
            process_records: Record range [start, end]
            existing_cluster: Existing cluster ID (optional)
            is_initial_load: Whether this is an initial load (creates tables + endpoints)
            
        Returns:
            List containing [tasks_list, parameters, job_cluster, job_parameters]
        """
        catalog_name = (self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "catalog_name").first().config_value)
        notebook_folder_path = self.db_config_service.getDBConfigProperties(key="notebook_path")
        job_cluster = None

        tags = get_resource_tags()
        if tags is None:
            tags = {}
        existing_cluster_value = existing_cluster
        
        parameters = {
            "entity_id": str(entity_id), 
            "experiment_id": str(model_id), 
            "processed_records": str(process_records), 
            "is_integration_hub": "0",
            "catalog_name": str(catalog_name)
        }
        
        # =====================================================================
        # BUILD TASK LIST FOR NEW EXPERIMENT PIPELINE
        # =====================================================================
        tasks_list = []
        
        # -----------------------------------------------------------------
        # Task 1: Parse_Entity_Model_JSON
        # Location: integration-core
        # -----------------------------------------------------------------
        tasks_list.append(
            Task(
                task_key="Parse_Entity_Model_JSON",
                existing_cluster_id=existing_cluster_value,
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # -----------------------------------------------------------------
        # Task 2: Check_Master_Exists
        # Location: integration-core
        # Outputs: is_initial_load (true if master doesn't exist, false if exists)
        # -----------------------------------------------------------------
        tasks_list.append(
            Task(
                task_key="Check_Master_Exists",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/integration-core/Check_Master_Exists",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Check_Master_Exists",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # -----------------------------------------------------------------
        # Task 3: Is_Initial_Load_Check
        # Checks: is_initial_load == "true" (master doesn't exist)
        # -----------------------------------------------------------------
        tasks_list.append(
            Task(
                task_key="Is_Initial_Load_Check",
                depends_on=[TaskDependency(task_key="Check_Master_Exists")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Check_Master_Exists.values.is_initial_load}}",
                    right="true"
                ),
                timeout_seconds=0,
            )
        )
        
        # -----------------------------------------------------------------
        # ENDPOINT CREATION BLOCK (INITIAL LOAD ONLY)
        # These run FIRST after Is_Initial_Load_Check=true
        # All 4 checks can run in parallel, then their respective endpoints
        # -----------------------------------------------------------------
        
        # Embedding Foundational Check
        tasks_list.append(
            Task(
                task_key="Embedding_Foundational_Model_Serving_Endpoint_Check",
                depends_on=[
                    TaskDependency(task_key="Is_Initial_Load_Check", outcome=True),
                ],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.embedding_model_source}}",
                    right="databricks_foundation"
                ),
                timeout_seconds=0,
            )
        )
        
        # Embedding Foundational Endpoint
        tasks_list.append(
            Task(
                task_key="Embedding_Foundational_Serving_Endpoint",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Embedding_Foundational_Model_Serving_Endpoint_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Embedding Foundational",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Embedding Foundational",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # Embedding HuggingFace Check
        tasks_list.append(
            Task(
                task_key="Embedding_Model_Serving_Endpoint_Check",
                depends_on=[
                    TaskDependency(task_key="Is_Initial_Load_Check", outcome=True),
                ],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.embedding_model_source}}",
                    right="databricks_custom_hugging_face"
                ),
                timeout_seconds=0,
            )
        )
        
        # Embedding HuggingFace Endpoint
        tasks_list.append(
            Task(
                task_key="Embedding_Hugging_Face_Serving_Endpoint",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Embedding_Model_Serving_Endpoint_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Embeddings Hugging Face",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Embeddings Hugging Face",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # LLM Foundational Check
        tasks_list.append(
            Task(
                task_key="LLM_Foundational_Model_Serving_Endpoint_Check",
                depends_on=[
                    TaskDependency(task_key="Is_Initial_Load_Check", outcome=True),
                ],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.llm_model_source}}",
                    right="databricks_foundation"
                ),
                timeout_seconds=0,
            )
        )
        
        # LLM Foundational Endpoint
        tasks_list.append(
            Task(
                task_key="LLM_Foundational_Serving_Endpoint",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="LLM_Foundational_Model_Serving_Endpoint_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/LLM Foundational",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/LLM Foundational",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # LLM HuggingFace Check
        tasks_list.append(
            Task(
                task_key="LLM_Model_Serving_Endpoint_Check",
                depends_on=[
                    TaskDependency(task_key="Is_Initial_Load_Check", outcome=True),
                ],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.llm_model_source}}",
                    right="databricks_custom_hugging_face"
                ),
                timeout_seconds=0,
            )
        )
        
        # LLM HuggingFace Endpoint
        tasks_list.append(
            Task(
                task_key="LLM_Hugging_Face_Serving_Endpoint",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="LLM_Model_Serving_Endpoint_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/LLM Hugging Face",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/LLM Hugging Face",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # -----------------------------------------------------------------
        # Create_Tables_Experiment (INITIAL LOAD ONLY)
        # Location: match-maven
        # Runs AFTER all endpoint creation is complete
        # -----------------------------------------------------------------
        tasks_list.append(
            Task(
                task_key="Create_Tables_Experiment",
                existing_cluster_id=existing_cluster_value,
                depends_on=[
                    # Wait for all endpoint tasks to complete (executed or skipped)
                    TaskDependency(task_key="Embedding_Foundational_Serving_Endpoint"),
                    TaskDependency(task_key="Embedding_Foundational_Model_Serving_Endpoint_Check", outcome=False),
                    TaskDependency(task_key="Embedding_Hugging_Face_Serving_Endpoint"),
                    TaskDependency(task_key="Embedding_Model_Serving_Endpoint_Check", outcome=False),
                    TaskDependency(task_key="LLM_Foundational_Serving_Endpoint"),
                    TaskDependency(task_key="LLM_Foundational_Model_Serving_Endpoint_Check", outcome=False),
                    TaskDependency(task_key="LLM_Hugging_Face_Serving_Endpoint"),
                    TaskDependency(task_key="LLM_Model_Serving_Endpoint_Check", outcome=False),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/integration-core/match_maven/Create_Tables_Experiment",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/match_maven/Create_Tables_Experiment",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # -----------------------------------------------------------------
        # Load_Experiment_Data
        # Location: match-maven
        # Initial: depends on Create_Tables_Experiment
        # Incremental: depends on Is_Initial_Load_Check=false (skips endpoints + create)
        # -----------------------------------------------------------------
        tasks_list.append(
            Task(
                task_key="Load_Experiment_Data",
                existing_cluster_id=existing_cluster_value,
                depends_on=[
                    TaskDependency(task_key="Create_Tables_Experiment"),
                    TaskDependency(task_key="Is_Initial_Load_Check", outcome=False),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/integration-core/match_maven/Load_Experiment_Data",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/match_maven/Load_Experiment_Data",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # -----------------------------------------------------------------
        # Endpoints_Mapping
        # Location: maven-core
        # Runs after Load_Experiment_Data
        # -----------------------------------------------------------------
        tasks_list.append(
            Task(
                task_key="Endpoints_Mapping",
                existing_cluster_id=existing_cluster_value,
                depends_on=[
                    TaskDependency(task_key="Load_Experiment_Data"),
                ],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Endpoints Mapping",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Endpoints Mapping",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # -----------------------------------------------------------------
        # Entity_Matching_Vector_Search_Experiment
        # Location: match-maven
        # Unified notebook handles both single-source (golden) and multi-source (normal)
        # For single-source: clones master to unified_dedup internally
        # -----------------------------------------------------------------
        tasks_list.append(
            Task(
                task_key="Entity_Matching_Vector_Search_Experiment",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Endpoints_Mapping")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/integration-core/match_maven/Entity_Matching_Vector_Search_Experiment",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/match_maven/Entity_Matching_Vector_Search_Experiment",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        tasks_list.append(
            Task(
                task_key="Entity_Matching_Detereministic_Experiment",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Entity_Matching_Vector_Search_Experiment")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/integration-core/match_maven/Entity_Matching_Vector_Search_Experiment",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/match_maven/Process_Deterministic_Experiment",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        # -----------------------------------------------------------------
        # Entity_Matching_LLM_Experiment
        # Location: match-maven
        # Unified notebook handles both single-source and multi-source
        # NO threshold classification - returns all scores for analysis
        # -----------------------------------------------------------------
        tasks_list.append(
            Task(
                task_key="Entity_Matching_LLM_Experiment",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Entity_Matching_Detereministic_Experiment")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/integration-core/match_maven/Entity_Matching_LLM_Experiment",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/match_maven/Entity_Matching_LLM_Experiment",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # -----------------------------------------------------------------
        # Process_Potential_Match_Experiment
        # Location: match-maven
        # Shows ALL matches for experiment analysis (no filtering)
        # -----------------------------------------------------------------
        tasks_list.append(
            Task(
                task_key="Process_Potential_Match_Experiment",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Entity_Matching_LLM_Experiment")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/integration-core/match_maven/Process_Potential_Match_Experiment",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/match_maven/Process_Potential_Match_Experiment",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        tasks_list.append(
            Task(
                task_key="Process_Deterministic_Potential_Match_Experiment",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Entity_Matching_LLM_Experiment")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/integration-core/match_maven/Process_Potential_Match_Experiment",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/match_maven/Process_Deterministic_Potential_Match_Experiment",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # -----------------------------------------------------------------
        # Resource_Tagging
        # Location: maven-core
        # -----------------------------------------------------------------
        tasks_list.append(
            Task(
                task_key="Resource_Tagging",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Experiment")],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Resource Tagging",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Resource Tagging",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        )
        
        # -----------------------------------------------------------------
        # Job Parameters
        # -----------------------------------------------------------------
        job_parameters = [
            JobParameter(name="entity_id", default=str(entity_id)),
            JobParameter(name="experiment_id", default=str(model_id)),
            JobParameter(name="processed_records", default=str(process_records)),
            JobParameter(name="is_integration_hub", default="0"),
            JobParameter(name="catalog_name", default=str(catalog_name)),
            JobParameter(name="to_emails", default=""),
        ]
        
        return [tasks_list, parameters, job_cluster, job_parameters]
            
    def create_tasks_and_job(self,entity_id,model_id,process_records=Optional[list[int]],existing_cluster=None):
        catalog_name=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "catalog_name").first().config_value)
        notebook_folder_path=self.db_config_service.getDBConfigProperties(key="notebook_path")
        job_cluster=None

        tags = get_resource_tags()
        if tags is None:
            tags = {}
        job_cluster_key_value = None
        existing_cluster_value = existing_cluster
        
        parameters = {"entity_id": str(entity_id), "experiment_id": str(model_id), "processed_records": str(process_records), "is_integration_hub": "0","catalog_name":str(catalog_name)}
                
        tasks_list = [
            Task(
                task_key="Parse_Entity_Model_JSON",
                existing_cluster_id=existing_cluster_value,
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Is_Master_Deduplication",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.is_golden_deduplication}}",
                    right="1"
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Prepare_Tables_DeDuplicate",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Is_Master_Deduplication", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{notebook_folder_path}/src/maven-core-deduplication/Prepare Tables",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Prepare_Tables",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Is_Master_Deduplication", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Prepare Tables",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Prepare Tables",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Match_Maven_Job",
                depends_on=[
                    TaskDependency(task_key="Prepare_Tables"),
                    TaskDependency(task_key="Prepare_Tables_DeDuplicate")
                ],
                run_if=RunIf.NONE_FAILED,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.NOT_EQUAL,
                    left="{{job.parameters.experiment_id}}",
                    right="prod"
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Check_Incremental_Load",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Match_Maven_Job", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Check_Incremental_load",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Check_Incremental_load",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Incremental_Load_Job",
                depends_on=[TaskDependency(task_key="Check_Incremental_Load")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Check_Incremental_Load.values.incremental_load}}",
                    right="true"
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Embedding_Foundational_Model_Serving_Endpoint_Check",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.embedding_model_source}}",
                    right="databricks_foundation"
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Embedding_Foundational_Serving_Endpoint",
                depends_on=[TaskDependency(task_key="Embedding_Foundational_Model_Serving_Endpoint_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Embedding Foundational",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Embedding Foundational",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                job_cluster_key=job_cluster_key_value,
                existing_cluster_id=existing_cluster_value,
                timeout_seconds=0,
            ),
            Task(
                task_key="Embedding_Model_Serving_Endpoint_Check",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.embedding_model_source}}",
                    right="databricks_custom_hugging_face"
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Embedding_Hugging_Face_Serving_Endpoint",
                depends_on=[TaskDependency(task_key="Embedding_Model_Serving_Endpoint_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Embeddings Hugging Face",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Embeddings Hugging Face",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                job_cluster_key=job_cluster_key_value,
                existing_cluster_id=existing_cluster_value,
                timeout_seconds=0,
            ),
            Task(
                task_key="LLM_Foundational_Model_Serving_Endpoint_Check",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.llm_model_source}}",
                    right="databricks_foundation"
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="LLM_Foundational_Serving_Endpoint",
                depends_on=[TaskDependency(task_key="LLM_Foundational_Model_Serving_Endpoint_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/LLM Foundational",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/LLM Foundational",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                job_cluster_key=job_cluster_key_value,
                existing_cluster_id=existing_cluster_value,
                timeout_seconds=0,
            ),
            Task(
                task_key="LLM_Model_Serving_Endpoint_Check",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.llm_model_source}}",
                    right="databricks_custom_hugging_face"
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="LLM_Hugging_Face_Serving_Endpoint",
                depends_on=[TaskDependency(task_key="LLM_Model_Serving_Endpoint_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/LLM Hugging Face",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/LLM Hugging Face",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                job_cluster_key=job_cluster_key_value,
                existing_cluster_id=existing_cluster_value,
                timeout_seconds=0,
            ),
            Task(
                task_key="Endpoints_Mapping",
                existing_cluster_id=existing_cluster_value,
                depends_on=[
                    TaskDependency(task_key="Incremental_Load_Job", outcome=True),
                    TaskDependency(task_key="Match_Maven_Job", outcome=False),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Endpoints Mapping",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Endpoints Mapping",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Is_Master_Deduplication_VS",
                depends_on=[
                    TaskDependency(task_key="Check_Incremental_Load"),
                    TaskDependency(task_key="Parse_Entity_Model_JSON"),
                    TaskDependency(task_key="Embedding_Model_Serving_Endpoint_Check", outcome=False),
                    TaskDependency(task_key="Endpoints_Mapping"),
                    TaskDependency(task_key="Embedding_Hugging_Face_Serving_Endpoint"),
                    TaskDependency(task_key="Embedding_Foundational_Model_Serving_Endpoint_Check", outcome=False),
                    TaskDependency(task_key="LLM_Foundational_Serving_Endpoint"),
                    TaskDependency(task_key="Embedding_Foundational_Serving_Endpoint"),
                    TaskDependency(task_key="LLM_Hugging_Face_Serving_Endpoint"),
                    TaskDependency(task_key="LLM_Foundational_Model_Serving_Endpoint_Check", outcome=False),
                ],
                run_if=RunIf.NONE_FAILED,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.is_golden_deduplication}}",
                    right="1"
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Entity_Matching_Vector_Search_DeDuplicate",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Is_Master_Deduplication_VS", outcome=True)],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{notebook_folder_path}/src/maven-core-deduplication/Entity Matching - Vector Search",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Entity_Matching_LLM_DeDuplicate",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Entity_Matching_Vector_Search_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{notebook_folder_path}/src/maven-core-deduplication/Entity Matching - LLM",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Entity_Matching_LLM_DeDuplicate_New",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Entity_Matching_Vector_Search_DeDuplicate_New")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{notebook_folder_path}/src/maven-core-deduplication/Entity Matching - LLM",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Entity_Matching_Vector_Search",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Is_Master_Deduplication_VS", outcome=False)],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Entity Matching - Vector Search",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Entity Matching - Vector Search",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Entity_Matching_LLM",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Entity_Matching_Vector_Search")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Entity Matching - LLM",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Entity Matching - LLM",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Prepare_Tables_DeDuplicate_New",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Entity_Matching_LLM")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{notebook_folder_path}/src/maven-core-deduplication/Prepare Tables",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Entity_Matching_Vector_Search_DeDuplicate_New",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Prepare_Tables_DeDuplicate_New")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{notebook_folder_path}/src/maven-core-deduplication/Entity Matching - Vector Search",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Merge_Records_Check",
                depends_on=[
                    TaskDependency(task_key="Entity_Matching_LLM"),
                    TaskDependency(task_key="Entity_Matching_LLM_DeDuplicate"),
                ],
                run_if=RunIf.NONE_FAILED,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{job.parameters.experiment_id}}",
                    right="prod"
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Match_Merge_Records",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Merge_Records_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Process Match - Merge Records",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Match - Merge Records",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Unmatched_Records",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Process_Match_Merge_Records")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Process Unmatched Records",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Unmatched Records",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Validation_Warning_Records",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Process_Unmatched_Records")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Process Validation Warning Records",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Validation Warning Records",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Send_Email_Notification",
                existing_cluster_id=existing_cluster_value,
                depends_on=[TaskDependency(task_key="Process_Unmatched_Records")],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Send Email Notification",
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Send Email Notification",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Resource_Tagging",
                depends_on=[
                    TaskDependency(task_key="Send_Email_Notification"),
                    TaskDependency(task_key="Entity_Matching_LLM_DeDuplicate_New")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{notebook_folder_path}/src/maven-core/Resource Tagging",  # New task
                    notebook_path=f"{notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Resource Tagging",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        ]
        job_parameters = [
        JobParameter(
            name="entity_id",
            default=str(entity_id)
        ),
        JobParameter(
            name="experiment_id",
            default=str(model_id)
        ),
        JobParameter(
            name="processed_records",
            default=str(process_records)
        ),
        JobParameter(
            name="is_integration_hub",
            default="0"
        ),
        JobParameter(
            name="catalog_name",
            default=str(catalog_name)
        ),

        JobParameter(
            name="to_emails",
            default=""
        )]  
        return [tasks_list,parameters,job_cluster,job_parameters]
    def _try_reset_or_create_job(self, job_service, job_id, entity_name, task_list_response, lakefusion_spn, existing_cluster):
        """
        Try to reset an existing job. If the job doesn't exist in Databricks, create a new one.
        
        Args:
            job_service: DatabricksJobManager instance
            job_id: Existing job ID to try to reset
            entity_name: Name for the job
            task_list_response: Task list from create_tasks_and_job or create_tasks_and_job_experiment
            lakefusion_spn: Service principal for RunAs
            existing_cluster: Existing cluster ID (optional)
            
        Returns:
            tuple: (job_id, is_new_job) - the job ID to use and whether a new job was created
        """
        from databricks.sdk.errors.platform import InvalidParameterValue
        
        try:
            # Try to reset the existing job
            if existing_cluster is None:
                job_service.reset_job(
                    job_id=job_id,
                    name=f"Match_Maven-{entity_name}",
                    job_clusters=task_list_response[2],
                    tasks_list=task_list_response[0],
                    job_parameters=task_list_response[3],
                    RunAs=lakefusion_spn
                )
            else:
                job_service.reset_job(
                    job_id=job_id,
                    name=f"Match_Maven-{entity_name}",
                    job_clusters=None,
                    tasks_list=task_list_response[0],
                    job_parameters=task_list_response[3],
                    RunAs=lakefusion_spn
                )
            return job_id, False
            
        except InvalidParameterValue as e:
            # Job doesn't exist in Databricks - create a new one
            if "does not exist" in str(e):
                app_logger.warning(f"Job {job_id} no longer exists in Databricks. Creating a new job.")
                new_job_id = job_service.create_job(
                    f"Match_Maven-{entity_name}",
                    job_clusters=task_list_response[2],
                    tasks_list=task_list_response[0],
                    job_parameters=task_list_response[3],
                    RunAs=lakefusion_spn
                )
                return new_job_id, True
            else:
                raise

    def create_and_run_job(self, entity_id: int, model_id: int, entity_name: str, is_more_records, 
                        existing_cluster: str, created_by: str, token: str):
        try:
            entity_service = EntityService(db=self.db)
            entity_data = entity_service.get_full_entity_by_id(entity_id)
            if entity_data.attributes == [] or entity_data.dataset_mappings == [] or entity_data.survivorship == []:
                raise HTTPException(
                    status_code=500,
                    detail=f"Either Entity Attributes or Dataset Mapping or Survivorship is missing"
                )
            
            job_service = DatabricksJobManager(token)
            lakefusion_spn = (self.db.query(DBConfigProperties).filter(
                DBConfigProperties.config_key == "lakefusion_spn").first().config_value)
            process_records = int(self.db.query(DBConfigProperties).filter(
                DBConfigProperties.config_key == "processable_records").first().config_value, 10)
            
            # Get the model to check its version
            model = self.db.query(Model_Experiment).filter(Model_Experiment.id == model_id).first()
            model_version = model.version if model and model.version else "1.0.0"
            
            # Use version to determine pipeline type (not feature flag for existing models)
            use_new_pipeline = is_version_gte(model_version, NEW_PIPELINE_MIN_VERSION)
            app_logger.info(f"create_and_run_job: model_id={model_id}, version={model_version}, use_new_pipeline={use_new_pipeline}")
            
            entity = self.db.query(Model_Databricks_Job).filter(
                Model_Databricks_Job.entity_id == entity_id).order_by(
                Model_Databricks_Job.created_at.desc()).first()
            
            if not entity:
                print("No entity found, creating a job first time for a model!!")
                if is_more_records == False:
                    print("process_records", process_records)
                
                # Use version-based pipeline selection
                if use_new_pipeline:
                    app_logger.info("Using NEW experiment pipeline (version >= 4.0.0)")
                    task_list_response = self.create_tasks_and_job_experiment(
                        entity_id, model_id, [0, process_records], existing_cluster, is_initial_load=True
                    )
                else:
                    app_logger.info("Using LEGACY experiment pipeline (version < 4.0.0)")
                    task_list_response = self.create_tasks_and_job(
                        entity_id, model_id, [0, process_records], existing_cluster)
                
                if(existing_cluster is None):
                    job_create_response=job_service.create_job(f"Match_Maven-{entity_name}",job_clusters=task_list_response[2],tasks_list=task_list_response[0],job_parameters=task_list_response[3],RunAs=lakefusion_spn)
                else:
                    job_create_response=job_service.create_job(f"Match_Maven-{entity_name}",job_clusters=task_list_response[2],tasks_list=task_list_response[0],job_parameters=task_list_response[3],RunAs=lakefusion_spn)
                job_run_response=job_service.run_job(job_create_response)
                job_response=job_service.get_job_run_status(job_run_response.run_id)
                model_jobs = Model_Databricks_Job(
                entity_id=entity_id,
                modelid=model_id,
                job_id=job_create_response,   
                job_run_id=job_run_response.run_id,
                job_repair_run_id=None,
                experiment_status='prepare',
                job_run_status=job_response,
                existing_cluster_id=existing_cluster,
                processed_record=process_records,
                created_by=created_by)

                self.db.add(model_jobs)
                self.db.commit()
                self.db.refresh(model_jobs)
                return model_jobs

            else:
                model_entity_id = self.db.query(Model_Databricks_Job).filter(Model_Databricks_Job.entity_id == entity_id).filter(Model_Databricks_Job.modelid == model_id).order_by(Model_Databricks_Job.created_at.desc()).first()
                print("model_entity_id",model_entity_id)
                if(model_entity_id is not None and is_more_records):
                    # Process more records: Update existing record instead of creating new one
                    no_processed_records=model_entity_id.processed_record+1
                    new_process_records=model_entity_id.processed_record+process_records
                    experiment_status='experiment_process_more_records'
                    
                    # Store current job run info in historical_jobs array before updating
                    current_job_info = {
                        "job_run_id": model_entity_id.job_run_id,
                        "job_run_status": model_entity_id.job_run_status,
                        "experiment_status": model_entity_id.experiment_status,
                        "processed_record": model_entity_id.processed_record,
                        "job_link": self._construct_job_link(entity.job_id, model_entity_id.job_run_id),
                        "created_at": model_entity_id.created_at.isoformat() if model_entity_id.created_at else None,
                        "archived_at": datetime.now().isoformat()
                    }
                    
                    # Initialize or update historical_jobs array
                    if hasattr(model_entity_id, 'historical_jobs') and model_entity_id.historical_jobs:
                        historical_jobs = model_entity_id.historical_jobs.copy()
                        historical_jobs.append(current_job_info)
                    else:
                        historical_jobs = [current_job_info]
                    
                    # Use appropriate task creation method based on feature flag
                    if use_new_pipeline:
                        app_logger.info("Using NEW experiment pipeline for incremental load (MDM_RESTRUCTURING enabled)")
                        task_list_response = self.create_tasks_and_job_experiment(
                            entity_id, model_id, [no_processed_records, new_process_records], existing_cluster, is_initial_load=False
                        )
                    else:
                        app_logger.info("Using LEGACY experiment pipeline for incremental load")
                        task_list_response = self.create_tasks_and_job(entity_id, model_id, [no_processed_records, new_process_records], existing_cluster)
                    
                    # Try to reset existing job, or create new one if it doesn't exist
                    actual_job_id, is_new_job = self._try_reset_or_create_job(
                        job_service, entity.job_id, entity_name, task_list_response, lakefusion_spn, existing_cluster
                    )
                        
                    job_run_response=job_service.run_job(actual_job_id)
                    job_response=job_service.get_job_run_status(job_run_response.run_id)
                    
                    # Update existing record instead of creating new one
                    model_entity_id.job_id = actual_job_id  # Update job_id in case a new job was created
                    model_entity_id.job_run_id = job_run_response.run_id
                    model_entity_id.job_repair_run_id = None
                    model_entity_id.experiment_status = experiment_status
                    model_entity_id.job_run_status = job_response
                    model_entity_id.processed_record = new_process_records
                    model_entity_id.created_by = created_by
                    if hasattr(model_entity_id, 'historical_jobs'):
                        model_entity_id.historical_jobs = historical_jobs
                    
                    self.db.commit()
                    self.db.refresh(model_entity_id)
                    return model_entity_id
                    
                elif(model_entity_id is not None):
                    # Same model but not processing more records - create new record
                    no_processed_records=0
                    new_process_records=process_records
                    experiment_status='prepare'
                    
                    # Use appropriate task creation method based on feature flag
                    if use_new_pipeline:
                        app_logger.info("Using NEW experiment pipeline for fresh run (MDM_RESTRUCTURING enabled)")
                        task_list_response = self.create_tasks_and_job_experiment(
                            entity_id, model_id, [no_processed_records, new_process_records], existing_cluster, is_initial_load=True
                        )
                    else:
                        app_logger.info("Using LEGACY experiment pipeline for fresh run")
                        task_list_response = self.create_tasks_and_job(entity_id, model_id, [no_processed_records, new_process_records], existing_cluster)
                    
                    # Try to reset existing job, or create new one if it doesn't exist
                    actual_job_id, is_new_job = self._try_reset_or_create_job(
                        job_service, entity.job_id, entity_name, task_list_response, lakefusion_spn, existing_cluster
                    )
                        
                    job_run_response=job_service.run_job(actual_job_id)
                    job_response=job_service.get_job_run_status(job_run_response.run_id)
                    model_jobs = Model_Databricks_Job(
                    entity_id=entity_id,
                    modelid=model_id,
                    job_id=actual_job_id,   
                    job_run_id=job_run_response.run_id,
                    job_repair_run_id=None,
                    experiment_status=experiment_status,
                    job_run_status=job_response,
                    existing_cluster_id=existing_cluster,
                    processed_record=new_process_records,
                    created_by=created_by)
                    
                    self.db.add(model_jobs)
                    self.db.commit()
                    self.db.refresh(model_jobs)
                    return model_jobs
                    
                else:
                    # No existing model found - create new record
                    no_processed_records=0
                    new_process_records=process_records
                    experiment_status='prepare'

                    # Use appropriate task creation method based on feature flag
                    if use_new_pipeline:
                        app_logger.info("Using NEW experiment pipeline for new model (MDM_RESTRUCTURING enabled)")
                        task_list_response = self.create_tasks_and_job_experiment(
                            entity_id, model_id, [no_processed_records, new_process_records], existing_cluster, is_initial_load=True
                        )
                    else:
                        app_logger.info("Using LEGACY experiment pipeline for new model")
                        task_list_response = self.create_tasks_and_job(entity_id, model_id, [no_processed_records, new_process_records], existing_cluster)
                    
                    # Try to reset existing job, or create new one if it doesn't exist
                    actual_job_id, is_new_job = self._try_reset_or_create_job(
                        job_service, entity.job_id, entity_name, task_list_response, lakefusion_spn, existing_cluster
                    )
                        
                    job_run_response=job_service.run_job(actual_job_id)
                    job_response=job_service.get_job_run_status(job_run_response.run_id)
                    model_jobs = Model_Databricks_Job(
                    entity_id=entity_id,
                    modelid=model_id,
                    job_id=actual_job_id,   
                    job_run_id=job_run_response.run_id,
                    job_repair_run_id=None,
                    experiment_status=experiment_status,
                    job_run_status=job_response,
                    existing_cluster_id=existing_cluster,
                    processed_record=new_process_records,
                    created_by=created_by) 
                    
                    self.db.add(model_jobs)
                    self.db.commit()
                    self.db.refresh(model_jobs)
                    return model_jobs
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create and run job. Reason - {message}')
            self.db.rollback()
        finally:
            self.db.close()

    def repair_run_job(self,entity_id:int,model_id:int,created_by:str,token: str):
        try:
            model_check=self.db.query(Model_Experiment).filter(Model_Experiment.id==model_id).filter(Model_Experiment.entity_id==entity_id).filter(Model_Experiment.status.in_(['experiment_failed','experiment_cancelled'])).order_by(Model_Experiment.created_at.desc()).first()
            if(not model_check):
                raise HTTPException(status_code=404, detail="Current Model is not failed or cancelled yet")
            match_maven_check=self.db.query(Model_Databricks_Job).filter(Model_Databricks_Job.modelid==model_check.id).order_by(Model_Databricks_Job.created_at.desc()).first()
            databricks_job_service = DatabricksJobManager(token)
            if(match_maven_check.job_repair_run_id!=(None)):
                job_repair_response=databricks_job_service.repair_and_run_job(job_run_id=match_maven_check.job_run_id,latest_repair_id=match_maven_check.job_repair_run_id)
               
            else:
                job_repair_response=databricks_job_service.repair_and_run_job(job_run_id=match_maven_check.job_run_id)
            job_run_response=databricks_job_service.get_job_run_status(match_maven_check.job_run_id)
            model_job = self.db.query(Model_Databricks_Job).filter(Model_Databricks_Job.job_run_id == match_maven_check.job_run_id).first()
            if model_job:
               # Update the model instance directly
               model_job.job_repair_run_id = str(job_repair_response)
               model_job.experiment_status = 'experiment_retry'
               model_job.job_run_status=job_run_response
               self.db.commit()
               self.db.refresh(model_job)
               model_check.status='experiment_retry'
               self.db.commit()
               self.db.refresh(model_check)

               return model_job
        except Exception as e:
            app_logger.exception(f'Unable to repair model databricks job. Reason - {str(e)}')
            self.db.rollback()
        finally:
            self.db.close()

    def cancel_run_job(self,entity_id:int,model_id:int,created_by:str,token: str):
        try:
            model_check=self.db.query(Model_Experiment).filter(Model_Experiment.id==model_id).filter(Model_Experiment.entity_id==entity_id).filter(Model_Experiment.status!='experiment_failed').order_by(Model_Experiment.created_at.desc()).first()
            if(not model_check):
                raise HTTPException(status_code=404, detail="Current Model is not failed yet")
            match_maven_check=self.db.query(Model_Databricks_Job).filter(Model_Databricks_Job.modelid==model_check.id).order_by(Model_Databricks_Job.created_at.desc()).first()
            databricks_job_service = DatabricksJobManager(token)
            databricks_job_service.stop_running_pipeline(job_run_id=match_maven_check.job_run_id)
            model_job = self.db.query(Model_Databricks_Job).filter(Model_Databricks_Job.job_run_id == match_maven_check.job_run_id).first()
            if model_job:
               # Update the model instance directly
               model_job.experiment_status = 'experiment_cancelled'
               model_check.status='experiment_cancelled'
               self.db.commit()
               self.db.refresh(model_job)
               self.db.refresh(model_check)
               return model_job
            else:
                raise HTTPException(status_code=404, detail="Model not found")
        except Exception as e:
            app_logger.exception(f'Unable to repair model databricks job. Reason - {str(e)}')
            self.db.rollback()
        finally:
            self.db.close()

    def _sanitize_name_for_volume(self, name: str) -> str:
        """
        Sanitize a name to be valid for Databricks volume names.
        Valid names must contain only alphanumeric characters and underscores.
        """
        import re
        # Replace invalid characters with underscores
        sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', str(name))
        # Remove multiple consecutive underscores
        sanitized = re.sub(r'_+', '_', sanitized)
        # Remove leading/trailing underscores
        sanitized = sanitized.strip('_')
        # Ensure it's not empty
        if not sanitized:
            sanitized = 'default'
        return sanitized

    def start_experiment(
        self,
        entity_id: str,
        model_id: str,
        is_more_records: bool = False,
        existing_cluster: Optional[str] = None,
        created_by: str = "",
        token: str = ""
    ) -> str:
        """
        Orchestrates the experiment start flow:
        1. Creates a volume folder in the catalog.
        2. Fetches entity and model data.
        3. Uploads entity and model metadata as JSON files.
        4. Triggers a Databricks job (using new or legacy pipeline based on feature flag).
        Returns the job_id for tracking.
        """

        app_logger.info(f"Starting experiment for entity_id={entity_id}, model_id={model_id}, created_by={created_by}")
        
        # Log feature flag status
        mdm_restructuring_enabled = self._is_mdm_restructuring_enabled()
        app_logger.info(f"MDM_RESTRUCTURING feature flag: {'ENABLED' if mdm_restructuring_enabled else 'DISABLED'}")

        # --- Initialize dependent services ---
        experiment_service = ExperimentService(self.db)
        entity_service = EntityService(self.db)
        catalog_service = CatalogService(token, self.db)

        # --- Create volume folder for this experiment ---
        folder_path = catalog_service.create_volume_folder(entity_id, model_id)
        app_logger.info(f"Created catalog volume folder at: {folder_path}")

        # --- Fetch entity & model data ---
        entity_data = entity_service.get_full_entity_by_id(entity_id).dict()
        model_data = experiment_service.get_model(model_id).dict()

        # --- Upload data as JSON ---
        catalog_service.upload_data_as_json(folder_path, 'entity.json', entity_data)
        catalog_service.upload_data_as_json(folder_path, 'model.json', model_data)
        app_logger.info("Uploaded entity.json and model.json to volume folder.")

        # --- Trigger Databricks Job ---
        # The create_and_run_job method will internally check the feature flag
        # and use either the new or legacy pipeline
        job_id = self.create_and_run_job(
            entity_id=entity_id,
            model_id=model_id,
            entity_name=entity_data["name"],
            is_more_records=is_more_records,
            existing_cluster=existing_cluster,
            created_by=created_by,
            token=token
        )

        app_logger.info(f"Experiment job started successfully. Job ID: {job_id}")
        return job_id
