"""
Service layer for PT Models Config CRUD operations and validation.
"""

import json
import os
from typing import Optional

from sqlalchemy.orm import Session
from fastapi import HTTPException

from lakefusion_utility.models.pt_models_config import (
    PTModelsConfig,
    PTModelsConfigCreate,
    PTModelsConfigUpdate,
    PTModelsConfigResponse,
    PTModelsConfigValidateRequest,
    PTModelsConfigValidateResponse,
)
from lakefusion_utility.models.api_response import ApiResponse
from lakefusion_utility.utils.databricks_util import get_model_optimization_info, CatalogService
from lakefusion_utility.utils.logging_utils import get_logger

app_logger = get_logger(__name__)

# Known models that report optimizable but fail endpoint creation
KNOWN_UNSUPPORTED_MODELS = [
    "system.ai.claude_v3_7_sonnet",
    "system.ai.claude_v4_sonnet",
    "system.ai.claude_v4_opus",
    "system.ai.claude_v3_5_sonnet",
    "system.ai.claude_v3_opus",
]


class PTModelsConfigService:
    """Service for managing PT models configuration."""

    def __init__(self, db: Session):
        """
        Initialize PT models config service.

        Args:
            db: SQLAlchemy database session
        """
        self.db = db

    def create_pt_config(
        self, pt_config: PTModelsConfigCreate, token: str
    ) -> ApiResponse[PTModelsConfigResponse]:
        """
        Create a new PT model configuration.

        Args:
            pt_config: PT model configuration data
            token: Databricks API token for syncing to Volume

        Returns:
            ApiResponse containing the created config

        Raises:
            HTTPException: If config already exists for the entity
        """
        # Check for active duplicate only (allows recreation after disable)
        existing = (
            self.db.query(PTModelsConfig)
            .filter(
                PTModelsConfig.entity_name == pt_config.entity_name,
                PTModelsConfig.is_active == True
            )
            .first()
        )

        if existing:
            raise HTTPException(
                status_code=409,
                detail=f"Active PT config already exists for model '{pt_config.entity_name}'. Disable or delete it first, or use update endpoint to modify it.",
            )

        # Build pt_config JSON from individual fields
        pt_config_json = PTModelsConfig.build_pt_config(
            pt_type=pt_config.pt_type,
            chunk_size=pt_config.chunk_size,
            provisioned_model_units=pt_config.provisioned_model_units,
            min_provisioned_throughput=pt_config.min_provisioned_throughput,
            max_provisioned_throughput=pt_config.max_provisioned_throughput,
            scale_to_zero_enabled=pt_config.scale_to_zero_enabled,
            burst_scaling_enabled=pt_config.burst_scaling_enabled,
        )

        # Create new DB record
        db_config = PTModelsConfig(
            entity_name=pt_config.entity_name,
            entity_version=pt_config.entity_version,
            pt_type=pt_config.pt_type,
            model_category=pt_config.model_category,
            pt_config=pt_config_json,  # Store as JSON
            is_active=True
        )
        self.db.add(db_config)
        self.db.commit()
        self.db.refresh(db_config)

        app_logger.info(f"Created PT config for {pt_config.entity_name}")

        # Sync to Volume
        try:
            self.sync_to_volume(token)
        except Exception as e:
            app_logger.error(f"Failed to sync PT config to Volume: {e}")
            # Don't fail the request, Volume sync is not critical for DB operation

        return ApiResponse[PTModelsConfigResponse](
            status="success",
            message="PT model config created successfully",
            data=PTModelsConfigResponse(**db_config.as_dict()),
        )

    def read_pt_configs(
        self, is_active: Optional[bool] = None
    ) -> ApiResponse[list]:
        """
        Read all PT model configurations.

        Args:
            is_active: Filter by active status (None = all)

        Returns:
            ApiResponse containing list of PT configs
        """
        query = self.db.query(PTModelsConfig)
        if is_active is not None:
            query = query.filter(PTModelsConfig.is_active == is_active)

        configs = query.all()

        return ApiResponse[list](
            status="success",
            message=f"Retrieved {len(configs)} PT configs",
            data=[PTModelsConfigResponse(**c.as_dict()) for c in configs],
        )

    def get_pt_config_by_id(self, config_id: int) -> PTModelsConfigResponse:
        """
        Get a single PT config by ID.

        Args:
            config_id: PT config ID

        Returns:
            PT config response

        Raises:
            HTTPException: If config not found
        """
        db_config = (
            self.db.query(PTModelsConfig)
            .filter(PTModelsConfig.id == config_id)
            .first()
        )
        if not db_config:
            raise HTTPException(status_code=404, detail="PT config not found")

        return PTModelsConfigResponse(**db_config.as_dict())

    def update_pt_config(
        self, config_id: int, update_data: PTModelsConfigUpdate, token: str
    ) -> ApiResponse[PTModelsConfigResponse]:
        """
        Update an existing PT config.

        Args:
            config_id: PT config ID
            update_data: Updated configuration data
            token: Databricks API token for syncing to Volume

        Returns:
            ApiResponse containing updated config

        Raises:
            HTTPException: If config not found
        """
        db_config = (
            self.db.query(PTModelsConfig)
            .filter(PTModelsConfig.id == config_id)
            .first()
        )
        if not db_config:
            raise HTTPException(status_code=404, detail="PT config not found")

        # Update fields
        update_dict = update_data.dict(exclude_unset=True)

        # Handle pt_config fields specially - rebuild JSON
        config_fields = ['chunk_size', 'provisioned_model_units', 'min_provisioned_throughput',
                        'max_provisioned_throughput', 'scale_to_zero_enabled', 'burst_scaling_enabled']

        # Check if any pt_config fields are being updated
        if any(field in update_dict for field in config_fields):
            # Get current pt_type (might be updated or use existing)
            pt_type = update_dict.get('pt_type', db_config.pt_type.value if hasattr(db_config.pt_type, 'value') else db_config.pt_type)

            # Merge existing pt_config with updates
            # Handle case where pt_config might be a JSON string from MySQL
            current_config = db_config.pt_config
            if isinstance(current_config, str):
                current_config = json.loads(current_config) if current_config else {}
            elif current_config is None:
                current_config = {}
            config_kwargs = dict(current_config)  # Start with existing config

            # Update with new values
            for field in config_fields:
                if field in update_dict:
                    config_kwargs[field] = update_dict[field]

            # Rebuild pt_config JSON
            db_config.pt_config = PTModelsConfig.build_pt_config(pt_type=pt_type, **config_kwargs)

        # Update non-config fields
        for key, value in update_dict.items():
            if key not in config_fields and value is not None:
                setattr(db_config, key, value)

        self.db.commit()
        self.db.refresh(db_config)

        app_logger.info(f"Updated PT config {config_id} for {db_config.entity_name}")

        # Sync to Volume
        try:
            self.sync_to_volume(token)
        except Exception as e:
            app_logger.error(f"Failed to sync PT config to Volume: {e}")

        return ApiResponse[PTModelsConfigResponse](
            status="success",
            message="PT config updated successfully",
            data=PTModelsConfigResponse(**db_config.as_dict()),
        )

    def delete_pt_config(self, config_id: int, token: str) -> ApiResponse[str]:
        """
        Hard delete a PT config.

        Args:
            config_id: PT config ID
            token: Databricks API token for syncing to Volume

        Returns:
            ApiResponse with confirmation message

        Raises:
            HTTPException: If config not found
        """
        db_config = (
            self.db.query(PTModelsConfig)
            .filter(PTModelsConfig.id == config_id)
            .first()
        )
        if not db_config:
            raise HTTPException(status_code=404, detail="PT config not found")

        entity_name = db_config.entity_name

        # Hard delete
        self.db.delete(db_config)
        self.db.commit()

        app_logger.info(f"Deleted PT config {config_id} for {entity_name}")

        # Sync to Volume
        try:
            self.sync_to_volume(token)
        except Exception as e:
            app_logger.error(f"Failed to sync PT config to Volume: {e}")

        return ApiResponse[str](
            status="success",
            message=f"PT config for '{entity_name}' deleted successfully",
            data=f"Config {config_id} deleted",
        )

    def toggle_pt_config(self, config_id: int, token: str) -> ApiResponse[PTModelsConfigResponse]:
        """
        Toggle PT config active status (enable/disable).

        Note: This does NOT sync to Databricks Volume. Use manual sync button to sync changes.

        Args:
            config_id: PT config ID
            token: Databricks API token (not used, kept for API consistency)

        Returns:
            ApiResponse with updated config

        Raises:
            HTTPException: If config not found
        """
        db_config = (
            self.db.query(PTModelsConfig)
            .filter(PTModelsConfig.id == config_id)
            .first()
        )
        if not db_config:
            raise HTTPException(status_code=404, detail="PT config not found")

        entity_name = db_config.entity_name
        old_status = db_config.is_active

        # Toggle is_active
        db_config.is_active = not db_config.is_active
        self.db.commit()
        self.db.refresh(db_config)

        action = "enabled" if db_config.is_active else "disabled"
        app_logger.info(f"{action.capitalize()} PT config {config_id} for {entity_name}")

        return ApiResponse[PTModelsConfigResponse](
            status="success",
            message=f"PT config for '{entity_name}' {action} successfully",
            data=PTModelsConfigResponse(**db_config.as_dict()),
        )

    def validate_pt_model(
        self, request: PTModelsConfigValidateRequest, token: str
    ) -> ApiResponse[PTModelsConfigValidateResponse]:
        """
        Validate if a model supports PT and get default configuration.

        Args:
            request: Validation request with entity name and version
            token: Databricks API token

        Returns:
            ApiResponse with validation result and defaults

        Raises:
            HTTPException: If model doesn't support PT or validation fails
        """
        # Check if config already exists
        existing_config = (
            self.db.query(PTModelsConfig)
            .filter(PTModelsConfig.entity_name == request.entity_name)
            .first()
        )

        existing_config_dict = None
        config_exists = False
        if existing_config:
            config_exists = True
            # Use as_dict() to get flattened config with chunk_size from pt_config JSON
            config_dict = existing_config.as_dict()
            existing_config_dict = {
                "id": config_dict["id"],
                "is_active": config_dict["is_active"],
                "pt_type": config_dict["pt_type"],
                "model_category": config_dict["model_category"],
                "chunk_size": config_dict.get("chunk_size"),
                "created_at": config_dict["created_at"],
            }

        # Check against known unsupported models
        if request.entity_name in KNOWN_UNSUPPORTED_MODELS:
            raise HTTPException(
                status_code=400,
                detail=f"Model '{request.entity_name}' reports as optimizable but PT endpoint creation is not yet supported by Databricks. Please use pay-per-token mode.",
            )

        # Call Databricks optimization API
        try:
            result = get_model_optimization_info(
                token, request.entity_name, int(request.entity_version)
            )
        except Exception as e:
            app_logger.error(
                f"Failed to validate model {request.entity_name}: {e}"
            )
            raise HTTPException(
                status_code=400,
                detail=f"Failed to validate model: {str(e)}",
            )

        if not result.get("optimizable"):
            raise HTTPException(
                status_code=400,
                detail=f"Model '{request.entity_name}' does not support provisioned throughput. Only available via pay-per-token.",
            )

        # Determine PT type
        if result.get("model_unit_chunk_size"):
            pt_type = "model_units"
            chunk_size = result["model_unit_chunk_size"]
            defaults = {"provisioned_model_units": chunk_size}
        elif result.get("throughput_chunk_size"):
            pt_type = "legacy"
            chunk_size = result["throughput_chunk_size"]
            defaults = {
                "min_provisioned_throughput": 0,
                "max_provisioned_throughput": chunk_size * 2,
            }
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Model optimization info incomplete for '{request.entity_name}'",
            )

        # Determine model category from task field
        task = result.get("task")
        category_auto_detected = False
        if task:
            model_category = "embedding" if "embedding" in task else "llm"
        else:
            # Heuristic for missing task field (common with model_units models)
            category_auto_detected = True
            entity_lower = request.entity_name.lower()
            if any(
                keyword in entity_lower
                for keyword in ["embed", "gte", "bge", "e5"]
            ):
                model_category = "embedding"
            else:
                model_category = "llm"

        app_logger.info(
            f"Validated {request.entity_name}: pt_type={pt_type}, category={model_category}, chunk_size={chunk_size}, config_exists={config_exists}"
        )

        return ApiResponse[PTModelsConfigValidateResponse](
            status="success",
            message=f"Model '{request.entity_name}' is eligible for provisioned throughput",
            data=PTModelsConfigValidateResponse(
                eligible=True,
                pt_type=pt_type,
                chunk_size=chunk_size,
                model_category=model_category,
                category_auto_detected=category_auto_detected,
                defaults=defaults,
                existing_config=existing_config_dict,
                config_exists=config_exists,
            ),
        )

    def sync_to_volume(self, token: str) -> None:
        """
        Write active PT configs to Databricks Volume JSON file.

        The JSON file is consumed by pipeline notebooks to determine
        which models should use PT endpoints and their configuration.

        Args:
            token: Databricks API token

        Raises:
            Exception: If Volume sync fails
        """
        # Expire all cached objects to ensure we get fresh data from DB
        self.db.expire_all()

        # Get active configs
        active_configs = (
            self.db.query(PTModelsConfig)
            .filter(PTModelsConfig.is_active == True)
            .all()
        )

        app_logger.info(f"Syncing {len(active_configs)} active PT configs to Volume")
        for config in active_configs:
            app_logger.info(f"  - {config.entity_name} (id={config.id}, active={config.is_active})")

        # Build JSON structure
        json_data = {"pt_models": [config.as_dict() for config in active_configs]}

        file_name = "pt_models_config.json"

        # Use CatalogService to upload JSON to Volume
        try:
            catalog_service = CatalogService(token, self.db)
            catalog_service.upload_metadata_file_to_volume(file_name, json_data)

            app_logger.info(
                f"Synced {len(active_configs)} PT configs to Volume"
            )
            app_logger.debug(f"JSON content written to Volume:\n{json.dumps(json_data, default=str, indent=2)}")
        except Exception as e:
            app_logger.error(f"Failed to sync PT configs to Volume: {e}")
            raise
