import traceback
from sqlalchemy.orm import Session
from fastapi import HTTPException
from typing import List
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.models.quality_assets import (
    QualityAsset,
    AssetCreate, AssetUpdate, ReferenceTableConfig
)

app_logger = get_logger(__name__)

class QualityAssetService:
    def __init__(self, db: Session):
        self.db = db

    def create_asset(self, asset: AssetCreate, created_by: str) -> QualityAsset:
        try:
            if asset.asset_type == "REFERENCE_TABLE":
                ReferenceTableConfig(**asset.configuration)
                
            db_asset = QualityAsset(
                name=asset.name,
                description=asset.description,
                asset_type=asset.asset_type,
                created_by=created_by,
                configuration=asset.configuration
            )
            
            self.db.add(db_asset)
            self.db.commit()
            self.db.refresh(db_asset)
            return db_asset
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create asset. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to create asset: {str(e)}")

    def update_asset(self, asset_id: int, asset_update: AssetUpdate) -> QualityAsset:
        try:
            db_asset = self.get_asset(asset_id)
            
            if asset_update.name is not None:
                db_asset.name = asset_update.name
                
            if asset_update.description is not None:
                db_asset.description = asset_update.description
                
            if asset_update.configuration is not None:
                if db_asset.asset_type == "REFERENCE_TABLE":
                    ReferenceTableConfig(**asset_update.configuration)
                db_asset.configuration = asset_update.configuration
            
            self.db.commit()
            self.db.refresh(db_asset)
            return db_asset
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update asset. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to update asset: {str(e)}")

    def get_asset(self, asset_id: int) -> QualityAsset:
        try:
            asset = self.db.query(QualityAsset).filter(
                QualityAsset.id == asset_id
            ).first()
            if not asset:
                raise HTTPException(status_code=404, detail="Asset not found")
            return asset
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to retrieve asset with ID {asset_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to retrieve asset: {str(e)}")

    def get_all_assets(self) -> List[QualityAsset]:
        try:
            return self.db.query(QualityAsset).all()
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to retrieve assets. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to retrieve assets: {str(e)}")

    def delete_asset(self, asset_id: int) -> str:
        try:
            asset = self.get_asset(asset_id)
            self.db.delete(asset)
            self.db.commit()
            return "Asset deleted successfully"
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete asset. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to delete asset: {str(e)}")