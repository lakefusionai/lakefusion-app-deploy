import traceback
from sqlalchemy.orm import Session
from datetime import datetime
from fastapi import HTTPException
from typing import List, Optional, Dict, Any
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.models.quality_tasks import (
    QualityTask,
    TaskType, TaskStatus,
    TaskCreate, NotebookConfigUpdate, DiagramConfigUpdate,
    ScheduleUpdate, TaskStatusUpdate
)
from databricks.sdk.service import jobs
from lakefusion_utility.utils.databricks_util import JobService,DatabricksJobManager, get_resource_tags
from databricks.sdk.service.compute import ClusterSpec, RuntimeEngine,AwsAttributes,AwsAvailability,AutoScale,DataSecurityMode,AzureAttributes
import base64
import os
import json
from lakefusion_utility.models.dbconfig import DBConfigProperties
from databricks.sdk.service.jobs import Task, NotebookTask, TaskEmailNotifications, RunIf, Source, CronSchedule, JobParameterDefinition, CreateResponse, Job, JobSettings,TaskDependency,ConditionTask,ConditionTaskOp,JobEmailNotifications,JobParameter
from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService

app_logger = get_logger(__name__)

class QualityTaskService:
    def __init__(self, db: Session):
        self.db = db
        self.db_config_service = DBConfigPropertiesService(db=self.db)
        self.notebook_folder_path=self.db_config_service.getDBConfigProperties(key="notebook_path")

    def create_task(self, task: TaskCreate, created_by: str) -> QualityTask:
        """Create a new quality task in DRAFT status."""
        try:
            db_task = QualityTask(
                name=task.name,
                description=task.description,
                task_type=task.task_type,
                created_by=created_by,
                dataset_id=task.dataset_id,
                entity_id=task.entity_id,
                quartz_cron_expression=task.quartz_cron_expression,
                timezone_id=task.timezone_id,
                status=TaskStatus.DRAFT
            )
            
            self.db.add(db_task)
            self.db.commit()
            self.db.refresh(db_task)
            return db_task
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create task. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to create task: {str(e)}")

    def update_notebook_config(
        self, 
        task_id: int, 
        config: NotebookConfigUpdate,
        created_by: str,
        token: str
    ) -> QualityTask:
        """Update notebook task configuration and create Databricks job."""
        try:
            task = self.get_task(task_id)
            
            if task.task_type != TaskType.NOTEBOOK:
                raise HTTPException(status_code=400, detail="Task is not a notebook task")
            
            job_service = JobService(token)
            
            job_parameters = config.config_parameters or {
                'input_table': task.dataset.path if task.dataset else None,
            }

            if task.databricks_job_id:
                # Update existing job
                job_response = job_service.update_single_task_job(
                    job_id=task.databricks_job_id,
                    job_name=f"Quality_Task_{task_id}",
                    notebook_path=config.notebook_path,
                    job_parameters=job_parameters,
                    failure_notification_emails=[created_by],
                    quartz_cron_expression=task.quartz_cron_expression,
                    timezone_id=task.timezone_id
                )
            else:
                # Create new job
                job_response = job_service.create_single_task_job(
                    job_name=f"Quality_Task_{task_id}",
                    notebook_path=config.notebook_path,
                    job_parameters=job_parameters,
                    failure_notification_emails=[created_by],
                    quartz_cron_expression=task.quartz_cron_expression,
                    timezone_id=task.timezone_id
                )
                task.databricks_job_id = job_response.job_id
            
            # Update task configuration
            task.notebook_path = config.notebook_path
            task.config_parameters = config.config_parameters
            task.job_info = job_response.as_dict()
            task.status = TaskStatus.CONFIGURED
            
            self.db.commit()
            self.db.refresh(task)
            return task
        
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update notebook config. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to update notebook config: {str(e)}")

    def update_diagram_config_new(
        self, 
        task_id: int, 
        config: DiagramConfigUpdate,
        created_by: str,
        token: str
    ) -> QualityTask:
        """Update diagram task configuration and create Databricks job."""
        try:
            task = self.get_task(task_id)
            
            if task.task_type != TaskType.DIAGRAM:
                raise HTTPException(status_code=400, detail="Task is not a diagram task")
            
            job_service = JobService(token)
            
            # Extract primary key from config parameters, with default fallback
            table_primary_key = config.config_parameters.get("table_primary_key", "id") if config.config_parameters else "id"
            
            # Create or update Databricks job
            job_parameters = {
                'input_table': task.dataset.path if task.dataset else None,
                'transformations_config': json.dumps(config.transformations),
                'table_primary_key': table_primary_key  # Include primary key explicitly
            }
            
            # Add any other config parameters
            if config.config_parameters:
                for key, value in config.config_parameters.items():
                    if key != "table_primary_key":  # Avoid duplication
                        job_parameters[key] = value
            
            try:
                if task.databricks_job_id:
                   job_service = DatabricksJobManager(token)
                   lakefusion_spn=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "lakefusion_spn").first().config_value)
                   task_list_response=self.create_tasks_and_job(task_id,config,token,None)
                   job_name=f"Quality_Task_{task_id}"
                   job_response=job_service.reset_job(task.databricks_job_id,job_name,job_clusters=task_list_response[1],tasks_list=task_list_response[0],job_parameters=task_list_response[2],RunAs=lakefusion_spn)

                else:
                   job_service = DatabricksJobManager(token)
                   lakefusion_spn=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "lakefusion_spn").first().config_value)
                   task_list_response=self.create_tasks_and_job(task_id,config,token,None)
                   job_name=f"Quality_Task_{task_id}"
                   job_response=job_service.create_job(job_name,job_clusters=task_list_response[1],tasks_list=task_list_response[0],job_parameters=task_list_response[2],RunAs=lakefusion_spn)
                
                if job_response:
                    task.databricks_job_id = job_response
                    # Store job info as JSON
                    task.job_info = job_response.as_dict() if hasattr(job_response, 'as_dict') else {"job_id": job_response}
                
            except Exception as job_error:
                message = traceback.format_exc()
                app_logger.exception(f'Job creation/update error. Reason - {message}')
                # Continue with the rest of the function even if job creation fails
                # This allows saving configuration without requiring job creation success
            
            # Update task configuration
            task.flow_data = config.flow_data
            task.transformations = config.transformations
            task.config_parameters = config.config_parameters
            task.status = TaskStatus.CONFIGURED
            
            self.db.commit()
            self.db.refresh(task)
            return task

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update diagram config. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to update diagram config: {str(e)}")
        
    def create_tasks_and_job(self,task_id,config: DiagramConfigUpdate,token:str,existing_cluster:None):
        try:
            task = self.get_task(task_id)
                
            if task.task_type != TaskType.DIAGRAM:
                raise HTTPException(status_code=400, detail="Task is not a diagram task")
            
            job_service = JobService(token)
            
            # Extract primary key from config parameters, with default fallback
            table_primary_key = config.config_parameters.get("table_primary_key", "id") if config.config_parameters else "id"
            
            # Create or update Databricks job
            parameters = {
                'input_table': task.dataset.path if task.dataset else None,
                'transformations_config': json.dumps(config.transformations),
                'table_primary_key': table_primary_key  # Include primary key explicitly
            }
            
            # Add any other config parameters
            if config.config_parameters:
                for key, value in config.config_parameters.items():
                    if key != "table_primary_key":  # Avoid duplication
                        parameters[key] = value  # ✅ Fixed variable name
            job_cluster=None

            tags = get_resource_tags()
            if tags is None:
                tags = {}
            
            dbx_cloud=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "dbx_cloud").first().config_value)
            if(dbx_cloud=='azure'):
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                cluster_name="",
                spark_version="16.0.x-cpu-ml-scala2.12",
                azure_attributes=AzureAttributes(
                    first_on_demand=1
                ),  # Corrected Azure Attributes
                node_type_id="Standard_DS12_v2",
                driver_node_type_id="Standard_DS12_v2",  # Correct Azure instance type
                spark_env_vars={
                    "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                },
                enable_elastic_disk=False,
                data_security_mode=DataSecurityMode.SINGLE_USER,
                runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                autoscale=AutoScale(
                    min_workers=1,  # Updated worker count
                    max_workers=1  # Updated worker count
                ),
                custom_tags=tags  # Add custom tags
            ))
            else:
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    aws_attributes=AwsAttributes(
                        first_on_demand=1,
                        availability=AwsAvailability.SPOT_WITH_FALLBACK,
                        zone_id="us-west-2d",
                        spot_bid_price_percent=100,
                        ebs_volume_count=0
                    ),
                    node_type_id="r5d.4xlarge",  # Updated instance type
                    spark_env_vars={
                        "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                    },
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                    autoscale=AutoScale(
                        min_workers=1,  # Updated worker count
                        max_workers=3   # Updated worker count
                    ),
                    custom_tags=tags
                    ))
            
            if(existing_cluster is None):
                job_cluster_key_value = job_cluster.job_cluster_key
                existing_cluster_value = None
            else:
                job_cluster_key_value = None
                existing_cluster_value = existing_cluster
            tasks_list = [
                Task(
                    task_key="Validate_Diagraming_Task",
                    run_if=RunIf.ALL_SUCCESS,
                    existing_cluster_id=existing_cluster_value,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/dataquality/validate-data-quality-diagramming",
                        base_parameters=parameters,
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
            
                Task(
                    task_key="Is_LookUp_Check",
                    depends_on=[TaskDependency(task_key="Validate_Diagraming_Task")],
                    run_if=RunIf.ALL_SUCCESS,
                    condition_task=ConditionTask(
                        op=ConditionTaskOp.EQUAL_TO,
                        left="{{tasks.Validate_Diagraming_Task.values.is_lookup_present}}",
                        right="1",
                    ),
                    timeout_seconds=0,
                ),
            
                Task(
                    task_key="LLM_Foundation_DQ_Check",
                    depends_on=[TaskDependency(task_key="Is_LookUp_Check", outcome=True)],
                    run_if=RunIf.ALL_SUCCESS,
                    existing_cluster_id=existing_cluster_value,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/dataquality/LLM Foundational DQ Check",
                        base_parameters=parameters,
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
            
                Task(
                    task_key="Is_LLM_Endpoint_Available",
                    depends_on=[TaskDependency(task_key="LLM_Foundation_DQ_Check")],
                    run_if=RunIf.ALL_SUCCESS,
                    condition_task=ConditionTask(
                        op=ConditionTaskOp.EQUAL_TO,
                        left="{{tasks.LLM_Foundation_DQ_Check.values.is_llm_endpoint}}",
                        right="true",
                    ),
                    timeout_seconds=0,
                ),
            
                Task(
                    task_key="LLM_Foundation_DQ_Create",
                    depends_on=[TaskDependency(task_key="Is_LLM_Endpoint_Available", outcome=False)],
                    run_if=RunIf.ALL_SUCCESS,
                    job_cluster_key=job_cluster_key_value,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/dataquality/LLM Foundational DQ Create",
                        base_parameters=parameters,
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
            
                Task(
                    task_key="Execute_Diagraming_Task_Lookup",
                    depends_on=[
                        TaskDependency(task_key="Is_LLM_Endpoint_Available", outcome=True),
                        TaskDependency(task_key="LLM_Foundation_DQ_Create"),
                    ],
                    run_if=RunIf.NONE_FAILED,
                    existing_cluster_id=existing_cluster_value,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/dataquality/execute-data-quality-diagramming",
                        base_parameters=parameters,
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
            
                Task(
                    task_key="Execute_Diagraming_Task",
                    depends_on=[TaskDependency(task_key="Is_LookUp_Check", outcome=False)],
                    run_if=RunIf.ALL_SUCCESS,
                    existing_cluster_id=existing_cluster_value,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/dataquality/execute-data-quality-diagramming",
                        base_parameters=parameters,
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                )
            ]
            job_parameters = [
            JobParameter(
                name="input_table",
                default=str(parameters['input_table'])
            ),
            JobParameter(
                name="table_primary_key",
                default=str(parameters['table_primary_key'])
            ),
            JobParameter(
                name="transformations_config",
                default=str(parameters['transformations_config'])
            )
            ]
            return [tasks_list,job_cluster,job_parameters]
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks and job configuration. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create tasks and job configuration: {str(e)}")  # ✅ Added

    def execute_task(
        self, 
        task_id: int, 
        created_by: str, 
        token: str
    ) -> Dict[str, Any]:
        """Execute a task directly in Databricks without tracking in the database."""
        try:
            task = self.get_task(task_id)
            
            if task.status != TaskStatus.CONFIGURED:
                raise HTTPException(status_code=400, detail="Task is not configured")
            
            job_service = JobService(token)
            
            try:
                # Run the job directly in Databricks
                run_response = job_service.run_job(
                    job_id=task.databricks_job_id
                )
                
                self.db.commit()
                
                # Return just what's needed for client to track the run
                return {
                    "task_id": task_id,
                    "run_id": run_response.run_id,
                    "job_url": task.job_url,
                    "run_url": f"{task.job_url}/run/{run_response.run_id}" if task.job_url else None,
                    "message": "Task execution started successfully"
                }

            except Exception as job_error:
                message = traceback.format_exc()
                app_logger.exception(f'Job execution error. Reason - {message}')
                task.status = TaskStatus.FAILED
                self.db.commit()
                raise HTTPException(
                    status_code=500,
                    detail=f"Failed to execute job: {str(job_error)}"
                )

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to execute task. Reason - {message}')
            self.db.rollback()
            raise HTTPException(
                status_code=500,
                detail=f"Failed to execute task: {str(e)}"
            )

    # def get_task_with_config_parameters(self, task_id: int, token: Optional[str] = None) -> QualityTask:
    #     """
    #     Get task details with robust error handling and validation.
        
    #     Args:
    #         task_id: The ID of the task to retrieve
    #         token: Optional Databricks token for job information retrieval
            
    #     Returns:
    #         QualityTask: The task object with updated job information if available
            
    #     Raises:
    #         HTTPException: For validation errors, not found, or service errors
    #     """
    #     try:
    #         # Use the internal method to get the task from database
    #         task = self.get_task(task_id)
            
    #         app_logger.info(f'Successfully found task {task_id}: {task.name}')
            
    #         # Handle Databricks job information retrieval if job exists and token provided
    #         if task.databricks_job_id and token:
    #             try:
    #                 app_logger.info(f'Retrieving Databricks job info for job ID: {task.databricks_job_id}')
                    
    #                 # Validate token before making API call
    #                 if not token.strip():
    #                     app_logger.warning('Empty or whitespace-only token provided')
    #                     raise ValueError("Invalid token provided")
                    
    #                 job_service = JobService(token)
    #                 job_response = job_service.get_single_task_job(
    #                     job_id=task.databricks_job_id
    #                 )

    #                 if job_response:
    #                     job_info = job_response.as_dict()
                        
    #                     # Safely extract parameters using dictionary access since job_info is now a dict
    #                     if 'settings' in job_info and 'parameters' in job_info['settings']:
    #                         parameters_list = job_info['settings']['parameters']
    #                         # Convert list of parameter objects to dictionary
    #                         if isinstance(parameters_list, list):
    #                             print("Parameters List:", parameters_list)
    #                             task.config_parameters = {param["name"]: param["default"] for param in parameters_list}
    #                         else:
    #                             # If it's already a dict, use as-is
    #                             task.config_parameters = parameters_list
    #                         app_logger.info(f'Updated config parameters for task {task_id}')
    #                     else:
    #                         app_logger.warning(f'No parameters found in job response for task {task_id}')
                            
    #                     # Update job_info if not already set
    #                     if not task.job_info:
    #                         task.job_info = job_info
                            
    #                 else:
    #                     app_logger.warning(f'No job response received for job ID: {task.databricks_job_id}')
                        
    #             except Exception as job_error:
    #                 # Don't fail the entire operation if job info retrieval fails
    #                 app_logger.warning(
    #                     f'Failed to retrieve Databricks job info for task {task_id}, '
    #                     f'job_id {task.databricks_job_id}: {str(job_error)}'
    #                 )
    #                 # Optionally, you could set a flag to indicate job info is stale
    #                 # task.job_info_status = 'stale'
                    
    #         elif task.databricks_job_id and not token:
    #             app_logger.info(f'Task {task_id} has Databricks job but no token provided - skipping job info update')
            
    #         return task
            
    #     except HTTPException:
    #         # Re-raise HTTP exceptions from get_task (validation, not found, etc.)
    #         raise
            
    #     except Exception as e:
    #         message = traceback.format_exc()
    #         app_logger.exception(f'Unexpected error retrieving task with ID {task_id}. Reason - {message}')
    #         raise HTTPException(
    #             status_code=500, 
    #             detail=f"Internal server error while retrieving task: {str(e)}"
    #         )

    def get_task(self, task_id: int) -> QualityTask:
        """
        Internal method to get task by ID without job info retrieval.
        Used for operations that don't need Databricks job information.
        
        Args:
            task_id: The ID of the task to retrieve
            
        Returns:
            QualityTask: The task object from database only
            
        Raises:
            HTTPException: For validation errors or not found
        """
        # Input validation
        if not isinstance(task_id, int) or task_id <= 0:
            app_logger.error(f'Invalid task_id provided: {task_id}')
            raise HTTPException(
                status_code=400, 
                detail="Task ID must be a positive integer"
            )
        
        try:
            app_logger.info(f'Fetching task (DB only) with ID: {task_id}')
            
            task = self.db.query(QualityTask).filter(
                QualityTask.id == task_id
            ).first()
            
            if not task:
                app_logger.warning(f'Task with ID {task_id} not found')
                raise HTTPException(
                    status_code=404, 
                    detail=f"Task with ID {task_id} not found"
                )
            
            return task
            
        except HTTPException:
            raise
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unexpected error retrieving task with ID {task_id}. Reason - {message}')
            raise HTTPException(
                status_code=500, 
                detail=f"Internal server error while retrieving task: {str(e)}"
            )
    def get_all_tasks(
        self, 
        sort_by: str = "created_at", 
        sort_order: str = "desc", 
        limit: Optional[int] = None, 
        offset: int = 0,
        status_filter: Optional[TaskStatus] = None,
        task_type_filter: Optional[TaskType] = None
    ) -> List[QualityTask]:
        """
        Retrieve quality tasks from the database with filtering, sorting, and pagination options.
        
        Args:
            sort_by: Field to sort by (e.g., 'id', 'name', 'created_at', 'updated_at'). Default is 'created_at'.
            sort_order: Sort order, either 'asc' or 'desc'. Default is 'desc'.
            limit: Maximum number of records to return. If None, returns all matching records.
            offset: Number of records to skip for pagination. Default is 0.
            status_filter: Filter by task status (e.g., TaskStatus.DRAFT, TaskStatus.CONFIGURED).
            task_type_filter: Filter by task type (e.g., TaskType.NOTEBOOK, TaskType.DIAGRAM).
            
        Returns:
            List[QualityTask]: A list of quality task objects based on filters and sorting.
            
        Raises:
            HTTPException: If there's an error during retrieval or invalid parameters.
        """
        try:
            # Validate sort_order parameter
            if sort_order.lower() not in ['asc', 'desc']:
                raise HTTPException(status_code=400, detail="sort_order must be either 'asc' or 'desc'")
            
            # Validate sort_by field exists on the QualityTask model
            if not hasattr(QualityTask, sort_by):
                raise HTTPException(status_code=400, detail=f"Invalid sort field: {sort_by}")
            
            # Validate limit and offset parameters
            if limit is not None and limit < 0:
                raise HTTPException(status_code=400, detail="limit must be non-negative")
            
            if offset < 0:
                raise HTTPException(status_code=400, detail="offset must be non-negative")
            
            # Start building the query
            task_query = self.db.query(QualityTask)
            
            # Apply filters
            if status_filter is not None:
                task_query = task_query.filter(QualityTask.status == status_filter)
            
            if task_type_filter is not None:
                task_query = task_query.filter(QualityTask.task_type == task_type_filter)
            
            # Apply sorting
            sort_field = getattr(QualityTask, sort_by)
            if sort_order.lower() == 'desc':
                task_query = task_query.order_by(sort_field.desc())
            else:
                task_query = task_query.order_by(sort_field.asc())
            
            # Apply pagination if specified
            if offset > 0:
                task_query = task_query.offset(offset)
            
            if limit is not None and limit > 0:
                task_query = task_query.limit(limit)
            
            # Execute query and return results
            tasks = task_query.all()
            
            app_logger.info(
                f"Successfully retrieved {len(tasks)} quality tasks with filters: "
                f"sort_by={sort_by}, sort_order={sort_order}, status_filter={status_filter}, "
                f"task_type_filter={task_type_filter}, limit={limit}, offset={offset}"
            )
            return tasks
            
        except HTTPException:
            # Re-raise HTTP exceptions (validation errors)
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to retrieve tasks. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to retrieve tasks: {str(e)}")

    def delete_task(self, task_id: int, token: str) -> str:
        """Delete task and its Databricks job."""
        try:
            task = self.get_task(task_id)
            
            if task.databricks_job_id:
                job_service = JobService(token)
                job_service.delete_job(task.databricks_job_id)
            
            self.db.delete(task)
            self.db.commit()
            return "Task deleted successfully"
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete task. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to delete task: {str(e)}")

    def update_schedule(
        self, 
        task_id: int, 
        schedule: ScheduleUpdate,
        token: str
    ) -> QualityTask:
        """Update task schedule."""
        try:
            task = self.get_task(task_id)
            
            task.quartz_cron_expression = schedule.quartz_cron_expression
            task.timezone_id = schedule.timezone_id
            
            if task.databricks_job_id:
                job_service = JobService(token)
                job_service.update_single_task_job(
                    job_id=task.databricks_job_id,
                    job_name=f"Quality_Task_{task_id}",
                    notebook_path=task.notebook_path or f"{self.notebook_folder_path}/src/dataquality/data-quality-diagramming",
                    job_parameters=task.config_parameters or {},
                    failure_notification_emails=[task.created_by],
                    quartz_cron_expression=schedule.quartz_cron_expression,
                    timezone_id=schedule.timezone_id
                )
            
            self.db.commit()
            self.db.refresh(task)
            return task
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update schedule. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to update schedule: {str(e)}")

    def get_template_file(self) -> dict:
        """Retrieve the notebook template file."""
        file_path = os.path.join("app/templates", "quality_template_notebook.py")
        
        try:
            if not os.path.exists(file_path):
                raise FileNotFoundError("Template file not found")

            with open(file_path, "r", encoding="utf-8") as f:
                source = f.read()

            cells = [
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "outputs": [],
                    "source": block.strip()
                }
                for block in source.split("# COMMAND ----------")
                if block.strip()
            ]

            notebook = {
                "nbformat": 4,
                "nbformat_minor": 5,
                "metadata": {
                    "kernelspec": {
                        "display_name": "Python 3",
                        "language": "python",
                        "name": "python3"
                    },
                    "language_info": {"name": "python", "version": "3.10.0"}
                },
                "cells": cells
            }

            nb_str = json.dumps(notebook, indent=1)
            encoded_content = base64.b64encode(nb_str.encode("utf-8")).decode("utf-8")

            return {
                "filename": "Quality Template Notebook.ipynb",  
                "content": encoded_content
            }
        
        except FileNotFoundError as e:
            message = traceback.format_exc()
            app_logger.exception(f"Template file not found. Reason - {message}")
            raise HTTPException(status_code=404, detail=f"Template file not found: {str(e)}")
        
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Unable to retrieve template file. Reason - {message}")
            raise HTTPException(status_code=500, detail=f"Failed to retrieve template file: {str(e)}")
        
    def get_quality_tasks_by_dataset_ids(self, dataset_ids: List[int]) -> List[QualityTask]:
        """
        Retrieve all QualityTasks that are associated with the given dataset IDs.
        Args:
            dataset_ids (List[int]): List of dataset IDs to fetch quality tasks for.
        Returns:
            List[QualityTask]: List of QualityTask objects for the given datasets.
        Raises:
            HTTPException: If query fails or dataset_ids is invalid.
        """
        try:
            if not dataset_ids:
                app_logger.warning("No dataset IDs provided to get_quality_tasks_by_dataset_ids.")
                return []

            app_logger.info(f"Fetching QualityTasks for dataset_ids: {dataset_ids}")

            tasks = (
                self.db.query(QualityTask)
                .filter(QualityTask.dataset_id.in_(dataset_ids))
                .all()
            )

            app_logger.info(f"Retrieved {len(tasks)} quality tasks for dataset_ids {dataset_ids}")
            return tasks

        except Exception as e:
            app_logger.exception(f"Failed to retrieve quality tasks for dataset_ids {dataset_ids}. Error: {str(e)}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to retrieve quality tasks: {str(e)}"
            )