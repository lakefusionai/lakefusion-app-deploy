import json
import traceback
from datetime import datetime
from typing import List, Optional

from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import (
    Task, NotebookTask, RunIf, Source, CronSchedule,
    TaskDependency, JobParameter, JobRunAs,
    JobAccessControlRequest, JobPermissionLevel, SubmitTask
)

from lakefusion_utility.models.schema_evolution import (
    SchemaEvolutionJob, SchemaEvolutionEdit,
    SchemaEvolutionJobCreate, SchemaEvolutionEditCreate,
    SchemaEvolutionJobResponse, SchemaEvolutionEditResponse,
    SchemaEvolutionValidateResponse, ValidationError
)
from lakefusion_utility.models.entity import (
    Entity, EntityAttributes, EntityDatasetMapping, SurvivorshipRule,
    ValidationFunction
)
from lakefusion_utility.models.integration_hub import Integration_Hub
from lakefusion_utility.models.match_maven import Model_Experiment
from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.services.entity_service import EntityService
from lakefusion_utility.services.model_experiment_service import ExperimentService
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
from lakefusion_utility.utils.databricks_util import DatabricksJobManager, CatalogService
from lakefusion_utility.utils.notebook_path_utils import get_notebook_folder
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.databricks_util import DATABRICKS_HOST, get_resource_tags

app_logger = get_logger(__name__)

SUPPORTED_TYPES = {'BIGINT', 'BOOLEAN', 'DATE', 'DOUBLE', 'FLOAT', 'INT', 'SMALLINT', 'STRING', 'TINYINT', 'TIMESTAMP'}
ACTIVE_STATUSES = {'DRAFT', 'VALIDATED', 'PUBLISHED', 'RUNNING', 'FAILED', 'PENDING_UPDATE'}

# ─── SVR aggregation function compatibility by type category ──────
NUMERIC_TYPES = {'BIGINT', 'INT', 'SMALLINT', 'TINYINT', 'FLOAT', 'DOUBLE', 'INTEGER', 'DECIMAL', 'LONG', 'NUMBER'}
STRING_TYPES = {'STRING', 'VARCHAR', 'TEXT', 'CHAR'}
DATE_TYPES = {'DATE', 'TIMESTAMP', 'DATETIME'}
BOOLEAN_TYPES = {'BOOLEAN', 'BOOL'}

AGGREGATION_FUNCTIONS_BY_CATEGORY = {
    'numeric': {'sum', 'avg', 'min', 'max', 'count'},
    'string': {'concat', 'longest', 'shortest'},
    'date': {'earliest', 'latest'},
    'boolean': {'any_true', 'all_true'},
}

def _get_type_category(attr_type: str) -> str:
    t = (attr_type or '').upper()
    if t in NUMERIC_TYPES:
        return 'numeric'
    if t in STRING_TYPES:
        return 'string'
    if t in DATE_TYPES:
        return 'date'
    if t in BOOLEAN_TYPES:
        return 'boolean'
    return 'string'  # default fallback

def _get_allowed_aggregations(attr_type: str) -> set:
    return AGGREGATION_FUNCTIONS_BY_CATEGORY.get(_get_type_category(attr_type), set())


class SchemaEvolutionService:
    def __init__(self, db: Session):
        self.db = db
        self.db_config_service = DBConfigPropertiesService(db=self.db)
        self.notebook_path = self.db_config_service.getDBConfigProperties(key="notebook_path")

    # ─── Job CRUD ───────────────────────────────────────────────

    def create_job(self, entity_id: int, data: SchemaEvolutionJobCreate, created_by: str) -> SchemaEvolutionJob:
        try:
            entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")

            hub = self.db.query(Integration_Hub).filter(
                Integration_Hub.entity_id == entity_id,
                Integration_Hub.is_active == True
            ).first()
            if not hub:
                raise HTTPException(status_code=400, detail="Entity does not have an active Integration Hub")

            existing = self.db.query(SchemaEvolutionJob).filter(
                SchemaEvolutionJob.entity_id == entity_id,
                SchemaEvolutionJob.status.in_(ACTIVE_STATUSES)
            ).first()
            if existing:
                raise HTTPException(
                    status_code=409,
                    detail=f"An active schema evolution job already exists (id={existing.id}, status={existing.status})"
                )

            job = SchemaEvolutionJob(
                entity_id=entity_id,
                integration_hub_id=hub.id,
                name=data.name,
                created_by=created_by,
                description=data.description
            )
            self.db.add(job)
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(job)
            app_logger.info(f"Schema evolution job created: id={job.id}, entity_id={entity_id}")
            return job

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to create schema evolution job: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to create schema evolution job: {str(e)}")

    def get_job(self, job_id: int) -> SchemaEvolutionJob:
        job = self.db.query(SchemaEvolutionJob).filter(SchemaEvolutionJob.id == job_id).first()
        if not job:
            raise HTTPException(status_code=404, detail="Schema evolution job not found")
        return job

    def get_jobs_for_entity(self, entity_id: int) -> List[SchemaEvolutionJob]:
        return (
            self.db.query(SchemaEvolutionJob)
            .filter(SchemaEvolutionJob.entity_id == entity_id)
            .order_by(SchemaEvolutionJob.created_at.desc())
            .all()
        )

    def get_all_jobs(self) -> List[dict]:
        """Get all schema evolution jobs across all entities, enriched with entity name."""
        jobs = (
            self.db.query(SchemaEvolutionJob)
            .order_by(SchemaEvolutionJob.created_at.desc())
            .all()
        )
        # Build entity name lookup
        entity_ids = list({j.entity_id for j in jobs})
        entities = self.db.query(Entity).filter(Entity.id.in_(entity_ids)).all() if entity_ids else []
        entity_map = {e.id: e.name for e in entities}

        result = []
        for job in jobs:
            edits = []
            for e in (job.edits or []):
                edits.append({
                    "id": e.id, "job_id": e.job_id, "action_type": e.action_type,
                    "attribute_name": e.attribute_name, "attribute_label": e.attribute_label,
                    "attribute_description": e.attribute_description, "attribute_type": e.attribute_type,
                    "is_match_attribute": e.is_match_attribute or False,
                    "source_mappings": e.source_mappings, "survivorship_rule": e.survivorship_rule,
                    "validation_function": e.validation_function, "new_attribute_name": e.new_attribute_name,
                    "created_at": e.created_at.isoformat() if e.created_at else None,
                    "updated_at": e.updated_at.isoformat() if e.updated_at else None,
                })
            job_dict = {
                "id": job.id, "entity_id": job.entity_id, "integration_hub_id": job.integration_hub_id,
                "name": job.name, "description": job.description, "status": job.status,
                "databricks_job_id": job.databricks_job_id, "databricks_run_id": job.databricks_run_id,
                "error_message": job.error_message, "edits": edits,
                "created_at": job.created_at.isoformat() if job.created_at else None,
                "updated_at": job.updated_at.isoformat() if job.updated_at else None,
                "completed_at": job.completed_at.isoformat() if job.completed_at else None,
                "created_by": job.created_by,
                "entity_name": entity_map.get(job.entity_id, 'Unknown'),
            }
            result.append(job_dict)
        return result

    # ─── Edit CRUD ──────────────────────────────────────────────

    def add_edit(self, job_id: int, data: SchemaEvolutionEditCreate) -> SchemaEvolutionEdit:
        try:
            job = self._get_editable_job(job_id)

            if data.action_type != 'ADD_ATTRIBUTE':
                raise HTTPException(status_code=400, detail="Only ADD_ATTRIBUTE is supported")

            edit = SchemaEvolutionEdit(
                job_id=job_id,
                action_type=data.action_type,
                attribute_name=data.attribute_name,
                attribute_label=data.attribute_label,
                attribute_description=data.attribute_description,
                attribute_type=data.attribute_type,
                is_match_attribute=data.is_match_attribute,
                source_mappings=[m.dict() for m in data.source_mappings] if data.source_mappings else None,
                survivorship_rule=data.survivorship_rule.dict() if data.survivorship_rule else None,
                validation_function=data.validation_function.dict() if data.validation_function else None,
                new_attribute_name=data.new_attribute_name
            )
            self.db.add(edit)

            if job.status == 'VALIDATED':
                job.status = 'DRAFT'
                job.updated_at = datetime.utcnow()

            db_commit_auto_rollback(db=self.db)
            self.db.refresh(edit)
            app_logger.info(f"Edit added to job {job_id}: {data.attribute_name}")
            return edit

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to add edit: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to add edit: {str(e)}")

    def update_edit(self, edit_id: int, data: SchemaEvolutionEditCreate) -> SchemaEvolutionEdit:
        try:
            edit = self.db.query(SchemaEvolutionEdit).filter(SchemaEvolutionEdit.id == edit_id).first()
            if not edit:
                raise HTTPException(status_code=404, detail="Edit not found")

            job = self._get_editable_job(edit.job_id)

            edit.action_type = data.action_type
            edit.attribute_name = data.attribute_name
            edit.attribute_label = data.attribute_label
            edit.attribute_description = data.attribute_description
            edit.attribute_type = data.attribute_type
            edit.is_match_attribute = data.is_match_attribute
            edit.source_mappings = [m.dict() for m in data.source_mappings] if data.source_mappings else None
            edit.survivorship_rule = data.survivorship_rule.dict() if data.survivorship_rule else None
            edit.validation_function = data.validation_function.dict() if data.validation_function else None
            edit.new_attribute_name = data.new_attribute_name
            edit.updated_at = datetime.utcnow()

            if job.status == 'VALIDATED':
                job.status = 'DRAFT'
                job.updated_at = datetime.utcnow()

            db_commit_auto_rollback(db=self.db)
            self.db.refresh(edit)
            return edit

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to update edit: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to update edit: {str(e)}")

    def delete_edit(self, edit_id: int):
        try:
            edit = self.db.query(SchemaEvolutionEdit).filter(SchemaEvolutionEdit.id == edit_id).first()
            if not edit:
                raise HTTPException(status_code=404, detail="Edit not found")

            job = self._get_editable_job(edit.job_id)

            self.db.delete(edit)

            if job.status == 'VALIDATED':
                job.status = 'DRAFT'
                job.updated_at = datetime.utcnow()

            db_commit_auto_rollback(db=self.db)
            return {"message": "Edit deleted"}

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to delete edit: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to delete edit: {str(e)}")

    # ─── Validate ───────────────────────────────────────────────

    def validate_job(self, job_id: int, token: str = None) -> dict:
        try:
            job = self.get_job(job_id)
            if job.status not in ('DRAFT', 'FAILED'):
                raise HTTPException(status_code=400, detail=f"Cannot validate job in status {job.status}")

            errors = []

            if not job.edits:
                errors.append(ValidationError(field="edits", message="Job must have at least one edit"))
                return {"is_valid": False, "errors": [e.dict() for e in errors]}

            # ── Check master table exists (integration task must have run) ──
            if token:
                try:
                    entity = self.db.query(Entity).filter(Entity.id == job.entity_id).first()
                    catalog_name = (
                        self.db.query(DBConfigProperties)
                        .filter(DBConfigProperties.config_key == "catalog_name")
                        .first().config_value
                    )
                    entity_name = entity.name.lower().replace(" ", "_")
                    master_table = f"{catalog_name}.gold.{entity_name}_master_prod"

                    w = WorkspaceClient(host=DATABRICKS_HOST, token=token)
                    try:
                        w.tables.get(full_name=master_table)
                    except Exception:
                        errors.append(ValidationError(
                            field="entity",
                            message=f"Master table '{master_table}' does not exist. Run the integration pipeline at least once before using Schema Evolution."
                        ))
                        return {"is_valid": False, "errors": [e.dict() for e in errors]}
                except Exception as e:
                    app_logger.warning(f"Could not verify master table existence: {e}")

            existing_attrs = {
                a.name for a in
                self.db.query(EntityAttributes).filter(
                    EntityAttributes.entity_id == job.entity_id,
                    EntityAttributes.is_active == True
                ).all()
            }

            edit_attr_names = []
            entity_mappings = self.db.query(EntityDatasetMapping).filter(
                EntityDatasetMapping.entity_id == job.entity_id,
                EntityDatasetMapping.is_active == True
            ).all()
            mapped_dataset_ids = {m.dataset_id for m in entity_mappings}

            # Cache for dataset schemas (fetched from Databricks once per dataset)
            dataset_schema_cache = {}
            w = None
            if token:
                try:
                    w = WorkspaceClient(host=DATABRICKS_HOST, token=token)
                except Exception as e:
                    app_logger.warning(f"Could not init WorkspaceClient for type checking: {e}")

            for edit in job.edits:
                if edit.action_type != 'ADD_ATTRIBUTE':
                    errors.append(ValidationError(
                        edit_id=edit.id, field="action_type",
                        message=f"Only ADD_ATTRIBUTE is supported, got {edit.action_type}"
                    ))
                    continue

                if edit.attribute_name in existing_attrs:
                    errors.append(ValidationError(
                        edit_id=edit.id, field="attribute_name",
                        message=f"Attribute '{edit.attribute_name}' already exists in this entity"
                    ))

                if edit.attribute_name in edit_attr_names:
                    errors.append(ValidationError(
                        edit_id=edit.id, field="attribute_name",
                        message=f"Duplicate attribute name '{edit.attribute_name}' within this job"
                    ))
                edit_attr_names.append(edit.attribute_name)

                if not edit.attribute_type or edit.attribute_type.upper() not in SUPPORTED_TYPES:
                    errors.append(ValidationError(
                        edit_id=edit.id, field="attribute_type",
                        message=f"Unsupported type '{edit.attribute_type}'. Supported: {', '.join(sorted(SUPPORTED_TYPES))}"
                    ))

                if not edit.source_mappings or len(edit.source_mappings) == 0:
                    errors.append(ValidationError(
                        edit_id=edit.id, field="source_mappings",
                        message="At least one source mapping is required"
                    ))
                else:
                    for mapping in edit.source_mappings:
                        ds_id = mapping.get('dataset_id')
                        if ds_id not in mapped_dataset_ids:
                            errors.append(ValidationError(
                                edit_id=edit.id, field="source_mappings",
                                message=f"Dataset {ds_id} is not mapped to this entity"
                            ))

                # ── SVR aggregation function vs attribute type compatibility ──
                if edit.survivorship_rule and edit.attribute_type:
                    svr = edit.survivorship_rule
                    strategy = svr.get('strategy', '')
                    strategy_rule = svr.get('strategy_rule') or {}
                    # The key is 'function' in DB JSON (e.g. {"function": "concat"})
                    agg_function = strategy_rule.get('function') if isinstance(strategy_rule, dict) else None

                    if strategy == 'Aggregation' and agg_function:
                        allowed = _get_allowed_aggregations(edit.attribute_type)
                        if agg_function not in allowed:
                            type_cat = _get_type_category(edit.attribute_type)
                            errors.append(ValidationError(
                                edit_id=edit.id, field="survivorship_rule",
                                message=f"Aggregation '{agg_function}' is not compatible with type '{edit.attribute_type}' ({type_cat}). "
                                        f"Allowed: {', '.join(sorted(allowed))}"
                            ))

                # ── Source column datatype compatibility ──
                if edit.source_mappings and edit.attribute_type and w:
                    entity_type_upper = edit.attribute_type.upper()
                    entity_type_category = _get_type_category(entity_type_upper)
                    for mapping in edit.source_mappings:
                        ds_id = mapping.get('dataset_id')
                        ds_attr = mapping.get('dataset_attribute')
                        if not ds_id or not ds_attr:
                            continue
                        try:
                            from lakefusion_utility.models.dataset import Dataset
                            dataset = self.db.query(Dataset).filter(Dataset.id == ds_id).first()
                            if dataset and dataset.path:
                                # Use cached schema if available, otherwise fetch from Databricks
                                if dataset.path not in dataset_schema_cache:
                                    try:
                                        tbl_info = w.tables.get(full_name=dataset.path)
                                        col_map = {}
                                        if tbl_info and tbl_info.columns:
                                            for c in tbl_info.columns:
                                                col_map[c.name.lower()] = (c.type_name or '').upper()
                                        dataset_schema_cache[dataset.path] = col_map
                                    except Exception:
                                        dataset_schema_cache[dataset.path] = {}
                                col_types = dataset_schema_cache.get(dataset.path, {})
                                src_type = col_types.get(ds_attr.lower(), '')
                                if src_type:
                                    src_category = _get_type_category(src_type)
                                    # String entity type accepts any source (implicit cast to string)
                                    if entity_type_category != 'string' and src_category != entity_type_category:
                                        errors.append(ValidationError(
                                            edit_id=edit.id, field="source_mappings",
                                            message=f"Source column '{ds_attr}' (type: {src_type}) is not compatible with "
                                                    f"entity attribute type '{edit.attribute_type}'. "
                                                    f"Cannot map {src_category} to {entity_type_category}."
                                        ))
                        except Exception as e:
                            app_logger.warning(f"Could not check source column type for dataset {ds_id}, column {ds_attr}: {e}")

            if errors:
                return {"is_valid": False, "errors": [e.dict() for e in errors]}

            job.status = 'VALIDATED'
            job.updated_at = datetime.utcnow()
            db_commit_auto_rollback(db=self.db)
            app_logger.info(f"Job {job_id} validated successfully")
            return {"is_valid": True, "errors": []}

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to validate job: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to validate job: {str(e)}")

    # ─── Publish ────────────────────────────────────────────────

    def publish_job(self, job_id: int, token: str) -> SchemaEvolutionJob:
        try:
            job = self.get_job(job_id)
            if job.status != 'VALIDATED':
                raise HTTPException(status_code=400, detail=f"Cannot publish job in status {job.status}. Must be VALIDATED.")

            hub = self.db.query(Integration_Hub).filter(Integration_Hub.id == job.integration_hub_id).first()
            if not hub:
                raise HTTPException(status_code=404, detail="Integration Hub not found")

            # Check that integration pipeline is not currently running
            w = WorkspaceClient(host=DATABRICKS_HOST, token=token)
            for jid in [hub.job_id_1, hub.job_id_2]:
                if jid:
                    active_runs = list(w.jobs.list_runs(job_id=int(jid), active_only=True))
                    if active_runs:
                        raise HTTPException(
                            status_code=409,
                            detail="Integration pipeline is currently running. Wait for it to complete before publishing."
                        )

            # Pause integration pipeline
            job_manager = DatabricksJobManager(token)
            for jid in [hub.job_id_1, hub.job_id_2]:
                if jid:
                    job_manager.pause_job_schedule(int(jid))
            app_logger.info(f"Integration pipeline paused for entity {job.entity_id}")

            # Build and upload schema evolution JSON
            evolution_json = self._build_evolution_json(job)
            catalog_service = CatalogService(token, self.db)
            file_name = f"entity_{job.entity_id}_schema_evolution_{job.id}.json"
            catalog_service.upload_metadata_file_to_volume(file_name, evolution_json)
            json_path = f"/Volumes/{catalog_service.catalog_name}/metadata/metadata_files/{file_name}"
            app_logger.info(f"Schema evolution JSON uploaded to {json_path}")

            # Create or update Databricks job
            if not job.databricks_job_id:
                tasks_and_params = self._create_tasks_and_job_schema_evolution(job.id, job.entity_id, catalog_service.catalog_name)
                lakefusion_spn = (
                    self.db.query(DBConfigProperties)
                    .filter(DBConfigProperties.config_key == "lakefusion_spn")
                    .first()
                )
                run_as = lakefusion_spn.config_value if lakefusion_spn else None

                dbx_job_id = job_manager.create_job(
                    f"Schema_Evolution_Entity_{job.entity_id}_Job_{job.id}",
                    tasks_list=tasks_and_params[1],
                    job_parameters=tasks_and_params[2],
                    RunAs=run_as
                )
                job.databricks_job_id = str(dbx_job_id)
                app_logger.info(f"Databricks job created: {dbx_job_id}")
            else:
                app_logger.info(f"Reusing existing Databricks job: {job.databricks_job_id}")

            job.status = 'PUBLISHED'
            job.updated_at = datetime.utcnow()
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(job)
            return job

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to publish job: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to publish job: {str(e)}")

    # ─── Run ────────────────────────────────────────────────────

    def run_job(self, job_id: int, token: str) -> SchemaEvolutionJob:
        try:
            job = self.get_job(job_id)
            if job.status not in ('PUBLISHED', 'FAILED'):
                raise HTTPException(status_code=400, detail=f"Cannot run job in status {job.status}. Must be PUBLISHED or FAILED.")

            if not job.databricks_job_id:
                raise HTTPException(status_code=400, detail="Job has no Databricks job. Publish the job first.")

            # Check that integration pipeline is not currently running
            hub = self.db.query(Integration_Hub).filter(Integration_Hub.id == job.integration_hub_id).first()
            if hub:
                w = WorkspaceClient(host=DATABRICKS_HOST, token=token)
                for jid in [hub.job_id_1, hub.job_id_2]:
                    if jid:
                        active_runs = list(w.jobs.list_runs(job_id=int(jid), active_only=True))
                        if active_runs:
                            raise HTTPException(
                                status_code=409,
                                detail="Integration pipeline is currently running. Please wait for it to complete before running Schema Evolution. Do not run integration/merge jobs while the SE job is in progress."
                            )

            # If retrying from FAILED, re-pause the integration pipeline
            # (complete_job unpauses it on failure)
            if job.status == 'FAILED':
                hub = self.db.query(Integration_Hub).filter(Integration_Hub.id == job.integration_hub_id).first()
                if hub:
                    pause_manager = DatabricksJobManager(token)
                    for jid in [hub.job_id_1, hub.job_id_2]:
                        if jid:
                            pause_manager.pause_job_schedule(int(jid))
                    app_logger.info(f"Re-paused integration pipeline for retry of job {job_id}")
                job.error_message = None

            job_manager = DatabricksJobManager(token)
            response = job_manager.run_job(int(job.databricks_job_id))

            job.databricks_run_id = str(response.run_id) if hasattr(response, 'run_id') else str(response)
            job.status = 'RUNNING'
            job.updated_at = datetime.utcnow()
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(job)
            app_logger.info(f"Job {job_id} running, run_id={job.databricks_run_id}")
            return job

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to run job: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to run job: {str(e)}")

    # ─── Poll Status ────────────────────────────────────────────

    def poll_job_status(self, job_id: int, token: str) -> dict:
        try:
            job = self.get_job(job_id)

            if job.status != 'RUNNING' or not job.databricks_run_id:
                return {
                    "status": job.status,
                    "databricks_run_id": job.databricks_run_id,
                    "life_cycle_state": None,
                    "result_state": None
                }

            w = WorkspaceClient(host=DATABRICKS_HOST, token=token)
            run = w.jobs.get_run(run_id=int(job.databricks_run_id))

            life_cycle_state = run.state.life_cycle_state.value if run.state.life_cycle_state else None
            result_state = run.state.result_state.value if run.state.result_state else None

            TERMINAL_STATES = {'TERMINATED', 'INTERNAL_ERROR', 'SKIPPED'}
            if life_cycle_state in TERMINAL_STATES:
                if life_cycle_state == 'TERMINATED' and result_state == 'SUCCESS':
                    self.complete_job(job_id, 'COMPLETED', None, token)
                else:
                    error_msg = run.state.state_message or f"Job failed with result: {result_state} (lifecycle: {life_cycle_state})"
                    self.complete_job(job_id, 'FAILED', error_msg, token)
                # Re-query instead of refresh — complete_job committed, detaching original object
                job = self.get_job(job_id)

            return {
                "status": job.status,
                "databricks_run_id": job.databricks_run_id,
                "life_cycle_state": life_cycle_state,
                "result_state": result_state
            }

        except HTTPException:
            raise
        except Exception as e:
            app_logger.exception(f"Failed to poll job status: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to poll job status: {str(e)}")

    # ─── Sync Job Status ────────────────────────────────────────

    def sync_job_status(self, job_id: int, token: str) -> dict:
        """Check Databricks and sync job status. Handles:
        - Job run from Databricks UI (no run_id in our DB)
        - Polling failures (status stuck on RUNNING)
        - Manual 'check now' requests
        """
        try:
            job = self.get_job(job_id)

            if not job.databricks_job_id:
                return {"status": job.status, "message": "No Databricks job to sync"}

            # Don't sync jobs that aren't actionable
            if job.status in ('DRAFT', 'VALIDATED'):
                return {"status": job.status, "message": "Job not yet published"}

            w = WorkspaceClient(host=DATABRICKS_HOST, token=token)

            # Strategy 1: If we have a run_id, check that specific run
            # Strategy 2: If no run_id (or PUBLISHED), check latest run for the job
            run = None
            if job.databricks_run_id:
                run = w.jobs.get_run(run_id=int(job.databricks_run_id))
            else:
                runs = list(w.jobs.list_runs(job_id=int(job.databricks_job_id), limit=1))
                if runs:
                    run = runs[0]
                    # Store the discovered run_id
                    job.databricks_run_id = str(run.run_id)
                    job.updated_at = datetime.utcnow()
                    db_commit_auto_rollback(db=self.db)
                    job = self.get_job(job_id)  # fresh after commit

            if not run:
                return {"status": job.status, "message": "No runs found for this Databricks job"}

            life_cycle_state = run.state.life_cycle_state.value if run.state.life_cycle_state else None
            result_state = run.state.result_state.value if run.state.result_state else None

            TERMINAL_STATES = {'TERMINATED', 'INTERNAL_ERROR', 'SKIPPED'}

            if life_cycle_state in TERMINAL_STATES and job.status not in ('COMPLETED', 'FAILED'):
                # Terminal — call complete_job to handle entity updates + pipeline unpause
                if life_cycle_state == 'TERMINATED' and result_state == 'SUCCESS':
                    self.complete_job(job_id, 'COMPLETED', None, token)
                else:
                    error_msg = run.state.state_message or f"Job failed: {result_state} ({life_cycle_state})"
                    self.complete_job(job_id, 'FAILED', error_msg, token)
                job = self.get_job(job_id)  # fresh after commit

            elif life_cycle_state in ('RUNNING', 'PENDING') and job.status != 'RUNNING':
                # Running but our DB doesn't know — update
                job.status = 'RUNNING'
                if not job.databricks_run_id:
                    job.databricks_run_id = str(run.run_id)
                job.updated_at = datetime.utcnow()
                db_commit_auto_rollback(db=self.db)
                job = self.get_job(job_id)

            return {
                "status": job.status,
                "databricks_run_id": job.databricks_run_id,
                "life_cycle_state": life_cycle_state,
                "result_state": result_state,
                "message": "Status synced from Databricks"
            }

        except HTTPException:
            raise
        except Exception as e:
            app_logger.exception(f"Failed to sync job status: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to sync job status: {str(e)}")

    # ─── Complete Job ───────────────────────────────────────────

    def complete_job(self, job_id: int, status: str, error_message: Optional[str], token: str):
        try:
            job = self.get_job(job_id)
            hub = self.db.query(Integration_Hub).filter(Integration_Hub.id == job.integration_hub_id).first()

            # ── Step 1: For FAILED jobs, persist immediately ──
            if status == 'FAILED':
                job.status = 'FAILED'
                job.error_message = error_message
                job.updated_at = datetime.utcnow()
                db_commit_auto_rollback(db=self.db, raise_exception=True)
                app_logger.info(f"Job {job_id} status persisted: FAILED")
            elif status == 'COMPLETED':
                # ── Step 2: Apply entity config updates FIRST ──
                update_success = False
                try:
                    self._apply_edits_to_entity(job)

                    # Re-generate and upload entity.json and model.json
                    entity_service = EntityService(self.db)
                    experiment_service = ExperimentService(self.db)
                    catalog_service = CatalogService(token, self.db)

                    entity_data = entity_service.get_full_entity_by_id(job.entity_id).dict()
                    folder_path = catalog_service.create_volume_folder(job.entity_id, 'prod')
                    catalog_service.upload_data_as_json(folder_path, 'entity.json', entity_data)

                    if hub and hub.modelid:
                        model_data = experiment_service.get_model(hub.modelid).dict()
                        catalog_service.upload_data_as_json(folder_path, 'model.json', model_data)

                    app_logger.info(f"Entity config updates applied for job {job_id}")
                    update_success = True
                except Exception as e:
                    app_logger.exception(f"Entity config updates failed for job {job_id}: {e}")

                # ── Step 3: Set status based on update result ──
                job = self.get_job(job_id)  # fresh after potential commits in _apply_edits
                if update_success:
                    job.status = 'COMPLETED'
                    job.completed_at = datetime.utcnow()
                else:
                    job.status = 'PENDING_UPDATE'
                    job.error_message = "Pipeline completed but entity config updates failed. Use 'Apply Updates' to retry."
                job.updated_at = datetime.utcnow()
                db_commit_auto_rollback(db=self.db, raise_exception=True)
                app_logger.info(f"Job {job_id} status persisted: {job.status}")

            # ── Step 4: Unpause integration pipeline ──
            if hub:
                try:
                    job_manager = DatabricksJobManager(token)
                    for jid in [hub.job_id_1, hub.job_id_2]:
                        if jid:
                            job_manager.unpause_job_schedule(int(jid))
                    app_logger.info(f"Integration pipeline unpaused for entity {job.entity_id}")
                except Exception as e:
                    app_logger.exception(f"Failed to unpause pipeline for job {job_id}: {e}")

            app_logger.info(f"Job {job_id} completed with status: {job.status}")

        except HTTPException:
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to complete job: {traceback.format_exc()}")
            try:
                if hub:
                    job_manager = DatabricksJobManager(token)
                    for jid in [hub.job_id_1, hub.job_id_2]:
                        if jid:
                            job_manager.unpause_job_schedule(int(jid))
            except Exception:
                app_logger.exception("Failed to unpause integration pipeline after error")
            raise HTTPException(status_code=500, detail=f"Failed to complete job: {str(e)}")

    def apply_updates(self, job_id: int, token: str):
        """Manually trigger entity config updates for a PENDING_UPDATE job."""
        try:
            job = self.get_job(job_id)
            if job.status != 'PENDING_UPDATE':
                raise HTTPException(status_code=400, detail=f"Cannot apply updates when job status is {job.status}. Must be PENDING_UPDATE.")

            hub = self.db.query(Integration_Hub).filter(Integration_Hub.id == job.integration_hub_id).first()

            self._apply_edits_to_entity(job)

            entity_service = EntityService(self.db)
            experiment_service = ExperimentService(self.db)
            catalog_service = CatalogService(token, self.db)

            entity_data = entity_service.get_full_entity_by_id(job.entity_id).dict()
            folder_path = catalog_service.create_volume_folder(job.entity_id, 'prod')
            catalog_service.upload_data_as_json(folder_path, 'entity.json', entity_data)

            if hub and hub.modelid:
                model_data = experiment_service.get_model(hub.modelid).dict()
                catalog_service.upload_data_as_json(folder_path, 'model.json', model_data)

            job = self.get_job(job_id)
            job.status = 'COMPLETED'
            job.completed_at = datetime.utcnow()
            job.error_message = None
            job.updated_at = datetime.utcnow()
            db_commit_auto_rollback(db=self.db, raise_exception=True)
            self.db.refresh(job)
            app_logger.info(f"Job {job_id} updates applied successfully — status set to COMPLETED")
            return job

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to apply updates for job {job_id}: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to apply updates: {str(e)}")

    # ─── Delete Job ────────────────────────────────────────────

    def delete_job(self, job_id: int, token: str):
        try:
            job = self.get_job(job_id)

            # Block deletion of running jobs
            if job.status == 'RUNNING':
                raise HTTPException(
                    status_code=400,
                    detail="Cannot delete a running job. Wait for it to complete or fail."
                )

            # If job has a Databricks job, clean it up
            if job.databricks_job_id:
                try:
                    job_manager = DatabricksJobManager(token)
                    job_manager.delete_job(int(job.databricks_job_id))
                    app_logger.info(f"Deleted Databricks job {job.databricks_job_id}")
                except Exception as e:
                    app_logger.warning(f"Failed to delete Databricks job {job.databricks_job_id}: {e}")

            # Delete the job (edits cascade via FK ondelete='CASCADE')
            self.db.delete(job)
            db_commit_auto_rollback(db=self.db)
            app_logger.info(f"Deleted schema evolution job {job_id}")
            return {"message": f"Job {job_id} deleted"}

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to delete job: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to delete job: {str(e)}")

    # ─── Rollback Job ─────────────────────────────────────────────

    def rollback_job(self, job_id: int, token: str):
        """Rollback a FAILED schema evolution job by dropping added columns from Delta tables.
        Submits a one-time Databricks run of the Rollback notebook, then resets job to PUBLISHED.
        """
        try:
            job = self.get_job(job_id)

            # Only FAILED jobs can be rolled back
            if job.status != 'FAILED':
                raise HTTPException(
                    status_code=400,
                    detail=f"Cannot rollback job in status '{job.status}'. Only FAILED jobs can be rolled back."
                )

            if not job.databricks_job_id:
                raise HTTPException(
                    status_code=400,
                    detail="Job has no Databricks job. Nothing to rollback."
                )

            # Get catalog_name and notebook path
            catalog_name = (
                self.db.query(DBConfigProperties)
                .filter(DBConfigProperties.config_key == "catalog_name")
                .first().config_value
            )
            notebook_folder = get_notebook_folder('schema-evolution', self.db)

            # Submit a one-time run of the Rollback notebook
            w = WorkspaceClient(host=DATABRICKS_HOST, token=token)
            run = w.jobs.submit(
                run_name=f"Rollback_Schema_Evolution_Job_{job_id}",
                tasks=[
                    SubmitTask(
                        task_key="Rollback_Schema_Evolution",
                        notebook_task=NotebookTask(
                            notebook_path=f"{self.notebook_path}/src/{notebook_folder}/Rollback_Schema_Evolution",
                            base_parameters={
                                "se_job_id": str(job_id),
                                "entity_id": str(job.entity_id),
                                "catalog_name": catalog_name
                            },
                            source=Source.WORKSPACE,
                        )
                    )
                ]
            )

            # Reset job to PUBLISHED so it can be re-run after rollback
            job.status = 'PUBLISHED'
            job.error_message = None
            job.updated_at = datetime.utcnow()
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(job)

            app_logger.info(f"Rollback submitted for job {job_id} (run_id={run.run_id})")
            return {"message": f"Rollback submitted. Job reset to PUBLISHED.", "run_id": str(run.run_id)}

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to rollback job: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to rollback job: {str(e)}")

    # ─── Toggle Schema Evolution ────────────────────────────────

    def toggle_schema_evolution(self, entity_id: int, enabled: bool):
        try:
            entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
            if not entity:
                raise HTTPException(status_code=404, detail="Entity not found")

            entity.schema_evolution_enabled = enabled
            db_commit_auto_rollback(db=self.db)
            return {"entity_id": entity_id, "schema_evolution_enabled": enabled}

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"Failed to toggle schema evolution: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to toggle: {str(e)}")

    # ─── Private Helpers ────────────────────────────────────────

    def _get_editable_job(self, job_id: int) -> SchemaEvolutionJob:
        job = self.get_job(job_id)
        if job.status not in ('DRAFT', 'VALIDATED', 'FAILED'):
            raise HTTPException(
                status_code=400,
                detail=f"Cannot modify edits when job status is {job.status}. Must be DRAFT, VALIDATED, or FAILED."
            )
        if job.status == 'VALIDATED':
            job.status = 'DRAFT'
            db_commit_auto_rollback(db=self.db)
        return job

    def _build_evolution_json(self, job: SchemaEvolutionJob) -> dict:
        entity = self.db.query(Entity).filter(Entity.id == job.entity_id).first()
        hub = self.db.query(Integration_Hub).filter(Integration_Hub.id == job.integration_hub_id).first()

        catalog_name = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first().config_value
        )

        entity_name = entity.name.lower().replace(" ", "_")
        experiment_id = "prod"
        id_key = "lakefusion_id"

        master_table = f"{catalog_name}.gold.{entity_name}_master_{experiment_id}"
        unified_table = f"{catalog_name}.silver.{entity_name}_unified_{experiment_id}"
        avs_table = f"{master_table}_attribute_version_sources"

        # Find the entity's primary key attribute (the attribute with is_primary_key=True)
        pk_attribute = self.db.query(EntityAttributes).filter(
            EntityAttributes.entity_id == job.entity_id,
            EntityAttributes.is_primary_key == True
        ).first()
        pk_attr_name = pk_attribute.name if pk_attribute else None

        edits_list = []
        for edit in job.edits:
            resolved_mappings = []
            if edit.source_mappings:
                for mapping in edit.source_mappings:
                    ds_id = mapping.get('dataset_id')
                    ds_attr = mapping.get('dataset_attribute')

                    dm = self.db.query(EntityDatasetMapping).filter(
                        EntityDatasetMapping.entity_id == job.entity_id,
                        EntityDatasetMapping.dataset_id == ds_id
                    ).first()

                    from lakefusion_utility.models.dataset import Dataset
                    dataset = self.db.query(Dataset).filter(Dataset.id == ds_id).first()
                    dataset_path = dataset.path if dataset else ""

                    if dm and dm.use_cleaned_table:
                        dataset_path = f"{dataset_path}_cleaned"

                    is_primary = dm.is_primary if dm else False

                    # Determine PK: find which dataset column maps to the entity's PK attribute
                    dataset_pk = "id"
                    if pk_attr_name and dm and dm.attributes:
                        for attr_map in dm.attributes:
                            if attr_map.get('entity_attribute') == pk_attr_name:
                                dataset_pk = attr_map.get('dataset_attribute', 'id')
                                break

                    resolved_mappings.append({
                        "dataset_id": ds_id,
                        "dataset_path": dataset_path,
                        "dataset_attribute": ds_attr,
                        "dataset_primary_key": dataset_pk,
                        "is_primary": is_primary
                    })

            edit_dict = {
                "action_type": edit.action_type,
                "attribute_name": edit.attribute_name,
                "attribute_label": edit.attribute_label or edit.attribute_name,
                "attribute_type": edit.attribute_type,
                "is_match_attribute": edit.is_match_attribute or False,
                "source_mappings": resolved_mappings,
            }
            if edit.survivorship_rule:
                edit_dict["survivorship_rule"] = edit.survivorship_rule
            if edit.validation_function:
                edit_dict["validation_function"] = edit.validation_function

            edits_list.append(edit_dict)

        return {
            "job_id": job.id,
            "entity_id": job.entity_id,
            "entity_name": entity_name,
            "catalog_name": catalog_name,
            "experiment_id": experiment_id,
            "id_key": id_key,
            "master_table": master_table,
            "unified_table": unified_table,
            "attribute_version_sources_table": avs_table,
            "edits": edits_list
        }

    def _create_tasks_and_job_schema_evolution(self, job_id: int, entity_id: int, catalog_name: str):
        parameters = {
            "se_job_id": str(job_id),
            "entity_id": str(entity_id),
            "catalog_name": catalog_name,
            "experiment_id": "prod"
        }

        notebook_folder = get_notebook_folder('schema-evolution', self.db)

        tasks_list = [
            Task(
                task_key="Parse_Schema_Evolution_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{notebook_folder}/Parse_Schema_Evolution_JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Alter_Tables",
                depends_on=[TaskDependency(task_key="Parse_Schema_Evolution_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{notebook_folder}/Alter_Tables",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Backfill_From_Sources",
                depends_on=[TaskDependency(task_key="Alter_Tables")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{notebook_folder}/Backfill_From_Sources",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Sync_Derived_Tables",
                depends_on=[TaskDependency(task_key="Backfill_From_Sources")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{notebook_folder}/Sync_Derived_Tables",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Update_Match_Config",
                depends_on=[TaskDependency(task_key="Sync_Derived_Tables")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{notebook_folder}/Update_Match_Config",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Validate_Schema_Evolution",
                depends_on=[TaskDependency(task_key="Update_Match_Config")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{notebook_folder}/Validate_Schema_Evolution",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        ]

        job_parameters_list = [
            JobParameter(name="se_job_id", default=str(job_id)),
            JobParameter(name="entity_id", default=str(entity_id)),
            JobParameter(name="catalog_name", default=catalog_name),
            JobParameter(name="experiment_id", default="prod"),
        ]

        return [None, tasks_list, job_parameters_list, None, None]

    def _apply_edits_to_entity(self, job: SchemaEvolutionJob):
        """Apply completed schema evolution edits to MySQL entity records.
        All inserts/updates use dedup guards so this is idempotent (safe if called twice).
        """
        for edit in job.edits:
            if edit.action_type != 'ADD_ATTRIBUTE':
                continue

            # ── 1. EntityAttributes (dedup on entity_id + name) ──
            existing_attr = self.db.query(EntityAttributes).filter(
                EntityAttributes.entity_id == job.entity_id,
                EntityAttributes.name == edit.attribute_name,
                EntityAttributes.is_active == True
            ).first()

            if not existing_attr:
                new_attr = EntityAttributes(
                    entity_id=job.entity_id,
                    name=edit.attribute_name,
                    description=edit.attribute_description or '',
                    type=edit.attribute_type,
                    label=edit.attribute_label or edit.attribute_name,
                    created_by=job.created_by,
                    is_active=True,
                    is_primary_key=False,
                    show_in_ui=True,
                    is_label=False
                )
                self.db.add(new_attr)
                app_logger.info(f"Added entity attribute: {edit.attribute_name}")
            else:
                app_logger.info(f"Entity attribute '{edit.attribute_name}' already exists — skipping")

            # ── 2. EntityDatasetMapping (dedup on entity_attribute in JSON array) ──
            if edit.source_mappings:
                for mapping in edit.source_mappings:
                    ds_id = mapping.get('dataset_id')
                    ds_attr = mapping.get('dataset_attribute')

                    dm = self.db.query(EntityDatasetMapping).filter(
                        EntityDatasetMapping.entity_id == job.entity_id,
                        EntityDatasetMapping.dataset_id == ds_id
                    ).first()

                    if dm:
                        current_attrs = list(dm.attributes or [])
                        already_mapped = any(
                            a.get('entity_attribute') == edit.attribute_name
                            for a in current_attrs
                        )
                        if not already_mapped:
                            current_attrs.append({
                                "entity_attribute": edit.attribute_name,
                                "dataset_attribute": ds_attr
                            })
                            dm.attributes = current_attrs
                            app_logger.info(f"Added dataset mapping: {edit.attribute_name} -> {ds_attr} (dataset {ds_id})")
                        else:
                            app_logger.info(f"Dataset mapping for '{edit.attribute_name}' already exists in dataset {ds_id} — skipping")

            # ── 3. SurvivorshipRule (dedup on attribute in rules JSON array) ──
            if edit.survivorship_rule:
                svr = edit.survivorship_rule
                existing_rules = self.db.query(SurvivorshipRule).filter(
                    SurvivorshipRule.entity_id == job.entity_id,
                    SurvivorshipRule.is_active == True
                ).all()

                if existing_rules:
                    default_rule = next((r for r in existing_rules if r.is_default), existing_rules[0])
                    current_rules = list(default_rule.rules or [])
                    already_has_rule = any(
                        r.get('attribute') == edit.attribute_name
                        for r in current_rules
                    )
                    if not already_has_rule:
                        current_rules.append({
                            "attribute": edit.attribute_name,
                            "strategy": svr.get('strategy'),
                            "strategyRule": svr.get('strategy_rule'),
                            "ignoreNull": svr.get('ignore_null', False)
                        })
                        default_rule.rules = current_rules
                        app_logger.info(f"Added SVR rule for '{edit.attribute_name}' to default rule group")
                    else:
                        app_logger.info(f"SVR rule for '{edit.attribute_name}' already exists — skipping")

            # ── 4. ValidationFunction (dedup on entity_id + attribute_name) ──
            if edit.validation_function:
                vf = edit.validation_function
                existing_vf = self.db.query(ValidationFunction).filter(
                    ValidationFunction.entity_id == job.entity_id,
                    ValidationFunction.attribute_name == edit.attribute_name,
                    ValidationFunction.is_active == True
                ).first()

                if not existing_vf:
                    func_name = vf.get('function_name') or ''
                    func_type = vf.get('function_type') or 'user_defined'
                    func_def = vf.get('function_definition') or ''

                    if func_name and not func_def:
                        try:
                            temp_vf = ValidationFunction(
                                entity_id=job.entity_id,
                                attribute_name=edit.attribute_name,
                                function_name=func_name,
                                function_type=func_type,
                                function_definition='',
                                validation_message='',
                                validation_level='error',
                                created_by=job.created_by
                            )
                            definition_info = temp_vf.get_function_definition(self.db)
                            func_def = definition_info.get('function_definition', '')
                            func_type = definition_info.get('function_definition_type', func_type)
                        except Exception as e:
                            app_logger.warning(f"Could not resolve function definition for '{func_name}': {e}")

                    new_vf = ValidationFunction(
                        entity_id=job.entity_id,
                        attribute_name=edit.attribute_name,
                        function_name=func_name,
                        function_type=func_type,
                        function_definition=func_def,
                        validation_message=vf.get('validation_message') or '',
                        validation_level=vf.get('validation_level') or 'error',
                        created_by=job.created_by
                    )
                    self.db.add(new_vf)
                    app_logger.info(f"Added validation function for '{edit.attribute_name}'")
                else:
                    app_logger.info(f"Validation function for '{edit.attribute_name}' already exists — skipping")

        db_commit_auto_rollback(db=self.db, raise_exception=True)
        app_logger.info(f"Applied {len(job.edits)} edits to entity {job.entity_id}")

        # ── 5. Model_Experiment attributes (add match attrs to model) ──
        match_edits = [e for e in job.edits if e.is_match_attribute and e.action_type == 'ADD_ATTRIBUTE']
        if match_edits:
            hub = self.db.query(Integration_Hub).filter(
                Integration_Hub.id == job.integration_hub_id
            ).first()
            if hub and hub.modelid:
                model = self.db.query(Model_Experiment).filter(
                    Model_Experiment.id == hub.modelid
                ).first()
                if model:
                    current_attrs = list(model.attributes or [])
                    for edit in match_edits:
                        entity_attr = self.db.query(EntityAttributes).filter(
                            EntityAttributes.entity_id == job.entity_id,
                            EntityAttributes.name == edit.attribute_name,
                            EntityAttributes.is_active == True
                        ).first()
                        if entity_attr:
                            already_in = any(
                                (a.get('name') if isinstance(a, dict) else getattr(a, 'name', None))
                                == edit.attribute_name for a in current_attrs
                            )
                            if not already_in:
                                attr_dict = {
                                    "id": entity_attr.id,
                                    "entity_id": entity_attr.entity_id,
                                    "name": entity_attr.name,
                                    "description": entity_attr.description,
                                    "type": entity_attr.type,
                                    "label": entity_attr.label,
                                    "created_at": entity_attr.created_at.isoformat() if entity_attr.created_at else None,
                                    "created_by": entity_attr.created_by,
                                    "is_active": entity_attr.is_active,
                                    "is_primary_key": entity_attr.is_primary_key,
                                    "show_in_ui": entity_attr.show_in_ui,
                                    "is_label": entity_attr.is_label,
                                }
                                current_attrs.append(attr_dict)
                                app_logger.info(f"Added match attribute '{edit.attribute_name}' to model {hub.modelid}")
                    model.attributes = current_attrs
                    flag_modified(model, 'attributes')
                    db_commit_auto_rollback(db=self.db, raise_exception=True)
                    app_logger.info(f"Updated model {hub.modelid} with {len(match_edits)} match attribute(s)")


# ─── Cron Job: Poll Databricks for RUNNING SE Jobs ────────────────

def check_schema_evolution_status(db: Session):
    """Cron job: poll Databricks for RUNNING schema evolution jobs and update status."""
    import os

    app_logger.info("Starting check_schema_evolution_status")
    try:
        running_jobs = db.query(SchemaEvolutionJob).filter(
            SchemaEvolutionJob.status == 'RUNNING'
        ).all()

        if not running_jobs:
            app_logger.info("No SE jobs in RUNNING state")
            return

        token = os.environ.get('LAKEFUSION_DATABRICKS_DAPI', '')
        if not token:
            app_logger.error("LAKEFUSION_DATABRICKS_DAPI not configured — cannot poll SE jobs")
            return

        app_logger.info(f"Polling {len(running_jobs)} RUNNING SE job(s)")

        for job in running_jobs:
            try:
                if not job.databricks_run_id:
                    app_logger.warning(f"SE job {job.id} is RUNNING but has no databricks_run_id — skipping")
                    continue

                service = SchemaEvolutionService(db)
                result = service.poll_job_status(job.id, token)
                app_logger.info(f"SE job {job.id}: status={result.get('status')}, "
                                f"lifecycle={result.get('life_cycle_state')}, result={result.get('result_state')}")

            except Exception as e:
                app_logger.error(f"Error polling SE job {job.id}: {e}")
                app_logger.error(traceback.format_exc())

    except Exception as e:
        app_logger.error(f"Error in check_schema_evolution_status: {e}")
        app_logger.error(traceback.format_exc())

    app_logger.info("Finished check_schema_evolution_status")
