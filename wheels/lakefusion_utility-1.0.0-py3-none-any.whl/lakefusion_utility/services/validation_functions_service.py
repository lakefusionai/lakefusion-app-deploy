import ast
import traceback
from lakefusion_utility.services.entity_service import EntityService
from lakefusion_utility.utils.databricks_util import CatalogService
from sqlalchemy.orm import Session
from fastapi import HTTPException
from lakefusion_utility.utils.app_db import db_commit_auto_rollback  # Import the db_commit_auto_rollback function
import logging
from lakefusion_utility import validation_functions_constant
from lakefusion_utility.models.entity import ValidationFunction,ValidationFunctionCreate,Entity,ValidationUserDefinedFunction,ValidationUserDefinedFunctionCreate
import inspect
from lakefusion_utility import validation_functions_constant as ValidationFunctionConstant

app_logger = logging.getLogger(__name__)

class ValidationFunctionsService:
    def __init__(self, db: Session):
        """Initializes the entityService with a database session.
        
        Args:
            db: SQLAlchemy session object.
        """
        self.db=db
        
    def update_entity_metadata_file_for_integration_job(self, token: str, entity_id: int):
        """
        Run only when an entity is part of an integration job.
        Updates the metadata file for an entity's integration job in the volume folder.

        Args:
            token (str): Authentication token.
            entity_id (int): The ID of the entity.

        Raises:
            HTTPException: If the entity is not found or an error occurs.
        """
        try:
            entity_service = EntityService(self.db)
            entity = entity_service.get_full_entity_by_id(entity_id).dict()

            if not entity:
                app_logger.error(f"Entity not found for ID {entity_id}")
                raise HTTPException(status_code=404, detail="Entity not found")
            
            volume_id = "prod"
            create_volume_folder = CatalogService(token, self.db)
            folder_path = create_volume_folder.create_volume_folder(entity_id, volume_id)
            if folder_path:
                create_volume_folder.upload_data_as_json(folder_path, 'entity.json', entity)
                app_logger.info(f"Metadata file updated for entity {entity_id} in volume {volume_id}")
            else:
                app_logger.error(f"Failed to create volume folder for entity {entity_id} and volume_id {volume_id}")
                raise HTTPException(status_code=500, detail="Failed to create volume folder")
            
        except HTTPException as http_exc:
            raise http_exc
        except Exception as e:
            app_logger.exception(f'Unable to update metadata file for entity {entity_id}. Reason - {str(e)}')
            raise HTTPException(status_code=500, detail={
                "status": "error",
                "message": f"Failed to update metadata file: {str(e)}",
                "data": None
            })
       

    def read_validation_functions(self):
        """Retrieves entitys from the database based on the `is_active` flag.
        
        Args:
            is_active: Filter entitys by their active status.
            
        Returns:
            A list of entitys based on the `is_active` flag.
        """
        try:
            functions_list = []
            # Inspect the constants module to find all the functions
            for name, func in inspect.getmembers(validation_functions_constant, inspect.isfunction):
            # Append the function name and its docstring (description)
                 functions_list.append({
                "function_name": name,
                "description": inspect.getdoc(func) or "No description available",
                "source_code": inspect.getsource(func).strip()
                 })

            return functions_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch validation functions. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch validation functions: {str(e)}")
        finally:
            self.db.close()

    def create_validation_function_entry(self, validation_create: ValidationFunctionCreate, entity_id: int, token: str, is_integration_job: bool = False):
        """
        Creates a new validation function entry and saves it to the database, with robust validation and error handling.
        """
        try:
            app_logger.info(f"Starting validation function creation for entity {entity_id}")

           
            # Validate entity exists and is active
            entity = self.db.query(Entity).filter(
                Entity.id == entity_id,
                Entity.is_active == True
            ).first()
            if not entity:
                raise HTTPException(status_code=404, detail="Active entity not found")
            # Check for duplicate validation function (same entity, attribute, and function name)
            existing_func = self.db.query(ValidationFunction).filter(
                ValidationFunction.entity_id == entity_id,
                ValidationFunction.attribute_name == validation_create.attribute_name,
                ValidationFunction.function_name == validation_create.function_name,
                ValidationFunction.is_active == True
            ).first()
            if existing_func:
                raise HTTPException(
                    status_code=409,
                    detail=f"Validation function '{validation_create.function_name}' for attribute '{validation_create.attribute_name}' already exists for entity {entity_id}"
                )
            # Resolve function definition
            temp_instance = ValidationFunction(
                entity_id=entity_id,
                attribute_name=validation_create.attribute_name,
                function_name=validation_create.function_name,
                function_type=validation_create.function_type,
                function_definition=validation_create.function_definition,  # placeholder
                validation_message=validation_create.validation_message,
                validation_level=validation_create.validation_level,
                created_by=validation_create.created_by,
            )
           
            definition_info = temp_instance.get_function_definition(self.db)
            resolved_function_definition = definition_info.get("function_definition")
            resolved_function_type = definition_info.get("function_definition_type")
            
            # Create new validation function entry
            db_entity = ValidationFunction(
                entity_id=entity_id,
                attribute_name=validation_create.attribute_name,
                function_name=validation_create.function_name,
                function_type=resolved_function_type,
                function_definition=resolved_function_definition,
                validation_message=validation_create.validation_message,
                validation_level=validation_create.validation_level,
                created_by=validation_create.created_by,
            )
            
            self.db.add(db_entity)
            self.db.flush()  # Ensure the insert is processed before any further actions
            # If this is part of an integration job, update metadata
            if is_integration_job:
                app_logger.debug("Integration job detected - updating entity metadata file")
                ValidationFunctionsService(self.db).update_entity_metadata_file_for_integration_job(token, entity_id)

            # Commit the transaction
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(db_entity)

            app_logger.info(f"Successfully created validation function '{db_entity.function_name}' for entity {entity_id}")

            return db_entity

        except HTTPException as he:
            app_logger.warning(f"HTTP error during validation function creation: {he.detail}")
            raise he
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create validation function entry. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to create validation function entry: {str(e)}")
        

    def update_validation_function(self,entity_id: int, validation_id: int, validation_update: ValidationFunctionCreate, token: str, is_integration_job: bool = False):
        """
        Update an existing validation function's details based on entity_id and validation_id.
    
       Args:
        db: SQLAlchemy session.
        validation_update: Pydantic model containing updated validation function details.
        entity_id: ID of the entity the validation function belongs to.
        validation_id: ID of the validation function to update.
    
       Returns:
        The updated validation function object.
    
       Raises:
        HTTPException: If the entity or validation function is not found.
       """
        try:
          # Fetch the validation function based on entity_id and validation_id
            validation_function = self.db.query(ValidationFunction).filter(ValidationFunction.entity_id == entity_id,
            ValidationFunction.validation_id == validation_id).first()
        
            if not validation_function:
               raise HTTPException(status_code=404, detail="Validation function not found")
            
            validation_function.attribute_name = validation_update.attribute_name
            validation_function.function_name = validation_update.function_name
            validation_function.function_type = validation_update.function_type
            validation_function.validation_message = validation_update.validation_message
            validation_function.validation_level = validation_update.validation_level
            validation_function.created_by = validation_update.created_by
    
            # Resolve function definition dynamically
            if validation_update.function_type == "user_defined":
                # from ValidationUserDefinedFunction table
                udf = (
                    self.db.query(ValidationUserDefinedFunction)
                    .filter_by(function_name=validation_update.function_name)
                    .first()
                )
                if udf:
                    validation_function.function_definition = udf.function_definition
            else:
                # from constants module
                func = getattr(ValidationFunctionConstant, validation_update.function_name, None)
                if func:
                    validation_function.function_definition = inspect.getsource(func)
    
            # Commit the changes
            self.db.commit()

            if is_integration_job:
                app_logger.debug("Integration job detected - updating entity metadata file")
                ValidationFunctionsService(self.db).update_entity_metadata_file_for_integration_job(token, entity_id)
            self.db.refresh(validation_function)  # reload fresh values
    
            return validation_function
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update validation function. Reason - {message}')
            self.db.rollback()  # Rollback in case of error
            raise HTTPException(status_code=500, detail=f"Failed to update validation function: {str(e)}")
        finally:
            self.db.close()
    
    def read_validationfunctionsentries(self, entity_id:int,is_active: bool = True):
        """Retrieves entitys from the database based on the `is_active` flag.
        
        Args:
            is_active: Filter entitys by their active status.
            
        Returns:
            A list of entitys based on the `is_active` flag.
        """
        try:
            db_entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
            # Raise an HTTPException with 404 status code if entity not found
            if db_entity is None:
              raise HTTPException(status_code=404, detail="Entity not found")
            entity_q = self.db.query(ValidationFunction).filter(ValidationFunction.entity_id == entity_id)
            if is_active:
                entity_q = entity_q.filter_by(is_active=is_active)
            entitys = entity_q.all()
            return entitys
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch validation function entries. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch validation function entries: {str(e)}")
    
    def get_validationfunctionsentry_by_id(self, entity_id: int,validation_id:int):
        """Retrieves a entity object by its ID.
        
        Args:
            entity_id: The ID of the entity to retrieve.
            
        Returns:
            The entity object.
        
        Raises:
            HTTPException: If the entity is not found.
        """
        try:
            # Fetch the entity by ID
            db_entity = self.db.query(ValidationFunction).filter(ValidationFunction.entity_id == entity_id).first()
            if db_entity is None:
              raise HTTPException(status_code=404, detail="Entity not found")
            db_validation = self.db.query(ValidationFunction).filter(ValidationFunction.entity_id == entity_id).filter(ValidationFunction.validation_id == validation_id).first()
            if db_validation is None or not db_validation.is_active:
                return None
            return db_validation  # Return the found entity
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch validation function entry with ID {validation_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch validation function entry: {str(e)}")
        
    def delete_validationfunctionentries_by_id(self, entity_id: int,validation_id:int,  token: str, is_integration_job: bool = False):
        """Deletes a entity by ID permanently.
        
        Args:
            entity_id: The ID of the entity to delete.
            
        Returns:
            A confirmation message or the deleted entity object.
            
        Raises:
            HTTPException: If the entity is not found or an error occurs during deletion.
        """
        try:
            # Fetch the entity by ID
            db_entity = self.db.query(ValidationFunction).filter(ValidationFunction.entity_id == entity_id).first()
            if db_entity is None:
                return {"detail": "entity not found"}
            db_validation = self.db.query(ValidationFunction).filter(ValidationFunction.entity_id == entity_id).filter(ValidationFunction.validation_id == validation_id).first()
            if db_validation is None:
                return {"detail": "entity found but validation entry not found"}
            
            self.db.delete(db_validation)  # Permanently delete the entity

            self.db.flush() # Ensure the delete is processed before any further actions

            if is_integration_job:
                app_logger.debug("Integration job detected - updating entity metadata file")
                ValidationFunctionsService(self.db).update_entity_metadata_file_for_integration_job(token, entity_id)

            db_commit_auto_rollback(db=self.db)  # Commit changes and handle rollback on failure
            return {"detail": " validation entry successfully deleted"}
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete validation function entry. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to delete validation function entry: {str(e)}")

class ValidationUserdefinedFunctionsService:
    def __init__(self, db: Session):
        """Initializes the entityService with a database session.
        
        Args:
            db: SQLAlchemy session object.
        """
        self.db=db
       

    
    def create_validation_userdefined_function(self,validation_create:ValidationUserDefinedFunctionCreate):
        """Creates a new entity and saves it to the database.
        
        Args:
            entity_create: Pydantic model containing entity details.
            
        Returns:
            The created entity object.
        
        Raises:
            HTTPException: If there's an error during creation.
        """
        try:
            # Validate Python syntax before saving
            try:
                ast.parse(validation_create.function_definition)
            except SyntaxError as e:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid Python syntax at line {e.lineno}: {e.msg}"
                )

            db_func = ValidationUserDefinedFunction(
               function_name=validation_create.function_name,
               function_type=validation_create.function_type,
               function_definition=validation_create.function_definition,
               created_by=validation_create.created_by)
            self.db.add(db_func)  # Add the entity to the session
            db_commit_auto_rollback(db=self.db)  # Commit changes and handle rollback on failure
            self.db.refresh(db_func)  # Refresh the instance to get the new data
            return db_func  # Return the created entity
        except HTTPException:
            raise
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create user defined function. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create user defined function: {str(e)}")
    
    def read_validation_userdefined_function_entries(self,is_active: bool = True):
        """Retrieves entitys from the database based on the `is_active` flag.
        
        Args:
            is_active: Filter entitys by their active status.
            
        Returns:
            A list of entitys based on the `is_active` flag.
        """
        try:
            userdefined_q = self.db.query(ValidationUserDefinedFunction)
            if is_active:
                userdefined_q = userdefined_q.filter_by(is_active=is_active)
            entitys = userdefined_q.all()
            return entitys
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch user defined functions. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch user defined functions: {str(e)}")
    
    def get_validation_userdefinedfunction_entries_by_id(self, function_id: int):
        """Retrieves a function by its ID.
        
        Args:
            function_id: The ID of the function to retrieve.
            
        Returns:
            The function object.
        
        Raises:
            HTTPException: If the function is not found.
        """
        try:
            # Fetch the entity by ID
            db_userdefined = self.db.query(ValidationUserDefinedFunction).filter(ValidationUserDefinedFunction.function_id == function_id).first()
            if db_userdefined is None:
              raise HTTPException(status_code=404, detail="Function not found")
            if db_userdefined is None or not db_userdefined.is_active:
                return None
            return db_userdefined  # Return the found entity
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch user defined function with ID {function_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch user defined function: {str(e)}")
        
    def update_validation_userdefined_function(self, function_id: int, validation_update: ValidationUserDefinedFunctionCreate):
        """Updates an existing user-defined function's details.

        Args:
            function_id: The ID of the function to update.
            validation_update: Pydantic model containing updated function details.

        Returns:
            The updated function object.

        Raises:
            HTTPException: If the function is not found or syntax is invalid.
        """
        try:
            # Validate Python syntax before saving
            try:
                ast.parse(validation_update.function_definition)
            except SyntaxError as e:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid Python syntax at line {e.lineno}: {e.msg}"
                )

            db_func = self.db.query(ValidationUserDefinedFunction).filter(
                ValidationUserDefinedFunction.function_id == function_id
            ).first()
            if db_func is None:
                raise HTTPException(status_code=404, detail="User-defined function not found")

            db_func.function_name = validation_update.function_name
            db_func.function_type = validation_update.function_type
            db_func.function_definition = validation_update.function_definition

            db_commit_auto_rollback(db=self.db)
            self.db.refresh(db_func)
            return db_func
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update user defined function with ID {function_id}. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to update user defined function: {str(e)}")

    def delete_validation_userdefined_function_entry_by_id(self, function_id: int):
        """Deletes a function by ID permanently.
        
        Args:
            entity_id: The ID of the function to delete.
            
        Returns:
            A confirmation message or the deleted function object.
            
        Raises:
            HTTPException: If the entity is not found or an error occurs during deletion.
        """
        try:
            # Fetch the entity by ID
            db_userdefined = self.db.query(ValidationUserDefinedFunction).filter(ValidationUserDefinedFunction.function_id == function_id).first()
            if db_userdefined is None:
                return {"detail": "userdefined not found"}
            
            
            self.db.delete(db_userdefined)  # Permanently delete the entity
            db_commit_auto_rollback(db=self.db)  # Commit changes and handle rollback on failure
            return {"detail": " validation entry successfully deleted"}
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete user defined function. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to delete user defined function: {str(e)}")

        