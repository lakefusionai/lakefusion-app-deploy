# shared_cache.py
from fastapi_cache import caches, close_caches
from fastapi_cache.backends.inmemory import InMemoryBackend
# Optionally, you could use Redis or any other backend supported by fastapi-cache

# Initialize the cache backend (In-memory in this example)
cache_in_memory = InMemoryBackend()

async def init_cache():
    caches.set("default", cache_in_memory)

async def shutdown_cache():
    await close_caches()