from sqlalchemy import MetaData
from lakefusion_utility.utils.logging_utils import get_logger
import traceback
# Hotfix 3.4.1 - Replace with sqlalchemy.orm declartive_base 
# as sqlalchemy.ext class is deprecated & can cause issues
from sqlalchemy.orm import declarative_base

logger = get_logger('utility_app_db')
# Naming convention for constraints
naming_convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s"
}
metadata = MetaData(naming_convention=naming_convention)
Base = declarative_base(metadata=metadata)


def get_class_by_tablename(db, table_fullname):
    """
    Return class reference mapped to table.
    :param table_fullname: String with fullname of table.
    :return: Class reference or None.
    """
    table_schema = None
    try:
        base = db.make_declarative_base(db.Model, db.Model.metadata)
        for c in base.registry.mappers:
            if hasattr(c, 'class_'):
                cls = c.class_
                if hasattr(cls, '__tablename__') and cls.__tablename__ == table_fullname:
                    table_schema = cls
                    break
    except Exception as e:
        print(f'Get class by tablename threw an error - {str(e)}')
    return table_schema


def db_commit_auto_rollback(db, close_session=False, raise_exception=False):
    """
       Handles auto rollback of session in case of a commit failure
       :param db_param: SQLAlchemy DB Object.
       :param close_session: Optionally avoid closing DB session.
       :param raise_exception: Optionally raise exception.
       :return: None.
   """
    should_rollback = False
    exception = ""
    try:
        db.commit()
    except Exception as err:
        exception = traceback.format_exc()
        should_rollback = True
        if raise_exception:
            raise err
    finally:
        if should_rollback:
            logger.exception(f"Exception occurred while commit the transaction - {str(exception)}")
            db.rollback()
        if close_session:
            db.close()