"""
Audit Log Middleware - Backwards Compatibility Module

This module re-exports from lakefusion_utility.services.audit_log_service
for backwards compatibility.

All audit log functionality is now consolidated in:
    lakefusion_utility.services.audit_log_service

New code should import directly from the service module.
"""

# Re-export for backwards compatibility
from lakefusion_utility.services.audit_log_service import (
    AuditLogMiddleware,
    create_audit_log_entry,
    MAX_PAYLOAD_SIZE,
    MAX_RESPONSE_SIZE,
    FILE_UPLOAD_CONTENT_TYPES,
    EXCLUDED_PATHS,
    EXCLUDED_PATH_PREFIXES,
    SENSITIVE_PAYLOAD_PATH_PREFIXES,
)

__all__ = [
    "AuditLogMiddleware",
    "create_audit_log_entry",
    "MAX_PAYLOAD_SIZE",
    "MAX_RESPONSE_SIZE",
    "FILE_UPLOAD_CONTENT_TYPES",
    "EXCLUDED_PATHS",
    "EXCLUDED_PATH_PREFIXES",
    "SENSITIVE_PAYLOAD_PATH_PREFIXES",
]
