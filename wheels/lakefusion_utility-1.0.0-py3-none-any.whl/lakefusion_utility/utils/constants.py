from enum import Enum

class Constants:
    session_token_key: str = "session_token"
    authorization_key: str = "Authorization"
    sqlwarehouse_path: str ="/sql/1.0/warehouses/"
