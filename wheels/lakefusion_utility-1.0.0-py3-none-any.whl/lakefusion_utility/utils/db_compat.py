"""
Database compatibility helpers for MySQL ↔ PostgreSQL.
Provides dialect-agnostic abstractions for operations that differ between databases.
"""
from sqlalchemy import func, cast, String, text
from lakefusion_utility.utils import database


def json_field(column, key):
    """
    Extract a JSON field value in a dialect-agnostic way.

    MySQL:      func.json_unquote(func.json_extract(column, '$.key'))
    PostgreSQL: column ->> 'key'  (via cast to text)

    Usage:
        from lakefusion_utility.utils.db_compat import json_field
        query.filter(json_field(Model.json_col, 'status') == 'PENDING')

    Args:
        column: SQLAlchemy column (must be JSON type)
        key: The JSON key to extract (without '$.' prefix)

    Returns:
        A SQLAlchemy expression suitable for filtering/selecting.
    """
    dialect = database.db_type

    if dialect == 'mysql':
        return func.json_unquote(func.json_extract(column, f'$.{key}'))
    else:
        # PostgreSQL, Lakebase (PostgreSQL-compatible)
        # Use the ->> operator which returns text (works with both JSON and JSONB columns)
        return column.op('->>')(key)