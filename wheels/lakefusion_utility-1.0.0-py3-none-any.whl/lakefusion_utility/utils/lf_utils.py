import hashlib
import json
import os
import re
from base64 import b64encode, b64decode
from datetime import datetime
from typing import Union

import jwt
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from bs4 import BeautifulSoup
from marshmallow import Schema, ValidationError, EXCLUDE

from lakefusion_utility.models.httpresponse import HttpResponse
from lakefusion_utility.models.jwtpayload import JWTPayload
from lakefusion_utility.models.schemavalidator import SchemaValidator

from pathlib import Path
from typing import Optional

issuer = 'https://databricks.okta.com/oauth2/default'
jwks_url = f"{issuer}/v1/keys"
jwks_client = jwt.PyJWKClient(jwks_url, cache_jwk_set=True, lifespan=60 * 60)


def date_time_format_checker(date_string, format):
    """compare date_string to its format"""
    try:
        datetime.strptime(date_string, format)
        return True
    except:
        return False


def convertDateTime(date_string, current_date_format, convert_date_format):
    """ return any datetime format into a given format """
    try:
        datetime.strptime(date_string, convert_date_format)
    except:
        date_string = datetime.strptime(date_string, current_date_format).strftime(convert_date_format)

    return date_string


def fetchBlobData(file_name, blob_container_url):
    try:
        dsh_ele_blobsasurl = blob_container_url
        container_client = ContainerClient.from_container_url(dsh_ele_blobsasurl)
        blob_client_instance = container_client.get_blob_client(file_name)
        blob_data = blob_client_instance.download_blob()
        data = blob_data.readall()
        data = data.decode('utf-8')
        return data

    except Exception as e:
        print("Error while fetching blob file data: ", str(e))
        return json.dumps({})


def checkBlobExist(file_name, blob_container_url):
    try:
        dsh_ele_blobsasurl = blob_container_url
        container_client = ContainerClient.from_container_url(dsh_ele_blobsasurl)
        blob_client_instance = container_client.get_blob_client(file_name)
        blob_data = blob_client_instance.download_blob()
        data = blob_data.readall()
        data = data.decode('utf-8')
        if bool(json.loads(data)):
            return True
        else:
            return False

    except Exception as e:
        print("Error while fetching blob file existence: ", str(e))
        return False


def extractWorkspaceId(url):
    result = re.findall(r".*?o=(\w+)", url)
    if bool(result):
        workspaceId = result[0]
        return workspaceId
    return None


def generateUniqueId(entity, length: int = 9):
    uniqueId = str(int(hashlib.md5(entity.encode('utf-8')).hexdigest(), 16))[0:length - 1]
    return uniqueId


def getResponseHeaders() -> dict:
    return dict({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Credentials': '*'
    })


def getBytesFromString(string: str) -> bytes:
    return string.encode('utf-8')


def getStringFromBytes(byte: Union[bytes, str]) -> str:
    return byte.decode('utf-8')


def validateRouteSchema(request_data, schema: Schema) -> SchemaValidator:
    is_valid_schema = False
    http_response = None
    try:
        # Validate request body against schema data types
        schema.load(request_data, unknown=EXCLUDE)
        is_valid_schema = True
    except ValidationError as err:
        # Return a nice message if validation fails
        data = None
        if err.messages:
            data = err.messages
        http_response = HttpResponse(message=f'{str(err)}', status=400, data=data)

    return SchemaValidator(is_valid_schema=is_valid_schema, http_response=http_response)


def getCrypt(secret_key: str) -> any:
    key = getBytesFromString(secret_key)
    cipher = AES.new(b64decode(key), AES.MODE_ECB)
    return cipher


def encrypt(secret_key: str, plain_text: str) -> str:
    cipher = getCrypt(secret_key)
    plain_text_padded = pad(getBytesFromString(plain_text), AES.block_size)
    cipher_enc = cipher.encrypt(plain_text_padded)
    encrypted_encoded = b64encode(cipher_enc)
    return encrypted_encoded


def decrypt(secret_key: str, encrypted_text: str) -> str:
    cipher = getCrypt(secret_key)
    encrypted_text_bytes = getBytesFromString(encrypted_text)
    decoded = b64decode(encrypted_text_bytes)
    decrypted = cipher.decrypt(decoded)
    decrypted_unpadded = unpad(decrypted, AES.block_size)
    return decrypted_unpadded


def decodeJWT(encoded_jwt: str) -> JWTPayload:
    decoded = jwt.decode(encoded_jwt, options={"verify_signature": False})
    user_email = request.headers.get("userEmail", "")
    okta_client_id_bot = os.environ.get('OKTA_APP_CLIENT_ID_AUTOMATION', '')
    preferred_username = decoded.get('sub')
    if preferred_username == okta_client_id_bot:
        if user_email:
            preferred_username = user_email
        else:
            return None

    return JWTPayload(
        preferred_username=preferred_username,
        roles=decoded.get('groups'),
        oid=decoded.get('uid'),
        iss=decoded.get('iss'),
        okta_app_id=decoded.get('cid')
    )


def valid_file_extension(filename: str, valid_extensions: list):
    return '.' in filename and \
        filename.rsplit('.', 1)[1].lower() in valid_extensions


def list_tuples_to_list_dict(list_tuples: list) -> list:
    results = []

    # results from sqlalchemy are returned as a list of tuples; this procedure converts it into a list of dicts
    for row_number, row in enumerate(list_tuples):
        results.append({})
        for column_number, value in enumerate(row):
            results[row_number][row.keys()[column_number]] = value

    return results


def validate_session_token(encoded_jwt: str) -> tuple:
    is_valid_token: bool = False
    decoded_jwt = None
    if not encoded_jwt:
        return is_valid_token, decoded_jwt, encoded_jwt
    encoded_jwt = encoded_jwt.replace("Bearer", "").strip()
    if encoded_jwt and is_access_token_valid(encoded_jwt):
        decoded_jwt = decodeJWT(encoded_jwt=encoded_jwt)
        if decoded_jwt:
            is_valid_token = True
    else:
        app.logger.exception("Invalid token")

    return is_valid_token, decoded_jwt, encoded_jwt


def authorize_routes(allowed_middle_layer_routes: list, current_route_path: str) -> bool:
    has_auhorized_routes: bool = False
    try:
        for allowed_middle_layer_route in allowed_middle_layer_routes:
            allowed_middle_layer_route_escaped = allowed_middle_layer_route.replace('/', '\/')
            if (allowed_middle_layer_route_escaped == '*' or bool(
                    re.match(allowed_middle_layer_route_escaped, current_route_path))):
                has_auhorized_routes = True
                break
    except:
        pass
    return has_auhorized_routes


def validate_role_in_params(current_route_params: dict, current_role: str) -> bool:
    has_valid_role_in_params: bool = False
    try:
        passed_role = current_route_params.get('role_name')
        if current_role is not None and passed_role is not None:
            if passed_role == current_role:
                has_valid_role_in_params = True
        else:
            has_valid_role_in_params = True
    except:
        pass
    return has_valid_role_in_params


def get_notebook_file_name(notebook_file_name: str, notebook_version: str) -> str:
    return f"{notebook_file_name}__{notebook_version}"


def html_to_text(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    formatted_text = soup.get_text()
    return formatted_text


def get_version_info() -> Optional[dict]:
    """
    Loads product version info from version.json file.

    Returns:
        dict containing version info, or None if file not found.
    """
    VERSION_FILE = Path("version.json")
    
    if not VERSION_FILE.exists():
        return dict()

    try:
        with open(VERSION_FILE) as f:
            return json.load(f)
    except json.JSONDecodeError:
        return dict()
