import logging
import os
from pathlib import Path
from datetime import datetime
from logging.handlers import TimedRotatingFileHandler

# Global variable to store service name
_service_name = None

def init_logger(service: str):
    """Initialize the logging service name"""
    global _service_name
    _service_name = service

def get_logger(name: str):
    if _service_name is None:
        raise RuntimeError("Logging not initialized. Call init(service_name) first.")
    
    logger = logging.getLogger(name)
    
    # Prevent adding duplicate handlers
    if logger.handlers:
        return logger
    
    logger.setLevel(logging.DEBUG)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # Determine appropriate log directory
    if os.name == 'posix':  # Linux/Unix/Mac
        if os.path.exists('/var/app_log') and os.access('/var/app_log', os.W_OK):
            log_dir = f'/var/app_log/{_service_name}'
        else:
            log_dir = os.path.expanduser(f'~/app_logs/{_service_name}')
    else:  # Windows or other OS
        log_dir = os.path.expanduser(f'~/app_logs/{_service_name}')
    
    # Create log directory if it doesn't exist
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    
    # File handler with daily rotation
    # Create filename with today's date
    date_str = datetime.now().strftime('%Y-%m-%d')
    log_file = os.path.join(log_dir, f'app-{date_str}.log')
    
    file_handler = TimedRotatingFileHandler(
        log_file,
        when='midnight',
        interval=1,
        backupCount=90,  # Keep 90 days of logs
        encoding='utf-8'
    )
    # Format: app-YYYY-MM-DD.log
    file_handler.namer = lambda name: name.replace('.log.', '-').replace('.log', '.log')
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)
    
    return logger