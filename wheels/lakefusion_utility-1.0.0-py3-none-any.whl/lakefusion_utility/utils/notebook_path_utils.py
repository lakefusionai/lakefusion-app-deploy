"""
Utility functions for notebook path resolution with SDK feature flag support.

When SDK_CHANGES feature flag is ACTIVE, notebook paths use _revamped folders
containing SDK thin wrappers. When INACTIVE, paths use original production folders.
"""
from typing import List
from sqlalchemy.orm import Session

from lakefusion_utility.services.feature_flags_service import FeatureFlagService

# Folders that have SDK revamped versions
SDK_FOLDERS: List[str] = ["integration-core", "maven-core", "dnb_integration", "schema-evolution"]

# Feature flag name for SDK changes
SDK_FEATURE_FLAG = "SDK_CHANGES"


def get_notebook_folder(base_folder: str, db: Session) -> str:
    """
    Returns the appropriate folder path based on SDK_CHANGES feature flag.

    When SDK_CHANGES is ACTIVE:
        - integration-core -> integration-core_revamped
        - maven-core -> maven-core_revamped
        - dnb_integration -> dnb_integration_revamped
        - schema-evolution -> schema-evolution_revamped

    When SDK_CHANGES is INACTIVE:
        - Returns the original folder name unchanged

    Folders not in SDK_FOLDERS (e.g., maven-core-deduplication, migration-utilities)
    are always returned unchanged.

    Args:
        base_folder: Base folder name (e.g., "integration-core", "maven-core")
        db: SQLAlchemy database session for feature flag lookup

    Returns:
        str: Folder name, with _revamped suffix if SDK is enabled for that folder

    Example:
        >>> folder = get_notebook_folder("integration-core", db)
        >>> # Returns "integration-core_revamped" if SDK_CHANGES is ACTIVE
        >>> # Returns "integration-core" if SDK_CHANGES is INACTIVE
    """
    # Folders not in SDK_FOLDERS are returned unchanged
    if base_folder not in SDK_FOLDERS:
        return base_folder

    # Check feature flag status
    sdk_enabled = FeatureFlagService._is_feature_flag_enabled(
        db=db,
        name=SDK_FEATURE_FLAG
    )

    if sdk_enabled:
        return f"{base_folder}_revamped"

    return base_folder


def is_sdk_enabled(db: Session) -> bool:
    """
    Check if SDK_CHANGES feature flag is enabled.

    Args:
        db: SQLAlchemy database session

    Returns:
        bool: True if SDK_CHANGES is ACTIVE, False otherwise
    """
    return FeatureFlagService._is_feature_flag_enabled(
        db=db,
        name=SDK_FEATURE_FLAG
    )
