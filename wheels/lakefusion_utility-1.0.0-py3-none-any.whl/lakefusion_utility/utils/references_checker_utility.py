from sqlalchemy import inspect, text
from sqlalchemy.orm import Session


def is_value_referenced_elsewhere(
    db: Session,
    table_name: str,
    column_name: str,
    value,
):
    """
    Checks whether a given value (e.g., dataset_id) from `table_name.column_name`
    exists in the same column name across *other* tables in the database.

    Args:
        db (Session): SQLAlchemy session
        table_name (str): Current table name (to exclude it from search)
        column_name (str): Column name to check (e.g. "dataset_id")
        value: The actual value to search for

    Returns:
        List of table names that reference the given value.
        Empty list means safe to delete.
    """
    inspector = inspect(db.bind)
    referenced_in = []

    for other_table in inspector.get_table_names():
        if other_table == table_name:
            continue  # skip current table

        try:
            columns = [col["name"] for col in inspector.get_columns(other_table)]
            if column_name in columns:
                # Check if the value exists in that table
                query = text(f"SELECT COUNT(*) FROM `{other_table}` WHERE `{column_name}` = :val")
                result = db.execute(query, {"val": value}).scalar()
                if result and result > 0:
                    referenced_in.append(other_table)
        except Exception as e:
            print(f"Skipping {other_table}: {e}")
            continue

    return referenced_in
