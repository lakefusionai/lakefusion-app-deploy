"""
Sensitive Data Masker Utility

Recursively traverses JSON payloads and masks sensitive fields.
Used by audit logging to redact sensitive information before storing.
"""

import re
from typing import Any, Dict, List, Set, Union

# Default sensitive field patterns (case-insensitive matching)
DEFAULT_SENSITIVE_PATTERNS: Set[str] = {
    # Auth related
    "password",
    "passwd",
    "secret",
    "token",
    "api_key",
    "apikey",
    "api-key",
    "credential",
    "credentials",
    "bearer",
    "authorization",
    "auth_token",
    "access_token",
    "refresh_token",
    "id_token",

    # PII related
    "ssn",
    "social_security",
    "social_security_number",
    "credit_card",
    "creditcard",
    "card_number",
    "cardnumber",
    "cvv",
    "cvc",
    "pin",

    # Keys related
    "private_key",
    "privatekey",
    "access_key",
    "accesskey",
    "secret_key",
    "secretkey",
    "client_secret",
    "clientsecret",
    "encryption_key",
    "signing_key",

    # Database related
    "db_password",
    "database_password",
    "connection_string",
}

MASKED_VALUE = "***MASKED***"


def _normalize_key(key: str) -> str:
    """Normalize key for comparison (lowercase, remove special chars)."""
    return re.sub(r'[_\-\s]', '', key.lower())


def _is_sensitive_key(key: str, sensitive_patterns: Set[str]) -> bool:
    """Check if a key matches any sensitive pattern."""
    normalized_key = _normalize_key(key)

    for pattern in sensitive_patterns:
        normalized_pattern = _normalize_key(pattern)
        # Check if the pattern is contained in the key
        if normalized_pattern in normalized_key:
            return True

    return False


def mask_sensitive_data(
    data: Any,
    sensitive_patterns: Set[str] = None,
    max_depth: int = 20,
    _current_depth: int = 0
) -> Any:
    """
    Recursively mask sensitive fields in a data structure.

    Args:
        data: The data to mask (dict, list, or primitive)
        sensitive_patterns: Set of field name patterns to mask (uses defaults if None)
        max_depth: Maximum recursion depth to prevent infinite loops
        _current_depth: Internal counter for current depth

    Returns:
        The data with sensitive fields masked
    """
    if sensitive_patterns is None:
        sensitive_patterns = DEFAULT_SENSITIVE_PATTERNS

    # Prevent infinite recursion
    if _current_depth > max_depth:
        return data

    if isinstance(data, dict):
        masked_dict = {}
        for key, value in data.items():
            if isinstance(key, str) and _is_sensitive_key(key, sensitive_patterns):
                # Mask the entire value for sensitive keys
                masked_dict[key] = MASKED_VALUE
            else:
                # Recursively process nested structures
                masked_dict[key] = mask_sensitive_data(
                    value,
                    sensitive_patterns,
                    max_depth,
                    _current_depth + 1
                )
        return masked_dict

    elif isinstance(data, list):
        return [
            mask_sensitive_data(item, sensitive_patterns, max_depth, _current_depth + 1)
            for item in data
        ]

    else:
        # Primitives (str, int, float, bool, None) are returned as-is
        return data


def mask_json_string(
    json_string: str,
    sensitive_patterns: Set[str] = None,
    max_length: int = 10240  # 10KB default
) -> str:
    """
    Mask sensitive data in a JSON string.

    Args:
        json_string: JSON string to mask
        sensitive_patterns: Set of field name patterns to mask
        max_length: Maximum length of output (truncates if exceeded)

    Returns:
        Masked JSON string, potentially truncated
    """
    import json

    if not json_string:
        return json_string

    try:
        data = json.loads(json_string)
        masked_data = mask_sensitive_data(data, sensitive_patterns)
        result = json.dumps(masked_data)

        if len(result) > max_length:
            return result[:max_length] + "...[TRUNCATED]"

        return result

    except json.JSONDecodeError:
        # If not valid JSON, return truncated original
        if len(json_string) > max_length:
            return json_string[:max_length] + "...[TRUNCATED]"
        return json_string


def truncate_string(text: str, max_length: int = 10240) -> str:
    """
    Truncate a string to max_length with indicator.

    Args:
        text: String to truncate
        max_length: Maximum length

    Returns:
        Truncated string with indicator if truncated
    """
    if not text or len(text) <= max_length:
        return text

    return text[:max_length] + "...[TRUNCATED]"
