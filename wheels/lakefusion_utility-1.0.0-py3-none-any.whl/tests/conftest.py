"""
Utility library test configuration.

Provides fixtures for:
- MySQL test database session (real MySQL, not SQLite)
- No TestClient needed (utility is a library, not a FastAPI app)
"""
import os
import sys
import pytest

# Add repo root to sys.path so shared testing utilities can be imported
REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

UTILITY_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if UTILITY_ROOT not in sys.path:
    sys.path.insert(0, UTILITY_ROOT)

# ---------------------------------------------------------------------------
# Environment variables required before any application module is imported
# ---------------------------------------------------------------------------
os.environ.setdefault("SQL_USERNAME", "test")
os.environ.setdefault("SQL_PASSWORD", "test")
os.environ.setdefault("SQL_SERVER", "localhost")
os.environ.setdefault("SQL_DBNAME", "test_db")
os.environ.setdefault("DEPLOYMENT_ENV", "")
os.environ.setdefault("DATABRICKS_HOST", "https://test.databricks.com")
os.environ.setdefault("DATABRICKS_OIDC_CLIENT_ID", "test-client-id")
os.environ.setdefault("AUTH_PROVIDER", "databricks")
os.environ.setdefault("DB_TYPE", "mysql")
os.environ.setdefault("AZURE_TENANT_ID", "test-tenant-id")
os.environ.setdefault("AZURE_AD_CLIENT_ID", "test-azure-client-id")

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Initialize logger BEFORE any lakefusion_utility imports
from lakefusion_utility.utils.logging_utils import init_logger
init_logger(service="utility_test")

from lakefusion_utility.utils.app_db import Base

# ---------------------------------------------------------------------------
# Test database URL -- real MySQL (same as production engine)
# ---------------------------------------------------------------------------
TEST_DATABASE_URL = os.environ.get(
    "TEST_DATABASE_URL",
    "mysql+pymysql://root:lakefusion%401@localhost:3306/lakefusion_test_dev"
)


# ---------------------------------------------------------------------------
# Session-scoped engine -- creates tables once per test session
# ---------------------------------------------------------------------------
@pytest.fixture(scope="session")
def test_engine():
    engine = create_engine(TEST_DATABASE_URL, pool_pre_ping=True)
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield engine
    Base.metadata.drop_all(bind=engine)
    engine.dispose()


# ---------------------------------------------------------------------------
# Per-test database session with auto-rollback
# ---------------------------------------------------------------------------
@pytest.fixture()
def db_session(test_engine):
    """Each test gets a clean session -- transaction rolls back after."""
    connection = test_engine.connect()
    transaction = connection.begin()
    session = sessionmaker(bind=connection)()

    yield session

    session.close()
    transaction.rollback()
    connection.close()
