"""
Tests for DatasetService — exercises real ORM logic against in-memory SQLite.

No mocking of the database; we rely on the db_session fixture from conftest.
"""
import pytest
from fastapi import HTTPException

from lakefusion_utility.models.dataset import Dataset, DatasetCreate
from lakefusion_utility.services.dataset_service import DatasetService


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_create_model(**overrides) -> DatasetCreate:
    """Build a DatasetCreate Pydantic model with sensible defaults."""
    defaults = {
        "name": "test_dataset",
        "path": "catalog.schema.table",
        "description": "A test dataset",
        "primary_field": "id",
        "color_code": "#AABBCC",
        "created_by": "unit-test@example.com",
    }
    defaults.update(overrides)
    return DatasetCreate(**defaults)


def _seed_dataset(db_session, **overrides) -> Dataset:
    """Insert a Dataset row directly and return the refreshed ORM object."""
    defaults = {
        "name": "seeded_ds",
        "path": "catalog.schema.seeded",
        "description": "seeded",
        "primary_field": "pk",
        "created_by": "seed@example.com",
        "is_active": True,
        "color_code": "#000000",
    }
    defaults.update(overrides)
    ds = Dataset(**defaults)
    db_session.add(ds)
    db_session.commit()
    db_session.refresh(ds)
    return ds


# =========================================================================
# create_dataset
# =========================================================================

class TestCreateDataset:
    def test_strips_whitespace(self, db_session):
        svc = DatasetService(db_session)
        model = _make_create_model(name="  spacey  ", path="  cat.sch.tbl  ")
        result = svc.create_dataset(model)
        assert result.data.name == "spacey"
        assert result.data.path == "cat.sch.tbl"

    def test_checks_duplicate(self, db_session):
        _seed_dataset(db_session, name="dup", path="cat.sch.dup")
        svc = DatasetService(db_session)
        model = _make_create_model(name="dup", path="cat.sch.dup")
        with pytest.raises(HTTPException) as exc_info:
            svc.create_dataset(model)
        assert exc_info.value.status_code == 409

    def test_success_creates_dataset(self, db_session):
        svc = DatasetService(db_session)
        model = _make_create_model(name="brand_new", path="cat.sch.new")
        result = svc.create_dataset(model)
        assert result.status == "success"
        assert result.data.id is not None
        assert result.data.name == "brand_new"
        assert result.data.is_active is True


# =========================================================================
# read_datasets
# =========================================================================

class TestReadDatasets:
    def test_returns_all(self, db_session):
        _seed_dataset(db_session, name="r1", path="cat.sch.r1")
        _seed_dataset(db_session, name="r2", path="cat.sch.r2")
        svc = DatasetService(db_session)
        datasets = svc.read_datasets()
        names = {d.name for d in datasets}
        assert "r1" in names
        assert "r2" in names

    def test_filters_active(self, db_session):
        _seed_dataset(db_session, name="act", path="cat.sch.act", is_active=True)
        _seed_dataset(db_session, name="inact", path="cat.sch.inact", is_active=False)
        svc = DatasetService(db_session)
        active = svc.read_datasets(is_active=True)
        assert all(d.is_active is True for d in active)
        names = {d.name for d in active}
        assert "act" in names
        assert "inact" not in names


# =========================================================================
# get_dataset_by_id
# =========================================================================

class TestGetDatasetById:
    def test_found(self, db_session):
        ds = _seed_dataset(db_session, name="findable", path="cat.sch.find")
        svc = DatasetService(db_session)
        result = svc.get_dataset_by_id(ds.id)
        assert result is not None
        assert result.name == "findable"

    def test_not_found(self, db_session):
        svc = DatasetService(db_session)
        result = svc.get_dataset_by_id(99999)
        assert result is None


# =========================================================================
# toggle_dataset_active
# =========================================================================

class TestToggleActive:
    def test_flips_true_to_false(self, db_session):
        ds = _seed_dataset(db_session, name="flip", path="cat.sch.flip", is_active=True)
        svc = DatasetService(db_session)
        toggled = svc.toggle_dataset_active(ds.id)
        assert toggled is not None
        assert toggled.is_active is False
