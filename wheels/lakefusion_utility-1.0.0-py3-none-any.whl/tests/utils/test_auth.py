"""
Tests for token_valid() and token_required() in lakefusion_utility.utils.auth.

All external calls (jwt.decode, ComputeService.list_clusters, DB queries)
are mocked so that tests run without network or database access.
"""
import pytest
from unittest.mock import MagicMock, patch
from fastapi import HTTPException
from jwt import ExpiredSignatureError, InvalidTokenError


# ---------------------------------------------------------------------------
# We need to clear the token_cache between tests so cached results from one
# test don't leak into another.
# ---------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def _clear_token_cache():
    from lakefusion_utility.utils.auth import token_cache
    token_cache.clear()
    yield
    token_cache.clear()


# =========================================================================
# token_valid()
# =========================================================================

class TestTokenValid:
    """Tests for the token_valid() function."""

    def test_valid_databricks_token(self, mocker):
        """A well-formed Databricks OIDC token should return (True, ..., decoded)."""
        from lakefusion_utility.utils import auth as auth_mod

        databricks_host = "https://test.databricks.com"
        expected_issuer = f"{databricks_host}/oidc"
        fake_claims = {
            "iss": expected_issuer,
            "sub": "user@example.com",
            "client_id": "test-client-id",
            "exp": 9999999999,
        }

        mocker.patch.object(auth_mod, "AUTH_PROVIDER", "databricks")
        mocker.patch.object(auth_mod, "DATABRICKS_HOST", databricks_host)
        mocker.patch.object(auth_mod, "DATABRICKS_OIDC_CLIENT_ID", "test-client-id")

        # jwt.decode is called twice: once unverified, once with exp/iss checks
        mocker.patch("lakefusion_utility.utils.auth.jwt.decode", return_value=fake_claims)

        mock_cs = mocker.patch("lakefusion_utility.utils.auth.ComputeService")
        mock_cs.return_value.list_clusters.return_value = []

        valid, message, data, decoded = auth_mod.token_valid("fake-token-dbx")

        assert valid is True
        assert decoded["sub"] == "user@example.com"

    def test_valid_azuread_token(self, mocker):
        """A well-formed Azure AD token should return (True, ..., decoded)."""
        from lakefusion_utility.utils import auth as auth_mod

        tenant_id = "test-tenant-id"
        expected_issuer = f"https://sts.windows.net/{tenant_id}/"
        fake_claims = {
            "iss": expected_issuer,
            "sub": "azure-sub",
            "appid": "test-azure-client-id",
            "upn": "user@contoso.com",
            "exp": 9999999999,
        }

        mocker.patch.object(auth_mod, "AUTH_PROVIDER", "azuread")
        mocker.patch.object(auth_mod, "AZURE_TENANT_ID", tenant_id)
        mocker.patch.object(auth_mod, "AZURE_AD_CLIENT_ID", "test-azure-client-id")

        mocker.patch("lakefusion_utility.utils.auth.jwt.decode", return_value=fake_claims)

        mock_cs = mocker.patch("lakefusion_utility.utils.auth.ComputeService")
        mock_cs.return_value.list_clusters.return_value = []

        valid, message, data, decoded = auth_mod.token_valid("fake-token-azure")

        assert valid is True
        # Azure AD normalizes sub to upn
        assert decoded["sub"] == "user@contoso.com"

    def test_expired_token(self, mocker):
        """An expired token should return (False, ...)."""
        from lakefusion_utility.utils import auth as auth_mod

        mocker.patch.object(auth_mod, "AUTH_PROVIDER", "databricks")
        mocker.patch.object(auth_mod, "DATABRICKS_HOST", "https://test.databricks.com")

        # First call (unverified) succeeds, second call raises ExpiredSignatureError
        mocker.patch(
            "lakefusion_utility.utils.auth.jwt.decode",
            side_effect=ExpiredSignatureError("Token expired"),
        )

        valid, message, data, decoded = auth_mod.token_valid("expired-token")

        assert valid is False
        assert "expired" in message.lower()

    def test_wrong_issuer(self, mocker):
        """A token whose issuer does not match should raise HTTPException
        which is caught internally, resulting in (False, ...)."""
        from lakefusion_utility.utils import auth as auth_mod

        mocker.patch.object(auth_mod, "AUTH_PROVIDER", "databricks")
        mocker.patch.object(auth_mod, "DATABRICKS_HOST", "https://test.databricks.com")

        wrong_claims = {
            "iss": "https://evil.example.com/oidc",
            "sub": "attacker",
            "client_id": "test-client-id",
        }
        mocker.patch("lakefusion_utility.utils.auth.jwt.decode", return_value=wrong_claims)

        # token_valid raises HTTPException internally for issuer mismatch,
        # which is caught by the outer except block
        valid, message, data, decoded = auth_mod.token_valid("wrong-issuer-token")

        assert valid is False

    def test_wrong_client_id(self, mocker):
        """A token with an unrecognised client_id should return (False, ...)."""
        from lakefusion_utility.utils import auth as auth_mod

        databricks_host = "https://test.databricks.com"
        expected_issuer = f"{databricks_host}/oidc"
        bad_claims = {
            "iss": expected_issuer,
            "sub": "user@example.com",
            "client_id": "wrong-client-id",
            "exp": 9999999999,
        }

        mocker.patch.object(auth_mod, "AUTH_PROVIDER", "databricks")
        mocker.patch.object(auth_mod, "DATABRICKS_HOST", databricks_host)
        mocker.patch.object(auth_mod, "DATABRICKS_OIDC_CLIENT_ID", "test-client-id")

        mocker.patch("lakefusion_utility.utils.auth.jwt.decode", return_value=bad_claims)

        valid, message, data, decoded = auth_mod.token_valid("bad-client-token")

        assert valid is False
        assert "invalid token" in message.lower()


# =========================================================================
# token_required()
# =========================================================================

class TestTokenRequired:
    """Tests for the token_required() dependency function."""

    def test_returns_decoded_claims(self, mocker, db_session):
        """When the token is valid and read-only is off, return the claims dict."""
        from lakefusion_utility.utils import auth as auth_mod

        mocker.patch(
            "lakefusion_utility.utils.auth.token_valid",
            return_value=(True, "", [], {"sub": "user@example.com"}),
        )

        # Build a mock Request (GET = non-write)
        mock_request = MagicMock()
        mock_request.method = "GET"
        mock_request.state = MagicMock()

        # Build a mock HTTPAuthorizationCredentials
        mock_creds = MagicMock()
        mock_creds.credentials = "valid-token"

        # No read-only config in DB
        db_session.query = MagicMock(return_value=MagicMock(
            filter=MagicMock(return_value=MagicMock(first=MagicMock(return_value=None)))
        ))

        result = auth_mod.token_required(
            token=mock_creds,
            request=mock_request,
            db=db_session,
        )

        assert result["valid"] is True
        assert result["token"] == "valid-token"
        assert result["decoded"]["sub"] == "user@example.com"

    def test_read_only_blocks_writes(self, mocker, db_session):
        """In read-only mode, POST requests to non-whitelisted routes should 403."""
        from lakefusion_utility.utils import auth as auth_mod
        from lakefusion_utility.models.dbconfig import DBConfigProperties

        mocker.patch(
            "lakefusion_utility.utils.auth.token_valid",
            return_value=(True, "", [], {"sub": "user@example.com"}),
        )

        mock_request = MagicMock()
        mock_request.method = "POST"
        mock_request.url.path = "/api/middle-layer/dataset/"
        mock_request.state = MagicMock()

        mock_creds = MagicMock()
        mock_creds.credentials = "valid-token"

        # Simulate read-only = true with no whitelisted routes
        read_only_config = MagicMock(spec=DBConfigProperties)
        read_only_config.config_value = "true"

        whitelist_config = MagicMock(spec=DBConfigProperties)
        whitelist_config.config_value = "{}"

        def _fake_query(model):
            mock_q = MagicMock()
            def _fake_filter(*args, **kwargs):
                mock_result = MagicMock()
                # Determine which config_key is being queried based on call context
                # We check the filter arguments to decide which config to return
                return mock_result
            mock_q.filter = _fake_filter
            return mock_q

        # Use side_effect to return different configs based on the query
        call_count = {"n": 0}
        original_query = db_session.query

        def _mock_query(model):
            mock_q = MagicMock()
            def _filter(*args, **kwargs):
                call_count["n"] += 1
                mock_first = MagicMock()
                if call_count["n"] == 1:
                    mock_first.first.return_value = read_only_config
                else:
                    mock_first.first.return_value = whitelist_config
                return mock_first
            mock_q.filter = _filter
            return mock_q

        db_session.query = _mock_query

        with pytest.raises(HTTPException) as exc_info:
            auth_mod.token_required(
                token=mock_creds,
                request=mock_request,
                db=db_session,
            )
        assert exc_info.value.status_code == 403

    def test_read_only_allows_whitelisted(self, mocker, db_session):
        """In read-only mode, POST to a whitelisted route should succeed."""
        import json
        from lakefusion_utility.utils import auth as auth_mod
        from lakefusion_utility.models.dbconfig import DBConfigProperties

        mocker.patch(
            "lakefusion_utility.utils.auth.token_valid",
            return_value=(True, "", [], {"sub": "user@example.com"}),
        )

        mock_request = MagicMock()
        mock_request.method = "POST"
        mock_request.url.path = "/api/middle-layer/entity-search/"
        mock_request.state = MagicMock()

        mock_creds = MagicMock()
        mock_creds.credentials = "valid-token"

        read_only_config = MagicMock(spec=DBConfigProperties)
        read_only_config.config_value = "true"

        whitelist_config = MagicMock(spec=DBConfigProperties)
        whitelist_config.config_value = json.dumps({
            "POST": ["/api/middle-layer/entity-search/"]
        })

        call_count = {"n": 0}

        def _mock_query(model):
            mock_q = MagicMock()
            def _filter(*args, **kwargs):
                call_count["n"] += 1
                mock_first = MagicMock()
                if call_count["n"] == 1:
                    mock_first.first.return_value = read_only_config
                else:
                    mock_first.first.return_value = whitelist_config
                return mock_first
            mock_q.filter = _filter
            return mock_q

        db_session.query = _mock_query

        result = auth_mod.token_required(
            token=mock_creds,
            request=mock_request,
            db=db_session,
        )
        assert result["valid"] is True

    def test_no_db_session_raises_500(self):
        """If db is None, token_required should raise HTTPException 500."""
        from lakefusion_utility.utils import auth as auth_mod

        mock_creds = MagicMock()
        mock_creds.credentials = "some-token"

        with pytest.raises(HTTPException) as exc_info:
            auth_mod.token_required(
                token=mock_creds,
                request=MagicMock(),
                db=None,
            )
        assert exc_info.value.status_code == 500
        assert "Database session is required" in str(exc_info.value.detail)
