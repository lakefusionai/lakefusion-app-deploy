from typing import Optional
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import HTTPException, Request, status


class HTTPBearer401(HTTPBearer):
    async def __call__(self, request: Request) -> Optional[HTTPAuthorizationCredentials]:
        # Check headers in order of priority:
        # 1. x-forwarded-access-token (Databricks Apps proxy — strips Authorization header)
        # 2. Authorization (local development / direct access)
        forwarded_token = request.headers.get("x-forwarded-access-token")
        if forwarded_token:
            return HTTPAuthorizationCredentials(scheme="Bearer", credentials=forwarded_token)

        try:
            return await super().__call__(request)
        except HTTPException as exc:
            if exc.status_code == status.HTTP_403_FORBIDDEN:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Not authenticated",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            raise

