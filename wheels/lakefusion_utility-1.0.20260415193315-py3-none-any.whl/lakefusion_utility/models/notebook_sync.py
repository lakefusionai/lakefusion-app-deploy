import uuid
from sqlalchemy import Column, String, Text, DateTime, Enum, ForeignKey, Index
from lakefusion_utility.utils.app_db import Base
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timezone


def _uuid() -> str:
    return str(uuid.uuid4())


# ===========================================================================
# NOTEBOOK SYNC REGISTRY — unified table for folders and notebooks
# ===========================================================================

class NotebookSyncRegistry(Base):
    __tablename__ = 'notebook_sync_registry'
    __table_args__ = (
        Index('idx_nsr_parent_path', 'parent_path'),
        Index('idx_nsr_item_type', 'item_type'),
        Index('idx_nsr_status', 'status'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    artifact_path = Column(String(500), unique=True, nullable=False)
    item_type = Column(String(20), nullable=False)  # FOLDER or NOTEBOOK
    parent_path = Column(String(500), nullable=True)  # NULL for root folders
    display_name = Column(String(255), nullable=False)
    workspace_path = Column(String(500), nullable=True)
    override_policy = Column(String(20), nullable=True)  # SYNC_ON_UPGRADE, LOCKED, or NULL (inherit)
    deployed_version = Column(String(20), nullable=True)
    available_version = Column(String(20), nullable=True)
    deployed_hash = Column(String(32), nullable=True)   # MD5 hash of file content at last successful import
    locked_by = Column(String(255), nullable=True)
    locked_at = Column(DateTime, nullable=True)
    lock_reason = Column(Text, nullable=True)
    last_synced_at = Column(DateTime, nullable=True)
    status = Column(String(20), nullable=False, default='ACTIVE')  # ACTIVE or ARCHIVED
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc), nullable=False)

    def __repr__(self):
        return f"<NotebookSyncRegistry(path={self.artifact_path}, type={self.item_type}, policy={self.override_policy})>"


# ===========================================================================
# NOTEBOOK SYNC AUDIT LOG
# ===========================================================================

class NotebookSyncAuditLog(Base):
    __tablename__ = 'notebook_sync_audit_log'
    __table_args__ = (
        Index('idx_nsal_registry', 'registry_id'),
        Index('idx_nsal_action', 'action'),
        Index('idx_nsal_run', 'sync_run_id'),
        Index('idx_nsal_created', 'created_at'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    registry_id = Column(String(36), ForeignKey('notebook_sync_registry.id'), nullable=True)
    artifact_path = Column(String(500), nullable=False)
    action = Column(String(20), nullable=False)  # IMPORTED, SKIPPED, REGISTERED, ARCHIVED
    from_version = Column(String(20), nullable=True)
    to_version = Column(String(20), nullable=True)
    effective_policy = Column(Text, nullable=True)
    reason = Column(Text, nullable=True)
    sync_run_id = Column(String(36), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    def __repr__(self):
        return f"<NotebookSyncAuditLog(path={self.artifact_path}, action={self.action})>"


# ===========================================================================
# PYDANTIC SCHEMAS
# ===========================================================================

class NotebookSyncRegistryResponse(BaseModel):
    id: str
    artifact_path: str
    item_type: str
    parent_path: Optional[str] = None
    display_name: str
    workspace_path: Optional[str] = None
    override_policy: Optional[str] = None
    deployed_version: Optional[str] = None
    available_version: Optional[str] = None
    deployed_hash: Optional[str] = None
    locked_by: Optional[str] = None
    locked_at: Optional[datetime] = None
    lock_reason: Optional[str] = None
    last_synced_at: Optional[datetime] = None
    status: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class NotebookSyncRegistryUpdate(BaseModel):
    override_policy: Optional[str] = None  # SYNC_ON_UPGRADE, LOCKED, or None (inherit)
    locked_by: Optional[str] = None
    lock_reason: Optional[str] = None


class NotebookSyncAuditLogResponse(BaseModel):
    id: str
    registry_id: Optional[str] = None
    artifact_path: str
    action: str
    from_version: Optional[str] = None
    to_version: Optional[str] = None
    effective_policy: Optional[str] = None
    reason: Optional[str] = None
    sync_run_id: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ForceSyncRequest(BaseModel):
    """Request body for force sync — specifies which locked items to unlock."""
    unlock_ids: List[str] = []  # registry IDs to unlock before syncing
