# config_defaults.py
# CONFIG_DEFAULTS = {
#     "catalog_name": "lakefusion_ai",
#     "dbx_cloud": "azure",
#     "enable_read_only": "False",
#     "lakefusion_spn": "",
#     "notebook_path":"/Workspace/Lakefusion_Notebooks/match-maven-notebooks",
#     "processable_records": "2000",
#     "whitelisted_readonly_routes": '''
#     {
#         "POST": [
#             "/api/middle-layer/dataset/",
#             "/api/auth/generate-auth-token",
#             "/api/auth/refresh-auth-token"
#         ],
#         "PUT": [""]
#     }
#     ''',
#     "default_prompt": '''You are an expert in classifying two entities as matching or not matching.
# You will be provided with a query entity and a list of possible entities.
# You need to find the closest matching entity with a similarity score to indicate how similar they are.
# Take into account:
# 1. The attributes are not mutually exclusive.
# 2. The attributes are not exhaustive.
# 3. The attributes are not consistent.
# 4. The attributes are not complete.
# 5. The attributes can have typos.
# 6. The entity type that is being considered here is - {entity}.
# 7. Do not consider scores in the search results / query entities. Generate scores by yourself.
# 8. If additional instructions are provided below, apply it alongside these core guidelines.'''
# }
from enum import Enum

class ConfigType(str, Enum):
    BOOLEAN = "boolean"
    STRING = "string"
    INT = "int"
    FLOAT = "float"
    JSON = "json"
    KEY = "key"

class ConfigCategory(str, Enum):
    GENERAL = "GENERAL"
    LFTAGS = "LFTAGS"
    DNB = "DNB"
    SPN = "SPN"
    LAKEBASE = "LAKEBASE"


CONFIG_DEFAULTS = [
    {
        "config_key": "catalog_name",
        "config_value": "lakefusion_ai",
        "config_value_type": ConfigType.STRING,
        "config_label": "Catalog Name",
        "config_desc": "Defines the unique name of the master data catalog within the LakeFusion platform. This catalog serves as the central repository for organizing and managing all entity datasets.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "cron_warehouse_id",
        "config_value": "",
        "config_value_type": ConfigType.STRING,
        "config_label": "Cron Warehouse ID",
        "config_desc": "Specifies the unique identifier for the connected data warehouse from Databricks where scheduled jobs and synchronization tasks are executed.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "dbx_cloud",
        "config_value": "aws",
        "config_value_type": ConfigType.STRING,
        "config_label": "DBX Cloud",
        "config_desc": "Indicates the configured Databricks cloud environment (e.g., AWS, Azure, GCP) where the LakeFusion workloads and data operations are deployed.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "default_prompt",
        "config_value": '''You are an entity matching scorer. Compare an incoming unified record against potential golden matches and score each 0.0-1.0.

## Important Context
- Entity type: {entity}
- The attributes are not mutually exclusive, exhaustive, consistent, or complete.
- The attributes can have typos.
- **Empty fields are neutral** — do not penalize or reward a missing value on either side. Only actively conflicting filled values are negative evidence.
- Do not consider vector similarity scores in the search results. Generate your own similarity scores.
- The lakefusion_id is an opaque string identifier — copy it exactly as-is into your output.
- Return exactly one scored result per potential match provided in the input.

## Attribute Order
Fields are pipe-delimited in this order:
{attributes}

Empty fields between pipes = no data.
Note: Some columns can have aggregated values separated by (bullet)

## Input Format

**Query Record:** A single pipe-delimited string following the attribute order above.

**Potential Matches:** A JSON array of 3-element arrays:
[[field1 | field2 | ... | fieldN, lakefusion_id, vector_score], ...]

WHERE each inner array contains:
- Index 0: pipe-separated attribute values (same order as above)
- Index 1: lakefusion_id (opaque string identifier — copy exactly)
- Index 2: vector retrieval score (IGNORE this — compute your own)

**CRITICAL EXTRACTION RULES:**
- For EACH entry, you MUST extract the lakefusion_id from index 1 of the inner array
- If you cannot find a valid lakefusion_id, DO NOT return that entry
- lakefusion_id format: 32 lowercase hexadecimal characters (a-f, 0-9)
- Example valid lakefusion_id: d728dead49f8c4bbbf0be3dcdc65d215

## Conflict vs. Near-match
Classify carefully — this distinction directly affects scoring:
- **Near-match** (typos/entry errors): character transpositions (Jonh->John), misspellings (SMth->Smith), truncations (10 Main St->101 Main St), date component swaps (1990-05-09->1990-09-05), minor formatting differences (St.->Street), missing accents or special characters (Mueller->Muller), language variations of the same word.
- **Conflict** (genuinely different values): completely different names (Mark->John), different cities (Dallas->Los Angeles), different product models (Sentry->C45), different dates with no transposition pattern (1990-05-09->1993-06-18).

## Additional Instructions
{additional_instructions}

## Output Format — STRICT
Return ONLY a plain JSON array. No markdown, no code blocks, no extra text.

The array MUST contain exactly one object per potential match in the input. If the input contains N matches, return N scored results. Each object MUST have exactly these keys:
- id: String (the match_record text from index 0 of the inner array)
- score: Float (YOUR similarity score 0.0-1.0, NOT the vector score)
- reason: String (see Reason Format below)
- lakefusion_id: String (COPY exactly as it appears in input)

Sort by score descending.

## Reason Format
Format: "Key signals: [2-3 most important field classifications]. Justification: [1-2 sentences explaining the score]."

Each field classification uses this taxonomy: exact_match | near_match | conflict | one_empty | both_empty. For conflicts and near-matches, include the actual values in parentheses.

Example:
"Key signals: companyName exact_match, addressLineOne near_match (123 Main vs 123 Main St), supplierEmail exact_match. Justification: Strong identity agreement across name and email with minor address formatting difference. Scored 0.95 as MATCH."''',
        "config_value_type": ConfigType.STRING,
        "config_label": "Default Prompt",
        "config_desc": "Provides the base instruction for entity matching and similarity scoring. This prompt guides the AI model in evaluating and classifying entities based on predefined attributes and rules.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "enable_read_only",
        "config_value": "False",
        "config_value_type": ConfigType.BOOLEAN,
        "config_label": "Enable Read Only",
        "config_desc": "When enabled, restricts modifications to configuration settings and data records. Useful for audit or view-only environments.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 0,
    },
    {
        "config_key": "lakefusion_spn",
        "config_value": "",
        "config_value_type": ConfigType.STRING,
        "config_label": "Service Principal Client ID",
        "config_desc": "The Application (Client) ID of the Service Principal used for secure authentication between LakeFusion and Databricks, including job execution (run_as) and workflow OAuth flows such as the Vector Search network-optimized route.",
        "config_category": ConfigCategory.SPN,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "notebook_path",
        "config_value": "/Workspace/Lakefusion_Notebooks/match-maven-notebooks-universe",
        "config_value_type": ConfigType.STRING,
        "config_label": "Notebook Path",
        "config_desc": "Specifies the absolute path in Databricks workspace where MDM-related notebooks and processing workflows are stored.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "processable_records",
        "config_value": "2000",
        "config_value_type": ConfigType.INT,
        "config_label": "Processable Records",
        "config_desc": "Indicates the maximum number of records the system can process in a single batch for match maven tasks.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "sync_tables",
        "config_value": "datasets,entity,entityattributes,entitydatasetmapping,model_experiments,profiling_tasks,quality_tasks,survivorshiprule,validationfunctions,validationuserdefinedfunctions",
        "config_value_type": ConfigType.STRING,
        "config_label": "Sync Tables",
        "config_desc": "Lists of tables that are configured for synchronization between LakeFusion and the associated Databricks workspace.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "whitelisted_readonly_routes",
        "config_value": '''{ "POST": ["/api/middle-layer/dataset/","/api/auth/generate-auth-token","/api/auth/refresh-auth-token"],     "PUT": [""] }''',
        "config_value_type": ConfigType.STRING,
        "config_label": "Whitelisted Readonly Routes",
        "config_desc": "List of API routes that are exempt from read-only restrictions, allowing specific operations to be performed even when read-only mode is enabled.",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 0,
    },
    {
        "config_key": "resource_tagging",
        "config_value": '''{}''',
        "config_value_type": ConfigType.JSON,
        "config_label": "Resource Tagging",
        "config_desc": "Allows users to assign key–value pairs to system resources for better organization, filtering, and access control within the Databricks environment.",
        "config_category": ConfigCategory.LFTAGS,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "dnb_integration_enabled",
        "config_value": "False",
        "config_value_type": ConfigType.BOOLEAN,
        "config_label": "Enable Dun & Bradstreet (DnB) Integration",
        "config_desc": "Activate or deactivate the Dun & Bradstreet (DnB) integration. When DnB integration is enabled, the DnB configuration panel within the Entities module becomes available. Users can then manage and customize Dun & Bradstreet enrichment settings for entity records.",
        "config_category": ConfigCategory.DNB,
        "extended_values": '{"dnb_api_key_length": ""}',
        "config_show": 1,
    },
    {
        "config_key": "lakefusion_spn_secret",
        "config_value": "",
        "config_value_type": ConfigType.KEY,
        "config_label": "Service Principal Client Secret",
        "config_desc": "The client secret for the Service Principal used for all workflow OAuth flows, including the Vector Search network-optimized route.",
        "config_category": ConfigCategory.SPN,
        "extended_values": '{"spn_client_secret_length": ""}',
        "config_show": 1,
    },
    {
        "config_key": "pipeline_base_version",
        "config_value": "4.0.0",
        "config_value_type": ConfigType.STRING,
        "config_label": "Pipeline Base Version",
        "config_desc": "Base version of MDM pipeline",
        "config_category": ConfigCategory.GENERAL,
        "extended_values": None,
        "config_show": 0,
    },
    {
        "config_key": "lakebase_instance_id",
        "config_value": "lakefusion-db",
        "config_value_type": ConfigType.STRING,
        "config_label": "Instance Name",
        "config_desc": "The name of the Lakebase instance to connect to. Required when Lakebase is configured as a storage destination.",
        "config_category": ConfigCategory.LAKEBASE,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "lakebase_branch_id",
        "config_value": "production",
        "config_value_type": ConfigType.STRING,
        "config_label": "Branch",
        "config_desc": "The branch in the Lakebase instance where data is stored. Used when Lakebase is enabled as a storage option.",
        "config_category": ConfigCategory.LAKEBASE,
        "extended_values": None,
        "config_show": 1,
    },
    {
        "config_key": "lakebase_endpoint_id",
        "config_value": "primary",
        "config_value_type": ConfigType.STRING,
        "config_label": "Endpoint",
        "config_desc": "The endpoint used to connect to the Lakebase instance. Required when Lakebase is configured as a storage destination.",
        "config_category": ConfigCategory.LAKEBASE,
        "extended_values": None,
        "config_show": 1,
    },
]

