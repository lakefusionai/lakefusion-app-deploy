from lakefusion_utility.utils.logging_utils import get_logger
import traceback
from lakefusion_utility.logparser.LogMessages import LogMessages
from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.models.httpresponse import HttpResponse
from cachetools import TTLCache, cached
from cachetools.keys import hashkey
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from sqlalchemy.orm import Session
from lakefusion_utility.config_defaults import CONFIG_DEFAULTS
from sqlalchemy import func
from fastapi import HTTPException
from datetime import datetime, timezone
from typing import Optional

token_cache = TTLCache(maxsize=100, ttl=3600)

logger = get_logger('db_config_utility')

class DBConfigPropertiesService:
    db: Session

    def __init__(self, db: Session):
        """
        Initializes the ProfilingTaskService with a database session.

        Parameters:
        - db: The database session to be used for operations
        """
        self.db = db

    def getDBConfigProperties(self, key: str, required=False):
        try:
            # Try to get the key from the database
            db_configs = self.getAllDBConfigProperties()
            value = db_configs.get(key)

            # If key not found in database, check CONFIG_DEFAULTS
            if not value:
                # Check if key exists in CONFIG_DEFAULTS
                if key in CONFIG_DEFAULTS:
                    return CONFIG_DEFAULTS[key]
                # If key is required and not found in either source, raise exception
                elif required:
                    raise Exception(f"Configuration key {key} not found in database & default configuration!")
            
            return value
        except Exception as e:
            logger.exception(e)
            raise Exception("App not configured properly") from e

    @cached(cache=token_cache, key=hashkey)
    def getAllDBConfigProperties(self):
        try:
            config_records = self.db.query(DBConfigProperties).all()
            return {record.config_key: record.config_value for record in config_records}
        except Exception as e:
            logger.exception(e)
            raise Exception("App not configured properly") from e


    # def get_db_config(self):
    #     try:
    #         config_records = self.db.query(DBConfigProperties).all()
    #         response = HttpResponse(status=200, data=[config_record.to_json() for config_record in config_records])
    #     except Exception as e:
    #         logger.exception(LogMessages.INTERNAL_SERVER_ERROR_OCCURRED.value.format(exception=e))
    #         response = HttpResponse(f'Exception Occurred - {e}', 500)
    #     return response


    # def update_db_config(self, key: str, value: str, new_key: str = None):
    #     try:
    #         config_record = self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == key).first()
    #         if new_key:
    #             config_record.config_key = new_key
    #         config_record.config_value = value
    #         self.db.add(config_record)
    #         db_commit_auto_rollback()
    #         response = HttpResponse(status=200, data=[config_record.to_json()], message="Config updated successfully")
    #     except Exception as e:
    #         logger.exception(LogMessages.INTERNAL_SERVER_ERROR_OCCURRED.value.format(exception=e))
    #         response = HttpResponse(f'Exception Occurred - {e}', 500)
    #     return response


    # def add_db_config(self, key: str, value: str):
    #     try:
    #         config_record = DBConfigProperties(config_key=key, config_value=value)
    #         self.db.add(config_record)
    #         db_commit_auto_rollback()
    #         response = HttpResponse(status=200, data=[config_record.to_json()], message="Config added successfully")
    #     except Exception as e:
    #         logger.exception(LogMessages.INTERNAL_SERVER_ERROR_OCCURRED.value.format(exception=e))
    #         response = HttpResponse(f'Exception Occurred - {e}', 500)
    #     return response
    

    def get_all_db_config_properties(self, category: str = None):
        """Retrieves all configuration properties from the database.
        
        Args:
            category: Optional category filter (case-insensitive)
            
        Returns:
            A list of dictionaries containing all config properties.
            
        Raises:
            Exception: If there's an error fetching the data.
        """
        try:
            # Start with base query
            query = self.db.query(DBConfigProperties)
            
            # Apply category filter if provided (case-insensitive)
            if category:
                query = query.filter(func.lower(DBConfigProperties.config_category) == func.lower(category))
            
            # Execute query
            config_properties = query.all()
            
            # Check if no results found when category was provided
            if category and not config_properties:
                raise ValueError(f"No Configs found by name {category}")
            
            # Use to_json() method - dynamic and maintainable
            result = [config.to_json() for config in config_properties]
            
            return result
            
        except ValueError as ve:
            logger.warning(str(ve))
            raise HTTPException(status_code=404, detail=str(ve))
        except Exception as e:
            message = traceback.format_exc()
            logger.exception(f'Unable to fetch DB Configs. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch DB Configs: {str(e)}") 


    def update_db_config_property(self, config_key: str, config_value: str, extended_values: str = None, updated_by: str = "system", token: Optional[str] = None):
        """Updates a specific configuration property in the database.
        
        Args:
            config_key: The configuration key to update
            config_value: The new value for the configuration
            updated_by: The user who is updating the config (default: "system")
            
        Returns:
            A dictionary containing the updated config property.
            
        Raises:
            HTTPException: If the config key is not found or if there's an error updating.
        """
        try:
            # Special handling for enable_read_only key to prevent lockout
            # This allows disabling read-only mode even when it's currently enabled
            if config_key == "enable_read_only" and config_value.lower() == "false":
                logger.info("Attempting to disable read-only mode - bypassing read-only restrictions")
            
            # Find the config record by key
            config_record = self.db.query(DBConfigProperties).filter(
                DBConfigProperties.config_key == config_key
            ).first()
            
            # If not found, raise 404
            if not config_record:
                raise ValueError(f"Configuration key '{config_key}' not found")
            
            # Update the values
            config_record.config_value = config_value
            config_record.updated_by = updated_by
            config_record.updated_at = datetime.now(timezone.utc)
            if extended_values is not None:
                config_record.extended_values = extended_values
            
            # Commit changes
            self.db.commit()
            
            # Clear the cache since config was updated
            token_cache.clear()

            logger.info(f"Successfully updated config key: {config_key}")

            # When SPN is updated, propagate the new SPN to all Databricks jobs
            if config_key == "lakefusion_spn" and token:
                self._update_spn_on_all_jobs(spn=config_value, token=token)

            # When catalog_name is updated, grant SPN permissions + register UDF
            if config_key == "catalog_name" and token:
                self._grant_catalog_permissions_to_spn(catalog_name=config_value, token=token)
                try:
                    from lakefusion_utility.services.catalog_setup_service import CatalogSetupService
                    warehouse_id = self.getDBConfigProperties(key="cron_warehouse_id")
                    if warehouse_id:
                        svc = CatalogSetupService(token=token, warehouse_id=warehouse_id, catalog_name=config_value)
                        svc.register_survivorship_udf()
                except Exception as e:
                    logger.warning(f"UDF registration failed (non-blocking): {e}")

            return config_record.to_json()
            
        except ValueError as ve:
            self.db.rollback()
            logger.warning(str(ve))
            raise HTTPException(status_code=404, detail=str(ve))
        except HTTPException:
            # Re-raise HTTPExceptions from post-commit steps (e.g. catalog permission failures)
            # without rolling back — the DB update already succeeded
            raise
        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            logger.exception(f'Unable to update DB Config. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to update DB Config: {str(e)}")
        
    def _update_spn_on_all_jobs(self, spn: str, token: str):
        """Propagates a new SPN to all Databricks jobs tracked in match_maven_job and integration_hub,
        and grants CAN_MANAGE on the notebook_path workspace folder.

        Args:
            spn: The new service principal name to set as run_as on every job.
            token: Databricks access token.
        """
        from lakefusion_utility.models.databricks_model import Model_Databricks_Job
        from lakefusion_utility.models.integration_hub import Integration_Hub
        from lakefusion_utility.utils.databricks_util import DatabricksJobManager, NotebookService
        from databricks.sdk.service.jobs import JobSettings, JobRunAs
        from databricks.sdk.service.iam import PermissionLevel

        try:
            job_manager = DatabricksJobManager(token=token)
            new_settings = JobSettings(run_as=JobRunAs(service_principal_name=spn))

            # Collect distinct job_ids from match_maven_job
            match_maven_job_ids = {
                row.job_id
                for row in self.db.query(Model_Databricks_Job.job_id).distinct().all()
                if row.job_id
            }

            # Collect job_id_1 and job_id_2 from integration_hub
            integration_hub_ids = set()
            for row in self.db.query(Integration_Hub.job_id_1, Integration_Hub.job_id_2).all():
                if row.job_id_1:
                    integration_hub_ids.add(row.job_id_1)
                if row.job_id_2:
                    integration_hub_ids.add(row.job_id_2)

            all_job_ids = match_maven_job_ids | integration_hub_ids

            if not all_job_ids:
                logger.info("No Databricks jobs found in match_maven_job or integration_hub — skipping SPN update on jobs")
            else:
                logger.info(f"Updating SPN on {len(all_job_ids)} Databricks job(s)")

            for job_id in all_job_ids:
                try:
                    job_manager.w.jobs.update(job_id=job_id, new_settings=new_settings)
                    logger.info(f"Updated SPN for job_id: {job_id}")
                except Exception as e:
                    logger.warning(f"Failed to update SPN for job_id {job_id}: {str(e)}")

            # Grant catalog permissions to the new SPN
            catalog_record = self.db.query(DBConfigProperties).filter(
                DBConfigProperties.config_key == "catalog_name"
            ).first()

            if catalog_record and catalog_record.config_value:
                self._grant_catalog_permissions_to_spn(catalog_name=catalog_record.config_value, token=token)
            else:
                logger.warning("catalog_name not configured — skipping catalog permission grant for SPN update")

            # Grant CAN_MANAGE on the notebook_path workspace folder to the new SPN
            notebook_path_record = self.db.query(DBConfigProperties).filter(
                DBConfigProperties.config_key == "notebook_path"
            ).first()

            if notebook_path_record and notebook_path_record.config_value:
                notebook_path = notebook_path_record.config_value
                try:
                    notebook_service = NotebookService(token=token)
                    workspace_object = notebook_service.get_object_info(notebook_path)
                    notebook_service.set_permissions(
                        workspace_object=workspace_object,
                        principal_id=spn,
                        permission=PermissionLevel.CAN_MANAGE,
                        is_service_principal=True,
                    )
                    logger.info(f"Granted CAN_MANAGE on notebook_path '{notebook_path}' to SPN '{spn}'")
                except Exception as e:
                    logger.warning(f"Failed to grant CAN_MANAGE on notebook_path '{notebook_path}': {str(e)}")
            else:
                logger.warning("notebook_path not configured — skipping workspace permission grant")

        except Exception as e:
            logger.exception(f"Error while updating SPN on Databricks jobs: {str(e)}")

    def _grant_catalog_permissions_to_spn(self, catalog_name: str, token: str):
        """Grants ALL_PRIVILEGES and ownership on a Unity Catalog catalog to the configured SPN.

        Args:
            catalog_name: The Unity Catalog catalog name to update.
            token: Databricks access token.
        """
        from lakefusion_utility.utils.databricks_util import DatabricksJobManager
        from lakefusion_utility.utils.databricks_util import _create_workspace_client
        from databricks.sdk.service.catalog import SecurableType, PermissionsChange, Privilege
        import os

        try:
            # Fetch the SPN from DB config
            spn_record = self.db.query(DBConfigProperties).filter(
                DBConfigProperties.config_key == "lakefusion_spn"
            ).first()

            if not spn_record or not spn_record.config_value:
                logger.warning("lakefusion_spn not configured — skipping catalog permission grant")
                return

            spn = spn_record.config_value

            # Shared helper guarantees the https:// prefix is present.
            from lakefusion_utility.utils.databricks_host import get_databricks_host
            DATABRICKS_HOST = get_databricks_host() or 'https://databricks.com'
            w = _create_workspace_client(token)

            # Grant ALL_PRIVILEGES on the catalog to the SPN
            # securable_type must be a lowercase string for the REST path (e.g. "catalog")
            w.grants.update(
                full_name=catalog_name,
                securable_type=SecurableType.CATALOG.value.lower(),
                changes=[PermissionsChange(add=[Privilege.ALL_PRIVILEGES, Privilege.MANAGE], principal=spn)]
            )
            logger.info(f"Granted ALL_PRIVILEGES on catalog '{catalog_name}' to SPN '{spn}'")

        except HTTPException:
            raise 
        except Exception as e:
            message = traceback.format_exc()
            logger.exception(f"Error while granting catalog permissions to SPN: {message}")
            raise HTTPException(
                status_code=500,
                detail=(
                    f"catalog_name was saved successfully, but granting ALL_PRIVILEGES and MANAGE "
                    f"on catalog '{catalog_name}' to SPN '{spn}' failed. "
                    f"Reason: {str(e)}. "
                    f"Please grant the permissions manually or retry."
                )
            )

    @classmethod
    def clear_cache(cls):
        token_cache.clear()
        logger.info("DBConfigProperties cache cleared successfully")