import asyncio
import os
import ssl
import time
import uuid
import jwt
from typing import AsyncGenerator
from contextlib import asynccontextmanager
from fastapi import FastAPI

from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.app_db import Base

from databricks.sdk import WorkspaceClient
from sqlalchemy import URL, event, create_engine
from sqlalchemy.orm import sessionmaker

from fastapi.security import HTTPAuthorizationCredentials
from fastapi import Depends, Request
from lakefusion_utility.utils.auth import token_required, token_auth_scheme
from sqlalchemy.orm import Session

from app.config import AppConfig
from sqlalchemy import URL, event, create_engine, text, Engine

logger = get_logger('utility_database')

# Environment configuration
SERVICE_NAME = os.getenv("SERVICE_NAME", "LakeFusionDBService")
DB_TYPE = os.environ.get("DB_TYPE", "mysql").lower()
# Use the shared helper to guarantee the https:// prefix (Databricks Apps
# inject DATABRICKS_HOST as a bare host; SDK auth requires the scheme).
from lakefusion_utility.utils.databricks_host import get_databricks_host
DATABRICKS_HOST = get_databricks_host() or None
DATABRICKS_DAPI = os.getenv("LAKEFUSION_DATABRICKS_DAPI")
# Detect Databricks Apps environment (DATABRICKS_APP_URL is only set inside Databricks Apps)
IS_DATABRICKS_APPS = bool(os.getenv("DATABRICKS_APP_URL"))
DATABRICKS_DATABASE_INSTANCE = os.getenv("DATABRICKS_DATABASE_INSTANCE", "LakeFusionTransactional")
DATABRICKS_DATABASE_NAME = os.getenv("DATABRICKS_DATABASE_NAME", 'transactional_db')
DATABRICKS_DATABASE_PORT = int(os.getenv("DATABRICKS_DATABASE_PORT", "5432"))
DB_POOL_SIZE = int(os.getenv("DB_POOL_SIZE", "20"))
DB_MAX_OVERFLOW = int(os.getenv("DB_MAX_OVERFLOW", "40"))
DB_POOL_TIMEOUT = int(os.getenv("DB_POOL_TIMEOUT", "90"))
DB_POOL_RECYCLE = int(os.getenv("DB_POOL_RECYCLE", "1200"))
DB_SSL_CA_PATH = os.getenv("DB_SSL_CA_PATH")

# Global variables
engine: Engine | None = None
SessionLocal: sessionmaker | None = None
workspace_client: WorkspaceClient | None = None
database_instance = None
app_name: str = SERVICE_NAME
db_type = DB_TYPE

# Token management for background refresh
postgres_password: str | None = None
last_password_refresh: float = 0
token_refresh_task: asyncio.Task | None = None

# Connection pool warm-up tracking
pool_warmed_up: bool = False
warm_up_task: asyncio.Task | None = None


async def refresh_token_background():
    global postgres_password, last_password_refresh, workspace_client, database_instance

    while True:
        try:
            await asyncio.sleep(50 * 60)
            logger.info("Background token refresh: Generating fresh PostgreSQL OAuth token")

            cred = workspace_client.database.generate_database_credential(
                request_id=str(uuid.uuid4()),
                instance_names=[database_instance.name],
            )
            postgres_password = cred.token
            last_password_refresh = time.time()
            logger.info("Background token refresh: Token updated successfully")

        except Exception as e:
            logger.error(f"Background token refresh failed: {e}")


def _get_ssl_connect_args():
    """Build SSL connect_args for MySQL/PostgreSQL when DB_SSL_CA_PATH is set."""
    if not DB_SSL_CA_PATH:
        return {}

    if db_type == "mysql":
        ssl_context = ssl.create_default_context(cafile=DB_SSL_CA_PATH)
        return {"ssl": ssl_context}
    elif db_type == "postgresql":
        return {"sslmode": "verify-full", "sslrootcert": DB_SSL_CA_PATH}

    return {}


def init_engine():
    global url, engine, SessionLocal, workspace_client, database_instance, postgres_password, last_password_refresh

    try:
        if db_type == 'lakebase':
            if IS_DATABRICKS_APPS:
                # Databricks Apps — automatic OAuth via service principal
                workspace_client = WorkspaceClient()
                logger.info("[DATABRICKS APPS] WorkspaceClient initialized with automatic auth")
            elif DATABRICKS_HOST:
                # Local dev — use DAPI token
                workspace_client = WorkspaceClient(
                    host=DATABRICKS_HOST, token=DATABRICKS_DAPI
                )
                logger.info(f"[LOCAL] WorkspaceClient initialized with token for {DATABRICKS_HOST}")
            else:
                workspace_client = WorkspaceClient()

            database_instance = workspace_client.database.get_database_instance(
                name=DATABRICKS_DATABASE_INSTANCE
            )

            cred = workspace_client.database.generate_database_credential(
                request_id=str(uuid.uuid4()), instance_names=[database_instance.name]
            )
            postgres_password = cred.token
            last_password_refresh = time.time()
            logger.info("Database: Initial credentials generated")

            decoded_token = jwt.decode(
                cred.token, options={"verify_signature": False}
            )
            username = decoded_token.get('sub', '')

            url = URL.create(
                drivername="postgresql+psycopg2",
                username=username,
                password="",
                host=database_instance.read_write_dns,
                port=DATABRICKS_DATABASE_PORT,
                database=DATABRICKS_DATABASE_NAME,
                query={"sslmode": "require"},
            )

            engine = create_engine(
                url,
                pool_pre_ping=True,
                echo=False,
                pool_size=DB_POOL_SIZE,
                max_overflow=DB_MAX_OVERFLOW,
                pool_timeout=DB_POOL_TIMEOUT,
                pool_recycle=DB_POOL_RECYCLE,
                # ✅ Performance optimizations for better latency
                pool_reset_on_return='commit',  # Faster connection reuse
                pool_use_lifo=True,            # Last-in-first-out for better locality
                connect_args={
                    'application_name': SERVICE_NAME,
                    'options': '-c statement_timeout=30000 -c idle_in_transaction_session_timeout=60000'
                }
            )

            @event.listens_for(engine, "do_connect")
            def provide_token(dialect, conn_rec, cargs, cparams):
                global postgres_password
                cparams["password"] = postgres_password

            logger.info(
                f"Database engine initialized for {DATABRICKS_DATABASE_NAME} with background token refresh"
            )
        else:
            url = AppConfig.DATABASE_URL
            logger.info(f"Database engine url: {url}")
            engine = create_engine(
                url,
                isolation_level="READ COMMITTED",
                pool_pre_ping=True,
                echo=False,
                pool_size=DB_POOL_SIZE,
                max_overflow=DB_MAX_OVERFLOW,
                pool_timeout=DB_POOL_TIMEOUT,
                pool_recycle=DB_POOL_RECYCLE,
                # ✅ Performance optimizations for MySQL
                pool_reset_on_return='commit',
                pool_use_lifo=True,
                connect_args=_get_ssl_connect_args()
            )
            if DB_SSL_CA_PATH:
                logger.info(f"Database engine initialized with SSL (CA: {DB_SSL_CA_PATH})")
            else:
                logger.info("Database engine initialized")

        # ✅ Fix: Create proper async session factory
        SessionLocal = sessionmaker(
            autocommit=False, 
            autoflush=False, 
            bind=engine
        )

    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        raise RuntimeError(f"Failed to initialize database: {e}") from e


async def start_token_refresh():
    global token_refresh_task
    if token_refresh_task is None or token_refresh_task.done():
        token_refresh_task = asyncio.create_task(refresh_token_background())
        logger.info("Background token refresh task started")


async def stop_token_refresh():
    global token_refresh_task
    if token_refresh_task and not token_refresh_task.done():
        token_refresh_task.cancel()
        try:
            await token_refresh_task
        except asyncio.CancelledError:
            pass
        logger.info("Background token refresh task stopped")


async def get_db() -> AsyncGenerator[Session, None]:
    """
    ✅ FIXED: Proper async session management for concurrent requests.
    This enables true concurrent database operations instead of serial execution.
    """
    global engine, SessionLocal, workspace_client, database_instance, postgres_password, last_password_refresh

    if SessionLocal is None:
        raise RuntimeError("Engine not initialized; call init_engine() first")
    
    # ✅ Use async context manager for proper async session handling
    with SessionLocal() as session:
        try:
            yield session
        except Exception:
            # Rollback on error
            session.rollback()
            raise
        finally:
            # Ensure session is properly closed
            session.close()


def token_required_wrapper(
    token: HTTPAuthorizationCredentials = Depends(token_auth_scheme),
    request: Request = None,
    db: Session = Depends(get_db)
):
    return token_required(token, request, db)


async def warm_up_connection_pool():
    """
    Pre-warm connection pool for better initial performance.
    This reduces latency for the first few requests by having connections ready.
    """
    global pool_warmed_up
    
    if pool_warmed_up:
        logger.info("Connection pool already warmed up, skipping...")
        return
    
    logger.info("🔥 Warming up connection pool for better performance...")
    
    try:
        # Calculate how many connections to warm up (min of 10 or pool size)
        warm_up_count = min(10, DB_POOL_SIZE)
        logger.info(f"Warming up {warm_up_count} connections...")
        
        warm_up_tasks = []
        
        for i in range(warm_up_count):
            task = asyncio.create_task(_warm_up_single_connection(i + 1))
            warm_up_tasks.append(task)
        
        # Wait for all warm-up tasks to complete
        results = await asyncio.gather(*warm_up_tasks, return_exceptions=True)
        
        # Count successful warm-ups
        successful_warm_ups = sum(1 for result in results if not isinstance(result, Exception))
        failed_warm_ups = len(results) - successful_warm_ups
        
        if failed_warm_ups > 0:
            logger.warning(f"Connection pool warm-up: {successful_warm_ups} successful, {failed_warm_ups} failed")
        else:
            logger.info(f"✅ Connection pool warmed up successfully with {successful_warm_ups} connections")
        
        pool_warmed_up = True
        
    except Exception as e:
        logger.error(f"❌ Connection pool warm-up failed: {e}")
        # Don't fail the application if warm-up fails
        pool_warmed_up = False


async def _warm_up_single_connection(connection_num: int):
    """
    Warm up a single connection by executing a simple query.
    This ensures the connection is ready for use.
    """
    try:
        with SessionLocal() as session:
            # Execute a simple query to warm up the connection
            result = session.execute(text("SELECT 1 as test_connection"))
            session.commit()
            
            logger.debug(f"Connection {connection_num} warmed up successfully")
            return True
            
    except Exception as e:
        logger.warning(f"Failed to warm up connection {connection_num}: {e}")
        return False


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Application startup initiated")

    logger.info(f"Initializing database engine for db_type: {db_type}")
    init_engine()
    logger.info("Database engine initialized")

    # Hotfix 3.4.1 - Removing this as we now have alembic for migrations
    # Base.metadata.create_all(bind=engine)
    logger.info("Database tables created")

    # ✅ Add connection pool warm-up for better initial performance
    logger.info("Starting connection pool warm-up...")
    await warm_up_connection_pool()
    logger.info("Connection pool warm-up completed")

    if db_type == "lakebase":
        logger.info("Starting Lakebase token refresh")
        await start_token_refresh()

    from lakefusion_utility.utils.databricks_util import set_user_agent_header
    set_user_agent_header()

    logger.info("Application startup complete")
    yield

    logger.info("Application shutdown initiated")
    if db_type == "lakebase":
        logger.info("Stopping Lakebase token refresh")
        await stop_token_refresh()

    logger.info("Application shutdown complete")
