import uuid
from sqlalchemy import (
    Column, String, Integer, Boolean, DateTime, Date, Numeric, Text,
    ForeignKey, ForeignKeyConstraint, UniqueConstraint, CheckConstraint, Index
)
from sqlalchemy.orm import relationship
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
from pydantic import BaseModel, field_validator
from typing import Optional, List
import uuid as _uuid_mod


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------
def _uuid() -> str:
    return str(uuid.uuid4())


import re as _re


def to_value_key(label: str) -> str:
    """Derive a stable option key from a display label.
    'Club Red' -> 'CLUB_RED', 'US 6' -> 'US_6', 'Fall/Winter' -> 'FALL_WINTER'.
    Upper-cases, replaces non-alphanumeric runs with '_', strips leading/trailing '_'.
    Single source of truth for option keys (used by attribute service + bulk importer).
    """
    if label is None:
        return ''
    key = _re.sub(r'[^A-Za-z0-9]+', '_', label.strip()).strip('_').upper()
    return key


# ===========================================================================
# LAYER 0 – REFERENCE TABLES
# ===========================================================================

class PimLanguageRef(Base):
    __tablename__ = 'pim_language_ref'
    __table_args__ = {'extend_existing': True}

    id = Column(String(10), primary_key=True)
    language_name = Column(String(100), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    def __init__(self, id, language_name, is_active=True, created_at=None):
        self.id = id
        self.language_name = language_name
        self.is_active = is_active
        self.created_at = created_at or datetime.utcnow()

    def __repr__(self):
        return f"<PimLanguageRef(id={self.id}, language_name={self.language_name})>"


class PimUnitRef(Base):
    __tablename__ = 'pim_unit_ref'
    __table_args__ = {'extend_existing': True}

    name = Column(String(50), primary_key=True)
    category = Column(String(50))
    description = Column(String(255))
    base_unit = Column(String(50), nullable=True)
    to_base_factor = Column(Numeric(20, 10), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    def __init__(self, name, category=None, description=None, base_unit=None,
                 to_base_factor=None, is_active=True, created_at=None):
        self.name = name
        self.category = category
        self.description = description
        self.base_unit = base_unit
        self.to_base_factor = to_base_factor
        self.is_active = is_active
        self.created_at = created_at or datetime.utcnow()

    def __repr__(self):
        return f"<PimUnitRef(name={self.name}, category={self.category})>"


# ===========================================================================
# LAYER 1 – TAXONOMY
# ===========================================================================

class PimTaxonomyNode(Base):
    __tablename__ = 'pim_taxonomy_node'
    __table_args__ = (
        UniqueConstraint('parent_id', 'code', name='uq_pim_taxonomy_code_parent'),
        Index('idx_pim_taxonomy_path', 'materialized_path'),
        Index('idx_pim_taxonomy_parent', 'parent_id'),
        Index('idx_pim_taxonomy_level', 'level'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    code = Column(String(255), nullable=False)
    label = Column(String(255), nullable=False)
    parent_id = Column(String(36), ForeignKey('pim_taxonomy_node.id'), nullable=True)
    materialized_path = Column(Text, nullable=False)
    level = Column(Integer, nullable=False, default=0)
    display_order = Column(Integer, nullable=False, default=0)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    parent = relationship('PimTaxonomyNode', remote_side=[id], back_populates='children')
    children = relationship('PimTaxonomyNode', back_populates='parent', cascade='all, delete-orphan')
    attribute_configs = relationship('PimSpecificationConfig', back_populates='taxonomy_node', cascade='all, delete-orphan')

    def __init__(self, code, label, materialized_path, level=0, display_order=0,
                 parent_id=None, id=None, is_active=True, created_at=None, updated_at=None):
        self.id = id or _uuid()
        self.code = code
        self.label = label
        self.parent_id = parent_id
        self.materialized_path = materialized_path
        self.level = level
        self.display_order = display_order
        self.is_active = is_active
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()

    def __repr__(self):
        return f"<PimTaxonomyNode(id={self.id}, code={self.code}, label={self.label}, level={self.level})>"


# ===========================================================================
# LAYER 2 – ATTRIBUTE DEFINITION
# ===========================================================================

class PimAttributeDefinition(Base):
    __tablename__ = 'pim_attribute_definition'
    __table_args__ = (
        UniqueConstraint('code', name='uq_pim_attr_code'),
        CheckConstraint(
            "data_type IN ('TEXT', 'NUMBER', 'BOOLEAN', 'DATE', 'SELECT', 'MULTISELECT', 'REFERENCE')",
            name='chk_pim_attr_type'
        ),
        # level validated against pim_entity_tier codes + 'ALL' in application code (supports N-tier)
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    code = Column(String(255), nullable=False, unique=True)
    label = Column(String(255), nullable=False)
    data_type = Column(String(50), nullable=False)
    reference_entity_id = Column(String(36), nullable=True)
    description = Column(Text, nullable=True)
    is_localizable = Column(Boolean, nullable=False, default=False)
    level = Column(String(20), nullable=False, default='ALL')
    scope = Column(String(20), nullable=False, default='specifications')
    is_system = Column(Boolean, nullable=False, default=False)
    is_identifier = Column(Boolean, nullable=False, default=False)
    is_label = Column(Boolean, nullable=False, default=False)
    group = Column(String(100), nullable=False, default='General')
    display_order = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    attribute_configs = relationship('PimSpecificationConfig', back_populates='attribute', cascade='all, delete-orphan')
    options = relationship('PimAttributeOption', cascade='all, delete-orphan',
                           order_by='PimAttributeOption.display_order')

    def __init__(self, code, label, data_type, reference_entity_id=None, description=None,
                 is_localizable=False, level='ALL', scope='specifications', is_system=False,
                 is_identifier=False, is_label_attr=False,
                 group=None, display_order=0,
                 id=None, created_at=None, updated_at=None):
        self.id = id or _uuid()
        self.code = code
        self.label = label
        self.data_type = data_type
        self.reference_entity_id = reference_entity_id
        self.description = description
        self.is_localizable = is_localizable
        self.level = level
        self.scope = scope
        self.is_system = is_system
        self.is_identifier = is_identifier
        self.is_label = is_label_attr
        self.group = group or ('Specifications' if scope == 'specifications' else 'General')
        self.display_order = display_order
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()

    def __repr__(self):
        return f"<PimAttributeDefinition(id={self.id}, code={self.code}, data_type={self.data_type})>"


class PimAttributeOption(Base):
    """Allowed option for a SELECT / MULTISELECT attribute (keyed controlled vocabulary).
    The stored product value (pim_value_select.ref_value_key / pim_value_multiselect.ref_value_key)
    equals this option's value_key, enforced by a hard composite FK (see PimValueSelect /
    PimValueMultiselect __table_args__). REFERENCE attributes do NOT use this table — their
    options come from the RDM entity referenced by pim_attribute_definition.reference_entity_id.
    """
    __tablename__ = 'pim_attribute_option'
    __table_args__ = (
        UniqueConstraint('attribute_id', 'value_key', name='uq_pim_attr_option'),
        Index('idx_pim_ao_attr', 'attribute_id'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    attribute_id = Column(String(36), ForeignKey('pim_attribute_definition.id', ondelete='CASCADE'), nullable=False)
    value_key = Column(String(255), nullable=False)    # stored code, e.g. 'CLUB_RED'
    label = Column(String(255), nullable=False)         # display text, e.g. 'Club Red'
    display_order = Column(Integer, nullable=False, default=0)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    attribute = relationship('PimAttributeDefinition', overlaps='options')

    def __repr__(self):
        return f"<PimAttributeOption(attr={self.attribute_id}, key={self.value_key})>"


# ===========================================================================
# LAYER 3 – GOVERNANCE
# ===========================================================================

class PimSpecificationConfig(Base):
    __tablename__ = 'pim_specification_config'
    __table_args__ = (
        UniqueConstraint('taxonomy_node_id', 'attribute_id', name='uq_pim_tac_node_attr'),
        Index('idx_pim_tac_node', 'taxonomy_node_id'),
        Index('idx_pim_tac_attr', 'attribute_id'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    taxonomy_node_id = Column(String(36), ForeignKey('pim_taxonomy_node.id', ondelete='CASCADE'), nullable=False)
    attribute_id = Column(String(36), ForeignKey('pim_attribute_definition.id', ondelete='CASCADE'), nullable=False)
    is_required = Column(Boolean, nullable=False, default=False)
    inherit_to_children = Column(Boolean, nullable=False, default=True)
    override_allowed = Column(Boolean, nullable=False, default=True)
    level_override = Column(String(20), nullable=True)
    display_order = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    taxonomy_node = relationship('PimTaxonomyNode', back_populates='attribute_configs')
    attribute = relationship('PimAttributeDefinition', back_populates='attribute_configs')
    default_scalar = relationship('PimTaxonomyDefaultScalar', back_populates='config', uselist=False, cascade='all, delete-orphan')
    default_refs = relationship('PimTaxonomyDefaultRef', back_populates='config', cascade='all, delete-orphan')

    def __init__(self, taxonomy_node_id, attribute_id, is_required=False,
                 inherit_to_children=True, override_allowed=True, level_override=None,
                 display_order=0, id=None, created_at=None, updated_at=None):
        self.id = id or _uuid()
        self.taxonomy_node_id = taxonomy_node_id
        self.attribute_id = attribute_id
        self.is_required = is_required
        self.inherit_to_children = inherit_to_children
        self.override_allowed = override_allowed
        self.level_override = level_override
        self.display_order = display_order
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()

    def __repr__(self):
        return f"<PimSpecificationConfig(id={self.id}, node={self.taxonomy_node_id}, attr={self.attribute_id})>"


class PimTaxonomyDefaultScalar(Base):
    __tablename__ = 'pim_taxonomy_default_scalar'
    __table_args__ = (
        UniqueConstraint('config_id', name='uq_pim_default_scalar_config'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    config_id = Column(String(36), ForeignKey('pim_specification_config.id', ondelete='CASCADE'), nullable=False, unique=True)
    default_text = Column(String(1000), nullable=True)
    default_number = Column(Numeric, nullable=True)
    default_boolean = Column(Boolean, nullable=True)
    default_date = Column(Date, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    config = relationship('PimSpecificationConfig', back_populates='default_scalar')

    def __init__(self, config_id, default_text=None, default_number=None,
                 default_boolean=None, default_date=None, id=None,
                 created_at=None, updated_at=None):
        self.id = id or _uuid()
        self.config_id = config_id
        self.default_text = default_text
        self.default_number = default_number
        self.default_boolean = default_boolean
        self.default_date = default_date
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()

    def __repr__(self):
        return f"<PimTaxonomyDefaultScalar(id={self.id}, config_id={self.config_id})>"


class PimTaxonomyDefaultRef(Base):
    __tablename__ = 'pim_taxonomy_default_ref'
    __table_args__ = (
        UniqueConstraint('config_id', 'ref_value_key', name='uq_pim_default_ref'),
        Index('idx_pim_tdr_config', 'config_id'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    config_id = Column(String(36), ForeignKey('pim_specification_config.id', ondelete='CASCADE'), nullable=False)
    ref_value_key = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    config = relationship('PimSpecificationConfig', back_populates='default_refs')

    def __init__(self, config_id, ref_value_key, id=None, created_at=None, updated_at=None):
        self.id = id or _uuid()
        self.config_id = config_id
        self.ref_value_key = ref_value_key
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()

    def __repr__(self):
        return f"<PimTaxonomyDefaultRef(id={self.id}, config_id={self.config_id}, ref_value_key={self.ref_value_key})>"


class PimResolvedSpecification(Base):
    __tablename__ = 'pim_resolved_specification'
    __table_args__ = (
        UniqueConstraint('taxonomy_node_id', 'attribute_id', name='uq_pim_resolved'),
        Index('idx_pim_rac_node', 'taxonomy_node_id'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    taxonomy_node_id = Column(String(36), nullable=False)
    attribute_id = Column(String(36), nullable=False)
    config_id = Column(String(36), ForeignKey('pim_specification_config.id', ondelete='CASCADE'), nullable=False)
    source_node_id = Column(String(36), nullable=False)
    is_required = Column(Boolean, nullable=False)
    display_order = Column(Integer, nullable=False, default=0)
    resolved_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # Relationships
    config = relationship('PimSpecificationConfig')

    def __init__(self, taxonomy_node_id, attribute_id, config_id, source_node_id,
                 is_required=False, display_order=0, id=None, resolved_at=None):
        self.id = id or _uuid()
        self.taxonomy_node_id = taxonomy_node_id
        self.attribute_id = attribute_id
        self.config_id = config_id
        self.source_node_id = source_node_id
        self.is_required = is_required
        self.display_order = display_order
        self.resolved_at = resolved_at or datetime.utcnow()

    def __repr__(self):
        return f"<PimResolvedSpecification(id={self.id}, node={self.taxonomy_node_id}, attr={self.attribute_id})>"


# ===========================================================================
# PYDANTIC BASE – Handles UUID-to-string coercion
# ===========================================================================
# ORM models use String(36) which returns strings in most cases,
# but psycopg2 can still return uuid.UUID objects in some edge cases.
# This base class auto-converts UUID objects to strings for safety.

class PimResponse(BaseModel):
    @field_validator('*', mode='before')
    @classmethod
    def _coerce_uuid(cls, v):
        if isinstance(v, _uuid_mod.UUID):
            return str(v)
        return v

    class Config:
        orm_mode = True
        from_attributes = True


# ===========================================================================
# PYDANTIC SCHEMAS – Language Ref
# ===========================================================================

class PimLanguageRefCreate(BaseModel):
    id: str
    language_name: str
    is_active: Optional[bool] = True
    created_by: Optional[str] = ''


class PimLanguageRefResponse(PimResponse):
    id: str
    language_name: str
    is_active: bool
    created_at: datetime


class PimLanguageRefUpdate(BaseModel):
    language_name: Optional[str] = None
    is_active: Optional[bool] = None


# ===========================================================================
# PYDANTIC SCHEMAS – Unit Ref
# ===========================================================================

class PimUnitRefCreate(BaseModel):
    name: str
    category: Optional[str] = None
    description: Optional[str] = None
    base_unit: Optional[str] = None
    to_base_factor: Optional[float] = None
    is_active: Optional[bool] = True
    created_by: Optional[str] = ''


class PimUnitRefResponse(PimResponse):
    name: str
    category: Optional[str]
    description: Optional[str]
    base_unit: Optional[str] = None
    to_base_factor: Optional[float] = None
    is_active: bool
    created_at: datetime


class PimUnitRefUpdate(BaseModel):
    category: Optional[str] = None
    description: Optional[str] = None
    base_unit: Optional[str] = None
    to_base_factor: Optional[float] = None
    is_active: Optional[bool] = None


# ===========================================================================
# PYDANTIC SCHEMAS – Taxonomy Node
# ===========================================================================

class PimTaxonomyNodeCreate(BaseModel):
    code: str
    label: str
    parent_id: Optional[str] = None
    display_order: Optional[int] = 0
    created_by: Optional[str] = ''


class PimTaxonomyNodeResponse(PimResponse):
    id: str
    code: str
    label: str
    parent_id: Optional[str]
    materialized_path: str
    level: int
    display_order: int
    is_active: bool
    created_at: datetime
    updated_at: datetime
    children: Optional[List['PimTaxonomyNodeResponse']] = []


class PimTaxonomyNodeUpdate(BaseModel):
    code: Optional[str] = None
    label: Optional[str] = None
    parent_id: Optional[str] = None
    display_order: Optional[int] = None
    is_active: Optional[bool] = None


class PimTaxonomyBulkCreateResponse(PimResponse):
    created: int
    nodes: List[PimTaxonomyNodeResponse]


# ===========================================================================
# PYDANTIC SCHEMAS – Attribute Definition
# ===========================================================================

class PimAttributeOptionCreate(BaseModel):
    label: str
    value_key: Optional[str] = None       # server-derives from label if absent
    display_order: Optional[int] = 0
    is_active: Optional[bool] = True


class PimAttributeOptionResponse(PimResponse):
    id: str
    attribute_id: str
    value_key: str
    label: str
    display_order: int
    is_active: bool


class PimAttributeOptionUpdate(BaseModel):
    label: Optional[str] = None
    display_order: Optional[int] = None
    is_active: Optional[bool] = None


class PimAttributeDefinitionCreate(BaseModel):
    code: str
    label: str
    data_type: str
    reference_entity_id: Optional[str] = None
    description: Optional[str] = None
    is_localizable: Optional[bool] = False
    level: Optional[str] = 'ALL'
    scope: Optional[str] = 'specifications'
    is_system: Optional[bool] = False
    is_identifier: Optional[bool] = False
    is_label: Optional[bool] = False
    group: Optional[str] = None
    display_order: Optional[int] = 0
    options: Optional[List[PimAttributeOptionCreate]] = None
    created_by: Optional[str] = ''


class PimAttributeDefinitionResponse(PimResponse):
    id: str
    code: str
    label: str
    data_type: str
    reference_entity_id: Optional[str]
    description: Optional[str]
    is_localizable: bool
    level: str
    scope: str = 'specifications'
    is_system: bool
    is_identifier: bool = False
    is_label: bool = False
    group: str = 'General'
    display_order: int = 0
    options: List[PimAttributeOptionResponse] = []
    created_at: datetime
    updated_at: datetime


class PimAttributeDefinitionEnrichedResponse(PimResponse):
    """Attribute definition with usage statistics for list views."""
    id: str
    code: str
    label: str
    data_type: str
    reference_entity_id: Optional[str]
    description: Optional[str]
    is_localizable: bool
    level: str
    scope: str = 'specifications'
    is_system: bool
    is_identifier: bool = False
    is_label: bool = False
    group: str = 'General'
    display_order: int = 0
    options: List[PimAttributeOptionResponse] = []
    created_at: datetime
    updated_at: datetime
    categories_count: int = 0
    products_count: int = 0
    assigned_products_count: int = 0
    coverage_pct: float = 0.0


class PimAttributeDefinitionListResponse(PimResponse):
    items: List[PimAttributeDefinitionEnrichedResponse]
    total: int
    page: int
    page_size: int


class PimAttributeDefinitionUpdate(BaseModel):
    code: Optional[str] = None
    label: Optional[str] = None
    data_type: Optional[str] = None
    reference_entity_id: Optional[str] = None
    description: Optional[str] = None
    is_localizable: Optional[bool] = None
    level: Optional[str] = None
    scope: Optional[str] = None
    is_system: Optional[bool] = None
    is_identifier: Optional[bool] = None
    is_label: Optional[bool] = None
    group: Optional[str] = None
    display_order: Optional[int] = None
    options: Optional[List[PimAttributeOptionCreate]] = None


class PimAttributeBulkCreateResponse(PimResponse):
    created: int
    attributes: List[PimAttributeDefinitionResponse]


# ===========================================================================
# PYDANTIC SCHEMAS – Taxonomy Attribute Config
# ===========================================================================

class PimSpecificationConfigCreate(BaseModel):
    taxonomy_node_id: str
    attribute_id: str
    is_required: Optional[bool] = False
    inherit_to_children: Optional[bool] = True
    override_allowed: Optional[bool] = True
    level_override: Optional[str] = None
    display_order: Optional[int] = 0
    created_by: Optional[str] = ''


class PimSpecificationConfigResponse(PimResponse):
    id: str
    taxonomy_node_id: str
    attribute_id: str
    is_required: bool
    inherit_to_children: bool
    override_allowed: bool
    level_override: Optional[str] = None
    display_order: int
    created_at: datetime
    updated_at: datetime


class PimSpecificationConfigUpdate(BaseModel):
    is_required: Optional[bool] = None
    inherit_to_children: Optional[bool] = None
    override_allowed: Optional[bool] = None
    level_override: Optional[str] = None
    display_order: Optional[int] = None


# ===========================================================================
# PYDANTIC SCHEMAS – Default Scalar
# ===========================================================================

class PimTaxonomyDefaultScalarCreate(BaseModel):
    default_text: Optional[str] = None
    default_number: Optional[float] = None
    default_boolean: Optional[bool] = None
    default_date: Optional[str] = None


class PimTaxonomyDefaultScalarResponse(PimResponse):
    id: str
    config_id: str
    default_text: Optional[str]
    default_number: Optional[float]
    default_boolean: Optional[bool]
    default_date: Optional[str]
    created_at: datetime
    updated_at: datetime


# ===========================================================================
# PYDANTIC SCHEMAS – Default Ref
# ===========================================================================

class PimTaxonomyDefaultRefCreate(BaseModel):
    ref_value_keys: List[str]


class PimTaxonomyDefaultRefResponse(PimResponse):
    id: str
    config_id: str
    ref_value_key: str
    created_at: datetime
    updated_at: datetime


# ===========================================================================
# PYDANTIC SCHEMAS – Resolved Attribute Config
# ===========================================================================

class PimResolvedSpecificationResponse(PimResponse):
    id: str
    taxonomy_node_id: str
    attribute_id: str
    config_id: str
    source_node_id: str
    is_required: bool
    display_order: int
    resolved_at: datetime


class PimResolvedSpecificationEnriched(PimResponse):
    """Enriched resolved config with attribute details and source node label (for MFE display)."""
    id: str
    taxonomy_node_id: str
    attribute_id: str
    config_id: str
    source_node_id: str
    is_required: bool
    display_order: int
    resolved_at: datetime
    # Enriched fields from JOINs
    attribute_code: str
    attribute_label: str
    attribute_data_type: str
    attribute_reference_entity_id: Optional[str] = None
    attribute_level: Optional[str] = None
    attribute_group: Optional[str] = 'Specifications'
    default_value: Optional[str] = None
    source_node_label: str
    override_allowed: Optional[bool] = True
    inherit_to_children: Optional[bool] = True


# ===========================================================================
# ENTITY CONFIGURATION – N-TIER HIERARCHY
# ===========================================================================

class PimEntityTier(Base):
    """
    Defines the product hierarchy tiers for this PIM deployment.
    Supports N-tier: customers choose their own levels.

    Examples:
      2-tier (default):  Product (level=0) → Item (level=1)
      3-tier (PUMA):     Product (level=0) → Variant (level=1) → SKU (level=2)
      4-tier (Amazon):   Brand Family (0) → Product Line (1) → Variant (2) → Sellable Unit (3)
    """
    __tablename__ = 'pim_entity_tier'
    __table_args__ = (
        UniqueConstraint('code', name='uq_pim_entity_tier_code'),
        UniqueConstraint('level', name='uq_pim_entity_tier_level'),
        Index('idx_pim_entity_tier_level', 'level'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    code = Column(String(50), nullable=False, unique=True)
    label = Column(String(255), nullable=False)
    level = Column(Integer, nullable=False)  # 0 = top tier, 1 = next, etc.
    parent_tier_id = Column(String(36), ForeignKey('pim_entity_tier.id'), nullable=True)
    is_leaf = Column(Boolean, nullable=False, default=False)  # True = lowest tier (items/SKUs)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    parent_tier = relationship('PimEntityTier', remote_side=[id])

    def __init__(self, code, label, level, parent_tier_id=None, is_leaf=False, id=None):
        self.id = id or _uuid()
        self.code = code
        self.label = label
        self.level = level
        self.parent_tier_id = parent_tier_id
        self.is_leaf = is_leaf
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()

    def __repr__(self):
        return f"<PimEntityTier(code={self.code}, label={self.label}, level={self.level})>"


class PimEntityTierCreate(BaseModel):
    code: str
    label: str
    level: int
    parent_tier_id: Optional[str] = None
    is_leaf: bool = False


class PimEntityTierResponse(PimResponse):
    id: str
    code: str
    label: str
    level: int
    parent_tier_id: Optional[str] = None
    is_leaf: bool
    created_at: datetime
    updated_at: datetime


# ===========================================================================
# LAYER 3b – ASSORTMENTS (steward ownership of categories)
# ===========================================================================

class PimAssortment(Base):
    __tablename__ = 'pim_assortment'
    __table_args__ = (
        UniqueConstraint('taxonomy_node_id', 'steward_user_id', name='uq_pim_assortment_node_steward'),
        Index('idx_pim_assortment_steward', 'steward_user_id'),
        Index('idx_pim_assortment_node', 'taxonomy_node_id'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    taxonomy_node_id = Column(String(36), ForeignKey('pim_taxonomy_node.id', ondelete='CASCADE'), nullable=False)
    steward_user_id = Column(String(255), nullable=False)
    steward_display_name = Column(String(255), nullable=True)
    name = Column(String(255), nullable=True)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    taxonomy_node = relationship('PimTaxonomyNode')

    def __init__(self, taxonomy_node_id, steward_user_id, steward_display_name=None,
                 name=None, description=None, id=None):
        self.id = id or _uuid()
        self.taxonomy_node_id = taxonomy_node_id
        self.steward_user_id = steward_user_id
        self.steward_display_name = steward_display_name
        self.name = name
        self.description = description
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()

    def __repr__(self):
        return f"<PimAssortment(id={self.id}, node={self.taxonomy_node_id}, steward={self.steward_user_id})>"


# ===========================================================================
# LAYER 4 – PRODUCT TABLES
# ===========================================================================

class PimEntity(Base):
    """Product entity — structural fields only.

    All product data (sku, name, ean, brand, etc.) lives in EAV value tables.
    The identifier and label are determined by is_identifier/is_label flags
    on pim_attribute_definition. The pim_entity_flat table denormalizes these
    for fast catalog reads.
    """
    __tablename__ = 'pim_entity'
    __table_args__ = (
        # entity_type_id validated against pim_entity_tier in application code (supports N-tier)
        Index('idx_pim_entity_taxonomy', 'taxonomy_node_id'),
        Index('idx_pim_entity_parent', 'parent_id'),
        Index('idx_pim_entity_type', 'entity_type_id'),
        Index('idx_pim_entity_status', 'status'),
        Index('idx_pim_entity_promoted', 'promoted'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    entity_type_id = Column(String(10), nullable=False)
    taxonomy_node_id = Column(String(36), ForeignKey('pim_taxonomy_node.id'), nullable=False)
    parent_id = Column(String(36), ForeignKey('pim_entity.id'), nullable=True)
    status = Column(String(50), nullable=False, default='Draft')
    active = Column(Boolean, nullable=False, default=True)
    promoted = Column(Boolean, nullable=False, default=False)
    published_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    taxonomy_node = relationship('PimTaxonomyNode')
    parent = relationship('PimEntity', remote_side=[id], back_populates='children')
    children = relationship('PimEntity', back_populates='parent')

    def __init__(self, entity_type_id, taxonomy_node_id,
                 parent_id=None, status='Draft', active=True, promoted=False,
                 published_at=None, id=None, created_at=None, updated_at=None):
        self.id = id or _uuid()
        self.entity_type_id = entity_type_id
        self.taxonomy_node_id = taxonomy_node_id
        self.parent_id = parent_id
        self.status = status
        self.active = active
        self.promoted = promoted
        self.published_at = published_at
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()

    def __repr__(self):
        return f"<PimEntity(id={self.id}, type={self.entity_type_id})>"


class PimEntityFlat(Base):
    """Denormalized read-only table for fast catalog list views.
    Populated by incremental refresh after each write.
    The identifier and label columns are populated from whichever attributes
    have is_identifier=True and is_label=True on pim_attribute_definition.
    """
    __tablename__ = 'pim_entity_flat'
    __table_args__ = (
        Index('idx_pef_identifier', 'identifier'),
        Index('idx_pef_label', 'label'),
        Index('idx_pef_status', 'status'),
        Index('idx_pef_type', 'entity_type_id'),
        Index('idx_pef_taxonomy', 'taxonomy_node_id'),
        Index('idx_pef_parent', 'parent_id'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True)
    entity_type_id = Column(String(10), nullable=False)
    taxonomy_node_id = Column(String(36), nullable=True)
    parent_id = Column(String(36), nullable=True)
    status = Column(String(50), nullable=True)
    active = Column(Boolean, nullable=True)
    promoted = Column(Boolean, nullable=True)
    published_at = Column(DateTime, nullable=True)
    identifier = Column(String(255), nullable=True)
    label = Column(String(255), nullable=True)
    category_label = Column(String(255), nullable=True)
    category_path = Column(Text, nullable=True)
    child_count = Column(Integer, nullable=True, default=0)
    created_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, nullable=True)

    def __repr__(self):
        return f"<PimEntityFlat(id={self.id}, identifier={self.identifier}, label={self.label})>"


# ===========================================================================
# LAYER 5 – TYPED VALUE TABLES
# ===========================================================================

class PimValueText(Base):
    __tablename__ = 'pim_value_text'
    __table_args__ = (
        UniqueConstraint('product_id', 'attribute_id', 'locale', name='uq_pim_vt'),
        CheckConstraint("source IN ('INHERITED', 'USER_SET', 'PIPELINE', 'IMPORT')", name='chk_pim_vt_source'),
        Index('idx_pim_vt_product', 'product_id'),
        Index('idx_pim_vt_attr', 'attribute_id'),
        Index('idx_pim_vt_locale', 'locale'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    product_id = Column(String(36), ForeignKey('pim_entity.id', ondelete='CASCADE'), nullable=False)
    attribute_id = Column(String(36), ForeignKey('pim_attribute_definition.id'), nullable=False)
    value = Column(String, nullable=False)
    locale = Column(String(10), nullable=False, default='')
    source = Column(String(50), nullable=False, default='USER_SET')
    version = Column(Integer, nullable=False, default=1)
    changed_by = Column(String(255), nullable=True)
    translation_model = Column(String(255), nullable=True)
    translation_source_locale = Column(String(10), nullable=True)
    translated_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    product = relationship('PimEntity')
    attribute = relationship('PimAttributeDefinition')

    def __repr__(self):
        return f"<PimValueText(product={self.product_id}, attr={self.attribute_id}, locale={self.locale})>"


class PimValueNumber(Base):
    __tablename__ = 'pim_value_number'
    __table_args__ = (
        UniqueConstraint('product_id', 'attribute_id', 'locale', 'currency', 'price_type', 'territory', name='uq_pim_vn'),
        CheckConstraint("source IN ('INHERITED', 'USER_SET', 'PIPELINE', 'IMPORT')", name='chk_pim_vn_source'),
        Index('idx_pim_vn_product', 'product_id'),
        Index('idx_pim_vn_attr', 'attribute_id'),
        Index('idx_pim_vn_locale', 'locale'),
        Index('idx_pim_vn_currency', 'currency'),
        Index('idx_pim_vn_price_type', 'price_type'),
        Index('idx_pim_vn_territory', 'territory'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    product_id = Column(String(36), ForeignKey('pim_entity.id', ondelete='CASCADE'), nullable=False)
    attribute_id = Column(String(36), ForeignKey('pim_attribute_definition.id'), nullable=False)
    value = Column(Numeric, nullable=False)
    locale = Column(String(10), nullable=False, default='')
    currency = Column(String(10), nullable=False, default='')
    price_type = Column(String(50), nullable=False, default='')
    territory = Column(String(50), nullable=False, default='')
    valid_from = Column(Date, nullable=True)
    valid_to = Column(Date, nullable=True)
    tax_rate = Column(Numeric, nullable=True)
    source = Column(String(50), nullable=False, default='USER_SET')
    version = Column(Integer, nullable=False, default=1)
    changed_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    product = relationship('PimEntity')
    attribute = relationship('PimAttributeDefinition')

    def __repr__(self):
        return f"<PimValueNumber(product={self.product_id}, attr={self.attribute_id}, locale={self.locale})>"


class PimValueBoolean(Base):
    __tablename__ = 'pim_value_boolean'
    __table_args__ = (
        UniqueConstraint('product_id', 'attribute_id', 'locale', name='uq_pim_vb'),
        CheckConstraint("source IN ('INHERITED', 'USER_SET', 'PIPELINE', 'IMPORT')", name='chk_pim_vb_source'),
        Index('idx_pim_vb_product', 'product_id'),
        Index('idx_pim_vb_attr', 'attribute_id'),
        Index('idx_pim_vb_locale', 'locale'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    product_id = Column(String(36), ForeignKey('pim_entity.id', ondelete='CASCADE'), nullable=False)
    attribute_id = Column(String(36), ForeignKey('pim_attribute_definition.id'), nullable=False)
    value = Column(Boolean, nullable=False)
    locale = Column(String(10), nullable=False, default='')
    source = Column(String(50), nullable=False, default='USER_SET')
    version = Column(Integer, nullable=False, default=1)
    changed_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    product = relationship('PimEntity')
    attribute = relationship('PimAttributeDefinition')

    def __repr__(self):
        return f"<PimValueBoolean(product={self.product_id}, attr={self.attribute_id}, locale={self.locale})>"


class PimValueDate(Base):
    __tablename__ = 'pim_value_date'
    __table_args__ = (
        UniqueConstraint('product_id', 'attribute_id', 'locale', name='uq_pim_vd'),
        CheckConstraint("source IN ('INHERITED', 'USER_SET', 'PIPELINE', 'IMPORT')", name='chk_pim_vd_source'),
        Index('idx_pim_vd_product', 'product_id'),
        Index('idx_pim_vd_attr', 'attribute_id'),
        Index('idx_pim_vd_locale', 'locale'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    product_id = Column(String(36), ForeignKey('pim_entity.id', ondelete='CASCADE'), nullable=False)
    attribute_id = Column(String(36), ForeignKey('pim_attribute_definition.id'), nullable=False)
    value = Column(Date, nullable=False)
    locale = Column(String(10), nullable=False, default='')
    source = Column(String(50), nullable=False, default='USER_SET')
    version = Column(Integer, nullable=False, default=1)
    changed_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    product = relationship('PimEntity')
    attribute = relationship('PimAttributeDefinition')

    def __repr__(self):
        return f"<PimValueDate(product={self.product_id}, attr={self.attribute_id}, locale={self.locale})>"


class PimValueSelect(Base):
    __tablename__ = 'pim_value_select'
    __table_args__ = (
        UniqueConstraint('product_id', 'attribute_id', 'locale', name='uq_pim_vs'),
        CheckConstraint("source IN ('INHERITED', 'USER_SET', 'PIPELINE', 'IMPORT')", name='chk_pim_vs_source'),
        # Hard composite FK: every stored select value must reference a defined option.
        # ON UPDATE CASCADE propagates value_key renames; ON DELETE RESTRICT blocks deleting
        # an option that products still use (friendly pre-check lives in the service layer).
        ForeignKeyConstraint(
            ['attribute_id', 'ref_value_key'],
            ['pim_attribute_option.attribute_id', 'pim_attribute_option.value_key'],
            name='fk_pim_vs_option', onupdate='CASCADE', ondelete='RESTRICT',
        ),
        Index('idx_pim_vs_product', 'product_id'),
        Index('idx_pim_vs_attr', 'attribute_id'),
        Index('idx_pim_vs_ref', 'ref_value_key'),
        Index('idx_pim_vs_locale', 'locale'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    product_id = Column(String(36), ForeignKey('pim_entity.id', ondelete='CASCADE'), nullable=False)
    attribute_id = Column(String(36), ForeignKey('pim_attribute_definition.id'), nullable=False)
    ref_value_key = Column(String(255), nullable=False)
    locale = Column(String(10), nullable=False, default='')
    source = Column(String(50), nullable=False, default='USER_SET')
    version = Column(Integer, nullable=False, default=1)
    changed_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    product = relationship('PimEntity')
    attribute = relationship('PimAttributeDefinition')

    def __repr__(self):
        return f"<PimValueSelect(product={self.product_id}, attr={self.attribute_id}, key={self.ref_value_key})>"


class PimValueMultiselect(Base):
    __tablename__ = 'pim_value_multiselect'
    __table_args__ = (
        UniqueConstraint('product_id', 'attribute_id', 'locale', 'ref_value_key', name='uq_pim_vm'),
        CheckConstraint("source IN ('INHERITED', 'USER_SET', 'PIPELINE', 'IMPORT')", name='chk_pim_vm_source'),
        # Hard composite FK — same guarantee as pim_value_select (see fk_pim_vs_option).
        ForeignKeyConstraint(
            ['attribute_id', 'ref_value_key'],
            ['pim_attribute_option.attribute_id', 'pim_attribute_option.value_key'],
            name='fk_pim_vm_option', onupdate='CASCADE', ondelete='RESTRICT',
        ),
        Index('idx_pim_vm_product', 'product_id'),
        Index('idx_pim_vm_attr', 'attribute_id'),
        Index('idx_pim_vm_ref', 'ref_value_key'),
        Index('idx_pim_vm_locale', 'locale'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    product_id = Column(String(36), ForeignKey('pim_entity.id', ondelete='CASCADE'), nullable=False)
    attribute_id = Column(String(36), ForeignKey('pim_attribute_definition.id'), nullable=False)
    ref_value_key = Column(String(255), nullable=False)
    locale = Column(String(10), nullable=False, default='')
    source = Column(String(50), nullable=False, default='USER_SET')
    version = Column(Integer, nullable=False, default=1)
    changed_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    product = relationship('PimEntity')
    attribute = relationship('PimAttributeDefinition')

    def __repr__(self):
        return f"<PimValueMultiselect(product={self.product_id}, attr={self.attribute_id}, key={self.ref_value_key})>"


class PimValueReference(Base):
    """Stores values for SELECT/MULTISELECT attributes that reference an RDM table.
    Each row links a product+attribute to a specific row (ref_id) in a reference table (ref_table).
    For MULTISELECT, multiple rows exist per product+attribute (one per selected option).
    """
    __tablename__ = 'pim_value_reference'
    __table_args__ = (
        UniqueConstraint('product_id', 'attribute_id', 'locale', 'ref_table', 'ref_id', name='uq_pim_vr'),
        CheckConstraint("source IN ('INHERITED', 'USER_SET', 'PIPELINE', 'IMPORT')", name='chk_pim_vr_source'),
        Index('idx_pim_vr_product', 'product_id'),
        Index('idx_pim_vr_attr', 'attribute_id'),
        Index('idx_pim_vr_ref', 'ref_table', 'ref_id'),
        Index('idx_pim_vr_locale', 'locale'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    product_id = Column(String(36), ForeignKey('pim_entity.id', ondelete='CASCADE'), nullable=False)
    attribute_id = Column(String(36), ForeignKey('pim_attribute_definition.id'), nullable=False)
    ref_table = Column(String(255), nullable=False)     # e.g. 'color_master'
    ref_id = Column(String(36), nullable=False)          # id in the reference table (string to support both int and uuid PKs)
    locale = Column(String(10), nullable=False, default='')
    source = Column(String(50), nullable=False, default='USER_SET')
    version = Column(Integer, nullable=False, default=1)
    changed_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    product = relationship('PimEntity')
    attribute = relationship('PimAttributeDefinition')

    def __repr__(self):
        return f"<PimValueReference(product={self.product_id}, attr={self.attribute_id}, table={self.ref_table}, ref_id={self.ref_id})>"


# ===========================================================================
# PYDANTIC SCHEMAS – Assortment
# ===========================================================================

class PimAssortmentCreate(BaseModel):
    taxonomy_node_id: str
    steward_user_id: str
    steward_display_name: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None


class PimAssortmentUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    steward_user_id: Optional[str] = None
    steward_display_name: Optional[str] = None


class PimAssortmentResponse(PimResponse):
    id: str
    taxonomy_node_id: str
    steward_user_id: str
    steward_display_name: Optional[str]
    name: Optional[str]
    description: Optional[str]
    created_at: datetime
    updated_at: datetime


class PimAssortmentEnrichedResponse(PimResponse):
    """Assortment with category details and completeness for dashboard cards."""
    id: str
    taxonomy_node_id: str
    steward_user_id: str
    steward_display_name: Optional[str]
    name: Optional[str]
    description: Optional[str]
    category_label: Optional[str] = None
    category_path: Optional[str] = None
    product_count: int = 0
    avg_completeness: float = 0.0
    created_at: datetime
    updated_at: datetime


# PYDANTIC SCHEMAS – Product
# ===========================================================================

class PimEntityCreate(BaseModel):
    """Create a product entity. sku/name/ean are now EAV attributes — pass them via
    attribute values after creation, or include in bulk import payload."""
    entity_type_id: str
    taxonomy_node_id: Optional[str] = None  # Optional for child products — inherited from parent
    parent_id: Optional[str] = None
    status: Optional[str] = 'Draft'
    active: Optional[bool] = True
    created_by: Optional[str] = ''
    # Convenience fields — service writes these as EAV attribute values
    identifier_value: Optional[str] = None  # value for the is_identifier attribute (e.g., sku)
    label_value: Optional[str] = None       # value for the is_label attribute (e.g., name)


class PimEntityUpdate(BaseModel):
    taxonomy_node_id: Optional[str] = None
    status: Optional[str] = None
    active: Optional[bool] = None


class PimPublishRequest(BaseModel):
    product_ids: List[str]


class PimEntityResponse(PimResponse):
    """Response includes identifier and label denormalized from EAV for display."""
    id: str
    entity_type_id: str
    identifier: Optional[str] = None   # value of the is_identifier attribute (e.g., sku)
    label: Optional[str] = None        # value of the is_label attribute (e.g., name)
    taxonomy_node_id: str
    parent_id: Optional[str]
    status: str
    active: bool
    promoted: bool = False
    published_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime


class PimEntityDetailResponse(PimEntityResponse):
    children: Optional[List[PimEntityResponse]] = []
    completeness: Optional[float] = None


class PimEntityListResponse(PimResponse):
    items: List[PimEntityResponse]
    total: int
    page: int
    page_size: int


class PimEntityEnrichedResponse(PimResponse):
    """Product with enrichment fields for list views."""
    id: str
    entity_type_id: str
    identifier: Optional[str] = None
    label: Optional[str] = None
    taxonomy_node_id: str
    parent_id: Optional[str]
    status: str
    active: bool
    promoted: bool = False
    published_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    category_label: Optional[str] = None
    category_path: Optional[str] = None
    child_count: Optional[int] = None
    completeness: Optional[float] = None
    attributes: Optional[dict] = None  # { code: { "value": "...", "source": "..." } }


class PimEntityEnrichedListResponse(PimResponse):
    items: List[PimEntityEnrichedResponse]
    total: int
    page: int
    page_size: int
    entity_types: Optional[List[str]] = None


class PimItemEnrichedResponse(PimResponse):
    """SKU/Item with enrichment fields for the SKU tab."""
    id: str
    entity_type_id: str
    identifier: Optional[str] = None
    label: Optional[str] = None
    taxonomy_node_id: str
    parent_id: Optional[str]
    status: str
    active: bool
    promoted: bool = False
    published_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    completeness: Optional[float] = None
    attributes: Optional[dict] = None  # { code: { "value": "...", "source": "..." } }


# ===========================================================================
# PYDANTIC SCHEMAS – Attribute Values (Unified Batch Pattern)
# ===========================================================================

class PimAttributeValueWrite(BaseModel):
    attribute_id: str
    value: Optional[str] = None
    ref_value_key: Optional[str] = None
    ref_value_keys: Optional[List[str]] = None
    locale: Optional[str] = ''
    currency: Optional[str] = ''
    price_type: Optional[str] = ''
    territory: Optional[str] = ''
    valid_from: Optional[str] = None
    valid_to: Optional[str] = None
    tax_rate: Optional[float] = None
    source: Optional[str] = 'USER_SET'
    changed_by: Optional[str] = None
    translation_model: Optional[str] = None
    translation_source_locale: Optional[str] = None


class PimBatchValueWriteRequest(BaseModel):
    values: List[PimAttributeValueWrite]


class PimAttributeValueResponse(PimResponse):
    id: str
    product_id: str
    attribute_id: str
    data_type: str
    value: Optional[str] = None
    ref_value_key: Optional[str] = None
    ref_value_keys: Optional[List[str]] = None
    locale: Optional[str] = ''
    currency: Optional[str] = ''
    price_type: Optional[str] = ''
    territory: Optional[str] = ''
    valid_from: Optional[str] = None
    valid_to: Optional[str] = None
    source: str
    version: int
    changed_by: Optional[str]


class PimBatchValueResponse(PimResponse):
    product_id: str
    values: List[PimAttributeValueResponse]
    completeness: Optional[float] = None


# ===========================================================================
# BULK IMPORT  (SCRUM-1790)
# ===========================================================================

class PimImportNodeValue(BaseModel):
    """A single attribute value to write during import."""
    attribute_id: str
    value: Optional[str] = None
    source: Optional[str] = 'IMPORT'


class PimImportNode(BaseModel):
    """A node in the import hierarchy (product, variant, item, etc.).
    identifier_value and label_value are convenience fields — the service
    resolves the correct attribute_id from is_identifier/is_label flags."""
    key: str                          # CSV row group key (for dedup / error reporting)
    tier_code: str                    # entity_type_id (from pim_entity_tier)
    identifier_value: Optional[str] = None   # value for the is_identifier attribute
    label_value: Optional[str] = None        # value for the is_label attribute
    status: Optional[str] = 'Draft'
    taxonomy_node_id: Optional[str] = None
    values: Optional[List[PimImportNodeValue]] = []
    children: Optional[List['PimImportNode']] = []


class PimBulkImportRequest(BaseModel):
    """Full hierarchy payload for bulk product import."""
    nodes: List[PimImportNode]        # root-level nodes (products)
    identifier_attribute_id: Optional[str] = None  # attribute to flag as is_identifier
    label_attribute_id: Optional[str] = None        # attribute to flag as is_label


class PimBulkImportResponse(BaseModel):
    """Response from bulk import."""
    created: dict                     # tier_code -> count
    errors: List[str]
    # SELECT/MULTISELECT values whose option was not defined (strict — rejected, not auto-created).
    # Each: {attribute_id, attribute_code, product_id, value, value_key, reason}
    rejected_values: List[dict] = []


# ===========================================================================
# BULK TAXONOMY IMPORT  (SCRUM-1790)
# ===========================================================================

class PimTaxonomyImportBinding(BaseModel):
    """An attribute binding to create during taxonomy import."""
    category_code: str
    attribute_code: str
    is_required: Optional[bool] = False
    inherit_to_children: Optional[bool] = True


class PimTaxonomyImportAttribute(BaseModel):
    """An attribute definition to create during taxonomy import."""
    code: str
    label: str
    data_type: Optional[str] = 'TEXT'
    level: Optional[str] = 'ALL'
    scope: Optional[str] = 'specifications'
    group: Optional[str] = None
    display_order: Optional[int] = 0
    description: Optional[str] = None
    reference_entity_id: Optional[str] = None
    # SELECT/MULTISELECT option catalog seeded from the spec CSV "Values" column.
    # Each item may carry an explicit value_key ('KEY:Label') or just a label (slugified).
    options: Optional[List[PimAttributeOptionCreate]] = None


class PimTaxonomyImportNode(BaseModel):
    """A taxonomy node to create during import."""
    code: str
    label: str
    parent_code: Optional[str] = None


class PimTaxonomyBulkImportRequest(BaseModel):
    """Full taxonomy import payload — nodes, attributes, and bindings."""
    nodes: List[PimTaxonomyImportNode]
    attributes: Optional[List[PimTaxonomyImportAttribute]] = []
    bindings: Optional[List[PimTaxonomyImportBinding]] = []


class PimTaxonomyBulkImportResponse(BaseModel):
    """Response from bulk taxonomy import."""
    nodes_created: int
    attributes_created: int
    bindings_created: int
    errors: List[str]

