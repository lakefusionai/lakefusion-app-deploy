import traceback,json
from typing import Optional
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from lakefusion_utility.models.integration_hub import Integration_Hub,IntegrationHub_Backup
from lakefusion_utility.models.databricks_model import Model_Databricks_Entity_Search_Job
from fastapi import HTTPException, status
from lakefusion_utility.utils.app_db import db_commit_auto_rollback  # Import the db_commit_auto_rollback function
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.services.model_experiment_service import ExperimentService
from lakefusion_utility.services.entity_service import EntityService
from lakefusion_utility.models.entity import Entity, EntityAttributes
from lakefusion_utility.utils.databricks_util import DatabricksJobManager,CatalogService, get_resource_tags
from lakefusion_utility.utils.databricks_util import DatabricksJobManager,DatabricksDashboard,DataSetSQLService,VectorSearchService
from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
from databricks.sdk.service.jobs import Task, NotebookTask, RunIf, Source, CronSchedule,TaskDependency,ConditionTask,ConditionTaskOp,JobEmailNotifications,JobParameter,PauseStatus
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.lf_utils import get_version_info
from lakefusion_utility.utils.notebook_path_utils import get_notebook_folder

# Set up logging
app_logger = get_logger(__name__)

DEFAULT_CRON = "0 0 0 * * ?"

def compare_versions(version1: str, version2: str) -> int:
    """
    Compare two version strings.
    Returns:
        -1 if version1 < version2
         0 if version1 == version2
         1 if version1 > version2
    """
    if not version1:
        version1 = "1.0.0"
    if not version2:
        version2 = "1.0.0"
    
    v1_parts = [int(x) for x in version1.split('.')]
    v2_parts = [int(x) for x in version2.split('.')]
    
    # Pad shorter version with zeros
    while len(v1_parts) < len(v2_parts):
        v1_parts.append(0)
    while len(v2_parts) < len(v1_parts):
        v2_parts.append(0)
    
    for i in range(len(v1_parts)):
        if v1_parts[i] < v2_parts[i]:
            return -1
        elif v1_parts[i] > v2_parts[i]:
            return 1
    return 0

class Integration_HubService:
    def __init__(self, db: Session):
        """Initializes the entityService with a database session.

        Args:
            db: SQLAlchemy session object.
        """
        self.db = db
        self.db_config_service = DBConfigPropertiesService(db=self.db)
        self.notebook_path=self.db_config_service.getDBConfigProperties(key="notebook_path")

    def _get_secret_scope_name(self) -> str:
        """Get secret scope name from db_config_properties, default to 'lakefusion'."""
        try:
            return self.db_config_service.getDBConfigProperties('secret_scope_name', required=False) or 'lakefusion'
        except Exception:
            return 'lakefusion'

    def _create_schedule(self, quartz_cron_expression: str, force_pause: bool = False) -> CronSchedule:
        """
        Creates a CronSchedule. If no cron expression provided, uses default with PAUSED status.
        
        Args:
            quartz_cron_expression: The cron expression string
            force_pause: If True, always pause regardless of cron expression
        
        Returns:
            CronSchedule object
        """
        if quartz_cron_expression and quartz_cron_expression.strip():
            return CronSchedule(
                quartz_cron_expression=quartz_cron_expression,
                timezone_id='UTC',
                pause_status=PauseStatus.PAUSED if force_pause else PauseStatus.UNPAUSED
            )
        else:
            return CronSchedule(
                quartz_cron_expression=DEFAULT_CRON,
                timezone_id='UTC',
                pause_status=PauseStatus.PAUSED
            )

    PIM_SENTINEL_ID = -1

    def _ensure_pim_sentinel_model(self, entity_id: int):
        """Create the PIM_PLACEHOLDER sentinel model_experiments row if absent.

        PIM integration_hub tasks reference modelid=-1 (sentinel) instead of a real
        model. The row's entity_id FK is satisfied by the task's own entity; the value
        is never read for PIM tasks. Idempotent and dialect-agnostic; the IntegrityError
        guard handles a concurrent create that inserted the sentinel first.
        """
        from sqlalchemy import text
        from sqlalchemy.exc import IntegrityError
        exists = self.db.execute(text(
            "SELECT 1 FROM model_experiments WHERE id = :id"
        ), {"id": self.PIM_SENTINEL_ID}).scalar()
        if exists:
            return
        try:
            self.db.execute(text(
                "INSERT INTO model_experiments "
                "(id, entity_id, status, modelname, description, "
                " llm_model_source, llm_model, embedding_model_source, embedding_model, "
                " config_thresold, created_at, created_by, vs_endpoint, attributes, max_potential_matches) "
                "VALUES "
                "(:id, :eid, 'PLACEHOLDER', 'PIM_PLACEHOLDER', 'Sentinel for PIM tasks', "
                " 'none', '{}', 'none', '{}', '{}', CURRENT_TIMESTAMP, 'system', 'none', '{}', 0)"
            ), {"id": self.PIM_SENTINEL_ID, "eid": entity_id})
            self.db.commit()
            app_logger.info(f"Created PIM_PLACEHOLDER sentinel model (entity_id={entity_id})")
        except IntegrityError:
            self.db.rollback()
            app_logger.info("PIM_PLACEHOLDER sentinel model already present (concurrent insert)")

    def create_integration_hub(self, integration_hub_create, token):
        """
        Creates a new Integration Hub record and its associated Databricks job.
        """
        hub_id = None
        
        try:
            app_logger.info(f"Creating Integration Hub with data: {integration_hub_create}")
            
            # Get the data as dict
            create_data = integration_hub_create.dict()

            merged_cron = create_data.pop('merged_quartz_cron_expression', None)
            
            # If merged mode and merged_cron provided, ensure both cron expressions are set
            if create_data.get('pipeline_mode') == 'merged' and merged_cron:
                create_data['traditional_quartz_cron_expression'] = merged_cron
                create_data['golden_deduplication_quartz_cron_expression'] = merged_cron
            
            # PIM tasks reference the PIM_PLACEHOLDER sentinel model (modelid=-1).
            # Ensure it exists before insert, or the modelid FK fails on a clean DB.
            if create_data.get('task_type') == 'pim':
                self._ensure_pim_sentinel_model(create_data.get('entity_id'))

            # Create the database object with cleaned data
            db_integration_hub = Integration_Hub(**create_data)

            self.db.add(db_integration_hub)
            self.db.commit()  # <-- COMMIT FIRST to persist the record
            
            hub_id = db_integration_hub.id
            app_logger.info(f"Integration Hub record created with id: {hub_id}")
            
            # PIM tasks only need the DB record — no Databricks jobs or volume folders
            if db_integration_hub.task_type == 'pim':
                from sqlalchemy.orm import joinedload
                created_hub = (
                    self.db.query(Integration_Hub)
                    .options(joinedload(Integration_Hub.entity))
                    .filter(Integration_Hub.id == hub_id)
                    .first()
                )
                # Prevent lazy-load of the placeholder model_experiment during serialization
                created_hub.model_experiment = None
                app_logger.info(f"PIM Integration Hub created successfully with id: {created_hub.id}")
                return created_hub

            # Store values we need
            entity_id = db_integration_hub.entity_id
            modelid = db_integration_hub.modelid
            to_emails = db_integration_hub.to_emails or []
            traditional_cron = db_integration_hub.traditional_quartz_cron_expression
            golden_cron = db_integration_hub.golden_deduplication_quartz_cron_expression
            created_by = db_integration_hub.created_by
            task_name = db_integration_hub.task_name
            is_traditional_pipeline = db_integration_hub.is_traditional_pipeline
            is_golden_deduplication_pipeline = db_integration_hub.is_golden_deduplication_pipeline
            pipeline_mode = create_data.get('pipeline_mode', 'separate')

            # Now do the external operations
            experiment_service = ExperimentService(self.db)
            create_volume_folder = CatalogService(token, self.db)
            folder_path = create_volume_folder.create_volume_folder(entity_id, 'prod')

            # Get entity and model data
            entity_service = EntityService(self.db)
            entity_data = entity_service.get_full_entity_by_id(entity_id).dict()
            model_data = experiment_service.get_model(modelid).dict()

            # Upload files
            create_volume_folder.upload_data_as_json(folder_path, 'entity.json', entity_data)
            create_volume_folder.upload_data_as_json(folder_path, 'model.json', model_data)

            # Get required config
            lakefusion_spn = (
                self.db.query(DBConfigProperties)
                .filter(DBConfigProperties.config_key == "lakefusion_spn")
                .first()
                .config_value
            )

            job_service = DatabricksJobManager(token)

            # Check if MDM restructuring feature is enabled
            integration_hub_enabled = FeatureFlagService._is_feature_flag_enabled(
                self.db,
                'MDM_RESTRUCTURING'
            )

            # Variables to store job IDs
            job_id_1 = None
            job_id_2 = None

            if integration_hub_enabled and pipeline_mode == 'merged':
                # MERGED MODE: Create single job with both pipelines
                task_list_response = self.create_tasks_and_job_merged_pipeline(
                    entity_id,
                    modelid,
                    to_emails,
                    traditional_cron,
                    created_by
                )

                job_create_response = job_service.create_job(
                    task_name,
                    task_list_response[0],
                    tasks_list=task_list_response[1],
                    job_parameters=task_list_response[2],
                    schedule=task_list_response[3],
                    email_notifcations=task_list_response[4],
                    RunAs=lakefusion_spn
                )

                job_id_1 = str(job_create_response) if job_create_response else None

            else:
                # Determine which pipeline creation method to use based on feature flag
                if integration_hub_enabled:
                    create_traditional = self.create_tasks_and_job_integration
                    create_golden = self.create_tasks_and_job_golden_dedup_integration
                else:
                    create_traditional = self.create_tasks_and_job_traditional
                    # Note: golden_deduplication needs schedule_status param
                    create_golden = None  # Handle separately below

                # Create traditional/matching pipeline job
                if is_traditional_pipeline:
                    task_list_response = create_traditional(
                        entity_id,
                        modelid,
                        to_emails,
                        traditional_cron,
                        created_by
                    )

                    job_create_response = job_service.create_job(
                        task_name,
                        task_list_response[0],
                        tasks_list=task_list_response[1],
                        job_parameters=task_list_response[2],
                        schedule=task_list_response[3],
                        email_notifcations=task_list_response[4],
                        RunAs=lakefusion_spn
                    )

                    job_id_1 = str(job_create_response) if job_create_response else None

                # Create golden deduplication job
                if is_golden_deduplication_pipeline:
                    if integration_hub_enabled:
                        task_list_response = self.create_tasks_and_job_golden_dedup_integration(
                            entity_id,
                            modelid,
                            to_emails,
                            golden_cron,
                            created_by,
                            schedule_status="UNPAUSED"
                        )
                    else:
                        # Traditional method requires schedule_status
                        schedule_status = "UNPAUSED" if is_golden_deduplication_pipeline else "PAUSED"
                        task_list_response = self.create_tasks_and_job_golden_deduplication(
                            entity_id,
                            modelid,
                            to_emails,
                            golden_cron,
                            created_by,
                            schedule_status
                        )

                    job_create_response = job_service.create_job(
                        f"Golden_Deduplication_{task_name}",
                        task_list_response[0],
                        tasks_list=task_list_response[1],
                        job_parameters=task_list_response[2],
                        schedule=task_list_response[3],
                        email_notifcations=task_list_response[4],
                        RunAs=lakefusion_spn
                    )

                    job_id_2 = str(job_create_response) if job_create_response else None

            # Update job IDs
            self.db.query(Integration_Hub).filter(Integration_Hub.id == hub_id).update(
                {"job_id_1": job_id_1, "job_id_2": job_id_2},
                synchronize_session=False
            )
            self.db.commit()

            # Fetch and return
            created_hub = self.db.query(Integration_Hub).filter(Integration_Hub.id == hub_id).first()
            app_logger.info(f"Integration Hub created successfully with id: {created_hub.id}")

            return created_hub

        except HTTPException:
            self.db.rollback()
            # If we created the hub but job creation failed, clean it up
            if hub_id:
                try:
                    self.db.query(Integration_Hub).filter(Integration_Hub.id == hub_id).delete()
                    self.db.commit()
                    app_logger.info(f"Cleaned up partial integration hub with id: {hub_id}")
                except:
                    pass
            raise
        except Exception as e:
            self.db.rollback()
            # If we created the hub but job creation failed, clean it up
            if hub_id:
                try:
                    self.db.query(Integration_Hub).filter(Integration_Hub.id == hub_id).delete()
                    self.db.commit()
                    app_logger.info(f"Cleaned up partial integration hub with id: {hub_id}")
                except:
                    pass
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create integration hub. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create integration hub: {str(e)}")
        
    def recreate_jobs_with_backup(self, integration_hub_id: int, token: str):
        try:
            # ----------------------------------------------------------------------
            # Step 1: Load existing Integration Hub
            # ----------------------------------------------------------------------
            hub = self.db.query(Integration_Hub).filter(
                Integration_Hub.id == integration_hub_id
            ).first()
    
            if not hub:
                raise HTTPException(status_code=404, detail="IntegrationHub not found")

            if hub.task_type == 'pim':
                raise HTTPException(status_code=400, detail="PIM tasks do not have Databricks jobs to recreate")

            app_logger.info(f"[RE-CREATE] Loaded IntegrationHub ID={integration_hub_id}")

            # ----------------------------------------------------------------------
            # Step 2: BACKUP existing job ids + version
            # ----------------------------------------------------------------------

            backup = IntegrationHub_Backup(
                integration_hub_id=integration_hub_id,
                job_id_1=hub.job_id_1,
                job_id_2=hub.job_id_2,
                version=hub.version,
                status_sync="BACKUP_CREATED"
            )
           
            self.db.add(backup)
    
            app_logger.info(
                f"[BACKUP] Backup created: hub_id={integration_hub_id}, "
                f"job1={hub.job_id_1}, job2={hub.job_id_2}, version={hub.version}"
            )
           
            # ----------------------------------------------------------------------
            # Step 3: Re-create NEW jobs with SAME SETTINGS as old hub
            # ----------------------------------------------------------------------
          
            job_result = self.create_job(
                hub.task_name,
                hub.entity_id,
                hub.modelid,
                1,
                hub.traditional_quartz_cron_expression,
                hub.is_golden_deduplication_pipeline,
                hub.golden_deduplication_quartz_cron_expression,
                hub.to_emails,
                hub.created_by,
                token
            )
          
            if not job_result or len(job_result) != 2:
                raise HTTPException(
                    status_code=500,
                    detail="Failed to create integration hub databricks job"
                )

            job_id_1, job_id_2=job_result
            app_logger.info(
                f"[JOB CREATE] New Jobs created for HUB {integration_hub_id}: "
                f"job1={job_id_1}, job2={job_id_2}"
            )
    
            # ----------------------------------------------------------------------
            # Step 4: Update hub with newly created job ids
            # ----------------------------------------------------------------------
            
            hub.job_id_1 = str(job_id_1) if job_id_1 else None
            hub.job_id_2 = str(job_id_2) if job_id_2 else None
            hub.is_traditional_pipeline=1
            hub.version=get_version_info()["productVersion"]
    
            self.db.add(hub)
            self.db.flush()
            
            
            # ----------------------------------------------------------------------
            # Step 5: Update backup status to SYNCED
            # ----------------------------------------------------------------------
            backup.version=get_version_info()["productVersion"]
            backup.status_sync = "SYNCED"
            self.db.commit()
    
            app_logger.info(
                f"[UPDATE] Hub {integration_hub_id} updated with new job ids. Backup marked as SYNCED."
            )
    
            return hub
    
        except Exception as e:
            self.db.rollback()
            app_logger.exception(f"[ERROR] Failed to re-create jobs for hub {integration_hub_id}: {e}")
            raise HTTPException(status_code=500, detail=str(e))
    
    def update_integration_hub(self, task_id, integration_hub_update, token):
        """
        Updates an existing Integration Hub record and its associated Databricks job.
        Handles pipeline mode transitions (separate <-> merged).

        Args:
            task_id (int): The ID of the integration hub to update.
            integration_hub_update: Pydantic model containing updated fields.
            token (str): Auth token for Databricks.

        Returns:
            The updated Integration_Hub object.

        Raises:
            HTTPException: If update fails.
        """
        try:
            # Fetch existing record
            app_logger.info(f"Fetching Integration Hub with id {task_id} for update")
            db_integration_hub = self.db.query(Integration_Hub).filter(Integration_Hub.id == task_id).first()
            if not db_integration_hub:
                raise HTTPException(
                    status_code=404,
                    detail=f"Integration Hub with id {task_id} not found"
                )

            # Get update data
            update_data = integration_hub_update.dict(exclude_unset=True)
            app_logger.info(f"Updating Integration Hub with id {task_id} with data: {update_data}")

            # PIM tasks — only update DB fields, skip Databricks job operations
            if db_integration_hub.task_type == 'pim':
                for key, value in update_data.items():
                    if key not in ['merged_quartz_cron_expression']:
                        setattr(db_integration_hub, key, value)
                self.db.add(db_integration_hub)
                self.db.flush()
                self.db.commit()
                self.db.refresh(db_integration_hub)
                app_logger.info(f"PIM Integration Hub with id {task_id} updated successfully")
                return db_integration_hub

            # Check if MDM restructuring is enabled
            integration_hub_enabled = FeatureFlagService._is_feature_flag_enabled(
                self.db,
                'MDM_RESTRUCTURING'
            )

            # Detect pipeline mode change
            current_mode = db_integration_hub.pipeline_mode or "separate"
            new_mode = update_data.get('pipeline_mode', current_mode)
            mode_changed = current_mode != new_mode and integration_hub_enabled
            emails_changed = 'to_emails' in update_data

            if emails_changed:
                db_integration_hub.to_emails = update_data['to_emails']

            job_service = DatabricksJobManager(token)
            lakefusion_spn = (self.db.query(DBConfigProperties)
                            .filter(DBConfigProperties.config_key == "lakefusion_spn")
                            .first().config_value)

            if mode_changed:
                app_logger.info(f"Pipeline mode changing from {current_mode} to {new_mode}")
                self._handle_pipeline_mode_transition(
                    db_integration_hub,
                    current_mode,
                    new_mode,
                    update_data,
                    job_service,
                    lakefusion_spn,
                    token
                )
            else:
                # No mode change - just update schedules normally
                self._update_job_schedules(
                    db_integration_hub,
                    update_data,
                    job_service,
                    lakefusion_spn=lakefusion_spn,
                    token=token
                )

                if emails_changed:
                    self._repush_to_emails(
                        db_integration_hub,
                        job_service,
                        lakefusion_spn,
                        integration_hub_enabled,
                    )

            # Update other fields
            for key, value in update_data.items():
                if key not in ['merged_quartz_cron_expression']:  # Skip frontend convenience fields
                    app_logger.debug(f"Setting attribute {key} to {value}")
                    setattr(db_integration_hub, key, value)

            self.db.add(db_integration_hub)
            self.db.flush()
            self.db.commit()
            self.db.refresh(db_integration_hub)
            
            app_logger.info(f"Integration Hub with id {task_id} updated successfully")
            return db_integration_hub

        except HTTPException:
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update integration hub. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to update integration hub: {str(e)}")

    def _handle_pipeline_mode_transition(self, hub, from_mode, to_mode, update_data, job_service, lakefusion_spn, token):
        """
        Handles transition between separate and merged pipeline modes.
        
        Separate -> Merged:
            - Update job_id_1 with merged pipeline tasks
            - Pause job_id_2's schedule (golden dedup)
        
        Merged -> Separate:
            - Update job_id_1 with normal pipeline tasks
            - Create or unpause job_id_2 for golden dedup
        """
        if from_mode == "separate" and to_mode == "merged":
            self._transition_to_merged(hub, update_data, job_service, lakefusion_spn, token)
        elif from_mode == "merged" and to_mode == "separate":
            self._transition_to_separate(hub, update_data, job_service, lakefusion_spn, token)

    def _transition_to_merged(self, hub, update_data, job_service, lakefusion_spn, token):
        """
        Transition from separate to merged pipeline mode.
        - Update job_id_1 to be a merged pipeline
        - Pause job_id_2 (golden dedup)
        """
        app_logger.info(f"Transitioning hub {hub.id} from SEPARATE to MERGED mode")

        # Get the schedule from update_data or use existing
        merged_cron = update_data.get('merged_quartz_cron_expression') or \
                    update_data.get('traditional_quartz_cron_expression') or \
                    hub.traditional_quartz_cron_expression

        # Step 1: Update job_id_1 with merged pipeline tasks
        if hub.job_id_1:
            try:
                # Get merged pipeline tasks
                task_list_response = self.create_tasks_and_job_merged_pipeline(
                    hub.entity_id,
                    hub.modelid,
                    hub.to_emails,
                    merged_cron,
                    hub.created_by
                )

                # Update the existing job with new tasks using update_job_with_new_tasks
                job_service.update_job_with_new_tasks(
                    job_id=hub.job_id_1,
                    name=hub.task_name,
                    tasks_list=task_list_response[1],
                    job_parameters=task_list_response[2],
                    schedule=task_list_response[3],
                    email_notifications=task_list_response[4],
                    RunAs=lakefusion_spn
                )
                app_logger.info(f"Updated job_id_1 ({hub.job_id_1}) with merged pipeline tasks")

            except Exception as e:
                app_logger.warning(f"Failed to update job_id_1 for merged mode: {e}")
                # If update fails, try recreating the job
                self._recreate_merged_job(hub, merged_cron, job_service, lakefusion_spn)

        # Step 2: Pause job_id_2 (golden dedup) if it exists
        if hub.job_id_2:
            try:
                job_service.pause_job_schedule(job_id=hub.job_id_2)
                app_logger.info(f"Paused job_id_2 ({hub.job_id_2}) for merged mode")
            except Exception as e:
                app_logger.warning(f"Failed to pause job_id_2: {e}")

        # Update the schedule fields to be consistent
        hub.traditional_quartz_cron_expression = merged_cron
        hub.golden_deduplication_quartz_cron_expression = merged_cron

    def _transition_to_separate(self, hub, update_data, job_service, lakefusion_spn, token):
        """
        Transition from merged to separate pipeline mode.
        - Update job_id_1 back to normal pipeline
        - Create or unpause job_id_2 for golden dedup
        """
        app_logger.info(f"Transitioning hub {hub.id} from MERGED to SEPARATE mode")

        # Get schedules from update_data or use existing
        traditional_cron = update_data.get('traditional_quartz_cron_expression') or \
                        hub.traditional_quartz_cron_expression
        golden_cron = update_data.get('golden_deduplication_quartz_cron_expression') or \
                    hub.golden_deduplication_quartz_cron_expression

        # Step 1: Update job_id_1 with normal pipeline tasks
        if hub.job_id_1:
            try:
                # Get normal pipeline tasks (integration mode)
                task_list_response = self.create_tasks_and_job_integration(
                    hub.entity_id,
                    hub.modelid,
                    hub.to_emails,
                    traditional_cron,
                    hub.created_by
                )

                # Update the existing job with normal tasks
                job_service.update_job_with_new_tasks(
                    job_id=hub.job_id_1,
                    name=hub.task_name,
                    tasks_list=task_list_response[1],
                    job_parameters=task_list_response[2],
                    schedule=task_list_response[3],
                    email_notifications=task_list_response[4],
                    RunAs=lakefusion_spn
                )
                app_logger.info(f"Updated job_id_1 ({hub.job_id_1}) with normal pipeline tasks")

            except Exception as e:
                app_logger.warning(f"Failed to update job_id_1 for separate mode: {e}")

        # Step 2: Handle job_id_2 (golden dedup)
        is_golden_enabled = update_data.get('is_golden_deduplication_pipeline', 
                                            hub.is_golden_deduplication_pipeline)

        if is_golden_enabled:
            if hub.job_id_2:
                # Unpause existing golden dedup job and update schedule
                try:
                    job_service.unpause_job_schedule(job_id=hub.job_id_2)
                    # Also update the schedule if changed
                    job_service.update_job(
                        hub.job_id_2,
                        golden_cron,
                        PauseStatus.UNPAUSED
                    )
                    app_logger.info(f"Unpaused and updated job_id_2 ({hub.job_id_2})")
                except Exception as e:
                    app_logger.warning(f"Failed to unpause job_id_2: {e}")
            else:
                # Create new golden dedup job
                try:
                    task_list_response = self.create_tasks_and_job_golden_dedup_integration(
                        hub.entity_id,
                        hub.modelid,
                        hub.to_emails,
                        golden_cron,
                        hub.created_by,
                        schedule_status="UNPAUSED"
                    )

                    job_create_response = job_service.create_job(
                        f"Golden_Deduplication_{hub.task_name}",
                        task_list_response[0],
                        tasks_list=task_list_response[1],
                        job_parameters=task_list_response[2],
                        schedule=task_list_response[3],
                        email_notifcations=task_list_response[4],
                        RunAs=lakefusion_spn
                    )
                    hub.job_id_2 = str(job_create_response) if job_create_response else None
                    app_logger.info(f"Created new golden dedup job: {hub.job_id_2}")
                except Exception as e:
                    app_logger.warning(f"Failed to create golden dedup job: {e}")

    def _update_job_schedules(self, hub, update_data, job_service, lakefusion_spn=None, token=None):
        """
        Update job schedules without changing pipeline mode.
        """
        # Update traditional job schedule
        if hub.job_id_1:
            try:
                traditional_cron = update_data.get('traditional_quartz_cron_expression')
                is_traditional = update_data.get('is_traditional_pipeline', hub.is_traditional_pipeline)
                
                if traditional_cron is not None or 'is_traditional_pipeline' in update_data:
                    # Determine pause status based on is_traditional_pipeline
                    pause_status = PauseStatus.UNPAUSED if is_traditional else PauseStatus.PAUSED
                    job_service.update_job(
                        hub.job_id_1,
                        traditional_cron or hub.traditional_quartz_cron_expression,
                        pause_status
                    )
                    app_logger.info(f"Updated traditional job schedule for job_id_1: {hub.job_id_1}")
            except Exception as job_exc:
                app_logger.warning(f"Failed to update traditional job: {job_exc}")

        # Handle golden dedup job
        golden_cron = update_data.get('golden_deduplication_quartz_cron_expression')
        is_golden_enabled = update_data.get('is_golden_deduplication_pipeline', hub.is_golden_deduplication_pipeline)
        was_golden_enabled = hub.is_golden_deduplication_pipeline
        
        # Check if golden dedup is being enabled
        golden_being_enabled = 'is_golden_deduplication_pipeline' in update_data and is_golden_enabled and not was_golden_enabled
        
        if hub.job_id_2:
            # Job exists - update or pause it
            try:
                if golden_cron is not None or 'is_golden_deduplication_pipeline' in update_data:
                    pause_status = PauseStatus.UNPAUSED if is_golden_enabled else PauseStatus.PAUSED
                    job_service.update_job(
                        hub.job_id_2,
                        golden_cron or hub.golden_deduplication_quartz_cron_expression,
                        pause_status
                    )
                    app_logger.info(f"Updated golden dedup job schedule for job_id_2: {hub.job_id_2}")
            except Exception as job_exc:
                app_logger.warning(f"Failed to update deduplication job: {job_exc}")
                
        elif is_golden_enabled and lakefusion_spn:
            # Job doesn't exist but golden dedup is being enabled - CREATE IT
            try:
                app_logger.info(f"Creating golden dedup job for hub {hub.id} (first time enable)")
                
                # Determine cron expression
                cron_to_use = golden_cron or hub.golden_deduplication_quartz_cron_expression or hub.traditional_quartz_cron_expression
                
                # Check if MDM restructuring is enabled to decide which pipeline to use
                integration_hub_enabled = FeatureFlagService._is_feature_flag_enabled(
                    self.db,
                    'MDM_RESTRUCTURING'
                )
                
                if integration_hub_enabled:
                    task_list_response = self.create_tasks_and_job_golden_dedup_integration(
                        hub.entity_id,
                        hub.modelid,
                        hub.to_emails or [],
                        cron_to_use,
                        hub.created_by,
                        schedule_status="UNPAUSED"
                    )
                else:
                    # Traditional method - create with UNPAUSED since we're enabling it
                    task_list_response = self.create_tasks_and_job_golden_deduplication(
                        hub.entity_id,
                        hub.modelid,
                        hub.to_emails or [],
                        cron_to_use,
                        hub.created_by,
                        "UNPAUSED"
                    )

                job_create_response = job_service.create_job(
                    f"Golden_Deduplication_{hub.task_name}",
                    task_list_response[0],
                    tasks_list=task_list_response[1],
                    job_parameters=task_list_response[2],
                    schedule=task_list_response[3],
                    email_notifcations=task_list_response[4],
                    RunAs=lakefusion_spn
                )
                
                hub.job_id_2 = str(job_create_response) if job_create_response else None
                app_logger.info(f"Created new golden dedup job: {hub.job_id_2}")
                
            except Exception as e:
                app_logger.warning(f"Failed to create golden dedup job: {e}")

    def _repush_to_emails(self, hub, job_service, lakefusion_spn, integration_hub_enabled):
        """
        Re-push the full task/parameter spec to existing Databricks job(s) so
        that the JobParameter `to_emails` (baked at job-create time) reflects
        the current value of hub.to_emails.

        Caller must update hub.to_emails to the new value BEFORE invoking.
        Skipped on mode transitions (those rebuild tasks via
        _handle_pipeline_mode_transition).
        """
        to_emails = hub.to_emails or []
        current_mode = hub.pipeline_mode or "separate"

        if integration_hub_enabled and current_mode == "merged":
            if hub.job_id_1:
                try:
                    tasks = self.create_tasks_and_job_merged_pipeline(
                        hub.entity_id,
                        hub.modelid,
                        to_emails,
                        hub.traditional_quartz_cron_expression,
                        hub.created_by,
                    )
                    job_service.update_job_with_new_tasks(
                        job_id=hub.job_id_1,
                        name=hub.task_name,
                        tasks_list=tasks[1],
                        job_parameters=tasks[2],
                        schedule=tasks[3],
                        email_notifications=tasks[4],
                        RunAs=lakefusion_spn,
                    )
                    app_logger.info(f"Re-pushed to_emails to merged job_id_1 ({hub.job_id_1})")
                except Exception as e:
                    app_logger.warning(f"Failed to re-push to_emails to merged job_id_1: {e}")
            return

        # Separate-mode re-push: traditional + golden dedup jobs
        if hub.job_id_1:
            try:
                if integration_hub_enabled:
                    tasks = self.create_tasks_and_job_integration(
                        hub.entity_id,
                        hub.modelid,
                        to_emails,
                        hub.traditional_quartz_cron_expression,
                        hub.created_by,
                    )
                else:
                    tasks = self.create_tasks_and_job_traditional(
                        hub.entity_id,
                        hub.modelid,
                        to_emails,
                        hub.traditional_quartz_cron_expression,
                        hub.created_by,
                    )
                job_service.update_job_with_new_tasks(
                    job_id=hub.job_id_1,
                    name=hub.task_name,
                    tasks_list=tasks[1],
                    job_parameters=tasks[2],
                    schedule=tasks[3],
                    email_notifications=tasks[4],
                    RunAs=lakefusion_spn,
                )
                app_logger.info(f"Re-pushed to_emails to job_id_1 ({hub.job_id_1})")
            except Exception as e:
                app_logger.warning(f"Failed to re-push to_emails to job_id_1: {e}")

        if hub.job_id_2:
            try:
                schedule_status = "UNPAUSED" if hub.is_golden_deduplication_pipeline else "PAUSED"
                if integration_hub_enabled:
                    tasks = self.create_tasks_and_job_golden_dedup_integration(
                        hub.entity_id,
                        hub.modelid,
                        to_emails,
                        hub.golden_deduplication_quartz_cron_expression,
                        hub.created_by,
                        schedule_status=schedule_status,
                    )
                else:
                    tasks = self.create_tasks_and_job_golden_deduplication(
                        hub.entity_id,
                        hub.modelid,
                        to_emails,
                        hub.golden_deduplication_quartz_cron_expression,
                        hub.created_by,
                        schedule_status,
                    )
                job_service.update_job_with_new_tasks(
                    job_id=hub.job_id_2,
                    name=f"Golden_Deduplication_{hub.task_name}",
                    tasks_list=tasks[1],
                    job_parameters=tasks[2],
                    schedule=tasks[3],
                    email_notifications=tasks[4],
                    RunAs=lakefusion_spn,
                )
                app_logger.info(f"Re-pushed to_emails to job_id_2 ({hub.job_id_2})")
            except Exception as e:
                app_logger.warning(f"Failed to re-push to_emails to job_id_2: {e}")

    def _recreate_merged_job(self, hub, cron_expression, job_service, lakefusion_spn):
        """
        Fallback: Delete and recreate job_id_1 as a merged pipeline job.
        """
        try:
            # Delete existing job
            if hub.job_id_1:
                try:
                    job_service.delete_job(int(hub.job_id_1))
                except:
                    pass

            # Create new merged pipeline job
            task_list_response = self.create_tasks_and_job_merged_pipeline(
                hub.entity_id,
                hub.modelid,
                hub.to_emails,
                cron_expression,
                hub.created_by
            )

            job_create_response = job_service.create_job(
                hub.task_name,
                task_list_response[0],
                tasks_list=task_list_response[1],
                job_parameters=task_list_response[2],
                schedule=task_list_response[3],
                email_notifcations=task_list_response[4],
                RunAs=lakefusion_spn
            )
            hub.job_id_1 = str(job_create_response) if job_create_response else None
            app_logger.info(f"Recreated merged pipeline job: {hub.job_id_1}")
        except Exception as e:
            app_logger.error(f"Failed to recreate merged job: {e}")
            raise

    def create_tasks_and_job_reference_pipeline(self, entity_id, quartz_cron_expression, created_by):
        """
        Creates a merged pipeline job that runs both normal deduplication and golden deduplication
        sequentially in a single job.
        """
        catalog_name = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
            .config_value
        )

        tags = get_resource_tags()
        if tags is None:
            tags = {}

        job_cluster = None

        parameters = {
            "entity_id": str(entity_id),
            "experiment_id": "prod",
            "catalog_name": str(catalog_name),
            "secret_scope_name": self._get_secret_scope_name(),
        }

        tasks_list = [
            # ============================================================
            # ---------------------- PARSE + MASTER CHECK -----------------
            # ============================================================

            Task(
                task_key="Parse_Entity_Model_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
             Task(
                task_key="Parse_Entity_Model_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ), Task(
                task_key="Parse_Entity_Model_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        ]
        job_parameters_list = [
            JobParameter(name="entity_id", default=str(entity_id)),
            JobParameter(name="experiment_id", default="prod"),
            JobParameter(name="processed_records", default=""),
            JobParameter(name="is_integration_hub", default="1"),
            JobParameter(name="catalog_name", default=str(catalog_name)),
            JobParameter(name="to_emails", default=','.join(to_emails))
        ]

        schedule = self._create_schedule(quartz_cron_expression)


        return [job_cluster, tasks_list, job_parameters_list, schedule]

    def create_tasks_and_job_merged_pipeline(self, entity_id, model_id, to_emails, quartz_cron_expression, created_by):
        """
        Creates a merged pipeline job that runs both normal deduplication and golden deduplication
        sequentially in a single job.
        """
        catalog_name = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
            .config_value
        )

        tags = get_resource_tags()
        if tags is None:
            tags = {}

        job_cluster = None

        parameters = {
            "entity_id": str(entity_id),
            "experiment_id": "prod",
            "to_emails": ','.join(to_emails),
            "processed_records": "",
            "is_integration_hub": "1",
            "catalog_name": str(catalog_name),
            "secret_scope_name": self._get_secret_scope_name(),
        }

        tasks_list = [
            # ============================================================
            # ---------------------- PARSE + MASTER CHECK -----------------
            # ============================================================

            Task(
                task_key="Parse_Entity_Model_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Check_Master_Exists",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Check_Master_Exists",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Check_Master_Exists",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Run_Migration",
                depends_on=[TaskDependency(task_key="Check_Master_Exists")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/migration-utilities/Run Migrations",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Is_Initial_Load_Check",
                depends_on=[TaskDependency(task_key="Run_Migration")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Check_Master_Exists.values.is_initial_load}}",
                    right="true",
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # -------------------------- INITIAL LOAD ---------------------
            # ============================================================

            Task(
                task_key="Validate_Initial_Load",
                depends_on=[TaskDependency(task_key="Is_Initial_Load_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Validate_Initial_Load",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Validate_Initial_Load",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Create_Tables",
                depends_on=[TaskDependency(task_key="Validate_Initial_Load")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Create_Tables",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Create_Tables",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Load_Primary_Source",
                depends_on=[TaskDependency(task_key="Create_Tables")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Load_Primary_Source",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Load_Primary_Source",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Load_Secondary_Sources",
                depends_on=[TaskDependency(task_key="Load_Primary_Source")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Load_Secondary_Sources",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Load_Secondary_Sources",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ------------------------ INCREMENTAL LOAD -------------------
            # ============================================================

            Task(
                task_key="Process_Incremental_Load",
                depends_on=[TaskDependency(task_key="Is_Initial_Load_Check", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/incremental_load/Incremental_Load_To_Unified",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/incremental_load/Incremental_Load_To_Unified",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ---------------------- ENDPOINTS MAPPING --------------------
            # ============================================================

            Task(
                task_key="Endpoints_Mapping",
                depends_on=[
                    TaskDependency(task_key="Load_Secondary_Sources"),
                    TaskDependency(task_key="Process_Incremental_Load"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Endpoints_Mapping",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Endpoints_Mapping",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ========== COMPUTE EMBEDDINGS (no-op for managed mode) =====
            # ============================================================

            Task(
                task_key="Compute_Embeddings",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Compute_Embeddings",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ========== NORMAL DEDUPLICATION SECTION =====================
            # ============================================================

            Task(
                task_key="Entity_Matching_Vector_Search",
                depends_on=[
                    TaskDependency(task_key="Compute_Embeddings"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Entity_Matching_Vector_Search",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Entity_Matching_Vector_Search",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Entity_Matching_Detereministic",
                depends_on=[
                    TaskDependency(task_key="Entity_Matching_Vector_Search"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Entity_Matching_Vector_Search",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Deterministic",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
                                
                            
            Task(
                task_key="Entity_Matching_LLM",
                depends_on=[TaskDependency(task_key="Entity_Matching_Detereministic")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Entity_Matching_LLM",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Entity_Matching_LLM",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Process_Auto_Merge",
                depends_on=[TaskDependency(task_key="Entity_Matching_LLM")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Process_Auto_Merge",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Auto_Merge",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Process_Unmatched_Records",
                depends_on=[TaskDependency(task_key="Process_Auto_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Process_Unmatched_Records",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Unmatched_Records",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ========== GOLDEN DEDUPLICATION SECTION =====================
            # ============================================================

            Task(
                task_key="Process_Unified_Dedup_Table",
                depends_on=[
                    TaskDependency(task_key="Process_Unmatched_Records"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Process_Unified_Dedup_Table",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Unified_Dedup_Table",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Compute_Embeddings_Golden",
                depends_on=[
                    TaskDependency(task_key="Process_Unified_Dedup_Table"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Compute_Embeddings",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Golden_Entity_Matching_Vector_Search",
                depends_on=[
                    TaskDependency(task_key="Compute_Embeddings_Golden"),
                    TaskDependency(task_key="Compute_Embeddings"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Entity_Matching_Vector_Search",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Entity_Matching_Vector_Search",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Golden_Entity_Matching_Detereministic",
                depends_on=[
                    TaskDependency(task_key="Golden_Entity_Matching_Vector_Search"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Entity_Matching_Vector_Search",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Deterministic",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            

            Task(
                task_key="Golden_Entity_Matching_LLM",
                depends_on=[TaskDependency(task_key="Golden_Entity_Matching_Detereministic")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Entity_Matching_LLM",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Entity_Matching_LLM",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Golden_Process_Auto_Merge",
                depends_on=[TaskDependency(task_key="Golden_Entity_Matching_LLM")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Process_Auto_Merge",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Auto_Merge",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ========== PARALLEL POTENTIAL MATCH PROCESSING ==============
            # ============================================================
            # In merged mode, both potential match tasks run without single source check

            Task(
                task_key="Process_Potential_Match_Normal",
                depends_on=[TaskDependency(task_key="Golden_Process_Auto_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Process_Potential_Match_Golden",
                depends_on=[TaskDependency(task_key="Golden_Process_Auto_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Potential_Match",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ========== PARALLEL UPDATE TABLE METADATA ===================
            # ============================================================

            Task(
                task_key="Update_Table_Metadata_Normal",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Normal")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Update_Table_Metadata",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Update_Table_Metadata",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Update_Table_Metadata_Golden",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Golden")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Update_Table_Metadata",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Update_Table_Metadata",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ========== CROSSWALK & WARNING RECORDS ======================
            # ============================================================

            Task(
                task_key="Process_CrossWalk",
                depends_on=[
                    TaskDependency(task_key="Process_Potential_Match_Normal"),
                    TaskDependency(task_key="Process_Potential_Match_Golden"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Process_Warning",
                depends_on=[
                    TaskDependency(task_key="Process_Potential_Match_Normal"),
                    TaskDependency(task_key="Process_Potential_Match_Golden"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Warning Records",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Warning Records",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ========== DNB INTEGRATION ==================================
            # ============================================================

            Task(
                task_key="DNB_Integration",
                depends_on=[
                    TaskDependency(task_key="Golden_Process_Auto_Merge"),
                ],
                run_if=RunIf.AT_LEAST_ONE_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.is_entity_dnb_enabled}}",
                    right="True"
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Process_DNB_Integration",
                depends_on=[TaskDependency(task_key="DNB_Integration", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/dnb_integration/D&B Match and Monitoring Accelerator",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('dnb_integration', self.db)}/D&B Match and Monitoring Accelerator",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ========== EMAIL NOTIFICATION ===============================
            # ============================================================

            Task(
                task_key="Check_Email_List",
                depends_on=[
                    TaskDependency(task_key="Process_Potential_Match_Normal"),
                    TaskDependency(task_key="Process_Potential_Match_Golden"),
                ],
                run_if=RunIf.NONE_FAILED,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{job.parameters.to_emails}}",
                    right=""
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Send_Email_Notification",
                depends_on=[TaskDependency(task_key="Check_Email_List", outcome=False)],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Send Email Notification",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Send Email Notification",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ========== RESOURCE TAGGING =================================
            # ============================================================

            Task(
                task_key="Resource_Tagging",
                depends_on=[
                    TaskDependency(task_key="Send_Email_Notification"),
                    TaskDependency(task_key="Process_DNB_Integration"),
                    TaskDependency(task_key="Process_CrossWalk"),
                    TaskDependency(task_key="Update_Table_Metadata_Normal"),
                    TaskDependency(task_key="Update_Table_Metadata_Golden"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Resource Tagging",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Resource Tagging",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # RBAC Permissions — must run last, always (even if prior tasks fail)
            # ============================================================
            Task(
                task_key="RBAC_Permissions",
                depends_on=[TaskDependency(task_key="Resource_Tagging")],
                run_if=RunIf.ALL_DONE,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/RBAC_Permissions",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        ]

        job_parameters_list = [
            JobParameter(name="entity_id", default=str(entity_id)),
            JobParameter(name="experiment_id", default="prod"),
            JobParameter(name="processed_records", default=""),
            JobParameter(name="is_integration_hub", default="1"),
            JobParameter(name="catalog_name", default=str(catalog_name)),
            JobParameter(name="to_emails", default=','.join(to_emails)),
            JobParameter(name="secret_scope_name", default=self._get_secret_scope_name())
        ]

        schedule = self._create_schedule(quartz_cron_expression)

        email_notifications = JobEmailNotifications(on_failure=created_by)

        return [job_cluster, tasks_list, job_parameters_list, schedule, email_notifications]
            
    def read_integration_hub(
        self,
        is_active: bool = True,
        task_type: Optional[str] = None,
        sort_by: str = "created_at",
        sort_order: str = "desc",
        limit: Optional[int] = None,
        offset: int = 0
    ):
        """Retrieves integration hubs from the database with filtering, sorting, and pagination options.
        
        Args:
            is_active: Filter integration hubs by their active status. If None, returns all hubs.
            sort_by: Field to sort by (e.g., 'id', 'task_name', 'created_at', 'updated_at'). Default is 'created_at'.
            sort_order: Sort order, either 'asc' or 'desc'. Default is 'desc'.
            limit: Maximum number of records to return. If None, returns all matching records.
            offset: Number of records to skip for pagination. Default is 0.
            
        Returns:
            A list of integration hubs based on the specified filters and sorting.
            
        Raises:
            HTTPException: If there's an error during retrieval or invalid parameters.
        """
        try:
            # Validate sort_order parameter
            if sort_order.lower() not in ['asc', 'desc']:
                raise HTTPException(status_code=400, detail="sort_order must be either 'asc' or 'desc'")
            
            # Validate sort_by field exists on the Integration_Hub model
            if not hasattr(Integration_Hub, sort_by):
                raise HTTPException(status_code=400, detail=f"Invalid sort field: {sort_by}")
            
            # Validate limit and offset parameters
            if limit is not None and limit < 0:
                raise HTTPException(status_code=400, detail="limit must be non-negative")
            
            if offset < 0:
                raise HTTPException(status_code=400, detail="offset must be non-negative")
            
            # Start building the query
            integration_hub_query = self.db.query(Integration_Hub)
            
            # Apply active filter if specified
            if is_active is not None:
                integration_hub_query = integration_hub_query.filter(Integration_Hub.is_active == is_active)

            # Apply task_type filter if specified
            if task_type is not None:
                integration_hub_query = integration_hub_query.filter(Integration_Hub.task_type == task_type)
            
            # Apply sorting
            sort_field = getattr(Integration_Hub, sort_by)
            if sort_order.lower() == 'desc':
                integration_hub_query = integration_hub_query.order_by(sort_field.desc())
            else:
                integration_hub_query = integration_hub_query.order_by(sort_field.asc())
            
            # Apply pagination if specified
            if offset > 0:
                integration_hub_query = integration_hub_query.offset(offset)
            
            if limit is not None and limit > 0:
                integration_hub_query = integration_hub_query.limit(limit)
            
            # Execute query and return results
            data = integration_hub_query.all()
            
            base_pipeline_version=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "pipeline_base_version").first().config_value)
            
            for row in data:
                row.sync_required = compare_versions(str(base_pipeline_version), getattr(row, "version", None)) == 1
                # Prevent lazy-load of placeholder model_experiment for PIM tasks
                if getattr(row, 'task_type', 'mdm') == 'pim':
                    row.model_experiment = None
                            
            app_logger.info(
                f"Successfully retrieved {len(data)} integration hubs with filters: "
                f"is_active={is_active}, sort_by={sort_by}, sort_order={sort_order}, "
                f"limit={limit}, offset={offset}"
            )
            return data

        except HTTPException:
            # Re-raise HTTP exceptions (validation errors)
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch integration hubs. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch integration hubs: {str(e)}"
            )
    
    def get_integration_hub_task_version(db: Session, entity_id: int):
        try:
            row = (
                db.query(Integration_Hub.version)
                .filter(Integration_Hub.entity_id == entity_id)
                .order_by(Integration_Hub.created_at.desc())  
                .first()
            )

            if not row:
                app_logger.warning(f"No integration hub record found for entity_id: {entity_id}")
                return None

            version = row.version
            app_logger.info(f"Fetched integration hub version {version} for entity_id: {entity_id}")

            return version

        except HTTPException:
            raise

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Unable to get entity version for entity_id {entity_id}. Reason: {message}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity version: {str(e)}"
            )

    def _drop_entity_tables(self, entity_id: int, token: str, warehouse_id: str = None, experiment_id: str = "prod"):
        """Drop all Delta tables/views the integration-hub pipeline creates for
        an entity, plus its row from the table_meta_info catalog.

        Best-effort: any individual DROP failure is logged and the rest still
        run, so a half-built entity (some tables created, others not) still
        gets cleaned up correctly. Returns a summary dict of what was attempted.

        Args:
            entity_id: entity to clean up
            token:     workspace token for the SQL warehouse client
            experiment_id: suffix used by the integration-hub jobs. Defaults
                           to "prod" (the value the hub passes to its jobs).
                           Pass an experiment id to clean up an experiment.
        """
        if not warehouse_id:
            app_logger.warning("Skipping entity-table drop: warehouse_id not provided")
            return {"dropped": 0, "skipped": "no_warehouse_id"}

        catalog_row = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
        )
        catalog_name = catalog_row.config_value if catalog_row else None
       

        if not catalog_name:
            app_logger.warning("Skipping entity-table drop: catalog_name not configured")
            return {"dropped": 0, "skipped": "no_catalog_name"}
        

        # Resolve entity_name from EntityService
        entity_service = EntityService(self.db)
        entity = entity_service.get_entity_by_id(entity_id=entity_id)
        if entity is None:
            app_logger.warning(f"Skipping entity-table drop: entity {entity_id} not found")
            return {"dropped": 0, "skipped": "no_entity"}
        entity_name = entity.name.lower().replace(" ", "_")

        suffix = f"_prod"

        # Single compound statement via BEGIN ... END — sent as one execute()
        # call to the SQL warehouse instead of N round-trips. DROP IF EXISTS,
        # DROP VIEW IF EXISTS and DELETE all tolerate missing objects, so the
        # whole block runs cleanly on a half-built entity too.
        #
        # NOTE: REFERENCE_ENTITY mapping tables ({ref_entity}_reference_mappings{suffix})
        # are intentionally NOT dropped here — they're keyed by the *reference*
        # entity (e.g. country), not the operating entity, so multiple operating
        # entities may share one mapping table. Cleaning them up requires a
        # separate "delete reference entity" flow.
        cleanup_sql = f"""
BEGIN
    -- Silver layer
    DROP TABLE IF EXISTS {catalog_name}.silver.{entity_name}_unified{suffix};
    DROP TABLE IF EXISTS {catalog_name}.silver.{entity_name}_unified_deduplicate{suffix};
    DROP TABLE IF EXISTS {catalog_name}.silver.{entity_name}_processed_unified{suffix};
    DROP TABLE IF EXISTS {catalog_name}.silver.{entity_name}_processed_unified_deduplicate{suffix};
    DROP TABLE IF EXISTS {catalog_name}.silver.{entity_name}_unified_validation_error{suffix};

    -- Tables added by Stage 1-3 (UnifiedErrorHandler, deterministic outputs)
    DROP TABLE IF EXISTS {catalog_name}.silver.{entity_name}_unified_error{suffix};
    DROP TABLE IF EXISTS {catalog_name}.silver.{entity_name}_unified_deduplicate_error{suffix};
    DROP TABLE IF EXISTS {catalog_name}.silver.{entity_name}_unified_deterministic{suffix};
    DROP TABLE IF EXISTS {catalog_name}.silver.{entity_name}_unified_deterministic_deduplicate{suffix};

    -- Gold layer — master + its companions
    DROP TABLE IF EXISTS {catalog_name}.gold.{entity_name}_master{suffix};
    DROP TABLE IF EXISTS {catalog_name}.gold.{entity_name}_master{suffix}_merge_activities;
    DROP TABLE IF EXISTS {catalog_name}.gold.{entity_name}_master{suffix}_attribute_version_sources;
    DROP TABLE IF EXISTS {catalog_name}.gold.{entity_name}_master_potential_match{suffix};
    DROP TABLE IF EXISTS {catalog_name}.gold.{entity_name}_master_potential_match_deduplicate{suffix};

    -- Crosswalk view
    DROP VIEW IF EXISTS {catalog_name}.gold.{entity_name}_crosswalk{suffix};

    -- Catalog metadata row
    DELETE FROM {catalog_name}.silver.table_meta_info
    WHERE entity_name = '{entity_name}';
END
"""

        sql_conn = DataSetSQLService(token, warehouse_id)
        sql_status = "ok"
        sql_error = None
        try:
            sql_conn.execute_dataset(cleanup_sql)
            app_logger.info(
                f"Entity table cleanup for entity_id={entity_id} ({entity_name}) succeeded"
            )
        except Exception as e:
            sql_status = "failed"
            sql_error = str(e)
            app_logger.warning(
                f"Entity table cleanup for entity_id={entity_id} ({entity_name}) failed: {e}"
            )

        # Delete the Vector Search index for the master table. Index name is
        # the same convention used by Entity_Matching_Vector_Search.py:
        # f"{master_table}_index". 404/not-found is treated as success.
        vs_index_name = f"{catalog_name}.gold.{entity_name}_master{suffix}_index"
        try:
            vs_service = VectorSearchService(token)
            vs_result = vs_service.delete_index(vs_index_name)
        except Exception as vs_exc:
            app_logger.warning(
                f"Vector Search index delete raised an error (continuing): {vs_exc}"
            )
            vs_result = {"status": "failed", "index_name": vs_index_name, "detail": str(vs_exc)}

        return {
            "status": sql_status,
            "entity_name": entity_name,
            "sql_error": sql_error,
            "vector_search_index": vs_result,
        }


    def delete_integration_hub(
        self,
        hub_id: int,
        job_ids: list,
        token: str,
        drop_tables: bool = False,
        warehouse_id: str = None,
    ):
        """Deletes an integration hub record by ID.

        Args:
            hub_id (int): The ID of the integration hub to delete.
            job_ids (list): Databricks job IDs to delete alongside this hub.
            token (str): Workspace token for the SDK / SQL warehouse calls.
            drop_tables (bool): When True, also DROP all entity Delta tables/views,
                the table_meta_info row, and the Vector Search index. When False
                (default), only the Databricks jobs and DB rows are deleted —
                catalog data is left intact.
            warehouse_id (str): SQL warehouse to run the DROP statements against.
                Required when drop_tables=True; the cleanup is skipped otherwise.

        Returns:
            dict: Success message.
        """
        try:
            for job_id in job_ids:
                try:
                    job_service = DatabricksJobManager(token)
                    job_service.delete_job(int(job_id))
                except Exception as job_exc:
                    app_logger.exception(f"Failed to delete Databricks job {job_id}: {job_exc}")
                    return {"message": f"Failed to delete Databricks job {job_id}: {str(job_exc)}"}

            # Delete associated schema evolution jobs (and their Databricks jobs)
            from lakefusion_utility.models.schema_evolution import SchemaEvolutionJob
            se_jobs = self.db.query(SchemaEvolutionJob).filter(
                SchemaEvolutionJob.integration_hub_id == hub_id
            ).all()

            for se_job in se_jobs:
                if se_job.databricks_job_id:
                    try:
                        se_job_service = DatabricksJobManager(token)
                        se_job_service.delete_job(int(se_job.databricks_job_id))
                    except Exception as se_exc:
                        app_logger.warning(f"Failed to delete SE Databricks job {se_job.databricks_job_id}: {se_exc}")
                self.db.delete(se_job)

            self.db.flush()

            integration_hub = (
                self.db.query(Integration_Hub)
                .filter(Integration_Hub.id == hub_id)
                .first()
            )

            if not integration_hub:
                raise HTTPException(
                    status_code=404,
                    detail=f"Integration Hub with id {hub_id} not found"
                )

            # Drop the entity's Delta tables/views in the catalog ONLY when the
            # caller opts in via the drop_tables flag. Best-effort: any cleanup
            # failure is logged and does not block the DB-row delete.
            if drop_tables:
                try:
                    self._drop_entity_tables(
                        entity_id=integration_hub.entity_id,
                        token=token,
                        warehouse_id=warehouse_id,
                    )
                except Exception as drop_exc:
                    app_logger.warning(
                        f"Entity-table cleanup raised an error (continuing with DB delete): {drop_exc}"
                    )
            else:
                app_logger.info(
                    f"drop_tables=False — skipping entity-table cleanup for hub_id={hub_id}"
                )

            # Delete all entity search job records for this entity to prevent stale
            # job statuses from affecting button state on re-initialization
            self.db.query(Model_Databricks_Entity_Search_Job).filter(
                Model_Databricks_Entity_Search_Job.entity_id == integration_hub.entity_id
            ).delete(synchronize_session=False)

            self.db.delete(integration_hub)
            self.db.commit()
    
            return {"message": f"Integration Hub with id {hub_id} deleted successfully"}
    
        except HTTPException:
            # Re-raise 404 or other HTTP errors as is
            raise
        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete integration hub. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to delete integration hub: {str(e)}"
            )

    def upload_metadata_files(self, integration_hub_id: int, token: str):
        """Re-uploads latest entity.json and model.json to the metadata volume."""
        try:
            integration_hub = self.db.query(Integration_Hub).filter(
                Integration_Hub.id == integration_hub_id
            ).first()

            if not integration_hub:
                raise HTTPException(status_code=404, detail="Integration Hub not found")

            if integration_hub.task_type == 'pim':
                return {"message": "PIM tasks do not require metadata file uploads"}

            entity_id = integration_hub.entity_id
            model_id = integration_hub.modelid

            entity_service = EntityService(self.db)
            entity_data = entity_service.get_full_entity_by_id(entity_id).dict()

            experiment_service = ExperimentService(self.db)
            model_data = experiment_service.get_model(model_id).dict()

            catalog_service = CatalogService(token, self.db)
            folder_path = catalog_service.create_volume_folder(entity_id, 'prod')

            if not folder_path:
                raise HTTPException(status_code=500, detail="Failed to create volume folder")

            catalog_service.upload_data_as_json(folder_path, 'entity.json', entity_data)
            catalog_service.upload_data_as_json(folder_path, 'model.json', model_data)

            app_logger.info(f"Metadata files uploaded successfully for entity {entity_id}")
            return {"message": f"Metadata files uploaded successfully for entity {entity_id}"}

        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to upload metadata files: {message}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to upload metadata files: {str(e)}"
            )

    def get_job_run_status(self,job_run_id:str,token:str):
        try:
            job_service = DatabricksJobManager(token)
            job_response=job_service.get_job_run_status(job_run_id)
            return job_response

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to get job run status. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to get job run status: {str(e)}")
        
    def sync_all_job_versions(self, token: str):
        """
        Sync version for all Integration Hub records by checking job_id_1 and job_id_2.
        Extracts version tag from Databricks job definitions and updates DB.
        """
        databricks_job=DatabricksJobManager(token)
    
        hubs = self.db.query(Integration_Hub).all()
        updated_count = 0
    
        for hub in hubs:
            job_id = hub.job_id_1 or hub.job_id_2  # pick available job
            if not job_id:
                app_logger.info(f"Skipping hub_id={hub.id}, no job_id_1 or job_id_2")
                continue
    
            try:
                # Fetch job definition (this is where tags live)
                job = databricks_job.get_job_info(job_id=job_id)
                if job.settings and job.settings.tags:
                    version = job.settings.tags.get("version")
                    if version:
                        version
                else:
                    app_logger.warning(
                            f"No version tag for job_id={job_id}, hub_id={hub.id}"
                    )
                    version="1.0.0"
    
    
                   
    
                # Update DB
                hub.version = version
                updated_count += 1
    
            except Exception as ex:
                app_logger.error(
                    f"Failed syncing hub_id={hub.id}, job_id={job_id}: {ex}"
                )
    
        # Commit all changes
        self.db.commit()
    
        app_logger.info(f"Version sync completed. Updated {updated_count} rows.")
        return {"updated": updated_count}

    def create_tasks_and_job_traditional(self,entity_id,model_id,to_emails,quartz_cron_expression,created_by):   
    
        catalog_name=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "catalog_name").first().config_value)

        tags = get_resource_tags()
        if tags is None:
            tags = {}
        
        job_cluster = None
        
        parameters={"entity_id":str(entity_id), "experiment_id":"prod", "to_emails": ','.join(to_emails),"processed_records":"","is_integration_hub":"1","catalog_name":str(catalog_name),"secret_scope_name":self._get_secret_scope_name()}
        tasks_list = [
            Task(
                task_key="Parse_Entity_Model_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Parse Entity & Model JSON",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Prepare_Tables",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Prepare Tables",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Prepare Tables",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Match_Maven_Job",
                depends_on=[TaskDependency(task_key="Prepare_Tables")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.NOT_EQUAL,
                    left="{{job.parameters.experiment_id}}",
                    right="prod"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Incremental_Load_Job",
                depends_on=[TaskDependency(task_key="Match_Maven_Job", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Prepare_Tables.values.incremental_load}}",
                    right="True"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Foundational_Model_Serving_Endpoint_Check",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.embedding_model_source}}",
                    right="databricks_foundation"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Foundational_Serving_Endpoint",
                depends_on=[TaskDependency(
                    task_key="Embedding_Foundational_Model_Serving_Endpoint_Check",
                    outcome=True
                )],
            
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Embedding Foundational",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Embedding Foundational",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Model_Serving_Endpoint_Check",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.embedding_model_source}}",
                    right="databricks_custom_hugging_face"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Hugging_Face_Serving_Endpoint",
                depends_on=[TaskDependency(
                    task_key="Embedding_Model_Serving_Endpoint_Check",
                    outcome=True
                )],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Embeddings Hugging Face",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Embeddings Hugging Face",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Foundational_Model_Serving_Endpoint_Check",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.llm_model_source}}",
                    right="databricks_foundation"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Foundational_Serving_Endpoint",
                depends_on=[TaskDependency(
                    task_key="LLM_Foundational_Model_Serving_Endpoint_Check",
                    outcome=True
                )],
                
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/LLM Foundational",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/LLM Foundational",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Model_Serving_Endpoint_Check",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.llm_model_source}}",
                    right="databricks_custom_hugging_face"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Hugging_Face_Serving_Endpoint",
                depends_on=[TaskDependency(
                    task_key="LLM_Model_Serving_Endpoint_Check",
                    outcome=True
                )],
            
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/LLM Hugging Face",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/LLM Hugging Face",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Endpoints_Mapping",
                depends_on=[
                    TaskDependency(task_key="Incremental_Load_Job", outcome=True),
                    TaskDependency(task_key="Match_Maven_Job", outcome=False)
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Endpoints Mapping",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Endpoints Mapping",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Primary_Delete",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Delete",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Primary_Insert",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Insert",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Primary_Updates",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Updates",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Delete",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Delete",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Delete",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Updates",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Updates",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Updates",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Entity_Matching_Vector_Search",
                depends_on=[
                    TaskDependency(task_key="Embedding_Model_Serving_Endpoint_Check", outcome=False),
                    TaskDependency(task_key="Endpoints_Mapping"),
                    TaskDependency(task_key="Process_Updates"),
                    TaskDependency(task_key="Process_Delete"),
                    TaskDependency(task_key="Process_Primary_Updates"),
                    TaskDependency(task_key="Process_Primary_Delete"),
                    TaskDependency(task_key="Process_Primary_Insert"),
                    TaskDependency(task_key="Embedding_Hugging_Face_Serving_Endpoint"),
                    TaskDependency(task_key="Incremental_Load_Job", outcome=True),
                    TaskDependency(task_key="Embedding_Foundational_Model_Serving_Endpoint_Check", outcome=False),
                    TaskDependency(task_key="LLM_Foundational_Serving_Endpoint"),
                    TaskDependency(task_key="Embedding_Foundational_Serving_Endpoint"),
                    TaskDependency(task_key="LLM_Hugging_Face_Serving_Endpoint"),
                    TaskDependency(task_key="LLM_Model_Serving_Endpoint_Check", outcome=False),
                    TaskDependency(task_key="LLM_Foundational_Model_Serving_Endpoint_Check", outcome=False)
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Entity Matching - Vector Search",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Entity Matching - Vector Search",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Entity_Matching_LLM",
                depends_on=[TaskDependency(task_key="Entity_Matching_Vector_Search")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Entity Matching - LLM",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Entity Matching - LLM",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Merge_Records_Check",
                depends_on=[TaskDependency(task_key="Entity_Matching_LLM")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{job.parameters.experiment_id}}",
                    right="prod"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Process_Match_Merge_Records",
                depends_on=[TaskDependency(task_key="Merge_Records_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Match - Merge Records",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Match - Merge Records",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Unmatched_Records",
                depends_on=[TaskDependency(task_key="Process_Match_Merge_Records")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Unmatched Records",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Unmatched Records",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Potential_Match_Table",
                depends_on=[TaskDependency(task_key="Process_Unmatched_Records")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Potential Match Table",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Potential Match Table",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Update_Table_Metadata",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Update Table Metadata",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Update Table Metadata",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_CrossWalk",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Cross Walk",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Warning",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Warning Records",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Warning Records",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="DNB_Integration",
                depends_on=[TaskDependency(task_key="Process_Unmatched_Records"),TaskDependency(task_key="Process_Match_Merge_Records")],
                run_if=RunIf.AT_LEAST_ONE_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.is_entity_dnb_enabled}}",
                    right="True"
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_DNB_Integration",
                depends_on=[TaskDependency(task_key="DNB_Integration",outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/dnb_integration/D&B Match and Monitoring Accelerator",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('dnb_integration', self.db)}/D&B Match and Monitoring Accelerator",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Check_Email_List",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{job.parameters.to_emails}}",
                    right=""
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Send_Email_Notification",
                depends_on=[
                    TaskDependency(task_key="Check_Email_List",outcome=False)
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Send Email Notification",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Send Email Notification",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Resource_Tagging",
                depends_on=[
                    TaskDependency(task_key="Send_Email_Notification"),
                    TaskDependency(task_key="Process_DNB_Integration"),
                    TaskDependency(task_key="Process_CrossWalk")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Resource Tagging",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Resource Tagging",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # RBAC Permissions — must run last, always (even if prior tasks fail)
            # ============================================================
            Task(
                task_key="RBAC_Permissions",
                depends_on=[TaskDependency(task_key="Resource_Tagging")],
                run_if=RunIf.ALL_DONE,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/RBAC_Permissions",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        ]
        job_parameters_list = [
        JobParameter(
            name="entity_id",
            default=str(entity_id)
        ),
        JobParameter(
            name="experiment_id",
            default="prod"
        ),
        JobParameter(
            name="processed_records",
            default=""
        ),
        JobParameter(
            name="is_integration_hub",
            default="1"
        ),
        JobParameter(
            name="catalog_name",
            default=str(catalog_name)
        ),
        JobParameter(
            name="to_emails",
            default=','.join(to_emails)
        ),
        JobParameter(
            name="secret_scope_name",
            default=self._get_secret_scope_name()
        ),
        ]  
        schedule=CronSchedule(
                quartz_cron_expression=quartz_cron_expression,
                timezone_id='UTC'
            )
        email_notifcations=JobEmailNotifications(
                on_failure=created_by)
        return [job_cluster,tasks_list,job_parameters_list,schedule,email_notifcations]
    
    def create_tasks_and_job_integration(self, entity_id, model_id, to_emails, quartz_cron_expression, created_by):
        catalog_name = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
            .config_value
        )

        tags = get_resource_tags()
        if tags is None:
            tags = {}

        job_cluster = None

        parameters = {
            "entity_id": str(entity_id),
            "experiment_id": "prod",
            "to_emails": ','.join(to_emails),
            "processed_records": "",
            "is_integration_hub": "1",
            "catalog_name": str(catalog_name),
            "secret_scope_name": self._get_secret_scope_name(),
        }

        tasks_list = [

            # ============================================================
            # ---------------------- PARSE + MASTER CHECK -----------------
            # ============================================================

            Task(
                task_key="Parse_Entity_Model_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Check_Master_Exists",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Check_Master_Exists",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Check_Master_Exists",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Run_Migration",
                depends_on=[TaskDependency(task_key="Check_Master_Exists")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/migration-utilities/Run Migrations",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Is_Initial_Load_Check",
                depends_on=[TaskDependency(task_key="Run_Migration")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Check_Master_Exists.values.is_initial_load}}",
                    right="true",
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # -------------------------- INITIAL LOAD ---------------------
            # ============================================================

            Task(
                task_key="Validate_Initial_Load",
                depends_on=[TaskDependency(task_key="Is_Initial_Load_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Validate_Initial_Load",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Validate_Initial_Load",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Create_Tables",
                depends_on=[TaskDependency(task_key="Validate_Initial_Load")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Create_Tables",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Create_Tables",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Load_Primary_Source",
                depends_on=[TaskDependency(task_key="Create_Tables")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Load_Primary_Source",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Load_Primary_Source",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Load_Secondary_Sources",
                depends_on=[TaskDependency(task_key="Load_Primary_Source")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Load_Secondary_Sources",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Load_Secondary_Sources",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ------------------------ INCREMENTAL LOAD -------------------
            # ============================================================

            Task(
                task_key="Process_Incremental_Load",
                depends_on=[TaskDependency(task_key="Is_Initial_Load_Check", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/incremental_load/Incremental_Load_To_Unified",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/incremental_load/Incremental_Load_To_Unified",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ---------------------- ENDPOINTS MAPPING --------------------
            # ============================================================

            Task(
                task_key="Endpoints_Mapping",
                depends_on=[
                    TaskDependency(task_key="Load_Secondary_Sources"),
                    TaskDependency(task_key="Process_Incremental_Load"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Endpoints_Mapping",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Endpoints_Mapping",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            # ========== COMPUTE EMBEDDINGS (no-op for managed mode) ==========

            Task(
                task_key="Compute_Embeddings",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Compute_Embeddings",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ========== ENTITY MATCHING - VECTOR SEARCH (Integration Core) ==========

            Task(
                task_key="Entity_Matching_Vector_Search",
                depends_on=[
                    TaskDependency(task_key="Compute_Embeddings"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Entity_Matching_Vector_Search",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Entity_Matching_Vector_Search",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Entity_Matching_Detereministic",
                depends_on=[
                    TaskDependency(task_key="Entity_Matching_Vector_Search"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Entity_Matching_Vector_Search",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Deterministic",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            # ========== ENTITY MATCHING - LLM (Maven Core) ==========
            
            Task(
                task_key="Entity_Matching_LLM",
                depends_on=[TaskDependency(task_key="Entity_Matching_Detereministic")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Entity_Matching_LLM",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Entity_Matching_LLM",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            # ========== EXISTING FLOW FROM HERE (Maven Core) ==========
            
            Task(
                task_key="Process_Auto_Merge",
                depends_on=[TaskDependency(task_key="Entity_Matching_LLM")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Process_Auto_Merge",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Auto_Merge",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_Unmatched_Records",
                depends_on=[TaskDependency(task_key="Process_Auto_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Process_Unmatched_Records",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Unmatched_Records",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_Potential_Match_Table",
                depends_on=[TaskDependency(task_key="Process_Unmatched_Records")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Update_Table_Metadata",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Update_Table_Metadata",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Update_Table_Metadata",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_CrossWalk",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_Warning",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Warning Records",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Warning Records",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="DNB_Integration",
                depends_on=[
                    TaskDependency(task_key="Process_Unmatched_Records"),
                    TaskDependency(task_key="Process_Auto_Merge")
                ],
                run_if=RunIf.AT_LEAST_ONE_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.is_entity_dnb_enabled}}",
                    right="True"
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_DNB_Integration",
                depends_on=[TaskDependency(task_key="DNB_Integration", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/dnb_integration/D&B Match and Monitoring Accelerator",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('dnb_integration', self.db)}/D&B Match and Monitoring Accelerator",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Check_Email_List",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{job.parameters.to_emails}}",
                    right=""
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Send_Email_Notification",
                depends_on=[TaskDependency(task_key="Check_Email_List", outcome=False)],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Send Email Notification",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Send Email Notification",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Resource_Tagging",
                depends_on=[
                    TaskDependency(task_key="Send_Email_Notification"),
                    TaskDependency(task_key="Process_DNB_Integration"),
                    TaskDependency(task_key="Process_CrossWalk")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Resource Tagging",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Resource Tagging",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # RBAC Permissions — must run last, always (even if prior tasks fail)
            # ============================================================
            Task(
                task_key="RBAC_Permissions",
                depends_on=[TaskDependency(task_key="Resource_Tagging")],
                run_if=RunIf.ALL_DONE,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/RBAC_Permissions",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        ]

        job_parameters_list = [
            JobParameter(
                name="entity_id",
                default=str(entity_id)
            ),
            JobParameter(
                name="experiment_id",
                default="prod"
            ),
            JobParameter(
                name="processed_records",
                default=""
            ),
            JobParameter(
                name="is_integration_hub",
                default="1"
            ),
            JobParameter(
                name="catalog_name",
                default=str(catalog_name)
            ),
            JobParameter(
                name="to_emails",
                default=','.join(to_emails)
            ),
            JobParameter(
                name="secret_scope_name",
                default=self._get_secret_scope_name()
            ),
        ]
        
        schedule = self._create_schedule(quartz_cron_expression)
        
        email_notifications = JobEmailNotifications(on_failure=created_by)
        
        return [job_cluster, tasks_list, job_parameters_list, schedule, email_notifications]

    def create_tasks_and_job_golden_deduplication(self,entity_id,model_id,to_emails,quartz_cron_expression,created_by,schedule_status):   
        catalog_name=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "catalog_name").first().config_value)

        tags = get_resource_tags()
        if tags is None:
            tags = {}
        
    
    
        job_cluster=None
        parameters={"entity_id":str(entity_id), "experiment_id":"prod", "to_emails": ','.join(to_emails),"processed_records":"","is_integration_hub":"1","catalog_name":str(catalog_name),"secret_scope_name":self._get_secret_scope_name()}
        
        
        tasks_list = [
            Task(
                task_key="Parse_Entity_Model_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Parse Entity & Model JSON",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Prepare_Tables_DeDuplicate",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Prepare Tables",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Match_Maven_Job_DeDuplicate",
                depends_on=[TaskDependency(task_key="Prepare_Tables_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.NOT_EQUAL,
                    left="{{job.parameters.experiment_id}}",
                    right="prod"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Incremental_Load_Job_DeDuplicate",
                depends_on=[TaskDependency(task_key="Match_Maven_Job_DeDuplicate", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Prepare_Tables_DeDuplicate.values.incremental_load}}",
                    right="True"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Foundational_Model_Serving_Endpoint_Check_DeDuplicate",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.embedding_model_source}}",
                    right="databricks_foundation"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Foundational_Serving_Endpoint_DeDuplicate",
                depends_on=[TaskDependency(
                    task_key="Embedding_Foundational_Model_Serving_Endpoint_Check_DeDuplicate",
                    outcome=True
                )],
            
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Embedding Foundational",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Embedding Foundational",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Model_Serving_Endpoint_Check_DeDuplicate",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.embedding_model_source}}",
                    right="databricks_custom_hugging_face"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Hugging_Face_Serving_Endpoint_DeDuplicate",
                depends_on=[TaskDependency(
                    task_key="Embedding_Model_Serving_Endpoint_Check_DeDuplicate",
                    outcome=True
                )],
            
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Embeddings Hugging Face",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Embeddings Hugging Face",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Foundational_Model_Serving_Endpoint_Check_DeDuplicate",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.llm_model_source}}",
                    right="databricks_foundation"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Foundational_Serving_Endpoint_DeDuplicate",
                depends_on=[TaskDependency(
                    task_key="LLM_Foundational_Model_Serving_Endpoint_Check_DeDuplicate",
                    outcome=True
                )],
            
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/LLM Foundational",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/LLM Foundational",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Model_Serving_Endpoint_Check_DeDuplicate",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.llm_model_source}}",
                    right="databricks_custom_hugging_face"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Hugging_Face_Serving_Endpoint_DeDuplicate",
                depends_on=[TaskDependency(
                    task_key="LLM_Model_Serving_Endpoint_Check_DeDuplicate",
                    outcome=True
                )],
                
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/LLM Hugging Face",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/LLM Hugging Face",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Endpoints_Mapping_DeDuplicate",
                depends_on=[
                    TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=True),
                    TaskDependency(task_key="Match_Maven_Job_DeDuplicate", outcome=False)
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Endpoints Mapping",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Endpoints Mapping",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Delete",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping_DeDuplicate")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Delete",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Insert",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping_DeDuplicate")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Insert",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Updates",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping_DeDuplicate")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Updates",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Unified",
                depends_on=[
                    TaskDependency(task_key="Process_Updates"),
                    TaskDependency(task_key="Process_Insert"),
                    TaskDependency(task_key="Process_Delete")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Unified",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Entity_Matching_Vector_Search_DeDuplicate",
                depends_on=[
                    TaskDependency(task_key="Embedding_Model_Serving_Endpoint_Check_DeDuplicate", outcome=False),
                    TaskDependency(task_key="Embedding_Hugging_Face_Serving_Endpoint_DeDuplicate"),
                    TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=True),
                    TaskDependency(task_key="Embedding_Foundational_Model_Serving_Endpoint_Check_DeDuplicate", outcome=False),
                    TaskDependency(task_key="LLM_Foundational_Serving_Endpoint_DeDuplicate"),
                    TaskDependency(task_key="Embedding_Foundational_Serving_Endpoint_DeDuplicate"),
                    TaskDependency(task_key="LLM_Hugging_Face_Serving_Endpoint_DeDuplicate"),
                    TaskDependency(task_key="LLM_Model_Serving_Endpoint_Check_DeDuplicate", outcome=False),
                    TaskDependency(task_key="LLM_Foundational_Model_Serving_Endpoint_Check_DeDuplicate", outcome=False),
                    TaskDependency(task_key="Process_Unified")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Entity Matching - Vector Search",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Entity_Matching_LLM_DeDuplicate",
                depends_on=[TaskDependency(task_key="Entity_Matching_Vector_Search_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Entity Matching - LLM",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Merge_Records_Check_DeDuplicate",
                depends_on=[TaskDependency(task_key="Entity_Matching_LLM_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{job.parameters.experiment_id}}",
                    right="prod"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Process_Match_Merge_Records_DeDuplicate",
                depends_on=[TaskDependency(task_key="Merge_Records_Check_DeDuplicate", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Match - Merge Records",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Potential_Match_Table_DeDuplicate",
                depends_on=[TaskDependency(task_key="Process_Match_Merge_Records_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Potential Match Table",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Update_Table_Metadata_DeDuplicate",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Update Table Metadata",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_CrossWalk",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Cross Walk",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Warning",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Warning Records",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Warning Records",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="DNB_Integration",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table_DeDuplicate"),TaskDependency(task_key="Process_Match_Merge_Records_DeDuplicate")],
                run_if=RunIf.AT_LEAST_ONE_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.is_entity_dnb_enabled}}",
                    right="True"
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_DNB_Integration",
                depends_on=[TaskDependency(task_key="DNB_Integration",outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/dnb_integration/D&B Match and Monitoring Accelerator",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('dnb_integration', self.db)}/D&B Match and Monitoring Accelerator",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Check_Email_List",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{job.parameters.to_emails}}",
                    right=""
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Send_Email_Notification",
                depends_on=[
                    TaskDependency(task_key="Check_Email_List",outcome=False)
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Send Email Notification",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Send Email Notification",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Resource_Tagging",
                depends_on=[
                    TaskDependency(task_key="Send_Email_Notification"),
                    TaskDependency(task_key="Process_DNB_Integration"),
                    TaskDependency(task_key="Process_CrossWalk")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Resource Tagging",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Resource Tagging",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # RBAC Permissions — must run last, always (even if prior tasks fail)
            # ============================================================
            Task(
                task_key="RBAC_Permissions",
                depends_on=[TaskDependency(task_key="Resource_Tagging")],
                run_if=RunIf.ALL_DONE,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/RBAC_Permissions",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        ]
        job_parameters_list = [
        JobParameter(
            name="entity_id",
            default=str(entity_id)
        ),
        JobParameter(
            name="experiment_id",
            default="prod"
        ),
        JobParameter(
            name="processed_records",
            default=""
        ),
        JobParameter(
            name="is_integration_hub",
            default="1"
        ),
        JobParameter(
            name="catalog_name",
            default=str(catalog_name)
        ),
        JobParameter(
            name="to_emails",
            default=','.join(to_emails)
        ),
        JobParameter(
            name="secret_scope_name",
            default=self._get_secret_scope_name()
        ),
        ]  
        force_pause = schedule_status.upper() == "PAUSED"
        schedule = self._create_schedule(quartz_cron_expression, force_pause=force_pause)
        email_notifcations = JobEmailNotifications(on_failure=created_by)
        return [job_cluster, tasks_list, job_parameters_list, schedule, email_notifcations]

    def create_tasks_and_job_golden_dedup_integration(self, entity_id, model_id, to_emails, quartz_cron_expression, created_by, schedule_status):
        catalog_name = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
            .config_value
        )

        tags = get_resource_tags()
        if tags is None:
            tags = {}

        job_cluster = None

        parameters = {
            "entity_id": str(entity_id),
            "experiment_id": "prod",
            "to_emails": ','.join(to_emails),
            "processed_records": "",
            "is_integration_hub": "1",
            "catalog_name": str(catalog_name),
            "secret_scope_name": self._get_secret_scope_name(),
        }

        tasks_list = [

            # ============================================================
            # ---------------------- PARSE + MASTER CHECK -----------------
            # ============================================================

            Task(
                task_key="Parse_Entity_Model_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Check_Master_Exists",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Check_Master_Exists",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Check_Master_Exists",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Run_Migration",
                depends_on=[TaskDependency(task_key="Check_Master_Exists")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/migration-utilities/Run Migrations",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ------------- SINGLE SOURCE: INITIAL LOAD CHECK -------------
            # ============================================================

            Task(
                task_key="Is_Initial_Load_Check",
                depends_on=[TaskDependency(task_key="Run_Migration")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Check_Master_Exists.values.is_initial_load}}",
                    right="true",
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ----------- SINGLE SOURCE: INITIAL LOAD BRANCH --------------
            # ============================================================

            Task(
                task_key="Validate_Initial_Load",
                depends_on=[TaskDependency(task_key="Is_Initial_Load_Check", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Validate_Initial_Load",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Validate_Initial_Load",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Create_Tables",
                depends_on=[TaskDependency(task_key="Validate_Initial_Load")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Create_Tables",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Create_Tables",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Load_Primary_Source",
                depends_on=[TaskDependency(task_key="Create_Tables")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Load_Primary_Source",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Load_Primary_Source",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Load_Secondary_Sources",
                depends_on=[TaskDependency(task_key="Load_Primary_Source")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/initial_load/Load_Secondary_Sources",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/initial_load/Load_Secondary_Sources",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ------------------- GOLDEN DEDUP UNIFIED TABLE --------------
            # ============================================================

            Task(
                task_key="Process_Unified_Dedup_Table",
                depends_on=[
                    TaskDependency(task_key="Load_Secondary_Sources"),
                    TaskDependency(task_key="Is_Initial_Load_Check", outcome=False),   # Multi source incremental
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Process_Unified_Dedup_Table",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Unified_Dedup_Table",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ---------------------- ENDPOINTS MAPPING --------------------
            # ============================================================

            Task(
                task_key="Endpoints_Mapping",
                depends_on=[
                    TaskDependency(task_key="Process_Unified_Dedup_Table"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Endpoints_Mapping",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Endpoints_Mapping",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            # ============================================================
            # ========== COMPUTE EMBEDDINGS (no-op for managed mode) =====
            # ============================================================

            Task(
                task_key="Compute_Embeddings",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Compute_Embeddings",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # ------------ ENTITY MATCHING - GOLDEN DEDUPLICATION ---------
            # ============================================================

            Task(
                task_key="Entity_Matching_Vector_Search",
                depends_on=[
                    TaskDependency(task_key="Compute_Embeddings"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Entity_Matching_Vector_Search",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Entity_Matching_Vector_Search",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Entity_Matching_Detereministic",
                depends_on=[
                    TaskDependency(task_key="Entity_Matching_Vector_Search"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Entity_Matching_Vector_Search",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Deterministic",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Entity_Matching_LLM",
                depends_on=[TaskDependency(task_key="Entity_Matching_Detereministic")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Entity_Matching_LLM",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Entity_Matching_LLM",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_Auto_Merge",
                depends_on=[TaskDependency(task_key="Entity_Matching_LLM")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Process_Auto_Merge",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Auto_Merge",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            # ============================================================
            # -------------- POTENTIAL MATCH & METADATA -------------------
            # ============================================================
            
            Task(
                task_key="Process_Potential_Match_Table",
                depends_on=[TaskDependency(task_key="Process_Auto_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Potential_Match",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Is_Single_Source",
                depends_on=[TaskDependency(task_key="Process_Auto_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.is_single_source}}",
                    right="true",
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Process_Potential_Match_Normal",
                depends_on=[TaskDependency(task_key="Is_Single_Source", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Update_Table_Metadata",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/golden_deduplication/Update_Table_Metadata",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Update_Table_Metadata",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            # ============================================================
            # --------------- CROSSWALK & WARNING RECORDS -----------------
            # ============================================================
            
            Task(
                task_key="Process_CrossWalk",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_Warning",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Warning Records",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Warning Records",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            # ============================================================
            # ---------------------- DNB INTEGRATION ----------------------
            # ============================================================
            
            Task(
                task_key="DNB_Integration",
                depends_on=[
                    TaskDependency(task_key="Process_Auto_Merge")
                ],
                run_if=RunIf.AT_LEAST_ONE_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.is_entity_dnb_enabled}}",
                    right="True"
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_DNB_Integration",
                depends_on=[TaskDependency(task_key="DNB_Integration", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/dnb_integration/D&B Match and Monitoring Accelerator",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('dnb_integration', self.db)}/D&B Match and Monitoring Accelerator",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            # ============================================================
            # ------------------- EMAIL NOTIFICATION ----------------------
            # ============================================================
            
            Task(
                task_key="Check_Email_List",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{job.parameters.to_emails}}",
                    right=""
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Send_Email_Notification",
                depends_on=[TaskDependency(task_key="Check_Email_List", outcome=False)],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Send Email Notification",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Send Email Notification",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            
            # ============================================================
            # -------------------- RESOURCE TAGGING -----------------------
            # ============================================================

            Task(
                task_key="Resource_Tagging",
                depends_on=[
                    TaskDependency(task_key="Send_Email_Notification"),
                    TaskDependency(task_key="Process_DNB_Integration"),
                    TaskDependency(task_key="Process_CrossWalk")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Resource Tagging",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Resource Tagging",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # ============================================================
            # RBAC Permissions — must run last, always (even if prior tasks fail)
            # ============================================================
            Task(
                task_key="RBAC_Permissions",
                depends_on=[TaskDependency(task_key="Resource_Tagging")],
                run_if=RunIf.ALL_DONE,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/RBAC_Permissions",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        ]

        job_parameters_list = [
            JobParameter(
                name="entity_id",
                default=str(entity_id)
            ),
            JobParameter(
                name="experiment_id",
                default="prod"
            ),
            JobParameter(
                name="processed_records",
                default=""
            ),
            JobParameter(
                name="is_integration_hub",
                default="1"
            ),
            JobParameter(
                name="catalog_name",
                default=str(catalog_name)
            ),
            JobParameter(
                name="to_emails",
                default=','.join(to_emails)
            ),
            JobParameter(
                name="secret_scope_name",
                default=self._get_secret_scope_name()
            ),
        ]
        
        force_pause = schedule_status.upper() == "PAUSED"
        schedule = self._create_schedule(quartz_cron_expression, force_pause=force_pause)
        
        email_notifications = JobEmailNotifications(on_failure=created_by)
        
        return [job_cluster, tasks_list, job_parameters_list, schedule, email_notifications]

    def update_job(self, task_id:int,pipeline_type,quartz_cron_expression,created_by,token):
        try:
            job_service = DatabricksJobManager(token)
            integration_hub_query = (
                self.db.query(Integration_Hub).filter_by(id==task_id)
            )
            if not integration_hub_query:
                raise Exception("No Integration Hub Pipeline found")
            job_id=integration_hub_query.job_id
            job_service.update_job(job_id,quartz_cron_expression)
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks and job configuration. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create tasks and job configuration: {str(e)}")

    def create_job(self, task_name: str, entity_id: int, model_id: str, is_traditional_pipeline, 
                traditional_quartz_cron_expression, is_golden_deduplication_pipeline, 
                golden_deduplication_quartz_cron_expression, to_emails, created_by, token):
        try:
            job_service = DatabricksJobManager(token)
            lakefusion_spn = (self.db.query(DBConfigProperties)
                            .filter(DBConfigProperties.config_key == "lakefusion_spn")
                            .first().config_value)
            
            integration_hub_enabled = FeatureFlagService._is_feature_flag_enabled(
                self.db,
                'MDM_RESTRUCTURING'
            )
            
            if is_traditional_pipeline == 1 and is_golden_deduplication_pipeline == 0:
                # Choose pipeline creation method based on feature flag
                if integration_hub_enabled:
                    app_logger.info("Using Integration Hub pipeline (feature flag enabled)")
                    task_list_response = self.create_tasks_and_job_integration(
                        entity_id, model_id, to_emails, 
                        traditional_quartz_cron_expression, created_by
                    )
                else:
                    app_logger.info("Using Traditional pipeline (feature flag disabled or not found)")
                    task_list_response = self.create_tasks_and_job_traditional(
                        entity_id, model_id, to_emails, 
                        traditional_quartz_cron_expression, created_by
                    )
                
                job_create_response_1 = job_service.create_job(
                    task_name, 
                    task_list_response[0],
                    tasks_list=task_list_response[1],
                    job_parameters=task_list_response[2],
                    schedule=task_list_response[3],
                    email_notifcations=task_list_response[4],
                    RunAs=lakefusion_spn
                )
                
                # Choose golden deduplication pipeline based on feature flag
                if integration_hub_enabled:
                    app_logger.info("Using Golden Dedup Integration Hub pipeline (feature flag enabled)")
                    task_list_response_deduplication = self.create_tasks_and_job_golden_dedup_integration(
                        entity_id, model_id, to_emails, 
                        golden_deduplication_quartz_cron_expression, 
                        created_by, schedule_status="PAUSED"
                    )
                else:
                    app_logger.info("Using Traditional Golden Dedup pipeline (feature flag disabled)")
                    task_list_response_deduplication = self.create_tasks_and_job_golden_deduplication(
                        entity_id, model_id, to_emails, 
                        golden_deduplication_quartz_cron_expression, 
                        created_by, schedule_status="PAUSED"
                    )
                
                job_create_response_2 = job_service.create_job(
                    f"Golden_Deduplication_{task_name}", 
                    task_list_response_deduplication[0],
                    tasks_list=task_list_response_deduplication[1],
                    job_parameters=task_list_response_deduplication[2],
                    schedule=task_list_response_deduplication[3],
                    email_notifcations=task_list_response_deduplication[4],
                    RunAs=lakefusion_spn
                )
                
                return (job_create_response_1, job_create_response_2)
            
            elif is_traditional_pipeline == 1 and is_golden_deduplication_pipeline == 1:
                # Choose pipeline creation method based on feature flag
                if integration_hub_enabled:
                    app_logger.info("Using Integration Hub pipeline (feature flag enabled)")
                    task_list_response = self.create_tasks_and_job_integration(
                        entity_id, model_id, to_emails, 
                        traditional_quartz_cron_expression, created_by
                    )
                else:
                    app_logger.info("Using Traditional pipeline (feature flag disabled)")
                    task_list_response = self.create_tasks_and_job_traditional(
                        entity_id, model_id, to_emails, 
                        traditional_quartz_cron_expression, created_by
                    )
                
                job_create_response_1 = job_service.create_job(
                    task_name, 
                    task_list_response[0],
                    tasks_list=task_list_response[1],
                    job_parameters=task_list_response[2],
                    schedule=task_list_response[3],
                    email_notifcations=task_list_response[4],
                    RunAs=lakefusion_spn
                )
                
                # Choose golden deduplication pipeline based on feature flag
                if integration_hub_enabled:
                    app_logger.info("Using Golden Dedup Integration Hub pipeline (feature flag enabled)")
                    task_list_response_deduplication = self.create_tasks_and_job_golden_dedup_integration(
                        entity_id, model_id, to_emails, 
                        golden_deduplication_quartz_cron_expression, 
                        created_by, schedule_status="UNPAUSED"
                    )
                else:
                    app_logger.info("Using Traditional Golden Dedup pipeline (feature flag disabled)")
                    task_list_response_deduplication = self.create_tasks_and_job_golden_deduplication(
                        entity_id, model_id, to_emails, 
                        golden_deduplication_quartz_cron_expression, 
                        created_by, schedule_status="UNPAUSED"
                    )
                
                job_create_response_2 = job_service.create_job(
                    f"Golden_Deduplication_{task_name}", 
                    task_list_response_deduplication[0],
                    tasks_list=task_list_response_deduplication[1],
                    job_parameters=task_list_response_deduplication[2],
                    schedule=task_list_response_deduplication[3],
                    email_notifcations=task_list_response_deduplication[4],
                    RunAs=lakefusion_spn
                )
                
                return (job_create_response_1, job_create_response_2)
            
            elif is_golden_deduplication_pipeline == 1 and is_traditional_pipeline == 0:
                # Choose golden deduplication pipeline based on feature flag
                if integration_hub_enabled:
                    app_logger.info("Using Golden Dedup Integration Hub pipeline (feature flag enabled)")
                    task_list_response = self.create_tasks_and_job_golden_dedup_integration(
                        entity_id, model_id, to_emails, 
                        golden_deduplication_quartz_cron_expression, 
                        created_by, schedule_status="UNPAUSED"
                    )
                else:
                    app_logger.info("Using Traditional Golden Dedup pipeline (feature flag disabled)")
                    task_list_response = self.create_tasks_and_job_golden_deduplication(
                        entity_id, model_id, to_emails, 
                        golden_deduplication_quartz_cron_expression, 
                        created_by, schedule_status="UNPAUSED"
                    )
                
                job_create_response_2 = job_service.create_job(
                    f"Golden_Deduplication_{task_name}", 
                    task_list_response[0],
                    tasks_list=task_list_response[1],
                    job_parameters=task_list_response[2],
                    schedule=task_list_response[3],
                    email_notifcations=task_list_response[4],
                    RunAs=lakefusion_spn
                )
                
                return (None, job_create_response_2)
                
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks and job configuration. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create tasks and job configuration: {str(e)}")
    
    def create_tasks_and_job_golden_deduplication_v1(self,entity_id,model_id,to_emails,quartz_cron_expression,created_by):   
    
        catalog_name=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "catalog_name").first().config_value)

        tags = get_resource_tags()
        if tags is None:
            tags = {}
        
        job_cluster=None
        parameters={"entity_id":str(entity_id), "experiment_id":"prod", "to_emails": ','.join(to_emails),"processed_records":"","is_integration_hub":"1","catalog_name":str(catalog_name),"secret_scope_name":self._get_secret_scope_name()}
        
        
        tasks_list = [
            Task(
                task_key="Parse_Entity_Model_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Parse Entity & Model JSON",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Prepare_Tables_DeDuplicate",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Prepare Tables",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Match_Maven_Job_DeDuplicate",
                depends_on=[TaskDependency(task_key="Prepare_Tables_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.NOT_EQUAL,
                    left="{{job.parameters.experiment_id}}",
                    right="prod"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Incremental_Load_Job_DeDuplicate",
                depends_on=[TaskDependency(task_key="Match_Maven_Job_DeDuplicate", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Prepare_Tables_DeDuplicate.values.incremental_load}}",
                    right="True"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Foundational_Model_Serving_Endpoint_Check_DeDuplicate",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.embedding_model_source}}",
                    right="databricks_foundation"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Foundational_Serving_Endpoint_DeDuplicate",
                depends_on=[TaskDependency(
                    task_key="Embedding_Foundational_Model_Serving_Endpoint_Check_DeDuplicate",
                    outcome=True
                )],
            
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Embedding Foundational",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Embedding Foundational",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Model_Serving_Endpoint_Check_DeDuplicate",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.embedding_model_source}}",
                    right="databricks_custom_hugging_face"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Embedding_Hugging_Face_Serving_Endpoint_DeDuplicate",
                depends_on=[TaskDependency(
                    task_key="Embedding_Model_Serving_Endpoint_Check_DeDuplicate",
                    outcome=True
                )],
            
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Embeddings Hugging Face",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Embeddings Hugging Face",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Foundational_Model_Serving_Endpoint_Check_DeDuplicate",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.llm_model_source}}",
                    right="databricks_foundation"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Foundational_Serving_Endpoint_DeDuplicate",
                depends_on=[TaskDependency(
                    task_key="LLM_Foundational_Model_Serving_Endpoint_Check_DeDuplicate",
                    outcome=True
                )],
            
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/LLM Foundational",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/LLM Foundational",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Model_Serving_Endpoint_Check_DeDuplicate",
                depends_on=[TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=False)],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.llm_model_source}}",
                    right="databricks_custom_hugging_face"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="LLM_Hugging_Face_Serving_Endpoint_DeDuplicate",
                depends_on=[TaskDependency(
                    task_key="LLM_Model_Serving_Endpoint_Check_DeDuplicate",
                    outcome=True
                )],
            
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/LLM Hugging Face",  # Updated path
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/LLM Hugging Face",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Endpoints_Mapping_DeDuplicate",
                depends_on=[
                    TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=True),
                    TaskDependency(task_key="Match_Maven_Job_DeDuplicate", outcome=False)
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Endpoints Mapping",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Endpoints Mapping",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Delete",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping_DeDuplicate")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Delete",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Insert",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping_DeDuplicate")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Insert",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Updates",
                depends_on=[
                    TaskDependency(task_key="Endpoints_Mapping_DeDuplicate")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Updates",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Unified",
                depends_on=[
                    TaskDependency(task_key="Process_Updates"),
                    TaskDependency(task_key="Process_Insert"),
                    TaskDependency(task_key="Process_Delete")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Unified",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Entity_Matching_Vector_Search_DeDuplicate",
                depends_on=[
                    TaskDependency(task_key="Embedding_Model_Serving_Endpoint_Check_DeDuplicate", outcome=False),
                    TaskDependency(task_key="Embedding_Hugging_Face_Serving_Endpoint_DeDuplicate"),
                    TaskDependency(task_key="Incremental_Load_Job_DeDuplicate", outcome=True),
                    TaskDependency(task_key="Embedding_Foundational_Model_Serving_Endpoint_Check_DeDuplicate", outcome=False),
                    TaskDependency(task_key="LLM_Foundational_Serving_Endpoint_DeDuplicate"),
                    TaskDependency(task_key="Embedding_Foundational_Serving_Endpoint_DeDuplicate"),
                    TaskDependency(task_key="LLM_Hugging_Face_Serving_Endpoint_DeDuplicate"),
                    TaskDependency(task_key="LLM_Model_Serving_Endpoint_Check_DeDuplicate", outcome=False),
                    TaskDependency(task_key="LLM_Foundational_Model_Serving_Endpoint_Check_DeDuplicate", outcome=False),
                    TaskDependency(task_key="Process_Unified")
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Entity Matching - Vector Search",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Entity_Matching_LLM_DeDuplicate",
                depends_on=[TaskDependency(task_key="Entity_Matching_Vector_Search_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Entity Matching - LLM",  # Updated path
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Merge_Records_Check_DeDuplicate",
                depends_on=[TaskDependency(task_key="Entity_Matching_LLM_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{job.parameters.experiment_id}}",
                    right="prod"
                ),
                timeout_seconds=0,
            ),
        
            Task(
                task_key="Process_Match_Merge_Records_DeDuplicate",
                depends_on=[TaskDependency(task_key="Merge_Records_Check_DeDuplicate", outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Match - Merge Records",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Process_Potential_Match_Table_DeDuplicate",
                depends_on=[TaskDependency(task_key="Process_Match_Merge_Records_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/maven-core-deduplication/Process Potential Match Table",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),  
            Task(
                task_key="Process_CrossWalk",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Process Cross Walk",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="DNB_Integration",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table_DeDuplicate"),TaskDependency(task_key="Process_Match_Merge_Records_DeDuplicate")],
                run_if=RunIf.AT_LEAST_ONE_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{tasks.Parse_Entity_Model_JSON.values.is_entity_dnb_enabled}}",
                    right="True"
                ),
                timeout_seconds=0,
            ),
            
            Task(
                task_key="Process_DNB_Integration",
                depends_on=[TaskDependency(task_key="DNB_Integration",outcome=True)],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/dnb_integration/D&B Match and Monitoring Accelerator",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('dnb_integration', self.db)}/D&B Match and Monitoring Accelerator",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Check_Email_List",
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table_DeDuplicate")],
                run_if=RunIf.ALL_SUCCESS,
                condition_task=ConditionTask(
                    op=ConditionTaskOp.EQUAL_TO,
                    left="{{job.parameters.to_emails}}",
                    right=""
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Send_Email_Notification",
                depends_on=[
                    TaskDependency(task_key="Check_Email_List",outcome=False)
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/maven-core/Send Email Notification",  # New task
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('maven-core', self.db)}/Send Email Notification",  # New task
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        ]
        job_parameters_list = [
        JobParameter(
            name="entity_id",
            default=str(entity_id)
        ),
        JobParameter(
            name="experiment_id",
            default="prod"
        ),
        JobParameter(
            name="processed_records",
            default=""
        ),
        JobParameter(
            name="is_integration_hub",
            default="1"
        ),
        JobParameter(
            name="catalog_name",
            default=str(catalog_name)
        ),
        JobParameter(
            name="to_emails",
            default=','.join(to_emails)
        ),
        JobParameter(
            name="secret_scope_name",
            default=self._get_secret_scope_name()
        ),
        ]  
        schedule=CronSchedule(
                quartz_cron_expression=quartz_cron_expression,
                timezone_id='UTC'
            )
        email_notifcations=JobEmailNotifications(
                on_failure=created_by)
        return [job_cluster,tasks_list,job_parameters_list,schedule,email_notifcations]     
    
        
    def create_dashboard(self, entity_id:int,warehouse_id:str,token: str):
        try:
            
            entity_service = EntityService(db=self.db)
            entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if entity is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail={
                        "status": "error",
                        "message": "Entity not found",
                        "data": None
                    }
                )
            entity_name = entity.name.lower().replace(' ', '_')

            entity_dataset = entity.datasets
            
            
            # Build UNION ALL SQL
            union_queries = []
            for ds in entity_dataset:
                #column = ds["primary_field"] if ds["primary_field"] else "id"
                table = ds.path
                source = ds.path.split('.')[2]
                union_queries.append(f'select count(*) as total_records, "{source}" as source from {table}')
            
            
            
            datatset_query = f"""select *
            from (
                {'  union all '.join(union_queries)}
            ) 
            """
            
            
            catalog_name=self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "catalog_name").first().config_value
            merge_activities_table=f"{catalog_name}.gold.{entity_name}_master_prod_merge_activities"
            master_potential=f"{catalog_name}.gold.{entity_name}_master_potential_match_prod"
            attributes = entity.attributes
            primary_key = next((attr for attr in attributes if attr.is_primary_key), None)
            merged_status = (
                "INITIAL_LOAD",
                "JOB_INSERT",
                "JOB_MERGE",
                "MANUAL_MERGE",
                "MASTER_JOB_MERGE",
                "MASTER_MANUAL_MERGE",
                "MASTER_FORCE_MERGE",
                "PROMOTED_TO_MASTER",
                "MERGED",
            )
            merged_status_string = ','.join([f"'{status}'" for status in merged_status])    
            json_data={"datasets": [
                                    {
                                        "name": "270b84f7",
                                        "displayName": "Potential_Matches",
                                        "queryLines": [
                                        "with cte_2\n",
                                        "as (\n",
                                        "SELECT *,ROW_NUMBER() OVER (PARTITION BY master_id order by version desc) as rn1 \n",
                                        "from " + f"{merge_activities_table}" + "\n",
                                        ")\n",
                                        "\n",
                                        "select count(master_id) as total_master_records,split_part(source,'.',-1) as source  from (\n",
                                        "select lakefusion_id,case when source<>'' then source else ''  end as source from (\n",
                                        "select distinct master_id,source,action_type\n",
                                        "from cte_2  where rn1=1\n",
                                        ") \n",
                                        ")  group by source"
                                        ],
                                        "catalog": f"{catalog_name}",
                                        "schema": "bronze"
                                    },
                                    {
                                        "name": "f7f072a6",
                                        "displayName": "Combined Source IDs Dataset",
                                        "queryLines": [datatset_query],
                                        "catalog": f"{catalog_name}",
                                        "schema": "bronze"
                                    },
                                    {
                                        "name": "01ca7597",
                                        "displayName": "Potential_matches-Pending",
                                        "queryLines": [
                                        "select count( distinct " + f"{primary_key.name}"+") as total_master,count(AUTO_MERGED) as total_auto_merged, \"MERGED\" as Type\n",
                                        "from (\n",
                                        "select distinct " + f"{primary_key.name}"+",potential_matches_1.__sourcename__ as source_system, case WHEN potential_matches_1.__mergestatus__ in " + merged_status_string + " THEN 1 END AS AUTO_MERGED, \n",
                                        "case WHEN potential_matches_1.__mergestatus__='PENDING' THEN 1 END AS PENDING\n",
                                        "from (\n",
                                        "select *,explode(potential_matches) as potential_matches_1 \n",
                                        "from "+f"{master_potential}"+"\n",
                                        ") \n",
                                        ") \n",
                                        "union all\n",
                                        "select count( distinct " + f"{primary_key.name}"+") as total_master,count(AUTO_MERGED) as total_auto_merged, \"PENDING\" as Type\n",
                                        "from (\n",
                                        "select distinct " + f"{primary_key.name}"+",potential_matches_1.__sourcename__ as source_system, case WHEN potential_matches_1.__mergestatus__='PENDING' THEN 1 END AS AUTO_MERGED, \n",
                                        "case WHEN potential_matches_1.__mergestatus__='PENDING' THEN 1 END AS PENDING\n",
                                        "from (\n",
                                        "select *,explode(potential_matches) as potential_matches_1 \n",
                                        "from "+ f"{master_potential}"+"\n",
                                        ") \n",
                                        ") \n",
                                        "\n",
                                        "\n"
                                        ],
                                        "catalog": f"{catalog_name}",
                                        "schema": "bronze"
                                    },
                                    {
                                        "name": "b107005d",
                                        "displayName": "No Match found",
                                        "queryLines": [
                                        "with cte_2\n",
                                        "as (\n",
                                        "SELECT *,ROW_NUMBER() OVER (PARTITION BY master_id order by version desc) as rn1 \n",
                                        "from "+ f"{merge_activities_table}"+"\n",
                                        ")\n",
                                        "\n",
                                        "select COUNT(distinct master_id) as total_records,split_part(source,'.',-1) as source\n",
                                        "from cte_2 \n",
                                        "where  rn1=1 and action_type in ('INITIAL_LOAD','JOB_INSERT')\n",
                                        "group by source ,action_type"
                                        ],
                                        "catalog": f"{catalog_name}",
                                        "schema": "bronze"
                                    }
                                    ],
                                    "pages": [
                                                {
                                                "name": "f46f9aee",
                                                "displayName": "Dashboard",
                                                "layout": [
                                                    {
                                                    "widget": {
                                                        "name": "e577afaa",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "f7f072a6",
                                                            "fields": [
                                                                {
                                                                "name": "source",
                                                                "expression": "`source`"
                                                                },
                                                                {
                                                                "name": "sum(total_records)",
                                                                "expression": "SUM(`total_records`)"
                                                                }
                                                            ],
                                                            "disaggregated": False
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 3,
                                                        "widgetType": "bar",
                                                        "encodings": {
                                                            "x": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical",
                                                                "sort": {
                                                                "by": "y-reversed"
                                                                }
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "y": {
                                                            "fieldName": "sum(total_records)",
                                                            "scale": {
                                                                "type": "quantitative"
                                                            },
                                                            "displayName": "Total Records"
                                                            },
                                                            "color": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical"
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "label": {
                                                            "show": True
                                                            }
                                                        },
                                                        "frame": {
                                                            "showDescription": True,
                                                            "title": "Total Records inserted into Lakefusion for matching",
                                                            "showTitle": True
                                                        },
                                                        "mark": {
                                                            "colors": [
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 4
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 2
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 3
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 4
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 5
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 6
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 7
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 8
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 9
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 10
                                                            }
                                                            ]
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 0,
                                                        "y": 0,
                                                        "width": 6,
                                                        "height": 6
                                                    }
                                                    },
                                                    {
                                                    "widget": {
                                                        "name": "9863788e",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "270b84f7",
                                                            "fields": [
                                                                {
                                                                "name": "source",
                                                                "expression": "`source`"
                                                                },
                                                                {
                                                                "name": "total_master_records",
                                                                "expression": "`total_master_records`"
                                                                }
                                                            ],
                                                            "disaggregated": True
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 3,
                                                        "widgetType": "bar",
                                                        "encodings": {
                                                            "x": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical"
                                                            },
                                                            "axis": {
                                                                "title": "source"
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "y": {
                                                            "fieldName": "total_master_records",
                                                            "scale": {
                                                                "type": "quantitative"
                                                            },
                                                            "axis": {
                                                                "title": "Total Master Records"
                                                            },
                                                            "displayName": "Total Master Records"
                                                            },
                                                            "color": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical",
                                                                "mappings": [
                                                                {
                                                                    "value": "aggk_company",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 1
                                                                    }
                                                                },
                                                                {
                                                                    "value": "ciq_company",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 2
                                                                    }
                                                                }
                                                                ]
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "label": {
                                                            "show": True
                                                            }
                                                        },
                                                        "frame": {
                                                            "title": "Golden Records Created/Updated -All Master Records - Source Wise\n",
                                                            "showTitle": True
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 0,
                                                        "y": 12,
                                                        "width": 3,
                                                        "height": 6
                                                    }
                                                    },
                                                    {
                                                    "widget": {
                                                        "name": "a9a05080",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "01ca7597",
                                                            "fields": [
                                                                {
                                                                "name": "sum(total_auto_merged)",
                                                                "expression": "SUM(`total_auto_merged`)"
                                                                },
                                                                {
                                                                "name": "Type",
                                                                "expression": "`Type`"
                                                                }
                                                            ],
                                                            "disaggregated": False
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 3,
                                                        "widgetType": "pie",
                                                        "encodings": {
                                                            "angle": {
                                                            "fieldName": "sum(total_auto_merged)",
                                                            "scale": {
                                                                "type": "quantitative"
                                                            },
                                                            "axis": {
                                                                "title": "Total Potential Matches Record"
                                                            },
                                                            "format": {
                                                                "type": "number-plain",
                                                                "abbreviation": "compact",
                                                                "decimalPlaces": {
                                                                "type": "all"
                                                                }
                                                            },
                                                            "displayName": "Total Potential Matches Record"
                                                            },
                                                            "color": {
                                                            "fieldName": "Type",
                                                            "scale": {
                                                                "type": "categorical",
                                                                "mappings": [
                                                                {
                                                                    "value": "MERGED",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 3
                                                                    }
                                                                },
                                                                {
                                                                    "value": "PENDING",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 4
                                                                    }
                                                                }
                                                                ]
                                                            },
                                                            "displayName": "Type"
                                                            },
                                                            "label": {
                                                            "show": True
                                                            }
                                                        },
                                                        "frame": {
                                                            "showDescription": False,
                                                            "title": "Potential_Matches  - Auto_Merged/Pending",
                                                            "showTitle": True
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 3,
                                                        "y": 6,
                                                        "width": 3,
                                                        "height": 6
                                                    }
                                                    },
                                                    {
                                                    "widget": {
                                                        "name": "9c96f925",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "b107005d",
                                                            "fields": [
                                                                {
                                                                "name": "source",
                                                                "expression": "`source`"
                                                                },
                                                                {
                                                                "name": "sum(total_records)",
                                                                "expression": "SUM(`total_records`)"
                                                                }
                                                            ],
                                                            "disaggregated": False
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 3,
                                                        "widgetType": "bar",
                                                        "encodings": {
                                                            "x": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical"
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "y": {
                                                            "fieldName": "sum(total_records)",
                                                            "scale": {
                                                                "type": "quantitative"
                                                            },
                                                            "displayName": "Total Records"
                                                            },
                                                            "color": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical",
                                                                "mappings": [
                                                                {
                                                                    "value": "aggk_company",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 1
                                                                    }
                                                                },
                                                                {
                                                                    "value": "ciq_company",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 2
                                                                    }
                                                                }
                                                                ]
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "label": {
                                                            "show": True
                                                            }
                                                        },
                                                        "frame": {
                                                            "title": " Unique Records -Records which doesnt have any matching in any source system",
                                                            "showTitle": True,
                                                            "showDescription": False
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 3,
                                                        "y": 12,
                                                        "width": 3,
                                                        "height": 6
                                                    }
                                                    },
                                                    {
                                                    "widget": {
                                                        "name": "63f37fd2",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "270b84f7",
                                                            "fields": [
                                                                {
                                                                "name": "sum(total_master_records)",
                                                                "expression": "SUM(`total_master_records`)"
                                                                }
                                                            ],
                                                            "disaggregated": False
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 2,
                                                        "widgetType": "counter",
                                                        "encodings": {
                                                            "value": {
                                                            "fieldName": "sum(total_master_records)",
                                                            "format": {
                                                                "type": "number-plain",
                                                                "abbreviation": "compact",
                                                                "decimalPlaces": {
                                                                "type": "exact",
                                                                "places": 3
                                                                }
                                                            },
                                                            "displayName": "Total Master Records"
                                                            }
                                                        },
                                                        "frame": {
                                                            "showTitle": True,
                                                            "title": "All Master Records in Lakefusion"
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 0,
                                                        "y": 9,
                                                        "width": 3,
                                                        "height": 3
                                                    }
                                                    },
                                                    {
                                                    "widget": {
                                                        "name": "c7b87f9e",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "01ca7597",
                                                            "fields": [
                                                                {
                                                                "name": "total_master",
                                                                "expression": "`total_master`"
                                                                }
                                                            ],
                                                            "disaggregated": True
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 2,
                                                        "widgetType": "counter",
                                                        "encodings": {
                                                            "value": {
                                                            "fieldName": "total_master",
                                                            "format": {
                                                                "type": "number-plain",
                                                                "abbreviation": "compact",
                                                                "decimalPlaces": {
                                                                "type": "exact",
                                                                "places": 3
                                                                }
                                                            },
                                                            "displayName": "Total Master"
                                                            }
                                                        },
                                                        "frame": {
                                                            "showTitle": True,
                                                            "title": "Total Potential Matches Records"
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 0,
                                                        "y": 6,
                                                        "width": 3,
                                                        "height": 3
                                                    }
                                                    }
                                                ],
                                                "pageType": "PAGE_TYPE_CANVAS"
                                                }
                                            ],
                                            "uiSettings": {
                                                "theme": {
                                                "widgetHeaderAlignment": "ALIGNMENT_UNSPECIFIED"
                                                }
                                            }
                                            }                       
            dasboard_json=json.dumps(json_data,separators=(',', ':'))
            dashboard=DatabricksDashboard(token)  
            dashboard_info=dashboard.create_dashboard(entity_name,warehouse_id,dasboard_json)
            return dashboard_info       
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create dashboard. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create dashboard: {str(e)}")


    def create_dashboard_updated(self, entity_id:int,warehouse_id:str,token: str):
        try:
            
            entity_service = EntityService(db=self.db)
            entity = entity_service.get_entity_by_id(entity_id=entity_id)
            if entity is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail={
                        "status": "error",
                        "message": "Entity not found",
                        "data": None
                    }
                )
            entity_name = entity.name.lower().replace(' ', '_')

            entity_dataset = entity.datasets
            
            
            # Build UNION ALL SQL
            union_queries = []
            for ds in entity_dataset:
                #column = ds["primary_field"] if ds["primary_field"] else "id"
                table = ds.path
                source = ds.path.split('.')[2]
                union_queries.append(f'select count(*) as total_records, "{source}" as source from {table}')
            
            
            
            datatset_query = f"""select *
            from (
                {'  union all '.join(union_queries)}
            ) 
            """
            
            
            catalog_name=self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "catalog_name").first().config_value
            merge_activities_table=f"{catalog_name}.gold.{entity_name}_master_prod_merge_activities"
            master_potential=f"{catalog_name}.gold.{entity_name}_master_potential_match_prod"
            attributes = entity.attributes
            primary_key = next((attr for attr in attributes if attr.is_primary_key), None)
            merged_status = (
                "INITIAL_LOAD",
                "JOB_INSERT",
                "JOB_MERGE",
                "MANUAL_MERGE",
                "MASTER_JOB_MERGE",
                "MASTER_MANUAL_MERGE",
                "MASTER_FORCE_MERGE",
                "PROMOTED_TO_MASTER",
                "MERGED",
            )
            merged_status_str = "(" + ", ".join([f"'{status}'" for status in merged_status]) + ")"
            json_data={"datasets": [
                                    {
                                        "name": "270b84f7",
                                        "displayName": "Potential_Matches",
                                        "queryLines": [
                                        "with cte_2\n",
                                        "as (\n",
                                        "SELECT *,ROW_NUMBER() OVER (PARTITION BY master_id order by version desc) as rn1 \n",
                                        "from " + f"{merge_activities_table}" + "\n",
                                        ")\n",
                                        "\n",
                                        "select count(master_id) as total_master_records,split_part(source,'.',-1) as source  from (\n",
                                        "select master_id,case when source<>'' then source else ''  end as source from (\n",
                                        "select distinct master_id,source,action_type\n",
                                        "from cte_2  where rn1=1\n",
                                        ") \n",
                                        ")  group by source"
                                        ],
                                        "catalog": f"{catalog_name}",
                                        "schema": "bronze"
                                    },
                                    {
                                        "name": "f7f072a6",
                                        "displayName": "Combined Source IDs Dataset",
                                        "queryLines": [datatset_query],
                                        "catalog": f"{catalog_name}",
                                        "schema": "bronze"
                                    },
                                    {
                                        "name": "01ca7597",
                                        "displayName": "Potential_matches-Pending",
                                        "queryLines": [
                                        "select count( distinct " + f"{primary_key.name}"+") as total_master,count(AUTO_MERGED) as total_auto_merged, \"MERGED\" as Type\n",
                                        "from (\n",
                                        "select distinct " + f"{primary_key.name}"+",potential_matches_1.__source_path__ as source_system, case WHEN potential_matches_1.__mergestatus__ in (" + merged_status_str + ") THEN 1 END AS AUTO_MERGED, \n",
                                        "case WHEN potential_matches_1.__mergestatus__='PENDING' THEN 1 END AS PENDING\n",
                                        "from (\n",
                                        "select *,explode(potential_matches) as potential_matches_1 \n",
                                        "from "+f"{master_potential}"+"\n",
                                        ") \n",
                                        ") \n",
                                        "union all\n",
                                        "select count( distinct " + f"{primary_key.name}"+") as total_master,count(AUTO_MERGED) as total_auto_merged, \"PENDING\" as Type\n",
                                        "from (\n",
                                        "select distinct " + f"{primary_key.name}"+",potential_matches_1.__source_path__ as source_system, case WHEN potential_matches_1.__mergestatus__='PENDING' THEN 1 END AS AUTO_MERGED, \n",
                                        "case WHEN potential_matches_1.__mergestatus__='PENDING' THEN 1 END AS PENDING\n",
                                        "from (\n",
                                        "select *,explode(potential_matches) as potential_matches_1 \n",
                                        "from "+ f"{master_potential}"+"\n",
                                        ") \n",
                                        ") \n",
                                        "\n",
                                        "\n"
                                        ],
                                        "catalog": f"{catalog_name}",
                                        "schema": "bronze"
                                    },
                                    {
                                        "name": "b107005d",
                                        "displayName": "No Match found",
                                        "queryLines": [
                                        "with cte_2\n",
                                        "as (\n",
                                        "SELECT *,ROW_NUMBER() OVER (PARTITION BY master_id order by version desc) as rn1 \n",
                                        "from "+ f"{merge_activities_table}"+"\n",
                                        ")\n",
                                        "\n",
                                        "select COUNT(distinct master_id) as total_records,split_part(source,'.',-1) as source\n",
                                        "from cte_2 \n",
                                        "where  rn1=1 and action_type in ('INITIAL_LOAD','JOB_INSERT')\n",
                                        "group by source ,action_type"
                                        ],
                                        "catalog": f"{catalog_name}",
                                        "schema": "bronze"
                                    }
                                    ],
                                    "pages": [
                                                {
                                                "name": "f46f9aee",
                                                "displayName": "Dashboard",
                                                "layout": [
                                                    {
                                                    "widget": {
                                                        "name": "e577afaa",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "f7f072a6",
                                                            "fields": [
                                                                {
                                                                "name": "source",
                                                                "expression": "`source`"
                                                                },
                                                                {
                                                                "name": "sum(total_records)",
                                                                "expression": "SUM(`total_records`)"
                                                                }
                                                            ],
                                                            "disaggregated": False
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 3,
                                                        "widgetType": "bar",
                                                        "encodings": {
                                                            "x": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical",
                                                                "sort": {
                                                                "by": "y-reversed"
                                                                }
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "y": {
                                                            "fieldName": "sum(total_records)",
                                                            "scale": {
                                                                "type": "quantitative"
                                                            },
                                                            "displayName": "Total Records"
                                                            },
                                                            "color": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical"
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "label": {
                                                            "show": True
                                                            }
                                                        },
                                                        "frame": {
                                                            "showDescription": True,
                                                            "title": "Total Records inserted into Lakefusion for matching",
                                                            "showTitle": True
                                                        },
                                                        "mark": {
                                                            "colors": [
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 4
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 2
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 3
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 4
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 5
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 6
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 7
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 8
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 9
                                                            },
                                                            {
                                                                "themeColorType": "visualizationColors",
                                                                "position": 10
                                                            }
                                                            ]
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 0,
                                                        "y": 0,
                                                        "width": 6,
                                                        "height": 6
                                                    }
                                                    },
                                                    {
                                                    "widget": {
                                                        "name": "9863788e",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "270b84f7",
                                                            "fields": [
                                                                {
                                                                "name": "source",
                                                                "expression": "`source`"
                                                                },
                                                                {
                                                                "name": "total_master_records",
                                                                "expression": "`total_master_records`"
                                                                }
                                                            ],
                                                            "disaggregated": True
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 3,
                                                        "widgetType": "bar",
                                                        "encodings": {
                                                            "x": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical"
                                                            },
                                                            "axis": {
                                                                "title": "source"
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "y": {
                                                            "fieldName": "total_master_records",
                                                            "scale": {
                                                                "type": "quantitative"
                                                            },
                                                            "axis": {
                                                                "title": "Total Master Records"
                                                            },
                                                            "displayName": "Total Master Records"
                                                            },
                                                            "color": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical",
                                                                "mappings": [
                                                                {
                                                                    "value": "aggk_company",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 1
                                                                    }
                                                                },
                                                                {
                                                                    "value": "ciq_company",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 2
                                                                    }
                                                                }
                                                                ]
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "label": {
                                                            "show": True
                                                            }
                                                        },
                                                        "frame": {
                                                            "title": "Golden Records Created/Updated -All Master Records - Source Wise\n",
                                                            "showTitle": True
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 0,
                                                        "y": 12,
                                                        "width": 3,
                                                        "height": 6
                                                    }
                                                    },
                                                    {
                                                    "widget": {
                                                        "name": "a9a05080",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "01ca7597",
                                                            "fields": [
                                                                {
                                                                "name": "sum(total_auto_merged)",
                                                                "expression": "SUM(`total_auto_merged`)"
                                                                },
                                                                {
                                                                "name": "Type",
                                                                "expression": "`Type`"
                                                                }
                                                            ],
                                                            "disaggregated": False
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 3,
                                                        "widgetType": "pie",
                                                        "encodings": {
                                                            "angle": {
                                                            "fieldName": "sum(total_auto_merged)",
                                                            "scale": {
                                                                "type": "quantitative"
                                                            },
                                                            "axis": {
                                                                "title": "Total Potential Matches Record"
                                                            },
                                                            "format": {
                                                                "type": "number-plain",
                                                                "abbreviation": "compact",
                                                                "decimalPlaces": {
                                                                "type": "all"
                                                                }
                                                            },
                                                            "displayName": "Total Potential Matches Record"
                                                            },
                                                            "color": {
                                                            "fieldName": "Type",
                                                            "scale": {
                                                                "type": "categorical",
                                                                "mappings": [
                                                                {
                                                                    "value": "MERGED",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 3
                                                                    }
                                                                },
                                                                {
                                                                    "value": "PENDING",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 4
                                                                    }
                                                                }
                                                                ]
                                                            },
                                                            "displayName": "Type"
                                                            },
                                                            "label": {
                                                            "show": True
                                                            }
                                                        },
                                                        "frame": {
                                                            "showDescription": False,
                                                            "title": "Potential_Matches  - Auto_Merged/Pending",
                                                            "showTitle": True
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 3,
                                                        "y": 6,
                                                        "width": 3,
                                                        "height": 6
                                                    }
                                                    },
                                                    {
                                                    "widget": {
                                                        "name": "9c96f925",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "b107005d",
                                                            "fields": [
                                                                {
                                                                "name": "source",
                                                                "expression": "`source`"
                                                                },
                                                                {
                                                                "name": "sum(total_records)",
                                                                "expression": "SUM(`total_records`)"
                                                                }
                                                            ],
                                                            "disaggregated": False
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 3,
                                                        "widgetType": "bar",
                                                        "encodings": {
                                                            "x": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical"
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "y": {
                                                            "fieldName": "sum(total_records)",
                                                            "scale": {
                                                                "type": "quantitative"
                                                            },
                                                            "displayName": "Total Records"
                                                            },
                                                            "color": {
                                                            "fieldName": "source",
                                                            "scale": {
                                                                "type": "categorical",
                                                                "mappings": [
                                                                {
                                                                    "value": "aggk_company",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 1
                                                                    }
                                                                },
                                                                {
                                                                    "value": "ciq_company",
                                                                    "color": {
                                                                    "themeColorType": "visualizationColors",
                                                                    "position": 2
                                                                    }
                                                                }
                                                                ]
                                                            },
                                                            "displayName": "source"
                                                            },
                                                            "label": {
                                                            "show": True
                                                            }
                                                        },
                                                        "frame": {
                                                            "title": " Unique Records -Records which doesnt have any matching in any source system",
                                                            "showTitle": True,
                                                            "showDescription": False
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 3,
                                                        "y": 12,
                                                        "width": 3,
                                                        "height": 6
                                                    }
                                                    },
                                                    {
                                                    "widget": {
                                                        "name": "63f37fd2",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "270b84f7",
                                                            "fields": [
                                                                {
                                                                "name": "sum(total_master_records)",
                                                                "expression": "SUM(`total_master_records`)"
                                                                }
                                                            ],
                                                            "disaggregated": False
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 2,
                                                        "widgetType": "counter",
                                                        "encodings": {
                                                            "value": {
                                                            "fieldName": "sum(total_master_records)",
                                                            "format": {
                                                                "type": "number-plain",
                                                                "abbreviation": "compact",
                                                                "decimalPlaces": {
                                                                "type": "exact",
                                                                "places": 3
                                                                }
                                                            },
                                                            "displayName": "Total Master Records"
                                                            }
                                                        },
                                                        "frame": {
                                                            "showTitle": True,
                                                            "title": "All Master Records in Lakefusion"
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 0,
                                                        "y": 9,
                                                        "width": 3,
                                                        "height": 3
                                                    }
                                                    },
                                                    {
                                                    "widget": {
                                                        "name": "c7b87f9e",
                                                        "queries": [
                                                        {
                                                            "name": "main_query",
                                                            "query": {
                                                            "datasetName": "01ca7597",
                                                            "fields": [
                                                                {
                                                                "name": "total_master",
                                                                "expression": "`total_master`"
                                                                }
                                                            ],
                                                            "disaggregated": True
                                                            }
                                                        }
                                                        ],
                                                        "spec": {
                                                        "version": 2,
                                                        "widgetType": "counter",
                                                        "encodings": {
                                                            "value": {
                                                            "fieldName": "total_master",
                                                            "format": {
                                                                "type": "number-plain",
                                                                "abbreviation": "compact",
                                                                "decimalPlaces": {
                                                                "type": "exact",
                                                                "places": 3
                                                                }
                                                            },
                                                            "displayName": "Total Master"
                                                            }
                                                        },
                                                        "frame": {
                                                            "showTitle": True,
                                                            "title": "Total Potential Matches Records"
                                                        }
                                                        }
                                                    },
                                                    "position": {
                                                        "x": 0,
                                                        "y": 6,
                                                        "width": 3,
                                                        "height": 3
                                                    }
                                                    }
                                                ],
                                                "pageType": "PAGE_TYPE_CANVAS"
                                                }
                                            ],
                                            "uiSettings": {
                                                "theme": {
                                                "widgetHeaderAlignment": "ALIGNMENT_UNSPECIFIED"
                                                }
                                            }
                                            }                       
            dasboard_json=json.dumps(json_data,separators=(',', ':'))
            dashboard=DatabricksDashboard(token)  
            dashboard_info=dashboard.create_dashboard(entity_name,warehouse_id,dasboard_json)
            return dashboard_info       
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create dashboard. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create dashboard: {str(e)}")



# ──────────────────────────────────────────────────────────────────────────────
# Reference Entity Sync Pipeline Service
# ──────────────────────────────────────────────────────────────────────────────

from lakefusion_utility.models.integration_hub import (
    IntegrationHubRefEntitySyncPipeline,
    RefEntitySyncPipelineCreate,
    RefEntitySyncPipelineUpdate,
)


class RefEntitySyncPipelineService:
    def __init__(self, db: Session):
        self.db = db
        self.db_config_service = DBConfigPropertiesService(db=self.db)
        self.notebook_path=self.db_config_service.getDBConfigProperties(key="notebook_path")
        self.lakebase_branch_id=self.db_config_service.getDBConfigProperties(key="lakebase_branch_id")
        self.lakebase_database=self.db_config_service.getDBConfigProperties(key="lakebase_database")
        self.lakebase_endpoint_id=self.db_config_service.getDBConfigProperties(key="lakebase_endpoint_id")
        self.lakebase_instance_id=self.db_config_service.getDBConfigProperties(key="lakebase_instance_id")
        self.lakefusion_spn=self.db_config_service.getDBConfigProperties(key="lakefusion_spn")

    def _get_secret_scope_name(self) -> str:
        """Get secret scope name from db_config_properties, default to 'lakefusion'."""
        try:
            return self.db_config_service.getDBConfigProperties('secret_scope_name', required=False) or 'lakefusion'
        except Exception:
            return 'lakefusion'

    def _create_schedule(self, quartz_cron_expression: str, force_pause: bool = False) -> CronSchedule:
        """
        Creates a CronSchedule. If no cron expression provided, uses default with PAUSED status.
        
        Args:
            quartz_cron_expression: The cron expression string
            force_pause: If True, always pause regardless of cron expression
        
        Returns:
            CronSchedule object
        """
        if quartz_cron_expression and quartz_cron_expression.strip():
            return CronSchedule(
                quartz_cron_expression=quartz_cron_expression,
                timezone_id='UTC',
                pause_status=PauseStatus.PAUSED if force_pause else PauseStatus.UNPAUSED
            )
        else:
            return CronSchedule(
                quartz_cron_expression=DEFAULT_CRON,
                timezone_id='UTC',
                pause_status=PauseStatus.PAUSED
            )

    def create_tasks_and_job_reference_pipeline(self, entity_id, quartz_cron_expression, created_by):
        """
        Creates a merged pipeline job that runs both normal deduplication and golden deduplication
        sequentially in a single job.
        """
        catalog_name = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
            .config_value
        )
        entity = (
            self.db.query(Entity)
            .filter(Entity.id == entity_id)
            .first()
        )
        if entity is None:
            raise HTTPException(status_code=404, detail=f"Entity {entity_id} not found")
        # storage_type is the write_mode for the notebook ("delta"/"lakebase").
        # Default to "delta" if the column was never backfilled (NULL).
        write_mode = entity.storage_type or "delta"

        tags = get_resource_tags()
        if tags is None:
            tags = {}

        job_cluster = None

        # Job base_parameters must be Dict[str, str]. Spread the 4 lakebase
        # keys as individual string parameters; the notebook receives them
        # via dbutils.widgets.get("lakebase_instance_id"), etc.
        parameters = {
            "entity_id": str(entity_id),
            "experiment_id": "prod",
            "catalog_name": str(catalog_name),
            "secret_scope_name": self._get_secret_scope_name(),
            "lakebase_instance_id": self.lakebase_instance_id,
            "lakebase_endpoint_id": self.lakebase_endpoint_id,
            "lakebase_branch_id": self.lakebase_branch_id,
            "write_mode": str(write_mode)

        }

        tasks_list = [
            # ============================================================
            # ---------------------- PARSE + MASTER CHECK -----------------
            # ============================================================

            Task(
                task_key="Parse_Entity_Model_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Check_Tables",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_path}/src/integration-core/Check_Master_Exists",
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/entity_reference/Create_Tables",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            # Drain Lakebase UI edits (captured by the change-log triggers) back
            # into Delta BEFORE matching reprocesses, so survivorship sees the
            # reconciled source-of-truth. No-op for delta mode / empty change-log.
            Task(
                task_key="Sync_Lakebase_Changelog_To_Delta",
                depends_on=[TaskDependency(task_key="Check_Tables")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/entity_reference/Sync_Lakebase_Changelog_To_Delta",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="Process_Reference_Table",
                depends_on=[TaskDependency(task_key="Sync_Lakebase_Changelog_To_Delta")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/entity_reference/Process_Reference_Table",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

            Task(
                task_key="RBAC_Permissions",
                depends_on=[TaskDependency(task_key="Process_Reference_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_path}/src/{get_notebook_folder('integration-core', self.db)}/entity_reference/RBAC_Permissions",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),

        ]

        job_parameters_list = [
            JobParameter(name="entity_id", default=str(entity_id)),
            JobParameter(name="experiment_id", default="prod"),
            JobParameter(name="catalog_name", default=str(catalog_name)),
            JobParameter(name="lakebase_instance_id", default=str(self.lakebase_instance_id)),
            JobParameter(name="write_mode", default=str(write_mode)),
            JobParameter(name="lakebase_endpoint_id", default=str(self.lakebase_endpoint_id)),
            JobParameter(name="lakebase_branch_id", default=str(self.lakebase_branch_id))
        ]

        schedule = self._create_schedule(quartz_cron_expression)

        email_notifications = JobEmailNotifications(on_failure=created_by)

        return [job_cluster, tasks_list, job_parameters_list, schedule]
        

    def create(self, payload: RefEntitySyncPipelineCreate,token) -> IntegrationHubRefEntitySyncPipeline:
        existing = (
            self.db.query(IntegrationHubRefEntitySyncPipeline)
            .filter(IntegrationHubRefEntitySyncPipeline.entity_id == payload.entity_id)
            .first()
        )
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"A sync pipeline already exists for entity {payload.entity_id}. Only one pipeline per entity is allowed.",
            )
        try:
            record = IntegrationHubRefEntitySyncPipeline(
                task_name=payload.task_name,
                entity_id=payload.entity_id,
                merge_config=payload.merge_config,
                sync_quartz_cron_expression=payload.sync_quartz_cron_expression,
                created_by=payload.created_by,
            )
            self.db.add(record)
            self.db.flush()  # persist record so it remains in session during external calls
            job_service = DatabricksJobManager(token)
            create_volume_folder = CatalogService(token, self.db)
            folder_path = create_volume_folder.create_volume_folder(payload.entity_id, 'prod')
            # Get entity and model data
            entity_service = EntityService(self.db)
            entity_data = entity_service.get_full_entity_by_id(payload.entity_id).dict()
            reference_entity_config_data = payload.dict(exclude={"created_by"})
            # Upload files
            create_volume_folder.upload_data_as_json(folder_path, 'entity.json', entity_data)
            create_volume_folder.upload_data_as_json(folder_path, 'reference.json', reference_entity_config_data)
            task_list_response = self.create_tasks_and_job_reference_pipeline(
                    payload.entity_id,
                    payload.sync_quartz_cron_expression,
                    payload.created_by
                )
            job_create_response = job_service.create_job(
                payload.task_name,
                task_list_response[0],
                tasks_list=task_list_response[1],
                job_parameters=task_list_response[2],
                schedule=task_list_response[3],
                RunAs=self.lakefusion_spn
            )
            record.job_id = str(job_create_response) if job_create_response else None
            db_commit_auto_rollback(self.db)
            self.db.refresh(record)
            return record
        except IntegrityError:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"A sync pipeline with task name '{payload.task_name}' already exists.",
            )
        except Exception as e:
            app_logger.exception(f"Failed to create ref entity sync pipeline: {traceback.format_exc()}")
            raise HTTPException(status_code=500, detail=f"Failed to create sync pipeline: {str(e)}")

    def read_all(self, is_active: bool = True) -> list:
        return (
            self.db.query(IntegrationHubRefEntitySyncPipeline)
            .filter(IntegrationHubRefEntitySyncPipeline.is_active == is_active)
            .order_by(IntegrationHubRefEntitySyncPipeline.created_at.desc())
            .all()
        )

    def read_by_id(self, task_id: int) -> IntegrationHubRefEntitySyncPipeline:
        record = self.db.query(IntegrationHubRefEntitySyncPipeline).filter(
            IntegrationHubRefEntitySyncPipeline.id == task_id
        ).first()
        if not record:
            raise HTTPException(status_code=404, detail=f"Sync pipeline {task_id} not found.")
        return record

    def update(self, task_id: int, payload: RefEntitySyncPipelineUpdate,token) -> IntegrationHubRefEntitySyncPipeline:
        record = self.read_by_id(task_id)
        update_data = payload.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(record, field, value)
        db_commit_auto_rollback(self.db)
        create_volume_folder = CatalogService(token, self.db)
        folder_path = create_volume_folder.create_volume_folder(payload.entity_id, 'prod')
        # Get entity and model data
        entity_service = EntityService(self.db)
        reference_entity_config_data = payload.dict(exclude={"created_by"})
        create_volume_folder.upload_data_as_json(folder_path, 'reference.json', reference_entity_config_data)
        self.db.refresh(record)
        return record

    def delete(
        self,
        task_id: int,
        token: Optional[str] = None,
        drop_tables: bool = False,
        delete_job: bool = False,
        warehouse_id: Optional[str] = None,
    ) -> dict:
        """Delete a ref-entity sync pipeline. Two opt-in cleanups are available
        in addition to the default DB-row delete:

          - drop_tables=True → drop every Delta table/view that the
            reference-entity pipeline creates for this ref entity (including
            its mappings table).
          - delete_job=True  → delete the Databricks job linked to this
            pipeline (record.job_id) via DatabricksJobManager.

        Args:
            task_id: pipeline record id.
            token: workspace token (required when drop_tables or delete_job).
            drop_tables: opt-in catalog cleanup.
            delete_job: opt-in Databricks job deletion.
            warehouse_id: SQL warehouse to run the DROP statements against.
                Required when drop_tables=True; the cleanup is skipped otherwise.
        """
        record = self.read_by_id(task_id)
        task_name = record.task_name
        entity_id = record.entity_id
        job_id = record.job_id

        # Block deletion if the reference entity is still used in any master entity attribute
        referencing_attrs = (
            self.db.query(EntityAttributes)
            .filter(
                EntityAttributes.is_active == True,
                EntityAttributes.type == 'REFERENCE_ENTITY',
                EntityAttributes.entity_id != entity_id,
            )
            .all()
        )
        mapped_attrs = [
            a for a in referencing_attrs
            if a.type_config and a.type_config.get('reference_entity_id') == entity_id
        ]
        if mapped_attrs:
            referencing_entity_ids = list({a.entity_id for a in mapped_attrs})
            referencing_entities = (
                self.db.query(Entity)
                .filter(Entity.id.in_(referencing_entity_ids))
                .all()
            )
            entity_names = [e.name for e in referencing_entities]
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "status": "error",
                    "message": (
                        f"Cannot delete sync pipeline '{task_name}' because its reference entity "
                        f"is still mapped in {len(mapped_attrs)} attribute(s) across entities "
                        f"({', '.join(entity_names)}). Remove those mappings first."
                    ),
                    "data": {
                        "referencing_attribute_ids": [a.id for a in mapped_attrs],
                        "referencing_entity_ids": referencing_entity_ids,
                        "referencing_entity_names": entity_names,
                    }
                }
            )

        # Best-effort job delete first — Databricks job is the most external
        # dependency, easier to deal with if it goes wrong.
        job_result = None
        if delete_job:
            if not job_id:
                app_logger.info(
                    f"delete_job=True but record has no job_id (task_id={task_id}); skipping"
                )
                job_result = {"status": "skipped", "reason": "no_job_id"}
            elif not token:
                app_logger.warning(
                    f"delete_job=True but token not provided (task_id={task_id}); skipping"
                )
                job_result = {"status": "skipped", "reason": "no_token"}
            else:
                try:
                    job_service = DatabricksJobManager(token)
                    job_service.delete_job(int(job_id))
                    app_logger.info(f"Deleted Databricks job {job_id} for task_id={task_id}")
                    job_result = {"status": "ok", "job_id": job_id}
                except Exception as job_exc:
                    app_logger.warning(
                        f"Failed to delete Databricks job {job_id} (continuing with DB delete): {job_exc}"
                    )
                    job_result = {"status": "failed", "job_id": job_id, "error": str(job_exc)}

        # Best-effort table cleanup before deleting the DB row, so we still
        # have the entity context. Failures are logged, not raised.
        drop_result = None
        if drop_tables:
            try:
                drop_result = self._drop_reference_entity_tables(
                    entity_id=entity_id,
                    token=token,
                    warehouse_id=warehouse_id,
                )
            except Exception as drop_exc:
                app_logger.warning(
                    f"Reference-entity table cleanup raised an error "
                    f"(continuing with DB delete): {drop_exc}"
                )

        self.db.delete(record)
        db_commit_auto_rollback(self.db)
        return {
            "message": f"Sync pipeline '{task_name}' deleted successfully.",
            "drop_tables": drop_tables,
            "drop_result": drop_result,
            "delete_job": delete_job,
            "job_result": job_result,
        }

    def _drop_reference_entity_tables(self, entity_id: int, token: str, warehouse_id: str = None):
        """Drop the six Delta tables/views that the reference-entity pipeline
        creates for a given ref entity, plus its mappings table.

        Always operates on the prod suffix (the ref-entity pipeline runs in
        prod context only).
        """
        catalog_row = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
        )
        catalog_name = catalog_row.config_value if catalog_row else None

        if not catalog_name:
            app_logger.warning("Skipping ref-entity drop: catalog_name not configured")
            return {"status": "skipped", "reason": "no_catalog_name"}
        if not warehouse_id:
            app_logger.warning("Skipping ref-entity drop: warehouse_id not provided")
            return {"status": "skipped", "reason": "no_warehouse_id"}
        if not token:
            app_logger.warning("Skipping ref-entity drop: token not provided")
            return {"status": "skipped", "reason": "no_token"}

        entity_service = EntityService(self.db)
        entity = entity_service.get_entity_by_id(entity_id=entity_id)
        if entity is None:
            app_logger.warning(f"Skipping ref-entity drop: entity {entity_id} not found")
            return {"status": "skipped", "reason": "no_entity"}
        ref_entity_name = entity.name.lower().replace(" ", "_")

        # Single compound statement — same approach as _drop_entity_tables.
        # All ref-entity tables live in the gold layer with a "_prod" suffix.
        cleanup_sql = f"""
BEGIN
    -- Drop legacy view (removed when master/audit split — kept here for
    -- backwards compat against any pre-split tables still around).
    DROP VIEW  IF EXISTS {catalog_name}.gold.{ref_entity_name}_reference_full_vw;

    -- Master (current state) and audit (SCD-2 history + provenance)
    DROP TABLE IF EXISTS {catalog_name}.gold.{ref_entity_name}_reference_prod;
    DROP TABLE IF EXISTS {catalog_name}.gold.{ref_entity_name}_reference_audit_prod;

    -- Conflict queue + (legacy) steward edit log
    DROP TABLE IF EXISTS {catalog_name}.gold.{ref_entity_name}_reference_conflict_queue_prod;
    DROP TABLE IF EXISTS {catalog_name}.gold.{ref_entity_name}_reference_steward_edit_log_prod;

    -- Per-source mapping table (source_value → ref_lakefusion_id)
    DROP TABLE IF EXISTS {catalog_name}.gold.{ref_entity_name}_reference_mappings_prod;
END
"""

        sql_conn = DataSetSQLService(token, warehouse_id)
        try:
            sql_conn.execute_dataset(cleanup_sql)
            app_logger.info(
                f"Ref-entity table cleanup for entity_id={entity_id} ({ref_entity_name}) succeeded"
            )
            return {"status": "ok", "ref_entity_name": ref_entity_name}
        except Exception as e:
            app_logger.warning(
                f"Ref-entity table cleanup for entity_id={entity_id} ({ref_entity_name}) failed: {e}"
            )
            return {"status": "failed", "ref_entity_name": ref_entity_name, "error": str(e)}


# ProductEntityTaskService removed — PIM tasks unified into Integration_Hub with task_type='pim'
