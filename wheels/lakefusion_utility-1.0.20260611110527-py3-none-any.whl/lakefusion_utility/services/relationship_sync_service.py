"""
Relationship Sync Pipeline service (Story 2 — IntHub task type).

Mirrors the Reference Entity sync pattern: persists an
``integration_hub_relationship`` row and creates / updates / deletes a
Databricks job that runs the relationship materialize-edges DAG.

The Databricks job points at the new notebooks under
``dbx_pipeline_artifacts/src/integration-core/relationship/`` (Story 2).
"""

import traceback
from typing import List, Optional

from fastapi import HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from databricks.sdk.service.jobs import (
    Task,
    NotebookTask,
    RunIf,
    Source,
    CronSchedule,
    TaskDependency,
    JobEmailNotifications,
    JobParameter,
    PauseStatus,
)

from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.models.entity import Entity, EntityType
from lakefusion_utility.models.integration_hub import (
    IntegrationHubRelationshipSyncPipeline,
    RelationshipSyncPipelineCreate,
    RelationshipSyncPipelineResponse,
    RelationshipSyncPipelineUpdate,
)
from lakefusion_utility.models.relationship import (
    Relationship,
    RelationshipDatasetMapping,
    RelationshipStatus,
)
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from lakefusion_utility.utils.databricks_util import (
    CatalogService,
    DatabricksJobManager,
    get_resource_tags,
)
from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
from lakefusion_utility.utils.lf_utils import get_version_info
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.notebook_path_utils import get_notebook_folder


app_logger = get_logger(__name__)

DEFAULT_CRON = "0 0 0 * * ?"
FEATURE_FLAG_NAME = "ENABLE_RELATIONSHIPS"


def _assert_feature_enabled(db: Session) -> None:
    if not FeatureFlagService._is_feature_flag_enabled(db, FEATURE_FLAG_NAME):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                f"Feature flag '{FEATURE_FLAG_NAME}' is not active. Relationship "
                "sync pipelines are disabled."
            ),
        )


class RelationshipSyncPipelineService:
    """CRUD + Databricks job lifecycle for relationship sync pipelines."""

    def __init__(self, db: Session):
        self.db = db
        self.db_config_service = DBConfigPropertiesService(db=self.db)
        self.notebook_path = self.db_config_service.getDBConfigProperties(key="notebook_path")
        self.lakefusion_spn = self.db_config_service.getDBConfigProperties(key="lakefusion_spn")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _catalog_name(self) -> str:
        row = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
        )
        if not row:
            raise HTTPException(status_code=500, detail="catalog_name not configured.")
        return row.config_value

    def _create_schedule(self, quartz_cron_expression: str) -> Optional[CronSchedule]:
        # Cron is optional. A value → an active (UNPAUSED) schedule. Empty → no
        # schedule at all; the job is created as manual-run only.
        if quartz_cron_expression and quartz_cron_expression.strip():
            return CronSchedule(
                quartz_cron_expression=quartz_cron_expression,
                timezone_id="UTC",
                pause_status=PauseStatus.UNPAUSED,
            )
        return None

    def _validate_selection(
        self,
        entity_id: int,
        selections: List,
        exclude_task_id: Optional[int] = None,
    ) -> None:
        """Each selected relationship must reference the entity (src or tgt) and
        be active with ≥1 active mapping (or referenced mapping_ids must exist)."""
        entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
        if not entity:
            raise HTTPException(status_code=400, detail=f"Entity {entity_id} not found.")
        if entity.entity_type != EntityType.MASTER.value:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Entity '{entity.name}' is not a Master entity. Relationship sync "
                    "tasks can only be created for Master entities."
                ),
            )

        for sel in selections:
            rel = (
                self.db.query(Relationship)
                .options(joinedload(Relationship.dataset_mappings))
                .filter(
                    Relationship.id == sel.relationship_id,
                    Relationship.is_active == True,  # noqa: E712
                )
                .first()
            )
            if not rel:
                raise HTTPException(
                    status_code=400,
                    detail=f"Relationship {sel.relationship_id} not found or inactive.",
                )
            if entity_id not in (rel.source_entity_id, rel.target_entity_id):
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Relationship '{rel.name}' does not reference entity "
                        f"'{entity.name}' as source or target."
                    ),
                )
            # Status check dropped — `is_active` already enforced in the
            # query above. Treating is_active as the sole gate keeps the UI
            # one-toggle simple.
            active_mapping_ids = {
                m.id for m in (rel.dataset_mappings or []) if m.is_active
            }
            if not active_mapping_ids:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Relationship '{rel.name}' has no active dataset mappings. "
                        "Configure at least one before loading."
                    ),
                )
            if sel.mapping_ids:
                invalid = [m for m in sel.mapping_ids if m not in active_mapping_ids]
                if invalid:
                    raise HTTPException(
                        status_code=400,
                        detail=(
                            f"Mapping ids {invalid} are not active mappings on "
                            f"relationship '{rel.name}'."
                        ),
                    )

        # Block overlap: no two active tasks should load the same (relationship_id).
        # On update, exclude the task being edited so re-sending its own
        # relationship_ids doesn't 409 against itself.
        overlap_q = self.db.query(IntegrationHubRelationshipSyncPipeline).filter(
            IntegrationHubRelationshipSyncPipeline.is_active == True  # noqa: E712
        )
        if exclude_task_id is not None:
            overlap_q = overlap_q.filter(
                IntegrationHubRelationshipSyncPipeline.id != exclude_task_id
            )
        overlapping = overlap_q.all()
        for sel in selections:
            for existing in overlapping:
                rel_ids = {
                    item.get("relationship_id")
                    for item in (existing.relationship_ids or [])
                }
                if sel.relationship_id in rel_ids:
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail=(
                            f"Relationship {sel.relationship_id} is already loaded by "
                            f"task '{existing.task_name}'. Pick a different relationship "
                            "or edit the existing task."
                        ),
                    )

    # ------------------------------------------------------------------
    # Databricks job construction
    # ------------------------------------------------------------------

    def _build_tasks_and_job(
        self,
        record: IntegrationHubRelationshipSyncPipeline,
        cron_expression: str,
    ):
        catalog_name = self._catalog_name()

        tags = get_resource_tags() or {}

        # Base parameters available to every notebook task.
        parameters = {
            "integration_hub_relationship_id": str(record.id),
            "entity_id": str(record.entity_id),
            "experiment_id": "prod",
            "catalog_name": str(catalog_name),
        }

        integration_core = get_notebook_folder("integration-core", self.db)
        rel_folder = f"{self.notebook_path}/src/{integration_core}/relationship"

        tasks_list = [
            Task(
                task_key="Parse_Relationship_JSON",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{rel_folder}/Parse_Relationship_JSON",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Materialize_Edges",
                depends_on=[TaskDependency(task_key="Parse_Relationship_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{rel_folder}/Materialize_Edges",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
            Task(
                task_key="Relationship_Job_Status",
                depends_on=[TaskDependency(task_key="Materialize_Edges")],
                run_if=RunIf.ALL_DONE,
                notebook_task=NotebookTask(
                    notebook_path=f"{rel_folder}/Relationship_Job_Status",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
        ]

        job_parameters_list = [
            JobParameter(name="integration_hub_relationship_id", default=str(record.id)),
            JobParameter(name="entity_id", default=str(record.entity_id)),
            JobParameter(name="experiment_id", default="prod"),
            JobParameter(name="catalog_name", default=str(catalog_name)),
        ]

        schedule = self._create_schedule(cron_expression)
        emails = [e for e in (record.to_emails or []) if e]
        email_notifications = JobEmailNotifications(on_failure=emails) if emails else None

        # No job-cluster override — use serverless / default job cluster like
        # the reference-entity sync pipeline does.
        return [None, tasks_list, job_parameters_list, schedule, email_notifications]

    def _upload_config_to_volume(
        self,
        record: IntegrationHubRelationshipSyncPipeline,
        token: str,
    ) -> None:
        """Snapshot the configuration to a UC Volume so the notebook can read it
        even if the Postgres tables aren't directly reachable from the cluster."""
        from lakefusion_utility.services.relationship_service import (
            RelationshipService,
            RelationshipAttributeService,
            RelationshipDatasetMappingService,
        )

        catalog_service = CatalogService(token, self.db)
        folder_path = catalog_service.create_volume_folder(record.entity_id, "prod")

        rel_service = RelationshipService(self.db)
        attr_service = RelationshipAttributeService(self.db)
        mapping_service = RelationshipDatasetMappingService(self.db)

        payload = {
            "integration_hub_relationship_id": record.id,
            "task_name": record.task_name,
            "entity_id": record.entity_id,
            "relationships": [],
        }
        for sel in (record.relationship_ids or []):
            rid = sel.get("relationship_id")
            mapping_ids = sel.get("mapping_ids") or []
            rel = rel_service.get_relationship(rid)
            attrs = attr_service.list_attributes(rid)
            all_mappings = mapping_service.list_mappings(rid)
            selected_mappings = (
                [m for m in all_mappings if m.id in set(mapping_ids)]
                if mapping_ids
                else [m for m in all_mappings if m.is_active]
            )
            payload["relationships"].append(
                {
                    "relationship": rel.model_dump(),
                    "attributes": [a.model_dump() for a in attrs],
                    "mappings": [m.model_dump() for m in selected_mappings],
                }
            )

        catalog_service.upload_data_as_json(folder_path, "relationship_sync.json", payload)

    # ------------------------------------------------------------------
    # Public CRUD
    # ------------------------------------------------------------------

    def _to_response(
        self, record: IntegrationHubRelationshipSyncPipeline
    ) -> RelationshipSyncPipelineResponse:
        rel_count = len(record.relationship_ids or [])
        mapping_count = sum(
            len(item.get("mapping_ids") or []) for item in (record.relationship_ids or [])
        )
        # Enrich each relationship_ids entry with the relationship's name +
        # label so the UI can show "Subsidiary Of" / "subsidiary_of" pills
        # without an extra round-trip per task row.
        enriched_relationship_ids: list = []
        for item in (record.relationship_ids or []):
            rid = item.get("relationship_id") if isinstance(item, dict) else None
            entry = dict(item) if isinstance(item, dict) else {}
            if rid is not None:
                rel = (
                    self.db.query(Relationship)
                    .filter(Relationship.id == rid)
                    .first()
                )
                if rel:
                    entry["relationship_name"] = rel.name
                    entry["label_forward"] = rel.label_forward
                    entry["label_reverse"] = rel.label_reverse
                    entry["cardinality"] = rel.cardinality
                    entry["is_bidirectional"] = rel.is_bidirectional
            enriched_relationship_ids.append(entry)

        return RelationshipSyncPipelineResponse(
            id=record.id,
            task_name=record.task_name,
            entity_id=record.entity_id,
            relationship_ids=enriched_relationship_ids,
            cron_expression=record.cron_expression,
            timezone_id=record.timezone_id,
            to_emails=record.to_emails or [],
            job_id=record.job_id,
            version=record.version,
            created_by=record.created_by,
            created_at=record.created_at,
            updated_at=record.updated_at,
            is_active=record.is_active,
            # EntityResponse uses v1-style `class Config: orm_mode = True` which
            # Pydantic v2's model_validate doesn't auto-honour. Pass
            # from_attributes=True explicitly so the SQLAlchemy ORM object is
            # accepted.
            entity=(
                EntityResponse.model_validate(record.entity, from_attributes=True)
                if record.entity
                else None
            ),
            relationship_count=rel_count,
            mapping_count=mapping_count,
        )

    def create(
        self, payload: RelationshipSyncPipelineCreate, token: str
    ) -> RelationshipSyncPipelineResponse:
        _assert_feature_enabled(self.db)
        self._validate_selection(payload.entity_id, payload.relationship_ids)

        # Build storage payload for relationship_ids.
        relationship_ids_storage = [
            {"relationship_id": s.relationship_id, "mapping_ids": s.mapping_ids}
            for s in payload.relationship_ids
        ]

        try:
            record = IntegrationHubRelationshipSyncPipeline(
                task_name=payload.task_name,
                entity_id=payload.entity_id,
                relationship_ids=relationship_ids_storage,
                cron_expression=payload.cron_expression,
                timezone_id=payload.timezone_id or "UTC",
                to_emails=payload.to_emails,
                created_by=payload.created_by or "",
                version=get_version_info().get("productVersion"),
            )
            self.db.add(record)
            self.db.flush()

            # Build and create the Databricks job.
            job_service = DatabricksJobManager(token)
            self._upload_config_to_volume(record, token)
            task_list_response = self._build_tasks_and_job(record, payload.cron_expression)
            job_create_response = job_service.create_job(
                payload.task_name,
                task_list_response[0],
                tasks_list=task_list_response[1],
                job_parameters=task_list_response[2],
                schedule=task_list_response[3],
                RunAs=self.lakefusion_spn,
            )
            record.job_id = str(job_create_response) if job_create_response else None

            db_commit_auto_rollback(self.db)
            self.db.refresh(record)
            return self._to_response(record)
        except IntegrityError:
            self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"A sync pipeline with task name '{payload.task_name}' already exists.",
            )
        except HTTPException:
            raise
        except Exception as e:
            self.db.rollback()
            app_logger.exception(
                f"Failed to create relationship sync pipeline: {traceback.format_exc()}"
            )
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create relationship sync pipeline: {str(e)}",
            )

    def read_all(self, is_active: bool = True) -> List[RelationshipSyncPipelineResponse]:
        _assert_feature_enabled(self.db)
        rows = (
            self.db.query(IntegrationHubRelationshipSyncPipeline)
            .filter(IntegrationHubRelationshipSyncPipeline.is_active == is_active)
            .order_by(IntegrationHubRelationshipSyncPipeline.created_at.desc())
            .all()
        )
        return [self._to_response(r) for r in rows]

    def read_by_id(self, task_id: int) -> IntegrationHubRelationshipSyncPipeline:
        rec = (
            self.db.query(IntegrationHubRelationshipSyncPipeline)
            .filter(IntegrationHubRelationshipSyncPipeline.id == task_id)
            .first()
        )
        if not rec:
            raise HTTPException(status_code=404, detail=f"Sync pipeline {task_id} not found.")
        return rec

    def update(
        self,
        task_id: int,
        payload: RelationshipSyncPipelineUpdate,
        token: str,
    ) -> RelationshipSyncPipelineResponse:
        _assert_feature_enabled(self.db)
        record = self.read_by_id(task_id)

        update_data = payload.dict(exclude_unset=True)
        if "relationship_ids" in update_data and update_data["relationship_ids"] is not None:
            self._validate_selection(
                record.entity_id, payload.relationship_ids, exclude_task_id=task_id
            )
            record.relationship_ids = [
                {"relationship_id": s.relationship_id, "mapping_ids": s.mapping_ids}
                for s in payload.relationship_ids
            ]
        if "cron_expression" in update_data and update_data["cron_expression"] is not None:
            record.cron_expression = update_data["cron_expression"]
        if "timezone_id" in update_data and update_data["timezone_id"] is not None:
            record.timezone_id = update_data["timezone_id"]
        if "to_emails" in update_data and update_data["to_emails"] is not None:
            record.to_emails = update_data["to_emails"]

        # Re-apply the schedule on the Databricks job when the cron changed: a value
        # activates the schedule, blank pauses it (job stays manual-run only).
        if "cron_expression" in update_data and record.job_id and token:
            try:
                job_service = DatabricksJobManager(token)
                cron = (record.cron_expression or "").strip()
                if cron:
                    job_service.update_job(record.job_id, cron, PauseStatus.UNPAUSED)
                else:
                    job_service.update_job(record.job_id, DEFAULT_CRON, PauseStatus.PAUSED)
            except Exception as e:  # noqa: BLE001
                app_logger.warning(
                    f"Failed to update schedule on job {record.job_id}: "
                    f"{type(e).__name__}: {e}"
                )

        db_commit_auto_rollback(self.db)
        self._upload_config_to_volume(record, token)
        self.db.refresh(record)
        return self._to_response(record)

    def delete(
        self,
        task_id: int,
        token: Optional[str] = None,
        delete_job: bool = False,
    ) -> dict:
        _assert_feature_enabled(self.db)
        record = self.read_by_id(task_id)
        job_id = record.job_id

        if delete_job and job_id and token:
            try:
                job_service = DatabricksJobManager(token)
                job_service.delete_job(int(job_id))
            except Exception as e:  # noqa: BLE001
                app_logger.warning(
                    f"Failed to delete Databricks job {job_id}: {type(e).__name__}: {e}"
                )

        self.db.delete(record)
        db_commit_auto_rollback(self.db)
        return {"status": "success", "message": "Relationship sync pipeline deleted"}


# Late import to avoid circular dependency at module load time.
from lakefusion_utility.models.entity import EntityResponse  # noqa: E402
