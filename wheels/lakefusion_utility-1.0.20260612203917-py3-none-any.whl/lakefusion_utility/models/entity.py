from sqlalchemy import Column, Integer, String, DateTime, Boolean,JSON,ForeignKey,Text
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
from pydantic import BaseModel
from typing import Optional,List
from sqlalchemy.orm import relationship
from typing import List, Dict, Union, Any
from fastapi import  HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import NoResultFound
import inspect
from lakefusion_utility import validation_functions_constant as ValidationFunctionConstant

class Entity(Base):
    __tablename__ = 'entity'
    __table_args__ = {'extend_existing': True}
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    path = Column(String(255), nullable=False)
    description = Column(String(255))
    created_by = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    color_code = Column(String(20))
    relation_updated_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    schema_evolution_enabled = Column(Boolean, default=False, nullable=False)
    dnb_integration = relationship("EntityDnB", back_populates="entity", lazy="joined",uselist=False)
    attributes = relationship("EntityAttributes", back_populates="entity")
    dataset_mappings = relationship(
        "EntityDatasetMapping", 
        back_populates="entity", 
        overlaps="datasets,entities"
    )
    datasets = relationship(
        "Dataset",
        secondary="entitydatasetmapping",
        back_populates="entities",
        overlaps="dataset_mappings,entity_mappings,entities"
    )
    
    survivorship = relationship("SurvivorshipRule", back_populates="entity", cascade="all, delete-orphan")
    validation_functions = relationship("ValidationFunction", back_populates="entity", cascade="all, delete-orphan")
    quality_tasks = relationship("QualityTask", back_populates="entity", cascade="all, delete-orphan")
    
    def __init__(self, name, path, description, created_by,created_at=None, relation_updated_at = None, is_active=True,color_code=None):
        self.name = name
        self.path = path
        self.description = description
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.relation_updated_at = relation_updated_at if relation_updated_at else datetime.utcnow()
        self.is_active = is_active
        self.color_code = color_code
    
    def __repr__(self):
        return f"<Entity(id={self.id}, name={self.name}, created_at={self.created_at}, relation_updated_at={self.relation_updated_at}, path={self.path}, description={self.description}, created_by={self.created_by}, is_active={self.is_active},color_code={self.color_code})>"
    
    @property
    def integration_hub(self):
        """Dynamically fetch the Integration_Hub entry **only if accessed**."""
        session = Session.object_session(self)
        if session is not None:
            from lakefusion_utility.models.integration_hub import Integration_Hub  # Avoid circular imports
            return session.query(Integration_Hub).filter(
                Integration_Hub.entity_id == self.id,
                Integration_Hub.is_active == True
            ).first()
        return None
    
    @property
    def integration_hub_pipeline(self):
        """Dynamically fetch the Integration_Hub entry **only if accessed**."""
        session = Session.object_session(self)
        if session is not None:
            from lakefusion_utility.models.integration_hub import Integration_Hub  # Avoid circular imports
            return session.query(Integration_Hub).filter(
                Integration_Hub.entity_id == self.id,
                Integration_Hub.is_active == True
            ).first()
        return None

    @property
    def integration_task(self):
        """Check if entity has active integration tasks."""
        return self.integration_hub is not None
    
    @property
    def missing_mappings(self):
        """
        Get a list of entity attributes that are not mapped to any dataset.
        
        Returns:
            List[str]: List of unmapped entity attribute names.
        """
        session = Session.object_session(self)
        if session is not None:
            # Get all active attributes for this entity
            entity_attributes = session.query(EntityAttributes).filter(
                EntityAttributes.entity_id == self.id,
                EntityAttributes.is_active == True
            ).all()

            # If no attributes exist, return empty list (nothing to map)
            if not entity_attributes:
                return []
            # Get no mapped attributes
            mapped_attributes = set()
            dataset_mappings = session.query(EntityDatasetMapping).filter(
                EntityDatasetMapping.entity_id == self.id,
                EntityDatasetMapping.is_active == True
            ).all()
            for mapping in dataset_mappings:
                if mapping.attributes:
                    for attr_mapping in mapping.attributes:
                        if isinstance(attr_mapping, dict) and 'entity_attribute' in attr_mapping:
                            mapped_attributes.add(attr_mapping['entity_attribute'])
            # Identify unmapped attributes
            unmapped_attributes = [attr.name for attr in entity_attributes if attr.name not in mapped_attributes]
            return unmapped_attributes
        return []


    @property
    def attributes_mapped(self):
        """
        Check if all entity attributes are mapped to at least one dataset.
        
        Returns:
            bool: True if all active entity attributes are mapped to at least one dataset,
                False otherwise.
        """
        session = Session.object_session(self)
        if session is not None:
            # Get all active attributes for this entity
            entity_attributes = session.query(EntityAttributes).filter(
                EntityAttributes.entity_id == self.id,
                EntityAttributes.is_active == True
            ).all()
            
            # If no attributes exist, consider as mapped (nothing to map)
            if not entity_attributes:
                return True
            
            # Get all active dataset mappings for this entity
            dataset_mappings = session.query(EntityDatasetMapping).filter(
                EntityDatasetMapping.entity_id == self.id,
                EntityDatasetMapping.is_active == True
            ).all()
            
            # If no mappings exist but attributes do, not all are mapped
            if not dataset_mappings:
                return False
            
            # Extract all mapped entity_attribute names from all mappings
            mapped_attribute_names = set()
            for mapping in dataset_mappings:
                if mapping.attributes:
                    for attr_mapping in mapping.attributes:
                        if isinstance(attr_mapping, dict) and 'entity_attribute' in attr_mapping:
                            mapped_attribute_names.add(attr_mapping['entity_attribute'])
            
            # Get all entity attribute names
            entity_attribute_names = {attr.name for attr in entity_attributes}
            
            # Check if all entity attributes are mapped
            return entity_attribute_names.issubset(mapped_attribute_names)
        
        return False
    

class EntityDnB(Base):
    __tablename__ = 'entity_dnb'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(Integer, ForeignKey('entity.id'), nullable=False) 
    created_by = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    is_active = Column(Boolean, default=False, nullable=False)
    threshold = Column(Integer,nullable=True)
    attributesmapping= Column(JSON,default={},nullable=False)
    minimumconfidence = Column(Integer,default=8,nullable=False)
    candidatemaximumquantity = Column(Integer,default=3,nullable=False)
    enrichment_policies = Column(JSON, default={}, nullable=True)
    entity = relationship("Entity", back_populates="dnb_integration")
    def __init__(self,entity_id,created_by,threshold,attributesmapping,minimumconfidence,candidatemaximumquantity,created_at=None, is_active=False,enrichment_policies=None):
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.entity_id = entity_id
        self.is_active = is_active
        self.threshold=threshold
        self.attributesmapping=attributesmapping
        self.minimumconfidence=minimumconfidence
        self.candidatemaximumquantity=candidatemaximumquantity
        self.enrichment_policies=enrichment_policies

    
    def __repr__(self):
        return f"<EntityDnB(id={self.id}, created_at={self.created_at}, created_by={self.created_by}, is_active={self.is_active},threshold={self.threshold},attributesmapping={self.attributesmapping},minimumconfidence={self.minimumconfidence}),candidatemaximumquantity={self.candidatemaximumquantity}>"
    
class EntityDnBResponse(BaseModel):
    id: int
    entity_id: int
    created_by: str
    created_at: datetime
    is_active: bool
    attributesmapping:Dict[str, str]
    minimumconfidence: int
    candidatemaximumquantity: int
    threshold: Optional[int] = None
    enrichment_policies: Optional[Dict] = None

    class Config:
        orm_mode = True
class EntityDnBCreate(BaseModel):
    threshold :int
    attributesmapping: Dict[str, str]
    minimumconfidence: int
    candidatemaximumquantity: int
    is_active :Optional[bool]= False
    created_by: Optional[str] = ''
    enrichment_policies: Optional[Dict] = None

class EntityDnBSchema(BaseModel):
    id:int
    entity_id:int
    threshold :int
    attributesmapping: Dict[str, str]
    minimumconfidence: int
    candidatemaximumquantity: int
    is_active :Optional[bool]
    created_by: Optional[str]
    enrichment_policies: Optional[Dict] = None

    class Config:
        orm_mode = True
        from_attributes = True  # Required for from_orm

# Pydantic model for request and response
class EntityCreate(BaseModel):
    name: str
    path: str
    description: Optional[str] = None
    created_by: Optional[str] = ''
    color_code: Optional[str] = None

class EntityAttributes(Base):
    __tablename__ = 'entityattributes'
    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(Integer, ForeignKey('entity.id'), nullable=False) 
    name = Column(String(255), nullable=False)
    description = Column(String(255))
    type = Column(String(255), nullable=False)
    label = Column(String(255), nullable=False)
    created_by = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_primary_key = Column(Boolean, default=False, nullable=False)
    show_in_ui = Column(Boolean, default=False, nullable=False)
    is_label = Column(Boolean, default=False, nullable=False)
    
    entity = relationship("Entity", back_populates="attributes")

    def __init__(self, entity_id, name, description, type, label, created_by, created_at=None, is_active=True, is_primary_key=False, show_in_ui=False, is_label=False):
        self.entity_id = entity_id
        self.name = name
        self.description = description
        self.type = type
        self.label = label
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.is_active = is_active
        self.is_primary_key = is_primary_key
        self.show_in_ui = show_in_ui
        self.is_label = is_label

    def __repr__(self):
        return f"<EntityAttributes(id={self.id}, entity_id={self.entity_id}, name={self.name}, type={self.type}, label={self.label}, created_at={self.created_at}, created_by={self.created_by}, is_active={self.is_active}, is_primary_key={self.is_primary_key}, show_in_ui={self.show_in_ui}, is_label={self.is_label})>"

class EntityAttributeCreate(BaseModel):
    name: str
    description: Optional[str] = None
    type: str
    label: str
    created_by: Optional[str] = ''
    is_primary_key: Optional[bool] = False
    show_in_ui: Optional[bool] = False
    is_label: Optional[bool] = False

class EntityAttributeResponse(BaseModel):
    id: int
    entity_id: int
    name: str
    description: Optional[str]
    type: str
    label: str
    created_at: datetime
    created_by: str
    is_active: bool
    is_primary_key: bool
    show_in_ui: bool
    is_label: bool

    class Config:
        orm_mode = True

class EntityDatasetMapping(Base):
    __tablename__ = 'entitydatasetmapping'
    __table_args__ = {'extend_existing': True}
    
    entity_id = Column(Integer, ForeignKey('entity.id'), primary_key=True)
    dataset_id = Column(Integer, ForeignKey('datasets.id'), primary_key=True)
    attributes = Column(JSON, nullable=False)
    is_primary  = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    created_by = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    use_cleaned_table = Column(Boolean, default=False, nullable=False)
    entity = relationship("Entity", back_populates="dataset_mappings", overlaps="datasets,entities")
    dataset = relationship("Dataset", back_populates="entity_mappings", overlaps="entities,datasets")
    
    def __init__(self, entity_id, dataset_id, attributes, is_primary, created_by, created_at=None, is_active=True, use_cleaned_table=False):
        self.entity_id = entity_id
        self.dataset_id = dataset_id
        self.attributes = attributes
        self.is_primary = is_primary
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.is_active = is_active
        self.use_cleaned_table = use_cleaned_table
    
    def __repr__(self):
        return f"<EntityDatasetMapping(entity_id={self.entity_id}, dataset_id={self.dataset_id}, attributes={self.attributes}, is_primary={self.is_primary}, created_at={self.created_at}, created_by={self.created_by}, is_active={self.is_active})>"

class MappingAttribute(BaseModel):
    entity_attribute: str
    dataset_attribute: str

class EntityDatasetMappingCreate(BaseModel):
    attributes: List[MappingAttribute]
    is_primary: bool
    created_by: Optional[str] = ''

class DatasetDetails(BaseModel):
    id: int
    name: str
    path: str
    description: Optional[str]
    created_at: datetime
    created_by: str
    color_code: str
    is_active: bool
    quality_task_enabled: bool

    class Config:
        orm_mode = True

class EntityDatasetMappingResponse(BaseModel):
    entity_id: int
    dataset_id: int
    attributes: List[MappingAttribute]
    is_primary: bool
    created_at: datetime
    created_by: str
    is_active: bool
    dataset: DatasetDetails
    use_cleaned_table: Optional[bool]

    class Config:
        orm_mode = True

class SurvivorshipRule(Base):
    __tablename__ = 'survivorshiprule'
    __table_args__ = {'extend_existing': True}
    
    entity_id  = Column(Integer, ForeignKey('entity.id'),primary_key=True, nullable=False) 
    survivorship_id = Column(Integer,primary_key=True,autoincrement=True, nullable=False)
    group_name = Column(String(255), nullable=False)
    description = Column(String(255), nullable=False)
    is_default  = Column(Boolean, default=False, nullable=False)
    rules = Column(JSON,nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    created_by = Column(String(255), nullable=False)
    is_active  = Column(Boolean, default=True, nullable=False)
    entity = relationship("Entity", back_populates="survivorship")
    
    def __init__(self,entity_id, group_name,description,is_default,rules,created_by, created_at=None, is_active=True):
        self.entity_id = entity_id
        self.group_name = group_name
        self.description=description
        self.is_default=is_default
        self.rules=rules
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.is_active = is_active
    
    def __repr__(self):
        return f"<SurvivorshipRule(entity_id={self.entity_id},group_name={self.group_name},description={self.description},is_default={self.is_default},rules={self.rules},created_at={self.created_at}, created_by={self.created_by}, is_active={self.is_active})>"
    

class SurvivorshipRulesAttributes(BaseModel):
    attribute: str
    strategy: str
    strategyRule: Optional[Any] = None
    ignoreNull: Optional[bool] = False 
    aggregateUniqueOnly: Optional[bool] = False
    tieBreaker: Optional[str] = "latest"

class SurvivorshipRulesCreate(BaseModel):
    group_name: str
    description:str
    is_default:bool
    rules: List[SurvivorshipRulesAttributes]
    created_by: Optional[str] = ''

class SurvivorshipRulesResponse(BaseModel):

    entity_id: int
    survivorship_id: int
    group_name: str
    description:str
    is_default:bool
    rules: List[SurvivorshipRulesAttributes]
    created_at: datetime
    created_by: str
    is_active: bool   

    class Config:
        orm_mode = True

class ValidationFunction(Base):
    __tablename__ = 'validationfunctions'   
    validation_id = Column(Integer, primary_key=True, autoincrement=True) 
    entity_id  = Column(Integer, ForeignKey('entity.id'), nullable=False) 
    attribute_name=Column(String(255), nullable=False)
    function_name = Column(String(255), nullable=False)
    function_type  = Column(String(255), default=True, nullable=False)
    function_definition=Column(Text,nullable=False)
    validation_message = Column(String(255), nullable=False)
    validation_level = Column(String(255),nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    created_by = Column(String(255), nullable=False)
    is_active  = Column(Boolean, default=True, nullable=False)
    entity = relationship("Entity", back_populates="validation_functions")
    
    def __init__(self,entity_id,attribute_name,function_name,function_type,function_definition,validation_message,validation_level,created_by, created_at=None, is_active=True):
        self.entity_id = entity_id
        self.attribute_name = attribute_name
        self.function_name=function_name
        self.function_type=function_type
        self.function_definition=function_definition
        self.validation_message=validation_message
        self.validation_level=validation_level
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.is_active = is_active
    
    def __repr__(self):
        return f"<ValidationFunction(entity_id={self.entity_id},validation_id={self.validation_id},attribute_name={self.attribute_name},function_name={self.function_name},function_type={self.function_type},validation_message={self.validation_message},function_definition={self.function_definition},validation_level={self.validation_level},created_at={self.created_at}, created_by={self.created_by}, is_active={self.is_active})>"
    

    def get_function_definition(self, db):
        if self.function_type in ('python','user_defined'):
            udf = db.query(ValidationUserDefinedFunction).filter(
                ValidationUserDefinedFunction.function_name == self.function_name,
                ValidationUserDefinedFunction.is_active.is_(True)
            ).first()
    
            if not udf:
                raise HTTPException(
                    status_code=400,
                    detail=f"User-defined function '{self.function_name}' not found"
                )
    
            return {
                "function_definition": udf.function_definition,
                "function_definition_type": "user_defined"
            }
           
        # python constant
        else:

            function = getattr(ValidationFunctionConstant, self.function_name, None)
            if not function:
                raise HTTPException(
                    status_code=400,
                    detail=f"Python validation function '{self.function_name}' not found"
                )
            return {
                "function_definition": inspect.getsource(function),
                "function_definition_type": "predefined"
            }


        
        
    
class ValidationFunctionCreate(BaseModel):
    attribute_name:str
    function_name:str
    function_type:str
    validation_message:str
    validation_level: str
    function_definition:Optional[str] = 'temp-definition'
    created_by: Optional[str] = ''

class ValidationFunctionResponse(BaseModel):

    entity_id: int
    validation_id:int
    attribute_name:str
    function_name: str
    function_type:str
    function_definition: str
    validation_message:str
    validation_level: str
    created_at: datetime
    created_by: str
    is_active: bool
    

    class Config:
        orm_mode = True

class ValidationUserDefinedFunction(Base):
    __tablename__ = 'validationuserdefinedfunctions'
    __table_args__ = {'extend_existing': True}
    function_name = Column(String(255), nullable=False)
    function_type = Column(String(255), nullable=False,default='user_defined')
    function_id = Column(Integer,primary_key=True,autoincrement=True,nullable=False) 
    function_definition = Column(String(1000), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    created_by = Column(String(255), nullable=False)
    is_active  = Column(Boolean, default=True, nullable=False)

    
    def __init__(self,function_name,function_type,function_definition,created_by, created_at=None, is_active=True):
        self.function_name = function_name
        self.function_type = function_type
        self.function_definition=function_definition
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.is_active = is_active
    
    def __repr__(self):
        return f"<ValidationUserDefinedFunction(function_name={self.function_name},function_type={self.function_type},function_definition={self.function_definition},created_at={self.created_at}, created_by={self.created_by}, is_active={self.is_active})>"
    

class ValidationUserDefinedFunctionCreate(BaseModel):
    function_name:str
    function_type:str
    function_definition:str
    created_by: Optional[str] = ''

class ValidationUserDefinedFunctionResponse(BaseModel):

    function_id: int
    function_name:str
    function_type:str
    function_definition: str
    created_at: datetime
    created_by: str
    is_active: bool

    class Config:
        orm_mode = True


class EntityResponseTags(BaseModel):
    id: int
    name: str
    created_at: datetime
    path: str
    description: Optional[str]
    created_by: str
    is_active: bool
    color_code: Optional[str]
    relation_updated_at: datetime
    tags:Optional[List[dict]]
    integration_task: bool = False 
    attributes_mapped: bool = False
    missing_mappings: List[str] = []

    # Include all relationships
    dnb_integration : Optional[EntityDnBResponse]=None
    attributes: List[EntityAttributeResponse] = []
    dataset_mappings: List[EntityDatasetMappingResponse] = []
    survivorship: List[SurvivorshipRulesResponse] = []
    validation_functions: List[ValidationFunctionResponse] = []
    is_traditional_pipeline:Optional[bool]
    is_golden_deduplication_pipeline:Optional[bool]
    job_id_1:Optional[str]
    job_id_2:Optional[str]

    class Config:
        orm_mode = True

class EntityResponse(BaseModel):
    id: int
    name: str
    created_at: datetime
    path: str
    description: Optional[str]
    created_by: str
    is_active: bool
    color_code: Optional[str]
    relation_updated_at: datetime
    schema_evolution_enabled: bool = False

    # Include all relationships
    dnb_integration : Optional[EntityDnBResponse]=None
    attributes: List[EntityAttributeResponse] = []
    dataset_mappings: List[EntityDatasetMappingResponse] = []
    survivorship: List[SurvivorshipRulesResponse] = []
    validation_functions: List[ValidationFunctionResponse] = []
    is_traditional_pipeline:Optional[bool] = None
    is_golden_deduplication_pipeline:Optional[bool] = None
    integration_task: bool = False
    attributes_mapped: bool = False
    missing_mappings: List[str] = []

    class Config:
        orm_mode = True

# Define Pydantic schemas for related models
class AttributeSchema(BaseModel):
    id: int
    entity_id: int
    name: str
    description: Optional[str]
    type: str
    label: str
    created_at: datetime
    created_by: str
    is_active: bool
    is_primary_key: int
    show_in_ui: bool
    is_label: bool

    class Config:
        orm_mode = True
        from_attributes = True  # Required for from_orm


class DatasetSchema(BaseModel):
    id: int
    name: str
    path: str
    description: str
    created_at: datetime
    created_by: str
    color_code: str
    is_active: bool
    quality_task_enabled: bool

    class Config:
        orm_mode = True
        from_attributes = True


class DatasetMappingAttributeSchema(BaseModel):
    entity_attribute: str
    dataset_attribute: str


class DatasetMappingSchema(BaseModel):
    entity_id: int
    dataset_id: int
    attributes: List[DatasetMappingAttributeSchema]
    is_primary: bool
    created_at: datetime
    created_by: str
    is_active: bool
    use_cleaned_table: Optional[bool] = False
    dataset: DatasetSchema

    class Config:
        orm_mode = True
        from_attributes = True


class SurvivorshipRuleSchema(BaseModel):
    attribute: str
    strategy: str
    strategyRule: Optional[Any] = None
    ignoreNull: Optional[bool] = False
    aggregateUniqueOnly: Optional[bool] = False
    tieBreaker: Optional[str] = "latest"

class SurvivorshipSchema(BaseModel):
    entity_id: int
    survivorship_id: int
    group_name: str
    description: str
    is_default: bool
    rules: List[SurvivorshipRuleSchema]
    created_at: datetime
    created_by: str
    is_active: bool

    class Config:
        orm_mode = True
        from_attributes = True


class ValidationFunctionSchema(BaseModel):
    entity_id: int
    validation_id: int
    attribute_name: str
    function_name: str
    function_type: str
    validation_level: str
    created_at: datetime
    created_by: str
    is_active: bool
    function_definition: str
    validation_message: str

    class Config:
        orm_mode = True
        from_attributes = True


# Define the main entity schema
class EntitySchema(BaseModel):
    id: int
    name: str
    created_at: datetime
    path: Optional[str]
    description: str
    created_by: str
    is_active: bool
    color_code: Optional[str]
    relation_updated_at: datetime
    attributes_mapped: bool = False
    missing_mappings: List[str] = []
    integration_task: bool = False
    #tags:List[dict]
    dnb_integration :Optional[EntityDnBSchema]=None
    attributes: List[AttributeSchema]
    dataset_mappings: List[DatasetMappingSchema]
    survivorship: List[SurvivorshipSchema]
    validation_functions: List[ValidationFunctionSchema]
    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

