from sqlalchemy import Column, Integer, String, DateTime, Boolean,JSON,ForeignKey,Float
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
from pydantic import BaseModel,ConfigDict
from typing import Optional
from sqlalchemy.orm import relationship
from typing import List,Dict
from lakefusion_utility.models.entity import EntityResponse
from lakefusion_utility.models.match_maven import Model_ExperimentResponse
from sqlalchemy import UniqueConstraint
from enum import Enum
from lakefusion_utility.utils.lf_utils import get_version_info

class IntegrationType(Enum):
    Traditional_Flow = "Traditional_Flow"
    Golden_Deduplication = "Golden_Deduplication"

class PipelineMode(str, Enum):
    """Enum for pipeline execution modes"""
    SEPARATE = "separate"  # Traditional and Golden Dedup run as separate jobs
    MERGED = "merged"      # Both pipelines run in a single job sequentially

class Integration_Hub(Base):
    __tablename__ = 'integration_hub'

    __table_args__ = (
        UniqueConstraint('modelid', 'entity_id', name='uix_modelid_entityid'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    task_name = Column(String(255), nullable=False)
    entity_id  = Column(Integer, ForeignKey('entity.id'), nullable=False)
    modelid  = Column(Integer, ForeignKey('model_experiments.id'), nullable=False)
    to_emails = Column(JSON, nullable=False)
    is_traditional_pipeline = Column(Boolean, default=True, nullable=False)
    is_golden_deduplication_pipeline = Column(Boolean, default=False, nullable=False)
    traditional_quartz_cron_expression = Column(String(45), default="0 0 0 * * ?", nullable=True)
    golden_deduplication_quartz_cron_expression = Column(String(45), default="0 0 0 * * ?", nullable=True)
    timezone_id = Column(String(255), default='UTC', nullable=True)
    created_by = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    job_id_1 = Column(String(255), nullable=True)  # Normal pipeline job (or Merged pipeline job)
    job_id_2 = Column(String(255), nullable=True)  # Golden deduplication job (paused when merged)
    version = Column(String(255), nullable=True)
    pipeline_mode = Column(String(50), default="separate", nullable=True)

    entity = relationship("Entity")
    model_experiment = relationship("Model_Experiment")

    def __init__(self, task_name, entity_id, modelid, to_emails, is_traditional_pipeline, 
                 is_golden_deduplication_pipeline, traditional_quartz_cron_expression,
                 golden_deduplication_quartz_cron_expression, timezone_id, created_by, 
                 pipeline_mode="separate", created_at=None, is_active=True, version=None):
        self.task_name = task_name
        self.entity_id = entity_id
        self.modelid = modelid
        self.to_emails = to_emails
        self.is_traditional_pipeline = is_traditional_pipeline
        self.is_golden_deduplication_pipeline = is_golden_deduplication_pipeline
        self.traditional_quartz_cron_expression = traditional_quartz_cron_expression
        self.golden_deduplication_quartz_cron_expression = golden_deduplication_quartz_cron_expression
        self.timezone_id = timezone_id
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.is_active = is_active
        self.version = get_version_info()["productVersion"]
        self.pipeline_mode = pipeline_mode

    def __repr__(self):
        return (
            f"<Integration_Hub("
            f"id={self.id}, "
            f"task_name={self.task_name}, "
            f"entity_id={self.entity_id}, "
            f"modelid={self.modelid}, "
            f"to_emails={self.to_emails}, "
            f"is_traditional_pipeline={self.is_traditional_pipeline}, "
            f"is_golden_deduplication_pipeline={self.is_golden_deduplication_pipeline}, "
            f"traditional_quartz_cron_expression={self.traditional_quartz_cron_expression}, "
            f"golden_deduplication_quartz_cron_expression={self.golden_deduplication_quartz_cron_expression}, "
            f"timezone_id={self.timezone_id}, "
            f"created_at={self.created_at}, "
            f"created_by={self.created_by}, "
            f"is_active={self.is_active}, "
            f"job_id_1={self.job_id_1}, "
            f"job_id_2={self.job_id_2}, "
            f"version={self.version}, "
            f"pipeline_mode={self.pipeline_mode}"
            f")>"
        )


class IntegrationHub_Backup(Base):
    __tablename__ = "integration_hub_backup"

    id = Column(Integer, primary_key=True, index=True)
    integration_hub_id = Column(Integer)
    job_id_1 = Column(String(255), nullable=True)
    job_id_2 = Column(String(255), nullable=True)
    version = Column(String(255), nullable=True)
    status_sync = Column(String(30), default="BACKUP_CREATED")   # e.g. BACKUP_CREATED, SYNCED, FAILED
    created_at = Column(DateTime, default=datetime.utcnow)
    pipeline_mode = Column(String(50), nullable=True)  # Track which mode was active

    def __init__(self, integration_hub_id, job_id_1, job_id_2, version, status_sync, 
                 pipeline_mode="separate", created_at=None):
        self.integration_hub_id = integration_hub_id
        self.job_id_1 = job_id_1
        self.job_id_2 = job_id_2
        self.version = version
        self.status_sync = status_sync
        self.pipeline_mode = pipeline_mode


class Integration_HubCreate(BaseModel):
    task_name: str
    entity_id: int
    modelid: str
    to_emails: List[str]
    is_traditional_pipeline: bool
    is_golden_deduplication_pipeline: bool
    traditional_quartz_cron_expression: Optional[str] = "0 0 0 * * ?"
    golden_deduplication_quartz_cron_expression: Optional[str] = "0 0 0 * * ?"
    timezone_id: Optional[str] = "UTC"
    created_by: Optional[str] = ''
    version: Optional[str] = get_version_info()["productVersion"]
    # Pipeline mode
    pipeline_mode: Optional[str] = "separate"
    merged_quartz_cron_expression: Optional[str] = None  # For frontend convenience

    class Config:
        orm_mode = True


class Integration_HubUpdate(BaseModel):
    modelid: Optional[str] = None
    traditional_quartz_cron_expression: Optional[str] = None
    golden_deduplication_quartz_cron_expression: Optional[str] = None
    is_traditional_pipeline: Optional[bool] = None
    is_golden_deduplication_pipeline: Optional[bool] = None
    timezone_id: Optional[str] = "UTC"
    updated_by: Optional[str] = ""
    version: Optional[str] = "1.0.0"
    # Pipeline mode
    pipeline_mode: Optional[str] = None
    merged_quartz_cron_expression: Optional[str] = None  # For frontend convenience

    class Config:
        orm_mode = True


class Integration_HubResponse(BaseModel):
    id: int
    task_name: str
    entity_id: int
    modelid: int
    to_emails: List[str]
    is_traditional_pipeline: bool
    is_golden_deduplication_pipeline: bool
    traditional_quartz_cron_expression: Optional[str] = "0 0 0 * * ?"
    golden_deduplication_quartz_cron_expression: Optional[str] = "0 0 0 * * ?"
    timezone_id: Optional[str] = "UTC"
    created_at: datetime
    created_by: str
    is_active: bool
    job_id_1: Optional[str]
    job_id_2: Optional[str]
    version: Optional[str]
    entity: EntityResponse
    model_experiment: Model_ExperimentResponse
    sync_required: Optional[bool] = False
    # Pipeline mode
    pipeline_mode: Optional[str] = "separate"

    class Config:
        orm_mode = True