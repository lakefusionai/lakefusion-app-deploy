"""
PT Models Config model for managing Provisioned Throughput configurations.
"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean, Enum as SQLEnum
from sqlalchemy.dialects.mysql import JSON
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
import enum


class PTType(str, enum.Enum):
    """PT type enumeration."""
    model_units = "model_units"
    legacy = "legacy"


class ModelCategory(str, enum.Enum):
    """Model category enumeration."""
    llm = "llm"
    embedding = "embedding"


class PTModelsConfig(Base):
    """
    SQLAlchemy model for PT models configuration.
    Stores which models support Provisioned Throughput and their settings.
    """
    __tablename__ = 'pt_models_config'

    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_name = Column(String(255), nullable=False, unique=True, index=True)
    entity_version = Column(String(10), default='1', nullable=False)
    pt_type = Column(SQLEnum(PTType), nullable=False)
    model_category = Column(SQLEnum(ModelCategory), nullable=False)
    pt_config = Column(JSON, nullable=False)  # NEW: JSON column stores all PT-specific config
    is_active = Column(Boolean, default=True, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    def as_dict(self):
        """
        Convert model to dictionary with flattened structure for API compatibility.
        Frontend still receives individual fields like chunk_size, provisioned_model_units, etc.
        """
        import json

        base_dict = {
            "id": self.id,
            "entity_name": self.entity_name,
            "entity_version": self.entity_version,
            "pt_type": self.pt_type.value if isinstance(self.pt_type, enum.Enum) else self.pt_type,
            "model_category": self.model_category.value if isinstance(self.model_category, enum.Enum) else self.model_category,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

        # Flatten pt_config JSON into top-level fields for API compatibility
        if self.pt_config:
            # Handle case where pt_config might be a JSON string
            if isinstance(self.pt_config, str):
                pt_config_dict = json.loads(self.pt_config)
            else:
                pt_config_dict = self.pt_config
            base_dict.update(pt_config_dict)

        return base_dict

    @staticmethod
    def build_pt_config(pt_type: str, **kwargs) -> dict:
        """
        Build pt_config JSON from individual fields.
        Frontend sends: chunk_size, provisioned_model_units, min_provisioned_throughput, etc.
        This method transforms them into the JSON structure for database storage.

        Args:
            pt_type: "model_units" or "legacy"
            **kwargs: Individual config fields (chunk_size, provisioned_model_units, etc.)

        Returns:
            dict: JSON-serializable config object
        """
        config: Dict[str, Any] = {}

        # chunk_size is required for all types
        if "chunk_size" in kwargs and kwargs["chunk_size"] is not None:
            config["chunk_size"] = kwargs["chunk_size"]

        if pt_type == "model_units":
            # Model Units PT specific fields
            if "provisioned_model_units" in kwargs and kwargs["provisioned_model_units"] is not None:
                config["provisioned_model_units"] = kwargs["provisioned_model_units"]
            if "burst_scaling_enabled" in kwargs and kwargs["burst_scaling_enabled"] is not None:
                config["burst_scaling_enabled"] = kwargs["burst_scaling_enabled"]

        elif pt_type == "legacy":
            # Legacy PT specific fields
            if "min_provisioned_throughput" in kwargs and kwargs["min_provisioned_throughput"] is not None:
                config["min_provisioned_throughput"] = kwargs["min_provisioned_throughput"]
            if "max_provisioned_throughput" in kwargs and kwargs["max_provisioned_throughput"] is not None:
                config["max_provisioned_throughput"] = kwargs["max_provisioned_throughput"]
            if "scale_to_zero_enabled" in kwargs and kwargs["scale_to_zero_enabled"] is not None:
                config["scale_to_zero_enabled"] = kwargs["scale_to_zero_enabled"]
            if "burst_scaling_enabled" in kwargs and kwargs["burst_scaling_enabled"] is not None:
                config["burst_scaling_enabled"] = kwargs["burst_scaling_enabled"]

        return config


# Pydantic models for API


class PTModelsConfigCreate(BaseModel):
    """Request model for creating PT config."""
    entity_name: str = Field(..., description="Entity name (e.g., system.ai.gpt-oss-120b)")
    entity_version: str = Field(default="1", description="Entity version")
    pt_type: str = Field(..., description="PT type: model_units or legacy")
    model_category: str = Field(..., description="Model category: llm or embedding")
    chunk_size: int = Field(..., gt=0, description="Chunk size for PT")
    provisioned_model_units: Optional[int] = Field(None, description="Provisioned model units (for model_units type)")
    min_provisioned_throughput: Optional[int] = Field(None, description="Min provisioned throughput (for legacy type)")
    max_provisioned_throughput: Optional[int] = Field(None, description="Max provisioned throughput (for legacy type)")
    # Future parameters - can be added without breaking existing code
    scale_to_zero_enabled: Optional[bool] = Field(None, description="Enable scale to zero (for legacy type)")
    burst_scaling_enabled: Optional[bool] = Field(None, description="Enable burst scaling")


class PTModelsConfigUpdate(BaseModel):
    """Request model for updating PT config."""
    entity_version: Optional[str] = Field(None, description="Entity version")
    pt_type: Optional[str] = Field(None, description="PT type: model_units or legacy")
    model_category: Optional[str] = Field(None, description="Model category: llm or embedding")
    chunk_size: Optional[int] = Field(None, gt=0, description="Chunk size for PT")
    provisioned_model_units: Optional[int] = Field(None, description="Provisioned model units (for model_units type)")
    min_provisioned_throughput: Optional[int] = Field(None, description="Min provisioned throughput (for legacy type)")
    max_provisioned_throughput: Optional[int] = Field(None, description="Max provisioned throughput (for legacy type)")
    is_active: Optional[bool] = Field(None, description="Active status")
    # Future parameters - can be added without breaking existing code
    scale_to_zero_enabled: Optional[bool] = Field(None, description="Enable scale to zero (for legacy type)")
    burst_scaling_enabled: Optional[bool] = Field(None, description="Enable burst scaling")


class PTModelsConfigResponse(BaseModel):
    """Response model for PT config."""
    id: int
    entity_name: str
    entity_version: str
    pt_type: str
    model_category: str
    chunk_size: int
    provisioned_model_units: Optional[int] = None
    min_provisioned_throughput: Optional[int] = None
    max_provisioned_throughput: Optional[int] = None
    is_active: bool
    created_at: str
    updated_at: str
    # Future parameters - can be added without breaking existing code
    scale_to_zero_enabled: Optional[bool] = None
    burst_scaling_enabled: Optional[bool] = None

    class Config:
        from_attributes = True


class PTModelsConfigValidateRequest(BaseModel):
    """Request model for validating PT model."""
    entity_name: str = Field(..., description="Entity name to validate")
    entity_version: str = Field(default="1", description="Entity version")


class PTModelsConfigValidateResponse(BaseModel):
    """Response model for PT model validation."""
    eligible: bool = Field(..., description="Whether model is eligible for PT")
    pt_type: Optional[str] = Field(None, description="PT type: model_units or legacy")
    chunk_size: Optional[int] = Field(None, description="Default chunk size")
    model_category: str = Field(..., description="Model category: llm or embedding")
    category_auto_detected: bool = Field(..., description="Whether category was auto-detected")
    defaults: Optional[dict] = Field(None, description="Default configuration values")
    existing_config: Optional[dict] = Field(None, description="Existing PT config if one exists")
    config_exists: bool = Field(default=False, description="Whether a PT config already exists for this model")
