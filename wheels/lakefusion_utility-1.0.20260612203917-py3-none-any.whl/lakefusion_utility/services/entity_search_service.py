import traceback
from sqlalchemy.orm import Session
from lakefusion_utility.models.dataset import Dataset
from lakefusion_utility.models.integration_hub import Integration_Hub
from fastapi import HTTPException
from lakefusion_utility.utils.app_db import db_commit_auto_rollback  # Import the db_commit_auto_rollback function
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.databricks_util import DataSetSQLService
from lakefusion_utility.services.entity_service import EntityService, EntityAttributeService
from sqlalchemy import and_
from databricks.sdk.service import jobs
from lakefusion_utility.models.databricks_model import *
from databricks.sdk.service.compute import ClusterSpec, RuntimeEngine,AwsAttributes,AwsAvailability,AutoScale,DataSecurityMode,AzureAttributes
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from lakefusion_utility.utils.databricks_util import DatabricksJobManager, DataSetSQLService, get_resource_tags
from lakefusion_utility.models.httpresponse import HttpResponse
from databricks.sdk.service.jobs import Task, NotebookTask, TaskEmailNotifications, RunIf, Source, CronSchedule, JobParameterDefinition, CreateResponse, Job, JobSettings,TaskDependency,ConditionTask,ConditionTaskOp,JobParameter,SubmitTask,SqlTask,SqlTaskQuery

from typing import List,Literal,Dict, Any, Tuple, Optional
from lakefusion_utility.utils.logging_utils import get_logger
from databricks.sdk.errors import PermissionDenied
import os,json
from sqlalchemy import or_, func
from sqlalchemy.dialects.mysql import JSON
from lakefusion_utility.models.match_maven import *
from lakefusion_utility.models.databricks_model import *
from lakefusion_utility.utils.databricks_util import DatabricksJobManager
from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
import math
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.notebook_path_utils import get_notebook_folder
from decimal import Decimal
from datetime import date, datetime
import re
from lakefusion_utility.utils.databricks_host import get_databricks_host

# Set up logging
app_logger = get_logger(__name__)

def serialize_row_data(row_dict: dict) -> dict:
    """
    Serialize row data with proper numeric precision handling.
    Converts float/Decimal types to properly formatted strings to preserve precision.
    
    Args:
        row_dict: Dictionary containing row data
    
    Returns:
        Processed dictionary with proper numeric precision
    """
    processed = {}
    for key, value in row_dict.items():
        if isinstance(value, Decimal):
            # Convert Decimal to float, round, then format
            rounded = round(float(value), 2)
            # Use g format to avoid trailing zeros, then convert to float for JSON
            processed[key] = float(rounded)
        elif isinstance(value, float):
            # Round to 2 decimal places
            rounded = round(value, 2)
            processed[key] = rounded
        elif isinstance(value, (date, datetime)):
            # Keep datetime objects as-is
            processed[key] = value
        else:
            processed[key] = value
    return processed

def compare_versions(version1: str, version2: str) -> int:
    """
    Compare two version strings.
    Returns:
        -1 if version1 < version2
         0 if version1 == version2
         1 if version1 > version2
    """
    if not version1:
        version1 = "1.0.0"
    if not version2:
        version2 = "1.0.0"
    
    v1_parts = [int(x) for x in version1.split('.')]
    v2_parts = [int(x) for x in version2.split('.')]
    
    # Pad shorter version with zeros
    while len(v1_parts) < len(v2_parts):
        v1_parts.append(0)
    while len(v2_parts) < len(v1_parts):
        v2_parts.append(0)
    
    for i in range(len(v1_parts)):
        if v1_parts[i] < v2_parts[i]:
            return -1
        elif v1_parts[i] > v2_parts[i]:
            return 1
    return 0


def is_version_gte(version: str, target: str) -> bool:
    """Check if version is greater than or equal to target version."""
    return compare_versions(version, target) >= 0


NEW_PIPELINE_MIN_VERSION = "4.0.0"


class AttributeValidationError(Exception):
    """Custom exception for attribute validation errors."""
    def __init__(self, errors: List[str]):
        self.errors = errors
        super().__init__(f"Validation failed: {'; '.join(errors)}")


class AttributeValidator:
    """Validates update attributes against entity attribute definitions."""
    
    # Mapping of common Spark/SQL types to Python validation
    TYPE_VALIDATORS = {
        'string': lambda v: isinstance(v, str),
        'str': lambda v: isinstance(v, str),
        'varchar': lambda v: isinstance(v, str),
        'text': lambda v: isinstance(v, str),
        'int': lambda v: AttributeValidator._is_int(v),
        'integer': lambda v: AttributeValidator._is_int(v),
        'bigint': lambda v: AttributeValidator._is_int(v),
        'smallint': lambda v: AttributeValidator._is_int(v),
        'tinyint': lambda v: AttributeValidator._is_int(v),
        'long': lambda v: AttributeValidator._is_int(v),
        'float': lambda v: AttributeValidator._is_numeric(v),
        'double': lambda v: AttributeValidator._is_numeric(v),
        'decimal': lambda v: AttributeValidator._is_numeric(v),
        'numeric': lambda v: AttributeValidator._is_numeric(v),
        'boolean': lambda v: AttributeValidator._is_boolean(v),
        'bool': lambda v: AttributeValidator._is_boolean(v),
        'date': lambda v: AttributeValidator._is_date(v),
        'timestamp': lambda v: AttributeValidator._is_timestamp(v),
        'datetime': lambda v: AttributeValidator._is_timestamp(v),
    }
    
    @staticmethod
    def _is_int(value: Any) -> bool:
        """Check if value can be converted to int."""
        if isinstance(value, bool):
            return False
        if isinstance(value, int):
            return True
        if isinstance(value, str):
            try:
                int(value)
                return True
            except ValueError:
                return False
        return False
    
    @staticmethod
    def _is_numeric(value: Any) -> bool:
        """Check if value can be converted to float."""
        if isinstance(value, bool):
            return False
        if isinstance(value, (int, float)):
            return True
        if isinstance(value, str):
            try:
                float(value)
                return True
            except ValueError:
                return False
        return False
    
    @staticmethod
    def _is_boolean(value: Any) -> bool:
        """Check if value is a valid boolean representation."""
        if isinstance(value, bool):
            return True
        if isinstance(value, str):
            return value.lower() in ('true', 'false', '1', '0', 'yes', 'no')
        if isinstance(value, int):
            return value in (0, 1)
        return False
    
    @staticmethod
    def _is_date(value: Any) -> bool:
        """Check if value is a valid date string."""
        if isinstance(value, str):
            # Common date formats
            date_patterns = [
                r'^\d{4}-\d{2}-\d{2}$',  # YYYY-MM-DD
                r'^\d{2}/\d{2}/\d{4}$',  # MM/DD/YYYY
                r'^\d{2}-\d{2}-\d{4}$',  # DD-MM-YYYY
            ]
            for pattern in date_patterns:
                if re.match(pattern, value):
                    return True
        return False
    
    @staticmethod
    def _is_timestamp(value: Any) -> bool:
        """Check if value is a valid timestamp string."""
        if isinstance(value, str):
            # Common timestamp formats
            timestamp_patterns = [
                r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}',  # ISO format
                r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}',  # YYYY-MM-DD HH:MM:SS
            ]
            for pattern in timestamp_patterns:
                if re.match(pattern, value):
                    return True
        return False
    
    @classmethod
    def validate(
        cls,
        update_attributes: Dict[str, Any],
        entity_attributes: List[Any]
    ) -> Tuple[bool, List[str]]:
        """
        Validate update attributes against entity attribute definitions.
        
        Args:
            update_attributes: Dict of attribute_name -> new_value
            entity_attributes: List of attribute objects or dicts with 'name' and 'data_type'
        
        Returns:
            Tuple of (is_valid, list_of_error_messages)
        """
        errors = []
        
        # Build lookup dict for entity attributes
        attr_definitions = {}
        for attr in entity_attributes:
            # Handle both dict and object types
            if isinstance(attr, dict):
                name = attr.get('name') or attr.get('column_name')
                data_type = attr.get('data_type') or attr.get('type') or 'string'
            else:
                # Handle attribute objects
                name = getattr(attr, 'name', None) or getattr(attr, 'column_name', None)
                data_type = getattr(attr, 'data_type', None) or getattr(attr, 'type', None) or 'string'
            
            if name:
                attr_definitions[name] = data_type.lower() if data_type else 'string'
        
        # Validate each update attribute
        for attr_name, attr_value in update_attributes.items():
            # Check if attribute exists in entity definition
            if attr_name not in attr_definitions:
                errors.append(f"Unknown attribute '{attr_name}'. Valid attributes: {list(attr_definitions.keys())}")
                continue
            
            # Skip null/None values - they're allowed
            if attr_value is None:
                continue
            
            # Get expected type
            expected_type = attr_definitions[attr_name]
            
            # Find validator for this type
            validator = None
            for type_key, type_validator in cls.TYPE_VALIDATORS.items():
                if type_key in expected_type:
                    validator = type_validator
                    break
            
            # If no specific validator found, default to string (most permissive)
            if validator is None:
                validator = cls.TYPE_VALIDATORS['string']
            
            # Validate
            if not validator(attr_value):
                errors.append(
                    f"Invalid value for '{attr_name}': expected {expected_type}, "
                    f"got {type(attr_value).__name__} with value '{attr_value}'"
                )
        
        return (len(errors) == 0, errors)
    
    @classmethod
    def validate_or_raise(
        cls,
        update_attributes: Dict[str, Any],
        entity_attributes: List[Any]
    ) -> None:
        """Validate and raise AttributeValidationError if validation fails."""
        is_valid, errors = cls.validate(update_attributes, entity_attributes)
        if not is_valid:
            raise AttributeValidationError(errors)


class EntitySearchService:
    def __init__(self, db: Session):
        """Initializes the entityService with a database session.
        
        Args:
            db: SQLAlchemy session object.
        """
        self.db = db
        self.catalog_name = (
        self.db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == "catalog_name")
        .first().config_value )
        self.db_config_service = DBConfigPropertiesService(db=self.db)
        self.notebook_folder_path=self.db_config_service.getDBConfigProperties(key="notebook_path")
        # Per-request cache of master-table column introspection results. Keyed by
        # (entity_name, experiment). Service instances are short-lived (per HTTP
        # request via FastAPI Depends(get_db)), so cache lifetime matches the
        # request and needs no invalidation.
        self._embedding_col_cache: Dict[Tuple[str, str], bool] = {}

    def get_integration_hub_task_version(self, entity_id: int) -> Optional[str]:
        """
        Get the version from the Integration_Hub table for a given entity.
        Each entity can have only one integration task associated with it.
        """
        try:
            row = (
                self.db.query(Integration_Hub.version)
                .filter(Integration_Hub.entity_id == entity_id)
                .order_by(Integration_Hub.created_at.desc())
                .first()
            )
            if not row:
                app_logger.warning(f"No integration hub record found for entity_id: {entity_id}")
                return None
            version = row.version
            app_logger.info(f"Fetched integration hub version {version} for entity_id: {entity_id}")
            return version
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Unable to get entity version for entity_id {entity_id}. Reason: {message}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity version: {str(e)}"
            )
    

    def get_job_run_status(self,job_run_id:str,token:str):
        try:
            job_service = DatabricksJobManager(token)
            job_response=job_service.get_job_run_status(job_run_id)
            return job_response

        except Exception as e:
            app_logger.exception(f'Unable to create model databricks job. Reason - {str(e)}')
 
    
    def read_entity_search_profile(self,entity_id:int,warehouse_id:str,token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            query=f"select * from {self.catalog_name}.gold.{entity_name}_master_prod"
            data=sqlservice_conn.execute_dataset(query=query)
            return data

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile: {str(e)}"
            )
        finally:
            # Ensure the session is closed properly
            self.db.close()

    def read_entity_search_profile_id(self,entity_id:int,id_value:str,warehouse_id:str,token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            entity_primary="lakefusion_id"
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            query=f"select * from {self.catalog_name}.gold.{entity_name}_master_prod where {entity_primary}='{id_value}' "
            data=sqlservice_conn.execute_dataset(query=query)
            if not data:
                app_logger.info(f'No data found for entity {entity_id} with {entity_primary}={id_value}')
                raise HTTPException(
                    status_code=404,
                    detail=f"No profile found for the given ID value: {id_value}"
                )
            
            if len(data) == 0:
                app_logger.info(f'Empty result set for entity {entity_id} with {entity_primary}={id_value}')
                raise HTTPException(
                    status_code=404,
                    detail=f"No profile found for the given ID value: {id_value}"
                )
            result = data[0]
            # Strip internal-use columns from the master row before returning to the UI.
            # Both `attributes_combined` (the deterministic-rules input string) and
            # `attributes_combined_embedding` (the precomputed-mode vector) are pipeline
            # infrastructure, not user-facing attributes. Both Profile Details and the
            # Sources tab consume this response, so filtering here covers both views.
            if isinstance(result, dict):
                for internal_col in ("attributes_combined", "attributes_combined_embedding"):
                    result.pop(internal_col, None)

            # Map attribute names to labels    
            entity_attribute_conn = EntityAttributeService(db=self.db)  
            for res in list(result.keys()):
                attribute_label = entity_attribute_conn.get_attributelabel_by_attributename(entity_id, res)
                if attribute_label:
                    result[attribute_label] = result.pop(res)
            
            # Ensure proper numeric precision in the result
            result = serialize_row_data(result)

            return result

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile: {str(e)}"
            )
        finally:
            # Ensure the session is closed properly
            self.db.close()

    def build_filter_clauses(self, filters, table_prefix=None):
        try:
            if isinstance(filters, str):
                if '%' in filters:
                    try:
                        import urllib.parse
                        filters = urllib.parse.unquote(filters)
                    except Exception as e:
                        app_logger.error(f"Error URL-decoding filters: {str(e)}")
                
                if filters.strip():
                    try:
                        filters = json.loads(filters)
                    except json.JSONDecodeError as e:
                        app_logger.error(f"Invalid JSON filter string: {e}")
                        return "", []
                else:
                    return "", []
                
            if not filters or not isinstance(filters, list):
                return "", []
                
            filter_clauses = []
            for i, filter_item in enumerate(filters):
                attribute_name = filter_item.get('attributeName')
                operator = filter_item.get('operator')
                value = filter_item.get('value')
                conjunction = filter_item.get('conjunction', 'AND')

                if not attribute_name or not operator:
                    continue

                # Validate operator against allowed set
                ALLOWED_OPERATORS = {'eq', 'neq', 'contains', 'not_contains', 'starts_with', 'ends_with',
                                     'gt', 'lt', 'gte', 'lte', 'is_null', 'is_not_null', 'eq_true', 'eq_false'}
                if operator not in ALLOWED_OPERATORS:
                    app_logger.warning(f"Invalid filter operator: {operator}")
                    continue

                # Validate conjunction
                if conjunction.upper() not in ('AND', 'OR'):
                    app_logger.warning(f"Invalid filter conjunction: {conjunction}")
                    conjunction = 'AND'

                # Validate attribute_name is a safe SQL identifier (letters, digits, underscores only)
                if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', attribute_name):
                    app_logger.warning(f"Invalid filter attribute name: {attribute_name}")
                    continue

                # Sanitize value for numeric operators
                NUMERIC_OPERATORS = {'gt', 'lt', 'gte', 'lte'}
                if operator in NUMERIC_OPERATORS:
                    try:
                        float(value)
                    except (ValueError, TypeError):
                        app_logger.warning(f"Non-numeric value for numeric operator {operator}: {value}")
                        continue

                # Escape single quotes in string values to prevent SQL injection
                if value is not None and isinstance(value, str):
                    value = value.replace("'", "''")

                column = f"{table_prefix}.{attribute_name}" if table_prefix else attribute_name
                
                sql_clause = ""
                
                # Text/String operators
                if operator == 'eq':  # is equal to
                    sql_clause = f"UPPER({column}) = UPPER('{value}')"
                elif operator == 'neq':  # is not equal to
                    sql_clause = f"UPPER({column}) != UPPER('{value}')"
                elif operator == 'contains':  # contains
                    sql_clause = f"UPPER({column}) LIKE UPPER('%{value}%')"
                elif operator == 'not_contains':  # does not contain
                    sql_clause = f"UPPER({column}) NOT LIKE UPPER('%{value}%')"
                elif operator == 'starts_with':  # starts with
                    sql_clause = f"UPPER({column}) LIKE UPPER('{value}%')"
                elif operator == 'ends_with':  # ends with
                    sql_clause = f"UPPER({column}) LIKE UPPER('%{value}')"
                
                # Numeric operators
                elif operator == 'gt':  # is greater than
                    sql_clause = f"{column} > {value}"
                elif operator == 'lt':  # is less than
                    sql_clause = f"{column} < {value}"
                elif operator == 'gte':  # is greater than or equal to
                    sql_clause = f"{column} >= {value}"
                elif operator == 'lte':  # is less than or equal to
                    sql_clause = f"{column} <= {value}"
                
                # Null operators
                elif operator == 'is_null':  # is null
                    sql_clause = f"{column} IS NULL"
                elif operator == 'is_not_null':  # is not null
                    sql_clause = f"{column} IS NOT NULL"
                
                # Boolean operators
                elif operator == 'eq_true':  # is true
                    sql_clause = f"{column} = TRUE"
                elif operator == 'eq_false':  # is false
                    sql_clause = f"{column} = FALSE"
                
                if sql_clause:
                    if i > 0:
                        filter_clauses.append(conjunction)
                    filter_clauses.append(sql_clause)
            
            if filter_clauses:
                return " ".join(filter_clauses), []
            return "", []
        except Exception as e:
            app_logger.error(f"Error building filter clauses: {str(e)}")
            return "", []
            
    def get_all_records(self, entity_id: int, warehouse_id: str, token: str, page: int = 1, page_size: int = 1000, filters=None):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            
            name_to_label = {}
            columns_to_select = []
            
            has_lakefusion_id = any(attr.name == "lakefusion_id" for attr in entity.attributes)
        
            if not has_lakefusion_id:
                columns_to_select.append("lakefusion_id")
            
            for attr in entity.attributes:
                if attr.name and (attr.show_in_ui or attr.is_label or attr.is_primary_key):
                    if attr.name not in columns_to_select:
                        columns_to_select.append(attr.name)
                        if attr.label:
                            name_to_label[attr.name] = attr.label
            
            if not columns_to_select:
                return {
                    "data": [],
                    "pagination": {
                        "page": page,
                        "page_size": page_size,
                        "total_count": 0,
                        "total_pages": 0
                    }
                }
            
            offset = (page - 1) * page_size

            sqlservice_conn = DataSetSQLService(token, warehouse_id)

            has_dnb = entity.dnb_integration is not None and entity.dnb_integration.is_active
            primary_key_attr = next((attr for attr in entity.attributes if attr.is_primary_key), None)

            if has_dnb and primary_key_attr:
                dnb_table = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"
                select_clause_prefixed = ", ".join([f"m.{col}" for col in columns_to_select])

                where_clause = ""
                if filters:
                    filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
                    if filter_clause:
                        where_clause = f"WHERE {filter_clause}"

                query = f"""
                    SELECT
                        {select_clause_prefixed},
                        COALESCE(d.dnb_status, 'NONE') AS dnb_status,
                        COUNT(*) OVER() AS total_count
                    FROM {self.catalog_name}.gold.{entity_name}_master_prod m
                    LEFT JOIN (
                        SELECT lakefusion_id AS dnb_lf_id,
                            CASE
                                WHEN MAX(CASE WHEN merge_status = 'ACCEPTED' THEN 1 ELSE 0 END) = 1 THEN 'ACCEPTED'
                                WHEN MAX(CASE WHEN merge_status = 'AUTO_MERGED' THEN 1 ELSE 0 END) = 1 THEN 'MATCHED'
                                WHEN MAX(CASE WHEN merge_status = 'IN_REVIEW' THEN 1 ELSE 0 END) = 1 THEN 'IN_REVIEW'
                                ELSE 'NONE'
                            END AS dnb_status
                        FROM {dnb_table}
                        GROUP BY lakefusion_id
                    ) d ON m.lakefusion_id = d.dnb_lf_id
                    {where_clause}
                    LIMIT {page_size} OFFSET {offset}
                """
            else:
                select_clause = ", ".join(columns_to_select)

                where_clause = ""
                if filters:
                    filter_clause, _ = self.build_filter_clauses(filters)
                    if filter_clause:
                        where_clause = f"WHERE {filter_clause}"

                query = f"""
                    SELECT
                        {select_clause},
                        COUNT(*) OVER() AS total_count
                    FROM {self.catalog_name}.gold.{entity_name}_master_prod
                    {where_clause}
                    LIMIT {page_size} OFFSET {offset}
                """
            
            raw_data = sqlservice_conn.execute_dataset(query=query)
            for i, record in enumerate(raw_data):
                if isinstance(record, dict):
                    raw_data[i] = serialize_row_data(record)

            total_count = raw_data[0]['total_count'] if raw_data and 'total_count' in raw_data[0] else 0
            
            if raw_data:
                for record in raw_data:
                    record_dict = dict(record) if not isinstance(record, dict) else record.copy()
                    
                    if 'total_count' in record_dict:
                        del record_dict['total_count']
            
            total_pages = math.ceil(total_count / page_size) if page_size > 0 else 0
            
            response_data = {
                "data": raw_data,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total_count": total_count,
                    "total_pages": total_pages
                }
            }
            
            return response_data

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch master records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch master records: {str(e)}"
            )
        finally:
            # Ensure the session is closed properly
            self.db.close()

    def create_not_match_tasks_and_job(self,parameters):
        try:
            job_parameters_list = [i for i in parameters]
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Match_Merge",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Manual Not A Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Manual Not A Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Potential Match Table",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
        
    def create_not_match_tasks_and_job_updated(self,parameters):
        try:
            job_parameters_list = [i for i in parameters]
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Not_Match",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Manual_Not_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Manual_Not_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )

    def create_match_merge_tasks_and_job(self,parameters):
        try:
            
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            
            job_parameters_list = [i for i in parameters]
            
            
            
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Match_Merge",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Manual Merge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Manual Merge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Potential Match Table",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create task: {str(e)}"
            )
        
    def create_match_merge_tasks_and_job_updated(self,parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}
           
            job_parameters_list = [i for i in parameters]
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Manual_Merge",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Manual_Merge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Manual_Merge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Manual_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Manual_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create task: {str(e)}"
            )

    def create_match_merge_tasks_and_job_dnbintegration(self,parameters):
        try:
            dbx_cloud=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "dbx_cloud").first().config_value)
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            if(dbx_cloud=='azure'):
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                cluster_name="",
                spark_version="16.0.x-cpu-ml-scala2.12",
                azure_attributes=AzureAttributes(
                    first_on_demand=1
                ),  # Corrected Azure Attributes
                node_type_id="Standard_DS12_v2",
                driver_node_type_id="Standard_DS12_v2",  # Correct Azure instance type
                spark_env_vars={
                    "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                },
                enable_elastic_disk=False,
                data_security_mode=DataSecurityMode.SINGLE_USER,
                runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                autoscale=AutoScale(
                    min_workers=1,  # Updated worker count
                    max_workers=1   # Updated worker count
                ),
                custom_tags=tags  # Add custom tags
                ))
            else:
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    aws_attributes=AwsAttributes(
                        first_on_demand=1,
                        availability=AwsAvailability.SPOT_WITH_FALLBACK,
                        zone_id="us-west-2d",
                        spot_bid_price_percent=100,
                        ebs_volume_count=0
                    ),
                    node_type_id="r5d.4xlarge",  # Updated instance type
                    spark_env_vars={
                        "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                    },
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                    autoscale=AutoScale(
                        min_workers=2,  # Updated worker count
                        max_workers=4   # Updated worker count
                    ),
                    custom_tags=tags  # Add custom tags
                    ))
            tasks_list = [
            SubmitTask(
                task_key="Entity_Match_Merge",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/dnb_integration/Manual Merge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('dnb_integration', self.db)}/Manual Merge",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
    
    def run_match_merge(self,entity_id:int,potential_record,token,created_by):
        try:
            job_parameters=[{"entity_id": str(entity_id),"experiment_id": str('prod') , "catalog_name":self.catalog_name },{"catalog_name":self.catalog_name,"experiment_id":str('prod'),"master_id":str(potential_record.master_id),"unified_dataset_ids": json.dumps([{"id": i.id,"dataset_id": i.dataset_id} for i in potential_record.unified_dataset_ids])}]
            if(potential_record.operation_type in ['MERGE','MERGE_ALL']):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_match_merge_tasks_and_job(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_MERGE",task_list_response)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
            elif(potential_record.operation_type=='NOT_A_MATCH'):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_not_match_tasks_and_job(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_Not_A_Match",task_list_response)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type='NOT_A_MATCH',
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
        
    def run_match_merge_updated(self,entity_id:int,potential_record,token,created_by):
        try:
            job_parameters=[{"entity_id": str(entity_id),"experiment_id": str('prod') , "catalog_name":self.catalog_name },{"catalog_name":self.catalog_name,"experiment_id":str('prod'),"master_id":str(potential_record.master_id),"unified_dataset_ids": json.dumps([{"id": i.id,"dataset_id": i.dataset_id} for i in potential_record.unified_dataset_ids])}]
            if(potential_record.operation_type in ['MERGE','MERGE_ALL']):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_match_merge_tasks_and_job_updated(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_MERGE",task_list_response)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
            elif(potential_record.operation_type=='NOT_A_MATCH'):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_not_match_tasks_and_job_updated(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_Not_A_Match",task_list_response)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type='NOT_A_MATCH',
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )

    # =========================================================================
    # SQL Stewardship: Shared utilities
    # =========================================================================

    def _create_pm_crosswalk_tasks(self, parameters):
        """
        Create task list for PM + CrossWalk refresh (superset DAG).
        Runs golden PM + normal PM + crosswalk to cover both normal and dedup merges.
        Parse_Entity_Model_JSON → (PM golden ∥ PM normal ∥ CrossWalk) → Entity_Job_Status
        """
        try:
            tags = get_resource_tags()
            if tags is None:
                tags = {}

            notebook_folder = get_notebook_folder('integration-core', self.db)
            job_parameters_list = [i for i in parameters]
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/{notebook_folder}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Potential_Match_Table",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/{notebook_folder}/golden_deduplication/Process_Potential_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Potential_Match_Normal",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/{notebook_folder}/normal_deduplication/Process_Potential_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_CrossWalk",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/{notebook_folder}/Process_Crosswalk",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Entity_Job_Status",
                    depends_on=[
                        TaskDependency(task_key="Process_CrossWalk"),
                        TaskDependency(task_key="Process_Potential_Match_Normal"),
                        TaskDependency(task_key="Process_Potential_Match_Table"),
                    ],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/{notebook_folder}/Entity_Job_Status",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
            ]
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create PM+Crosswalk tasks: {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create PM+Crosswalk tasks: {str(e)}")

    # =========================================================================
    # SQL Stewardship: Merge via SQL Warehouse
    # =========================================================================

    # Delta concurrency retry config (mirrors concurrency_utils.py in notebooks)
    _CONCURRENT_RETRY_MARKERS = (
        "CONCURRENT_APPEND",
        "CONCURRENT_DELETE_DELETE",
        "CONCURRENT_DELETE_READ",
    )
    _RETRY_DELAYS = (5, 10, 20, 30, 45, 60)

    def _execute_with_concurrency_retry(self, token: str, warehouse_id: str, sql_script: str, description: str = "SQL") -> dict:
        """Execute SQL script with retry on Delta concurrency conflicts."""
        import time, random
        max_retries = 1 + len(self._RETRY_DELAYS)
        for attempt in range(max_retries):
            try:
                sql_service = DataSetSQLService(token, warehouse_id)
                return sql_service.execute_sql_script(sql_script)
            except Exception as e:
                err_str = str(e)
                is_retryable = any(marker in err_str for marker in self._CONCURRENT_RETRY_MARKERS)
                if is_retryable and attempt < max_retries - 1:
                    base = self._RETRY_DELAYS[attempt]
                    wait = base + random.uniform(0, base * 0.2)
                    app_logger.warning(
                        f"[retry] {description}: Delta concurrency conflict on "
                        f"attempt {attempt + 1}/{max_retries}; sleeping {wait:.1f}s"
                    )
                    time.sleep(wait)
                else:
                    raise

    def _resolve_survivorship_rules(self, entity_dict: dict) -> list:
        """
        Resolve dataset IDs in survivorship rules to actual table paths.
        Expects entity_dict from entity_data.model_dump() / entity_data.dict().
        """
        # Find default active survivorship rule set
        survivorship_rules = []
        for sr in entity_dict.get('survivorship', []):
            if sr.get('is_default') and sr.get('is_active') and sr.get('rules'):
                survivorship_rules = [dict(r) for r in sr['rules']]
                break

        if not survivorship_rules:
            return []

        # Build dataset_id → path mapping
        dataset_id_to_path = {}
        for dm in entity_dict.get('dataset_mappings', []):
            ds = dm.get('dataset', {})
            if ds.get('id') is not None and ds.get('path'):
                dataset_id_to_path[ds['id']] = ds['path']

        # Resolve Source System strategyRule dataset IDs to paths
        for rule in survivorship_rules:
            if rule.get('strategy') == 'Source System' and isinstance(rule.get('strategyRule'), list):
                rule['strategyRule'] = [
                    dataset_id_to_path.get(did)
                    for did in rule['strategyRule']
                    if dataset_id_to_path.get(did) is not None
                ]

        return survivorship_rules

    def _build_complete_attr_mapping_sql(
        self, attributes: list, json_var: str, unified_tbl: str, master_id: str
    ) -> str:
        """
        Build SQL expression returning ARRAY<STRUCT<attribute_name, attribute_value, source>>
        that includes ALL entity attributes — not just the non-null ones from the UDF.

        The survivorship UDF only emits mappings for attributes with non-null values.
        This supplements the UDF output with null-valued attributes, assigning the
        first contributor's source_path as their source (matching notebook behavior).
        """
        attr_names = [a['name'] for a in attributes]
        attr_list = ", ".join(f"'{name}'" for name in attr_names)
        mapping_schema = "ARRAY<STRUCT<attribute_name:STRING, attribute_value:STRING, source:STRING>>"
        mapping_expr = f"from_json({json_var}:resultant_master_attribute_source_mapping, '{mapping_schema}')"

        return f"""(
    SELECT collect_list(named_struct(
      'attribute_name', all_attrs.attr_name,
      'attribute_value', all_attrs.attr_value,
      'source', all_attrs.attr_source
    ))
    FROM (
      -- Non-null attributes from UDF survivorship output
      SELECT attribute_name AS attr_name, attribute_value AS attr_value, source AS attr_source
      FROM (SELECT inline({mapping_expr}))

      UNION ALL

      -- Null-valued attributes skipped by UDF — assign first contributor's source
      SELECT
        a.attr AS attr_name,
        CAST(NULL AS STRING) AS attr_value,
        (SELECT source_path FROM {unified_tbl}
         WHERE master_lakefusion_id = '{master_id}' LIMIT 1) AS attr_source
      FROM (SELECT explode(array({attr_list})) AS attr) a
      WHERE a.attr NOT IN (
        SELECT attribute_name FROM (SELECT inline({mapping_expr}))
      )
    ) all_attrs
  )"""

    def _fetch_steward_decision_snapshots(self, token: str, warehouse_id: str, entity_name: str,
                                           master_id: str, match_id: str, attr_names: list,
                                           is_master_to_master: bool = False) -> tuple:
        """Fetch master and match record attributes before a stewardship operation.
        Returns (master_attrs_dict, match_attrs_dict). Either may be empty dict if not found."""
        try:
            sql_service = DataSetSQLService(token, warehouse_id)
            master_table = f"{self.catalog_name}.gold.{entity_name}_master_prod"
            unified_table = f"{self.catalog_name}.silver.{entity_name}_unified_prod"
            cols_sql = ", ".join(attr_names)

            if is_master_to_master:
                script = (
                    f"BEGIN SELECT lakefusion_id AS _lookup_key, "
                    f"CASE WHEN lakefusion_id = '{master_id}' THEN 'master' ELSE 'match' END AS _record_type, "
                    f"{cols_sql} FROM {master_table} "
                    f"WHERE lakefusion_id IN ('{master_id}', '{match_id}'); END"
                )
            else:
                parts = [
                    f"SELECT lakefusion_id AS _lookup_key, 'master' AS _record_type, {cols_sql} "
                    f"FROM {master_table} WHERE lakefusion_id = '{master_id}'"
                ]
                if match_id:
                    parts.append(
                        f"SELECT surrogate_key AS _lookup_key, 'match' AS _record_type, {cols_sql} "
                        f"FROM {unified_table} WHERE surrogate_key = '{match_id}'"
                    )
                script = f"BEGIN SELECT * FROM ({' UNION ALL '.join(parts)}); END"

            result = sql_service.execute_sql_script(script)
            master_attrs = {}
            match_attrs = {}
            for row in (result.get("result") or []):
                record_type = row.pop("_record_type", None)
                row.pop("_lookup_key", None)
                if record_type == "master":
                    master_attrs = row
                elif record_type == "match":
                    match_attrs = row
            return master_attrs, match_attrs
        except Exception as e:
            app_logger.warning(f"Could not fetch steward decision snapshots: {e}")
            return {}, {}

    def _write_steward_decision(self, token: str, warehouse_id: str, entity_name: str,
                                 entity_id: int, action_type: str, master_id: str, match_id: str,
                                 master_attrs: dict, match_attrs: dict, created_by: str = ""):
        """Write pre-captured snapshots to steward_decisions Delta table via SQL warehouse."""
        import uuid
        import json as _json

        try:
            sql_service = DataSetSQLService(token, warehouse_id)
            decisions_table = f"{self.catalog_name}.silver.{entity_name}_steward_decisions"
            _sql_esc = lambda v: "'" + str(v).replace("'", "''") + "'" if v else 'NULL'

            to_str = lambda d: {k: str(v) if v is not None else None for k, v in d.items()}
            m_json = _json.dumps(to_str(master_attrs)) if master_attrs else None
            r_json = _json.dumps(to_str(match_attrs)) if match_attrs else None
            decision_id = str(uuid.uuid4()).replace("-", "")

            sql_service.execute_sql_script(
                f"BEGIN "
                f"CREATE TABLE IF NOT EXISTS {decisions_table} ("
                f"decision_id STRING, entity_id STRING, action_type STRING, master_id STRING, match_id STRING, "
                f"reason STRING, reason_category STRING, master_record_attributes STRING, match_record_attributes STRING, "
                f"master_record_source STRING, match_record_source STRING, steward STRING, decided_at TIMESTAMP, aml_status STRING"
                f") USING DELTA; "
                f"INSERT INTO {decisions_table} VALUES ("
                f"'{decision_id}', '{entity_id}', '{action_type}', '{master_id}', '{match_id}', "
                f"NULL, NULL, {_sql_esc(m_json)}, {_sql_esc(r_json)}, "
                f"NULL, NULL, {_sql_esc(created_by)}, current_timestamp(), 'PENDING'"
                f"); END"
            )
            app_logger.info(f"Steward decision written for {action_type} master={master_id}")
        except Exception as e:
            app_logger.warning(f"Could not write steward decision: {e}")

    def _master_has_embedding_col(self, token: str, warehouse_id: str, entity_name: str, experiment: str = 'prod') -> bool:
        """Detect whether the master table carries `attributes_combined_embedding`.

        Precomputed-mode experiments have the column; managed-mode experiments don't.
        Used to gate the `attributes_combined_embedding = NULL` clause that stewardship
        SQL scripts must emit alongside any `attributes_combined` rewrite.

        Tries `information_schema.columns` first (standard, single round-trip), falls
        back to `DESCRIBE TABLE` if metastore-level grants block the first path.
        DESCRIBE TABLE only needs read access to the table itself, which the caller
        already has since the same flow is about to write to it.

        On total failure returns False — precomputed-mode embeddings would then go
        stale. Logs at error level so the operator sees it.

        Result is cached per (entity_name, experiment) for the service-instance
        lifetime so a single request making multiple stewardship calls against the
        same entity (e.g. Merge All) only pays one warehouse round-trip.
        """
        cache_key = (entity_name, experiment)
        if cache_key in self._embedding_col_cache:
            return self._embedding_col_cache[cache_key]

        table_name = f"{entity_name}_master_{experiment}"
        # Backtick-quote the identifier path so an apostrophe in entity_name (e.g. O'Brien)
        # can't break out of the identifier. Backticks inside an identifier are escaped by
        # doubling them. Apply the same treatment to catalog_name for consistency, even
        # though Unity Catalog naming rules currently disallow backticks in catalog names.
        catalog_quoted = self.catalog_name.replace("`", "``")
        master_tbl_quoted = (
            f"`{catalog_quoted}`.`gold`.`{table_name.replace('`', '``')}`"
        )
        # Single-quote-escape the string literal used in information_schema.
        table_name_escaped = table_name.replace("'", "''")

        has_col: bool
        try:
            sql_service = DataSetSQLService(token, warehouse_id)
            result = sql_service.execute_sql_script(
                f"BEGIN SELECT column_name FROM `{catalog_quoted}`.information_schema.columns "
                f"WHERE table_schema = 'gold' "
                f"  AND table_name = '{table_name_escaped}' "
                f"  AND lower(column_name) = 'attributes_combined_embedding'; END"
            )
            has_col = len(result.get("result") or []) > 0
            self._embedding_col_cache[cache_key] = has_col
            return has_col
        except Exception as e:
            app_logger.warning(
                f"information_schema lookup failed for {master_tbl_quoted}, falling back to DESCRIBE TABLE: {e}"
            )

        try:
            sql_service = DataSetSQLService(token, warehouse_id)
            result = sql_service.execute_sql_script(
                f"BEGIN SELECT col_name FROM (DESCRIBE TABLE {master_tbl_quoted}) "
                f"WHERE lower(col_name) = 'attributes_combined_embedding'; END"
            )
            has_col = len(result.get("result") or []) > 0
            self._embedding_col_cache[cache_key] = has_col
            return has_col
        except Exception as e:
            app_logger.error(
                f"Both information_schema and DESCRIBE TABLE failed for {master_tbl_quoted}: {e}. "
                f"Embedding invalidation will be skipped — precomputed-mode embeddings may go stale."
            )
            # Don't cache failures — let the next call retry in case the warehouse
            # was transiently unavailable.
            return False

    def build_merge_sql_script(
        self,
        catalog: str,
        entity_name: str,
        experiment: str,
        master_id: str,
        surrogate_keys: list,
        attributes: list,
        survivorship_rules: list,
        created_by: str,
        has_embedding_col: bool = False
    ) -> str:
        """Build a BEGIN...END SQL script for the merge stewardship operation."""

        # Table names
        master_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}"
        unified_tbl = f"{catalog}.silver.{entity_name}_unified_{experiment}"
        activities_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_merge_activities"
        attrsrc_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_attribute_version_sources"

        # Dynamic column fragments
        col_list = ", ".join(a['name'] for a in attributes)
        struct_fields = ", ".join(
            f"CAST({a['name']} AS STRING) AS {a['name']}" for a in attributes
        )
        json_extracts = ",\n      ".join(
            f"CAST(get_json_object(v_json, '$.resultant_record.{a['name']}') AS {a['type']}) AS {a['name']}"
            for a in attributes
        )
        merge_set = ",\n      ".join(
            f"t.{a['name']} = s.{a['name']}" for a in attributes
        )
        # COALESCE so NULL attributes become '' — concat_ws would otherwise skip them
        # and collapse separators, producing a different attributes_combined than the
        # rest of the pipeline (which uses coalesce(...cast..., lit("")) — see
        # dbx_pipeline_artifacts/src/integration-core/normal_deduplication/Manual_Merge.py).
        concat_fields = ", ".join(
            f"COALESCE(CAST(s.{a['name']} AS STRING), '')" for a in attributes
        )

        # When attributes_combined is rewritten the precomputed embedding becomes stale.
        # Compute_Embeddings.py only refills rows where the embedding IS NULL, so we must
        # invalidate it here. Gate on column presence — managed-mode tables lack it.
        embedding_null_set = ",\n      t.attributes_combined_embedding = NULL" if has_embedding_col else ""

        # Escape single quotes in JSON strings for SQL embedding
        sk_json = json.dumps(surrogate_keys).replace("'", "''")
        rules_json = json.dumps(survivorship_rules).replace("'", "''")
        attrs_json = json.dumps([a['name'] for a in attributes]).replace("'", "''")
        dtypes_json = json.dumps({a['name']: a['type'] for a in attributes}).replace("'", "''")
        created_by_escaped = created_by.replace("'", "''")

        sql = f"""-- =====================================================================
-- STEWARDSHIP MERGE — Dynamic SQL Script
-- Entity:    {entity_name}
-- Master:    {master_id}
-- Merging:   {', '.join(surrogate_keys)}
-- Triggered: {created_by}
-- =====================================================================
BEGIN
  DECLARE v_master_exists INT;
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;
  DECLARE v_json STRING;

  -- [1] Validate master exists + get current version
  SET v_master_exists = (SELECT COUNT(*) FROM {master_tbl} WHERE lakefusion_id = '{master_id}');

  IF v_master_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Master record not found: {master_id}';
  END IF;

  SET v_max_version = (SELECT COALESCE(MAX(version), 0) FROM {activities_tbl} WHERE master_id = '{master_id}');
  SET v_new_version = v_max_version + 1;

  -- [2] Collect contributors + apply survivorship UDF
  SET v_json = (
    SELECT {catalog}.metadata.survivorship_apply(
      records_json,
      '{rules_json}',
      '{attrs_json}',
      '{dtypes_json}',
      'surrogate_key'
    )
    FROM (
      SELECT to_json(collect_list(struct(
        surrogate_key AS surrogate_key,
        source_path AS source_path,
        {struct_fields}
      ))) AS records_json
      FROM {unified_tbl}
      WHERE (master_lakefusion_id = '{master_id}' AND record_status = 'MERGED')
         OR (surrogate_key IN (SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>'))) AND record_status = 'ACTIVE')
    )
  );

  -- [3] Update master table with survived attributes
  MERGE INTO {master_tbl} AS t
  USING (
    SELECT
      '{master_id}' AS lakefusion_id,
      {json_extracts}
  ) AS s ON t.lakefusion_id = s.lakefusion_id
  WHEN MATCHED THEN UPDATE SET
      {merge_set},
      t.attributes_combined = concat_ws(' | ', {concat_fields}){embedding_null_set};

  -- [4] Insert attribute version sources (include null-valued attributes with source)
  INSERT INTO {attrsrc_tbl} (lakefusion_id, version, attribute_source_mapping)
  SELECT
    '{master_id}',
    v_new_version,
    {self._build_complete_attr_mapping_sql(attributes, 'v_json', unified_tbl, master_id)};

  -- [5] Log merge activities
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    '{master_id}',
    sk.col1,
    (SELECT source_path FROM {unified_tbl} WHERE surrogate_key = sk.col1 LIMIT 1),
    v_new_version,
    'MANUAL_MERGE',
    current_timestamp()
  FROM (SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>')) AS col1) sk;

  -- [6] Mark unified records as MERGED
  MERGE INTO {unified_tbl} AS t
  USING (SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>')) AS sk) AS s
  ON t.surrogate_key = s.sk
  WHEN MATCHED THEN UPDATE SET
    t.master_lakefusion_id = '{master_id}',
    t.record_status = 'MERGED';

  -- Return new version
  SELECT v_new_version AS new_version;
END"""
        return sql

    def build_golden_dedup_merge_sql_script(
        self,
        catalog: str,
        entity_name: str,
        experiment: str,
        master_id: str,
        match_record_id: str,
        attributes: list,
        survivorship_rules: list,
        created_by: str,
        action_type: str = 'MASTER_MANUAL_MERGE',
        has_embedding_col: bool = False
    ) -> str:
        """Build a BEGIN...END SQL script for the golden deduplication merge (master-to-master)."""

        # Table names
        master_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}"
        unified_tbl = f"{catalog}.silver.{entity_name}_unified_{experiment}"
        activities_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_merge_activities"
        attrsrc_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_attribute_version_sources"

        # Dynamic column fragments (same as normal merge)
        struct_fields = ", ".join(
            f"CAST({a['name']} AS STRING) AS {a['name']}" for a in attributes
        )
        json_extracts = ",\n      ".join(
            f"CAST(get_json_object(v_json, '$.resultant_record.{a['name']}') AS {a['type']}) AS {a['name']}"
            for a in attributes
        )
        merge_set = ",\n      ".join(
            f"t.{a['name']} = s.{a['name']}" for a in attributes
        )
        # COALESCE preserves NULL positions as empty strings between separators.
        concat_fields = ", ".join(
            f"COALESCE(CAST(s.{a['name']} AS STRING), '')" for a in attributes
        )

        # Invalidate stale precomputed embedding when attributes_combined is rewritten.
        embedding_null_set = ",\n      t.attributes_combined_embedding = NULL" if has_embedding_col else ""

        rules_json = json.dumps(survivorship_rules).replace("'", "''")
        attrs_json = json.dumps([a['name'] for a in attributes]).replace("'", "''")
        dtypes_json = json.dumps({a['name']: a['type'] for a in attributes}).replace("'", "''")
        created_by_escaped = created_by.replace("'", "''")

        sql = f"""-- =====================================================================
-- STEWARDSHIP GOLDEN DEDUP MERGE — Dynamic SQL Script (Master-to-Master)
-- Entity:    {entity_name}
-- Survivor:  {master_id}
-- Absorbed:  {match_record_id}
-- Triggered: {created_by}
-- =====================================================================
BEGIN
  DECLARE v_survivor_exists INT;
  DECLARE v_absorbed_exists INT;
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;
  DECLARE v_json STRING;

  -- [1] Validate both masters exist
  SET v_survivor_exists = (SELECT COUNT(*) FROM {master_tbl} WHERE lakefusion_id = '{master_id}');
  SET v_absorbed_exists = (SELECT COUNT(*) FROM {master_tbl} WHERE lakefusion_id = '{match_record_id}');

  IF v_survivor_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Survivor master not found: {master_id}';
  END IF;
  IF v_absorbed_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Absorbed master not found: {match_record_id}';
  END IF;

  SET v_max_version = (SELECT COALESCE(MAX(version), 0) FROM {activities_tbl} WHERE master_id = '{master_id}');
  SET v_new_version = v_max_version + 1;

  -- [2] Collect ALL contributors from both masters + apply survivorship
  SET v_json = (
    SELECT {catalog}.metadata.survivorship_apply(
      records_json,
      '{rules_json}',
      '{attrs_json}',
      '{dtypes_json}',
      'surrogate_key'
    )
    FROM (
      SELECT to_json(collect_list(struct(
        surrogate_key AS surrogate_key,
        source_path AS source_path,
        {struct_fields}
      ))) AS records_json
      FROM {unified_tbl}
      WHERE master_lakefusion_id IN ('{master_id}', '{match_record_id}')
        AND record_status = 'MERGED'
    )
  );

  -- [3] Update survivor master with survived attributes
  MERGE INTO {master_tbl} AS t
  USING (
    SELECT
      '{master_id}' AS lakefusion_id,
      {json_extracts}
  ) AS s ON t.lakefusion_id = s.lakefusion_id
  WHEN MATCHED THEN UPDATE SET
      {merge_set},
      t.attributes_combined = concat_ws(' | ', {concat_fields}){embedding_null_set};

  -- [4] Delete absorbed master
  DELETE FROM {master_tbl} WHERE lakefusion_id = '{match_record_id}';

  -- [5] Reassign absorbed master's unified contributors to survivor
  MERGE INTO {unified_tbl} AS t
  USING (SELECT '{match_record_id}' AS old_master) AS s
  ON t.master_lakefusion_id = s.old_master AND t.record_status = 'MERGED'
  WHEN MATCHED THEN UPDATE SET
    t.master_lakefusion_id = '{master_id}';

  -- [6] Insert attribute version sources (include null-valued attributes with source)
  INSERT INTO {attrsrc_tbl} (lakefusion_id, version, attribute_source_mapping)
  SELECT
    '{master_id}',
    v_new_version,
    {self._build_complete_attr_mapping_sql(attributes, 'v_json', unified_tbl, master_id)};

  -- [7] Log merge activity
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    '{master_id}',
    '{match_record_id}',
    'MASTER_MERGE',
    v_new_version,
    '{action_type}',
    current_timestamp();

  -- Return new version
  SELECT v_new_version AS new_version;
END"""
        return sql

    def build_unmerge_sql_script(
        self,
        catalog: str,
        entity_name: str,
        experiment: str,
        master_id: str,
        surrogate_keys: list,
        attributes: list,
        survivorship_rules: list,
        created_by: str,
        has_embedding_col: bool = False
    ) -> str:
        """Build a BEGIN...END SQL script for the unmerge stewardship operation.

        Maps to the 13-step ManualUnmergeExecutor:
        1. Validate master exists
        2-4. Count contributors, validate, separate remaining vs unmerge
        5-6. Apply survivorship UDF on remaining contributors → update master
        7. Generate new lakefusion_ids for unmerged records
        8-9. Insert new masters for unmerged records + update existing master
        10-11. Insert attribute version sources for both
        12. Log merge activities (MANUAL_UNMERGE + JOB_INSERT)
        13. Update unified table (remap master_lakefusion_id)
        """

        # Table names
        master_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}"
        unified_tbl = f"{catalog}.silver.{entity_name}_unified_{experiment}"
        activities_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_merge_activities"
        attrsrc_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_attribute_version_sources"

        # Dynamic column fragments
        struct_fields = ", ".join(
            f"CAST({a['name']} AS STRING) AS {a['name']}" for a in attributes
        )
        json_extracts = ",\n      ".join(
            f"CAST(get_json_object(v_json, '$.resultant_record.{a['name']}') AS {a['type']}) AS {a['name']}"
            for a in attributes
        )
        merge_set = ",\n      ".join(
            f"t.{a['name']} = s.{a['name']}" for a in attributes
        )
        # COALESCE preserves NULL positions as empty strings between separators.
        concat_fields = ", ".join(
            f"COALESCE(CAST(s.{a['name']} AS STRING), '')" for a in attributes
        )

        # Cast expressions for unmerge records → master insert (from unified columns)
        unmerge_select_cols = ", ".join(
            f"CAST(u.{a['name']} AS {a['type']}) AS {a['name']}" for a in attributes
        )
        # For attributes_combined on unmerge inserts — same NULL-position safety.
        unmerge_concat = ", ".join(
            f"COALESCE(CAST(u.{a['name']} AS STRING), '')" for a in attributes
        )
        # Explicit column list for INSERT (avoids DELTA_MERGE_UNRESOLVED_EXPRESSION
        # when master table has extra columns like attributes_combined_embedding).
        # When the master carries attributes_combined_embedding, include it explicitly
        # as NULL so Compute_Embeddings.py refills it on the next pipeline run.
        insert_cols = "lakefusion_id, " + ", ".join(a['name'] for a in attributes) + ", attributes_combined"
        insert_values_attrs = ", ".join(f"s.{a['name']}" for a in attributes)
        if has_embedding_col:
            insert_cols += ", attributes_combined_embedding"
            insert_embedding_value = ", CAST(NULL AS ARRAY<FLOAT>)"
        else:
            insert_embedding_value = ""

        # When attributes_combined is rewritten the precomputed embedding becomes stale.
        embedding_null_set = ",\n      t.attributes_combined_embedding = NULL" if has_embedding_col else ""

        # Escape single quotes in JSON strings for SQL embedding
        sk_json = json.dumps(surrogate_keys).replace("'", "''")
        rules_json = json.dumps(survivorship_rules).replace("'", "''")
        attrs_json = json.dumps([a['name'] for a in attributes]).replace("'", "''")
        dtypes_json = json.dumps({a['name']: a['type'] for a in attributes}).replace("'", "''")
        created_by_escaped = created_by.replace("'", "''")

        # Build the per-unmerge-record INSERT for new masters + attr version sources + activities
        # Generate new lakefusion_ids in Python (uuid4 without dashes — same as generate_lakefusion_id())
        import uuid as _uuid
        sk_to_new_id = {}
        for sk in surrogate_keys:
            sk_to_new_id[sk] = str(_uuid.uuid4()).replace("-", "")

        # Build VALUES clause for surrogate_key → new_lakefusion_id mapping temp table
        mapping_values = ", ".join(
            f"('{sk}', '{new_id}')" for sk, new_id in sk_to_new_id.items()
        )

        sql = f"""-- =====================================================================
-- STEWARDSHIP UNMERGE — Dynamic SQL Script
-- Entity:    {entity_name}
-- Master:    {master_id}
-- Unmerging: {', '.join(surrogate_keys)}
-- Triggered: {created_by}
-- =====================================================================
BEGIN
  DECLARE v_master_exists INT;
  DECLARE v_total_contributors INT;
  DECLARE v_unmerge_count INT;
  DECLARE v_remaining_count INT;
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;
  DECLARE v_json STRING;

  -- [1] Validate master exists
  SET v_master_exists = (SELECT COUNT(*) FROM {master_tbl} WHERE lakefusion_id = '{master_id}');
  IF v_master_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Master record not found: {master_id}';
  END IF;

  -- [2] Count total contributors and validate
  SET v_total_contributors = (
    SELECT COUNT(*) FROM {unified_tbl}
    WHERE master_lakefusion_id = '{master_id}' AND record_status = 'MERGED'
  );

  SET v_unmerge_count = (
    SELECT COUNT(*) FROM {unified_tbl}
    WHERE master_lakefusion_id = '{master_id}'
      AND record_status = 'MERGED'
      AND surrogate_key IN (SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>')))
  );

  SET v_remaining_count = v_total_contributors - v_unmerge_count;

  IF v_unmerge_count = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'None of the specified records are contributors to this master';
  END IF;

  IF v_remaining_count = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot unmerge - would leave master with no contributors';
  END IF;

  -- [3] Create temp mapping of surrogate_key → new_lakefusion_id
  DROP TEMPORARY TABLE IF EXISTS _unmerge_id_map;
  CREATE TEMPORARY TABLE _unmerge_id_map AS
  SELECT col1 AS surrogate_key, col2 AS new_lakefusion_id
  FROM VALUES {mapping_values};

  -- [4] Apply survivorship on REMAINING contributors (exclude unmerge records)
  SET v_json = (
    SELECT {catalog}.metadata.survivorship_apply(
      records_json,
      '{rules_json}',
      '{attrs_json}',
      '{dtypes_json}',
      'surrogate_key'
    )
    FROM (
      SELECT to_json(collect_list(struct(
        surrogate_key AS surrogate_key,
        source_path AS source_path,
        {struct_fields}
      ))) AS records_json
      FROM {unified_tbl}
      WHERE master_lakefusion_id = '{master_id}'
        AND record_status = 'MERGED'
        AND surrogate_key NOT IN (SELECT surrogate_key FROM _unmerge_id_map)
    )
  );

  -- [5] Get next version
  SET v_max_version = (SELECT MAX(version) FROM (DESCRIBE HISTORY {master_tbl} LIMIT 1));
  SET v_new_version = v_max_version + 1;

  -- [6] Update existing master with re-survivored values
  MERGE INTO {master_tbl} AS t
  USING (
    SELECT
      '{master_id}' AS lakefusion_id,
      {json_extracts}
  ) AS s ON t.lakefusion_id = s.lakefusion_id
  WHEN MATCHED THEN UPDATE SET
      {merge_set},
      t.attributes_combined = concat_ws(' | ', {concat_fields}){embedding_null_set};

  -- [7] Insert new masters for each unmerged record (promoted to independent master)
  MERGE INTO {master_tbl} AS t
  USING (
    SELECT
      m.new_lakefusion_id AS lakefusion_id,
      {unmerge_select_cols},
      concat_ws(' | ', {unmerge_concat}) AS attributes_combined
    FROM {unified_tbl} u
    INNER JOIN _unmerge_id_map m ON u.surrogate_key = m.surrogate_key
  ) AS s ON t.lakefusion_id = s.lakefusion_id
  WHEN NOT MATCHED THEN INSERT ({insert_cols})
    VALUES (s.lakefusion_id, {insert_values_attrs}, s.attributes_combined{insert_embedding_value});

  -- [8] Insert attribute version sources for updated master (with complete mapping)
  INSERT INTO {attrsrc_tbl} (lakefusion_id, version, attribute_source_mapping)
  SELECT
    '{master_id}',
    v_new_version,
    {self._build_complete_attr_mapping_sql(attributes, 'v_json', unified_tbl, master_id)};

  -- [9] Insert attribute version sources for each unmerged record (single contributor)
  INSERT INTO {attrsrc_tbl} (lakefusion_id, version, attribute_source_mapping)
  SELECT
    m.new_lakefusion_id,
    v_new_version,
    array({", ".join(
        f"named_struct('attribute_name', '{a['name']}', 'attribute_value', CAST(u.{a['name']} AS STRING), 'source', u.source_path)"
        for a in attributes
    )})
  FROM {unified_tbl} u
  INNER JOIN _unmerge_id_map m ON u.surrogate_key = m.surrogate_key;

  -- [10] Log MANUAL_UNMERGE activities (record leaves original master)
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    '{master_id}',
    u.surrogate_key,
    u.source_path,
    v_new_version,
    'MANUAL_UNMERGE',
    current_timestamp()
  FROM {unified_tbl} u
  INNER JOIN _unmerge_id_map m ON u.surrogate_key = m.surrogate_key;

  -- [11] Log JOB_INSERT activities (record promoted to new master)
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    m.new_lakefusion_id,
    u.surrogate_key,
    u.source_path,
    v_new_version,
    'JOB_INSERT',
    current_timestamp()
  FROM {unified_tbl} u
  INNER JOIN _unmerge_id_map m ON u.surrogate_key = m.surrogate_key;

  -- [12] Update unified table — remap unmerged records to new master IDs
  MERGE INTO {unified_tbl} AS t
  USING _unmerge_id_map AS s
  ON t.surrogate_key = s.surrogate_key
  WHEN MATCHED THEN UPDATE SET
    t.master_lakefusion_id = s.new_lakefusion_id;

  -- Return new version and new lakefusion IDs
  SELECT v_new_version AS new_version, to_json(collect_list(struct(surrogate_key, new_lakefusion_id))) AS id_mapping
  FROM _unmerge_id_map;
END"""
        return sql

    def run_unmerge_sql(self, entity_id: int, unmerge_record, token, created_by, warehouse_id: str = None):
        """Execute unmerge via SQL warehouse instead of notebook job."""
        try:
            # Load entity metadata as dict
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            # Get entity attributes (PK first, then rest)
            all_attrs = entity_dict.get('attributes', [])
            pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and a.get('is_primary_key')]
            non_pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and not a.get('is_primary_key')]
            attributes = pk_attrs + non_pk_attrs

            # Resolve survivorship rules (dataset_id → path)
            survivorship_rules = self._resolve_survivorship_rules(entity_dict)

            # Extract surrogate keys
            surrogate_keys = [str(i.id) for i in unmerge_record.unified_dataset_ids]

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots BEFORE the unmerge
            attr_names = [a['name'] for a in attributes]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(unmerge_record.master_id),
                match_id=surrogate_keys[0] if surrogate_keys else None,
                attr_names=attr_names
            )

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            # Build SQL script
            sql_script = self.build_unmerge_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(unmerge_record.master_id),
                surrogate_keys=surrogate_keys,
                attributes=attributes,
                survivorship_rules=survivorship_rules,
                created_by=created_by,
                has_embedding_col=has_embedding_col
            )

            # Execute on SQL warehouse with retry on Delta concurrency conflicts
            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"UNMERGE master={unmerge_record.master_id}"
            )

            # Write steward decision
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id, 'UNMERGE',
                str(unmerge_record.master_id), surrogate_keys[0] if surrogate_keys else "",
                sd_master, sd_match, created_by
            )

            # Store tracking record
            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            entity_search_jobs_list = []
            for i in unmerge_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=str(unmerge_record.master_id),
                    profile_id=str(i.id),
                    operation_type='UNMERGE',
                    job_run_id=None,
                    status=StewardshipJobStatus.QUERY_COMPLETED.value,
                    job_run_status={"execution_type": "query", "result": "success"},
                    created_by=created_by,
                    execution_type='query',
                    query_id=str(query_id)
                )
                self.db.add(entity_search_jobs)
                entity_search_jobs_list.append(entity_search_jobs)

            self.db.commit()
            for job in entity_search_jobs_list:
                self.db.refresh(job)

            return entity_search_jobs_list[0] if entity_search_jobs_list else None

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL stewardship unmerge failed: {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to unmerge records via SQL: {str(e)}"
            )

    def run_match_merge_sql(self, entity_id: int, potential_record, token, created_by, warehouse_id: str = None):
        """Execute merge via SQL warehouse instead of notebook job."""
        try:
            # Load entity metadata as dict
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            # Get entity attributes (PK first, then rest)
            all_attrs = entity_dict.get('attributes', [])
            pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and a.get('is_primary_key')]
            non_pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and not a.get('is_primary_key')]
            attributes = pk_attrs + non_pk_attrs

            # Resolve survivorship rules (dataset_id → path)
            survivorship_rules = self._resolve_survivorship_rules(entity_dict)

            # Extract surrogate keys
            surrogate_keys = [str(i.id) for i in potential_record.unified_dataset_ids]

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots BEFORE the merge
            attr_names = [a['name'] for a in attributes]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(potential_record.master_id),
                match_id=surrogate_keys[0] if surrogate_keys else None,
                attr_names=attr_names
            )

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            # Build SQL script
            sql_script = self.build_merge_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(potential_record.master_id),
                surrogate_keys=surrogate_keys,
                attributes=attributes,
                survivorship_rules=survivorship_rules,
                created_by=created_by,
                has_embedding_col=has_embedding_col
            )

            # Execute on SQL warehouse with retry on Delta concurrency conflicts
            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"MERGE master={potential_record.master_id}"
            )

            # Write steward decision with frozen snapshots
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id,
                potential_record.operation_type or 'MERGE',
                str(potential_record.master_id), surrogate_keys[0] if surrogate_keys else "",
                sd_master, sd_match, created_by
            )

            # Store tracking record
            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            for i in potential_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=str(potential_record.master_id),
                    profile_id=str(i.id),
                    operation_type=potential_record.operation_type or 'MERGE',
                    job_run_id=None,
                    status=StewardshipJobStatus.QUERY_COMPLETED.value,
                    job_run_status={"execution_type": "query", "result": "success"},
                    created_by=created_by,
                    execution_type='query',
                    query_id=str(query_id)
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL stewardship merge failed: {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records via SQL: {str(e)}"
            )

    def run_golden_dedup_merge_sql(self, entity_id: int, potential_record, token, created_by, warehouse_id: str = None):
        """Execute golden deduplication merge (master-to-master) via SQL warehouse."""
        try:
            # Load entity metadata as dict
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            # Get entity attributes (PK first, then rest)
            all_attrs = entity_dict.get('attributes', [])
            pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and a.get('is_primary_key')]
            non_pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and not a.get('is_primary_key')]
            attributes = pk_attrs + non_pk_attrs

            # Resolve survivorship rules (dataset_id → path)
            survivorship_rules = self._resolve_survivorship_rules(entity_dict)

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots BEFORE the merge (both from master table)
            attr_names = [a['name'] for a in attributes]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(potential_record.master_id),
                match_id=str(potential_record.match_record_id),
                attr_names=attr_names, is_master_to_master=True
            )

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            # Build SQL script
            sql_script = self.build_golden_dedup_merge_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(potential_record.master_id),
                match_record_id=str(potential_record.match_record_id),
                attributes=attributes,
                survivorship_rules=survivorship_rules,
                created_by=created_by,
                has_embedding_col=has_embedding_col
            )

            # Execute on SQL warehouse with retry
            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"GOLDEN_MERGE survivor={potential_record.master_id} absorbed={potential_record.match_record_id}"
            )

            # Write steward decision
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id,
                potential_record.operation_type or 'MERGE',
                str(potential_record.master_id), str(potential_record.match_record_id),
                sd_master, sd_match, created_by
            )

            # Store tracking record
            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            entity_search_jobs = Model_Databricks_Entity_Search_Job(
                entity_id=entity_id,
                master_id=str(potential_record.master_id),
                profile_id=str(potential_record.match_record_id),
                operation_type=potential_record.operation_type or 'MERGE',
                job_run_id=None,
                status=StewardshipJobStatus.QUERY_COMPLETED.value,
                job_run_status={"execution_type": "query", "result": "success"},
                created_by=created_by,
                execution_type='query',
                query_id=str(query_id)
            )
            self.db.add(entity_search_jobs)
            self.db.commit()
            self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL golden dedup merge failed: {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge masters via SQL: {str(e)}"
            )

    def build_not_a_match_sql_script(
        self,
        catalog: str,
        entity_name: str,
        experiment: str,
        master_id: str,
        surrogate_keys: list,
        attributes: list,
        created_by: str,
        has_embedding_col: bool = False
    ) -> str:
        """Build a BEGIN...END SQL script for the not-a-match stewardship operation."""

        master_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}"
        unified_tbl = f"{catalog}.silver.{entity_name}_unified_{experiment}"
        activities_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_merge_activities"
        attrsrc_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_attribute_version_sources"
        pm_tbl = f"{catalog}.gold.{entity_name}_master_potential_match_{experiment}"

        col_list = ", ".join(a['name'] for a in attributes)
        # COALESCE preserves NULL positions as empty strings between separators.
        concat_fields = ", ".join(f"COALESCE(CAST({a['name']} AS STRING), '')" for a in attributes)
        concat_fields_nm = ", ".join(f"COALESCE(CAST(nm.{a['name']} AS STRING), '')" for a in attributes)
        # Explicit column list for INSERT (avoids DELTA_MERGE_UNRESOLVED_EXPRESSION
        # when master table has extra columns like attributes_combined_embedding).
        # When the master carries attributes_combined_embedding, include it explicitly
        # as NULL so Compute_Embeddings.py refills it on the next pipeline run.
        insert_cols = "lakefusion_id, " + ", ".join(a['name'] for a in attributes) + ", attributes_combined"
        insert_values_attrs = ", ".join(f"s.{a['name']}" for a in attributes)
        if has_embedding_col:
            insert_cols += ", attributes_combined_embedding"
            insert_embedding_value = ", CAST(NULL AS ARRAY<FLOAT>)"
        else:
            insert_embedding_value = ""

        sk_json = json.dumps(surrogate_keys).replace("'", "''")
        created_by_escaped = created_by.replace("'", "''")

        sql = f"""-- =====================================================================
-- STEWARDSHIP NOT-A-MATCH — Dynamic SQL Script
-- Entity:    {entity_name}
-- Master:    {master_id}
-- Rejecting: {', '.join(surrogate_keys)}
-- Triggered: {created_by}
-- =====================================================================
BEGIN
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;
  DECLARE v_records_without_other_matches INT;

  -- [1] Get current version
  SET v_max_version = (SELECT COALESCE(MAX(version), 0) FROM {activities_tbl} WHERE master_id = '{master_id}');
  SET v_new_version = v_max_version + 1;

  -- [2] Log MANUAL_NOT_A_MATCH activities
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    '{master_id}',
    sk.col1,
    (SELECT source_path FROM {unified_tbl} WHERE surrogate_key = sk.col1 LIMIT 1),
    v_new_version,
    'MANUAL_NOT_A_MATCH',
    current_timestamp()
  FROM (SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>')) AS col1) sk;

  -- [3] Check which rejected records have OTHER pending matches on other masters
  CREATE OR REPLACE TEMPORARY VIEW _rejected_keys AS
  SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>')) AS surrogate_key;

  -- Find records that have other PENDING matches (excluding current master)
  CREATE OR REPLACE TEMPORARY VIEW _with_other_matches AS
  SELECT DISTINCT pm_match.surrogate_key
  FROM {pm_tbl} pm
  LATERAL VIEW explode(pm.potential_matches) AS pm_match
  WHERE pm_match.__mergestatus__ = 'PENDING'
    AND pm_match.surrogate_key IN (SELECT surrogate_key FROM _rejected_keys)
    AND pm.lakefusion_id != '{master_id}';

  -- Records WITHOUT other matches → need to be promoted to their own master
  -- This is the stable "should promote" set — doesn't change on retry
  CREATE OR REPLACE TEMPORARY VIEW _to_promote AS
  SELECT rk.surrogate_key
  FROM _rejected_keys rk
  LEFT JOIN _with_other_matches wom ON rk.surrogate_key = wom.surrogate_key
  WHERE wom.surrogate_key IS NULL;

  -- Also filter out records already merged via merge_activities (JOB_MERGE/MANUAL_MERGE means already absorbed)
  CREATE OR REPLACE TEMPORARY VIEW _promotable AS
  SELECT tp.surrogate_key
  FROM _to_promote tp
  LEFT JOIN (
    SELECT DISTINCT match_id FROM {activities_tbl}
    WHERE action_type IN ('JOB_MERGE', 'MANUAL_MERGE') AND match_id IS NOT NULL AND match_id != ''
  ) ma ON tp.surrogate_key = ma.match_id
  WHERE ma.match_id IS NULL;

  SET v_records_without_other_matches = (SELECT COUNT(*) FROM _promotable);

  -- [4] If records need promotion, run all steps idempotently
  IF v_records_without_other_matches > 0 THEN

    -- Generate new lakefusion_ids — materialized as temp table so UUID is stable across all references
    -- (On retry, if unified already has master_lakefusion_id assigned, reuse it)
    DROP TABLE IF EXISTS _new_masters;
    CREATE TEMPORARY TABLE _new_masters AS
    SELECT
      p.surrogate_key,
      CASE WHEN u.master_lakefusion_id IS NOT NULL AND u.master_lakefusion_id != '' THEN u.master_lakefusion_id ELSE replace(uuid(), '-', '') END AS new_lakefusion_id,
      u.source_path,
      {', '.join(f"u.{a['name']}" for a in attributes)}
    FROM _promotable p
    INNER JOIN {unified_tbl} u ON p.surrogate_key = u.surrogate_key;

    -- Insert into master table (idempotent — WHEN NOT MATCHED skips existing)
    MERGE INTO {master_tbl} AS t
    USING (
      SELECT
        nm.new_lakefusion_id AS lakefusion_id,
        {col_list},
        concat_ws(' | ', {concat_fields_nm}) AS attributes_combined
      FROM _new_masters nm
    ) AS s ON t.lakefusion_id = s.lakefusion_id
    WHEN NOT MATCHED THEN INSERT ({insert_cols})
      VALUES (s.lakefusion_id, {insert_values_attrs}, s.attributes_combined{insert_embedding_value});

    -- Update unified table: assign new master and mark as MERGED
    -- (idempotent — if already MERGED with correct master, no change)
    MERGE INTO {unified_tbl} AS t
    USING _new_masters AS s
    ON t.surrogate_key = s.surrogate_key
    WHEN MATCHED AND (t.record_status != 'MERGED' OR t.master_lakefusion_id IS NULL OR t.master_lakefusion_id = '') THEN UPDATE SET
      t.master_lakefusion_id = s.new_lakefusion_id,
      t.record_status = 'MERGED';

    -- Log JOB_INSERT activities (idempotent — use MERGE to avoid duplicates)
    MERGE INTO {activities_tbl} AS t
    USING (
      SELECT
        nm.new_lakefusion_id AS master_id,
        nm.surrogate_key AS match_id,
        nm.source_path AS source,
        v_new_version AS version,
        'JOB_INSERT' AS action_type,
        current_timestamp() AS created_at
      FROM _new_masters nm
    ) AS s
    ON t.master_id = s.master_id AND t.match_id = s.match_id AND t.action_type = 'JOB_INSERT'
    WHEN NOT MATCHED THEN INSERT *;

    -- Insert attribute version sources (idempotent — MERGE to avoid duplicates)
    MERGE INTO {attrsrc_tbl} AS t
    USING (
      SELECT
        nm.new_lakefusion_id AS lakefusion_id,
        v_new_version AS version,
        array({', '.join(
            f"named_struct('attribute_name', '{a['name']}', 'attribute_value', CAST(nm.{a['name']} AS STRING), 'source', nm.source_path)"
            for a in attributes
        )}) AS attribute_source_mapping
      FROM _new_masters nm
    ) AS s
    ON t.lakefusion_id = s.lakefusion_id AND t.version = s.version
    WHEN NOT MATCHED THEN INSERT *;

  END IF;

  -- Return results
  SELECT v_new_version AS new_version, v_records_without_other_matches AS promoted_count;
END"""
        return sql

    def run_not_a_match_sql(self, entity_id: int, potential_record, token, created_by, warehouse_id: str = None):
        """Execute not-a-match via SQL warehouse instead of notebook job."""
        try:
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            all_attrs = entity_dict.get('attributes', [])
            pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and a.get('is_primary_key')]
            non_pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and not a.get('is_primary_key')]
            attributes = pk_attrs + non_pk_attrs

            surrogate_keys = [str(i.id) for i in potential_record.unified_dataset_ids]

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots BEFORE not-a-match
            attr_names = [a['name'] for a in attributes]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(potential_record.master_id),
                match_id=surrogate_keys[0] if surrogate_keys else None,
                attr_names=attr_names
            )

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            sql_script = self.build_not_a_match_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(potential_record.master_id),
                surrogate_keys=surrogate_keys,
                attributes=attributes,
                created_by=created_by,
                has_embedding_col=has_embedding_col
            )

            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"NOT_A_MATCH master={potential_record.master_id}"
            )

            # Write steward decision
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id, 'NOT_A_MATCH',
                str(potential_record.master_id), surrogate_keys[0] if surrogate_keys else "",
                sd_master, sd_match, created_by
            )

            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            for i in potential_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=str(potential_record.master_id),
                    profile_id=str(i.id),
                    operation_type='NOT_A_MATCH',
                    job_run_id=None,
                    status=StewardshipJobStatus.QUERY_COMPLETED.value,
                    job_run_status={"execution_type": "query", "result": "success"},
                    created_by=created_by,
                    execution_type='query',
                    query_id=str(query_id)
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL not-a-match failed: {message}')
            raise HTTPException(status_code=500, detail=f"Failed to mark as not-a-match via SQL: {str(e)}")

    def build_golden_dedup_not_a_match_sql_script(
        self,
        catalog: str,
        entity_name: str,
        experiment: str,
        master_id: str,
        match_record_id: str,
        created_by: str
    ) -> str:
        """Build SQL script for golden dedup not-a-match (simpler — just log the rejection)."""

        activities_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_merge_activities"

        sql = f"""-- =====================================================================
-- STEWARDSHIP GOLDEN DEDUP NOT-A-MATCH — Dynamic SQL Script
-- Entity:    {entity_name}
-- Master:    {master_id}
-- Rejected:  {match_record_id}
-- Triggered: {created_by}
-- =====================================================================
BEGIN
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;

  SET v_max_version = (SELECT COALESCE(MAX(version), 0) FROM {activities_tbl} WHERE master_id = '{master_id}');
  SET v_new_version = v_max_version + 1;

  -- Log MANUAL_NOT_A_MATCH activity
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  VALUES ('{master_id}', '{match_record_id}', 'MASTER_NOT_A_MATCH', v_new_version, 'MANUAL_NOT_A_MATCH', current_timestamp());

  SELECT v_new_version AS new_version;
END"""
        return sql

    def run_golden_dedup_not_a_match_sql(self, entity_id: int, potential_record, token, created_by, warehouse_id: str = None):
        """Execute golden dedup not-a-match via SQL warehouse."""
        try:
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots (both from master table)
            all_attrs = entity_dict.get('attributes', [])
            attr_names = [a['name'] for a in all_attrs if a.get('is_active')]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(potential_record.master_id),
                match_id=str(potential_record.match_record_id),
                attr_names=attr_names, is_master_to_master=True
            )

            sql_script = self.build_golden_dedup_not_a_match_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(potential_record.master_id),
                match_record_id=str(potential_record.match_record_id),
                created_by=created_by
            )

            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"GOLDEN_NOT_A_MATCH master={potential_record.master_id}"
            )

            # Write steward decision
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id, 'NOT_A_MATCH',
                str(potential_record.master_id), str(potential_record.match_record_id),
                sd_master, sd_match, created_by
            )

            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            entity_search_jobs = Model_Databricks_Entity_Search_Job(
                entity_id=entity_id,
                master_id=str(potential_record.master_id),
                profile_id=str(potential_record.match_record_id),
                operation_type='NOT_A_MATCH',
                job_run_id=None,
                status=StewardshipJobStatus.QUERY_COMPLETED.value,
                job_run_status={"execution_type": "query", "result": "success"},
                created_by=created_by,
                execution_type='query',
                query_id=str(query_id)
            )
            self.db.add(entity_search_jobs)
            self.db.commit()
            self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL golden dedup not-a-match failed: {message}')
            raise HTTPException(status_code=500, detail=f"Failed golden dedup not-a-match via SQL: {str(e)}")

    # =========================================================================
    # SQL Stewardship: Manual Update (Profile Edit) via SQL Warehouse
    # =========================================================================

    def build_manual_update_sql_script(
        self,
        catalog: str,
        entity_name: str,
        lakefusion_id: str,
        update_attributes: dict,
        entity_attribute_names: list,
        entity_attributes_with_types: list,
        created_by: str,
        has_embedding_col: bool = False
    ) -> str:
        """Build a BEGIN...END SQL script for manual profile update.

        Maps to the 6-step Manual_Update.py notebook:
        1. Validate master exists
        2. Get current attribute source mapping (latest version)
        3. Update master table (changed attrs + attributes_combined)
        4. Insert attribute version sources (MANUAL_UPDATE for changed, preserve existing)
        5. Insert merge activity (MANUAL_UPDATE)
        6. Clear stale scoring_results in unified table
        """

        # Table names
        master_tbl = f"{catalog}.gold.{entity_name}_master_prod"
        activities_tbl = f"{catalog}.gold.{entity_name}_master_prod_merge_activities"
        attrsrc_tbl = f"{catalog}.gold.{entity_name}_master_prod_attribute_version_sources"
        unified_tbl = f"{catalog}.silver.{entity_name}_unified_prod"

        lakefusion_id_escaped = lakefusion_id.replace("'", "''")
        created_by_escaped = created_by.replace("'", "''")

        # Build SET clause for master table update
        set_clauses = []
        for attr_name, attr_value in update_attributes.items():
            if attr_value is None:
                set_clauses.append(f"{attr_name} = NULL")
            else:
                escaped_value = str(attr_value).replace("'", "''")
                set_clauses.append(f"{attr_name} = '{escaped_value}'")
        set_clause = ", ".join(set_clauses)

        # Build attributes_combined rebuild expression.
        # COALESCE preserves NULL positions as empty strings between separators.
        concat_parts = ", ".join(
            f"COALESCE(CAST({attr_name} AS STRING), '')" for attr_name in entity_attribute_names
        )

        # Invalidate stale precomputed embedding when attributes_combined is rewritten.
        embedding_null_set = ", attributes_combined_embedding = NULL" if has_embedding_col else ""

        # Build attribute source mapping array of named_structs
        # For changed attrs: source = 'MANUAL_UPDATE' with new value
        # For unchanged attrs: preserve from latest version or use current master value with INITIAL_LOAD
        # This must be computed dynamically in SQL using the current mapping
        mapping_schema = "ARRAY<STRUCT<attribute_name:STRING, attribute_value:STRING, source:STRING>>"

        # Build the CASE expression for each attribute
        attr_struct_parts = []
        for attr_name in entity_attribute_names:
            escaped_name = attr_name.replace("'", "''")
            if attr_name in update_attributes:
                # Changed attribute — use MANUAL_UPDATE source
                new_val = update_attributes[attr_name]
                if new_val is None:
                    val_sql = "NULL"
                else:
                    val_sql = "'" + str(new_val).replace("'", "''") + "'"
                attr_struct_parts.append(
                    f"named_struct('attribute_name', '{escaped_name}', 'attribute_value', {val_sql}, 'source', 'MANUAL_UPDATE')"
                )
            else:
                # Unchanged attribute — preserve existing source from latest mapping, or fallback to master value
                attr_struct_parts.append(
                    f"named_struct('attribute_name', '{escaped_name}', "
                    f"'attribute_value', COALESCE("
                    f"(SELECT e.attribute_value FROM (SELECT inline(v_current_mapping)) e WHERE e.attribute_name = '{escaped_name}'), "
                    f"CAST((SELECT m.{attr_name} FROM {master_tbl} m WHERE m.lakefusion_id = '{lakefusion_id_escaped}') AS STRING)), "
                    f"'source', COALESCE("
                    f"(SELECT e.source FROM (SELECT inline(v_current_mapping)) e WHERE e.attribute_name = '{escaped_name}'), "
                    f"'INITIAL_LOAD'))"
                )

        mapping_sql = f"array({', '.join(attr_struct_parts)})"

        sql = f"""-- =====================================================================
-- STEWARDSHIP MANUAL UPDATE — Dynamic SQL Script
-- Entity:       {entity_name}
-- LakeFusion ID: {lakefusion_id}
-- Triggered:    {created_by}
-- =====================================================================
BEGIN
  DECLARE v_master_exists INT;
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;
  DECLARE v_current_mapping {mapping_schema};

  -- [1] Validate master record exists
  SET v_master_exists = (SELECT COUNT(*) FROM {master_tbl} WHERE lakefusion_id = '{lakefusion_id_escaped}');

  IF v_master_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Master record not found: {lakefusion_id_escaped}';
  END IF;

  -- [2] Get current attribute source mapping (latest version)
  SET v_current_mapping = (
    SELECT attribute_source_mapping
    FROM {attrsrc_tbl}
    WHERE lakefusion_id = '{lakefusion_id_escaped}'
    ORDER BY version DESC
    LIMIT 1
  );

  -- Get new version number
  SET v_max_version = (SELECT COALESCE(MAX(version), 0) FROM {attrsrc_tbl} WHERE lakefusion_id = '{lakefusion_id_escaped}');
  SET v_new_version = v_max_version + 1;

  -- [3] Update master table — changed attributes
  UPDATE {master_tbl}
  SET {set_clause}
  WHERE lakefusion_id = '{lakefusion_id_escaped}';

  -- [3b] Rebuild attributes_combined (and invalidate precomputed embedding when present)
  UPDATE {master_tbl}
  SET attributes_combined = concat_ws(' | ', {concat_parts}){embedding_null_set}
  WHERE lakefusion_id = '{lakefusion_id_escaped}';

  -- [4] Insert new attribute version sources
  INSERT INTO {attrsrc_tbl} (lakefusion_id, version, attribute_source_mapping)
  SELECT
    '{lakefusion_id_escaped}',
    v_new_version,
    {mapping_sql};

  -- [5] Insert merge activity record
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    '{lakefusion_id_escaped}',
    NULL,
    'MANUAL_UPDATE',
    v_new_version,
    'MANUAL_UPDATE',
    current_timestamp();

  -- [6] Clear stale scoring_results in unified table
  UPDATE {unified_tbl}
  SET search_results = NULL,
      scoring_results = NULL
  WHERE record_status = 'ACTIVE'
    AND scoring_results IS NOT NULL
    AND scoring_results != ''
    AND scoring_results != '[]'
    AND scoring_results LIKE '%{lakefusion_id_escaped}%';

  -- Return new version
  SELECT v_new_version AS new_version;
END"""
        return sql

    def run_manual_update_sql(self, entity_id: int, id_value: str, update_attributes: dict,
                              entity_attribute_names: list, entity_attributes_with_types: list,
                              token, created_by, warehouse_id: str = None):
        """Execute manual profile update via SQL warehouse instead of notebook job."""
        try:
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            # Build SQL script
            sql_script = self.build_manual_update_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                lakefusion_id=id_value,
                update_attributes=update_attributes,
                entity_attribute_names=entity_attribute_names,
                entity_attributes_with_types=entity_attributes_with_types,
                created_by=created_by,
                has_embedding_col=has_embedding_col
            )

            # Execute on SQL warehouse with retry on Delta concurrency conflicts
            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"MANUAL_UPDATE lakefusion_id={id_value}"
            )

            # Store tracking record
            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            entity_search_jobs = Model_Databricks_Entity_Search_Job(
                entity_id=entity_id,
                master_id=id_value,
                profile_id=id_value,
                operation_type='MANUAL_UPDATE',
                job_run_id=None,
                status=StewardshipJobStatus.QUERY_COMPLETED.value,
                job_run_status={"execution_type": "query", "result": "success"},
                created_by=created_by,
                execution_type='query',
                query_id=str(query_id)
            )
            self.db.add(entity_search_jobs)
            self.db.commit()
            self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL manual update failed: {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update profile via SQL: {str(e)}"
            )

    # =========================================================================
    # SQL Stewardship: Force Merge (Master-to-Master) via SQL Warehouse
    # =========================================================================

    def run_force_merge_sql(self, entity_id: int, potential_record, token, created_by, warehouse_id: str = None):
        """Execute force merge (master-to-master) via SQL warehouse instead of notebook job."""
        try:
            # Load entity metadata as dict
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            # Get entity attributes (PK first, then rest)
            all_attrs = entity_dict.get('attributes', [])
            pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and a.get('is_primary_key')]
            non_pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and not a.get('is_primary_key')]
            attributes = pk_attrs + non_pk_attrs

            # Resolve survivorship rules (dataset_id → path)
            survivorship_rules = self._resolve_survivorship_rules(entity_dict)

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots BEFORE the force merge (both from master table)
            attr_names = [a['name'] for a in attributes]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(potential_record.master_id),
                match_id=str(potential_record.match_record_id),
                attr_names=attr_names, is_master_to_master=True
            )

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            # Build SQL script — reuse golden dedup merge with MASTER_FORCE_MERGE action type
            sql_script = self.build_golden_dedup_merge_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(potential_record.master_id),
                match_record_id=str(potential_record.match_record_id),
                attributes=attributes,
                survivorship_rules=survivorship_rules,
                created_by=created_by,
                action_type='MASTER_FORCE_MERGE',
                has_embedding_col=has_embedding_col
            )

            # Execute on SQL warehouse with retry
            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"FORCE_MERGE survivor={potential_record.master_id} absorbed={potential_record.match_record_id}"
            )

            # Write steward decision
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id, 'FORCE_MERGE',
                str(potential_record.master_id), str(potential_record.match_record_id),
                sd_master, sd_match, created_by
            )

            # Store tracking record
            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            entity_search_jobs = Model_Databricks_Entity_Search_Job(
                entity_id=entity_id,
                master_id=str(potential_record.master_id),
                profile_id=str(potential_record.match_record_id),
                operation_type='FORCE_MERGE',
                job_run_id=None,
                status=StewardshipJobStatus.QUERY_COMPLETED.value,
                job_run_status={"execution_type": "query", "result": "success"},
                created_by=created_by,
                execution_type='query',
                query_id=str(query_id)
            )
            self.db.add(entity_search_jobs)
            self.db.commit()
            self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL force merge failed: {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to force merge records via SQL: {str(e)}"
            )

    def run_match_merge_dnbintegration(self,entity_id:int,potential_record,token,created_by):
        try:
            entity_conn = EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            unified_ids = [str(i.id) for i in potential_record.unified_dataset_ids]
            dnb_duns_value=unified_ids[0]
            job_parameters = {
                    "entity_name":entity_name,
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "id_value": str(potential_record.master_id),
                    "dnb_duns_value": dnb_duns_value
                }
            if(potential_record.operation_type in ['MERGE']):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_match_merge_tasks_and_job_dnbintegration(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_Match_Merge_DNB",task_list_response)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=potential_record.master_id,
                    profile_id=dnb_duns_value,
                    operation_type="MERGE",
                    job_run_id=job_create_response.run_id,
                    status=StewardshipJobStatus.SUBMITTED.value,
                    job_run_status=job_run_response,
                    created_by=created_by)
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs        
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )

    def accept_dnb_candidate(self, entity_id, master_id, dnb_duns_value, warehouse_id, token):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            dnb_table = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"

            query = f"""
                UPDATE {dnb_table}
                SET merge_status = CASE
                    WHEN dnb_duns = '{dnb_duns_value}' THEN 'ACCEPTED'
                    ELSE 'REJECTED'
                END
                WHERE lakefusion_id = '{master_id}' AND merge_status = 'IN_REVIEW'
            """
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            sqlservice_conn.execute_insert_query(query=query)
            return {"message": "D&B candidate accepted successfully"}
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to accept D&B candidate. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to accept D&B candidate: {str(e)}"
            )

    def reject_all_dnb_candidates(self, entity_id, master_id, warehouse_id, token):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            dnb_table = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"

            query = f"""
                UPDATE {dnb_table}
                SET merge_status = 'REJECTED'
                WHERE lakefusion_id = '{master_id}' AND merge_status = 'IN_REVIEW'
            """
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            sqlservice_conn.execute_insert_query(query=query)
            return {"message": "All D&B candidates rejected successfully"}
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to reject D&B candidates. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to reject D&B candidates: {str(e)}"
            )

    def create_match_merge_tasks_and_job_deduplication(self, parameters):
        try:
            
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Match_Merge_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Manual Merge",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )
            ]
            return tasks_list
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
    
    def create_not_match_tasks_and_job_deduplication(self, parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Not_Match_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Manual Not A Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )

    def create_match_merge_tasks_and_job_deduplication_updated(self, parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Merge_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Manual_Merge",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Manual_Merge",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Potential_Match_Table",
                    #new_cluster=job_cluster.new_cluster,
                    depends_on=[TaskDependency(task_key="Entity_Merge_Deduplication")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Process_Potential_Match",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Potential_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Potential_Match_Normal",
                    #new_cluster=job_cluster.new_cluster,
                    depends_on=[TaskDependency(task_key="Entity_Merge_Deduplication")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_CrossWalk",
                    #new_cluster=job_cluster.new_cluster,
                    depends_on=[TaskDependency(task_key="Entity_Merge_Deduplication")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Normal"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
    
    def create_not_match_tasks_and_job_deduplication_updated(self, parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}   
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Not_Match_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Manual_Not_Match",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Manual_Not_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table"),TaskDependency(task_key="Process_CrossWalk")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )

    def run_match_merge_deduplication(self, entity_id: int, potential_record, token, created_by):
        try:
            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str(potential_record.operation_type),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type in ['MERGE', 'MERGE_ALL']:
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
            elif potential_record.operation_type == 'NOT_A_MATCH':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_not_match_tasks_and_job_deduplication(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_Not_A_Match", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type="NOT_A_MATCH",
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
        
    def run_match_merge_deduplication_updated(self, entity_id: int, potential_record, token, created_by):
        try:
            if potential_record.operation_type in ['MERGE','MERGE_ALL']:
                operation_type='MASTER_MANUAL_MERGE'
            else:
                operation_type='MANUAL_NOT_A_MATCH'


            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str(operation_type),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type in ['MERGE', 'MERGE_ALL']:
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication_updated(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
            elif potential_record.operation_type == 'NOT_A_MATCH':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_not_match_tasks_and_job_deduplication_updated(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_Not_A_Match", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type="NOT_A_MATCH",
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
        

    def run_force_merge_deduplication(self, entity_id: int, potential_record, token, created_by):
        try:
            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str('MASTER_FORCE_MERGE'),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type=='FORCE_MERGE':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
           
                
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to force merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
        
    def run_force_merge_deduplication_updated(self, entity_id: int, potential_record, token, created_by):
        try:
            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str('MASTER_FORCE_MERGE'),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type=='FORCE_MERGE':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication_updated(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to force merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
    def create_unmerge_tasks_and_job(self, parameters):
        try:
            dbx_cloud=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "dbx_cloud").first().config_value)
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            if(dbx_cloud=='azure'):
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                cluster_name="",
                spark_version="16.0.x-cpu-ml-scala2.12",
                azure_attributes=AzureAttributes(
                    first_on_demand=1
                ),  # Corrected Azure Attributes
                node_type_id="Standard_DS12_v2",
                driver_node_type_id="Standard_DS12_v2",  # Correct Azure instance type
                spark_env_vars={
                    "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                },
                enable_elastic_disk=False,
                data_security_mode=DataSecurityMode.SINGLE_USER,
                runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                autoscale=AutoScale(
                    min_workers=1,  # Updated worker count
                    max_workers=1   # Updated worker count
                ),
                custom_tags=tags  # Add custom tags
                ))
            else:
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    aws_attributes=AwsAttributes(
                        first_on_demand=1,
                        availability=AwsAvailability.SPOT_WITH_FALLBACK,
                        zone_id="us-west-2d",
                        spot_bid_price_percent=100,
                        ebs_volume_count=0
                    ),
                    node_type_id="r5d.4xlarge",  # Updated instance type
                    spark_env_vars={
                        "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                    },
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                    autoscale=AutoScale(
                        min_workers=2,  # Updated worker count
                        max_workers=4   # Updated worker count
                    ),
                    custom_tags=tags  # Add custom tags
                    ))
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Unmerge",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Manual Unmerge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Manual Unmerge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Potential Match Table",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create unmerge tasks. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create unmerge tasks: {str(e)}"
            )

    def create_unmerge_tasks_and_job_updated(self, parameters):
        try:

            tags = get_resource_tags()
            if tags is None:
                tags = {}

            job_parameters_list = [i for i in parameters]

            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Unmerge",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Manual_Unmerge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Manual_Unmerge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create unmerge tasks. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create unmerge tasks: {str(e)}"
            )

    def run_unmerge(self, entity_id: int, unmerge_record, token, created_by):
        try:
            job_parameters=[
                {"entity_id": str(entity_id), "experiment_id": str('prod'), "catalog_name": self.catalog_name},
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "master_id": str(unmerge_record.master_id),
                    "unified_dataset_ids": json.dumps([{"id": i.id, "dataset_id": i.dataset_id} for i in unmerge_record.unified_dataset_ids])
                }
            ]
            
            job_service = DatabricksJobManager(token)
            task_list_response = self.create_unmerge_tasks_and_job(job_parameters)
            job_create_response = job_service.create_and_submit_job("Entity_UNMERGE", task_list_response)
            job_run_response = job_service.get_job_run_status(job_create_response.run_id)
            
            entity_search_jobs_list = []
            for i in unmerge_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=unmerge_record.master_id,
                    profile_id=i.id,
                    operation_type='UNMERGE',
                    job_run_id=job_create_response.run_id,
                    status=StewardshipJobStatus.SUBMITTED.value,
                    job_run_status=job_run_response,
                    created_by=created_by)
                self.db.add(entity_search_jobs)
                entity_search_jobs_list.append(entity_search_jobs)
                
            self.db.commit()
            for job in entity_search_jobs_list:
                self.db.refresh(job)
                
            return entity_search_jobs_list[0] if entity_search_jobs_list else None
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to unmerge. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to unmerge records: {str(e)}"
            )
        
    def run_unmerge_updated(self, entity_id: int, unmerge_record, token, created_by):
        try:
            job_parameters=[
                {"entity_id": str(entity_id), "experiment_id": str('prod'), "catalog_name": self.catalog_name},
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "master_id": str(unmerge_record.master_id),
                    "unified_dataset_ids": json.dumps([{"id": i.id, "dataset_id": i.dataset_id} for i in unmerge_record.unified_dataset_ids])
                }
            ]
            
            job_service = DatabricksJobManager(token)
            task_list_response = self.create_unmerge_tasks_and_job_updated(job_parameters)
            job_create_response = job_service.create_and_submit_job("Entity_UNMERGE", task_list_response)
            job_run_response = job_service.get_job_run_status(job_create_response.run_id)
            
            entity_search_jobs_list = []
            for i in unmerge_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=unmerge_record.master_id,
                    profile_id=i.id,
                    operation_type='UNMERGE',
                    job_run_id=job_create_response.run_id,
                    status=StewardshipJobStatus.SUBMITTED.value,
                    job_run_status=job_run_response,
                    created_by=created_by)
                self.db.add(entity_search_jobs)
                entity_search_jobs_list.append(entity_search_jobs)
                
            self.db.commit()
            for job in entity_search_jobs_list:
                self.db.refresh(job)
                
            return entity_search_jobs_list[0] if entity_search_jobs_list else None
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to unmerge. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to unmerge records: {str(e)}"
            )

    def create_tasks_and_job(self, parameters):
        """Legacy job creation for update profile (versions < 4.0.0)."""
        dbx_cloud = (self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "dbx_cloud").first().config_value)
        tags = get_resource_tags()
        if tags is None:
            tags = {}
        if dbx_cloud == 'azure':
            job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    azure_attributes=AzureAttributes(first_on_demand=1),
                    node_type_id="Standard_DS12_v2",
                    driver_node_type_id="Standard_DS12_v2",
                    spark_env_vars={"PYSPARK_PYTHON": "/databricks/python3/bin/python3"},
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,
                    autoscale=AutoScale(min_workers=1, max_workers=1),
                    custom_tags=tags
                )
            )
        else:
            job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    aws_attributes=AwsAttributes(
                        first_on_demand=1,
                        availability=AwsAvailability.SPOT_WITH_FALLBACK,
                        zone_id="us-west-2d",
                        spot_bid_price_percent=100,
                        ebs_volume_count=0
                    ),
                    node_type_id="r5d.4xlarge",
                    spark_env_vars={"PYSPARK_PYTHON": "/databricks/python3/bin/python3"},
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,
                    autoscale=AutoScale(min_workers=2, max_workers=4),
                    custom_tags=tags
                )
            )

        if len(parameters) == 1:
            tasks_list = [
                Task(
                    task_key="UpdateEntityDnBIntegration",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Update Entity Search Profile",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Update Entity Search Profile",
                        base_parameters={"query_1": str(parameters[0])},
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                )
            ]
        else:
            tasks_list = [
                Task(
                    task_key="UpdateEntityProfile",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Update Entity Search Profile",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Update Entity Search Profile",
                        base_parameters={
                            "query_1": str(parameters[0]),
                            "query_2": str(parameters[1]),
                            "query_3": str(parameters[2])
                        },
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                )
            ]

        return [tasks_list, job_cluster]
    
    def _create_manual_update_job_config(self, notebook_params: dict):
        """
        Create the job configuration for the v4.0.0+ Manual_Update notebook.
        Uses serverless compute (no cluster specification).
        """
        tasks_list = [
             SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
             SubmitTask(
                task_key="ManualUpdateProfile",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Manual_Update",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Manual_Update",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
             SubmitTask(
                task_key="Process_Warning_Records",
                depends_on=[TaskDependency(task_key="ManualUpdateProfile")],
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Warning Records",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Warning Records",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_Warning_Records")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
        ]

        return tasks_list
    
    def _process_attribute_updates(self, latest_attributes_result, attributes_values, source):
        """Process attribute updates using NumPy for better performance"""
        import numpy as np
        import json
        
        existing_attributes = []
        try:
            if (latest_attributes_result is not None and 
                len(latest_attributes_result) > 0):
                
                if not isinstance(latest_attributes_result, np.ndarray):
                    result_array = np.array(latest_attributes_result)
                else:
                    result_array = latest_attributes_result
                
                if (result_array.size > 0 and 
                    isinstance(result_array[0], dict) and
                    'attribute_source_mapping' in result_array[0] and 
                    result_array[0]['attribute_source_mapping'] is not None):
                    
                    existing_attributes = result_array[0]['attribute_source_mapping']
                    
                    if isinstance(existing_attributes, str):
                        try:
                            existing_attributes = json.loads(existing_attributes)
                        except:
                            existing_attributes = []
                    elif isinstance(existing_attributes, np.ndarray):
                        existing_attributes = existing_attributes.tolist()
                    elif not isinstance(existing_attributes, list):
                        existing_attributes = []
                        
        except (TypeError, IndexError, KeyError, ValueError) as e:
            print(f"Debug: Error processing attributes: {e}")
            existing_attributes = []
        
        attributes_dict = {}
        
        if isinstance(existing_attributes, list):
            for attr in existing_attributes:
                if isinstance(attr, dict) and attr.get('attribute_name'):
                    attr_name = attr.get('attribute_name')
                    attributes_dict[attr_name] = {
                        'attribute_name': attr_name,
                        'attribute_value': attr.get('attribute_value', ''),
                        'source': attr.get('source', source)
                    }
        
        for key, value in attributes_values.items():
            safe_value = str(value) if value is not None else ''
            attributes_dict[key] = {
                'attribute_name': key,
                'attribute_value': safe_value,
                'source': 'MANUAL_UPDATE'
            }
        
        final_attributes = list(attributes_dict.values())
        
        return final_attributes

    def _convert_attributes_to_sql_array(self, attribute_values):
        """Convert Python attribute list to SQL array format"""
        
        if not attribute_values:
            return "array()"
        
        attribute_structs = []
        for attr in attribute_values:
            safe_name = str(attr['attribute_name']).replace("'", "''")
            safe_value = str(attr['attribute_value']).replace("'", "''")
            safe_source = str(attr['source']).replace("'", "''")
            
            struct = f"named_struct('attribute_name', '{safe_name}', 'attribute_value', '{safe_value}', 'source', '{safe_source}')"
            attribute_structs.append(struct)
        
        return f"array({', '.join(attribute_structs)})"
    
    def _get_entity_attributes_with_types(self, entity) -> List[Any]:
        """
        Extract entity attributes with their data types from the entity model.
        Returns the list of attribute objects or dicts.
        """
        if hasattr(entity, 'attributes') and entity.attributes:
            return entity.attributes
        return []

    def _update_profile_v4(
        self,
        entity_name: str,
        entity_id:int,
        id_value: str,
        update_attributes: dict,
        entity_attributes: List[str],
        token: str,
        created_by
    ):
        """
        New v4.0.0+ update flow using Manual_Update notebook.
        All logic is handled in the notebook. Uses serverless compute.
        """
        # Prepare parameters for the notebook
        notebook_params = {
            "catalog_name": self.catalog_name,
            "entity_name": entity_name,
            "entity_id": entity_id,
            "lakefusion_id": id_value,
            "update_attributes": json.dumps(update_attributes),
            "entity_attributes": json.dumps(entity_attributes)
        }
        
        app_logger.info(f"Triggering Manual_Update job (v4.0.0+) with params: {notebook_params}")
        
        # Create and run the job using serverless (same pattern as other methods)
        job_service = DatabricksJobManager(token)
        tasks_list = self._create_manual_update_job_config(notebook_params)
        
        # Use create_and_submit_job (serverless) instead of create_job + run_job
        job_create_response = job_service.create_and_submit_job(
            f"Manual_Update_Profile-{entity_name}-{id_value[:8]}",
            tasks_list
        )
        
        job_run_response = job_service.get_job_run_status(job_create_response.run_id)
        entity_update_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=id_value,
                    profile_id=id_value,
                    operation_type='MANUAL_UPDATE',
                    job_run_id=job_create_response.run_id,
                    status=StewardshipJobStatus.SUBMITTED.value,
                    job_run_status=job_run_response,
                    created_by=created_by)
        self.db.add(entity_update_jobs)
        self.db.commit()
        self.db.refresh(entity_update_jobs)
        
        app_logger.info(f"Manual_Update job triggered successfully: run_id={job_create_response.run_id}")
        return job_run_response

    def _update_profile_legacy(
        self,
        entity_name: str,
        id_value: str,
        update_attributes: dict,
        warehouse_id: str,
        token: str,
        entity
    ):
        """
        Legacy update flow for versions < 4.0.0.
        Uses the old query-based approach.
        """
        source = entity.path
        entity_primary = "lakefusion_id"
        
        get_attributes_and_version_query = f"""
        with global_max as (
            select coalesce(max(version), 0) as global_max_version
            from {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources
        ),
        latest_attrs as (
            select 
                version,
                attribute_source_mapping
            from {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources 
            where {entity_primary}='{id_value}'
            order by version desc
            limit 1
        )
        select 
            coalesce(la.version, 0) as record_version,
            la.attribute_source_mapping,
            gm.global_max_version
        from global_max gm
        left join latest_attrs la on 1=1
        """
        
        sqlservice_conn = DataSetSQLService(token, warehouse_id)
        combined_result = sqlservice_conn.execute_dataset(get_attributes_and_version_query)
        
        global_max_version = combined_result[0]['global_max_version'] if combined_result else 0
        next_version = global_max_version + 1
        
        attributes_data = [{
            'attribute_source_mapping': combined_result[0]['attribute_source_mapping'] if combined_result else None
        }] if combined_result else []
        
        new_attribute_values = self._process_attribute_updates(
            attributes_data, 
            update_attributes, 
            source
        )
        
        attribute_values_sql = self._convert_attributes_to_sql_array(new_attribute_values)
        
        update_query = ", ".join([f"{k} = '{v}'" for k, v in update_attributes.items()])
        query_1 = f"update {self.catalog_name}.gold.{entity_name}_master_prod set {update_query} where {entity_primary}='{id_value}'"

        query_2 = f"""
        insert into {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources 
        values (
            '{id_value}',
            {next_version},
            {attribute_values_sql}
        )
        """
        
        query_3 = f"""
        insert into {self.catalog_name}.gold.{entity_name}_master_prod_merge_activities 
        values (
            '{id_value}',
            Null,
            'MANUAL_UPDATE',
            {next_version},
            'MANUAL_UPDATE'
        )
        """

        parameters = [query_1, query_2, query_3]
        job_service = DatabricksJobManager(token)
        task_job = self.create_tasks_and_job(parameters)
        job_create_response = job_service.create_job(
            f"Update_Profile-{entity_name}",
            job_clusters=task_job[1],
            tasks_list=task_job[0]
        )
        job_response = job_service.run_job(job_create_response)
        return job_response
        
    def update_entity_search_profile(self, entity_id, id_value: str, attributes_values, warehouse_id, token,created_by):
        """
        Update an entity profile with version-based routing.
        
        For v4.0.0+: Routes to new Manual_Update notebook
        For < v4.0.0: Routes to legacy query-based flow
        
        Includes pre-flight validation of attributes before starting any job.
        """
        try:
            # Get entity information
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            
            # Get version from Integration_Hub table instead of entity table
            entity_version = self.get_integration_hub_task_version(entity_id) or "1.0.0"
            
            # Get entity attributes (for validation and passing to notebook)
            entity_attributes = self._get_entity_attributes_with_types(entity)
            entity_attribute_names = []
            for attr in entity_attributes:
                if isinstance(attr, dict):
                    name = attr.get('name') or attr.get('column_name')
                else:
                    name = getattr(attr, 'name', None) or getattr(attr, 'column_name', None)
                if name and name != 'attributes_combined':
                    entity_attribute_names.append(name)
            
            app_logger.info(
                f"Processing update for entity '{entity_name}' (version {entity_version}), "
                f"lakefusion_id '{id_value}'"
            )
            
            # ===== VALIDATION =====
            # Validate attributes before starting any job
            try:
                AttributeValidator.validate_or_raise(attributes_values, entity_attributes)
                app_logger.info("✓ Attribute validation passed")
            except AttributeValidationError as e:
                app_logger.warning(f"Attribute validation failed: {e.errors}")
                raise HTTPException(
                    status_code=400,
                    detail={
                        "error": "Validation failed",
                        "messages": e.errors
                    }
                )
            
            # ===== SQL STEWARDSHIP PATH (feature-flagged) =====
            sql_stewardship_enabled = FeatureFlagService._is_feature_flag_enabled(self.db, "ENABLE_SQL_STEWARDSHIP")
            if sql_stewardship_enabled and warehouse_id:
                app_logger.info(f"Using SQL stewardship flow for manual update (entity={entity_name}, lakefusion_id={id_value})")
                return self.run_manual_update_sql(
                    entity_id=entity_id,
                    id_value=id_value,
                    update_attributes=attributes_values,
                    entity_attribute_names=entity_attribute_names,
                    entity_attributes_with_types=entity_attributes,
                    token=token,
                    created_by=created_by,
                    warehouse_id=warehouse_id
                )

            # ===== VERSION-BASED ROUTING =====
            if is_version_gte(entity_version, NEW_PIPELINE_MIN_VERSION):
                # New v4.0.0+ flow
                app_logger.info(f"Using NEW pipeline flow (version {entity_version} >= {NEW_PIPELINE_MIN_VERSION})")
                return self._update_profile_v4(
                    entity_name=entity_name,
                    entity_id=entity_id,
                    id_value=id_value,
                    update_attributes=attributes_values,
                    entity_attributes=entity_attribute_names,
                    token=token,
                    created_by=created_by
                )
            else:
                # Legacy flow
                app_logger.info(f"Using LEGACY pipeline flow (version {entity_version} < {NEW_PIPELINE_MIN_VERSION})")
                return self._update_profile_legacy(
                    entity_name=entity_name,
                    id_value=id_value,
                    update_attributes=attributes_values,
                    warehouse_id=warehouse_id,
                    token=token,
                    entity=entity
                )
             
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update entity gold table: {str(e)}"
            )
    
    def get_merge_statuses(self, entity_id: int, master_id: str) -> List[dict]:
        """
        Get all merge operation statuses for a given master_id.
        
        Args:
            entity_id: The entity ID
            master_id: The master record ID to check statuses for
        
        Returns:
            List of status objects containing profile_id and status
        """
        try:
            results = self.db.query(Model_Databricks_Entity_Search_Job).filter(
                and_(
                    Model_Databricks_Entity_Search_Job.entity_id == entity_id,
                    Model_Databricks_Entity_Search_Job.master_id == master_id
                )
            ).order_by(Model_Databricks_Entity_Search_Job.created_at.desc()).all()
            
            # Group by profile_id and get latest status
            databricks_host = get_databricks_host() or None
            status_map = {}
            for result in results:
                if result.profile_id not in status_map:
                    entry = {
                        "job_id": result.id,
                        "profile_id": result.profile_id,
                        "status": result.status,
                        "operation_type": result.operation_type,
                        "execution_type": result.execution_type,
                        "created_at": result.created_at.isoformat()
                    }
                    # Build execution link if applicable
                    if result.execution_type == 'query' and result.query_id:
                        entry["execution_link"] = f"{databricks_host}/sql/history?queryId={result.query_id}"
                    elif result.job_run_id:
                        entry["execution_link"] = f"{databricks_host}/jobs/runs/{result.job_run_id}"
                    status_map[result.profile_id] = entry

            return list(status_map.values())
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch merge statuses for master_id {master_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed fetching merge statuses: {str(e)}")
        
    def get_force_merge_status(self, entity_id: int, master_id: str, match_id: str) -> list[dict]:
        """Retrieves latest force merge job status from the database."""
        try:
            result = (
                self.db.query(Model_Databricks_Entity_Search_Job)
                .filter(
                    Model_Databricks_Entity_Search_Job.entity_id == entity_id,
                    Model_Databricks_Entity_Search_Job.operation_type == "FORCE_MERGE",
                    or_(
                        or_(
                            Model_Databricks_Entity_Search_Job.master_id == master_id,
                            Model_Databricks_Entity_Search_Job.profile_id == match_id,
                        ),
                        or_(
                            Model_Databricks_Entity_Search_Job.master_id == match_id,
                            Model_Databricks_Entity_Search_Job.profile_id == master_id,
                        ),
                    ),
                )
                .order_by(Model_Databricks_Entity_Search_Job.created_at.desc())
                .first()
            )

            if result is None:
                return []

            return [{
                "master_id": result.master_id,
                "profile_id": result.profile_id,
                "status": result.status,
                "job_run_id": result.job_run_id,
                "job_run_status": result.job_run_status,
                "created_at": result.created_at.isoformat(),
            }]

        except Exception as e:
            app_logger.exception("Unable to fetch force merge status")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch force merge status: {str(e)}",
            )
        
    def read_entity_search_profile_validation_id(self,entity_id:int,id_value:str,warehouse_id:str,validation_type:str,token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            
            entity_primary="lakefusion_id"
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            if(validation_type=='error'):
               query=f"""WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'gold'
      AND table_name = '{entity_name}_master_validation_error_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)
SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.gold.{entity_name}_unified_prod p' ||
  ' LEFT JOIN {self.catalog_name}.gold.{entity_name}_unified_validation_error_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN 
      ' WHERE p.{entity_primary} = ''{id_value}'' AND ' || where_conditions
    ELSE ' WHERE p.{entity_primary} = ''{id_value}'' '
  END AS generated_query
FROM validation_columns;"""
            else:
                query=f"""WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'silver'
      AND table_name = '{entity_name}_unified_validation_warning_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)
SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.silver.{entity_name}_unified_prod p' ||
  ' LEFT JOIN {self.catalog_name}.silver.{entity_name}_unified_validation_warning_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN 
      ' WHERE p.{entity_primary} = ''{id_value}'' AND ' || where_conditions
    ELSE ' WHERE p.{entity_primary} = ''{id_value}'' '
  END AS generated_query
FROM validation_columns;"""
            data=sqlservice_conn.execute_dataset(query=query)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            data=sqlservice_conn.execute_dataset(query=data[0]['generated_query'])
            return [serialize_row_data(row) for row in data]

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile with validation records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile with validation records: {str(e)}"
            )

    def read_entity_search_profile_validation(self,entity_id:int,warehouse_id:str,validation_type:str,token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            #entity_name='Patients'
            entity_primary="lakefusion_id"
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            if(validation_type=='error'):
               query=f"""WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'gold'
      AND table_name = '{entity_name}_master_validation_error_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)

SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.gold.{entity_name}_master_prod p' ||
  ' LEFT JOIN {self.catalog_name}.gold.{entity_name}_master_validation_error_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN ' WHERE ' || where_conditions
    ELSE ''
  END AS generated_query
FROM validation_columns;"""
            else:
                query=f"""
WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'silver'
      AND table_name = '{entity_name}_unified_validation_warning_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)

SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.silver.{entity_name}_unified_prod p' ||
  ' LEFT JOIN {self.catalog_name}.silver.{entity_name}_unified_validation_warning_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN ' WHERE ' || where_conditions
    ELSE ''
  END AS generated_query
FROM validation_columns;"""
            data=sqlservice_conn.execute_dataset(query=query)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            return_data=sqlservice_conn.execute_dataset(query=data[0]['generated_query'])
            return [serialize_row_data(row) for row in return_data]

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile with validation records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile with validation records: {str(e)}"
            )

    def get_attribute_sources(self, entity_id: int, profile_id: str, warehouse_id: str, token: str):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            entity_primary = "lakefusion_id"
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            query = f"select * from {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources where {entity_primary}='{profile_id}'"
            data = sqlservice_conn.execute_dataset(query=query)
            
            def convert_to_string(value):
                if value is None:
                    return ""
                if isinstance(value, (int, float, bool)):
                    return str(value)
                if isinstance(value, (list, dict)):
                    return json.dumps(value)
                return str(value)

            # Convert the data to a list of dictionaries with string values
            if data:
                formatted_data = []
                for row in data:
                    if hasattr(row, '_asdict'):
                        # Handle named tuples
                        row_dict = row._asdict()
                    elif hasattr(row, '__dict__'):
                        # Handle objects
                        row_dict = row.__dict__
                    elif isinstance(row, dict):
                        row_dict = row
                    else:
                        # Handle tuples/lists
                        columns = [col[0] if isinstance(col, tuple) else col for col in data[0]._fields] if hasattr(data[0], '_fields') else data[0].keys()
                        row_dict = dict(zip(columns, row))
                    
                    # Convert all values to strings
                    formatted_row = {key: convert_to_string(value) for key, value in row_dict.items()}
                    formatted_data.append(formatted_row)
                
                return formatted_data
            
            return []

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch profile sources. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch profile sources: {str(e)}"
            )

    def get_merge_activities(self, entity_id: int, profile_id: str, warehouse_id: str, token: str):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)

            entity_name = entity.name.lower().replace(' ', '_')
            entity_primary = "lakefusion_id"
            table_name = f"{entity_name}_master_prod_merge_activities"

            # ---------- 1st Connection (check columns) ----------
            sqlservice_conn = DataSetSQLService(token, warehouse_id)

            column_check_query = f"""
                SELECT column_name
                FROM {self.catalog_name}.information_schema.columns
                WHERE table_schema = 'gold'
                AND table_name = '{table_name}'
                AND column_name IN ('master_{entity_primary}', 'master_id');
            """

            cols = sqlservice_conn.execute_dataset(query=column_check_query)
            col_names = set()
            for row in cols or []:
                if isinstance(row, dict):
                    col_names.add(row.get("column_name") or row.get("COLUMN_NAME"))
                else:
                    col_names.add(row[0])

            if f"master_{entity_primary}" in col_names:
                master_col = f"master_{entity_primary}"
            elif "master_id" in col_names:
                master_col = "master_id"
            else:
                raise Exception(f"No valid master column found in table {table_name}")
            
            print("master col", master_col)

            # ---------- 2nd Connection (main data query) ----------
            sqlservice_conn = DataSetSQLService(token, warehouse_id)

            query = f"""
                SELECT *
                FROM {self.catalog_name}.gold.{table_name}
                WHERE {master_col} = '{profile_id}';
            """

            data = sqlservice_conn.execute_dataset(query=query)
            return data

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch merge activities. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch merge activities: {str(e)}"
            )

    def read_entity_validation_data(self,entity_id:int,warehouse_id:str,validation_type:Literal["error","warning"],token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            validation_function_warning_enabled = FeatureFlagService._is_feature_flag_enabled(
                self.db,
                'ENABLE_VALIDATION_FUNCTION_WARNING_FEATURE'
            )
            if not validation_function_warning_enabled:
                # Hide the API as if it does not exist
                raise HTTPException(
                    status_code=404,
                    detail="This API is disabled."
                )
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            validation_funcs = [attr for attr in entity.validation_functions
                               if attr.validation_level == validation_type]
            attribute_names = [attr.attribute_name for attr in validation_funcs]
            entity_name = entity.name.lower().replace(" ", "_")
            entity_primary = "lakefusion_id"
            select_b = [f"b.{entity_primary}"]
            # Build dynamic SELECT parts
            select_b += [
            f"b.{attr.name}" for attr in entity.attributes
            if attr.name != "attributes_combined" and attr.name not in attribute_names]
            select_a = ', '.join([f"'{attr}'" for attr in attribute_names])
            
            where_conditions = [f"t.{attr} IS NOT NULL" for attr in attribute_names]

            where_clause = " OR ".join(where_conditions)
            select_attrs = []
           
            for attr in attribute_names:
                # alias: FullName -> FullName_obj
                select_attrs.append(
                        f"named_struct('value', b.{attr}, 'status', t.{attr}) AS {attr}"
                    )
                

            # Join select parts
            select_clause = ", ".join(select_b + select_attrs)
            
            # Build pivot list for SQL
            select_a = ', '.join([f"'{attr}'" for attr in attribute_names])
            
            

            query = f"""
                SELECT {select_clause}
                FROM (SELECT * FROM
                         (SELECT distinct lakefusion_id,attribute_name,status FROM {self.catalog_name}.gold.{entity_name}_master_{validation_type}_prod ) a
                         PIVOT (
                             FIRST(status)
                             FOR attribute_name IN ({select_a})
                         ) ) t
                JOIN {self.catalog_name}.gold.{entity_name}_master_prod b
                  ON t.{entity_primary} = b.{entity_primary} WHERE {where_clause}
            """
            print(query)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            data = sqlservice_conn.execute_dataset(query=query)
            return [serialize_row_data(row) for row in data]


        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity validation {validation_type} records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity validation {validation_type} records: {str(e)}"
            )
        
        finally:
            # Ensure the session is closed properly
            self.db.close()

lakefusion_databricks_dapi = os.environ.get('LAKEFUSION_DATABRICKS_DAPI', '')
class Monitor_Entity_Search_Databricks_Job:
    def __init__(self, db: Session):
        self.db = db

    def get_experiment_status(self, job_run_data: List[Dict], job_run_id) -> str:
        """
        Update experiment status based on job run tasks states
        """

        # ✅ ALWAYS return a string
        if not job_run_data:
            return StewardshipJobStatus.PENDING.value

        # Convert list to dict (exclude manual testing)
        task_states = {
            task['task_key']: task
            for task in job_run_data
            if task.get('task_key') != 'Entity_Manual_Testing'
        }

        # 1️⃣ Failures first
        if any(
            task.get('result_state') in ('FAILED', 'UPSTREAM_FAILED')
            for task in job_run_data
        ):
            return StewardshipJobStatus.FAILED.value

        # 2️⃣ Cancelled
        if any(
            task.get('result_state') in ('CANCELED', 'UPSTREAM_CANCELED')
            for task in job_run_data
        ):
            return 'match_merge_cancelled'

        # 3️⃣ Success detection (REAL merge tasks)
        merge_task = (
            task_states.get('Process_Entity_Job_Status')
            # or task_states.get('Process_CrossWalk')
            # or task_states.get('Entity_Match_Merge')  # backward compatibility
        )

        if (
            merge_task
            and merge_task.get('state') == 'TERMINATED'
            and merge_task.get('result_state') == 'SUCCESS'
        ):
            return StewardshipJobStatus.COMPLETED.value

        # 4️⃣ Default
        return StewardshipJobStatus.PENDING.value

    
    def get_pending_tasks(self):
        """
        Retrieve all rows where task_status is 'pending' from the Model_Databricks_Job table.

        Args:
            db (Session): SQLAlchemy database session.

        Returns:
            List[Model_Databricks_Job]: List of jobs with task_status as 'pending'.
        """
        try:
            pending_tasks = self.db.query(Model_Databricks_Entity_Search_Job).filter(
                Model_Databricks_Entity_Search_Job.status.in_([StewardshipJobStatus.PENDING.value, StewardshipJobStatus.SUBMITTED.value])
            ).all()
            return pending_tasks
        except Exception as e:
            print(f"Error fetching pending tasks: {e}")
            raise
    


    def update_job_run_status(
        self,
        job_run_id: str,
        new_job_run_status,
        new_status: str
    ):
        try:
            # 🔒 Strong validation (prevents MySQL errors forever)
            if not isinstance(new_status, str):
                raise ValueError(
                    f"Invalid status value: {new_status} (type={type(new_status)})"
                )

            # Get ALL records with this job_run_id (Merge All creates multiple records per job)
            job_entries = (
                self.db.query(Model_Databricks_Entity_Search_Job)
                .filter(
                    Model_Databricks_Entity_Search_Job.job_run_id == job_run_id
                )
                .all()
            )

            if not job_entries:
                raise ValueError(f"No job found with run_id: {job_run_id}")

            # ✅ Update ALL records with this job_run_id
            updated_count = 0
            for job_entry in job_entries:
                job_entry.job_run_status = new_job_run_status
                job_entry.status = new_status
                updated_count += 1

            self.db.commit()
            app_logger.info(f"Updated {updated_count} records for job_run_id={job_run_id} to status={new_status}")

            return job_entries

        except Exception:
            self.db.rollback()
            app_logger.exception(
                f"Failed to update job run status for job_run_id={job_run_id}"
            )
            raise

    
    

def check_entity_search_monitor_status(db: Session):
    """
    Check and update the monitor status of pending profiling tasks.

    Returns:
    - None: This function does not return a value.

    Raises:
    - HTTPException: If there is an issue with the database query or
      fetching monitor information.
    """
    app_logger.info("Starting check_entity_search_monitor_status function execution.")

    try:
        # Initialize the ProfilingTaskService with the database session.
        monitor_model_job_service = Monitor_Entity_Search_Databricks_Job(db)

        # Attempt to fetch tasks that have a pending monitor status.
        try:
            pending_job_run_tasks = monitor_model_job_service.get_pending_tasks()
        except Exception as e:
            # Log any errors that occur while fetching pending tasks.
            app_logger.error(f"Error fetching pending tasks: {str(e)}")
            app_logger.error(f"Traceback: {traceback.format_exc()}")
            return  # Exit the function if an error occurs to prevent further processing.

        # Get unique job_run_ids to avoid redundant Databricks API calls
        # (Merge All creates multiple records with same job_run_id)
        unique_job_run_ids = set()
        job_run_map = {}  # Store first job_run for each job_run_id (for fallback status)
        for job_run in pending_job_run_tasks:
            if job_run.job_run_id not in unique_job_run_ids:
                unique_job_run_ids.add(job_run.job_run_id)
                job_run_map[job_run.job_run_id] = job_run

        app_logger.info(f"Found {len(pending_job_run_tasks)} pending tasks with {len(unique_job_run_ids)} unique job_run_ids")

        # Process each unique job_run_id only once
        for job_run_id in unique_job_run_ids:
            try:
                job_run = job_run_map[job_run_id]

                # Fetch the latest monitor information for the task's dataset.
                job_status = DatabricksJobManager(token=lakefusion_databricks_dapi)
                latest_job_run_info = job_status.get_job_run_status(job_run_id)
                if latest_job_run_info is None:
                    app_logger.warning(f"Using previous job_run_status for job_run_id={job_run_id}")
                    latest_job_run_info = job_run.job_run_status
                new_experiment_status = monitor_model_job_service.get_experiment_status(latest_job_run_info, job_run_id)
                monitor_model_job_service.update_job_run_status(job_run_id, latest_job_run_info, new_experiment_status)

            except Exception as task_error:
                # Log any errors that occur while processing each individual task.
                app_logger.error(f"Error processing job run with ID {job_run_id}: {str(task_error)}")
                app_logger.error(f"Traceback: {traceback.format_exc()}")
                # Optionally, implement retry logic or other error handling here.

    except Exception as function_error:
        # Log any errors that occur at the function level.
        app_logger.error(f"Error in check_monitor_status function: {str(function_error)}")
        app_logger.error(f"Traceback: {traceback.format_exc()}")

    # Log the completion of the function execution.
    app_logger.info("Finished check_entity_search_monitor_status function execution.")


def process_query_completed_stewardship(db: Session):
    """
    Cron job (every 5 min): pick up all QUERY_COMPLETED records from entity_search_databricks_job,
    group by entity_id, and submit a Process_Potential_Match + Process_CrossWalk job per entity.
    The existing check_entity_search_monitor_status cron will track job completion.
    """
    app_logger.info("Starting process_query_completed_stewardship execution.")

    try:
        # Find all QUERY_COMPLETED records grouped by entity_id
        query_completed_records = db.query(Model_Databricks_Entity_Search_Job).filter(
            Model_Databricks_Entity_Search_Job.status == StewardshipJobStatus.QUERY_COMPLETED.value,
            Model_Databricks_Entity_Search_Job.execution_type == 'query'
        ).all()

        if not query_completed_records:
            app_logger.info("No QUERY_COMPLETED records found. Nothing to process.")
            return

        # Group by entity_id
        entity_groups = {}
        for record in query_completed_records:
            if record.entity_id not in entity_groups:
                entity_groups[record.entity_id] = []
            entity_groups[record.entity_id].append(record)

        app_logger.info(f"Found {len(query_completed_records)} QUERY_COMPLETED records across {len(entity_groups)} entities")

        # Get token — prefer App SP, fall back to PAT
        from lakefusion_utility.utils.databricks_util import get_app_sp_token, generate_pat
        token = get_app_sp_token() or generate_pat()
        if not token:
            app_logger.warning("No Databricks token available (SP or PAT) — cannot submit jobs")
            return

        service = EntitySearchService(db)

        for entity_id, records in entity_groups.items():
            try:
                app_logger.info(f"Submitting PM+Crosswalk job for entity_id={entity_id} ({len(records)} records)")

                # Build job parameters — only need entity-level params (no record-specific IDs)
                job_parameters = [
                    {"entity_id": str(entity_id), "experiment_id": "prod", "catalog_name": service.catalog_name},
                    {"catalog_name": service.catalog_name, "experiment_id": "prod"}
                ]

                # Create task list: Parse_Entity_Model_JSON → Process_Potential_Match + Process_CrossWalk → Entity_Job_Status
                tasks_list = service._create_pm_crosswalk_tasks(job_parameters)

                # Submit job
                job_service = DatabricksJobManager(token)
                job_create_response = job_service.create_and_submit_job("Stewardship_PM_Crosswalk", tasks_list)
                run_id = job_create_response.run_id

                app_logger.info(f"Submitted job run_id={run_id} for entity_id={entity_id}")

                # Update all QUERY_COMPLETED records for this entity
                for record in records:
                    record.job_run_id = str(run_id)
                    record.status = StewardshipJobStatus.SUBMITTED.value

                db.commit()
                app_logger.info(f"Updated {len(records)} records to SUBMITTED with job_run_id={run_id}")

            except Exception as e:
                app_logger.error(f"Failed to submit PM+Crosswalk job for entity_id={entity_id}: {e}")
                db.rollback()

    except Exception as e:
        app_logger.error(f"Error in process_query_completed_stewardship: {e}")
        app_logger.error(f"Traceback: {traceback.format_exc()}")

    app_logger.info("Finished process_query_completed_stewardship execution.")
