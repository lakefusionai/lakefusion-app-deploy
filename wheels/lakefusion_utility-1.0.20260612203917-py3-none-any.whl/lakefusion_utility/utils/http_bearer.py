from typing import Optional
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import HTTPException, Request, status
from lakefusion_utility.utils.logging_utils import get_logger

_logger = get_logger(__name__)


class HTTPBearer401(HTTPBearer):
    async def __call__(self, request: Request) -> Optional[HTTPAuthorizationCredentials]:
        # Check headers in order of priority:
        # 1. x-forwarded-access-token (Databricks Apps proxy-injected user token)
        # 2. Authorization (K8s / local development / direct access)
        forwarded_token = request.headers.get("x-forwarded-access-token")
        has_auth = bool(request.headers.get("authorization"))

        _logger.debug(
            f"Auth headers for {request.method} {request.url.path}: "
            f"Authorization={'Y' if has_auth else 'N'}, "
            f"x-forwarded-access-token={'Y' if forwarded_token else 'N'}"
        )

        if forwarded_token:
            _logger.info(f"Using x-forwarded-access-token for {request.url.path}")
            return HTTPAuthorizationCredentials(scheme="Bearer", credentials=forwarded_token)

        try:
            result = await super().__call__(request)
            _logger.info(f"Using Authorization header for {request.url.path}")
            return result
        except HTTPException as exc:
            _logger.warning(f"No valid auth credential found for {request.url.path}")
            if exc.status_code == status.HTTP_403_FORBIDDEN:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Not authenticated",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            raise

