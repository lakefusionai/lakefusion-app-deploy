from sqlalchemy import Column, Integer, String, DateTime, Boolean, JSON, ForeignKey, Text
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
from pydantic import BaseModel
from typing import Optional, List, Any
from sqlalchemy.orm import relationship

class SchemaEvolutionJob(Base):
    __tablename__ = 'schema_evolution_jobs'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(Integer, ForeignKey('entity.id'), nullable=False)
    integration_hub_id = Column(Integer, ForeignKey('integration_hub.id'), nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String(50), nullable=False, default='DRAFT')
    databricks_job_id = Column(String(255), nullable=True)
    databricks_run_id = Column(String(255), nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    completed_at = Column(DateTime, nullable=True)
    created_by = Column(String(255), nullable=False)

    edits = relationship("SchemaEvolutionEdit", back_populates="job", cascade="all, delete-orphan")

    def __init__(self, entity_id, integration_hub_id, name, created_by, description=None):
        self.entity_id = entity_id
        self.integration_hub_id = integration_hub_id
        self.name = name
        self.created_by = created_by
        self.description = description
        self.status = 'DRAFT'
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()

    def __repr__(self):
        return (
            f"<SchemaEvolutionJob(id={self.id}, entity_id={self.entity_id}, "
            f"name={self.name}, status={self.status})>"
        )


class SchemaEvolutionEdit(Base):
    __tablename__ = 'schema_evolution_edits'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, autoincrement=True)
    job_id = Column(Integer, ForeignKey('schema_evolution_jobs.id', ondelete='CASCADE'), nullable=False)
    action_type = Column(String(50), nullable=False)
    attribute_name = Column(String(255), nullable=False)
    attribute_label = Column(String(255), nullable=True)
    attribute_description = Column(Text, nullable=True)
    attribute_type = Column(String(50), nullable=True)
    is_match_attribute = Column(Boolean, default=False)
    source_mappings = Column(JSON, nullable=True)
    survivorship_rule = Column(JSON, nullable=True)
    validation_function = Column(JSON, nullable=True)
    new_attribute_name = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    job = relationship("SchemaEvolutionJob", back_populates="edits")

    def __init__(self, job_id, action_type, attribute_name, attribute_label=None,
                 attribute_description=None, attribute_type=None, is_match_attribute=False,
                 source_mappings=None, survivorship_rule=None, validation_function=None,
                 new_attribute_name=None):
        self.job_id = job_id
        self.action_type = action_type
        self.attribute_name = attribute_name
        self.attribute_label = attribute_label
        self.attribute_description = attribute_description
        self.attribute_type = attribute_type
        self.is_match_attribute = is_match_attribute
        self.source_mappings = source_mappings
        self.survivorship_rule = survivorship_rule
        self.validation_function = validation_function
        self.new_attribute_name = new_attribute_name
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()

    def __repr__(self):
        return (
            f"<SchemaEvolutionEdit(id={self.id}, job_id={self.job_id}, "
            f"action_type={self.action_type}, attribute_name={self.attribute_name})>"
        )

class SourceMappingSchema(BaseModel):
    dataset_id: int
    dataset_attribute: str


class SurvivorshipRuleSchema(BaseModel):
    strategy: str
    strategy_rule: Optional[Any] = None
    ignore_null: Optional[bool] = False
    # Tie-break direction. One of "latest" | "earliest". Default "latest".
    tie_breaker: Optional[str] = "latest"


class ValidationFunctionSchema(BaseModel):
    function_name: str
    function_type: str  # 'predefined' or 'userdefined'
    function_definition: Optional[str] = None
    validation_level: str  # 'error' or 'warning'
    validation_message: str


class SchemaEvolutionJobCreate(BaseModel):
    name: str
    description: Optional[str] = None


class SchemaEvolutionEditCreate(BaseModel):
    action_type: str  # ADD_ATTRIBUTE (only supported for now)
    attribute_name: str
    attribute_label: Optional[str] = None
    attribute_description: Optional[str] = None
    attribute_type: Optional[str] = None
    is_match_attribute: bool = False
    source_mappings: Optional[List[SourceMappingSchema]] = None
    survivorship_rule: Optional[SurvivorshipRuleSchema] = None
    validation_function: Optional[ValidationFunctionSchema] = None
    new_attribute_name: Optional[str] = None


class SchemaEvolutionEditResponse(BaseModel):
    id: int
    job_id: int
    action_type: str
    attribute_name: str
    attribute_label: Optional[str]
    attribute_description: Optional[str]
    attribute_type: Optional[str]
    is_match_attribute: bool
    source_mappings: Optional[List[dict]]
    survivorship_rule: Optional[dict]
    validation_function: Optional[dict]
    new_attribute_name: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True


class SchemaEvolutionJobResponse(BaseModel):
    id: int
    entity_id: int
    integration_hub_id: int
    name: str
    description: Optional[str]
    status: str
    databricks_job_id: Optional[str]
    databricks_run_id: Optional[str]
    error_message: Optional[str]
    edits: List[SchemaEvolutionEditResponse] = []
    created_at: datetime
    updated_at: datetime
    completed_at: Optional[datetime]
    created_by: str

    class Config:
        orm_mode = True


class ValidationError(BaseModel):
    edit_id: Optional[int] = None
    field: str
    message: str


class SchemaEvolutionValidateResponse(BaseModel):
    is_valid: bool
    errors: List[ValidationError] = []
