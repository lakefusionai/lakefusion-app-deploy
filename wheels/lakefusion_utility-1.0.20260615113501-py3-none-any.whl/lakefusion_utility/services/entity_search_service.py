import json
import traceback
from sqlalchemy.orm import Session
from lakefusion_utility.models.dataset import Dataset
from lakefusion_utility.models.integration_hub import Integration_Hub
from fastapi import HTTPException
from lakefusion_utility.utils.app_db import db_commit_auto_rollback  # Import the db_commit_auto_rollback function
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.databricks_util import DataSetSQLService, CommonUtilities, CatalogService, _create_workspace_client, get_app_sp_token
from lakefusion_utility.services.entity_service import EntityService, EntityAttributeService
from lakefusion_utility.models.entity import Entity, EntityAttributes, EntityDatasetMapping
from sqlalchemy import and_
from databricks.sdk.service import jobs
from lakefusion_utility.models.databricks_model import *
from databricks.sdk.service.compute import ClusterSpec, RuntimeEngine,AwsAttributes,AwsAvailability,AutoScale,DataSecurityMode,AzureAttributes
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from lakefusion_utility.utils.databricks_util import DatabricksJobManager, DataSetSQLService, get_resource_tags
from lakefusion_utility.models.httpresponse import HttpResponse
from databricks.sdk.service.jobs import Task, NotebookTask, TaskEmailNotifications, RunIf, Source, CronSchedule, JobParameterDefinition, CreateResponse, Job, JobSettings,TaskDependency,ConditionTask,ConditionTaskOp,JobParameter,SubmitTask,SqlTask,SqlTaskQuery
from typing import List,Literal,Dict, Any, Tuple, Optional
from lakefusion_utility.utils.logging_utils import get_logger
from databricks.sdk.errors import PermissionDenied
from lakefusion_utility.utils.dbx_error_handler import raise_on_dbx_permission_error
import os,json
from sqlalchemy import or_, func, JSON
from lakefusion_utility.models.match_maven import *
from lakefusion_utility.models.databricks_model import *
from lakefusion_utility.models.entity import EntityAttributes  # re-import after wildcard to override match_maven.EntityAttributes
from lakefusion_utility.utils.databricks_util import DatabricksJobManager
from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
from lakefusion_core_engine.lakebase_client import LakebasePgClient
import math
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.notebook_path_utils import get_notebook_folder
from decimal import Decimal
from datetime import date, datetime
import re
from lakefusion_utility.utils.databricks_host import get_databricks_host
import hashlib
from typing import Any

# Set up logging
app_logger = get_logger(__name__)

def generate_ref_key(source_path: str, source_id: str) -> str:
    """
    Generate a deterministic surrogate key for source records.
    
    Args:
        source_path: Source table path
        source_id: Source record ID
        
    Returns:
        surrogate_key with 'ref_' prefix
    """
    composite = f"{source_path}_{source_id}"
    hash_value = hashlib.md5(composite.encode()).hexdigest()
    return f"ref_{hash_value}"

def serialize_row_data(row_dict: dict) -> dict:
    """
    Serialize row data with proper numeric precision handling.
    Converts float/Decimal types to properly formatted strings to preserve precision.
    
    Args:
        row_dict: Dictionary containing row data
    
    Returns:
        Processed dictionary with proper numeric precision
    """
    processed = {}
    for key, value in row_dict.items():
        if isinstance(value, Decimal):
            # Convert Decimal to float, round, then format
            rounded = round(float(value), 2)
            # Use g format to avoid trailing zeros, then convert to float for JSON
            processed[key] = float(rounded)
        elif isinstance(value, float):
            # Round to 2 decimal places
            rounded = round(value, 2)
            processed[key] = rounded
        elif isinstance(value, (date, datetime)):
            # Keep datetime objects as-is
            processed[key] = value
        else:
            processed[key] = value
    return processed

def compare_versions(version1: str, version2: str) -> int:
    """
    Compare two version strings.
    Returns:
        -1 if version1 < version2
         0 if version1 == version2
         1 if version1 > version2
    """
    if not version1:
        version1 = "1.0.0"
    if not version2:
        version2 = "1.0.0"
    
    v1_parts = [int(x) for x in version1.split('.')]
    v2_parts = [int(x) for x in version2.split('.')]
    
    # Pad shorter version with zeros
    while len(v1_parts) < len(v2_parts):
        v1_parts.append(0)
    while len(v2_parts) < len(v1_parts):
        v2_parts.append(0)
    
    for i in range(len(v1_parts)):
        if v1_parts[i] < v2_parts[i]:
            return -1
        elif v1_parts[i] > v2_parts[i]:
            return 1
    return 0


def is_version_gte(version: str, target: str) -> bool:
    """Check if version is greater than or equal to target version."""
    return compare_versions(version, target) >= 0


NEW_PIPELINE_MIN_VERSION = "4.0.0"


class AttributeValidationError(Exception):
    """Custom exception for attribute validation errors."""
    def __init__(self, errors: List[str]):
        self.errors = errors
        super().__init__(f"Validation failed: {'; '.join(errors)}")


class AttributeValidator:
    """Validates update attributes against entity attribute definitions."""
    
    # Mapping of common Spark/SQL types to Python validation
    TYPE_VALIDATORS = {
        'string': lambda v: isinstance(v, str),
        'str': lambda v: isinstance(v, str),
        'varchar': lambda v: isinstance(v, str),
        'text': lambda v: isinstance(v, str),
        'int': lambda v: AttributeValidator._is_int(v),
        'integer': lambda v: AttributeValidator._is_int(v),
        'bigint': lambda v: AttributeValidator._is_int(v),
        'smallint': lambda v: AttributeValidator._is_int(v),
        'tinyint': lambda v: AttributeValidator._is_int(v),
        'long': lambda v: AttributeValidator._is_int(v),
        'float': lambda v: AttributeValidator._is_numeric(v),
        'double': lambda v: AttributeValidator._is_numeric(v),
        'decimal': lambda v: AttributeValidator._is_numeric(v),
        'numeric': lambda v: AttributeValidator._is_numeric(v),
        'boolean': lambda v: AttributeValidator._is_boolean(v),
        'bool': lambda v: AttributeValidator._is_boolean(v),
        'date': lambda v: AttributeValidator._is_date(v),
        'timestamp': lambda v: AttributeValidator._is_timestamp(v),
        'datetime': lambda v: AttributeValidator._is_timestamp(v),
    }
    
    @staticmethod
    def _is_int(value: Any) -> bool:
        """Check if value can be converted to int."""
        if isinstance(value, bool):
            return False
        if isinstance(value, int):
            return True
        if isinstance(value, str):
            try:
                int(value)
                return True
            except ValueError:
                return False
        return False
    
    @staticmethod
    def _is_numeric(value: Any) -> bool:
        """Check if value can be converted to float."""
        if isinstance(value, bool):
            return False
        if isinstance(value, (int, float)):
            return True
        if isinstance(value, str):
            try:
                float(value)
                return True
            except ValueError:
                return False
        return False
    
    @staticmethod
    def _is_boolean(value: Any) -> bool:
        """Check if value is a valid boolean representation."""
        if isinstance(value, bool):
            return True
        if isinstance(value, str):
            return value.lower() in ('true', 'false', '1', '0', 'yes', 'no')
        if isinstance(value, int):
            return value in (0, 1)
        return False
    
    @staticmethod
    def _is_date(value: Any) -> bool:
        """Check if value is a valid date string."""
        if isinstance(value, str):
            # Common date formats
            date_patterns = [
                r'^\d{4}-\d{2}-\d{2}$',  # YYYY-MM-DD
                r'^\d{2}/\d{2}/\d{4}$',  # MM/DD/YYYY
                r'^\d{2}-\d{2}-\d{4}$',  # DD-MM-YYYY
            ]
            for pattern in date_patterns:
                if re.match(pattern, value):
                    return True
        return False
    
    @staticmethod
    def _is_timestamp(value: Any) -> bool:
        """Check if value is a valid timestamp string."""
        if isinstance(value, str):
            # Common timestamp formats
            timestamp_patterns = [
                r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}',  # ISO format
                r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}',  # YYYY-MM-DD HH:MM:SS
            ]
            for pattern in timestamp_patterns:
                if re.match(pattern, value):
                    return True
        return False
    
    @classmethod
    def validate(
        cls,
        update_attributes: Dict[str, Any],
        entity_attributes: List[Any]
    ) -> Tuple[bool, List[str]]:
        """
        Validate update attributes against entity attribute definitions.
        
        Args:
            update_attributes: Dict of attribute_name -> new_value
            entity_attributes: List of attribute objects or dicts with 'name' and 'data_type'
        
        Returns:
            Tuple of (is_valid, list_of_error_messages)
        """
        errors = []
        
        # Build lookup dict for entity attributes
        attr_definitions = {}
        for attr in entity_attributes:
            # Handle both dict and object types
            if isinstance(attr, dict):
                name = attr.get('name') or attr.get('column_name')
                data_type = attr.get('data_type') or attr.get('type') or 'string'
            else:
                # Handle attribute objects
                name = getattr(attr, 'name', None) or getattr(attr, 'column_name', None)
                data_type = getattr(attr, 'data_type', None) or getattr(attr, 'type', None) or 'string'
            
            if name:
                attr_definitions[name] = data_type.lower() if data_type else 'string'
        
        # Validate each update attribute
        for attr_name, attr_value in update_attributes.items():
            # Check if attribute exists in entity definition
            if attr_name not in attr_definitions:
                errors.append(f"Unknown attribute '{attr_name}'. Valid attributes: {list(attr_definitions.keys())}")
                continue
            
            # Skip null/None values - they're allowed
            if attr_value is None:
                continue
            
            # Get expected type
            expected_type = attr_definitions[attr_name]
            
            # Find validator for this type
            validator = None
            for type_key, type_validator in cls.TYPE_VALIDATORS.items():
                if type_key in expected_type:
                    validator = type_validator
                    break
            
            # If no specific validator found, default to string (most permissive)
            if validator is None:
                validator = cls.TYPE_VALIDATORS['string']
            
            # Validate
            if not validator(attr_value):
                errors.append(
                    f"Invalid value for '{attr_name}': expected {expected_type}, "
                    f"got {type(attr_value).__name__} with value '{attr_value}'"
                )
        
        return (len(errors) == 0, errors)
    
    @classmethod
    def validate_or_raise(
        cls,
        update_attributes: Dict[str, Any],
        entity_attributes: List[Any]
    ) -> None:
        """Validate and raise AttributeValidationError if validation fails."""
        is_valid, errors = cls.validate(update_attributes, entity_attributes)
        if not is_valid:
            raise AttributeValidationError(errors)


class EntitySearchService:
    def __init__(self, db: Session):
        """Initializes the entityService with a database session.
        
        Args:
            db: SQLAlchemy session object.
        """
        self.db = db
        self.catalog_name = (
        self.db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == "catalog_name")
        .first().config_value )
        self.db_config_service = DBConfigPropertiesService(db=self.db)
        self.notebook_folder_path=self.db_config_service.getDBConfigProperties(key="notebook_path")
        self.lakefusion_spn=self.db_config_service.getDBConfigProperties(key="lakefusion_spn")
        # Per-request cache of master-table column introspection results. Keyed by
        # (entity_name, experiment). Service instances are short-lived (per HTTP
        # request via FastAPI Depends(get_db)), so cache lifetime matches the
        # request and needs no invalidation.
        self._embedding_col_cache: Dict[Tuple[str, str], bool] = {}

    def get_integration_hub_task_version(self, entity_id: int) -> Optional[str]:
        """
        Get the version from the Integration_Hub table for a given entity.
        Each entity can have only one integration task associated with it.
        """
        try:
            row = (
                self.db.query(Integration_Hub.version)
                .filter(Integration_Hub.entity_id == entity_id)
                .order_by(Integration_Hub.created_at.desc())
                .first()
            )
            if not row:
                app_logger.warning(f"No integration hub record found for entity_id: {entity_id}")
                return None
            version = row.version
            app_logger.info(f"Fetched integration hub version {version} for entity_id: {entity_id}")
            return version
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Unable to get entity version for entity_id {entity_id}. Reason: {message}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity version: {str(e)}"
            )
    

    def get_job_run_status(self,job_run_id:str,token:str):
        try:
            job_service = DatabricksJobManager(token)
            job_response=job_service.get_job_run_status(job_run_id)
            return job_response

        except Exception as e:
            app_logger.exception(f'Unable to create model databricks job. Reason - {str(e)}')
 
    
    def read_entity_search_profile(self, entity_id: int, warehouse_id: str, token: str):
        """Retrieves master entity records with REFERENCE_ENTITY columns resolved
        to their canonical display values via the reference entity table.
        """
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')

            # Reference-entity reads route through ReadOperations so that
            # entities backed by Lakebase Postgres (entity_type='reference')
            # transparently read from the synced UC lb_<table>_history
            # Delta table instead of from a Delta table written directly.
            # Master/product entities still read UC Delta tables as before.
            db_config_service = DBConfigPropertiesService(db=self.db)
            ref_read_ops_cache: Dict[int, Any] = {}

            def get_ref_table_ref(ref_entity_id: int, ref_table_path: str) -> str:
                # The reference master table (_reference_prod) is a UC Delta
                # table for BOTH delta- and lakebase-backed reference entities
                # (Delta is the source of truth; lakebase mirrors it to
                # Postgres). This master-grid JOIN runs in warehouse SQL
                # against UC, so join directly against the Delta reference
                # table — no lb_*_history / LakebaseReadOps hop (that path is
                # obsolete and LakebaseReadOps is no longer instantiable).
                return self._common_utils.apply_tilde(ref_table_path)

            # Build a lookup: reference_entity_id → reference_entity metadata
            ref_dataset_lookup = {
                rd.reference_entity_id: rd
                for rd in (entity.reference_dataset or [])
            }

            select_parts = ["mp.lakefusion_id"]
            joins = []
            join_alias_counter = 0

            for attr in entity.attributes:
                if not attr.name or attr.name == "lakefusion_id" or not attr.show_in_ui:
                    continue

                if attr.type == "REFERENCE_ENTITY" and attr.type_config:
                    ref_entity_id   = attr.type_config.get("reference_entity_id")
                    ref_output_attr = attr.type_config.get("reference_entity_output_attr") or attr.name
                    ref_dataset     = ref_dataset_lookup.get(ref_entity_id)
                    ref_table       = getattr(ref_dataset, "reference_entity_table_path", None) if ref_dataset else None

                    if ref_table:
                        alias = f"ref_{join_alias_counter}"
                        join_alias_counter += 1

                        ref_table_sql = get_ref_table_ref(ref_entity_id, ref_table)

                        # mp.{attr} holds ref_lakefusion_id after RDM pipeline
                        joins.append(
                            f"LEFT JOIN {ref_table_sql} {alias} "
                            f"ON mp.`{attr.name}` = {alias}.ref_lakefusion_id"
                        )
                        # Show canonical value; NULL if no match (mp.attr is NULL)
                        select_parts.append(
                            f"CASE WHEN mp.`{attr.name}` IS NOT NULL "
                            f"THEN {alias}.`{ref_output_attr}` "
                            f"ELSE NULL END AS `{attr.name}`"
                        )
                    else:
                        # ref table path missing — fall back to raw value
                        select_parts.append(f"mp.`{attr.name}`")
                else:
                    select_parts.append(f"mp.`{attr.name}`")
    
            select_clause = ",\n  ".join(select_parts)
            join_clause   = "\n".join(joins)
    
            query = f"""
                SELECT
                  {select_clause}
                FROM {self.catalog_name}.gold.{entity_name}_master_prod mp
                {join_clause}
            """
    
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            data = sqlservice_conn.execute_dataset(query=query)
            return data
    
        except Exception as e:
            _ename = _owner = None
            try:
                _ent = EntityService(db=self.db).get_full_entity_by_id(entity_id)
                if _ent:
                    _ename = _ent.name
                    _owner = _ent.created_by
            except Exception:
                pass
            raise_on_dbx_permission_error(
                e, "read entity profile",
                entity_name=_ename,
                owner_email=_owner,
            )
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile: {str(e)}"
            )
        finally:
            self.db.close()
    
    def read_entity_search_profile_id(self, entity_id: int, id_value: str, warehouse_id: str, token: str):
        """Retrieves a single master entity record by lakefusion_id with
        REFERENCE_ENTITY columns resolved to canonical display values.
        """
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')

            # Reference-entity JOINs route through ReadOperations so that
            # lakebase-backed reference entities resolve to the synced
            # lb_<table>_history; delta-backed ones stay on the original
            # path. See read_entity_search_profile for details.
            db_config_service = DBConfigPropertiesService(db=self.db)
            ref_read_ops_cache: Dict[int, Any] = {}

            def get_ref_table_ref(ref_entity_id: int, ref_table_path: str) -> str:
                # The reference master table (_reference_prod) is a UC Delta
                # table for BOTH delta- and lakebase-backed reference entities
                # (Delta is the source of truth; lakebase mirrors it to
                # Postgres). This master-grid JOIN runs in warehouse SQL
                # against UC, so join directly against the Delta reference
                # table — no lb_*_history / LakebaseReadOps hop (that path is
                # obsolete and LakebaseReadOps is no longer instantiable).
                return self._common_utils.apply_tilde(ref_table_path)

            # Build reference entity lookup
            ref_dataset_lookup = {
                rd.reference_entity_id: rd
                for rd in (entity.reference_dataset or [])
            }
    
            def _wrap_complex(expr, attr_obj):
                """Wrap STRUCT/ARRAY cols in to_json so the JDBC connector
                returns a parseable JSON string instead of the field-name
                array quirk it falls back to for plain struct columns."""
                is_arr = bool(getattr(attr_obj, "is_array", False))
                atype = (getattr(attr_obj, "type", "") or "").strip().upper()
                if is_arr or atype == "STRUCT":
                    return f"to_json({expr})"
                return expr

            select_parts = ["mp.lakefusion_id"]
            joins = []
            join_alias_counter = 0

            for attr in entity.attributes:
                if not attr.name or attr.name == "lakefusion_id" or not attr.show_in_ui:
                    continue

                if attr.type == "REFERENCE_ENTITY" and attr.type_config:
                    ref_entity_id   = attr.type_config.get("reference_entity_id")
                    ref_output_attr = attr.type_config.get("reference_entity_output_attr") or attr.name
                    ref_dataset     = ref_dataset_lookup.get(ref_entity_id)
                    ref_table       = getattr(ref_dataset, "reference_entity_table_path", None) if ref_dataset else None

                    if ref_table:
                        alias = f"ref_{join_alias_counter}"
                        join_alias_counter += 1
                        ref_table_sql = get_ref_table_ref(ref_entity_id, ref_table)
                        joins.append(
                            f"LEFT JOIN {ref_table_sql} {alias} "
                            f"ON mp.`{attr.name}` = {alias}.ref_lakefusion_id"
                        )
                        select_parts.append(
                            f"CASE WHEN mp.`{attr.name}` IS NOT NULL "
                            f"THEN {alias}.`{ref_output_attr}` "
                            f"ELSE NULL END AS `{attr.name}`"
                        )
                    else:
                        select_parts.append(
                            f"{_wrap_complex(f'mp.`{attr.name}`', attr)} AS `{attr.name}`"
                        )
                else:
                    select_parts.append(
                        f"{_wrap_complex(f'mp.`{attr.name}`', attr)} AS `{attr.name}`"
                    )
    
            select_clause = ",\n  ".join(select_parts)
            join_clause   = "\n".join(joins)
    
            query = f"""
                SELECT
                  {select_clause}
                FROM {self.catalog_name}.gold.{entity_name}_master_prod mp
                {join_clause}
                WHERE mp.lakefusion_id = '{id_value}'
            """
    
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            data = sqlservice_conn.execute_dataset(query=query)
    
            if not data or len(data) == 0:
                app_logger.info(f'No data found for entity {entity_id} with lakefusion_id={id_value}')
                raise HTTPException(
                    status_code=404,
                    detail=f"No profile found for the given ID value: {id_value}"
                )
    
            result = data[0]
            # Strip internal-use columns from the master row before returning to the UI.
            # Both `attributes_combined` (the deterministic-rules input string) and
            # `attributes_combined_embedding` (the precomputed-mode vector) are pipeline
            # infrastructure, not user-facing attributes. Both Profile Details and the
            # Sources tab consume this response, so filtering here covers both views.
            if isinstance(result, dict):
                for internal_col in ("attributes_combined", "attributes_combined_embedding"):
                    result.pop(internal_col, None)

            # Map attribute names to labels    
            entity_attribute_conn = EntityAttributeService(db=self.db)  
            for res in list(result.keys()):
                attribute_label = entity_attribute_conn.get_attributelabel_by_attributename(entity_id, res)
                if attribute_label:
                    result[attribute_label] = result.pop(res)
    
            result = serialize_row_data(result)
            return result
    
        except Exception as e:
            raise_on_dbx_permission_error(e, "read entity profile by ID")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile: {str(e)}"
            )
        finally:
            self.db.close()
    def build_filter_clauses(self, filters, table_prefix=None):
        try:
            if isinstance(filters, str):
                if '%' in filters:
                    try:
                        import urllib.parse
                        filters = urllib.parse.unquote(filters)
                    except Exception as e:
                        app_logger.error(f"Error URL-decoding filters: {str(e)}")
                
                if filters.strip():
                    try:
                        filters = json.loads(filters)
                    except json.JSONDecodeError as e:
                        app_logger.error(f"Invalid JSON filter string: {e}")
                        return "", []
                else:
                    return "", []
                
            if not filters or not isinstance(filters, list):
                return "", []
                
            filter_clauses = []
            for i, filter_item in enumerate(filters):
                # attributeName is the actual column name; attributeId may be a numeric DB primary key.
                # Prefer attributeName to ensure correct SQL column references.
                attribute_name = filter_item.get('attributeName') or filter_item.get('attributeId')
                operator = filter_item.get('operator')
                value = filter_item.get('value')
                conjunction = filter_item.get('conjunction', 'AND')

                if not attribute_name or not operator:
                    continue
                    
                column = f"{table_prefix}.{attribute_name}" if table_prefix else attribute_name
                
                sql_clause = ""
                
                # Text/String operators
                if operator == 'eq':  # is equal to
                    sql_clause = f"UPPER({column}) = UPPER('{value}')"
                elif operator == 'neq':  # is not equal to
                    sql_clause = f"UPPER({column}) != UPPER('{value}')"
                elif operator == 'contains':  # contains
                    sql_clause = f"UPPER({column}) LIKE UPPER('%{value}%')"
                elif operator == 'not_contains':  # does not contain
                    sql_clause = f"UPPER({column}) NOT LIKE UPPER('%{value}%')"
                elif operator == 'starts_with':  # starts with
                    sql_clause = f"UPPER({column}) LIKE UPPER('{value}%')"
                elif operator == 'ends_with':  # ends with
                    sql_clause = f"UPPER({column}) LIKE UPPER('%{value}')"
                
                # Numeric operators
                elif operator == 'gt':  # is greater than
                    sql_clause = f"{column} > {value}"
                elif operator == 'lt':  # is less than
                    sql_clause = f"{column} < {value}"
                elif operator == 'gte':  # is greater than or equal to
                    sql_clause = f"{column} >= {value}"
                elif operator == 'lte':  # is less than or equal to
                    sql_clause = f"{column} <= {value}"
                
                # Null operators
                elif operator == 'is_null':  # is null
                    sql_clause = f"{column} IS NULL"
                elif operator == 'is_not_null':  # is not null
                    sql_clause = f"{column} IS NOT NULL"
                
                # Boolean operators
                elif operator == 'eq_true':  # is true
                    sql_clause = f"{column} = TRUE"
                elif operator == 'eq_false':  # is false
                    sql_clause = f"{column} = FALSE"
                
                if sql_clause:
                    if i > 0:
                        filter_clauses.append(conjunction)
                    filter_clauses.append(sql_clause)
            
            if filter_clauses:
                return " ".join(filter_clauses), []
            return "", []
        except Exception as e:
            app_logger.error(f"Error building filter clauses: {str(e)}")
            return "", []
            
    def get_all_records(self, entity_id: int, warehouse_id: str, token: str, page: int = 1, page_size: int = 1000, filters=None):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')

            # Reference-entity JOINs route through ReadOperations — see
            # read_entity_search_profile for details.
            db_config_service = DBConfigPropertiesService(db=self.db)
            ref_read_ops_cache: Dict[int, Any] = {}

            def get_ref_table_ref(ref_entity_id: int, ref_table_path: str) -> str:
                # The reference master table (_reference_prod) is a UC Delta
                # table for BOTH delta- and lakebase-backed reference entities
                # (Delta is the source of truth; lakebase mirrors it to
                # Postgres). This master-grid JOIN runs in warehouse SQL
                # against UC, so join directly against the Delta reference
                # table — no lb_*_history / LakebaseReadOps hop (that path is
                # obsolete and LakebaseReadOps is no longer instantiable).
                return self._common_utils.apply_tilde(ref_table_path)

            # Reference entity lookup
            ref_dataset_lookup = {
                rd.reference_entity_id: rd
                for rd in (entity.reference_dataset or [])
            }

            name_to_label  = {}
            columns_to_select = []

            has_lakefusion_id = any(attr.name == "lakefusion_id" for attr in entity.attributes)
            if not has_lakefusion_id:
                columns_to_select.append("lakefusion_id")

            for attr in entity.attributes:
                if attr.name and (attr.show_in_ui or attr.is_label or attr.is_primary_key):
                    if attr.name not in columns_to_select:
                        columns_to_select.append(attr.name)
                        if attr.label:
                            name_to_label[attr.name] = attr.label

            if not columns_to_select:
                return {
                    "data": [],
                    "pagination": {
                        "page": page, "page_size": page_size,
                        "total_count": 0, "total_pages": 0
                    }
                }

            offset = (page - 1) * page_size

            # ── Build SELECT parts + JOINs for REFERENCE_ENTITY columns ──────────
            # Built once, reused in both DNB and non-DNB branches.
            # DNB branch uses alias "m.", non-DNB uses no prefix — handled below.
            joins              = []
            join_alias_counter = 0
            # Maps column name → select expression (with placeholder {pfx} for table prefix)
            select_expr = {}

            for col in columns_to_select:
                attr = next((a for a in entity.attributes if a.name == col), None)

                if attr and attr.type == "REFERENCE_ENTITY" and attr.type_config:
                    ref_entity_id   = attr.type_config.get("reference_entity_id")
                    ref_output_attr = attr.type_config.get("reference_entity_output_attr") or col
                    ref_dataset     = ref_dataset_lookup.get(ref_entity_id)
                    ref_table       = getattr(ref_dataset, "reference_entity_table_path", None) if ref_dataset else None

                    if ref_table:
                        alias = f"ref_{join_alias_counter}"
                        join_alias_counter += 1
                        # Route lakebase-backed reference entities to their
                        # synced lb_<table>_history; delta-backed ones pass
                        # through unchanged.
                        ref_table_sql = get_ref_table_ref(ref_entity_id, ref_table)
                        # JOIN uses {pfx} placeholder — filled per branch
                        joins.append((alias, ref_table_sql, col))
                        select_expr[col] = (
                            f"CASE WHEN {{pfx}}`{col}` IS NOT NULL "
                            f"THEN {alias}.`{ref_output_attr}` "
                            f"ELSE NULL END AS `{col}`"
                        )
                    else:
                        select_expr[col] = "{pfx}`" + col + "`"
                else:
                    select_expr[col] = "{pfx}`" + col + "`"
    
            def build_select_and_joins(table_prefix: str):
                """Materialise select expressions and JOIN clauses for a given table prefix."""
                pfx = f"{table_prefix}." if table_prefix else ""
                parts = [expr.format(pfx=pfx) for expr in select_expr.values()]
                join_clauses = "\n".join(
                    f"LEFT JOIN {ref_table} {alias} "
                    f"ON {pfx}`{col}` = {alias}.ref_lakefusion_id"
                    for alias, ref_table, col in joins
                )
                return parts, join_clauses
    
            sqlservice_conn  = DataSetSQLService(token, warehouse_id)
            has_dnb          = entity.dnb_integration is not None and entity.dnb_integration.is_active
            primary_key_attr = next((attr for attr in entity.attributes if attr.is_primary_key), None)
    
            if has_dnb and primary_key_attr:
                dnb_table             = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"
                select_parts, join_clause = build_select_and_joins("m")
                select_parts.append("COALESCE(d.dnb_status, 'NONE') AS dnb_status")
                select_parts.append("COUNT(*) OVER() AS total_count")
                select_clause_str = ",\n                        ".join(select_parts)
    
                where_clause = ""
                if filters:
                    filter_clause, _ = self.build_filter_clauses(filters, table_prefix="m")
                    if filter_clause:
                        where_clause = f"WHERE {filter_clause}"
    
                query = f"""
                    SELECT
                        {select_clause_str}
                    FROM {self.catalog_name}.gold.{entity_name}_master_prod m
                    {join_clause}
                    LEFT JOIN (
                        SELECT lakefusion_id AS dnb_lf_id,
                            CASE
                                WHEN MAX(CASE WHEN merge_status = 'ACCEPTED'    THEN 1 ELSE 0 END) = 1 THEN 'ACCEPTED'
                                WHEN MAX(CASE WHEN merge_status = 'AUTO_MERGED' THEN 1 ELSE 0 END) = 1 THEN 'MATCHED'
                                WHEN MAX(CASE WHEN merge_status = 'IN_REVIEW'   THEN 1 ELSE 0 END) = 1 THEN 'IN_REVIEW'
                                ELSE 'NONE'
                            END AS dnb_status
                        FROM {dnb_table}
                        GROUP BY lakefusion_id
                    ) d ON m.lakefusion_id = d.dnb_lf_id
                    {where_clause}
                    LIMIT {page_size} OFFSET {offset}
                """
            else:
                select_parts, join_clause = build_select_and_joins("mp")
                select_parts.append("COUNT(*) OVER() AS total_count")
                select_clause_str = ",\n                        ".join(select_parts)

                where_clause = ""
                if filters:
                    filter_clause, _ = self.build_filter_clauses(filters, table_prefix="mp")
                    if filter_clause:
                        where_clause = f"WHERE {filter_clause}"

                query = f"""
                    SELECT
                        {select_clause_str}
                    FROM {self.catalog_name}.gold.{entity_name}_master_prod mp
                    {join_clause}
                    {where_clause}
                    LIMIT {page_size} OFFSET {offset}
                """
    
            raw_data = sqlservice_conn.execute_dataset(query=query)
            for i, record in enumerate(raw_data):
                if isinstance(record, dict):
                    raw_data[i] = serialize_row_data(record)
    
            total_count = raw_data[0]['total_count'] if raw_data and 'total_count' in raw_data[0] else 0
    
            if raw_data:
                for record in raw_data:
                    record_dict = dict(record) if not isinstance(record, dict) else record
                    record_dict.pop('total_count', None)
    
            total_pages = math.ceil(total_count / page_size) if page_size > 0 else 0
    
            return {
                "data": raw_data,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total_count": total_count,
                    "total_pages": total_pages
                }
            }
    
        except HTTPException:
            raise
        except Exception as e:
            _ename = _owner = None
            try:
                _ent = EntityService(db=self.db).get_full_entity_by_id(entity_id)
                if _ent:
                    _ename = _ent.name
                    _owner = _ent.created_by
            except Exception:
                pass
            raise_on_dbx_permission_error(
                e, "fetch all records",
                entity_name=_ename,
                owner_email=_owner,
            )
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch master records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch master records: {str(e)}"
            )
        finally:
            self.db.close()
    def create_not_match_tasks_and_job_updated(self,parameters):
        try:
            job_parameters_list = [i for i in parameters]
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Not_Match",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Manual_Not_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Manual_Not_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )

    def create_match_merge_tasks_and_job(self,parameters):
        try:
            
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            
            job_parameters_list = [i for i in parameters]
            
            
            
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Match_Merge",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Manual Merge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Manual Merge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Potential Match Table",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create task: {str(e)}"
            )
        
    def create_match_merge_tasks_and_job_updated(self,parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}
           
            job_parameters_list = [i for i in parameters]
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                #new_cluster=job_cluster.new_cluster,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Manual_Merge",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Manual_Merge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Manual_Merge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Manual_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Manual_Merge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create task: {str(e)}"
            )

    def create_match_merge_tasks_and_job_dnbintegration(self,parameters):
        try:
            dbx_cloud=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "dbx_cloud").first().config_value)
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            if(dbx_cloud=='azure'):
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                cluster_name="",
                spark_version="16.0.x-cpu-ml-scala2.12",
                azure_attributes=AzureAttributes(
                    first_on_demand=1
                ),  # Corrected Azure Attributes
                node_type_id="Standard_DS12_v2",
                driver_node_type_id="Standard_DS12_v2",  # Correct Azure instance type
                spark_env_vars={
                    "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                },
                enable_elastic_disk=False,
                data_security_mode=DataSecurityMode.SINGLE_USER,
                runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                autoscale=AutoScale(
                    min_workers=1,  # Updated worker count
                    max_workers=1   # Updated worker count
                ),
                custom_tags=tags  # Add custom tags
                ))
            else:
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    aws_attributes=AwsAttributes(
                        first_on_demand=1,
                        availability=AwsAvailability.SPOT_WITH_FALLBACK,
                        zone_id="us-west-2d",
                        spot_bid_price_percent=100,
                        ebs_volume_count=0
                    ),
                    node_type_id="r5d.4xlarge",  # Updated instance type
                    spark_env_vars={
                        "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                    },
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                    autoscale=AutoScale(
                        min_workers=2,  # Updated worker count
                        max_workers=4   # Updated worker count
                    ),
                    custom_tags=tags  # Add custom tags
                    ))
            tasks_list = [
            SubmitTask(
                task_key="Entity_Match_Merge",
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/dnb_integration/Manual Merge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('dnb_integration', self.db)}/Manual Merge",
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )] 
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
    
    def run_match_merge(self,entity_id:int,potential_record,token,created_by):
        try:
            job_parameters=[{"entity_id": str(entity_id),"experiment_id": str('prod') , "catalog_name":self.catalog_name },{"catalog_name":self.catalog_name,"experiment_id":str('prod'),"master_id":str(potential_record.master_id),"unified_dataset_ids": json.dumps([{"id": i.id,"dataset_id": i.dataset_id} for i in potential_record.unified_dataset_ids])}]
            if(potential_record.operation_type in ['MERGE','MERGE_ALL']):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_match_merge_tasks_and_job(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_MERGE",task_list_response,self.lakefusion_spn)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
            elif(potential_record.operation_type=='NOT_A_MATCH'):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_not_match_tasks_and_job(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_Not_A_Match",task_list_response,self.lakefusion_spn)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type='NOT_A_MATCH',
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "run match merge")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )

    def run_match_merge_updated(self,entity_id:int,potential_record,token,created_by):
        try:
            job_parameters=[{"entity_id": str(entity_id),"experiment_id": str('prod') , "catalog_name":self.catalog_name },{"catalog_name":self.catalog_name,"experiment_id":str('prod'),"master_id":str(potential_record.master_id),"unified_dataset_ids": json.dumps([{"id": i.id,"dataset_id": i.dataset_id} for i in potential_record.unified_dataset_ids])}]
            if(potential_record.operation_type in ['MERGE','MERGE_ALL']):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_match_merge_tasks_and_job_updated(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_MERGE",task_list_response,self.lakefusion_spn)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
            elif(potential_record.operation_type=='NOT_A_MATCH'):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_not_match_tasks_and_job_updated(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_Not_A_Match",task_list_response,self.lakefusion_spn)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                for i in potential_record.unified_dataset_ids:
                    entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=i.id,
                        operation_type='NOT_A_MATCH',
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by)
                    self.db.add(entity_search_jobs)
                    self.db.commit()
                    self.db.refresh(entity_search_jobs)
                return entity_search_jobs
        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "run match merge")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )

    # =========================================================================
    # SQL Stewardship: Shared utilities
    # =========================================================================

    def _create_pm_crosswalk_tasks(self, parameters):
        """
        Create task list for PM + CrossWalk refresh (superset DAG).
        Runs golden PM + normal PM + crosswalk to cover both normal and dedup merges.
        Parse_Entity_Model_JSON → (PM golden ∥ PM normal ∥ CrossWalk) → Entity_Job_Status
        """
        try:
            tags = get_resource_tags()
            if tags is None:
                tags = {}

            notebook_folder = get_notebook_folder('integration-core', self.db)
            job_parameters_list = [i for i in parameters]
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/{notebook_folder}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Potential_Match_Table",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/{notebook_folder}/golden_deduplication/Process_Potential_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Potential_Match_Normal",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/{notebook_folder}/normal_deduplication/Process_Potential_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_CrossWalk",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/{notebook_folder}/Process_Crosswalk",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Entity_Job_Status",
                    depends_on=[
                        TaskDependency(task_key="Process_CrossWalk"),
                        TaskDependency(task_key="Process_Potential_Match_Normal"),
                        TaskDependency(task_key="Process_Potential_Match_Table"),
                    ],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/{notebook_folder}/Entity_Job_Status",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
            ]
            return tasks_list
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create PM+Crosswalk tasks: {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create PM+Crosswalk tasks: {str(e)}")

    # =========================================================================
    # SQL Stewardship: Merge via SQL Warehouse
    # =========================================================================

    # Delta concurrency retry config (mirrors concurrency_utils.py in notebooks)
    _CONCURRENT_RETRY_MARKERS = (
        "CONCURRENT_APPEND",
        "CONCURRENT_DELETE_DELETE",
        "CONCURRENT_DELETE_READ",
    )
    _RETRY_DELAYS = (5, 10, 20, 30, 45, 60)

    def _execute_with_concurrency_retry(self, token: str, warehouse_id: str, sql_script: str, description: str = "SQL") -> dict:
        """Execute SQL script with retry on Delta concurrency conflicts."""
        import time, random
        max_retries = 1 + len(self._RETRY_DELAYS)
        for attempt in range(max_retries):
            try:
                sql_service = DataSetSQLService(token, warehouse_id)
                return sql_service.execute_sql_script(sql_script)
            except Exception as e:
                err_str = str(e)
                is_retryable = any(marker in err_str for marker in self._CONCURRENT_RETRY_MARKERS)
                if is_retryable and attempt < max_retries - 1:
                    base = self._RETRY_DELAYS[attempt]
                    wait = base + random.uniform(0, base * 0.2)
                    app_logger.warning(
                        f"[retry] {description}: Delta concurrency conflict on "
                        f"attempt {attempt + 1}/{max_retries}; sleeping {wait:.1f}s"
                    )
                    time.sleep(wait)
                else:
                    raise

    def _resolve_survivorship_rules(self, entity_dict: dict) -> list:
        """
        Resolve dataset IDs in survivorship rules to actual table paths.
        Expects entity_dict from entity_data.model_dump() / entity_data.dict().
        """
        # Find default active survivorship rule set
        survivorship_rules = []
        for sr in entity_dict.get('survivorship', []):
            if sr.get('is_default') and sr.get('is_active') and sr.get('rules'):
                survivorship_rules = [dict(r) for r in sr['rules']]
                break

        if not survivorship_rules:
            return []

        # Build dataset_id → path mapping
        dataset_id_to_path = {}
        for dm in entity_dict.get('dataset_mappings', []):
            ds = dm.get('dataset', {})
            if ds.get('id') is not None and ds.get('path'):
                dataset_id_to_path[ds['id']] = ds['path']

        # Resolve Source System strategyRule dataset IDs to paths
        for rule in survivorship_rules:
            if rule.get('strategy') == 'Source System' and isinstance(rule.get('strategyRule'), list):
                rule['strategyRule'] = [
                    dataset_id_to_path.get(did)
                    for did in rule['strategyRule']
                    if dataset_id_to_path.get(did) is not None
                ]

        return survivorship_rules

    def _build_complete_attr_mapping_sql(
        self, attributes: list, json_var: str, unified_tbl: str, master_id: str
    ) -> str:
        """
        Build SQL expression returning ARRAY<STRUCT<attribute_name, attribute_value, source>>
        that includes ALL entity attributes — not just the non-null ones from the UDF.

        The survivorship UDF only emits mappings for attributes with non-null values.
        This supplements the UDF output with null-valued attributes, assigning the
        first contributor's source_path as their source (matching notebook behavior).
        """
        attr_names = [a['name'] for a in attributes]
        attr_list = ", ".join(f"'{name}'" for name in attr_names)
        mapping_schema = "ARRAY<STRUCT<attribute_name:STRING, attribute_value:STRING, source:STRING>>"
        mapping_expr = f"from_json({json_var}:resultant_master_attribute_source_mapping, '{mapping_schema}')"

        return f"""(
    SELECT collect_list(named_struct(
      'attribute_name', all_attrs.attr_name,
      'attribute_value', all_attrs.attr_value,
      'source', all_attrs.attr_source
    ))
    FROM (
      -- Non-null attributes from UDF survivorship output
      SELECT attribute_name AS attr_name, attribute_value AS attr_value, source AS attr_source
      FROM (SELECT inline({mapping_expr}))

      UNION ALL

      -- Null-valued attributes skipped by UDF — assign first contributor's source
      SELECT
        a.attr AS attr_name,
        CAST(NULL AS STRING) AS attr_value,
        (SELECT source_path FROM {unified_tbl}
         WHERE master_lakefusion_id = '{master_id}' LIMIT 1) AS attr_source
      FROM (SELECT explode(array({attr_list})) AS attr) a
      WHERE a.attr NOT IN (
        SELECT attribute_name FROM (SELECT inline({mapping_expr}))
      )
    ) all_attrs
  )"""

    def _fetch_steward_decision_snapshots(self, token: str, warehouse_id: str, entity_name: str,
                                           master_id: str, match_id: str, attr_names: list,
                                           is_master_to_master: bool = False) -> tuple:
        """Fetch master and match record attributes before a stewardship operation.
        Returns (master_attrs_dict, match_attrs_dict). Either may be empty dict if not found."""
        try:
            sql_service = DataSetSQLService(token, warehouse_id)
            master_table = f"{self.catalog_name}.gold.{entity_name}_master_prod"
            unified_table = f"{self.catalog_name}.silver.{entity_name}_unified_prod"
            cols_sql = ", ".join(attr_names)

            if is_master_to_master:
                script = (
                    f"BEGIN SELECT lakefusion_id AS _lookup_key, "
                    f"CASE WHEN lakefusion_id = '{master_id}' THEN 'master' ELSE 'match' END AS _record_type, "
                    f"{cols_sql} FROM {master_table} "
                    f"WHERE lakefusion_id IN ('{master_id}', '{match_id}'); END"
                )
            else:
                parts = [
                    f"SELECT lakefusion_id AS _lookup_key, 'master' AS _record_type, {cols_sql} "
                    f"FROM {master_table} WHERE lakefusion_id = '{master_id}'"
                ]
                if match_id:
                    parts.append(
                        f"SELECT surrogate_key AS _lookup_key, 'match' AS _record_type, {cols_sql} "
                        f"FROM {unified_table} WHERE surrogate_key = '{match_id}'"
                    )
                script = f"BEGIN SELECT * FROM ({' UNION ALL '.join(parts)}); END"

            result = sql_service.execute_sql_script(script)
            master_attrs = {}
            match_attrs = {}
            for row in (result.get("result") or []):
                record_type = row.pop("_record_type", None)
                row.pop("_lookup_key", None)
                if record_type == "master":
                    master_attrs = row
                elif record_type == "match":
                    match_attrs = row
            return master_attrs, match_attrs
        except Exception as e:
            app_logger.warning(f"Could not fetch steward decision snapshots: {e}")
            return {}, {}

    def _update_golden_dedup_after_unmerge_sql(
        self, token: str, warehouse_id: str, entity_name: str,
        survivor_id: str, unmerged_sks: list, attr_names: list,
    ):
        """Update golden dedup potential_match_deduplicate table after unmerge via SQL warehouse."""
        catalog = self.catalog_name
        master_table = f"{catalog}.gold.{entity_name}_master"
        unified_table = f"{catalog}.silver.{entity_name}_unified"
        pm_dedup_table = f"{catalog}.gold.{entity_name}_master_potential_match_deduplicate"
        ma_table = f"{master_table}_merge_activities"

        sql_service = DataSetSQLService(token, warehouse_id)

        # Check if golden dedup table exists
        try:
            sql_service.execute_sql_script(f"SELECT 1 FROM {pm_dedup_table} LIMIT 1")
        except Exception:
            app_logger.info("Golden dedup table does not exist, skipping health update")
            return

        # Find affected merged masters
        sk_list_sql = ", ".join(f"'{sk}'" for sk in unmerged_sks)
        affected_sql = f"""
        SELECT DISTINCT ma.master_id AS original_master
        FROM {ma_table} ma
        WHERE ma.match_id IN ({sk_list_sql})
          AND ma.action_type IN ('JOB_INSERT','JOB_MERGE','MANUAL_MERGE','INITIAL_LOAD')
          AND ma.master_id != '{survivor_id}'
          AND ma.master_id NOT IN (SELECT lakefusion_id FROM {master_table})
        """
        affected_result = sql_service.execute_sql_script(affected_sql)
        affected_masters = []
        if affected_result and affected_result.get("data"):
            affected_masters = [row[0] for row in affected_result["data"]]

        if not affected_masters:
            app_logger.info("No affected merged masters found in golden dedup, skipping")
            return

        app_logger.info(f"Golden dedup health: affected merged masters: {affected_masters}")

        for merged_master_id in affected_masters:
            health_sql = f"""
            WITH source_records AS (
                SELECT DISTINCT ma.match_id AS source_sk
                FROM {ma_table} ma
                WHERE ma.master_id = '{merged_master_id}'
                  AND ma.action_type IN ('JOB_INSERT','JOB_MERGE','MANUAL_MERGE','INITIAL_LOAD')
                  AND ma.match_id LIKE 'sk_%'
            )
            SELECT
                COUNT(DISTINCT sr.source_sk) AS total,
                COUNT(DISTINCT CASE
                    WHEN u.master_lakefusion_id = '{survivor_id}' AND u.record_status != 'DELETED'
                    THEN sr.source_sk END) AS remaining
            FROM source_records sr
            LEFT JOIN {unified_table} u ON u.surrogate_key = sr.source_sk -- unified_id_key is always surrogate_key in SQL stewardship path
            """
            health_result = sql_service.execute_sql_script(health_sql)
            if not health_result or not health_result.get("data"):
                continue

            total = int(health_result["data"][0][0])
            remaining = int(health_result["data"][0][1])
            app_logger.info(f"Golden dedup health: {merged_master_id} remaining={remaining}, total={total}")

            if total == 0:
                continue
            elif remaining == 0:
                app_logger.info(f"Golden dedup health: fully unmerged — removing {merged_master_id}")
                filter_sql = f"""
                UPDATE {pm_dedup_table}
                SET potential_matches = FILTER(potential_matches, x -> x.lakefusion_id != '{merged_master_id}')
                WHERE lakefusion_id = '{survivor_id}'
                """
                sql_service.execute_sql_script(filter_sql)
            elif remaining < total:
                app_logger.info(f"Golden dedup health: partial merge — updating {merged_master_id} ({remaining}/{total})")
                struct_parts = []
                for attr in attr_names:
                    struct_parts.append(f"'{attr}', x.{attr}")
                struct_parts.extend([
                    "'__score__', x.__score__",
                    "'__reason__', x.__reason__",
                    "'lakefusion_id', x.lakefusion_id",
                    "'__mergestatus__', 'MASTER_PARTIAL_MERGE'",
                    f"'__merge_remaining__', CAST({remaining} AS STRING)",
                    f"'__merge_total__', CAST({total} AS STRING)",
                    "'__attributes_combined__', x.__attributes_combined__",
                ])
                ns = f"named_struct({', '.join(struct_parts)})"
                transform_sql = f"""
                UPDATE {pm_dedup_table}
                SET potential_matches = TRANSFORM(potential_matches, x ->
                    IF(x.lakefusion_id = '{merged_master_id}', {ns}, x))
                WHERE lakefusion_id = '{survivor_id}'
                """
                sql_service.execute_sql_script(transform_sql)
            else:
                app_logger.info(f"Golden dedup health: still fully merged ({remaining}/{total}), no update")

    def _write_steward_decision(self, token: str, warehouse_id: str, entity_name: str,
                                 entity_id: int, action_type: str, master_id: str, match_id: str,
                                 master_attrs: dict, match_attrs: dict, created_by: str = ""):
        """Write pre-captured snapshots to steward_decisions Delta table via SQL warehouse."""
        import uuid
        import json as _json

        try:
            sql_service = DataSetSQLService(token, warehouse_id)
            decisions_table = f"{self.catalog_name}.silver.{entity_name}_steward_decisions"
            _sql_esc = lambda v: "'" + str(v).replace("'", "''") + "'" if v else 'NULL'

            to_str = lambda d: {k: str(v) if v is not None else None for k, v in d.items()}
            m_json = _json.dumps(to_str(master_attrs)) if master_attrs else None
            r_json = _json.dumps(to_str(match_attrs)) if match_attrs else None
            decision_id = str(uuid.uuid4()).replace("-", "")

            sql_service.execute_sql_script(
                f"BEGIN "
                f"CREATE TABLE IF NOT EXISTS {decisions_table} ("
                f"decision_id STRING, entity_id STRING, action_type STRING, master_id STRING, match_id STRING, "
                f"reason STRING, reason_category STRING, master_record_attributes STRING, match_record_attributes STRING, "
                f"master_record_source STRING, match_record_source STRING, steward STRING, decided_at TIMESTAMP, aml_status STRING"
                f") USING DELTA; "
                f"INSERT INTO {decisions_table} VALUES ("
                f"'{decision_id}', '{entity_id}', '{action_type}', '{master_id}', '{match_id}', "
                f"NULL, NULL, {_sql_esc(m_json)}, {_sql_esc(r_json)}, "
                f"NULL, NULL, {_sql_esc(created_by)}, current_timestamp(), 'PENDING'"
                f"); END"
            )
            app_logger.info(f"Steward decision written for {action_type} master={master_id}")
        except Exception as e:
            app_logger.warning(f"Could not write steward decision: {e}")

    def _master_has_embedding_col(self, token: str, warehouse_id: str, entity_name: str, experiment: str = 'prod') -> bool:
        """Detect whether the master table carries `attributes_combined_embedding`.

        Precomputed-mode experiments have the column; managed-mode experiments don't.
        Used to gate the `attributes_combined_embedding = NULL` clause that stewardship
        SQL scripts must emit alongside any `attributes_combined` rewrite.

        Tries `information_schema.columns` first (standard, single round-trip), falls
        back to `DESCRIBE TABLE` if metastore-level grants block the first path.
        DESCRIBE TABLE only needs read access to the table itself, which the caller
        already has since the same flow is about to write to it.

        On total failure returns False — precomputed-mode embeddings would then go
        stale. Logs at error level so the operator sees it.

        Result is cached per (entity_name, experiment) for the service-instance
        lifetime so a single request making multiple stewardship calls against the
        same entity (e.g. Merge All) only pays one warehouse round-trip.
        """
        cache_key = (entity_name, experiment)
        if cache_key in self._embedding_col_cache:
            return self._embedding_col_cache[cache_key]

        table_name = f"{entity_name}_master_{experiment}"
        # Backtick-quote the identifier path so an apostrophe in entity_name (e.g. O'Brien)
        # can't break out of the identifier. Backticks inside an identifier are escaped by
        # doubling them. Apply the same treatment to catalog_name for consistency, even
        # though Unity Catalog naming rules currently disallow backticks in catalog names.
        catalog_quoted = self.catalog_name.replace("`", "``")
        master_tbl_quoted = (
            f"`{catalog_quoted}`.`gold`.`{table_name.replace('`', '``')}`"
        )
        # Single-quote-escape the string literal used in information_schema.
        table_name_escaped = table_name.replace("'", "''")

        has_col: bool
        try:
            sql_service = DataSetSQLService(token, warehouse_id)
            result = sql_service.execute_sql_script(
                f"BEGIN SELECT column_name FROM `{catalog_quoted}`.information_schema.columns "
                f"WHERE table_schema = 'gold' "
                f"  AND table_name = '{table_name_escaped}' "
                f"  AND lower(column_name) = 'attributes_combined_embedding'; END"
            )
            has_col = len(result.get("result") or []) > 0
            self._embedding_col_cache[cache_key] = has_col
            return has_col
        except Exception as e:
            app_logger.warning(
                f"information_schema lookup failed for {master_tbl_quoted}, falling back to DESCRIBE TABLE: {e}"
            )

        try:
            sql_service = DataSetSQLService(token, warehouse_id)
            result = sql_service.execute_sql_script(
                f"BEGIN SELECT col_name FROM (DESCRIBE TABLE {master_tbl_quoted}) "
                f"WHERE lower(col_name) = 'attributes_combined_embedding'; END"
            )
            has_col = len(result.get("result") or []) > 0
            self._embedding_col_cache[cache_key] = has_col
            return has_col
        except Exception as e:
            app_logger.error(
                f"Both information_schema and DESCRIBE TABLE failed for {master_tbl_quoted}: {e}. "
                f"Embedding invalidation will be skipped — precomputed-mode embeddings may go stale."
            )
            # Don't cache failures — let the next call retry in case the warehouse
            # was transiently unavailable.
            return False

    def build_merge_sql_script(
        self,
        catalog: str,
        entity_name: str,
        experiment: str,
        master_id: str,
        surrogate_keys: list,
        attributes: list,
        survivorship_rules: list,
        created_by: str,
        has_embedding_col: bool = False
    ) -> str:
        """Build a BEGIN...END SQL script for the merge stewardship operation."""

        # Table names
        master_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}"
        unified_tbl = f"{catalog}.silver.{entity_name}_unified_{experiment}"
        activities_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_merge_activities"
        attrsrc_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_attribute_version_sources"

        # Dynamic column fragments
        col_list = ", ".join(a['name'] for a in attributes)
        struct_fields = ", ".join(
            f"CAST({a['name']} AS STRING) AS {a['name']}" for a in attributes
        )
        json_extracts = ",\n      ".join(
            f"CAST(get_json_object(v_json, '$.resultant_record.{a['name']}') AS {a['type']}) AS {a['name']}"
            for a in attributes
        )
        merge_set = ",\n      ".join(
            f"t.{a['name']} = s.{a['name']}" for a in attributes
        )
        # COALESCE so NULL attributes become '' — concat_ws would otherwise skip them
        # and collapse separators, producing a different attributes_combined than the
        # rest of the pipeline (which uses coalesce(...cast..., lit("")) — see
        # dbx_pipeline_artifacts/src/integration-core/normal_deduplication/Manual_Merge.py).
        concat_fields = ", ".join(
            f"COALESCE(CAST(s.{a['name']} AS STRING), '')" for a in attributes
        )

        # When attributes_combined is rewritten the precomputed embedding becomes stale.
        # Compute_Embeddings.py only refills rows where the embedding IS NULL, so we must
        # invalidate it here. Gate on column presence — managed-mode tables lack it.
        embedding_null_set = ",\n      t.attributes_combined_embedding = NULL" if has_embedding_col else ""

        # Escape single quotes in JSON strings for SQL embedding
        sk_json = json.dumps(surrogate_keys).replace("'", "''")
        rules_json = json.dumps(survivorship_rules).replace("'", "''")
        attrs_json = json.dumps([a['name'] for a in attributes]).replace("'", "''")
        dtypes_json = json.dumps({a['name']: a['type'] for a in attributes}).replace("'", "''")
        created_by_escaped = created_by.replace("'", "''")

        sql = f"""-- =====================================================================
-- STEWARDSHIP MERGE — Dynamic SQL Script
-- Entity:    {entity_name}
-- Master:    {master_id}
-- Merging:   {', '.join(surrogate_keys)}
-- Triggered: {created_by}
-- =====================================================================
BEGIN
  DECLARE v_master_exists INT;
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;
  DECLARE v_json STRING;

  -- [1] Validate master exists + get current version
  SET v_master_exists = (SELECT COUNT(*) FROM {master_tbl} WHERE lakefusion_id = '{master_id}');

  IF v_master_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Master record not found: {master_id}';
  END IF;

  SET v_max_version = (SELECT COALESCE(MAX(version), 0) FROM {activities_tbl} WHERE master_id = '{master_id}');
  SET v_new_version = v_max_version + 1;

  -- [2] Collect contributors + apply survivorship UDF
  SET v_json = (
    SELECT {catalog}.metadata.survivorship_apply(
      records_json,
      '{rules_json}',
      '{attrs_json}',
      '{dtypes_json}',
      'surrogate_key'
    )
    FROM (
      SELECT to_json(collect_list(struct(
        surrogate_key AS surrogate_key,
        source_path AS source_path,
        {struct_fields}
      ))) AS records_json
      FROM {unified_tbl}
      WHERE (master_lakefusion_id = '{master_id}' AND record_status = 'MERGED')
         OR (surrogate_key IN (SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>'))) AND record_status = 'ACTIVE')
    )
  );

  -- [3] Update master table with survived attributes
  MERGE INTO {master_tbl} AS t
  USING (
    SELECT
      '{master_id}' AS lakefusion_id,
      {json_extracts}
  ) AS s ON t.lakefusion_id = s.lakefusion_id
  WHEN MATCHED THEN UPDATE SET
      {merge_set},
      t.attributes_combined = concat_ws(' | ', {concat_fields}){embedding_null_set};

  -- [4] Insert attribute version sources (include null-valued attributes with source)
  INSERT INTO {attrsrc_tbl} (lakefusion_id, version, attribute_source_mapping)
  SELECT
    '{master_id}',
    v_new_version,
    {self._build_complete_attr_mapping_sql(attributes, 'v_json', unified_tbl, master_id)};

  -- [5] Log merge activities
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    '{master_id}',
    sk.col1,
    (SELECT source_path FROM {unified_tbl} WHERE surrogate_key = sk.col1 LIMIT 1),
    v_new_version,
    'MANUAL_MERGE',
    current_timestamp()
  FROM (SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>')) AS col1) sk;

  -- [6] Mark unified records as MERGED
  MERGE INTO {unified_tbl} AS t
  USING (SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>')) AS sk) AS s
  ON t.surrogate_key = s.sk
  WHEN MATCHED THEN UPDATE SET
    t.master_lakefusion_id = '{master_id}',
    t.record_status = 'MERGED';

  -- Return new version
  SELECT v_new_version AS new_version;
END"""
        return sql

    def build_golden_dedup_merge_sql_script(
        self,
        catalog: str,
        entity_name: str,
        experiment: str,
        master_id: str,
        match_record_id: str,
        attributes: list,
        survivorship_rules: list,
        created_by: str,
        action_type: str = 'MASTER_MANUAL_MERGE',
        has_embedding_col: bool = False
    ) -> str:
        """Build a BEGIN...END SQL script for the golden deduplication merge (master-to-master)."""

        # Table names
        master_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}"
        unified_tbl = f"{catalog}.silver.{entity_name}_unified_{experiment}"
        activities_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_merge_activities"
        attrsrc_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_attribute_version_sources"

        # Dynamic column fragments (same as normal merge)
        struct_fields = ", ".join(
            f"CAST({a['name']} AS STRING) AS {a['name']}" for a in attributes
        )
        json_extracts = ",\n      ".join(
            f"CAST(get_json_object(v_json, '$.resultant_record.{a['name']}') AS {a['type']}) AS {a['name']}"
            for a in attributes
        )
        merge_set = ",\n      ".join(
            f"t.{a['name']} = s.{a['name']}" for a in attributes
        )
        # COALESCE preserves NULL positions as empty strings between separators.
        concat_fields = ", ".join(
            f"COALESCE(CAST(s.{a['name']} AS STRING), '')" for a in attributes
        )

        # Invalidate stale precomputed embedding when attributes_combined is rewritten.
        embedding_null_set = ",\n      t.attributes_combined_embedding = NULL" if has_embedding_col else ""

        rules_json = json.dumps(survivorship_rules).replace("'", "''")
        attrs_json = json.dumps([a['name'] for a in attributes]).replace("'", "''")
        dtypes_json = json.dumps({a['name']: a['type'] for a in attributes}).replace("'", "''")
        created_by_escaped = created_by.replace("'", "''")

        sql = f"""-- =====================================================================
-- STEWARDSHIP GOLDEN DEDUP MERGE — Dynamic SQL Script (Master-to-Master)
-- Entity:    {entity_name}
-- Survivor:  {master_id}
-- Absorbed:  {match_record_id}
-- Triggered: {created_by}
-- =====================================================================
BEGIN
  DECLARE v_survivor_exists INT;
  DECLARE v_absorbed_exists INT;
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;
  DECLARE v_json STRING;

  -- [1] Validate both masters exist
  SET v_survivor_exists = (SELECT COUNT(*) FROM {master_tbl} WHERE lakefusion_id = '{master_id}');
  SET v_absorbed_exists = (SELECT COUNT(*) FROM {master_tbl} WHERE lakefusion_id = '{match_record_id}');

  IF v_survivor_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Survivor master not found: {master_id}';
  END IF;
  IF v_absorbed_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Absorbed master not found: {match_record_id}';
  END IF;

  SET v_max_version = (SELECT COALESCE(MAX(version), 0) FROM {activities_tbl} WHERE master_id = '{master_id}');
  SET v_new_version = v_max_version + 1;

  -- [2] Collect ALL contributors from both masters + apply survivorship
  SET v_json = (
    SELECT {catalog}.metadata.survivorship_apply(
      records_json,
      '{rules_json}',
      '{attrs_json}',
      '{dtypes_json}',
      'surrogate_key'
    )
    FROM (
      SELECT to_json(collect_list(struct(
        surrogate_key AS surrogate_key,
        source_path AS source_path,
        {struct_fields}
      ))) AS records_json
      FROM {unified_tbl}
      WHERE master_lakefusion_id IN ('{master_id}', '{match_record_id}')
        AND record_status = 'MERGED'
    )
  );

  -- [3] Update survivor master with survived attributes
  MERGE INTO {master_tbl} AS t
  USING (
    SELECT
      '{master_id}' AS lakefusion_id,
      {json_extracts}
  ) AS s ON t.lakefusion_id = s.lakefusion_id
  WHEN MATCHED THEN UPDATE SET
      {merge_set},
      t.attributes_combined = concat_ws(' | ', {concat_fields}){embedding_null_set};

  -- [4] Delete absorbed master
  DELETE FROM {master_tbl} WHERE lakefusion_id = '{match_record_id}';

  -- [5] Reassign absorbed master's unified contributors to survivor
  MERGE INTO {unified_tbl} AS t
  USING (SELECT '{match_record_id}' AS old_master) AS s
  ON t.master_lakefusion_id = s.old_master AND t.record_status = 'MERGED'
  WHEN MATCHED THEN UPDATE SET
    t.master_lakefusion_id = '{master_id}';

  -- [6] Insert attribute version sources (include null-valued attributes with source)
  INSERT INTO {attrsrc_tbl} (lakefusion_id, version, attribute_source_mapping)
  SELECT
    '{master_id}',
    v_new_version,
    {self._build_complete_attr_mapping_sql(attributes, 'v_json', unified_tbl, master_id)};

  -- [7] Log merge activity
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    '{master_id}',
    '{match_record_id}',
    'MASTER_MERGE',
    v_new_version,
    '{action_type}',
    current_timestamp();

  -- Return new version
  SELECT v_new_version AS new_version;
END"""
        return sql

    def build_unmerge_sql_script(
        self,
        catalog: str,
        entity_name: str,
        experiment: str,
        master_id: str,
        surrogate_keys: list,
        attributes: list,
        survivorship_rules: list,
        created_by: str,
        has_embedding_col: bool = False
    ) -> str:
        """Build a BEGIN...END SQL script for the unmerge stewardship operation.

        Maps to the 13-step ManualUnmergeExecutor:
        1. Validate master exists
        2-4. Count contributors, validate, separate remaining vs unmerge
        5-6. Apply survivorship UDF on remaining contributors → update master
        7. Generate new lakefusion_ids for unmerged records
        8-9. Insert new masters for unmerged records + update existing master
        10-11. Insert attribute version sources for both
        12. Log merge activities (MANUAL_UNMERGE + JOB_INSERT)
        13. Update unified table (remap master_lakefusion_id)
        """

        # Table names
        master_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}"
        unified_tbl = f"{catalog}.silver.{entity_name}_unified_{experiment}"
        activities_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_merge_activities"
        attrsrc_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_attribute_version_sources"

        # Dynamic column fragments
        struct_fields = ", ".join(
            f"CAST({a['name']} AS STRING) AS {a['name']}" for a in attributes
        )
        json_extracts = ",\n      ".join(
            f"CAST(get_json_object(v_json, '$.resultant_record.{a['name']}') AS {a['type']}) AS {a['name']}"
            for a in attributes
        )
        merge_set = ",\n      ".join(
            f"t.{a['name']} = s.{a['name']}" for a in attributes
        )
        # COALESCE preserves NULL positions as empty strings between separators.
        concat_fields = ", ".join(
            f"COALESCE(CAST(s.{a['name']} AS STRING), '')" for a in attributes
        )

        # Cast expressions for unmerge records → master insert (from unified columns)
        unmerge_select_cols = ", ".join(
            f"CAST(u.{a['name']} AS {a['type']}) AS {a['name']}" for a in attributes
        )
        # For attributes_combined on unmerge inserts — same NULL-position safety.
        unmerge_concat = ", ".join(
            f"COALESCE(CAST(u.{a['name']} AS STRING), '')" for a in attributes
        )
        # Explicit column list for INSERT (avoids DELTA_MERGE_UNRESOLVED_EXPRESSION
        # when master table has extra columns like attributes_combined_embedding).
        # When the master carries attributes_combined_embedding, include it explicitly
        # as NULL so Compute_Embeddings.py refills it on the next pipeline run.
        insert_cols = "lakefusion_id, " + ", ".join(a['name'] for a in attributes) + ", attributes_combined"
        insert_values_attrs = ", ".join(f"s.{a['name']}" for a in attributes)
        if has_embedding_col:
            insert_cols += ", attributes_combined_embedding"
            insert_embedding_value = ", CAST(NULL AS ARRAY<FLOAT>)"
        else:
            insert_embedding_value = ""

        # When attributes_combined is rewritten the precomputed embedding becomes stale.
        embedding_null_set = ",\n      t.attributes_combined_embedding = NULL" if has_embedding_col else ""

        # Escape single quotes in JSON strings for SQL embedding
        sk_json = json.dumps(surrogate_keys).replace("'", "''")
        rules_json = json.dumps(survivorship_rules).replace("'", "''")
        attrs_json = json.dumps([a['name'] for a in attributes]).replace("'", "''")
        dtypes_json = json.dumps({a['name']: a['type'] for a in attributes}).replace("'", "''")
        created_by_escaped = created_by.replace("'", "''")

        # Build the per-unmerge-record INSERT for new masters + attr version sources + activities
        # Generate new lakefusion_ids in Python (uuid4 without dashes — same as generate_lakefusion_id())
        import uuid as _uuid
        sk_to_new_id = {}
        for sk in surrogate_keys:
            sk_to_new_id[sk] = str(_uuid.uuid4()).replace("-", "")

        # Build VALUES clause for surrogate_key → new_lakefusion_id mapping temp table
        mapping_values = ", ".join(
            f"('{sk}', '{new_id}')" for sk, new_id in sk_to_new_id.items()
        )

        sql = f"""-- =====================================================================
-- STEWARDSHIP UNMERGE — Dynamic SQL Script
-- Entity:    {entity_name}
-- Master:    {master_id}
-- Unmerging: {', '.join(surrogate_keys)}
-- Triggered: {created_by}
-- =====================================================================
BEGIN
  DECLARE v_master_exists INT;
  DECLARE v_total_contributors INT;
  DECLARE v_unmerge_count INT;
  DECLARE v_remaining_count INT;
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;
  DECLARE v_json STRING;

  -- [1] Validate master exists
  SET v_master_exists = (SELECT COUNT(*) FROM {master_tbl} WHERE lakefusion_id = '{master_id}');
  IF v_master_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Master record not found: {master_id}';
  END IF;

  -- [2] Count total contributors and validate
  SET v_total_contributors = (
    SELECT COUNT(*) FROM {unified_tbl}
    WHERE master_lakefusion_id = '{master_id}' AND record_status = 'MERGED'
  );

  SET v_unmerge_count = (
    SELECT COUNT(*) FROM {unified_tbl}
    WHERE master_lakefusion_id = '{master_id}'
      AND record_status = 'MERGED'
      AND surrogate_key IN (SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>')))
  );

  SET v_remaining_count = v_total_contributors - v_unmerge_count;

  IF v_unmerge_count = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'None of the specified records are contributors to this master';
  END IF;

  IF v_remaining_count = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot unmerge - would leave master with no contributors';
  END IF;

  -- [3] Create temp mapping of surrogate_key → new_lakefusion_id
  DROP TEMPORARY TABLE IF EXISTS _unmerge_id_map;
  CREATE TEMPORARY TABLE _unmerge_id_map AS
  SELECT col1 AS surrogate_key, col2 AS new_lakefusion_id
  FROM VALUES {mapping_values};

  -- [4] Apply survivorship on REMAINING contributors (exclude unmerge records)
  SET v_json = (
    SELECT {catalog}.metadata.survivorship_apply(
      records_json,
      '{rules_json}',
      '{attrs_json}',
      '{dtypes_json}',
      'surrogate_key'
    )
    FROM (
      SELECT to_json(collect_list(struct(
        surrogate_key AS surrogate_key,
        source_path AS source_path,
        {struct_fields}
      ))) AS records_json
      FROM {unified_tbl}
      WHERE master_lakefusion_id = '{master_id}'
        AND record_status = 'MERGED'
        AND surrogate_key NOT IN (SELECT surrogate_key FROM _unmerge_id_map)
    )
  );

  -- [5] Get next version
  SET v_max_version = (SELECT MAX(version) FROM (DESCRIBE HISTORY {master_tbl} LIMIT 1));
  SET v_new_version = v_max_version + 1;

  -- [6] Update existing master with re-survivored values
  MERGE INTO {master_tbl} AS t
  USING (
    SELECT
      '{master_id}' AS lakefusion_id,
      {json_extracts}
  ) AS s ON t.lakefusion_id = s.lakefusion_id
  WHEN MATCHED THEN UPDATE SET
      {merge_set},
      t.attributes_combined = concat_ws(' | ', {concat_fields}){embedding_null_set};

  -- [7] Insert new masters for each unmerged record (promoted to independent master)
  MERGE INTO {master_tbl} AS t
  USING (
    SELECT
      m.new_lakefusion_id AS lakefusion_id,
      {unmerge_select_cols},
      concat_ws(' | ', {unmerge_concat}) AS attributes_combined
    FROM {unified_tbl} u
    INNER JOIN _unmerge_id_map m ON u.surrogate_key = m.surrogate_key
  ) AS s ON t.lakefusion_id = s.lakefusion_id
  WHEN NOT MATCHED THEN INSERT ({insert_cols})
    VALUES (s.lakefusion_id, {insert_values_attrs}, s.attributes_combined{insert_embedding_value});

  -- [8] Insert attribute version sources for updated master (with complete mapping)
  INSERT INTO {attrsrc_tbl} (lakefusion_id, version, attribute_source_mapping)
  SELECT
    '{master_id}',
    v_new_version,
    {self._build_complete_attr_mapping_sql(attributes, 'v_json', unified_tbl, master_id)};

  -- [9] Insert attribute version sources for each unmerged record (single contributor)
  INSERT INTO {attrsrc_tbl} (lakefusion_id, version, attribute_source_mapping)
  SELECT
    m.new_lakefusion_id,
    v_new_version,
    array({", ".join(
        f"named_struct('attribute_name', '{a['name']}', 'attribute_value', CAST(u.{a['name']} AS STRING), 'source', u.source_path)"
        for a in attributes
    )})
  FROM {unified_tbl} u
  INNER JOIN _unmerge_id_map m ON u.surrogate_key = m.surrogate_key;

  -- [10] Log MANUAL_UNMERGE activities (record leaves original master)
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    '{master_id}',
    u.surrogate_key,
    u.source_path,
    v_new_version,
    'MANUAL_UNMERGE',
    current_timestamp()
  FROM {unified_tbl} u
  INNER JOIN _unmerge_id_map m ON u.surrogate_key = m.surrogate_key;

  -- [11] Log JOB_INSERT activities (record promoted to new master)
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    m.new_lakefusion_id,
    u.surrogate_key,
    u.source_path,
    v_new_version,
    'JOB_INSERT',
    current_timestamp()
  FROM {unified_tbl} u
  INNER JOIN _unmerge_id_map m ON u.surrogate_key = m.surrogate_key;

  -- [12] Update unified table — remap unmerged records to new master IDs
  MERGE INTO {unified_tbl} AS t
  USING _unmerge_id_map AS s
  ON t.surrogate_key = s.surrogate_key
  WHEN MATCHED THEN UPDATE SET
    t.master_lakefusion_id = s.new_lakefusion_id;

  -- Return new version and new lakefusion IDs
  SELECT v_new_version AS new_version, to_json(collect_list(struct(surrogate_key, new_lakefusion_id))) AS id_mapping
  FROM _unmerge_id_map;
END"""
        return sql

    def run_unmerge_sql(self, entity_id: int, unmerge_record, token, created_by, warehouse_id: str = None):
        """Execute unmerge via SQL warehouse instead of notebook job."""
        try:
            # Load entity metadata as dict
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            # Get entity attributes (PK first, then rest)
            all_attrs = entity_dict.get('attributes', [])
            pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and a.get('is_primary_key')]
            non_pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and not a.get('is_primary_key')]
            attributes = pk_attrs + non_pk_attrs

            # Resolve survivorship rules (dataset_id → path)
            survivorship_rules = self._resolve_survivorship_rules(entity_dict)

            # Extract surrogate keys
            surrogate_keys = [str(i.id) for i in unmerge_record.unified_dataset_ids]

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots BEFORE the unmerge
            attr_names = [a['name'] for a in attributes]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(unmerge_record.master_id),
                match_id=surrogate_keys[0] if surrogate_keys else None,
                attr_names=attr_names
            )

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            # Build SQL script
            sql_script = self.build_unmerge_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(unmerge_record.master_id),
                surrogate_keys=surrogate_keys,
                attributes=attributes,
                survivorship_rules=survivorship_rules,
                created_by=created_by,
                has_embedding_col=has_embedding_col
            )

            # Execute on SQL warehouse with retry on Delta concurrency conflicts
            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"UNMERGE master={unmerge_record.master_id}"
            )

            # Write steward decision
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id, 'UNMERGE',
                str(unmerge_record.master_id), surrogate_keys[0] if surrogate_keys else "",
                sd_master, sd_match, created_by
            )

            # Update golden dedup health
            try:
                self._update_golden_dedup_after_unmerge_sql(
                    token=token,
                    warehouse_id=warehouse_id,
                    entity_name=entity_name,
                    survivor_id=str(unmerge_record.master_id),
                    unmerged_sks=surrogate_keys,
                    attr_names=attr_names,
                )
            except Exception as gd_err:
                app_logger.warning(f"Golden dedup health update failed (non-fatal): {gd_err}")

            # Store tracking record
            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            entity_search_jobs_list = []
            for i in unmerge_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=str(unmerge_record.master_id),
                    profile_id=str(i.id),
                    operation_type='UNMERGE',
                    job_run_id=None,
                    status=StewardshipJobStatus.QUERY_COMPLETED.value,
                    job_run_status={"execution_type": "query", "result": "success"},
                    created_by=created_by,
                    execution_type='query',
                    query_id=str(query_id)
                )
                self.db.add(entity_search_jobs)
                entity_search_jobs_list.append(entity_search_jobs)

            self.db.commit()
            for job in entity_search_jobs_list:
                self.db.refresh(job)

            return entity_search_jobs_list[0] if entity_search_jobs_list else None

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL stewardship unmerge failed: {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to unmerge records via SQL: {str(e)}"
            )

    def run_match_merge_sql(self, entity_id: int, potential_record, token, created_by, warehouse_id: str = None):
        """Execute merge via SQL warehouse instead of notebook job."""
        try:
            # Load entity metadata as dict
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            # Get entity attributes (PK first, then rest)
            all_attrs = entity_dict.get('attributes', [])
            pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and a.get('is_primary_key')]
            non_pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and not a.get('is_primary_key')]
            attributes = pk_attrs + non_pk_attrs

            # Resolve survivorship rules (dataset_id → path)
            survivorship_rules = self._resolve_survivorship_rules(entity_dict)

            # Extract surrogate keys
            surrogate_keys = [str(i.id) for i in potential_record.unified_dataset_ids]

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots BEFORE the merge
            attr_names = [a['name'] for a in attributes]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(potential_record.master_id),
                match_id=surrogate_keys[0] if surrogate_keys else None,
                attr_names=attr_names
            )

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            # Build SQL script
            sql_script = self.build_merge_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(potential_record.master_id),
                surrogate_keys=surrogate_keys,
                attributes=attributes,
                survivorship_rules=survivorship_rules,
                created_by=created_by,
                has_embedding_col=has_embedding_col
            )

            # Execute on SQL warehouse with retry on Delta concurrency conflicts
            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"MERGE master={potential_record.master_id}"
            )

            # Write steward decision with frozen snapshots
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id,
                potential_record.operation_type or 'MERGE',
                str(potential_record.master_id), surrogate_keys[0] if surrogate_keys else "",
                sd_master, sd_match, created_by
            )

            # Store tracking record
            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            for i in potential_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=str(potential_record.master_id),
                    profile_id=str(i.id),
                    operation_type=potential_record.operation_type or 'MERGE',
                    job_run_id=None,
                    status=StewardshipJobStatus.QUERY_COMPLETED.value,
                    job_run_status={"execution_type": "query", "result": "success"},
                    created_by=created_by,
                    execution_type='query',
                    query_id=str(query_id)
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL stewardship merge failed: {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records via SQL: {str(e)}"
            )

    def run_golden_dedup_merge_sql(self, entity_id: int, potential_record, token, created_by, warehouse_id: str = None):
        """Execute golden deduplication merge (master-to-master) via SQL warehouse."""
        try:
            # Load entity metadata as dict
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            # Get entity attributes (PK first, then rest)
            all_attrs = entity_dict.get('attributes', [])
            pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and a.get('is_primary_key')]
            non_pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and not a.get('is_primary_key')]
            attributes = pk_attrs + non_pk_attrs

            # Resolve survivorship rules (dataset_id → path)
            survivorship_rules = self._resolve_survivorship_rules(entity_dict)

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots BEFORE the merge (both from master table)
            attr_names = [a['name'] for a in attributes]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(potential_record.master_id),
                match_id=str(potential_record.match_record_id),
                attr_names=attr_names, is_master_to_master=True
            )

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            # Build SQL script
            sql_script = self.build_golden_dedup_merge_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(potential_record.master_id),
                match_record_id=str(potential_record.match_record_id),
                attributes=attributes,
                survivorship_rules=survivorship_rules,
                created_by=created_by,
                has_embedding_col=has_embedding_col
            )

            # Execute on SQL warehouse with retry
            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"GOLDEN_MERGE survivor={potential_record.master_id} absorbed={potential_record.match_record_id}"
            )

            # Write steward decision
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id,
                potential_record.operation_type or 'MERGE',
                str(potential_record.master_id), str(potential_record.match_record_id),
                sd_master, sd_match, created_by
            )

            # Store tracking record
            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            entity_search_jobs = Model_Databricks_Entity_Search_Job(
                entity_id=entity_id,
                master_id=str(potential_record.master_id),
                profile_id=str(potential_record.match_record_id),
                operation_type=potential_record.operation_type or 'MERGE',
                job_run_id=None,
                status=StewardshipJobStatus.QUERY_COMPLETED.value,
                job_run_status={"execution_type": "query", "result": "success"},
                created_by=created_by,
                execution_type='query',
                query_id=str(query_id)
            )
            self.db.add(entity_search_jobs)
            self.db.commit()
            self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL golden dedup merge failed: {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge masters via SQL: {str(e)}"
            )

    def build_not_a_match_sql_script(
        self,
        catalog: str,
        entity_name: str,
        experiment: str,
        master_id: str,
        surrogate_keys: list,
        attributes: list,
        created_by: str,
        has_embedding_col: bool = False
    ) -> str:
        """Build a BEGIN...END SQL script for the not-a-match stewardship operation."""

        master_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}"
        unified_tbl = f"{catalog}.silver.{entity_name}_unified_{experiment}"
        activities_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_merge_activities"
        attrsrc_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_attribute_version_sources"
        pm_tbl = f"{catalog}.gold.{entity_name}_master_potential_match_{experiment}"

        col_list = ", ".join(a['name'] for a in attributes)
        # COALESCE preserves NULL positions as empty strings between separators.
        concat_fields = ", ".join(f"COALESCE(CAST({a['name']} AS STRING), '')" for a in attributes)
        concat_fields_nm = ", ".join(f"COALESCE(CAST(nm.{a['name']} AS STRING), '')" for a in attributes)
        # Explicit column list for INSERT (avoids DELTA_MERGE_UNRESOLVED_EXPRESSION
        # when master table has extra columns like attributes_combined_embedding).
        # When the master carries attributes_combined_embedding, include it explicitly
        # as NULL so Compute_Embeddings.py refills it on the next pipeline run.
        insert_cols = "lakefusion_id, " + ", ".join(a['name'] for a in attributes) + ", attributes_combined"
        insert_values_attrs = ", ".join(f"s.{a['name']}" for a in attributes)
        if has_embedding_col:
            insert_cols += ", attributes_combined_embedding"
            insert_embedding_value = ", CAST(NULL AS ARRAY<FLOAT>)"
        else:
            insert_embedding_value = ""

        sk_json = json.dumps(surrogate_keys).replace("'", "''")
        created_by_escaped = created_by.replace("'", "''")

        sql = f"""-- =====================================================================
-- STEWARDSHIP NOT-A-MATCH — Dynamic SQL Script
-- Entity:    {entity_name}
-- Master:    {master_id}
-- Rejecting: {', '.join(surrogate_keys)}
-- Triggered: {created_by}
-- =====================================================================
BEGIN
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;
  DECLARE v_records_without_other_matches INT;

  -- [1] Get current version
  SET v_max_version = (SELECT COALESCE(MAX(version), 0) FROM {activities_tbl} WHERE master_id = '{master_id}');
  SET v_new_version = v_max_version + 1;

  -- [2] Log MANUAL_NOT_A_MATCH activities
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    '{master_id}',
    sk.col1,
    (SELECT source_path FROM {unified_tbl} WHERE surrogate_key = sk.col1 LIMIT 1),
    v_new_version,
    'MANUAL_NOT_A_MATCH',
    current_timestamp()
  FROM (SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>')) AS col1) sk;

  -- [3] Check which rejected records have OTHER pending matches on other masters
  CREATE OR REPLACE TEMPORARY VIEW _rejected_keys AS
  SELECT explode(from_json('{sk_json}', 'ARRAY<STRING>')) AS surrogate_key;

  -- Find records that have other PENDING matches (excluding current master)
  CREATE OR REPLACE TEMPORARY VIEW _with_other_matches AS
  SELECT DISTINCT pm_match.surrogate_key
  FROM {pm_tbl} pm
  LATERAL VIEW explode(pm.potential_matches) AS pm_match
  WHERE pm_match.__mergestatus__ = 'PENDING'
    AND pm_match.surrogate_key IN (SELECT surrogate_key FROM _rejected_keys)
    AND pm.lakefusion_id != '{master_id}';

  -- Records WITHOUT other matches → need to be promoted to their own master
  -- This is the stable "should promote" set — doesn't change on retry
  CREATE OR REPLACE TEMPORARY VIEW _to_promote AS
  SELECT rk.surrogate_key
  FROM _rejected_keys rk
  LEFT JOIN _with_other_matches wom ON rk.surrogate_key = wom.surrogate_key
  WHERE wom.surrogate_key IS NULL;

  -- Also filter out records already merged via merge_activities (JOB_MERGE/MANUAL_MERGE means already absorbed)
  CREATE OR REPLACE TEMPORARY VIEW _promotable AS
  SELECT tp.surrogate_key
  FROM _to_promote tp
  LEFT JOIN (
    SELECT DISTINCT match_id FROM {activities_tbl}
    WHERE action_type IN ('JOB_MERGE', 'MANUAL_MERGE') AND match_id IS NOT NULL AND match_id != ''
  ) ma ON tp.surrogate_key = ma.match_id
  WHERE ma.match_id IS NULL;

  SET v_records_without_other_matches = (SELECT COUNT(*) FROM _promotable);

  -- [4] If records need promotion, run all steps idempotently
  IF v_records_without_other_matches > 0 THEN

    -- Generate new lakefusion_ids — materialized as temp table so UUID is stable across all references
    -- (On retry, if unified already has master_lakefusion_id assigned, reuse it)
    DROP TABLE IF EXISTS _new_masters;
    CREATE TEMPORARY TABLE _new_masters AS
    SELECT
      p.surrogate_key,
      CASE WHEN u.master_lakefusion_id IS NOT NULL AND u.master_lakefusion_id != '' THEN u.master_lakefusion_id ELSE replace(uuid(), '-', '') END AS new_lakefusion_id,
      u.source_path,
      {', '.join(f"u.{a['name']}" for a in attributes)}
    FROM _promotable p
    INNER JOIN {unified_tbl} u ON p.surrogate_key = u.surrogate_key;

    -- Insert into master table (idempotent — WHEN NOT MATCHED skips existing)
    MERGE INTO {master_tbl} AS t
    USING (
      SELECT
        nm.new_lakefusion_id AS lakefusion_id,
        {col_list},
        concat_ws(' | ', {concat_fields_nm}) AS attributes_combined
      FROM _new_masters nm
    ) AS s ON t.lakefusion_id = s.lakefusion_id
    WHEN NOT MATCHED THEN INSERT ({insert_cols})
      VALUES (s.lakefusion_id, {insert_values_attrs}, s.attributes_combined{insert_embedding_value});

    -- Update unified table: assign new master and mark as MERGED
    -- (idempotent — if already MERGED with correct master, no change)
    MERGE INTO {unified_tbl} AS t
    USING _new_masters AS s
    ON t.surrogate_key = s.surrogate_key
    WHEN MATCHED AND (t.record_status != 'MERGED' OR t.master_lakefusion_id IS NULL OR t.master_lakefusion_id = '') THEN UPDATE SET
      t.master_lakefusion_id = s.new_lakefusion_id,
      t.record_status = 'MERGED';

    -- Log JOB_INSERT activities (idempotent — use MERGE to avoid duplicates)
    MERGE INTO {activities_tbl} AS t
    USING (
      SELECT
        nm.new_lakefusion_id AS master_id,
        nm.surrogate_key AS match_id,
        nm.source_path AS source,
        v_new_version AS version,
        'JOB_INSERT' AS action_type,
        current_timestamp() AS created_at
      FROM _new_masters nm
    ) AS s
    ON t.master_id = s.master_id AND t.match_id = s.match_id AND t.action_type = 'JOB_INSERT'
    WHEN NOT MATCHED THEN INSERT *;

    -- Insert attribute version sources (idempotent — MERGE to avoid duplicates)
    MERGE INTO {attrsrc_tbl} AS t
    USING (
      SELECT
        nm.new_lakefusion_id AS lakefusion_id,
        v_new_version AS version,
        array({', '.join(
            f"named_struct('attribute_name', '{a['name']}', 'attribute_value', CAST(nm.{a['name']} AS STRING), 'source', nm.source_path)"
            for a in attributes
        )}) AS attribute_source_mapping
      FROM _new_masters nm
    ) AS s
    ON t.lakefusion_id = s.lakefusion_id AND t.version = s.version
    WHEN NOT MATCHED THEN INSERT *;

  END IF;

  -- Return results
  SELECT v_new_version AS new_version, v_records_without_other_matches AS promoted_count;
END"""
        return sql

    def run_not_a_match_sql(self, entity_id: int, potential_record, token, created_by, warehouse_id: str = None):
        """Execute not-a-match via SQL warehouse instead of notebook job."""
        try:
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            all_attrs = entity_dict.get('attributes', [])
            pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and a.get('is_primary_key')]
            non_pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and not a.get('is_primary_key')]
            attributes = pk_attrs + non_pk_attrs

            surrogate_keys = [str(i.id) for i in potential_record.unified_dataset_ids]

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots BEFORE not-a-match
            attr_names = [a['name'] for a in attributes]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(potential_record.master_id),
                match_id=surrogate_keys[0] if surrogate_keys else None,
                attr_names=attr_names
            )

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            sql_script = self.build_not_a_match_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(potential_record.master_id),
                surrogate_keys=surrogate_keys,
                attributes=attributes,
                created_by=created_by,
                has_embedding_col=has_embedding_col
            )

            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"NOT_A_MATCH master={potential_record.master_id}"
            )

            # Write steward decision
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id, 'NOT_A_MATCH',
                str(potential_record.master_id), surrogate_keys[0] if surrogate_keys else "",
                sd_master, sd_match, created_by
            )

            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            for i in potential_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=str(potential_record.master_id),
                    profile_id=str(i.id),
                    operation_type='NOT_A_MATCH',
                    job_run_id=None,
                    status=StewardshipJobStatus.QUERY_COMPLETED.value,
                    job_run_status={"execution_type": "query", "result": "success"},
                    created_by=created_by,
                    execution_type='query',
                    query_id=str(query_id)
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL not-a-match failed: {message}')
            raise HTTPException(status_code=500, detail=f"Failed to mark as not-a-match via SQL: {str(e)}")

    def build_golden_dedup_not_a_match_sql_script(
        self,
        catalog: str,
        entity_name: str,
        experiment: str,
        master_id: str,
        match_record_id: str,
        created_by: str
    ) -> str:
        """Build SQL script for golden dedup not-a-match (simpler — just log the rejection)."""

        activities_tbl = f"{catalog}.gold.{entity_name}_master_{experiment}_merge_activities"

        sql = f"""-- =====================================================================
-- STEWARDSHIP GOLDEN DEDUP NOT-A-MATCH — Dynamic SQL Script
-- Entity:    {entity_name}
-- Master:    {master_id}
-- Rejected:  {match_record_id}
-- Triggered: {created_by}
-- =====================================================================
BEGIN
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;

  SET v_max_version = (SELECT COALESCE(MAX(version), 0) FROM {activities_tbl} WHERE master_id = '{master_id}');
  SET v_new_version = v_max_version + 1;

  -- Log MANUAL_NOT_A_MATCH activity
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  VALUES ('{master_id}', '{match_record_id}', 'MASTER_NOT_A_MATCH', v_new_version, 'MANUAL_NOT_A_MATCH', current_timestamp());

  SELECT v_new_version AS new_version;
END"""
        return sql

    def run_golden_dedup_not_a_match_sql(self, entity_id: int, potential_record, token, created_by, warehouse_id: str = None):
        """Execute golden dedup not-a-match via SQL warehouse."""
        try:
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots (both from master table)
            all_attrs = entity_dict.get('attributes', [])
            attr_names = [a['name'] for a in all_attrs if a.get('is_active')]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(potential_record.master_id),
                match_id=str(potential_record.match_record_id),
                attr_names=attr_names, is_master_to_master=True
            )

            sql_script = self.build_golden_dedup_not_a_match_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(potential_record.master_id),
                match_record_id=str(potential_record.match_record_id),
                created_by=created_by
            )

            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"GOLDEN_NOT_A_MATCH master={potential_record.master_id}"
            )

            # Write steward decision
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id, 'NOT_A_MATCH',
                str(potential_record.master_id), str(potential_record.match_record_id),
                sd_master, sd_match, created_by
            )

            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            entity_search_jobs = Model_Databricks_Entity_Search_Job(
                entity_id=entity_id,
                master_id=str(potential_record.master_id),
                profile_id=str(potential_record.match_record_id),
                operation_type='NOT_A_MATCH',
                job_run_id=None,
                status=StewardshipJobStatus.QUERY_COMPLETED.value,
                job_run_status={"execution_type": "query", "result": "success"},
                created_by=created_by,
                execution_type='query',
                query_id=str(query_id)
            )
            self.db.add(entity_search_jobs)
            self.db.commit()
            self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL golden dedup not-a-match failed: {message}')
            raise HTTPException(status_code=500, detail=f"Failed golden dedup not-a-match via SQL: {str(e)}")

    # =========================================================================
    # SQL Stewardship: Manual Update (Profile Edit) via SQL Warehouse
    # =========================================================================

    def build_manual_update_sql_script(
        self,
        catalog: str,
        entity_name: str,
        lakefusion_id: str,
        update_attributes: dict,
        entity_attribute_names: list,
        entity_attributes_with_types: list,
        created_by: str,
        has_embedding_col: bool = False
    ) -> str:
        """Build a BEGIN...END SQL script for manual profile update.

        Maps to the 6-step Manual_Update.py notebook:
        1. Validate master exists
        2. Get current attribute source mapping (latest version)
        3. Update master table (changed attrs + attributes_combined)
        4. Insert attribute version sources (MANUAL_UPDATE for changed, preserve existing)
        5. Insert merge activity (MANUAL_UPDATE)
        6. Clear stale scoring_results in unified table
        """

        if not update_attributes:
            raise HTTPException(status_code=400, detail="No attributes to update")

        # Table names
        master_tbl = f"{catalog}.gold.{entity_name}_master_prod"
        activities_tbl = f"{catalog}.gold.{entity_name}_master_prod_merge_activities"
        attrsrc_tbl = f"{catalog}.gold.{entity_name}_master_prod_attribute_version_sources"
        unified_tbl = f"{catalog}.silver.{entity_name}_unified_prod"

        lakefusion_id_escaped = lakefusion_id.replace("'", "''")
        created_by_escaped = created_by.replace("'", "''")

        # Index attribute meta by name for complex-type lookups. Each entry
        # exposes `type`, `is_array`, and `struct_definition.fields[]` (added
        # by the complex-types schema migration).
        attr_meta_by_name = {}
        for a in entity_attributes_with_types or []:
            name = a.get("name") if isinstance(a, dict) else getattr(a, "name", None)
            if name:
                attr_meta_by_name[name] = a

        def _is_complex(meta):
            if meta is None:
                return False
            is_array = (meta.get("is_array") if isinstance(meta, dict)
                        else getattr(meta, "is_array", False))
            atype = (meta.get("type") if isinstance(meta, dict)
                     else getattr(meta, "type", "")) or ""
            return bool(is_array) or atype.strip().upper() == "STRUCT"

        def _spark_schema_ddl(meta) -> str:
            """Build a Spark DDL schema string for `from_json` from attr meta.
            Handles STRUCT, ARRAY<scalar>, and ARRAY<STRUCT>."""
            is_array = (meta.get("is_array") if isinstance(meta, dict)
                        else getattr(meta, "is_array", False))
            atype = ((meta.get("type") if isinstance(meta, dict)
                      else getattr(meta, "type", "")) or "").strip().upper() or "STRING"
            if atype == "STRUCT":
                sd = (meta.get("struct_definition") if isinstance(meta, dict)
                      else getattr(meta, "struct_definition", None))
                fields = []
                if sd is not None:
                    raw_fields = (sd.get("fields") if isinstance(sd, dict)
                                  else getattr(sd, "fields", None)) or []
                    sorted_fields = sorted(
                        raw_fields,
                        key=lambda f: (f.get("ordinal_position", 0) if isinstance(f, dict)
                                       else getattr(f, "ordinal_position", 0)),
                    )
                    for f in sorted_fields:
                        fname = (f.get("name") if isinstance(f, dict)
                                 else getattr(f, "name", None))
                        ftype = ((f.get("data_type") if isinstance(f, dict)
                                  else getattr(f, "data_type", "STRING")) or "STRING").upper()
                        if fname:
                            fields.append(f"{fname}:{ftype}")
                inner = f"STRUCT<{', '.join(fields)}>" if fields else "STRUCT<>"
                return f"ARRAY<{inner}>" if is_array else inner
            # Scalar element (ARRAY<scalar>)
            return f"ARRAY<{atype}>" if is_array else atype

        def _sql_literal_for_value(attr_name, attr_value, meta):
            """Render a value as a Spark SQL expression appropriate for the
            attribute type. STRUCT / ARRAY values flow through `from_json`."""
            if attr_value is None:
                return "NULL"
            if _is_complex(meta):
                payload = json.dumps(attr_value, default=str).replace("'", "''")
                schema_ddl = _spark_schema_ddl(meta).replace("'", "''")
                return f"from_json('{payload}', '{schema_ddl}')"
            return "'" + str(attr_value).replace("'", "''") + "'"

        # Build SET clause for master table update. STRUCT / ARRAY use
        # from_json(...) with the attribute's Spark schema so nested values
        # are written as typed columns instead of coerced strings.
        set_clauses = []
        for attr_name, attr_value in update_attributes.items():
            meta = attr_meta_by_name.get(attr_name)
            rhs = _sql_literal_for_value(attr_name, attr_value, meta)
            set_clauses.append(f"{attr_name} = {rhs}")
        set_clause = ", ".join(set_clauses)

        # Build attributes_combined rebuild expression.
        # COALESCE preserves NULL positions as empty strings between separators.
        concat_parts = ", ".join(
            f"COALESCE(CAST({attr_name} AS STRING), '')" for attr_name in entity_attribute_names
        )

        # Invalidate stale precomputed embedding when attributes_combined is rewritten.
        embedding_null_set = ", attributes_combined_embedding = NULL" if has_embedding_col else ""

        # Build attribute source mapping array of named_structs
        # For changed attrs: source = 'MANUAL_UPDATE' with new value
        # For unchanged attrs: preserve from latest version or use current master value with INITIAL_LOAD
        # This must be computed dynamically in SQL using the current mapping
        mapping_schema = "ARRAY<STRUCT<attribute_name:STRING, attribute_value:STRING, source:STRING>>"

        # Build the CASE expression for each attribute
        attr_struct_parts = []
        for attr_name in entity_attribute_names:
            escaped_name = attr_name.replace("'", "''")
            if attr_name in update_attributes:
                # Changed attribute — use MANUAL_UPDATE source. Audit table
                # `attribute_value` is StringType; JSON-encode dict/list
                # values losslessly so structure is preserved.
                new_val = update_attributes[attr_name]
                if new_val is None:
                    val_sql = "NULL"
                elif isinstance(new_val, (dict, list)):
                    val_sql = "'" + json.dumps(new_val, default=str).replace("'", "''") + "'"
                else:
                    val_sql = "'" + str(new_val).replace("'", "''") + "'"
                attr_struct_parts.append(
                    f"named_struct('attribute_name', '{escaped_name}', 'attribute_value', {val_sql}, 'source', 'MANUAL_UPDATE')"
                )
            else:
                # Unchanged attribute — preserve existing source from latest mapping, or fallback to master value
                attr_struct_parts.append(
                    f"named_struct('attribute_name', '{escaped_name}', "
                    f"'attribute_value', COALESCE("
                    f"(SELECT e.attribute_value FROM (SELECT inline(v_current_mapping)) e WHERE e.attribute_name = '{escaped_name}'), "
                    f"CAST((SELECT m.{attr_name} FROM {master_tbl} m WHERE m.lakefusion_id = '{lakefusion_id_escaped}') AS STRING)), "
                    f"'source', COALESCE("
                    f"(SELECT e.source FROM (SELECT inline(v_current_mapping)) e WHERE e.attribute_name = '{escaped_name}'), "
                    f"'INITIAL_LOAD'))"
                )

        mapping_sql = f"array({', '.join(attr_struct_parts)})"

        sql = f"""-- =====================================================================
-- STEWARDSHIP MANUAL UPDATE — Dynamic SQL Script
-- Entity:       {entity_name}
-- LakeFusion ID: {lakefusion_id}
-- Triggered:    {created_by}
-- =====================================================================
BEGIN
  DECLARE v_master_exists INT;
  DECLARE v_max_version INT;
  DECLARE v_new_version INT;
  DECLARE v_current_mapping {mapping_schema};

  -- [1] Validate master record exists
  SET v_master_exists = (SELECT COUNT(*) FROM {master_tbl} WHERE lakefusion_id = '{lakefusion_id_escaped}');

  IF v_master_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Master record not found: {lakefusion_id_escaped}';
  END IF;

  -- [2] Get current attribute source mapping (latest version)
  SET v_current_mapping = (
    SELECT attribute_source_mapping
    FROM {attrsrc_tbl}
    WHERE lakefusion_id = '{lakefusion_id_escaped}'
    ORDER BY version DESC
    LIMIT 1
  );

  -- Get new version number
  SET v_max_version = (SELECT COALESCE(MAX(version), 0) FROM {attrsrc_tbl} WHERE lakefusion_id = '{lakefusion_id_escaped}');
  SET v_new_version = v_max_version + 1;

  -- [3] Update master table — changed attributes
  UPDATE {master_tbl}
  SET {set_clause}
  WHERE lakefusion_id = '{lakefusion_id_escaped}';

  -- [3b] Rebuild attributes_combined (and invalidate precomputed embedding when present)
  UPDATE {master_tbl}
  SET attributes_combined = concat_ws(' | ', {concat_parts}){embedding_null_set}
  WHERE lakefusion_id = '{lakefusion_id_escaped}';

  -- [4] Insert new attribute version sources
  INSERT INTO {attrsrc_tbl} (lakefusion_id, version, attribute_source_mapping)
  SELECT
    '{lakefusion_id_escaped}',
    v_new_version,
    {mapping_sql};

  -- [5] Insert merge activity record
  INSERT INTO {activities_tbl} (master_id, match_id, source, version, action_type, created_at)
  SELECT
    '{lakefusion_id_escaped}',
    NULL,
    'MANUAL_UPDATE',
    v_new_version,
    'MANUAL_UPDATE',
    current_timestamp();

  -- [6] Clear stale scoring_results in unified table
  UPDATE {unified_tbl}
  SET search_results = NULL,
      scoring_results = NULL
  WHERE record_status = 'ACTIVE'
    AND scoring_results IS NOT NULL
    AND scoring_results != ''
    AND scoring_results != '[]'
    AND scoring_results LIKE '%{lakefusion_id_escaped}%';

  -- Return new version
  SELECT v_new_version AS new_version;
END"""
        return sql

    def run_manual_update_sql(self, entity_id: int, id_value: str, update_attributes: dict,
                              entity_attribute_names: list, entity_attributes_with_types: list,
                              token, created_by, warehouse_id: str = None):
        """Execute manual profile update via SQL warehouse instead of notebook job."""
        try:
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            # Build SQL script
            sql_script = self.build_manual_update_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                lakefusion_id=id_value,
                update_attributes=update_attributes,
                entity_attribute_names=entity_attribute_names,
                entity_attributes_with_types=entity_attributes_with_types,
                created_by=created_by,
                has_embedding_col=has_embedding_col
            )

            # Execute on SQL warehouse with retry on Delta concurrency conflicts
            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"MANUAL_UPDATE lakefusion_id={id_value}"
            )

            # Store tracking record
            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            entity_search_jobs = Model_Databricks_Entity_Search_Job(
                entity_id=entity_id,
                master_id=id_value,
                profile_id=id_value,
                operation_type='MANUAL_UPDATE',
                job_run_id=None,
                status=StewardshipJobStatus.QUERY_COMPLETED.value,
                job_run_status={"execution_type": "query", "result": "success"},
                created_by=created_by,
                execution_type='query',
                query_id=str(query_id)
            )
            self.db.add(entity_search_jobs)
            self.db.commit()
            self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL manual update failed: {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update profile via SQL: {str(e)}"
            )

    # =========================================================================
    # SQL Stewardship: Force Merge (Master-to-Master) via SQL Warehouse
    # =========================================================================

    def run_force_merge_sql(self, entity_id: int, potential_record, token, created_by, warehouse_id: str = None):
        """Execute force merge (master-to-master) via SQL warehouse instead of notebook job."""
        try:
            # Load entity metadata as dict
            entity_conn = EntityService(db=self.db)
            entity_data = entity_conn.get_full_entity_by_id(entity_id)
            entity_dict = entity_data.model_dump() if hasattr(entity_data, 'model_dump') else entity_data.dict()
            entity_name = entity_dict['name'].lower().replace(' ', '_')

            # Get entity attributes (PK first, then rest)
            all_attrs = entity_dict.get('attributes', [])
            pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and a.get('is_primary_key')]
            non_pk_attrs = [{'name': a['name'], 'type': a['type']} for a in all_attrs if a.get('is_active') and not a.get('is_primary_key')]
            attributes = pk_attrs + non_pk_attrs

            # Resolve survivorship rules (dataset_id → path)
            survivorship_rules = self._resolve_survivorship_rules(entity_dict)

            if not warehouse_id:
                warehouse_id = self.db_config_service.getDBConfigProperties(key="cron_warehouse_id")

            # Capture record snapshots BEFORE the force merge (both from master table)
            attr_names = [a['name'] for a in attributes]
            sd_master, sd_match = self._fetch_steward_decision_snapshots(
                token, warehouse_id, entity_name,
                master_id=str(potential_record.master_id),
                match_id=str(potential_record.match_record_id),
                attr_names=attr_names, is_master_to_master=True
            )

            # Detect precomputed-mode embedding column so the SQL script can null it.
            has_embedding_col = self._master_has_embedding_col(token, warehouse_id, entity_name)

            # Build SQL script — reuse golden dedup merge with MASTER_FORCE_MERGE action type
            sql_script = self.build_golden_dedup_merge_sql_script(
                catalog=self.catalog_name,
                entity_name=entity_name,
                experiment='prod',
                master_id=str(potential_record.master_id),
                match_record_id=str(potential_record.match_record_id),
                attributes=attributes,
                survivorship_rules=survivorship_rules,
                created_by=created_by,
                action_type='MASTER_FORCE_MERGE',
                has_embedding_col=has_embedding_col
            )

            # Execute on SQL warehouse with retry
            result = self._execute_with_concurrency_retry(
                token=token, warehouse_id=warehouse_id, sql_script=sql_script,
                description=f"FORCE_MERGE survivor={potential_record.master_id} absorbed={potential_record.match_record_id}"
            )

            # Write steward decision
            self._write_steward_decision(
                token, warehouse_id, entity_name, entity_id, 'FORCE_MERGE',
                str(potential_record.master_id), str(potential_record.match_record_id),
                sd_master, sd_match, created_by
            )

            # Store tracking record
            query_id = result.get("query_id", "unknown") if isinstance(result, dict) else "unknown"
            entity_search_jobs = Model_Databricks_Entity_Search_Job(
                entity_id=entity_id,
                master_id=str(potential_record.master_id),
                profile_id=str(potential_record.match_record_id),
                operation_type='FORCE_MERGE',
                job_run_id=None,
                status=StewardshipJobStatus.QUERY_COMPLETED.value,
                job_run_status={"execution_type": "query", "result": "success"},
                created_by=created_by,
                execution_type='query',
                query_id=str(query_id)
            )
            self.db.add(entity_search_jobs)
            self.db.commit()
            self.db.refresh(entity_search_jobs)

            return entity_search_jobs

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'SQL force merge failed: {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to force merge records via SQL: {str(e)}"
            )

    def run_match_merge_dnbintegration(self,entity_id:int,potential_record,token,created_by):
        try:
            entity_conn = EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            unified_ids = [str(i.id) for i in potential_record.unified_dataset_ids]
            dnb_duns_value=unified_ids[0]
            job_parameters = {
                    "entity_name":entity_name,
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "id_value": str(potential_record.master_id),
                    "dnb_duns_value": dnb_duns_value
                }
            if(potential_record.operation_type in ['MERGE']):
                job_service = DatabricksJobManager(token)
                task_list_response=self.create_match_merge_tasks_and_job_dnbintegration(job_parameters)
                job_create_response=job_service.create_and_submit_job("Entity_Match_Merge_DNB",task_list_response,self.lakefusion_spn)
                job_run_response=job_service.get_job_run_status(job_create_response.run_id)
                
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=potential_record.master_id,
                    profile_id=dnb_duns_value,
                    operation_type="MERGE",
                    job_run_id=job_create_response.run_id,
                    status=StewardshipJobStatus.SUBMITTED.value,
                    job_run_status=job_run_response,
                    created_by=created_by)
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs        
        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "run match merge (DNB integration)")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )

    def accept_dnb_candidate(self, entity_id, master_id, dnb_duns_value, warehouse_id, token):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            dnb_table = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"

            query = f"""
                UPDATE {dnb_table}
                SET merge_status = CASE
                    WHEN dnb_duns = '{dnb_duns_value}' THEN 'ACCEPTED'
                    ELSE 'REJECTED'
                END
                WHERE lakefusion_id = '{master_id}' AND merge_status = 'IN_REVIEW'
            """
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            sqlservice_conn.execute_insert_query(query=query)
            return {"message": "D&B candidate accepted successfully"}
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to accept D&B candidate. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to accept D&B candidate: {str(e)}"
            )

    def reject_all_dnb_candidates(self, entity_id, master_id, warehouse_id, token):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            dnb_table = f"{self.catalog_name}.gold.{entity_name}_master_prod_dnb_duns"

            query = f"""
                UPDATE {dnb_table}
                SET merge_status = 'REJECTED'
                WHERE lakefusion_id = '{master_id}' AND merge_status = 'IN_REVIEW'
            """
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            sqlservice_conn.execute_insert_query(query=query)
            return {"message": "All D&B candidates rejected successfully"}
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to reject D&B candidates. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to reject D&B candidates: {str(e)}"
            )

    def create_match_merge_tasks_and_job_deduplication(self, parameters):
        try:
            
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Match_Merge_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Manual Merge",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Match_Merge_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                
                timeout_seconds=0,
            )
            ]
            return tasks_list
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
    
    def create_not_match_tasks_and_job_deduplication(self, parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Not_Match_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Manual Not A Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/maven-core-deduplication/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )

    def create_match_merge_tasks_and_job_deduplication_updated(self, parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Merge_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Manual_Merge",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Manual_Merge",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Potential_Match_Table",
                    #new_cluster=job_cluster.new_cluster,
                    depends_on=[TaskDependency(task_key="Entity_Merge_Deduplication")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Process_Potential_Match",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Potential_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_Potential_Match_Normal",
                    #new_cluster=job_cluster.new_cluster,
                    depends_on=[TaskDependency(task_key="Entity_Merge_Deduplication")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Process_CrossWalk",
                    #new_cluster=job_cluster.new_cluster,
                    depends_on=[TaskDependency(task_key="Entity_Merge_Deduplication")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Normal"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )
    
    def create_not_match_tasks_and_job_deduplication_updated(self, parameters):
        try:
           
            tags = get_resource_tags()
            if tags is None:
                tags = {}   
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
                SubmitTask(
                    task_key="Parse_Entity_Model_JSON",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                        base_parameters=job_parameters_list[0],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),
                SubmitTask(
                    task_key="Entity_Not_Match_Deduplication",
                    depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                    run_if=RunIf.ALL_SUCCESS,
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Manual_Not_Match",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Manual_Not_Match",
                        base_parameters=job_parameters_list[1],
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/golden_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Not_Match_Deduplication")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_Potential_Match_Table"),TaskDependency(task_key="Process_CrossWalk")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create tasks Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create tasks: {str(e)}"
            )

    def run_match_merge_deduplication(self, entity_id: int, potential_record, token, created_by):
        try:
            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str(potential_record.operation_type),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type in ['MERGE', 'MERGE_ALL']:
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response,self.lakefusion_spn)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
            elif potential_record.operation_type == 'NOT_A_MATCH':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_not_match_tasks_and_job_deduplication(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_Not_A_Match", task_list_response,self.lakefusion_spn)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type="NOT_A_MATCH",
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "run match merge deduplication")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )

    def run_match_merge_deduplication_updated(self, entity_id: int, potential_record, token, created_by):
        try:
            if potential_record.operation_type in ['MERGE','MERGE_ALL']:
                operation_type='MASTER_MANUAL_MERGE'
            else:
                operation_type='MANUAL_NOT_A_MATCH'


            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str(operation_type),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type in ['MERGE', 'MERGE_ALL']:
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication_updated(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response,self.lakefusion_spn)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
            elif potential_record.operation_type == 'NOT_A_MATCH':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_not_match_tasks_and_job_deduplication_updated(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_Not_A_Match", task_list_response,self.lakefusion_spn)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type="NOT_A_MATCH",
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "run match merge deduplication")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )


    def run_force_merge_deduplication(self, entity_id: int, potential_record, token, created_by):
        try:
            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str('MASTER_FORCE_MERGE'),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type=='FORCE_MERGE':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response,self.lakefusion_spn)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
           
                
        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "run force merge")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to force merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )

    def run_force_merge_deduplication_updated(self, entity_id: int, potential_record, token, created_by):
        try:
            job_parameters = [
                {
                    "entity_id": str(entity_id),
                    "experiment_id": str('prod'),
                    "catalog_name": self.catalog_name
                },
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "operation_type":str('MASTER_FORCE_MERGE'),
                    "master_id": str(potential_record.master_id),
                    "match_record_id": str(potential_record.match_record_id)
                }
            ]
            
            if potential_record.operation_type=='FORCE_MERGE':
                job_service = DatabricksJobManager(token)
                task_list_response = self.create_match_merge_tasks_and_job_deduplication_updated(job_parameters)
                job_create_response = job_service.create_and_submit_job("Entity_MERGE", task_list_response,self.lakefusion_spn)
                job_run_response = job_service.get_job_run_status(job_create_response.run_id)
                
                # Create single job record for the match record
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                        entity_id=entity_id,
                        master_id=potential_record.master_id,
                        profile_id=potential_record.match_record_id,
                        operation_type=potential_record.operation_type,
                        job_run_id=job_create_response.run_id,
                        status=StewardshipJobStatus.SUBMITTED.value,
                        job_run_status=job_run_response,
                        created_by=created_by
                )
                self.db.add(entity_search_jobs)
                self.db.commit()
                self.db.refresh(entity_search_jobs)
                return entity_search_jobs
                
        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "run force merge")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to force merge Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to merge records: {str(e)}"
            )
    def create_unmerge_tasks_and_job(self, parameters):
        try:
            dbx_cloud=(self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "dbx_cloud").first().config_value)
            tags = get_resource_tags()
            if tags is None:
                tags = {}
            if(dbx_cloud=='azure'):
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                cluster_name="",
                spark_version="16.0.x-cpu-ml-scala2.12",
                azure_attributes=AzureAttributes(
                    first_on_demand=1
                ),  # Corrected Azure Attributes
                node_type_id="Standard_DS12_v2",
                driver_node_type_id="Standard_DS12_v2",  # Correct Azure instance type
                spark_env_vars={
                    "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                },
                enable_elastic_disk=False,
                data_security_mode=DataSecurityMode.SINGLE_USER,
                runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                autoscale=AutoScale(
                    min_workers=1,  # Updated worker count
                    max_workers=1   # Updated worker count
                ),
                custom_tags=tags  # Add custom tags
                ))
            else:
                job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    aws_attributes=AwsAttributes(
                        first_on_demand=1,
                        availability=AwsAvailability.SPOT_WITH_FALLBACK,
                        zone_id="us-west-2d",
                        spot_bid_price_percent=100,
                        ebs_volume_count=0
                    ),
                    node_type_id="r5d.4xlarge",  # Updated instance type
                    spark_env_vars={
                        "PYSPARK_PYTHON": "/databricks/python3/bin/python3"
                    },
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,  # Updated to STANDARD
                    autoscale=AutoScale(
                        min_workers=2,  # Updated worker count
                        max_workers=4   # Updated worker count
                    ),
                    custom_tags=tags  # Add custom tags
                    ))
            job_parameters_list = [i for i in parameters]
            
            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Unmerge",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Manual Unmerge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Manual Unmerge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Potential Match Table",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Potential Match Table",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Process Cross Walk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Cross Walk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create unmerge tasks. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create unmerge tasks: {str(e)}"
            )

    def create_unmerge_tasks_and_job_updated(self, parameters):
        try:

            tags = get_resource_tags()
            if tags is None:
                tags = {}

            job_parameters_list = [i for i in parameters]

            tasks_list = [
            SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Parse Entity & Model JSON",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=job_parameters_list[0],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Entity_Unmerge",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Manual_Unmerge",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Manual_Unmerge",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Potential_Match_Table",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/normal_deduplication/Process_Potential_Match",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_CrossWalk",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Entity_Unmerge")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Process_Crosswalk",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Process_Crosswalk",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            ),SubmitTask(
                task_key="Process_Entity_Job_Status",
                #new_cluster=job_cluster.new_cluster,
                depends_on=[TaskDependency(task_key="Process_CrossWalk"),TaskDependency(task_key="Process_Potential_Match_Table")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    # notebook_path=f"{self.notebook_folder_path}/src/integration-core/Entity_Job_Status",
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    base_parameters=job_parameters_list[1],
                    source=Source.WORKSPACE,
                ),

                timeout_seconds=0,
            )
            ]
            return tasks_list

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create unmerge tasks. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to create unmerge tasks: {str(e)}"
            )

    def run_unmerge(self, entity_id: int, unmerge_record, token, created_by):
        try:
            job_parameters=[
                {"entity_id": str(entity_id), "experiment_id": str('prod'), "catalog_name": self.catalog_name},
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "master_id": str(unmerge_record.master_id),
                    "unified_dataset_ids": json.dumps([{"id": i.id, "dataset_id": i.dataset_id} for i in unmerge_record.unified_dataset_ids])
                }
            ]
            
            job_service = DatabricksJobManager(token)
            task_list_response = self.create_unmerge_tasks_and_job(job_parameters)
            job_create_response = job_service.create_and_submit_job("Entity_UNMERGE", task_list_response,self.lakefusion_spn)
            job_run_response = job_service.get_job_run_status(job_create_response.run_id)
            
            entity_search_jobs_list = []
            for i in unmerge_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=unmerge_record.master_id,
                    profile_id=i.id,
                    operation_type='UNMERGE',
                    job_run_id=job_create_response.run_id,
                    status=StewardshipJobStatus.SUBMITTED.value,
                    job_run_status=job_run_response,
                    created_by=created_by)
                self.db.add(entity_search_jobs)
                entity_search_jobs_list.append(entity_search_jobs)
                
            self.db.commit()
            for job in entity_search_jobs_list:
                self.db.refresh(job)
                
            return entity_search_jobs_list[0] if entity_search_jobs_list else None
            
        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "run unmerge")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to unmerge. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to unmerge records: {str(e)}"
            )

    def run_unmerge_updated(self, entity_id: int, unmerge_record, token, created_by):
        try:
            job_parameters=[
                {"entity_id": str(entity_id), "experiment_id": str('prod'), "catalog_name": self.catalog_name},
                {
                    "catalog_name": self.catalog_name,
                    "experiment_id": str('prod'),
                    "master_id": str(unmerge_record.master_id),
                    "unified_dataset_ids": json.dumps([{"id": i.id, "dataset_id": i.dataset_id} for i in unmerge_record.unified_dataset_ids])
                }
            ]
            
            job_service = DatabricksJobManager(token)
            task_list_response = self.create_unmerge_tasks_and_job_updated(job_parameters)
            job_create_response = job_service.create_and_submit_job("Entity_UNMERGE", task_list_response,self.lakefusion_spn)
            job_run_response = job_service.get_job_run_status(job_create_response.run_id)
            
            entity_search_jobs_list = []
            for i in unmerge_record.unified_dataset_ids:
                entity_search_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=unmerge_record.master_id,
                    profile_id=i.id,
                    operation_type='UNMERGE',
                    job_run_id=job_create_response.run_id,
                    status=StewardshipJobStatus.SUBMITTED.value,
                    job_run_status=job_run_response,
                    created_by=created_by)
                self.db.add(entity_search_jobs)
                entity_search_jobs_list.append(entity_search_jobs)
                
            self.db.commit()
            for job in entity_search_jobs_list:
                self.db.refresh(job)
                
            return entity_search_jobs_list[0] if entity_search_jobs_list else None
            
        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "run unmerge")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to unmerge. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to unmerge records: {str(e)}"
            )

    def create_tasks_and_job(self, parameters):
        """Legacy job creation for update profile (versions < 4.0.0)."""
        dbx_cloud = (self.db.query(DBConfigProperties).filter(DBConfigProperties.config_key == "dbx_cloud").first().config_value)
        tags = get_resource_tags()
        if tags is None:
            tags = {}
        if dbx_cloud == 'azure':
            job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    azure_attributes=AzureAttributes(first_on_demand=1),
                    node_type_id="Standard_DS12_v2",
                    driver_node_type_id="Standard_DS12_v2",
                    spark_env_vars={"PYSPARK_PYTHON": "/databricks/python3/bin/python3"},
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,
                    autoscale=AutoScale(min_workers=1, max_workers=1),
                    custom_tags=tags
                )
            )
        else:
            job_cluster = jobs.JobCluster(
                job_cluster_key="MatchMaven_ML_Memory_optimized_Cluster",
                new_cluster=ClusterSpec(
                    cluster_name="",
                    spark_version="16.0.x-cpu-ml-scala2.12",
                    aws_attributes=AwsAttributes(
                        first_on_demand=1,
                        availability=AwsAvailability.SPOT_WITH_FALLBACK,
                        zone_id="us-west-2d",
                        spot_bid_price_percent=100,
                        ebs_volume_count=0
                    ),
                    node_type_id="r5d.4xlarge",
                    spark_env_vars={"PYSPARK_PYTHON": "/databricks/python3/bin/python3"},
                    enable_elastic_disk=False,
                    data_security_mode=DataSecurityMode.SINGLE_USER,
                    runtime_engine=RuntimeEngine.STANDARD,
                    autoscale=AutoScale(min_workers=2, max_workers=4),
                    custom_tags=tags
                )
            )

        if len(parameters) == 1:
            tasks_list = [
                Task(
                    task_key="UpdateEntityDnBIntegration",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Update Entity Search Profile",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Update Entity Search Profile",
                        base_parameters={"query_1": str(parameters[0])},
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                )
            ]
        else:
            tasks_list = [
                Task(
                    task_key="UpdateEntityProfile",
                    notebook_task=NotebookTask(
                        # notebook_path=f"{self.notebook_folder_path}/src/maven-core/Update Entity Search Profile",
                        notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Update Entity Search Profile",
                        base_parameters={
                            "query_1": str(parameters[0]),
                            "query_2": str(parameters[1]),
                            "query_3": str(parameters[2])
                        },
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=0,
                )
            ]

        return [tasks_list, job_cluster]
    
    def _create_manual_update_job_config(self, notebook_params: dict):
        """
        Create the job configuration for the v4.0.0+ Manual_Update notebook.
        Uses serverless compute (no cluster specification).

        Pipeline:
            Parse_Entity_Model_JSON
                -> ManualUpdateProfile
                    -> Process_Potential_Match_Normal  (parallel)
                    -> Process_Potential_Match_Golden  (parallel; exits early if
                       processed_unified_deduplicate_prod missing)
                    -> Process_Warning_Records         (parallel)
                        -> Process_Entity_Job_Status

        Process_Potential_Match_* rebuild gold.*_master_potential_match_prod
        and gold.*_master_potential_match_deduplicate_prod so the Potential
        Matches / Golden De-duplication UI reflects the manual edit.
        """
        tasks_list = [
             SubmitTask(
                task_key="Parse_Entity_Model_JSON",
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Parse Entity & Model JSON",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
             SubmitTask(
                task_key="ManualUpdateProfile",
                depends_on=[TaskDependency(task_key="Parse_Entity_Model_JSON")],
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Manual_Update",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
             SubmitTask(
                task_key="Process_Potential_Match_Normal",
                depends_on=[TaskDependency(task_key="ManualUpdateProfile")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/normal_deduplication/Process_Potential_Match",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
             SubmitTask(
                task_key="Process_Potential_Match_Golden",
                depends_on=[TaskDependency(task_key="ManualUpdateProfile")],
                run_if=RunIf.ALL_SUCCESS,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/golden_deduplication/Process_Potential_Match",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
             SubmitTask(
                task_key="Process_Warning_Records",
                depends_on=[TaskDependency(task_key="ManualUpdateProfile")],
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('maven-core', self.db)}/Process Warning Records",
                    base_parameters=notebook_params,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            ),
             SubmitTask(
                task_key="Process_Entity_Job_Status",
                depends_on=[
                    TaskDependency(task_key="Process_Potential_Match_Normal"),
                    TaskDependency(task_key="Process_Potential_Match_Golden"),
                    TaskDependency(task_key="Process_Warning_Records"),
                ],
                run_if=RunIf.NONE_FAILED,
                notebook_task=NotebookTask(
                    notebook_path=f"{self.notebook_folder_path}/src/{get_notebook_folder('integration-core', self.db)}/Entity_Job_Status",
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=0,
            )
        ]

        return tasks_list
    
    def _process_attribute_updates(self, latest_attributes_result, attributes_values, source):
        """Process attribute updates using NumPy for better performance"""
        import numpy as np
        import json
        
        existing_attributes = []
        try:
            if (latest_attributes_result is not None and 
                len(latest_attributes_result) > 0):
                
                if not isinstance(latest_attributes_result, np.ndarray):
                    result_array = np.array(latest_attributes_result)
                else:
                    result_array = latest_attributes_result
                
                if (result_array.size > 0 and 
                    isinstance(result_array[0], dict) and
                    'attribute_source_mapping' in result_array[0] and 
                    result_array[0]['attribute_source_mapping'] is not None):
                    
                    existing_attributes = result_array[0]['attribute_source_mapping']
                    
                    if isinstance(existing_attributes, str):
                        try:
                            existing_attributes = json.loads(existing_attributes)
                        except:
                            existing_attributes = []
                    elif isinstance(existing_attributes, np.ndarray):
                        existing_attributes = existing_attributes.tolist()
                    elif not isinstance(existing_attributes, list):
                        existing_attributes = []
                        
        except (TypeError, IndexError, KeyError, ValueError) as e:
            print(f"Debug: Error processing attributes: {e}")
            existing_attributes = []
        
        attributes_dict = {}
        
        if isinstance(existing_attributes, list):
            for attr in existing_attributes:
                if isinstance(attr, dict) and attr.get('attribute_name'):
                    attr_name = attr.get('attribute_name')
                    attributes_dict[attr_name] = {
                        'attribute_name': attr_name,
                        'attribute_value': attr.get('attribute_value', ''),
                        'source': attr.get('source', source)
                    }
        
        for key, value in attributes_values.items():
            safe_value = str(value) if value is not None else ''
            attributes_dict[key] = {
                'attribute_name': key,
                'attribute_value': safe_value,
                'source': 'MANUAL_UPDATE'
            }
        
        final_attributes = list(attributes_dict.values())
        
        return final_attributes

    def _convert_attributes_to_sql_array(self, attribute_values):
        """Convert Python attribute list to SQL array format"""
        
        if not attribute_values:
            return "array()"
        
        attribute_structs = []
        for attr in attribute_values:
            safe_name = str(attr['attribute_name']).replace("'", "''")
            safe_value = str(attr['attribute_value']).replace("'", "''")
            safe_source = str(attr['source']).replace("'", "''")
            
            struct = f"named_struct('attribute_name', '{safe_name}', 'attribute_value', '{safe_value}', 'source', '{safe_source}')"
            attribute_structs.append(struct)
        
        return f"array({', '.join(attribute_structs)})"
    
    def _get_entity_attributes_with_types(self, entity) -> List[Any]:
        """
        Extract entity attributes with their data types from the entity model.
        Returns the list of attribute objects or dicts.
        """
        if hasattr(entity, 'attributes') and entity.attributes:
            return entity.attributes
        return []

    def _update_profile_v4(
        self,
        entity_name: str,
        entity_id:int,
        id_value: str,
        update_attributes: dict,
        entity_attributes: List[str],
        token: str,
        created_by
    ):
        """
        New v4.0.0+ update flow using Manual_Update notebook.
        All logic is handled in the notebook. Uses serverless compute.
        """
        # Prepare parameters for the notebook
        notebook_params = {
            "catalog_name": self.catalog_name,
            "entity_name": entity_name,
            "entity_id": entity_id,
            "lakefusion_id": id_value,
            "update_attributes": json.dumps(update_attributes),
            "entity_attributes": json.dumps(entity_attributes),
            "experiment_id": "prod",
        }
        
        app_logger.info(f"Triggering Manual_Update job (v4.0.0+) with params: {notebook_params}")
        
        # Create and run the job using serverless (same pattern as other methods)
        job_service = DatabricksJobManager(token)
        tasks_list = self._create_manual_update_job_config(notebook_params)
        
        # Use create_and_submit_job (serverless) instead of create_job + run_job
        job_create_response = job_service.create_and_submit_job(
            f"Manual_Update_Profile-{entity_name}-{id_value[:8]}",
            tasks_list,self.lakefusion_spn
        )
        
        job_run_response = job_service.get_job_run_status(job_create_response.run_id)
        entity_update_jobs = Model_Databricks_Entity_Search_Job(
                    entity_id=entity_id,
                    master_id=id_value,
                    profile_id=id_value,
                    operation_type='MANUAL_UPDATE',
                    job_run_id=job_create_response.run_id,
                    status=StewardshipJobStatus.SUBMITTED.value,
                    job_run_status=job_run_response,
                    created_by=created_by)
        self.db.add(entity_update_jobs)
        self.db.commit()
        self.db.refresh(entity_update_jobs)
        
        app_logger.info(f"Manual_Update job triggered successfully: run_id={job_create_response.run_id}")
        return job_run_response

    def _update_profile_legacy(
        self,
        entity_name: str,
        id_value: str,
        update_attributes: dict,
        warehouse_id: str,
        token: str,
        entity
    ):
        """
        Legacy update flow for versions < 4.0.0.
        Uses the old query-based approach.
        """
        source = entity.path
        entity_primary = "lakefusion_id"
        
        get_attributes_and_version_query = f"""
        with global_max as (
            select coalesce(max(version), 0) as global_max_version
            from {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources
        ),
        latest_attrs as (
            select 
                version,
                attribute_source_mapping
            from {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources 
            where {entity_primary}='{id_value}'
            order by version desc
            limit 1
        )
        select 
            coalesce(la.version, 0) as record_version,
            la.attribute_source_mapping,
            gm.global_max_version
        from global_max gm
        left join latest_attrs la on 1=1
        """
        
        sqlservice_conn = DataSetSQLService(token, warehouse_id)
        combined_result = sqlservice_conn.execute_dataset(get_attributes_and_version_query)
        
        global_max_version = combined_result[0]['global_max_version'] if combined_result else 0
        next_version = global_max_version + 1
        
        attributes_data = [{
            'attribute_source_mapping': combined_result[0]['attribute_source_mapping'] if combined_result else None
        }] if combined_result else []
        
        new_attribute_values = self._process_attribute_updates(
            attributes_data, 
            update_attributes, 
            source
        )
        
        attribute_values_sql = self._convert_attributes_to_sql_array(new_attribute_values)
        
        update_query = ", ".join([f"{k} = '{v}'" for k, v in update_attributes.items()])
        query_1 = f"update {self.catalog_name}.gold.{entity_name}_master_prod set {update_query} where {entity_primary}='{id_value}'"

        query_2 = f"""
        insert into {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources 
        values (
            '{id_value}',
            {next_version},
            {attribute_values_sql}
        )
        """
        
        query_3 = f"""
        insert into {self.catalog_name}.gold.{entity_name}_master_prod_merge_activities 
        values (
            '{id_value}',
            Null,
            'MANUAL_UPDATE',
            {next_version},
            'MANUAL_UPDATE'
        )
        """

        parameters = [query_1, query_2, query_3]
        job_service = DatabricksJobManager(token)
        task_job = self.create_tasks_and_job(parameters)
        job_create_response = job_service.create_job(
            f"Update_Profile-{entity_name}",
            job_clusters=task_job[1],
            tasks_list=task_job[0]
        )
        job_response = job_service.run_job(job_create_response)
        return job_response
        
    def update_entity_search_profile(self, entity_id, id_value: str, attributes_values, warehouse_id, token,created_by):
        """
        Update an entity profile with version-based routing.
        
        For v4.0.0+: Routes to new Manual_Update notebook
        For < v4.0.0: Routes to legacy query-based flow
        
        Includes pre-flight validation of attributes before starting any job.
        """
        try:
            # Get entity information
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            
            # Get version from Integration_Hub table instead of entity table
            entity_version = self.get_integration_hub_task_version(entity_id) or "1.0.0"
            
            # Get entity attributes (for validation and passing to notebook)
            entity_attributes = self._get_entity_attributes_with_types(entity)
            entity_attribute_names = []
            for attr in entity_attributes:
                if isinstance(attr, dict):
                    name = attr.get('name') or attr.get('column_name')
                else:
                    name = getattr(attr, 'name', None) or getattr(attr, 'column_name', None)
                if name and name != 'attributes_combined':
                    entity_attribute_names.append(name)
            
            app_logger.info(
                f"Processing update for entity '{entity_name}' (version {entity_version}), "
                f"lakefusion_id '{id_value}'"
            )
            
            # ===== VALIDATION =====
            # Validate attributes before starting any job
            try:
                AttributeValidator.validate_or_raise(attributes_values, entity_attributes)
                app_logger.info("✓ Attribute validation passed")
            except AttributeValidationError as e:
                app_logger.warning(f"Attribute validation failed: {e.errors}")
                raise HTTPException(
                    status_code=400,
                    detail={
                        "error": "Validation failed",
                        "messages": e.errors
                    }
                )
            
            # ===== SQL STEWARDSHIP PATH (feature-flagged) =====
            sql_stewardship_enabled = FeatureFlagService._is_feature_flag_enabled(self.db, "ENABLE_SQL_STEWARDSHIP")
            if sql_stewardship_enabled and warehouse_id:
                app_logger.info(f"Using SQL stewardship flow for manual update (entity={entity_name}, lakefusion_id={id_value})")
                return self.run_manual_update_sql(
                    entity_id=entity_id,
                    id_value=id_value,
                    update_attributes=attributes_values,
                    entity_attribute_names=entity_attribute_names,
                    entity_attributes_with_types=entity_attributes,
                    token=token,
                    created_by=created_by,
                    warehouse_id=warehouse_id
                )

            # ===== VERSION-BASED ROUTING =====
            if is_version_gte(entity_version, NEW_PIPELINE_MIN_VERSION):
                # New v4.0.0+ flow
                app_logger.info(f"Using NEW pipeline flow (version {entity_version} >= {NEW_PIPELINE_MIN_VERSION})")
                return self._update_profile_v4(
                    entity_name=entity_name,
                    entity_id=entity_id,
                    id_value=id_value,
                    update_attributes=attributes_values,
                    entity_attributes=entity_attribute_names,
                    token=token,
                    created_by=created_by
                )
            else:
                # Legacy flow
                app_logger.info(f"Using LEGACY pipeline flow (version {entity_version} < {NEW_PIPELINE_MIN_VERSION})")
                return self._update_profile_legacy(
                    entity_name=entity_name,
                    id_value=id_value,
                    update_attributes=attributes_values,
                    warehouse_id=warehouse_id,
                    token=token,
                    entity=entity
                )
             
        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "update entity profile")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update entity gold table: {str(e)}"
            )
    
    def get_merge_statuses(self, entity_id: int, master_id: str) -> List[dict]:
        """
        Get all merge operation statuses for a given master_id.
        
        Args:
            entity_id: The entity ID
            master_id: The master record ID to check statuses for
        
        Returns:
            List of status objects containing profile_id and status
        """
        try:
            results = self.db.query(Model_Databricks_Entity_Search_Job).filter(
                and_(
                    Model_Databricks_Entity_Search_Job.entity_id == entity_id,
                    Model_Databricks_Entity_Search_Job.master_id == master_id
                )
            ).order_by(Model_Databricks_Entity_Search_Job.created_at.desc()).all()
            
            # Group by profile_id and get latest status
            databricks_host = get_databricks_host() or None
            status_map = {}
            for result in results:
                if result.profile_id not in status_map:
                    entry = {
                        "job_id": result.id,
                        "profile_id": result.profile_id,
                        "status": result.status,
                        "operation_type": result.operation_type,
                        "execution_type": result.execution_type,
                        "created_at": result.created_at.isoformat()
                    }
                    # Build execution link if applicable
                    if result.execution_type == 'query' and result.query_id:
                        entry["execution_link"] = f"{databricks_host}/sql/history?queryId={result.query_id}"
                    elif result.job_run_id:
                        entry["execution_link"] = f"{databricks_host}/jobs/runs/{result.job_run_id}"
                    status_map[result.profile_id] = entry

            return list(status_map.values())
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch merge statuses for master_id {master_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed fetching merge statuses: {str(e)}")
        
    def get_force_merge_status(self, entity_id: int, master_id: str, match_id: str) -> list[dict]:
        """Retrieves latest force merge job status from the database."""
        try:
            result = (
                self.db.query(Model_Databricks_Entity_Search_Job)
                .filter(
                    Model_Databricks_Entity_Search_Job.entity_id == entity_id,
                    Model_Databricks_Entity_Search_Job.operation_type == "FORCE_MERGE",
                    or_(
                        or_(
                            Model_Databricks_Entity_Search_Job.master_id == master_id,
                            Model_Databricks_Entity_Search_Job.profile_id == match_id,
                        ),
                        or_(
                            Model_Databricks_Entity_Search_Job.master_id == match_id,
                            Model_Databricks_Entity_Search_Job.profile_id == master_id,
                        ),
                    ),
                )
                .order_by(Model_Databricks_Entity_Search_Job.created_at.desc())
                .first()
            )

            if result is None:
                return []

            return [{
                "master_id": result.master_id,
                "profile_id": result.profile_id,
                "status": result.status,
                "job_run_id": result.job_run_id,
                "job_run_status": result.job_run_status,
                "created_at": result.created_at.isoformat(),
            }]

        except Exception as e:
            app_logger.exception("Unable to fetch force merge status")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch force merge status: {str(e)}",
            )
        
    def read_entity_search_profile_validation_id(self,entity_id:int,id_value:str,warehouse_id:str,validation_type:str,token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            
            entity_primary="lakefusion_id"
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            if(validation_type=='error'):
               query=f"""WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'gold'
      AND table_name = '{entity_name}_master_validation_error_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)
SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.gold.{entity_name}_unified_prod p' ||
  ' LEFT JOIN {self.catalog_name}.gold.{entity_name}_unified_validation_error_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN 
      ' WHERE p.{entity_primary} = ''{id_value}'' AND ' || where_conditions
    ELSE ' WHERE p.{entity_primary} = ''{id_value}'' '
  END AS generated_query
FROM validation_columns;"""
            else:
                query=f"""WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'silver'
      AND table_name = '{entity_name}_unified_validation_warning_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)
SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.silver.{entity_name}_unified_prod p' ||
  ' LEFT JOIN {self.catalog_name}.silver.{entity_name}_unified_validation_warning_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN 
      ' WHERE p.{entity_primary} = ''{id_value}'' AND ' || where_conditions
    ELSE ' WHERE p.{entity_primary} = ''{id_value}'' '
  END AS generated_query
FROM validation_columns;"""
            data=sqlservice_conn.execute_dataset(query=query)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            data=sqlservice_conn.execute_dataset(query=data[0]['generated_query'])
            return [serialize_row_data(row) for row in data]

        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "read validation records")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile with validation records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile with validation records: {str(e)}"
            )

    def read_entity_search_profile_validation(self,entity_id:int,warehouse_id:str,validation_type:str,token:str):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            #entity_name='Patients'
            entity_primary="lakefusion_id"
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            if(validation_type=='error'):
               query=f"""WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'gold'
      AND table_name = '{entity_name}_master_validation_error_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)

SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.gold.{entity_name}_master_prod p' ||
  ' LEFT JOIN {self.catalog_name}.gold.{entity_name}_master_validation_error_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN ' WHERE ' || where_conditions
    ELSE ''
  END AS generated_query
FROM validation_columns;"""
            else:
                query=f"""
WITH validation_columns AS (
  SELECT 
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name)
        END
      ), 
      ', '
    ) AS column_list,
    array_join(
      collect_list(
        CASE 
          WHEN column_name != '{entity_primary}' THEN concat('w.', column_name, ' = FALSE')
        END
      ), 
      ' OR '
    ) AS where_conditions
  FROM (
    SELECT 
      column_name,
      row_number() OVER (ORDER BY ordinal_position) AS rn
    FROM information_schema.columns 
    WHERE table_schema = 'silver'
      AND table_name = '{entity_name}_unified_validation_warning_prod'
  ) 
  WHERE column_name != '{entity_primary}'
)

SELECT 
  'SELECT ' || 
  CASE 
    WHEN column_list='' THEN 'p.*' 
    ELSE 'p.*, ' || column_list 
  END || 
  ' FROM {self.catalog_name}.silver.{entity_name}_unified_prod p' ||
  ' LEFT JOIN {self.catalog_name}.silver.{entity_name}_unified_validation_warning_prod w' ||
  ' ON p.{entity_primary} = w.{entity_primary}' ||
  CASE 
    WHEN where_conditions!='' THEN ' WHERE ' || where_conditions
    ELSE ''
  END AS generated_query
FROM validation_columns;"""
            data=sqlservice_conn.execute_dataset(query=query)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            return_data=sqlservice_conn.execute_dataset(query=data[0]['generated_query'])
            return [serialize_row_data(row) for row in return_data]

        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "read validation records")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity profile with validation records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity profile with validation records: {str(e)}"
            )

    def get_attribute_sources(self, entity_id: int, profile_id: str, warehouse_id: str, token: str):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            entity_primary = "lakefusion_id"
            hidden_attrs = {attr.name for attr in entity.attributes if attr.name and not attr.show_in_ui}
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            query = f"select * from {self.catalog_name}.gold.{entity_name}_master_prod_attribute_version_sources where {entity_primary}='{profile_id}'"
            data = sqlservice_conn.execute_dataset(query=query)

            def convert_to_string(value):
                if value is None:
                    return ""
                if isinstance(value, (int, float, bool)):
                    return str(value)
                if isinstance(value, (list, dict)):
                    return json.dumps(value)
                return str(value)

            # Convert the data to a list of dictionaries with string values
            if data:
                formatted_data = []
                for row in data:
                    if hasattr(row, '_asdict'):
                        # Handle named tuples
                        row_dict = row._asdict()
                    elif hasattr(row, '__dict__'):
                        # Handle objects
                        row_dict = row.__dict__
                    elif isinstance(row, dict):
                        row_dict = row
                    else:
                        # Handle tuples/lists
                        columns = [col[0] if isinstance(col, tuple) else col for col in data[0]._fields] if hasattr(data[0], '_fields') else data[0].keys()
                        row_dict = dict(zip(columns, row))
                    
                    # Convert all values to strings, excluding hidden attributes
                    formatted_row = {key: convert_to_string(value) for key, value in row_dict.items() if key not in hidden_attrs}
                    formatted_data.append(formatted_row)
                
                return formatted_data
            
            return []

        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "read attribute sources")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch profile sources. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch profile sources: {str(e)}"
            )

    def get_merge_activities(self, entity_id: int, profile_id: str, warehouse_id: str, token: str):
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)

            entity_name = entity.name.lower().replace(' ', '_')
            entity_primary = "lakefusion_id"
            table_name = f"{entity_name}_master_prod_merge_activities"

            # ---------- 1st Connection (check columns) ----------
            sqlservice_conn = DataSetSQLService(token, warehouse_id)

            column_check_query = f"""
                SELECT column_name
                FROM {self.catalog_name}.information_schema.columns
                WHERE table_schema = 'gold'
                AND table_name = '{table_name}'
                AND column_name IN ('master_{entity_primary}', 'master_id');
            """

            cols = sqlservice_conn.execute_dataset(query=column_check_query)
            col_names = set()
            for row in cols or []:
                if isinstance(row, dict):
                    col_names.add(row.get("column_name") or row.get("COLUMN_NAME"))
                else:
                    col_names.add(row[0])

            if f"master_{entity_primary}" in col_names:
                master_col = f"master_{entity_primary}"
            elif "master_id" in col_names:
                master_col = "master_id"
            else:
                raise Exception(f"No valid master column found in table {table_name}")
            
            print("master col", master_col)

            # ---------- 2nd Connection (main data query) ----------
            sqlservice_conn = DataSetSQLService(token, warehouse_id)

            query = f"""
                SELECT *
                FROM {self.catalog_name}.gold.{table_name}
                WHERE {master_col} = '{profile_id}';
            """

            data = sqlservice_conn.execute_dataset(query=query)

            # Enrich manual operations with username from entity_search_databricks_jobs
            # merge_activities action_type → jobs operation_type mapping:
            #   MANUAL_MERGE → MERGE (profile_id = surrogate_key)
            #   MANUAL_UNMERGE → UNMERGE (profile_id = surrogate_key)
            #   MANUAL_NOT_A_MATCH → NOT_A_MATCH (profile_id = surrogate_key)
            #   MANUAL_UPDATE → MANUAL_UPDATE (profile_id = lakefusion_id)
            #   MASTER_MANUAL_MERGE → MERGE (profile_id = lakefusion_id)
            #   MASTER_FORCE_MERGE → FORCE_MERGE (profile_id = lakefusion_id)
            #   MASTER_MANUAL_NOT_A_MATCH → NOT_A_MATCH (profile_id = lakefusion_id)
            MANUAL_ACTION_MAP = {
                'MANUAL_MERGE': ['MERGE', 'MERGE_ALL'],
                'MANUAL_UNMERGE': ['UNMERGE'],
                'MANUAL_NOT_A_MATCH': ['NOT_A_MATCH'],
                'MANUAL_UPDATE': ['MANUAL_UPDATE'],
                'MASTER_MANUAL_MERGE': ['MERGE', 'MERGE_ALL'],
                'MASTER_FORCE_MERGE': ['FORCE_MERGE'],
                'MASTER_MANUAL_NOT_A_MATCH': ['NOT_A_MATCH'],
            }
            if data:
                try:
                    jobs = (
                        self.db.query(Model_Databricks_Entity_Search_Job)
                        .filter(Model_Databricks_Entity_Search_Job.entity_id == entity_id)
                        .filter(Model_Databricks_Entity_Search_Job.master_id == profile_id)
                        .all()
                    )

                    for item in data:
                        if not isinstance(item, dict):
                            continue
                        action = item.get("action_type", "")
                        job_ops = MANUAL_ACTION_MAP.get(action)
                        if not job_ops:
                            continue  # Skip non-manual operations (INITIAL_LOAD, JOB_MERGE, etc.)

                        match_id = item.get("match_id") or item.get("match_lakefusion_id", "")
                        activity_ts = item.get("created_at")

                        # Parse activity timestamp to naive UTC datetime
                        act_dt = None
                        if activity_ts:
                            try:
                                ts_str = str(activity_ts)
                                # Strip timezone info to get naive datetime for comparison
                                for suffix in ["+00:00", "Z", "+00", ".000+00:00"]:
                                    ts_str = ts_str.replace(suffix, "")
                                # Handle fractional seconds
                                if "." in ts_str:
                                    act_dt = datetime.strptime(ts_str, "%Y-%m-%dT%H:%M:%S.%f")
                                elif "T" in ts_str:
                                    act_dt = datetime.strptime(ts_str, "%Y-%m-%dT%H:%M:%S")
                                else:
                                    act_dt = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S")
                            except Exception:
                                act_dt = None

                        # Find closest matching job by (match_id, operation_type, nearest created_at)
                        user = None
                        best_delta = None
                        for job in jobs:
                            if job.profile_id == match_id and job.operation_type in job_ops:
                                if act_dt and job.created_at:
                                    delta = abs((act_dt - job.created_at).total_seconds())
                                    if best_delta is None or delta < best_delta:
                                        best_delta = delta
                                        user = job.created_by
                                elif not user:
                                    user = job.created_by
                        item["performed_by"] = user or None
                except Exception as e:
                    app_logger.warning(f"Could not enrich merge activities with usernames: {e}")

            return data

        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "read merge activities")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch merge activities. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch merge activities: {str(e)}"
            )

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # ERRORED RECORDS (unified_error_prod)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def fetch_errored_records(self, token: str, entity_id: int, warehouse_id: str, page: int = 1, page_size: int = 50, error_stage: str = None):
        """Fetch errored records from _unified_error_prod, joined with _unified_prod
        to get the primary key value. Parses error_message to extract attribute and source value.
        """
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            catalog_config = self.db.query(DBConfigProperties).filter(
                DBConfigProperties.config_key == "catalog_name"
            ).first()
            catalog = catalog_config.config_value if catalog_config else "hive_metastore"

            tilde = self._common_utils.apply_tilde
            error_table = tilde(f"{catalog}.silver.{entity_name}_unified_error_prod")

            where_parts = []
            if error_stage:
                where_parts.append(f"e.error_stage = '{error_stage}'")
            where_clause = f"WHERE {' AND '.join(where_parts)}" if where_parts else ""

            offset = (page - 1) * page_size
            sql = (
                f"SELECT e.surrogate_key, e.error_message, e.error_stage, e.error_timestamp, e.run_id, "
                f"COUNT(*) OVER() AS _total "
                f"FROM {error_table} e "
                f"{where_clause} "
                f"ORDER BY e.error_timestamp DESC "
                f"LIMIT {page_size} OFFSET {offset}"
            )

            rows = DataSetSQLService(token, warehouse_id).execute_dataset(sql)
            total_count = rows[0]['_total'] if rows else 0
            records = []
            for r in (rows or []):
                row = r if isinstance(r, dict) else dict(r)
                row.pop('_total', None)
                # Parse error_message: FORMAT = ATTRIBUTE=REASON(SOURCE_VALUE)
                msg = row.get('error_message', '')
                attr_name = ''
                reason = ''
                source_value = ''
                if '=' in msg and '(' in msg:
                    attr_name = msg.split('=')[0]
                    rest = msg.split('=', 1)[1]
                    if '(' in rest and rest.endswith(')'):
                        reason = rest.split('(')[0]
                        source_value = rest.split('(', 1)[1].rstrip(')')
                    else:
                        reason = rest
                row['parsed_attribute'] = attr_name
                row['parsed_reason'] = reason
                row['parsed_source_value'] = source_value
                records.append(row)

            has_more = (offset + len(records)) < total_count
            return HttpResponse(status=200, data=records, totalCount=total_count, has_more=has_more)

        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to fetch errored records for entity {entity_id}: {message}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch errored records: {str(e)}")

    def fetch_errored_record_detail(self, token: str, entity_id: int, warehouse_id: str, surrogate_key: str):
        """Fetch full record from _unified_prod by surrogate_key for the error detail dialog."""
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(' ', '_')
            catalog_config = self.db.query(DBConfigProperties).filter(
                DBConfigProperties.config_key == "catalog_name"
            ).first()
            catalog = catalog_config.config_value if catalog_config else "hive_metastore"

            tilde = self._common_utils.apply_tilde
            unified_table = tilde(f"{catalog}.silver.{entity_name}_unified_prod")
            safe_key = str(surrogate_key).replace("'", "''")

            rows = DataSetSQLService(token, warehouse_id).execute_dataset(
                f"SELECT * FROM {unified_table} WHERE surrogate_key = '{safe_key}' LIMIT 1"
            )
            if not rows:
                raise HTTPException(status_code=404, detail=f"Record with surrogate_key '{surrogate_key}' not found")

            return rows[0] if isinstance(rows[0], dict) else dict(rows[0])

        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to fetch errored record detail: {message}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch errored record detail: {str(e)}")

    def read_entity_validation_data(self,entity_id:int,warehouse_id:str,validation_type:Literal["error","warning"],token:str, page:int=1, page_size:int=1000):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            validation_function_warning_enabled = FeatureFlagService._is_feature_flag_enabled(
                self.db,
                'ENABLE_VALIDATION_FUNCTION_WARNING_FEATURE'
            )
            if not validation_function_warning_enabled:
                # Hide the API as if it does not exist
                raise HTTPException(
                    status_code=404,
                    detail="This API is disabled."
                )
            entity_conn=EntityService(db=self.db)
            entity=entity_conn.get_full_entity_by_id(entity_id)
            validation_funcs = [attr for attr in entity.validation_functions
                               if attr.validation_level == validation_type]
            attribute_names = [attr.attribute_name for attr in validation_funcs]
            entity_name = entity.name.lower().replace(" ", "_")
            entity_primary = "lakefusion_id"
            select_b = [f"b.{entity_primary}"]
            # Build dynamic SELECT parts
            select_b += [
            f"b.{attr.name}" for attr in entity.attributes
            if attr.name != "attributes_combined" and attr.name not in attribute_names]
            select_a = ', '.join([f"'{attr}'" for attr in attribute_names])
            
            where_conditions = [f"t.{attr} IS NOT NULL" for attr in attribute_names]

            where_clause = " OR ".join(where_conditions)
            select_attrs = []
           
            for attr in attribute_names:
                # alias: FullName -> FullName_obj
                select_attrs.append(
                        f"named_struct('value', b.{attr}, 'status', t.{attr}) AS {attr}"
                    )
                

            # Join select parts
            select_clause = ", ".join(select_b + select_attrs)

            # Build pivot list for SQL
            select_a = ', '.join([f"'{attr}'" for attr in attribute_names])

            offset = (page - 1) * page_size

            query = f"""
                SELECT {select_clause}, COUNT(*) OVER() AS total_count
                FROM (SELECT * FROM
                         (SELECT distinct lakefusion_id,attribute_name,status FROM {self.catalog_name}.gold.{entity_name}_master_{validation_type}_prod ) a
                         PIVOT (
                             FIRST(status)
                             FOR attribute_name IN ({select_a})
                         ) ) t
                JOIN {self.catalog_name}.gold.{entity_name}_master_prod b
                  ON t.{entity_primary} = b.{entity_primary} WHERE {where_clause}
                LIMIT {page_size} OFFSET {offset}
            """
            print(query)
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            data = sqlservice_conn.execute_dataset(query=query)
            for i, record in enumerate(data):
                if isinstance(record, dict):
                    data[i] = serialize_row_data(record)

            total_count = data[0]['total_count'] if data and 'total_count' in data[0] else 0
            if data:
                for record in data:
                    record_dict = dict(record) if not isinstance(record, dict) else record
                    record_dict.pop('total_count', None)

            total_pages = math.ceil(total_count / page_size) if page_size > 0 else 0

            return {
                "data": data,
                "pagination": {
                    "page": page,
                    "page_size": page_size,
                    "total_count": total_count,
                    "total_pages": total_pages
                }
            }


        except HTTPException:
            raise
        except Exception as e:
            raise_on_dbx_permission_error(e, "read validation data")
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity validation {validation_type} records. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity validation {validation_type} records: {str(e)}"
            )

        finally:
            # Ensure the session is closed properly
            self.db.close()

    # ═══════════════════════════════════════════════════════════════════════════
    # Reference Entity Methods
    # ═══════════════════════════════════════════════════════════════════════════

    _common_utils = CommonUtilities()

    _ATTR_TYPE_MAP = {
        "string": "STRING", "text": "STRING",
        "integer": "BIGINT", "int": "BIGINT",
        "float": "DOUBLE", "double": "DOUBLE",
        "decimal": "DECIMAL(38,10)",
        "boolean": "BOOLEAN", "bool": "BOOLEAN",
        "date": "DATE",
        "timestamp": "TIMESTAMP", "datetime": "TIMESTAMP",
    }

    REVIEW_STATUSES = ("PENDING", "NO_MATCH")
    APPROVED_STATUSES = ("AUTO_APPROVED", "APPROVED", "MANUALLY_ADDED")
    REJECTED_STATUSES = ("REJECTED",)

    def _get_ref_catalog_and_entity(self, entity_id: int):
        entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
        if not entity:
            raise HTTPException(status_code=404, detail=f"Entity {entity_id} not found")
        catalog_config = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
        )
        catalog = catalog_config.config_value if catalog_config else "lakefusion_ai"
        return catalog, entity.name.lower().replace(" ", "_")

    def get_primary_field_for_entity(self, entity_id: int) -> str | None:
        pk_attr = (
            self.db.query(EntityAttributes)
            .filter(EntityAttributes.entity_id == entity_id, EntityAttributes.is_primary_key == True)
            .first()
        )
        return pk_attr.name if pk_attr else None

    def _attr_type_to_sql(self, attr_type: str) -> str:
        return self._ATTR_TYPE_MAP.get((attr_type or "string").lower(), "STRING")

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # LAKEBASE DISPATCH HELPERS
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # Reference entities with storage_type='lakebase' have:
    #   - Reads from `<sync_catalog>.<schema>.lb_<table>_history` in UC,
    #     populated by Lakehouse Sync (used via LakebaseReadOps.table_ref()
    #     inside warehouse SQL OR via .read() for Spark/DataFrame paths).
    #   - Writes to the underlying Postgres table directly via
    #     LakebasePgClient (psycopg2). Warehouse SQL CANNOT write to
    #     Lakebase Postgres — INSERTs/UPDATEs/DELETEs must go through
    #     this client.

    def _is_lakebase_entity(self, entity) -> bool:
        return entity is not None and getattr(entity, "storage_type", None) == "lakebase"

    def _entity_pg_schema(self, entity) -> str:
        """Postgres schema for this entity (= sanitized entity name)."""
        return entity.name.lower().replace(" ", "_")

    def _ref_pg_paths(self, entity, master_path: str, audit_path: str):
        """Resolve UC reference-table paths to Postgres (schema, table) pairs.

        Lakebase synced tables mirror the UC schema and append a `_synced`
        suffix to the table name (matching the `synced_table_id` naming
        used by LakebaseWriteOps.create_table). The Postgres database is
        the entity-level Lakebase instance, configured on the client.

        UC `lakefusion_dev.gold.acme_reference_prod`
          -> ("gold", "acme_reference_prod_synced")
        """
        def split(uc_path: str):
            parts = uc_path.split(".")
            if len(parts) != 3:
                raise ValueError(
                    f"Expected 3-part UC table name (catalog.schema.table), got: {uc_path}"
                )
            _, schema, table = parts
            return (schema, f"{table}_synced")

        return split(master_path), split(audit_path)

    def _get_lakebase_pg_client(self, entity, token: Optional[str] = None) -> LakebasePgClient:
        """Construct a per-request LakebasePgClient bound to the entity's
        Postgres database. Each entity lives in its own Lakebase database
        named after the (sanitized) entity name — synced tables land at
        <entity_name>.<gold>.<table>_synced.

        The Lakebase SDK calls (list_projects / generate_database_credential /
        pipeline triggers) prefer the SERVICE identity, falling back to the
        caller's token when no service credential is configured:
          - `get_app_sp_token()` -> LAKEFUSION_DATABRICKS_DAPI (K8s) or "" in
            Databricks Apps (then App SP auto-auth).
          - if that's empty, use the user `token`.
        NOTE: the Lakebase postgres API requires an identity with Lakebase
        permissions. A bare user token may be rejected ("403 Invalid Token"),
        and a missing service credential surfaces as "cannot configure
        default credentials" — both are environment/permission issues, not
        code bugs. See _create_workspace_client / get_app_sp_token.

        Caller is responsible for closing it (use as a context manager).
        """
        ws = _create_workspace_client(get_app_sp_token() or token)
        return LakebasePgClient.from_db_config(
            self.db_config_service,
            database=self._entity_pg_schema(entity),
            workspace_client=ws,
        )

    # NOTE: The former `_replay_to_delta_async` / `_create_sync_log` /
    # `_finalize_sync_log` / `_trigger_synced_table_sync` helpers were removed.
    # Lakebase UI writes are no longer pushed to Delta directly. Each write goes
    # to the Postgres synced tables only; the change-log triggers capture it into
    # gold."{entity}_change_log", and the Sync_Lakebase_Changelog_To_Delta
    # workflow merges the change-log into Delta on the pipeline schedule. This
    # gives a single, ordered Delta-write path (no background replay race, no
    # lakebase_delta_sync_log bookkeeping).

    def _check_ref_table_exists(self, token: str, warehouse_id: str, table_path: str) -> bool:
        return CatalogService(token, self.db).check_table_exists(table_path)

    def _normalize_filters(self, filters):
        """Common filter parsing — handles URL-encoded JSON strings and raw lists.
        Returns the parsed list or None if filters are empty/invalid.
        """
        if isinstance(filters, str):
            if '%' in filters:
                import urllib.parse
                try:
                    filters = urllib.parse.unquote(filters)
                except Exception:
                    pass
            if not filters.strip():
                return None
            try:
                filters = json.loads(filters)
            except json.JSONDecodeError:
                return None
        if not filters or not isinstance(filters, list):
            return None
        return filters

    def _build_ref_filter_clauses_pg(self, filters, table_alias=None):
        """Postgres-flavored filter builder.

        Returns (sql, params) where placeholders are %s and identifiers are
        double-quoted. Mirrors _build_ref_filter_clauses but parameterizes
        values rather than inlining them — psycopg2-safe.
        """
        filters = self._normalize_filters(filters)
        if not filters:
            return "", ()

        prefix = f'{table_alias}.' if table_alias else ''
        clauses = []
        params: list = []
        for i, f in enumerate(filters):
            attr = f.get('attributeId') or f.get('attributeName')
            op = f.get('operator')
            val = f.get('value')
            conj = f.get('conjunction', 'AND')
            if not attr or not op:
                continue
            col = f'{prefix}"{attr}"'
            sql_clause = ""
            if op == 'eq':
                sql_clause = f"{col} = %s"
                params.append(val)
            elif op == 'neq':
                sql_clause = f"{col} <> %s"
                params.append(val)
            elif op == 'contains':
                sql_clause = f"{col} LIKE %s"
                params.append(f"%{val}%")
            elif op == 'icontains':
                sql_clause = f"{col} ILIKE %s"
                params.append(f"%{val}%")
            elif op == 'not_contains':
                sql_clause = f"{col} NOT LIKE %s"
                params.append(f"%{val}%")
            elif op == 'starts_with':
                sql_clause = f"{col} LIKE %s"
                params.append(f"{val}%")
            elif op == 'ends_with':
                sql_clause = f"{col} LIKE %s"
                params.append(f"%{val}")
            elif op in ('gt', 'lt', 'gte', 'lte'):
                try:
                    safe_num = float(val)
                except (TypeError, ValueError):
                    continue
                op_sym = {'gt': '>', 'lt': '<', 'gte': '>=', 'lte': '<='}[op]
                sql_clause = f"{col} {op_sym} %s"
                params.append(safe_num)
            elif op == 'is_null':
                sql_clause = f"{col} IS NULL"
            elif op == 'is_not_null':
                sql_clause = f"{col} IS NOT NULL"
            elif op == 'eq_true':
                sql_clause = f"{col} = TRUE"
            elif op == 'eq_false':
                sql_clause = f"{col} = FALSE"
            if sql_clause:
                if clauses:
                    clauses.append(conj)
                clauses.append(sql_clause)
        return (" ".join(clauses), tuple(params)) if clauses else ("", ())

    def _build_ref_filter_clauses(self, filters, table_alias=None):
        try:
            if isinstance(filters, str):
                if '%' in filters:
                    import urllib.parse
                    try:
                        filters = urllib.parse.unquote(filters)
                    except Exception:
                        pass
                if filters.strip():
                    try:
                        filters = json.loads(filters)
                    except json.JSONDecodeError:
                        return "", []
                else:
                    return "", []
            if not filters or not isinstance(filters, list):
                return "", []
            prefix = f"{table_alias}." if table_alias else ""
            filter_clauses = []
            for i, f in enumerate(filters):
                # attributeId is the actual column name; attributeName is the display label.
                # Prefer attributeId to ensure correct SQL column references.
                attr = f.get('attributeId') or f.get('attributeName')
                op = f.get('operator')
                val = f.get('value')
                conj = f.get('conjunction', 'AND')
                if not attr or not op:
                    continue
                col = f"{prefix}`{attr}`"
                safe_val = str(val).replace("'", "''") if val is not None else ""
                sql_clause = ""
                if op == 'eq':             sql_clause = f"{col} = '{safe_val}'"
                elif op == 'neq':          sql_clause = f"{col} != '{safe_val}'"
                elif op == 'contains':     sql_clause = f"{col} LIKE '%{safe_val}%'"
                elif op == 'icontains':    sql_clause = f"{col} ILIKE '%{safe_val}%'"
                elif op == 'not_contains': sql_clause = f"{col} NOT LIKE '%{safe_val}%'"
                elif op == 'starts_with':  sql_clause = f"{col} LIKE '{safe_val}%'"
                elif op == 'ends_with':    sql_clause = f"{col} LIKE '%{safe_val}'"
                elif op in ('gt', 'lt', 'gte', 'lte'):
                    try:
                        safe_num = float(val)
                    except (TypeError, ValueError):
                        continue
                    op_sym = {'gt': '>', 'lt': '<', 'gte': '>=', 'lte': '<='}[op]
                    sql_clause = f"{col} {op_sym} {safe_num}"
                elif op == 'is_null':      sql_clause = f"{col} IS NULL"
                elif op == 'is_not_null':  sql_clause = f"{col} IS NOT NULL"
                elif op == 'eq_true':      sql_clause = f"{col} = TRUE"
                elif op == 'eq_false':     sql_clause = f"{col} = FALSE"
                if sql_clause:
                    if i > 0:
                        filter_clauses.append(conj)
                    filter_clauses.append(sql_clause)
            return (" ".join(filter_clauses), []) if filter_clauses else ("", [])
        except Exception as e:
            app_logger.error(f"Error building filter clauses: {str(e)}")
            return "", []

    # ── Reference Table ───────────────────────────────────────────────────────

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # PATH HELPERS
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def get_reference_table_path(self, entity_id: int) -> tuple[str, str]:
        """Returns the MASTER table path (business columns only, current state)."""
        catalog, entity_name_snake = self._get_ref_catalog_and_entity(entity_id)
        return f"{catalog}.gold.{entity_name_snake}_reference_prod", entity_name_snake

    def get_reference_audit_table_path(self, entity_id: int) -> tuple[str, str]:
        """Returns the AUDIT table path — append-only SCD-2 history + provenance."""
        catalog, entity_name_snake = self._get_ref_catalog_and_entity(entity_id)
        return f"{catalog}.gold.{entity_name_snake}_reference_audit_prod", entity_name_snake

    def get_reference_meta_table_path(self, entity_id: int) -> tuple[str, str]:
        """DEPRECATED — meta table consolidated, then split into audit. Kept
        as an alias of master for backwards compatibility with old callers."""
        return self.get_reference_table_path(entity_id)

    def get_reference_view_path(self, entity_id: int) -> tuple[str, str]:
        """DEPRECATED — the SCD-2 view was removed when master/audit split.
        Master IS the current state; readers should query master directly.
        Returns master path so existing callers continue to work."""
        return self.get_reference_table_path(entity_id)

    def get_reference_review_table_path(self, entity_id: int) -> tuple[str, str]:
        catalog, entity_name_snake = self._get_ref_catalog_and_entity(entity_id)
        return f"{catalog}.gold.{entity_name_snake}_reference_conflict_queue_prod", entity_name_snake

    def get_reference_mappings_table_path(self, entity_id: int) -> tuple[str, str]:
        catalog, entity_name_snake = self._get_ref_catalog_and_entity(entity_id)
        return f"{catalog}.gold.{entity_name_snake}_reference_mappings_prod", entity_name_snake

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # TABLE EXISTENCE CHECK
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def check_reference_entity_tables_existence(self, token: str, entity_id: int, warehouse_id: str) -> dict:
        master_path, _   = self.get_reference_table_path(entity_id)
        audit_path, _    = self.get_reference_audit_table_path(entity_id)
        review_path, _   = self.get_reference_review_table_path(entity_id)
        mappings_path, _ = self.get_reference_mappings_table_path(entity_id)

        entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)

        app_logger.info(
            f"[lakebase-routing] check_reference_entity_tables_existence "
            f"entity_id={entity_id} storage_type={getattr(entity, 'storage_type', None)!r} -> "
            f"{'LAKEBASE(pg)' if self._is_lakebase_entity(entity) else 'DELTA(warehouse)'}"
        )

        if self._is_lakebase_entity(entity):
            # Master + audit live in Postgres as synced tables; check
            # there. Mappings table stays in UC (per scope) so leave it
            # on the warehouse check.
            (pg_schema_m, pg_table_m), (pg_schema_a, pg_table_a) = self._ref_pg_paths(
                entity, master_path, audit_path,
            )
            with self._get_lakebase_pg_client(entity, token=token) as pg:
                master_exists = self._pg_table_exists(pg, pg_schema_m, pg_table_m)
                audit_exists  = self._pg_table_exists(pg, pg_schema_a, pg_table_a)
            return {
                "reference_data_table_exists":     master_exists,
                "reference_view_exists":           master_exists,
                "reference_meta_table_exists":     master_exists,
                "reference_audit_table_exists":    audit_exists,
                "reference_review_table_exists":   self._check_ref_table_exists(token, warehouse_id, review_path),
                "reference_mappings_table_exists": self._check_ref_table_exists(token, warehouse_id, mappings_path),
            }

        master_exists = self._check_ref_table_exists(token, warehouse_id, master_path)
        # `reference_data_table_exists` / `reference_view_exists` /
        # `reference_meta_table_exists` are kept for backwards compat — they
        # all mirror master existence now (the view was removed; meta was
        # folded in earlier and is now split into audit).
        return {
            "reference_data_table_exists":     master_exists,
            "reference_view_exists":           master_exists,
            "reference_meta_table_exists":     master_exists,
            "reference_audit_table_exists":    self._check_ref_table_exists(token, warehouse_id, audit_path),
            "reference_review_table_exists":   self._check_ref_table_exists(token, warehouse_id, review_path),
            "reference_mappings_table_exists": self._check_ref_table_exists(token, warehouse_id, mappings_path),
        }

    def _pg_table_exists(self, pg, schema: str, table: str) -> bool:
        """information_schema lookup for a (schema, table) pair in Postgres."""
        rows = pg.query(
            "SELECT 1 FROM information_schema.tables "
            "WHERE table_schema = %s AND table_name = %s LIMIT 1",
            (schema, table),
        )
        return bool(rows)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # CREATE TABLES  (data + meta + view)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def _create_reference_table(self, token: str, entity_id: int, warehouse_id: str):
        """Creates the master + audit reference tables.

        - master ({entity}_reference_prod): business columns only, current state.
          One row per ref_lakefusion_id.
        - audit  ({entity}_reference_audit_prod): append-only SCD-2 history with
          valid_from / valid_to / is_current / version / source plus full
          steward/provenance fields.
        """
        master_path, _ = self.get_reference_table_path(entity_id)
        audit_path, _  = self.get_reference_audit_table_path(entity_id)

        attrs = (
            self.db.query(EntityAttributes)
            .filter(EntityAttributes.entity_id == entity_id, EntityAttributes.is_active == True)
            .all()
        )
        if not attrs:
            raise HTTPException(
                status_code=400,
                detail="Entity has no active attributes; cannot create table."
            )

        pk_attr = next((a for a in attrs if a.is_primary_key), None)
        if not pk_attr:
            raise HTTPException(
                status_code=400,
                detail="Entity has no primary key attribute; cannot create reference tables."
            )

        tilde = self._common_utils.apply_tilde

        # DataSetSQLService.execute_dataset() closes its connection after each
        # call, so reusing one instance across multiple DDL statements fails on
        # the 2nd with "Cannot create cursor from closed connection". Run each
        # DDL on its own short-lived service.
        def sql_svc_run(q):
            DataSetSQLService(token, warehouse_id).execute_dataset(q)

        business_col_defs = ", ".join(
            f"{tilde(a.name)} {self._attr_type_to_sql(a.type)}" for a in attrs
        )

        # ── MASTER table — business cols only, current state ───────────────────
        master_cols = (
            "`ref_lakefusion_id` STRING NOT NULL"
            f", {business_col_defs}"
        )
        master_ddl = (
            f"CREATE TABLE IF NOT EXISTS {tilde(master_path)} "
            f"({master_cols}) USING DELTA "
            f"TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', "
            f"'delta.feature.allowColumnDefaults' = 'supported')"
        )
        app_logger.info(f"Creating reference MASTER table '{master_path}'")
        sql_svc_run(master_ddl)

        # ── AUDIT table — append-only SCD-2 history + provenance ───────────────
        audit_cols = (
            "`ref_lakefusion_id` STRING NOT NULL"
            f", {business_col_defs}"
            ", `valid_from` TIMESTAMP NOT NULL"
            ", `valid_to`   TIMESTAMP"
            ", `is_current` BOOLEAN  NOT NULL"
            ", `version`    INT      NOT NULL"
            ", `source`     STRING"
            ", `action_type` STRING"
            ", `steward_locked` BOOLEAN NOT NULL"
            ", `steward_edited_cols` ARRAY<STRING>"
            ", `steward_edited_by` STRING"
        )
        audit_ddl = (
            f"CREATE TABLE IF NOT EXISTS {tilde(audit_path)} "
            f"({audit_cols}) USING DELTA "
            f"TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', "
            f"'delta.feature.allowColumnDefaults' = 'supported')"
        )
        app_logger.info(f"Creating reference AUDIT table '{audit_path}'")
        sql_svc_run(audit_ddl)
        sql_svc_run(
            f"ALTER TABLE {tilde(audit_path)} ALTER COLUMN `valid_from` SET DEFAULT current_timestamp()"
        )
        sql_svc_run(
            f"ALTER TABLE {tilde(audit_path)} ALTER COLUMN `is_current` SET DEFAULT TRUE"
        )
        sql_svc_run(
            f"ALTER TABLE {tilde(audit_path)} ALTER COLUMN `steward_locked` SET DEFAULT FALSE"
        )

        # Lakebase entities: after the Delta DDL succeeds, provision a
        # Databricks Lakebase synced table for master + audit so UI reads
        # and writes land in Postgres (same pattern as LakebaseWriteOps,
        # but invoked from the middlelayer rather than a Spark notebook).
        entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)
        if self._is_lakebase_entity(entity):
            self._provision_lakebase_synced_tables(
                entity, master_path, audit_path,
                primary_key_columns=["ref_lakefusion_id"],
                token=token,
            )

    def _provision_lakebase_synced_tables(
        self,
        entity,
        master_path: str,
        audit_path: str,
        primary_key_columns: list,
        token: Optional[str] = None,
    ) -> None:
        """Create Databricks Lakebase synced tables for the given UC master
        and audit Delta tables. Idempotent — existing synced tables are
        skipped via a `get_synced_table` probe.

        The Postgres database name is the sanitized entity name (matching
        _get_lakebase_pg_client). Branch / endpoint / scheduling policy are
        read from db_config_properties. The WorkspaceClient is authenticated
        with the caller's token (the middlelayer has no default SDK creds).
        """
        from databricks.sdk.errors import NotFound
        from databricks.sdk.service.postgres import (
            SyncedTable,
            SyncedTableSyncedTableSpec,
            SyncedTableSyncedTableSpecSyncedTableSchedulingPolicy,
        )

        instance_id = self.db_config_service.getDBConfigProperties(
            "lakebase_instance_id", required=True
        )
        branch_id = self.db_config_service.getDBConfigProperties(
            "lakebase_branch_id"
        ) or "production"
        policy_name = (
            self.db_config_service.getDBConfigProperties("lakebase_scheduling_policy")
            or "SNAPSHOT"
        ).upper()
        policy_map = {
            "SNAPSHOT":   SyncedTableSyncedTableSpecSyncedTableSchedulingPolicy.SNAPSHOT,
            "TRIGGERED":  SyncedTableSyncedTableSpecSyncedTableSchedulingPolicy.TRIGGERED,
            "CONTINUOUS": SyncedTableSyncedTableSpecSyncedTableSchedulingPolicy.CONTINUOUS,
        }
        if policy_name not in policy_map:
            raise HTTPException(
                status_code=500,
                detail=f"Unsupported lakebase_scheduling_policy '{policy_name}'.",
            )

        pg_database = self._entity_pg_schema(entity)
        # Prefer the service identity; fall back to the caller's token when no
        # service credential is configured.
        ws = _create_workspace_client(get_app_sp_token() or token)

        for source_table in (master_path, audit_path):
            synced_id = f"{source_table}_synced"
            try:
                existing = ws.postgres.get_synced_table(name=synced_id)
                app_logger.info(
                    f"Lakebase synced table {existing.name} already exists; skipping."
                )
                continue
            except NotFound:
                pass

            app_logger.info(
                f"Provisioning Lakebase synced table {synced_id} "
                f"(database={pg_database}, policy={policy_name})"
            )
            ws.postgres.create_synced_table(
                synced_table=SyncedTable(spec=SyncedTableSyncedTableSpec(
                    source_table_full_name=source_table,
                    branch=f"projects/{instance_id}/branches/{branch_id}",
                    primary_key_columns=primary_key_columns,
                    scheduling_policy=policy_map[policy_name],
                    postgres_database=pg_database,
                    create_database_objects_if_missing=True,
                )),
                synced_table_id=synced_id,
            ).wait()

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # FETCH RECORDS  (reads through the unified view)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    def _apply_filters_where(self, filters) -> str:
        if not filters:
            return ""
        if isinstance(filters, str):
            import urllib.parse as _up
            if "%" in filters:
                try:
                    filters = _up.unquote(filters)
                except Exception:
                    pass
            try:
                filters = json.loads(filters)
            except json.JSONDecodeError:
                return ""
        if isinstance(filters, list) and filters:
            filter_clause, _ = self._build_ref_filter_clauses(filters)
            if filter_clause:
                return f"WHERE {filter_clause}"
        return ""

    def fetch_reference_records(
        self, token: str, entity_id: int, warehouse_id: str,
        page: int = 1, page_size: int = 50, filters=None
    ):
        """Reads the master reference table — one row per ref_lakefusion_id,
        always current state. No is_current filter or join needed.

        - Delta entities: warehouse SQL against the UC master table.
        - Lakebase entities: psycopg2 against the Postgres master table
          (same logical name, different instance — no lb_*_history hop).
        """
        entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)
        master_path, _ = self.get_reference_table_path(entity_id)
        primary_field  = self.get_primary_field_for_entity(entity_id)
        offset = (page - 1) * page_size

        app_logger.info(
            f"[lakebase-routing] fetch_reference_records entity_id={entity_id} "
            f"storage_type={getattr(entity, 'storage_type', None)!r} -> "
            f"{'LAKEBASE(pg)' if self._is_lakebase_entity(entity) else 'DELTA(warehouse)'}"
        )

        if self._is_lakebase_entity(entity):
            (pg_schema, pg_table), _ = self._ref_pg_paths(entity, master_path, master_path)
            where_sql, where_params = self._build_ref_filter_clauses_pg(filters)
            where_clause = f"WHERE {where_sql}" if where_sql else ""
            order_clause = f'ORDER BY "{primary_field}"' if primary_field else ""
            sql = (
                f'SELECT *, COUNT(*) OVER() AS _total '
                f'FROM "{pg_schema}"."{pg_table}" '
                f'{where_clause} {order_clause} '
                f'LIMIT {int(page_size)} OFFSET {int(offset)}'
            )
            with self._get_lakebase_pg_client(entity, token=token) as pg:
                # Existence is checked in Postgres (the synced table), NOT in
                # Delta — for a lakebase entity the UI reads the synced PG
                # table. If it isn't provisioned yet, return empty instead of
                # raising a raw "relation does not exist".
                if not self._pg_table_exists(pg, pg_schema, pg_table):
                    return HttpResponse(status=200, data=[], totalCount=0, has_more=False)
                rows = pg.query(sql, where_params or None)
        else:
            tilde        = self._common_utils.apply_tilde
            master_table = self._common_utils.apply_tilde(master_path)
            filter_clause = self._apply_filters_where(filters)
            where_clause  = filter_clause or ""
            order_clause  = f"ORDER BY {tilde(primary_field)}" if primary_field else ""
            sql_service = DataSetSQLService(token, warehouse_id)
            rows = sql_service.execute_dataset(
                f"SELECT *, COUNT(*) OVER() AS _total FROM {master_table} {where_clause} {order_clause} "
                f"LIMIT {page_size} OFFSET {offset}"
            )

        total_count = rows[0]['_total'] if rows else 0
        rows = [{k: v for k, v in r.items() if k != '_total'} for r in rows]
        has_more = (offset + len(rows)) < total_count
        return HttpResponse(status=200, data=rows, totalCount=total_count, has_more=has_more)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # SINGLE REFERENCE RECORD PROFILE + HISTORY (SCD-2)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    _SCD2_PROVENANCE_COLS = {
        "valid_from", "valid_to", "is_current", "version", "source",
        "is_active", "action_type", "steward_locked",
        "steward_edited_cols", "steward_edited_by",
        "steward_edited_at", "created_at", "updated_at",
    }

    def get_reference_profile_by_id(self, token: str, entity_id: int, ref_lakefusion_id: str, warehouse_id: str):
        """Fetch the current version of a single reference record by ref_lakefusion_id.

        - Delta entities: warehouse SQL against the master table (current state).
        - Lakebase entities: psycopg2 against the Postgres master table
          (same logical name; Postgres is the live source of truth).

        Strips SCD-2/provenance columns so the response contains only
        business attributes + ref_lakefusion_id.
        """
        try:
            entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)

            if self._is_lakebase_entity(entity):
                master_path, _ = self.get_reference_table_path(entity_id)
                (pg_schema, pg_table), _ = self._ref_pg_paths(entity, master_path, master_path)
                with self._get_lakebase_pg_client(entity, token=token) as pg:
                    rows = pg.query(
                        f'SELECT * FROM "{pg_schema}"."{pg_table}" '
                        f'WHERE "ref_lakefusion_id" = %s LIMIT 1',
                        (ref_lakefusion_id,),
                    )
            else:
                safe_ref = str(ref_lakefusion_id).replace("'", "''")
                view_path, _ = self.get_reference_view_path(entity_id)
                from_clause = self._common_utils.apply_tilde(view_path)
                rows = DataSetSQLService(token, warehouse_id).execute_dataset(
                    f"SELECT * FROM {from_clause} WHERE `ref_lakefusion_id` = '{safe_ref}' LIMIT 1"
                )

            if not rows:
                raise HTTPException(status_code=404, detail=f"Reference record '{ref_lakefusion_id}' not found")

            row = rows[0] if isinstance(rows[0], dict) else dict(rows[0])
            return {k: v for k, v in row.items() if k not in self._SCD2_PROVENANCE_COLS}

        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to fetch reference profile {ref_lakefusion_id}: {message}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch reference profile: {str(e)}")

    def get_reference_record_history(self, token: str, entity_id: int, ref_lakefusion_id: str, warehouse_id: str):
        """Fetch all SCD-2 versions of a reference record from the audit table.
        Returns all versions (current + expired + tombstones) ordered newest first.

        Both storage types use the same audit schema (master + audit tables
        with `version`/`valid_from`/`valid_to`/`is_current` columns). Only
        the connection differs:
          - Delta entities: warehouse SQL against the UC audit table.
          - Lakebase entities: psycopg2 against the Postgres audit table.
        """
        try:
            entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)
            audit_path, _ = self.get_reference_audit_table_path(entity_id)

            if self._is_lakebase_entity(entity):
                _, (pg_schema, pg_table) = self._ref_pg_paths(entity, audit_path, audit_path)
                with self._get_lakebase_pg_client(entity, token=token) as pg:
                    rows = pg.query(
                        f'SELECT * FROM "{pg_schema}"."{pg_table}" '
                        f'WHERE "ref_lakefusion_id" = %s '
                        f'ORDER BY "version" DESC',
                        (ref_lakefusion_id,),
                    )
            else:
                safe_ref = str(ref_lakefusion_id).replace("'", "''")
                from_clause = self._common_utils.apply_tilde(audit_path)
                rows = DataSetSQLService(token, warehouse_id).execute_dataset(
                    f"SELECT * "
                    f"FROM {from_clause} "
                    f"WHERE `ref_lakefusion_id` = '{safe_ref}' "
                    f"ORDER BY `version` DESC"
                )

            versions = [r if isinstance(r, dict) else dict(r) for r in (rows or [])]
            return HttpResponse(status=200, data=versions, totalCount=len(versions))

        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to fetch reference record history for {ref_lakefusion_id}: {message}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch reference record history: {str(e)}")

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # RESOLVE CONFLICT  (writes to correct table per column ownership)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

   
    def _scd2_apply_steward_change(
        self,
        token: str,
        warehouse_id: str,
        master_table: str,
        audit_table: str,
        ref_lakefusion_id: str,
        overrides: dict,
        action_type: str,
        steward_locked: bool,
        steward_edited_cols: list,
        steward_edited_by: str,
    ):
        """Master + audit helper for steward-driven changes.

        1. Reads current biz values from master.
        2. Reads prior version + source from audit (current row).
        3. UPDATE master with merged biz values.
        4. EXPIRE prior audit current row (is_current=FALSE, valid_to=cutover).
        5. APPEND new audit row with full provenance.

        Args:
            master_table:         tilde-quoted master table FQN
            audit_table:          tilde-quoted audit table FQN
            ref_lakefusion_id:    surrogate of the row to version
            overrides:            {col_name: new_value} — empty dict means
                                  metadata-only change (KEEP_RDM ack)
            action_type:          provenance label for the new version
            steward_locked:       value for steward_locked on new version
            steward_edited_cols:  list of cols changed (only in this version)
            steward_edited_by:    creator of the new version
        """
        from datetime import datetime as _dt

        sql = DataSetSQLService(token, warehouse_id)
        tilde = self._common_utils.apply_tilde
        safe_ref = str(ref_lakefusion_id).replace("'", "''")

        # 1. Fetch current biz values from master.
        master_rows = sql.execute_dataset(
            f"SELECT * FROM {master_table} "
            f"WHERE `ref_lakefusion_id` = '{safe_ref}' LIMIT 1"
        ) or []
        if not master_rows:
            raise HTTPException(
                status_code=404,
                detail=f"No master row for ref_lakefusion_id='{ref_lakefusion_id}'"
            )
        current = dict(master_rows[0])

        # 2. Read prior version / source / steward_locked from audit's current row.
        audit_rows = DataSetSQLService(token, warehouse_id).execute_dataset(
            f"SELECT `version`, `source`, `steward_locked` FROM {audit_table} "
            f"WHERE `ref_lakefusion_id` = '{safe_ref}' AND `is_current` = TRUE LIMIT 1"
        ) or []
        prior_audit  = dict(audit_rows[0]) if audit_rows else {}
        prior_version = int(prior_audit.get("version") or 0)
        next_version  = prior_version + 1
        prior_source  = prior_audit.get("source")

        # 3. Merge: master is biz-only, no reserved cols to drop. Just overlay overrides.
        merged = dict(current)
        merged.update(overrides or {})

        # 4. UPSERT master with merged biz values (UPDATE only; the row exists).
        cols       = list(merged.keys())
        cols_clause = ", ".join(tilde(c) for c in cols)
        placeholders = ", ".join(["?"] * len(cols))

        # UPDATE master row in place
        set_clause = ", ".join(f"{tilde(c)} = ?" for c in cols if c != "ref_lakefusion_id")
        update_master_sql = (
            f"UPDATE {master_table} SET {set_clause} "
            f"WHERE `ref_lakefusion_id` = '{safe_ref}'"
        )
        DataSetSQLService(token, warehouse_id).execute_update_query(
            update_master_sql,
            [merged[c] for c in cols if c != "ref_lakefusion_id"],
        )

        # 5. EXPIRE prior current audit row.
        cutover_ts = _dt.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f")
        DataSetSQLService(token, warehouse_id).execute_update_query(
            f"UPDATE {audit_table} "
            f"SET `is_current` = FALSE, `valid_to` = '{cutover_ts}' "
            f"WHERE `ref_lakefusion_id` = '{safe_ref}' "
            f"AND `is_current` = TRUE "
            f"AND `valid_from` < '{cutover_ts}'",
            [],
        )

        # 6. APPEND new audit row with full provenance.
        # Carry source forward — the underlying data still originated from that
        # source; the steward only overrode values. NULL only when no prior source.
        source_sql = (
            "NULL" if prior_source is None
            else "'" + str(prior_source).replace("'", "''") + "'"
        )
        edited_cols_arr = (
            "ARRAY(" + ", ".join(f"'{c}'" for c in steward_edited_cols) + ")"
            if steward_edited_cols else "NULL"
        )
        safe_steward_by = str(steward_edited_by or "").replace("'", "''")

        insert_audit_sql = (
            f"INSERT INTO {audit_table} ({cols_clause}, "
            f"`valid_from`, `valid_to`, `is_current`, `version`, `source`, "
            f"`action_type`, `steward_locked`, "
            f"`steward_edited_cols`, `steward_edited_by`) "
            f"VALUES ({placeholders}, "
            f"'{cutover_ts}', NULL, TRUE, {next_version}, {source_sql}, "
            f"'{action_type}', {str(bool(steward_locked)).lower()}, "
            f"{edited_cols_arr}, '{safe_steward_by}')"
        )
        DataSetSQLService(token, warehouse_id).execute_insert_query(
            insert_audit_sql, [merged[c] for c in cols]
        )

    def resolve_conflict(self, token: str, warehouse_id: str, entity_id: int,conflict_id: str, decision: str, resolved_by: str):
        valid_decisions = {"KEEP_RDM", "USE_SOURCE", "APPROVED", "REJECTED"}
        if decision not in valid_decisions:
            raise ValueError(f"Invalid decision '{decision}'. Must be one of {valid_decisions}")

        # Lakebase entities resolve conflicts Postgres-first so the change-log
        # triggers capture the conflict-queue + master/audit writes; the
        # Sync_Lakebase_Changelog_To_Delta workflow reconciles Delta.
        entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)
        if self._is_lakebase_entity(entity):
            return self._resolve_conflict_lakebase(entity, conflict_id, decision, resolved_by)

        sql_service = DataSetSQLService(token, warehouse_id)
        tilde       = self._common_utils.apply_tilde

        conflict_table_path, _ = self.get_reference_review_table_path(entity_id)
        master_table_path, _   = self.get_reference_table_path(entity_id)
        audit_table_path, _    = self.get_reference_audit_table_path(entity_id)

        conflict_table = tilde(conflict_table_path)
        master_table   = tilde(master_table_path)
        audit_table    = tilde(audit_table_path)

        primary_field = self.get_primary_field_for_entity(entity_id)
        tilde_pk      = tilde(primary_field)

        now = datetime.utcnow().isoformat()

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # STEP 1: Fetch the pending conflict row
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        safe_conflict_id = str(conflict_id).replace("'", "''")
        safe_resolved_by = str(resolved_by).replace("'", "''")
        rows = DataSetSQLService(token, warehouse_id).execute_dataset(f"""
            SELECT *
            FROM {conflict_table}
            WHERE conflict_id = '{safe_conflict_id}'
              AND status = 'PENDING'
            LIMIT 1
        """)

        if not rows:
            raise HTTPException(
                status_code=404,
                detail=f"Conflict '{conflict_id}' not found or already resolved."
            )

        row               = rows[0]
        conflict_type     = row["conflict_type"]
        field_name        = row["field_name"]
        source_value      = row["source_value"]
        entity_key        = row["entity_key_value"]        # business PK (for display/logging)
        ref_lakefusion_id = row.get("ref_lakefusion_id")   # surrogate — needed for most decisions

        # REJECTED requires no DATA change so ref_lakefusion_id is not needed.
        if not ref_lakefusion_id and decision != "REJECTED":
            raise HTTPException(
                status_code=400,
                detail=f"Conflict '{conflict_id}' is missing ref_lakefusion_id — cannot resolve as '{decision}'."
            )

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # STEP 2: Apply decision (SCD-2: every state change is a new version)
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

        # ── Case A: UPDATE_CONFLICT + USE_SOURCE ──────────────────────────────
        # SCD-2: read current row, build new version with field overridden,
        # mark as CONFLICT_RESOLVED + steward_locked=FALSE, expire old version.
        if conflict_type == "UPDATE_CONFLICT" and decision == "USE_SOURCE":
            self._scd2_apply_steward_change(
                token, warehouse_id, master_table, audit_table,
                ref_lakefusion_id=ref_lakefusion_id,
                overrides={field_name: source_value},
                action_type="CONFLICT_RESOLVED",
                steward_locked=False,
                steward_edited_cols=[field_name],
                steward_edited_by=safe_resolved_by,
            )

        # ── Case B: PENDING_INSERT + APPROVED ─────────────────────────────────
        # Append a new SCD-2 version. Despite the conflict_type name, the
        # ref_lakefusion_id may already have prior versions (e.g. expired rows
        # from earlier merges), so version must be max(version)+1, not 1.
        elif conflict_type == "PENDING_INSERT" and decision == "APPROVED":
            import json as _json
            try:
                data: dict = _json.loads(source_value)
            except _json.JSONDecodeError:
                raise HTTPException(
                    status_code=400,
                    detail=f"source_value for PENDING_INSERT is not valid JSON: {source_value}"
                )

            data.pop("ref_lakefusion_id", None)

            business_cols   = ", ".join(tilde(k) for k in data.keys())
            business_values = ", ".join(
                str(v).lower() if isinstance(v, bool) else f"'{str(v).replace(chr(39), chr(39)*2)}'"
                for v in data.values()
            )
            edited_cols_arr = "ARRAY(" + ", ".join(f"'{k}'" for k in data.keys()) + ")"

            safe_ref_lakefusion_id = str(ref_lakefusion_id).replace("'", "''")

            # Compute next version from audit (might have prior expired versions).
            version_rows = DataSetSQLService(token, warehouse_id).execute_dataset(
                f"SELECT MAX(`version`) AS max_version FROM {audit_table} "
                f"WHERE `ref_lakefusion_id` = '{safe_ref_lakefusion_id}'"
            ) or []
            prior_version = (version_rows[0].get("max_version") if version_rows else None) or 0
            next_version  = int(prior_version) + 1

            # UPSERT master (the ref might have an expired prior version → row exists).
            update_set = ", ".join(f"{tilde(k)} = src.{tilde(k)}" for k in data.keys())
            insert_cols = ", ".join(["`ref_lakefusion_id`"] + [tilde(k) for k in data.keys()])
            insert_vals = ", ".join(["src.`ref_lakefusion_id`"] + [f"src.{tilde(k)}" for k in data.keys()])
            DataSetSQLService(token, warehouse_id).execute_dataset(f"""
                MERGE INTO {master_table} AS tgt
                USING (
                    SELECT '{ref_lakefusion_id}' AS `ref_lakefusion_id`,
                           {", ".join(f"{val} AS {tilde(k)}" for k, val in zip(data.keys(), [str(v).lower() if isinstance(v, bool) else f"'{str(v).replace(chr(39), chr(39)*2)}'" for v in data.values()]))}
                ) AS src
                ON tgt.`ref_lakefusion_id` = src.`ref_lakefusion_id`
                WHEN MATCHED THEN UPDATE SET {update_set}
                WHEN NOT MATCHED THEN INSERT ({insert_cols}) VALUES ({insert_vals})
            """)

            # Append audit row with full provenance.
            DataSetSQLService(token, warehouse_id).execute_dataset(f"""
                INSERT INTO {audit_table}
                    (`ref_lakefusion_id`, {business_cols},
                     `valid_from`, `valid_to`, `is_current`, `version`, `source`,
                     `action_type`, `steward_locked`,
                     `steward_edited_cols`, `steward_edited_by`)
                VALUES
                    ('{ref_lakefusion_id}', {business_values},
                     current_timestamp(), NULL, TRUE, {next_version}, NULL,
                     'CONFLICT_RESOLVED', FALSE,
                     {edited_cols_arr}, '{safe_resolved_by}')
            """)

        # ── Case C: KEEP_RDM ──────────────────────────────────────────────────
        # No business change, but a steward acknowledgment. SCD-2: clone
        # current row as new version with action_type=KEEP_RDM. The audit
        # trail then shows when steward acknowledged the conflict.
        elif decision == "KEEP_RDM":
            self._scd2_apply_steward_change(
                token, warehouse_id, master_table, audit_table,
                ref_lakefusion_id=ref_lakefusion_id,
                overrides={},
                action_type="KEEP_RDM",
                steward_locked=True,   # KEEP_RDM = steward asserts current value
                steward_edited_cols=[],
                steward_edited_by=safe_resolved_by,
            )

        # ── Case D: REJECTED ──────────────────────────────────────────────────
        # No DATA change — just close the queue row below
        elif conflict_type == "PENDING_INSERT" and decision == "REJECTED":
            pass
    
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # STEP 3: Close the conflict queue row
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        DataSetSQLService(token, warehouse_id).execute_dataset(f"""
            UPDATE {conflict_table}
            SET status      = '{decision}',
                resolved_by = '{safe_resolved_by}',
                resolved_at = '{now}'
            WHERE conflict_id = '{safe_conflict_id}'
        """)
    
        return HttpResponse(
            status=200,
            message=f"Conflict '{conflict_id}' resolved as '{decision}' by '{resolved_by}'."
        )

    def _resolve_conflict_lakebase(self, entity, conflict_id: str, decision: str, resolved_by: str):
        """Lakebase (Postgres-first) variant of resolve_conflict.

        Writes the conflict-queue + master/audit Postgres synced tables directly
        (via psycopg2, one transaction per resolution) so the change-log triggers
        capture every change. The Sync_Lakebase_Changelog_To_Delta workflow then
        reconciles Delta — there is no inline Delta write here. Mirrors the Delta
        resolve_conflict SCD-2 decision matrix (USE_SOURCE / APPROVED / KEEP_RDM /
        REJECTED).
        """
        from psycopg2.extras import Json
        import json as _json

        conflict_path, _ = self.get_reference_review_table_path(entity.id)
        master_path,   _ = self.get_reference_table_path(entity.id)
        audit_path,    _ = self.get_reference_audit_table_path(entity.id)
        (pg_schema_c, pg_table_c), _ = self._ref_pg_paths(entity, conflict_path, conflict_path)
        (pg_schema_m, pg_table_m), (pg_schema_a, pg_table_a) = self._ref_pg_paths(
            entity, master_path, audit_path,
        )

        def _pg_val(v):
            # jsonb-typed complex (STRUCT/ARRAY) columns need the Json adapter;
            # scalars bind as-is.
            return Json(v) if isinstance(v, (dict, list)) else v

        with self._get_lakebase_pg_client(entity) as pg:
            # 1. Fetch the pending conflict row from Postgres (authoritative).
            rows = pg.query(
                f'SELECT * FROM "{pg_schema_c}"."{pg_table_c}" '
                f'WHERE "conflict_id" = %s AND "status" = %s LIMIT 1',
                (str(conflict_id), "PENDING"),
            )
            if not rows:
                raise HTTPException(
                    status_code=404,
                    detail=f"Conflict '{conflict_id}' not found or already resolved.",
                )
            row = rows[0]
            conflict_type     = row.get("conflict_type")
            field_name        = row.get("field_name")
            source_value      = row.get("source_value")
            ref_lakefusion_id = row.get("ref_lakefusion_id")

            # REJECTED requires no DATA change so ref_lakefusion_id is not needed.
            if not ref_lakefusion_id and decision != "REJECTED":
                raise HTTPException(
                    status_code=400,
                    detail=f"Conflict '{conflict_id}' is missing ref_lakefusion_id — cannot resolve as '{decision}'.",
                )

            # SCD-2 apply (PG): update/upsert master, expire prior current audit
            # row, append a new audit version. Runs inside the caller's txn.
            def _scd2_apply(ref_id, overrides, action_type, steward_locked,
                            edited_cols, insert_data=None):
                cur = pg.query(
                    f'SELECT * FROM "{pg_schema_m}"."{pg_table_m}" '
                    f'WHERE "ref_lakefusion_id" = %s LIMIT 1',
                    (ref_id,),
                )
                base = dict(cur[0]) if cur else {}
                meta = pg.query(
                    f'SELECT MAX("version") AS max_version, '
                    f'(array_agg("source" ORDER BY "version" DESC))[1] AS prior_source '
                    f'FROM "{pg_schema_a}"."{pg_table_a}" WHERE "ref_lakefusion_id" = %s',
                    (ref_id,),
                )
                prior_version = int((meta[0].get("max_version") if meta else 0) or 0)
                next_version  = prior_version + 1
                prior_source  = meta[0].get("prior_source") if meta else None

                new_biz = {**base, **(insert_data or {}), **overrides}
                new_biz.pop("ref_lakefusion_id", None)

                # master: insert when brand-new (PENDING_INSERT w/o prior row), else update.
                if not cur:
                    pg.insert_row(
                        pg_schema_m, pg_table_m,
                        {"ref_lakefusion_id": ref_id,
                         **{k: _pg_val(v) for k, v in new_biz.items()}},
                    )
                elif new_biz:
                    pg.update_where(
                        pg_schema_m, pg_table_m,
                        set_values={k: _pg_val(v) for k, v in new_biz.items()},
                        where='"ref_lakefusion_id" = %s', where_params=(ref_id,),
                    )

                # expire prior current audit row
                pg.execute(
                    f'UPDATE "{pg_schema_a}"."{pg_table_a}" '
                    f'SET "is_current" = FALSE, "valid_to" = CURRENT_TIMESTAMP '
                    f'WHERE "ref_lakefusion_id" = %s AND "is_current" = TRUE',
                    (ref_id,),
                )

                # append new audit version with full provenance
                audit_row = {"ref_lakefusion_id": ref_id,
                             **{k: _pg_val(v) for k, v in new_biz.items()}}
                audit_row["valid_to"]            = None
                audit_row["is_current"]          = True
                audit_row["version"]             = next_version
                audit_row["source"]              = prior_source
                audit_row["action_type"]         = action_type
                audit_row["steward_locked"]      = steward_locked
                audit_row["steward_edited_cols"] = Json(edited_cols) if edited_cols is not None else None
                audit_row["steward_edited_by"]   = resolved_by or None
                pg.insert_row(pg_schema_a, pg_table_a, audit_row)

            with pg.transaction():
                # ── Case A: UPDATE_CONFLICT + USE_SOURCE ──────────────────────
                if conflict_type == "UPDATE_CONFLICT" and decision == "USE_SOURCE":
                    _scd2_apply(ref_lakefusion_id, {field_name: source_value},
                                "CONFLICT_RESOLVED", False, [field_name])

                # ── Case B: PENDING_INSERT + APPROVED ─────────────────────────
                elif conflict_type == "PENDING_INSERT" and decision == "APPROVED":
                    try:
                        data = _json.loads(source_value)
                    except (TypeError, _json.JSONDecodeError):
                        raise HTTPException(
                            status_code=400,
                            detail=f"source_value for PENDING_INSERT is not valid JSON: {source_value}",
                        )
                    data.pop("ref_lakefusion_id", None)
                    _scd2_apply(ref_lakefusion_id, {}, "CONFLICT_RESOLVED", False,
                                list(data.keys()), insert_data=data)

                # ── Case C: KEEP_RDM ──────────────────────────────────────────
                elif decision == "KEEP_RDM":
                    _scd2_apply(ref_lakefusion_id, {}, "KEEP_RDM", True, [])

                # ── Case D: REJECTED / other → no DATA change ─────────────────

                # Close the conflict queue row (captured by the conflict trigger).
                pg.update_where(
                    pg_schema_c, pg_table_c,
                    set_values={"status": decision, "resolved_by": resolved_by,
                                "resolved_at": datetime.utcnow()},
                    where='"conflict_id" = %s', where_params=(str(conflict_id),),
                )

        return HttpResponse(
            status=200,
            message=f"Conflict '{conflict_id}' resolved as '{decision}' by '{resolved_by}'."
        )

    def _build_single_filter_clause_delta(self, col_expr, op, val):
        """Build one WHERE clause for a Delta SQL expression (no backtick wrapping)."""
        safe_val = str(val).replace("'", "''") if val is not None else ""
        if op == 'eq':             return f"UPPER({col_expr}) = UPPER('{safe_val}')"
        elif op == 'neq':          return f"UPPER({col_expr}) != UPPER('{safe_val}')"
        elif op == 'contains':     return f"UPPER({col_expr}) LIKE UPPER('%{safe_val}%')"
        elif op == 'not_contains': return f"UPPER({col_expr}) NOT LIKE UPPER('%{safe_val}%')"
        elif op == 'starts_with':  return f"UPPER({col_expr}) LIKE UPPER('{safe_val}%')"
        elif op == 'ends_with':    return f"UPPER({col_expr}) LIKE UPPER('%{safe_val}')"
        elif op == 'is_null':      return f"{col_expr} IS NULL"
        elif op == 'is_not_null':  return f"{col_expr} IS NOT NULL"
        return ""

    def _build_single_filter_clause_pg(self, col_expr, op, val):
        """Build one WHERE clause + params for a Postgres SQL expression (no quoting)."""
        if op == 'eq':             return f"UPPER({col_expr}) = UPPER(%s)", [val]
        elif op == 'neq':          return f"UPPER({col_expr}) <> UPPER(%s)", [val]
        elif op == 'contains':     return f"UPPER({col_expr}) LIKE UPPER(%s)", [f"%{val}%"]
        elif op == 'not_contains': return f"UPPER({col_expr}) NOT LIKE UPPER(%s)", [f"%{val}%"]
        elif op == 'starts_with':  return f"UPPER({col_expr}) LIKE UPPER(%s)", [f"{val}%"]
        elif op == 'ends_with':    return f"UPPER({col_expr}) LIKE UPPER(%s)", [f"%{val}"]
        elif op == 'is_null':      return f"{col_expr} IS NULL", []
        elif op == 'is_not_null':  return f"{col_expr} IS NOT NULL", []
        return "", []

    def fetch_conflict_records(self, token: str, entity_id: int, warehouse_id: str, page: int = 1, page_size: int = 50, filters=None, conflict_type=None):
        if conflict_type and conflict_type not in ("UPDATE_CONFLICT", "PENDING_INSERT"):
            conflict_type = None
        conflict_table_path, _ = self.get_reference_review_table_path(entity_id)
        data_path, _ = self.get_reference_table_path(entity_id)
        primary_field = self.get_primary_field_for_entity(entity_id)
        offset = (page - 1) * page_size

        entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)
        if self._is_lakebase_entity(entity):
            (pg_schema_c, pg_table_c), _ = self._ref_pg_paths(entity, conflict_table_path, conflict_table_path)
            (pg_schema_m, pg_table_m), _ = self._ref_pg_paths(entity, data_path, data_path)

            where_parts = ['c."status" = %s']
            params: list = ['PENDING']

            if conflict_type:
                where_parts.append('c."conflict_type" = %s')
                params.append(conflict_type)

            # Filters: for PENDING_INSERT, filter on JSON keys inside source_value;
            # for UPDATE_CONFLICT, filter on direct columns.
            if conflict_type == "PENDING_INSERT" and filters:
                parsed = self._normalize_filters(filters)
                if parsed:
                    json_clauses = []
                    json_params = []
                    for i, f in enumerate(parsed):
                        attr = f.get('attributeId') or f.get('attributeName')
                        op = f.get('operator')
                        val = f.get('value')
                        conj = f.get('conjunction', 'AND')
                        if not attr or not op:
                            continue
                        safe_attr = attr.replace("'", "''")
                        col_expr = f"""c."source_value"::jsonb ->> '{safe_attr}'"""
                        clause, clause_params = self._build_single_filter_clause_pg(col_expr, op, val)
                        if clause:
                            if json_clauses:
                                json_clauses.append(conj)
                            json_clauses.append(clause)
                            json_params.extend(clause_params)
                    if json_clauses:
                        where_parts.append(f"({' '.join(json_clauses)})")
                        params.extend(json_params)
            elif filters:
                filt_sql, filt_params = self._build_ref_filter_clauses_pg(filters, table_alias="c")
                if filt_sql:
                    where_parts.append(f"({filt_sql})")
                    params.extend(filt_params)

            where_clause = "WHERE " + " AND ".join(where_parts)

            with self._get_lakebase_pg_client(entity, token=token) as pg:
                if not self._pg_table_exists(pg, pg_schema_c, pg_table_c):
                    resp = HttpResponse(status=200, data=[], totalCount=0, has_more=False)
                    resp.conflict_count = 0
                    resp.new_record_count = 0
                    return resp

                if primary_field and self._pg_table_exists(pg, pg_schema_m, pg_table_m):
                    join_clause = (
                        f'LEFT JOIN "{pg_schema_m}"."{pg_table_m}" r '
                        f'ON CAST(c."entity_key_value" AS TEXT) = CAST(r."{primary_field}" AS TEXT)'
                    )
                    ref_select = (
                        f', CASE WHEN r."{primary_field}" IS NOT NULL '
                        f'THEN to_jsonb(r)::text ELSE NULL END AS "ref_record"'
                    )
                else:
                    join_clause = ""
                    ref_select = ', NULL AS "ref_record"'

                sql = (
                    f'SELECT c.*{ref_select}, COUNT(*) OVER() AS _total '
                    f'FROM "{pg_schema_c}"."{pg_table_c}" c {join_clause} '
                    f'{where_clause} ORDER BY c."created_at" DESC '
                    f'LIMIT {int(page_size)} OFFSET {int(offset)}'
                )
                rows = pg.query(sql, tuple(params))

                # Unfiltered counts per conflict_type for tab badges
                count_rows = pg.query(
                    f'SELECT "conflict_type", COUNT(*) AS cnt '
                    f'FROM "{pg_schema_c}"."{pg_table_c}" '
                    f'WHERE "status" = %s GROUP BY "conflict_type"',
                    ('PENDING',)
                )
                count_map = {r['conflict_type']: r['cnt'] for r in (count_rows or [])}

            total_count = rows[0]['_total'] if rows else 0
            rows = [{k: v for k, v in r.items() if k != '_total'} for r in rows]
            has_more = (offset + len(rows)) < total_count
            resp = HttpResponse(status=200, data=rows, totalCount=total_count, has_more=has_more)
            resp.conflict_count = count_map.get('UPDATE_CONFLICT', 0)
            resp.new_record_count = count_map.get('PENDING_INSERT', 0)
            return resp

        # ── Delta path ──────────────────────────────────────────────────────────
        tilde = self._common_utils.apply_tilde
        conflict_table = tilde(conflict_table_path)

        conflict_cols_str = ", ".join(
            f"c.{tilde(col)}" for col in [
                "conflict_id", "conflict_type", "ref_lakefusion_id","entity_key_value", "field_name",
                "rdm_value", "source_value", "edited_by", "status",
                "resolved_by", "resolved_at", "created_at",
            ]
        )

        join_clause = ""
        ref_select = ", NULL AS `ref_record`"
        if primary_field and self._check_ref_table_exists(token, warehouse_id, data_path):
            pk_col = tilde(primary_field)
            join_clause = f"LEFT JOIN {tilde(data_path)} r ON CAST(c.`entity_key_value` AS STRING) = CAST(r.{pk_col} AS STRING)"
            ref_select = f", CASE WHEN r.{pk_col} IS NOT NULL THEN to_json(struct(r.*)) ELSE NULL END AS `ref_record`"

        where_parts = ["c.`status` = 'PENDING'"]

        if conflict_type:
            where_parts.append(f"c.`conflict_type` = '{conflict_type}'")

        # Filters: for PENDING_INSERT, filter on JSON keys inside source_value;
        # for UPDATE_CONFLICT, filter on direct columns.
        if conflict_type == "PENDING_INSERT" and filters:
            parsed = self._normalize_filters(filters)
            if parsed:
                json_clauses = []
                for i, f in enumerate(parsed):
                    attr = f.get('attributeId') or f.get('attributeName')
                    op = f.get('operator')
                    val = f.get('value')
                    conj = f.get('conjunction', 'AND')
                    if not attr or not op:
                        continue
                    safe_attr = attr.replace("'", "''")
                    col_expr = f"get_json_object(c.`source_value`, '$.{safe_attr}')"
                    clause = self._build_single_filter_clause_delta(col_expr, op, val)
                    if clause:
                        if json_clauses:
                            json_clauses.append(conj)
                        json_clauses.append(clause)
                if json_clauses:
                    where_parts.append(f"({' '.join(json_clauses)})")
        elif filters:
            filter_clause, _ = self._build_ref_filter_clauses(filters, table_alias="c")
            if filter_clause:
                where_parts.append(f"({filter_clause})")

        where_clause = "WHERE " + " AND ".join(where_parts)
        order_clause = "ORDER BY c.`created_at` DESC"
        from_clause = f"FROM {conflict_table} c {join_clause}"

        sql_service = DataSetSQLService(token, warehouse_id)
        rows = sql_service.execute_dataset(
            f"SELECT {conflict_cols_str}{ref_select}, COUNT(*) OVER() AS _total {from_clause} {where_clause} {order_clause} LIMIT {page_size} OFFSET {offset}"
        )
        total_count = rows[0]['_total'] if rows else 0
        rows = [{k: v for k, v in r.items() if k != '_total'} for r in rows]
        has_more = (offset + len(rows)) < total_count

        # Unfiltered counts per conflict_type for tab badges
        count_service = DataSetSQLService(token, warehouse_id)
        count_rows = count_service.execute_dataset(
            f"SELECT c.`conflict_type`, COUNT(*) AS cnt FROM {conflict_table} c WHERE c.`status` = 'PENDING' GROUP BY c.`conflict_type`"
        )
        count_map = {r['conflict_type']: r['cnt'] for r in (count_rows or [])}

        resp = HttpResponse(status=200, data=rows, totalCount=total_count, has_more=has_more)
        resp.conflict_count = count_map.get('UPDATE_CONFLICT', 0)
        resp.new_record_count = count_map.get('PENDING_INSERT', 0)
        return resp
    
   

    def create_reference_record(self, token: str, entity_id: int, warehouse_id: str, data_object: dict):
        """Dispatch on entity.storage_type."""
        # Strip optional `source` from the payload before attribute validation
        # (mirrors what import_reference_records does). It gets stamped on the
        # audit row rather than the master row.
        source = data_object.pop("source", None)
        if isinstance(source, str) and source.strip() == "":
            source = None
        entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)
        if self._is_lakebase_entity(entity):
            return self._create_reference_record_lakebase(entity, data_object, token, warehouse_id, source=source)
        return self._create_reference_record_delta(token, entity_id, warehouse_id, data_object, source=source)

    def _create_reference_record_lakebase(
        self,
        entity,
        data_object: dict,
        token: Optional[str] = None,
        warehouse_id: Optional[str] = None,
        source: Optional[str] = None,
    ):
        """Lakebase variant of create_reference_record.

        Master INSERT + audit v1 INSERT in a single Postgres transaction.
        Uniqueness check on the business PK hits Postgres directly (not the
        synced lb_*_history) so a freshly-inserted row blocks a duplicate
        in the same request — Sync lag would otherwise allow races.

        After the PG commit, the same insert is replayed against the
        underlying Delta master/audit in a background thread so the
        original Delta table stays consistent with PG. Replay failures
        are logged but do not fail the UI request.
        """
        from lakefusion_core_engine.identifiers import generate_ref_key

        entity_id = entity.id
        master_path, _ = self.get_reference_table_path(entity_id)
        audit_path,  _ = self.get_reference_audit_table_path(entity_id)
        primary_field = self.get_primary_field_for_entity(entity_id)
        if primary_field is None:
            raise HTTPException(status_code=400, detail="No primary key attribute is set for this reference entity.")

        valid_attr_names = {
            a.name for a in self.db.query(EntityAttributes)
            .filter(EntityAttributes.entity_id == entity_id, EntityAttributes.is_active == True)
            .all()
        }
        invalid_cols = set(data_object.keys()) - valid_attr_names
        if invalid_cols:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown column(s): {', '.join(sorted(invalid_cols))}",
            )

        # Defensive: caller should never supply ref_lakefusion_id — we mint it.
        data_object.pop("ref_lakefusion_id", None)

        primary_value = data_object.get(primary_field)
        if primary_value is None:
            raise HTTPException(
                status_code=400,
                detail=f"Primary field '{primary_field}' is missing from the provided data.",
            )

        (pg_schema_m, pg_table_m), (pg_schema_a, pg_table_a) = self._ref_pg_paths(
            entity, master_path, audit_path,
        )

        ref_lakefusion_id = generate_ref_key(master_path, str(primary_value))
        user_col_names = list(data_object.keys())

        with self._get_lakebase_pg_client(entity) as pg:
            # PK uniqueness check (master IS current state).
            existing = pg.query(
                f'SELECT 1 FROM "{pg_schema_m}"."{pg_table_m}" '
                f'WHERE "{primary_field}" = %s LIMIT 1',
                (primary_value,),
            )
            if existing:
                raise HTTPException(
                    status_code=409,
                    detail=f"A record with {primary_field} = '{primary_value}' already exists.",
                )

            # Next version from audit (may have prior expired versions).
            ver_rows = pg.query(
                f'SELECT MAX("version") AS max_version '
                f'FROM "{pg_schema_a}"."{pg_table_a}" '
                f'WHERE "ref_lakefusion_id" = %s',
                (ref_lakefusion_id,),
            )
            prior_version = (ver_rows[0].get("max_version") if ver_rows else None) or 0
            next_version = int(prior_version) + 1

            master_row = {"ref_lakefusion_id": ref_lakefusion_id}
            for c in user_col_names:
                master_row[c] = data_object[c]

            audit_row = dict(master_row)
            audit_row["valid_to"] = None
            audit_row["is_current"] = True
            audit_row["version"] = next_version
            audit_row["source"] = source
            audit_row["action_type"] = "MANUAL_INSERT"
            audit_row["steward_locked"] = False
            audit_row["steward_edited_cols"] = None
            audit_row["steward_edited_by"] = None
            # valid_from gets CURRENT_TIMESTAMP from the column's DEFAULT.

            with pg.transaction():
                pg.insert_row(pg_schema_m, pg_table_m, master_row)
                pg.insert_row(pg_schema_a, pg_table_a, audit_row)

        # Delta is NOT written here. The Postgres write above is captured by the
        # change-log triggers into gold."{entity}_change_log"; the
        # Sync_Lakebase_Changelog_To_Delta workflow merges it into Delta. This
        # keeps a single Delta-write path (no double-write / replay race).

        return HttpResponse(
            status=200,
            message="Record inserted successfully!",
            data={
                "affected_rows":     1,
                "ref_lakefusion_id": ref_lakefusion_id,
                "created_record":    [{**data_object, "ref_lakefusion_id": ref_lakefusion_id}],
            }
        )

    def _create_reference_record_delta(self, token: str, entity_id: int, warehouse_id: str, data_object: dict, source: Optional[str] = None):
        master_path, _ = self.get_reference_table_path(entity_id)
        audit_path, _  = self.get_reference_audit_table_path(entity_id)
        primary_field = self.get_primary_field_for_entity(entity_id)
        if primary_field is None:
            raise HTTPException(status_code=400, detail="No primary key attribute is set for this reference entity.")

        # Validate provided columns against entity attributes
        valid_attr_names = {
            a.name for a in self.db.query(EntityAttributes)
            .filter(EntityAttributes.entity_id == entity_id, EntityAttributes.is_active == True)
            .all()
        }
        invalid_cols = set(data_object.keys()) - valid_attr_names
        if invalid_cols:
            raise HTTPException(status_code=400, detail=f"Unknown column(s): {', '.join(sorted(invalid_cols))}")

        # Defensive: caller should never supply ref_lakefusion_id — we mint it.
        data_object.pop("ref_lakefusion_id", None)

        primary_value = data_object.get(primary_field)
        if primary_value is None:
            raise HTTPException(status_code=400, detail=f"Primary field '{primary_field}' is missing from the provided data.")

        # Ensure master + audit reference tables exist. Check BOTH: a partial
        # state (master present, audit missing — e.g. from an earlier failed
        # setup or an entity created before the audit table existed) must still
        # be repaired, else the audit reads/writes below raise
        # TABLE_OR_VIEW_NOT_FOUND. _create_reference_table is idempotent
        # (CREATE TABLE IF NOT EXISTS for each), so it just creates what's missing.
        if (not self._check_ref_table_exists(token, warehouse_id, master_path)
                or not self._check_ref_table_exists(token, warehouse_id, audit_path)):
            self._create_reference_table(token, entity_id, warehouse_id)

        tilde        = self._common_utils.apply_tilde
        master_table = tilde(master_path)
        audit_table  = tilde(audit_path)
        pk_col       = tilde(primary_field)

        # Business-PK uniqueness check on master (master IS current state).
        if DataSetSQLService(token, warehouse_id).execute_dataset(
            f"SELECT 1 FROM {master_table} WHERE {pk_col} = '{primary_value}' LIMIT 1"
        ):
            raise HTTPException(
                status_code=409,
                detail=f"A record with {primary_field} = '{primary_value}' already exists."
            )

        # Mint the surrogate — immutable, decoupled from business PK.
        ref_lakefusion_id = generate_ref_key(master_path, str(primary_value))

        # Compute next version (might have prior expired versions in audit).
        safe_ref = str(ref_lakefusion_id).replace("'", "''")
        version_rows = DataSetSQLService(token, warehouse_id).execute_dataset(
            f"SELECT MAX(`version`) AS max_version FROM {audit_table} "
            f"WHERE `ref_lakefusion_id` = '{safe_ref}'"
        ) or []
        prior_version = (version_rows[0].get("max_version") if version_rows else None) or 0
        next_version  = int(prior_version) + 1

        user_col_names = list(data_object.keys())

        # ── INSERT into master (business cols only) ─────────────────────────────
        master_cols_str = ", ".join(["`ref_lakefusion_id`"] + [tilde(c) for c in user_col_names])
        master_placeholders = ", ".join(["?"] * (1 + len(user_col_names)))
        master_insert_sql = f"INSERT INTO {master_table} ({master_cols_str}) VALUES ({master_placeholders})"
        master_vals = [ref_lakefusion_id] + [data_object[c] for c in user_col_names]
        affected = DataSetSQLService(token, warehouse_id).execute_insert_query(master_insert_sql, master_vals)

        # ── APPEND audit row with full provenance ───────────────────────────────
        audit_cols_str = ", ".join(
            ["`ref_lakefusion_id`"]
            + [tilde(c) for c in user_col_names]
            + [
                "`valid_from`", "`valid_to`", "`is_current`", "`version`", "`source`",
                "`action_type`", "`steward_locked`",
                "`steward_edited_cols`", "`steward_edited_by`",
            ]
        )
        source_sql = f"'{source.replace(chr(39), chr(39)+chr(39))}'" if source else "NULL"
        audit_placeholders = (
            ", ".join(["?"] * (1 + len(user_col_names)))
            + f", current_timestamp(), NULL, TRUE, {next_version}, {source_sql}, 'MANUAL_INSERT', FALSE, NULL, NULL"
        )
        audit_insert_sql = f"INSERT INTO {audit_table} ({audit_cols_str}) VALUES ({audit_placeholders})"
        DataSetSQLService(token, warehouse_id).execute_insert_query(audit_insert_sql, master_vals)

        return HttpResponse(
            status=200,
            message="Record inserted successfully!",
            data={
                "affected_rows":     affected,
                "ref_lakefusion_id": ref_lakefusion_id,
                "created_record":    [{**data_object, "ref_lakefusion_id": ref_lakefusion_id}],
            }
        )
    

    def update_reference_record(self, token: str, entity_id: int, warehouse_id: str, primary_field: str, updates: list, edited_by: str = ""):
        """Dispatch on entity.storage_type:
          - 'lakebase' -> psycopg2 path against Postgres
          - else       -> existing warehouse-SQL path (Delta)
        """
        entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)
        if self._is_lakebase_entity(entity):
            return self._update_reference_record_lakebase(
                entity, primary_field, updates, edited_by,
                token=token, warehouse_id=warehouse_id,
            )
        return self._update_reference_record_delta(
            token, entity_id, warehouse_id, primary_field, updates, edited_by,
        )

    def _update_reference_record_lakebase(
        self, entity, primary_field: str, updates: list, edited_by: str = "",
        token: Optional[str] = None, warehouse_id: Optional[str] = None,
    ):
        """Lakebase variant of update_reference_record.

        Mirrors the Delta SCD-2 sequence (UPDATE master, EXPIRE prior audit
        current row, APPEND new audit row) but writes via psycopg2. Each
        update is wrapped in a Postgres transaction so the three statements
        either all commit or all roll back.

        Reads (pre-update snapshot, prior-version lookup) hit Postgres
        directly — warehouse SQL would see stale Sync state which would
        race against the writes we're about to do.

        After the PG commit, the same updates are replayed against the
        underlying Delta master/audit in a background thread so the original
        Delta table stays consistent with PG. Replay failures are logged
        but do not fail the UI request.
        """
        valid_updates = [
            u.model_dump() if hasattr(u, "model_dump") else dict(u)
            for u in updates
        ]
        if not valid_updates:
            raise HTTPException(status_code=400, detail="No updates provided")

        master_path, _ = self.get_reference_table_path(entity.id)
        audit_path,  _ = self.get_reference_audit_table_path(entity.id)
        (pg_schema_m, pg_table_m), (pg_schema_a, pg_table_a) = self._ref_pg_paths(
            entity, master_path, audit_path,
        )

        pv_list = [u["primary_field_value"] for u in valid_updates]

        # Validate at least one updatable column was supplied
        all_cols = set()
        for u in valid_updates:
            all_cols.update(u.get("data", {}).keys())
        all_cols.discard(primary_field)
        all_cols.discard("ref_lakefusion_id")
        if not all_cols:
            raise HTTPException(status_code=400, detail="No valid fields to update")

        affected_data = 0

        with self._get_lakebase_pg_client(entity) as pg:
            # 0a. Read current master state (post-Sync, but also authoritative
            # for our purposes since Postgres IS the source of truth).
            placeholders = ", ".join(["%s"] * len(pv_list))
            current_rows = pg.query(
                f'SELECT * FROM "{pg_schema_m}"."{pg_table_m}" '
                f'WHERE "{primary_field}" IN ({placeholders})',
                tuple(pv_list),
            )
            pk_to_row = {row.get(primary_field): row for row in current_rows}
            pk_to_ref = {pv: r["ref_lakefusion_id"] for pv, r in pk_to_row.items()}

            missing = [pv for pv in pv_list if pv not in pk_to_row]
            if missing:
                raise HTTPException(
                    status_code=404,
                    detail=f"No reference record(s) found for {primary_field}: {missing}"
                )

            ref_ids = list(pk_to_ref.values())

            # 0b. Audit metadata per ref — max version + most-recent source.
            ref_placeholders = ", ".join(["%s"] * len(ref_ids))
            audit_meta_rows = pg.query(
                f'SELECT "ref_lakefusion_id", '
                f'MAX("version") AS max_version, '
                f'(array_agg("source" ORDER BY "version" DESC))[1] AS prior_source '
                f'FROM "{pg_schema_a}"."{pg_table_a}" '
                f'WHERE "ref_lakefusion_id" IN ({ref_placeholders}) '
                f'GROUP BY "ref_lakefusion_id"',
                tuple(ref_ids),
            )
            ref_to_audit_meta = {
                r["ref_lakefusion_id"]: r for r in audit_meta_rows
            }

            # Process each update atomically.
            for u in valid_updates:
                pv = u["primary_field_value"]
                base = pk_to_row[pv]
                ref_id = base["ref_lakefusion_id"]
                user_data = u.get("data", {})
                updates_map = {
                    k: v for k, v in user_data.items()
                    if k not in (primary_field, "ref_lakefusion_id")
                }
                if not updates_map:
                    continue

                new_row = {**base, **updates_map}
                audit_meta = ref_to_audit_meta.get(ref_id, {}) or {}
                prior_version = int(audit_meta.get("max_version") or 0)
                next_version = prior_version + 1
                prior_source = audit_meta.get("prior_source")
                edited_cols = list(updates_map.keys())

                with pg.transaction():
                    # 1. UPDATE master in place (biz cols only — never touch PK).
                    biz_set = {
                        k: new_row[k] for k in new_row
                        if k != "ref_lakefusion_id"
                    }
                    pg.update_where(
                        pg_schema_m, pg_table_m,
                        set_values=biz_set,
                        where='"ref_lakefusion_id" = %s',
                        where_params=(ref_id,),
                    )

                    # 2. EXPIRE prior audit current row.
                    pg.execute(
                        f'UPDATE "{pg_schema_a}"."{pg_table_a}" '
                        f'SET "is_current" = FALSE, "valid_to" = CURRENT_TIMESTAMP '
                        f'WHERE "ref_lakefusion_id" = %s AND "is_current" = TRUE',
                        (ref_id,),
                    )

                    # 3. APPEND new audit row with full provenance.
                    # valid_from is omitted to fall through to the column's
                    # CURRENT_TIMESTAMP DEFAULT (set during table creation).
                    # steward_edited_cols is JSONB in the synced Postgres
                    # table (Lakehouse Sync maps Delta ARRAY<STRING> -> jsonb).
                    # Wrap with psycopg2's Json adapter so the list binds as
                    # JSON, not as a PG text[].
                    from psycopg2.extras import Json
                    audit_row = {**base, **updates_map}
                    audit_row["valid_to"] = None
                    audit_row["is_current"] = True
                    audit_row["version"] = next_version
                    audit_row["source"] = prior_source
                    audit_row["action_type"] = "STEWARD_EDIT"
                    audit_row["steward_locked"] = True
                    audit_row["steward_edited_cols"] = Json(edited_cols) if edited_cols is not None else None
                    audit_row["steward_edited_by"] = edited_by or None
                    pg.insert_row(pg_schema_a, pg_table_a, audit_row)

                affected_data += 1

        # Delta is NOT written here — the Postgres SCD-2 writes above are
        # captured by the change-log triggers and merged to Delta by the
        # Sync_Lakebase_Changelog_To_Delta workflow (single Delta-write path).

        return {
            "status": 200,
            "data": {
                "message":                  "Reference records updated successfully",
                "total_updates_requested":  len(updates),
                "successful_updates":       len(valid_updates),
                "data_table_affected_rows": affected_data,
                "meta_table_affected_rows": affected_data,
                "resolved_ref_ids":         pk_to_ref,
            }
        }

    def _update_reference_record_delta(self, token: str, entity_id: int, warehouse_id: str, primary_field: str, updates: list, edited_by: str = ""):
        # ── Resolve master + audit table paths ───────────────────────────────
        master_path, _ = self.get_reference_table_path(entity_id)
        audit_path, _  = self.get_reference_audit_table_path(entity_id)

        tilde        = self._common_utils.apply_tilde
        master_table = tilde(master_path)
        audit_table  = tilde(audit_path)
        pk_col       = tilde(primary_field)

        valid_updates = [u.model_dump() if hasattr(u, "model_dump") else dict(u) for u in updates]
        if not valid_updates:
            raise HTTPException(status_code=400, detail="No updates provided")

        sql_service = DataSetSQLService(token, warehouse_id)
        pv_list     = [u["primary_field_value"] for u in valid_updates]
        pv_in_clause = ", ".join(f"'{pv}'" for pv in pv_list)

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # STEP 0: Read the CURRENT biz values from master + version/source from
        # audit (current row).
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        current_rows = DataSetSQLService(token, warehouse_id).execute_dataset(f"""
            SELECT *
            FROM {master_table}
            WHERE {pk_col} IN ({pv_in_clause})
        """) or []

        pk_to_row = {dict(row).get(primary_field): dict(row) for row in current_rows}
        pk_to_ref = {pv: r["ref_lakefusion_id"] for pv, r in pk_to_row.items()}

        missing = [pv for pv in pv_list if pv not in pk_to_row]
        if missing:
            raise HTTPException(
                status_code=404,
                detail=f"No reference record(s) found for {primary_field}: {missing}"
            )

        ref_ids = list(pk_to_ref.values())
        ref_in_clause = ", ".join(f"'{r}'" for r in ref_ids)

        # Look up max(version) + prior source from audit per ref_id.
        audit_meta_rows = DataSetSQLService(token, warehouse_id).execute_dataset(f"""
            SELECT `ref_lakefusion_id`,
                   MAX(`version`) AS max_version,
                   max_by(`source`, `version`) AS prior_source
            FROM {audit_table}
            WHERE `ref_lakefusion_id` IN ({ref_in_clause})
            GROUP BY `ref_lakefusion_id`
        """) or []
        ref_to_audit_meta = {
            dict(r).get("ref_lakefusion_id"): dict(r) for r in audit_meta_rows
        }

        # Validate at least one updatable column was supplied across all updates
        all_cols = set()
        for u in valid_updates:
            all_cols.update(u.get("data", {}).keys())
        all_cols.discard(primary_field)
        all_cols.discard("ref_lakefusion_id")
        if not all_cols:
            raise HTTPException(status_code=400, detail="No valid fields to update")

        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # Per update: UPDATE master in place, EXPIRE prior audit current row,
        # APPEND new audit row with provenance.
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        from datetime import datetime as _dt
        cutover_ts = _dt.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f")

        safe_edited_by = str(edited_by or "").replace("'", "''")
        affected_data = 0

        for u in valid_updates:
            pv          = u["primary_field_value"]
            base        = pk_to_row[pv]
            ref_id      = base["ref_lakefusion_id"]
            user_data   = u.get("data", {})
            updates_map = {
                k: v for k, v in user_data.items()
                if k not in (primary_field, "ref_lakefusion_id")
            }
            if not updates_map:
                continue

            # New biz values = current master row + overrides.
            new_row = {**base, **updates_map}

            # Audit version + source carry-forward
            audit_meta    = ref_to_audit_meta.get(ref_id, {})
            prior_version = int(audit_meta.get("max_version") or 0)
            next_version  = prior_version + 1
            prior_source  = audit_meta.get("prior_source")
            source_sql = (
                "NULL" if prior_source is None
                else "'" + str(prior_source).replace("'", "''") + "'"
            )

            edited_cols_arr = (
                "ARRAY(" + ", ".join(f"'{c}'" for c in updates_map.keys()) + ")"
            )

            # 1. UPDATE master in place (biz cols only).
            biz_cols = [c for c in new_row.keys() if c != "ref_lakefusion_id"]
            set_clause = ", ".join(f"{tilde(c)} = ?" for c in biz_cols)
            update_master_sql = (
                f"UPDATE {master_table} SET {set_clause} "
                f"WHERE `ref_lakefusion_id` = '{str(ref_id).replace(chr(39), chr(39)*2)}'"
            )
            DataSetSQLService(token, warehouse_id).execute_update_query(
                update_master_sql, [new_row[c] for c in biz_cols]
            )

            # 2. EXPIRE prior audit current row for this ref.
            DataSetSQLService(token, warehouse_id).execute_update_query(
                f"UPDATE {audit_table} "
                f"SET `is_current` = FALSE, `valid_to` = '{cutover_ts}' "
                f"WHERE `ref_lakefusion_id` = '{str(ref_id).replace(chr(39), chr(39)*2)}' "
                f"AND `is_current` = TRUE "
                f"AND `valid_from` < '{cutover_ts}'",
                [],
            )

            # 3. APPEND new audit row with full provenance.
            cols         = ["ref_lakefusion_id"] + biz_cols
            cols_clause  = ", ".join(tilde(c) for c in cols)
            placeholders = ", ".join(["?"] * len(cols))
            audit_insert_sql = (
                f"INSERT INTO {audit_table} ({cols_clause}, "
                f"`valid_from`, `valid_to`, `is_current`, `version`, `source`, "
                f"`action_type`, `steward_locked`, "
                f"`steward_edited_cols`, `steward_edited_by`) "
                f"VALUES ({placeholders}, "
                f"'{cutover_ts}', NULL, TRUE, {next_version}, {source_sql}, "
                f"'STEWARD_EDIT', TRUE, "
                f"{edited_cols_arr}, '{safe_edited_by}')"
            )
            DataSetSQLService(token, warehouse_id).execute_insert_query(
                audit_insert_sql, [new_row[c] for c in cols]
            )
            affected_data += 1

        # Steward provenance is recorded on the new SCD-2 row directly
        # (action_type='STEWARD_EDIT', steward_edited_*); no separate META
        # update needed. Keep affected_meta in the response for shape
        # backwards-compat — set it equal to affected_data.
        affected_meta = affected_data
    
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        # RESPONSE
        # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        return {
            "status": 200,
            "data": {
                "message":                  "Reference records updated successfully",
                "total_updates_requested":  len(updates),
                "successful_updates":       len(valid_updates),
                "data_table_affected_rows": affected_data,
                "meta_table_affected_rows": affected_meta,
                "resolved_ref_ids":         pk_to_ref,
            }
        } 
    def delete_reference_record(self, token: str, entity_id: int, warehouse_id: str, primary_field: str, primary_field_value):
        """Dispatch on entity.storage_type."""
        entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)
        if self._is_lakebase_entity(entity):
            return self._delete_reference_record_lakebase(
                entity, primary_field, primary_field_value,
                token=token, warehouse_id=warehouse_id,
            )
        return self._delete_reference_record_delta(
            token, entity_id, warehouse_id, primary_field, primary_field_value,
        )

    def _delete_reference_record_lakebase(
        self, entity, primary_field: str, primary_field_value,
        token: Optional[str] = None, warehouse_id: Optional[str] = None,
    ):
        """Lakebase variant of delete_reference_record.

        SCD-2 delete: DELETE the master row + EXPIRE the prior audit current
        row + APPEND a tombstone audit row (action_type='SOFT_DELETE',
        is_current=FALSE) so the full history survives the deletion.

        After the PG commit, the same delete is replayed against the
        underlying Delta master/audit in a background thread so the
        original Delta table stays consistent with PG. Replay failures
        are logged but do not fail the UI request.
        """
        master_path, _ = self.get_reference_table_path(entity.id)
        audit_path,  _ = self.get_reference_audit_table_path(entity.id)
        (pg_schema_m, pg_table_m), (pg_schema_a, pg_table_a) = self._ref_pg_paths(
            entity, master_path, audit_path,
        )

        with self._get_lakebase_pg_client(entity) as pg:
            # Look up the master row first so we can build a tombstone with
            # the row's biz values frozen at delete-time.
            master_rows = pg.query(
                f'SELECT * FROM "{pg_schema_m}"."{pg_table_m}" '
                f'WHERE "{primary_field}" = %s LIMIT 1',
                (primary_field_value,),
            )
            if not master_rows:
                raise HTTPException(
                    status_code=404,
                    detail=f"No reference record found for {primary_field}='{primary_field_value}'",
                )
            base = master_rows[0]
            ref_id = base["ref_lakefusion_id"]

            ver_rows = pg.query(
                f'SELECT MAX("version") AS max_version, '
                f'(array_agg("source" ORDER BY "version" DESC))[1] AS prior_source '
                f'FROM "{pg_schema_a}"."{pg_table_a}" '
                f'WHERE "ref_lakefusion_id" = %s',
                (ref_id,),
            )
            prior_version = int((ver_rows[0].get("max_version") if ver_rows else 0) or 0)
            prior_source  = ver_rows[0].get("prior_source") if ver_rows else None
            next_version  = prior_version + 1

            with pg.transaction():
                # 1. DELETE from master.
                pg.delete_where(
                    pg_schema_m, pg_table_m,
                    where='"ref_lakefusion_id" = %s',
                    where_params=(ref_id,),
                )

                # 2. EXPIRE prior audit current row.
                pg.execute(
                    f'UPDATE "{pg_schema_a}"."{pg_table_a}" '
                    f'SET "is_current" = FALSE, "valid_to" = CURRENT_TIMESTAMP '
                    f'WHERE "ref_lakefusion_id" = %s AND "is_current" = TRUE',
                    (ref_id,),
                )

                # 3. Tombstone audit row — same biz values, version+1,
                # is_current=FALSE so it's never seen as "current".
                tombstone = dict(base)
                tombstone["valid_to"] = None
                tombstone["is_current"] = False
                tombstone["version"] = next_version
                tombstone["source"] = prior_source
                tombstone["action_type"] = "SOFT_DELETE"
                tombstone["steward_locked"] = False
                tombstone["steward_edited_cols"] = None
                tombstone["steward_edited_by"] = None
                pg.insert_row(pg_schema_a, pg_table_a, tombstone)

        # Delta is NOT written here — the Postgres delete/tombstone above is
        # captured by the change-log triggers and merged to Delta by the
        # Sync_Lakebase_Changelog_To_Delta workflow (single Delta-write path).

        return HttpResponse(
            status=200,
            message="Record deleted successfully.",
            data={"ref_lakefusion_id": ref_id, "affected_rows": 1},
        )

    def _delete_reference_record_delta(self, token: str, entity_id: int, warehouse_id: str, primary_field: str, primary_field_value):
        """SCD-2 delete on the consolidated reference table: expire the current
        version (set is_current=FALSE, valid_to=now(), action_type marker).
        Full history is preserved — the view filters on is_current=TRUE so the
        row "disappears" from the UI but old versions remain queryable.
        """
        data_path, _ = self.get_reference_table_path(entity_id)

        tilde = self._common_utils.apply_tilde
        data_table = tilde(data_path)
        pk_col = tilde(primary_field)
        sanitized = str(primary_field_value).replace("'", "''")

        sql_service = DataSetSQLService(token, warehouse_id)

        # SCD-2 expire: set is_current=FALSE, valid_to=now(), and stamp
        # action_type='STEWARD_DELETE_EXPIRED' on the current version. Old
        # versions stay untouched.
        sql_service.execute_update_query(
            f"UPDATE {data_table} "
            f"SET `is_current` = FALSE, "
            f"    `valid_to` = current_timestamp(), "
            f"    `action_type` = 'STEWARD_DELETE_EXPIRED' "
            f"WHERE {pk_col} = '{sanitized}' AND `is_current` = TRUE",
            [],
        )


    # ── Reference Mappings Table ──────────────────────────────────────────────

    def fetch_reference_mappings_records(self, token: str, entity_id: int, warehouse_id: str, page: int = 1, page_size: int = 50, status_filter: list | None = None, filters=None):
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        where_parts = ["status != 'REJECTED'"]
        if status_filter:
            quoted = ", ".join(f"'{s}'" for s in status_filter)
            where_parts.append(f"status IN ({quoted})")
        if filters:
            extra = self._apply_filters_where(filters)
            if extra.startswith("WHERE "):
                where_parts.append(f"({extra[6:]})")
        where_clause = f"WHERE {' AND '.join(where_parts)}"
        offset = (page - 1) * page_size
        rows = DataSetSQLService(token, warehouse_id).execute_dataset(
            f"SELECT *, COUNT(*) OVER() AS _total FROM {table} {where_clause} ORDER BY mapping_id DESC LIMIT {page_size} OFFSET {offset}"
        )
        total_count = rows[0]['_total'] if rows else 0
        rows = [{k: v for k, v in r.items() if k != '_total'} for r in rows]
        has_more = (offset + len(rows)) < total_count

        # Enrich rows with source_name from app DB using source_id (= dataset_id)
        # Cast to int — Databricks may return source_id as a string, but Dataset.id is an int
        source_ids = list({int(r["source_id"]) for r in rows if r.get("source_id") is not None})
        if source_ids:
            datasets = self.db.query(Dataset).filter(Dataset.id.in_(source_ids)).all()
            dataset_name_map = {d.id: d.name for d in datasets}
            for r in rows:
                sid = r.get("source_id")
                r["source_name"] = dataset_name_map.get(int(sid)) if sid is not None else None

        # Overwrite ref_record with live data from _reference_prod using ref_lakefusion_id
        try:
            ref_ids = list({r["ref_lakefusion_id"] for r in rows if r.get("ref_lakefusion_id")})
            if ref_ids:
                ref_prod_path, _ = self.get_reference_table_path(entity_id)
                entity_obj = EntityService(db=self.db).get_full_entity_by_id(entity_id)
                if self._is_lakebase_entity(entity_obj):
                    (pg_schema, pg_table), _ = self._ref_pg_paths(entity_obj, ref_prod_path, ref_prod_path)
                    placeholders = ", ".join(["%s"] * len(ref_ids))
                    with self._get_lakebase_pg_client(entity_obj, token=token) as pg:
                        ref_rows = pg.query(
                            f'SELECT * FROM "{pg_schema}"."{pg_table}" '
                            f'WHERE "ref_lakefusion_id" IN ({placeholders})',
                            tuple(ref_ids),
                        )
                else:
                    ref_prod_table = self._common_utils.apply_tilde(ref_prod_path)
                    quoted_ids = ", ".join(f"'{rid}'" for rid in ref_ids)
                    ref_rows = DataSetSQLService(token, warehouse_id).execute_dataset(
                        f"SELECT * FROM {ref_prod_table} WHERE ref_lakefusion_id IN ({quoted_ids})"
                    )
                ref_record_map = {}
                for rr in ref_rows:
                    rr_dict = rr if isinstance(rr, dict) else dict(rr)
                    ref_lf_id = rr_dict.get("ref_lakefusion_id")
                    if ref_lf_id:
                        ref_record_map[ref_lf_id] = rr_dict
                for r in rows:
                    rid = r.get("ref_lakefusion_id")
                    r["ref_record"] = ref_record_map.get(rid) if rid else None
        except Exception as e:
            app_logger.warning(f"Failed to enrich ref_record from _reference_prod for entity {entity_id}: {e}")

        return HttpResponse(status=200, data=rows, totalCount=total_count, has_more=has_more)

    def approve_all_reference_mapping_records(self, token: str, entity_id: int, warehouse_id: str):
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        total = DataSetSQLService(token, warehouse_id).execute_count_query(
            f"SELECT COUNT(*) FROM {table} WHERE status IN ('PENDING', 'NO_MATCH')"
        )
        if total == 0:
            return HttpResponse(status=200, message="No pending mappings to approve.", data={"approved_count": 0})
        DataSetSQLService(token, warehouse_id).execute_update_query(
            f"UPDATE {table} SET status = 'APPROVED' WHERE status IN ('PENDING', 'NO_MATCH')", []
        )
        return HttpResponse(status=200, message=f"All {total} pending mappings approved.", data={"approved_count": total})

    def _resolve_source_names(self, source_names: list) -> dict:
        """Map dataset names → Dataset objects. Raises 400 if any name is unknown or inactive."""
        unique_names = list(set(source_names))
        datasets = self.db.query(Dataset).filter(
            Dataset.name.in_(unique_names),
            Dataset.is_active == True,
        ).all()
        found = {d.name: d for d in datasets}
        missing = [n for n in unique_names if n not in found]
        if missing:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown or inactive dataset name(s): {', '.join(missing)}",
            )
        return found

    def create_reference_mapping_record(self, token: str, entity_id: int, warehouse_id: str, data_object: dict):
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        if "status" not in data_object:
            data_object["status"] = "MANUALLY_ADDED"
        # mapping_id is auto-generated by the DB — strip it if the caller accidentally supplies it
        data_object.pop("mapping_id", None)
        # source = dataset path, source_id = dataset id — both sent directly from the frontend.
        columns = list(data_object.keys())
        values = list(data_object.values())
        columns_str = ", ".join(self._common_utils.apply_tilde(c) for c in columns)
        placeholders = ", ".join(["?"] * len(values))
        affected = DataSetSQLService(token, warehouse_id).execute_insert_query(
            f"INSERT INTO {table} ({columns_str}) VALUES ({placeholders})", values
        )
        return HttpResponse(status=200, message="Mapping record inserted successfully!", data={"affected_rows": affected, "created_record": [data_object]})

    def import_reference_records(self, token: str, entity_id: int, warehouse_id: str, records: list):
        """Bulk-upsert records into the reference DATA and META tables.
        - Generates ref_lakefusion_id deterministically for each record.
        - Upserts: new records are inserted; existing records (matched by business PK) are updated.
        - META table is keyed by ref_lakefusion_id (FK to data table), not by business PK.
        - Raises 400 if any record is missing the primary key field.
        - Deduplicates within the incoming batch (first occurrence wins).
        - Creates the reference tables if they do not yet exist.
        - Optional `source` column in the CSV: if present and non-empty,
          stamps that value on the new SCD-2 version. Otherwise the prior
          version's source is carried forward (or NULL for brand-new refs).

        Dispatches on entity.storage_type:
          - 'lakebase' -> psycopg2 against Postgres synced tables
          - else       -> warehouse SQL against UC Delta (legacy)
        """
        if not records:
            raise HTTPException(status_code=400, detail="No records provided.")
        primary_field = self.get_primary_field_for_entity(entity_id)
        if primary_field is None:
            raise HTTPException(status_code=400, detail="No primary key attribute is set for this reference entity.")

        # Validate every record has a non-empty primary key
        for i, rec in enumerate(records):
            if not rec.get(primary_field):
                raise HTTPException(status_code=400, detail=f"Record at index {i} is missing primary field '{primary_field}'.")

        # Deduplicate within the incoming batch — keep first occurrence; strip any caller-supplied ref_lakefusion_id
        seen: set = set()
        unique_records: list = []
        for rec in records:
            pk_val = rec.get(primary_field)
            if pk_val not in seen:
                seen.add(pk_val)
                unique_records.append({k: v for k, v in rec.items() if k != "ref_lakefusion_id"})
        duplicates_in_batch = len(records) - len(unique_records)

        # Strip optional `source` column from each record and capture per-row.
        # Empty / whitespace-only values count as "not provided" and we'll
        # carry the prior version's source instead.
        record_sources: list = []
        for rec in unique_records:
            src = rec.pop("source", None)
            if isinstance(src, str) and src.strip() == "":
                src = None
            record_sources.append(src)

        entity = EntityService(db=self.db).get_full_entity_by_id(entity_id)
        if self._is_lakebase_entity(entity):
            return self._import_reference_records_lakebase(
                entity, primary_field, unique_records, record_sources,
                duplicates_in_batch, total_submitted=len(records),
                token=token, warehouse_id=warehouse_id,
            )

        return self._import_reference_records_delta(
            token, entity_id, warehouse_id, primary_field, unique_records,
            record_sources, duplicates_in_batch, total_submitted=len(records),
        )

    def _import_reference_records_delta(
        self,
        token: str,
        entity_id: int,
        warehouse_id: str,
        primary_field: str,
        unique_records: list,
        record_sources: list,
        duplicates_in_batch: int,
        total_submitted: int,
    ):
        """Delta variant of import_reference_records (warehouse SQL).

        Also used as the reverse-sync target for lakebase imports — same
        UPSERT-master + EXPIRE-audit + APPEND-audit sequence as the
        lakebase variant, just against UC Delta.
        """
        # Ensure master + audit reference tables exist (Delta path). Check BOTH:
        # a partial state (master present, audit missing — e.g. from an earlier
        # failed setup) must still be repaired, else the audit reads/writes below
        # raise TABLE_OR_VIEW_NOT_FOUND. _create_reference_table is idempotent
        # (CREATE TABLE IF NOT EXISTS for each), so it just creates what's missing.
        master_path, _ = self.get_reference_table_path(entity_id)
        audit_path, _  = self.get_reference_audit_table_path(entity_id)
        if (not self._check_ref_table_exists(token, warehouse_id, master_path)
                or not self._check_ref_table_exists(token, warehouse_id, audit_path)):
            self._create_reference_table(token, entity_id, warehouse_id)

        tilde        = self._common_utils.apply_tilde
        master_table = tilde(master_path)
        audit_table  = tilde(audit_path)
        pk_tilde     = tilde(primary_field)

        # Generate ref_lakefusion_id deterministically for each record
        ref_ids = [generate_ref_key(master_path, str(rec.get(primary_field))) for rec in unique_records]
        pk_values = [rec.get(primary_field) for rec in unique_records]

        # ── Set-based bulk upsert (scales to tens of thousands of rows) ───────
        # Stage all rows once into a temp Delta table, then run a single MERGE
        # (master) + one EXPIRE + one INSERT…SELECT (audit). Replaces the prior
        # ~3-statements-per-row loop that timed out / dropped the warehouse
        # connection on large CSVs. NOTE: each execute_dataset() uses a fresh
        # DataSetSQLService because it closes its own connection on completion.
        import json as _json
        import uuid as _uuid
        from datetime import datetime as _dt
        cutover_ts = _dt.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f")

        business_cols = list(unique_records[0].keys())

        # Pre-existing master count (inserted vs updated reporting).
        pk_placeholders = ", ".join(["?"] * len(pk_values))
        pre_existing = DataSetSQLService(token, warehouse_id).execute_count_query(
            f"SELECT COUNT(*) FROM {master_table} WHERE {pk_tilde} IN ({pk_placeholders})",
            pk_values,
        )

        # Master column types — drive cast / from_json of the staged STRING cols
        # so scalars AND complex (STRUCT/ARRAY/MAP) attrs round-trip correctly.
        desc_rows = DataSetSQLService(token, warehouse_id).execute_dataset(
            f"DESCRIBE {master_table}"
        ) or []
        col_types = {}
        for r in desc_rows:
            cn = (r.get("col_name") or "").strip()
            if cn and not cn.startswith("#"):
                col_types[cn] = (r.get("data_type") or "string")

        # Per-ref max(version) + carry-forward source from audit.
        ref_in_for_lookup = ", ".join([f"'{r}'" for r in ref_ids])
        prior_meta_rows = DataSetSQLService(token, warehouse_id).execute_dataset(
            f"SELECT `ref_lakefusion_id`, MAX(`version`) AS max_version, "
            f"max_by(`source`, `version`) AS prior_source "
            f"FROM {audit_table} WHERE `ref_lakefusion_id` IN ({ref_in_for_lookup}) "
            f"GROUP BY `ref_lakefusion_id`"
        ) or []
        prior_versions = {row.get("ref_lakefusion_id"): (row.get("max_version") or 0) for row in prior_meta_rows}
        prior_sources  = {row.get("ref_lakefusion_id"): row.get("prior_source") for row in prior_meta_rows}

        def _is_complex(dt):
            return bool(dt) and dt.strip().lower().startswith(("struct", "array", "map"))

        def _to_stg_str(v):
            if v is None:
                return None
            if isinstance(v, (dict, list)):
                return _json.dumps(v)
            return str(v)

        # Staging table: every business col as STRING (JSON for complex) + the
        # precomputed version + chosen source.
        stg_path  = f"{master_path}_import_stg_{_uuid.uuid4().hex[:8]}"
        stg_table = tilde(stg_path)
        stg_col_defs = ", ".join(
            ["`ref_lakefusion_id` STRING"]
            + [f"{tilde(c)} STRING" for c in business_cols]
            + ["`_version` INT", "`_source` STRING"]
        )
        stg_insert_cols = ", ".join(
            ["`ref_lakefusion_id`"] + [tilde(c) for c in business_cols] + ["`_version`", "`_source`"]
        )

        def _proj(c):
            # staged STRING -> master column type (from_json for complex, else cast)
            dt = col_types.get(c, "string")
            if _is_complex(dt):
                return f"from_json(s.{tilde(c)}, '{dt}') AS {tilde(c)}"
            return f"CAST(s.{tilde(c)} AS {dt}) AS {tilde(c)}"
        proj_biz = ", ".join(_proj(c) for c in business_cols)

        try:
            DataSetSQLService(token, warehouse_id).execute_dataset(
                f"CREATE TABLE {stg_table} ({stg_col_defs}) USING DELTA"
            )

            # Bulk-load staging in chunks (multi-row INSERT). One service kept
            # open across the loop (execute_insert_query doesn't close it).
            ins_svc = DataSetSQLService(token, warehouse_id)
            ncols = len(business_cols) + 3  # ref + biz + _version + _source
            row_ph = "(" + ", ".join(["?"] * ncols) + ")"
            CHUNK = 1000
            for start in range(0, len(unique_records), CHUNK):
                end = min(start + CHUNK, len(unique_records))
                values_clause = ", ".join([row_ph] * (end - start))
                params = []
                for i in range(start, end):
                    rec = unique_records[i]
                    ref_id = ref_ids[i]
                    ver = int(prior_versions.get(ref_id, 0)) + 1
                    src = record_sources[i] if record_sources[i] is not None else prior_sources.get(ref_id)
                    params.append(ref_id)
                    params.extend(_to_stg_str(rec.get(c)) for c in business_cols)
                    params.append(ver)
                    params.append(src)
                ins_svc.execute_insert_query(
                    f"INSERT INTO {stg_table} ({stg_insert_cols}) VALUES {values_clause}",
                    params,
                )
            try:
                ins_svc.connection.close()
            except Exception:
                pass

            # 1. MERGE staging → master.
            update_set  = ", ".join(f"t.{tilde(c)} = src.{tilde(c)}" for c in business_cols)
            insert_cols = ", ".join(["`ref_lakefusion_id`"] + [tilde(c) for c in business_cols])
            insert_vals = ", ".join(["src.`ref_lakefusion_id`"] + [f"src.{tilde(c)}" for c in business_cols])
            DataSetSQLService(token, warehouse_id).execute_dataset(
                f"MERGE INTO {master_table} t USING ("
                f"SELECT s.`ref_lakefusion_id`, {proj_biz} FROM {stg_table} s) src "
                f"ON t.`ref_lakefusion_id` = src.`ref_lakefusion_id` "
                f"WHEN MATCHED THEN UPDATE SET {update_set} "
                f"WHEN NOT MATCHED THEN INSERT ({insert_cols}) VALUES ({insert_vals})"
            )

            # 2. EXPIRE prior current audit rows for all staged refs.
            DataSetSQLService(token, warehouse_id).execute_dataset(
                f"UPDATE {audit_table} SET `is_current` = FALSE, `valid_to` = '{cutover_ts}' "
                f"WHERE `ref_lakefusion_id` IN (SELECT `ref_lakefusion_id` FROM {stg_table}) "
                f"AND `is_current` = TRUE AND `valid_from` < '{cutover_ts}'"
            )

            # 3. APPEND the new audit versions (version + source from staging).
            biz_cols_sql = ", ".join(tilde(c) for c in business_cols)
            DataSetSQLService(token, warehouse_id).execute_dataset(
                f"INSERT INTO {audit_table} (`ref_lakefusion_id`, {biz_cols_sql}, "
                f"`valid_from`, `valid_to`, `is_current`, `version`, `source`, "
                f"`action_type`, `steward_locked`, `steward_edited_cols`, `steward_edited_by`) "
                f"SELECT s.`ref_lakefusion_id`, {proj_biz}, "
                f"'{cutover_ts}', NULL, TRUE, s.`_version`, s.`_source`, "
                f"'MANUAL_UPSERT', FALSE, NULL, NULL FROM {stg_table} s"
            )
        finally:
            try:
                DataSetSQLService(token, warehouse_id).execute_dataset(
                    f"DROP TABLE IF EXISTS {stg_table}"
                )
            except Exception:
                pass

        inserted = len(unique_records) - pre_existing
        updated = pre_existing

        return HttpResponse(
            status=200,
            message=f"{inserted} record(s) inserted, {updated} record(s) updated, {duplicates_in_batch} duplicate(s) in batch skipped.",
            data={
                "affected_rows": inserted + updated,
                "inserted_count": inserted,
                "updated_count": updated,
                "submitted_count": total_submitted,
                "duplicates_skipped": duplicates_in_batch,
            },
        )

    def _import_reference_records_lakebase(
        self,
        entity,
        primary_field: str,
        unique_records: list,
        record_sources: list,
        duplicates_in_batch: int,
        total_submitted: int,
        token: Optional[str] = None,
        warehouse_id: Optional[str] = None,
    ):
        """Lakebase variant of import_reference_records.

        Per-row UPSERT master + EXPIRE prior audit current row + APPEND new
        audit row, all inside a single Postgres transaction. Bulk-friendly
        Postgres approach without warehouse SQL.

        After the PG transaction commits, the same import is replayed
        against the underlying Delta master/audit in a background thread
        so the original Delta table stays consistent with PG. Replay
        failures are logged but do not fail the UI request.
        """
        from datetime import datetime as _dt

        entity_id      = entity.id
        master_path, _ = self.get_reference_table_path(entity_id)
        audit_path,  _ = self.get_reference_audit_table_path(entity_id)
        (pg_schema_m, pg_table_m), (pg_schema_a, pg_table_a) = self._ref_pg_paths(
            entity, master_path, audit_path,
        )

        ref_ids   = [generate_ref_key(master_path, str(rec.get(primary_field))) for rec in unique_records]
        pk_values = [rec.get(primary_field) for rec in unique_records]
        business_cols = list(unique_records[0].keys())
        cutover_ts = _dt.utcnow()

        with self._get_lakebase_pg_client(entity) as pg:
            # Bail if synced tables haven't been provisioned yet — for lakebase
            # entities the synced tables are created by the notebook write path,
            # not on-demand from the middlelayer.
            if not self._pg_table_exists(pg, pg_schema_m, pg_table_m):
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Lakebase synced master table "
                        f'"{pg_schema_m}"."{pg_table_m}" does not exist. '
                        f"Run the reference-entity setup notebook to provision "
                        f"it before importing records."
                    ),
                )

            # Pre-existing count on master (business-PK match)
            pk_placeholders = ", ".join(["%s"] * len(pk_values))
            pre_rows = pg.query(
                f'SELECT COUNT(*) AS c FROM "{pg_schema_m}"."{pg_table_m}" '
                f'WHERE "{primary_field}" IN ({pk_placeholders})',
                tuple(pk_values),
            )
            pre_existing = int(pre_rows[0].get("c", 0)) if pre_rows else 0

            # Per-ref max(version) and most-recent source from audit.
            ref_placeholders = ", ".join(["%s"] * len(ref_ids))
            prior_meta_rows = pg.query(
                f'SELECT "ref_lakefusion_id", '
                f'MAX("version") AS max_version, '
                f'(array_agg("source" ORDER BY "version" DESC))[1] AS prior_source '
                f'FROM "{pg_schema_a}"."{pg_table_a}" '
                f'WHERE "ref_lakefusion_id" IN ({ref_placeholders}) '
                f'GROUP BY "ref_lakefusion_id"',
                tuple(ref_ids),
            ) or []
            prior_versions = {
                r.get("ref_lakefusion_id"): (r.get("max_version") or 0)
                for r in prior_meta_rows
            }
            prior_sources = {
                r.get("ref_lakefusion_id"): r.get("prior_source")
                for r in prior_meta_rows
            }

            # ── Set-based bulk upsert (scales to tens of thousands of rows) ────
            # 3 statements total instead of ~3 per row:
            #   1. master upsert  — batched INSERT ... ON CONFLICT DO UPDATE
            #   2. audit  expire  — single UPDATE over all refs (chunked IN list)
            #   3. audit  append  — batched INSERT of the new versions
            # All in one transaction so the import is atomic.
            from psycopg2.extras import Json

            def _pgval(v):
                # complex (STRUCT/ARRAY) synced columns are jsonb — wrap dict/list.
                return Json(v) if isinstance(v, (dict, list)) else v

            master_cols     = ["ref_lakefusion_id"] + business_cols
            master_cols_sql = ", ".join(f'"{c}"' for c in master_cols)
            master_set_sql  = ", ".join(f'"{c}" = EXCLUDED."{c}"' for c in business_cols)
            master_rows = [
                tuple([ref_ids[i]] + [_pgval(rec.get(c)) for c in business_cols])
                for i, rec in enumerate(unique_records)
            ]

            audit_cols = master_cols + [
                "valid_from", "valid_to", "is_current", "version", "source",
                "action_type", "steward_locked", "steward_edited_cols", "steward_edited_by",
            ]
            audit_cols_sql = ", ".join(f'"{c}"' for c in audit_cols)
            audit_rows = []
            for i, rec in enumerate(unique_records):
                ref_id = ref_ids[i]
                next_version = int(prior_versions.get(ref_id, 0)) + 1
                chosen_source = (
                    record_sources[i]
                    if record_sources[i] is not None
                    else prior_sources.get(ref_id)
                )
                audit_rows.append(tuple(
                    [ref_id] + [_pgval(rec.get(c)) for c in business_cols] + [
                        cutover_ts, None, True, next_version, chosen_source,
                        "MANUAL_UPSERT", False, None, None,
                    ]
                ))

            with pg.transaction():
                # 1. master upsert (execute_values pages internally)
                pg.execute_many(
                    f'INSERT INTO "{pg_schema_m}"."{pg_table_m}" ({master_cols_sql}) '
                    f'VALUES %s ON CONFLICT ("ref_lakefusion_id") DO UPDATE SET {master_set_sql}',
                    master_rows,
                )

                # 2. expire prior current audit rows for all refs (chunk the IN list)
                _CHUNK = 5000
                for s in range(0, len(ref_ids), _CHUNK):
                    chunk = ref_ids[s:s + _CHUNK]
                    ph = ", ".join(["%s"] * len(chunk))
                    pg.execute(
                        f'UPDATE "{pg_schema_a}"."{pg_table_a}" '
                        f'SET "is_current" = FALSE, "valid_to" = %s '
                        f'WHERE "ref_lakefusion_id" IN ({ph}) '
                        f'AND "is_current" = TRUE AND "valid_from" < %s',
                        tuple([cutover_ts] + chunk + [cutover_ts]),
                    )

                # 3. append new audit versions (execute_values pages internally)
                pg.execute_many(
                    f'INSERT INTO "{pg_schema_a}"."{pg_table_a}" ({audit_cols_sql}) VALUES %s',
                    audit_rows,
                )

        inserted = len(unique_records) - pre_existing
        updated  = pre_existing

        # Delta is NOT written here — the Postgres upserts above are captured by
        # the change-log triggers and merged to Delta by the
        # Sync_Lakebase_Changelog_To_Delta workflow (single Delta-write path).

        return HttpResponse(
            status=200,
            message=f"{inserted} record(s) inserted, {updated} record(s) updated, {duplicates_in_batch} duplicate(s) in batch skipped.",
            data={
                "affected_rows":     inserted + updated,
                "inserted_count":    inserted,
                "updated_count":     updated,
                "submitted_count":   total_submitted,
                "duplicates_skipped": duplicates_in_batch,
            },
        )

    def import_reference_mapping_records(self, token: str, entity_id: int, warehouse_id: str, records: list):
        """Bulk-upsert mapping records. Resolves source names to dataset paths/ids.
        - Natural unique key: (source, source_attr, source_value, ref_attr)
        - Deduplicates within the batch (last occurrence wins per natural key).
        - Returns inserted_count, updated_count, duplicates_skipped.
        """
        if not records:
            raise HTTPException(status_code=400, detail="No records provided.")
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        if not self._check_ref_table_exists(token, warehouse_id, table_path):
            raise HTTPException(status_code=400, detail="Mappings table does not exist. Run the sync pipeline first to initialise it.")

        # 1. Set default status + strip auto-gen PK
        for rec in records:
            if not rec.get("status"):
                rec["status"] = "MANUALLY_ADDED"
            rec.pop("mapping_id", None)

        # 2. Validate source and source_id fields present in all records
        missing_source = [i for i, r in enumerate(records) if not r.get("source") or not r.get("source_id")]
        if missing_source:
            raise HTTPException(
                status_code=400,
                detail=f"Records at indices {missing_source} are missing 'source' (dataset path) or 'source_id' (dataset id).",
            )

        # 3. source = dataset path, source_id = dataset id — already provided by the frontend.

        # 4. Deduplicate within batch — natural key: (source, source_attr, source_value, ref_attr). Last occurrence wins.
        natural_key = ("source", "source_attr", "source_value", "ref_attr")
        seen: dict = {}
        for rec in records:
            key = tuple(rec.get(k) for k in natural_key)
            seen[key] = rec
        unique_records = list(seen.values())
        duplicates_in_batch = len(records) - len(unique_records)

        # 5. Build MERGE SQL
        tilde = self._common_utils.apply_tilde
        table = tilde(table_path)
        columns = list(unique_records[0].keys())
        col_tilde = [tilde(c) for c in columns]
        cols_str = ", ".join(col_tilde)
        row_ph = "(" + ", ".join(["?"] * len(columns)) + ")"
        all_ph = ", ".join([row_ph] * len(unique_records))
        flat_params = [rec.get(col) for rec in unique_records for col in columns]

        on_clause = " AND ".join(f"t.{tilde(k)} = s.{tilde(k)}" for k in natural_key)
        update_cols = [c for c in columns if c not in natural_key]
        update_set = ", ".join(f"t.{tilde(c)} = s.{tilde(c)}" for c in update_cols)
        insert_vals = ", ".join(f"s.{tilde(c)}" for c in columns)

        merge_sql = (
            f"MERGE INTO {table} AS t "
            f"USING (SELECT {cols_str} FROM VALUES {all_ph} AS tmp({cols_str})) AS s "
            f"ON {on_clause} "
            f"WHEN MATCHED THEN UPDATE SET {update_set} "
            f"WHEN NOT MATCHED THEN INSERT ({cols_str}) VALUES ({insert_vals})"
        )

        # 6. Pre-count existing rows matching natural key to split inserted vs updated
        nat_tilde = [tilde(k) for k in natural_key]
        nat_cols_str = ", ".join(nat_tilde)
        key_row_ph = "(" + ", ".join(["?"] * len(natural_key)) + ")"
        key_all_ph = ", ".join([key_row_ph] * len(unique_records))
        key_params = [rec.get(k) for rec in unique_records for k in natural_key]
        on_pre = " AND ".join(f"t.{tilde(k)} = s.{tilde(k)}" for k in natural_key)

        svc = DataSetSQLService(token, warehouse_id)
        pre_existing = svc.execute_count_query(
            f"SELECT COUNT(*) FROM {table} AS t "
            f"INNER JOIN (SELECT {nat_cols_str} FROM VALUES {key_all_ph} AS tmp({nat_cols_str})) AS s "
            f"ON {on_pre}",
            key_params,
        )

        svc.execute_merge_query(merge_sql, flat_params)
        inserted = len(unique_records) - pre_existing
        updated = pre_existing

        return HttpResponse(
            status=200,
            message=f"{inserted} record(s) inserted, {updated} record(s) updated, {duplicates_in_batch} duplicate(s) in batch skipped.",
            data={
                "affected_rows": inserted + updated,
                "inserted_count": inserted,
                "updated_count": updated,
                "submitted_count": len(records),
                "duplicates_skipped": duplicates_in_batch,
            },
        )

    def update_reference_mapping_record(self, token: str, entity_id: int, warehouse_id: str, record_id: int, data_object: dict):
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        if not data_object:
            raise HTTPException(status_code=400, detail="No fields to update")
        # mapping_id is the auto-generated PK — never allow it to be changed
        data_object.pop("mapping_id", None)
        if not data_object:
            raise HTTPException(status_code=400, detail="No updatable fields provided")
        set_clauses = ", ".join(f"{self._common_utils.apply_tilde(k)} = ?" for k in data_object.keys())
        params = list(data_object.values()) + [record_id]
        affected = DataSetSQLService(token, warehouse_id).execute_update_query(
            f"UPDATE {table} SET {set_clauses} WHERE mapping_id = ?", params
        )
        return {"status": 200, "data": {"message": "Mapping record updated successfully", "total_affected_rows": affected}}

    def delete_reference_mapping_record(self, token: str, entity_id: int, warehouse_id: str, record_id: int):
        table_path, _ = self.get_reference_mappings_table_path(entity_id)
        table = self._common_utils.apply_tilde(table_path)
        return DataSetSQLService(token, warehouse_id).execute_delete_query(f"DELETE FROM {table} WHERE mapping_id = {record_id}")

    # ── RDM Resolution for Profile View ──────────────────────────────────────

    def get_rdm_resolution_for_profile(self, entity_id: int, profile_id: str, warehouse_id: str, token: str) -> dict:
        """
        For each REFERENCE_ENTITY attribute on the master entity:
          1. Gets source_id + source_attr from EntityDatasetMapping for that attribute.
          2. Reads the ref_lakefusion_id stored in _master_prod for this profile.
          3. Queries _reference_mappings_prod by (ref_lakefusion_id, source_id, source_attr)
             to get the unique resolved mapping row.
        Returns a dict keyed by entity attribute name.
        """
        try:
            entity_conn = EntityService(db=self.db)
            entity      = entity_conn.get_full_entity_by_id(entity_id)
            entity_name = entity.name.lower().replace(" ", "_")

            # ── 1. Collect REFERENCE_ENTITY attributes ────────────────────────
            ref_attrs = []
            for attr in entity.attributes:
                if not attr.name or attr.type != "REFERENCE_ENTITY":
                    continue
                tc = attr.type_config or {}
                if isinstance(tc, str):
                    try:
                        tc = json.loads(tc)
                    except (json.JSONDecodeError, TypeError):
                        tc = {}
                ref_entity_id = tc.get("reference_entity_id")
                if not ref_entity_id:
                    continue
                output_attr = tc.get("reference_entity_output_attr")
                ref_attrs.append({"attr_name": attr.name, "ref_entity_id": int(ref_entity_id), "output_attr": output_attr})

            if not ref_attrs:
                return {}

            # ── 2. Build entity_attr → [{source_id, source_attr}] from dataset_mappings
            #    Use the already-loaded Pydantic dataset_mappings on the entity object
            #    instead of a separate DB query to avoid session conflicts.
            ref_attr_names = {r["attr_name"] for r in ref_attrs}
            attr_sources: dict = {}
            for dm in entity.dataset_mappings:
                if not dm.is_active:
                    continue
                for ma in (dm.attributes or []):
                    entity_attr  = ma.entity_attribute  if hasattr(ma, "entity_attribute")  else (ma.get("entity_attribute")  if isinstance(ma, dict) else None)
                    dataset_attr = ma.dataset_attribute if hasattr(ma, "dataset_attribute") else (ma.get("dataset_attribute") if isinstance(ma, dict) else None)
                    if not entity_attr or not dataset_attr or entity_attr not in ref_attr_names:
                        continue
                    attr_sources.setdefault(entity_attr, []).append({
                        "source_id":   dm.dataset_id,
                        "source_attr": dataset_attr,
                    })

            # ── 3. Fetch master record ────────────────────────────────────────
            tilde    = self._common_utils.apply_tilde
            safe_pid = str(profile_id).replace("'", "''")
            master_rows = DataSetSQLService(token, warehouse_id).execute_dataset(
                f"SELECT * FROM {tilde(self.catalog_name + '.gold.' + entity_name + '_master_prod')} "
                f"WHERE lakefusion_id = '{safe_pid}' LIMIT 1"
            )
            if not master_rows:
                return {}
            master_record = master_rows[0] if isinstance(master_rows[0], dict) else dict(master_rows[0])

            # ── 4. Resolve each REFERENCE_ENTITY attribute ────────────────────
            result = {}

            for info in ref_attrs:
                attr_name     = info["attr_name"]
                ref_entity_id = info["ref_entity_id"]
                output_attr   = info.get("output_attr")

                ref_entity      = self.db.query(Entity).filter(Entity.id == ref_entity_id).first()
                ref_entity_name = ref_entity.name if ref_entity else str(ref_entity_id)

                def _not_mapped():
                    return {
                        "status":           "NOT_MAPPED",
                        "mapping_id":       None,
                        "source_value":     None,
                        "match":            None,
                        "ref_record":       None,
                        "ref_output_value": None,
                        "method":           None,
                        "score":            None,
                        "ref_entity_name":  ref_entity_name,
                        "ref_entity_id":    ref_entity_id,
                    }

                # Dataset mapping must exist for this attr — otherwise NOT_MAPPED
                sources = attr_sources.get(attr_name, [])
                if not sources or not ref_entity:
                    app_logger.info(
                        f"[rdm_resolution] NOT_MAPPED — attr={attr_name} "
                        f"sources_empty={not sources} ref_entity_missing={not ref_entity}"
                    )
                    result[attr_name] = _not_mapped()
                    continue

                # ref_lakefusion_id stored in master record for this attr
                raw_val   = master_record.get(attr_name)
                ref_lf_id = str(raw_val).strip() if raw_val is not None and str(raw_val).strip() != "" else None

                app_logger.info(f"[rdm_resolution] profile={profile_id} attr={attr_name} ref_lf_id={ref_lf_id!r}")

                # Empty value means pipeline found no match
                if ref_lf_id is None:
                    app_logger.info(f"[rdm_resolution] profile={profile_id} attr={attr_name} → NO_MATCH (null in master)")
                    result[attr_name] = {
                        "status":           "NO_MATCH",
                        "mapping_id":       None,
                        "source_value":     None,
                        "match":            None,
                        "ref_record":       None,
                        "ref_output_value": None,
                        "method":           None,
                        "score":            None,
                        "ref_entity_name":  ref_entity_name,
                        "ref_entity_id":    ref_entity_id,
                    }
                    continue

                # Query mappings table by (ref_lakefusion_id, source_id, source_attr)
                safe_ref_id      = ref_lf_id.replace("'", "''")
                source_ids_sql   = ", ".join(str(s["source_id"]) for s in sources)
                source_attrs_sql = ", ".join(
                    f"'{s['source_attr'].replace(chr(39), chr(39)*2)}'" for s in sources
                )
                ref_name_snake = ref_entity.name.lower().replace(" ", "_")
                mappings_table = tilde(f"{self.catalog_name}.gold.{ref_name_snake}_reference_mappings_prod")

                query = (
                    f"SELECT mapping_id, source_value, match, score, method, status, ref_record, updated_at "
                    f"FROM {mappings_table} "
                    f"WHERE ref_lakefusion_id = '{safe_ref_id}' "
                    f"AND source_id IN ({source_ids_sql}) "
                    f"AND source_attr IN ({source_attrs_sql})"
                )

                app_logger.info(f"[rdm_resolution] profile={profile_id} attr={attr_name} executing query: {query}")
                try:
                    mapping_rows = DataSetSQLService(token, warehouse_id).execute_dataset(query)
                except Exception as qe:
                    app_logger.exception(f"[rdm_resolution] query failed for attr={attr_name}: {qe}")
                    result[attr_name] = _not_mapped()
                    continue

                if not mapping_rows:
                    app_logger.info(f"[rdm_resolution] profile={profile_id} attr={attr_name} → NOT_MAPPED (0 rows for ref_lf_id={ref_lf_id!r})")
                    result[attr_name] = _not_mapped()
                    continue

                # Normalize all rows to dicts
                all_rows = [r if isinstance(r, dict) else dict(r) for r in mapping_rows]

                # Priority order for status (lower index = higher priority)
                status_priority = {
                    "MANUALLY_ADDED": 0,
                    "APPROVED":       1,
                    "AUTO_APPROVED":  2,
                    "PENDING":        3,
                    "NO_MATCH":       4,
                    "REJECTED":       5,
                }

                # Find the winning status (highest priority present)
                winning_priority = min(
                    (status_priority.get(r.get("status", ""), 99) for r in all_rows),
                    default=99,
                )
                winning_status_rows = [
                    r for r in all_rows
                    if status_priority.get(r.get("status", ""), 99) == winning_priority
                ]

                # Sort by score DESC (None last), then updated_at DESC (None last)
                def _sort_key(r):
                    score = r.get("score")
                    updated = r.get("updated_at")
                    return (
                        -(float(score)) if score is not None else float("inf"),
                        "" if updated is None else str(updated),
                    )

                winning_status_rows.sort(key=_sort_key)

                # Winning rows = all rows tied at top score + updated_at
                top = winning_status_rows[0]
                top_score     = top.get("score")
                top_updated   = top.get("updated_at")
                winning_rows  = [
                    r for r in winning_status_rows
                    if r.get("score") == top_score and r.get("updated_at") == top_updated
                ]

                app_logger.info(
                    f"[rdm_resolution] profile={profile_id} attr={attr_name} "
                    f"total_rows={len(all_rows)} winning_rows={len(winning_rows)} "
                    f"status={top.get('status')!r} score={top_score!r}"
                )

                # Collect deduplicated source_values from winning rows
                seen_sv = []
                for r in winning_rows:
                    sv = r.get("source_value")
                    if sv is not None and sv not in seen_sv:
                        seen_sv.append(sv)

                # Fetch ref_record and ref_output_value from _reference_prod using ref_lakefusion_id
                ref_record       = {}
                ref_output_value = None
                try:
                    ref_prod_path, _ = self.get_reference_table_path(ref_entity_id)
                    if self._is_lakebase_entity(ref_entity):
                        (pg_schema, pg_table), _ = self._ref_pg_paths(ref_entity, ref_prod_path, ref_prod_path)
                        with self._get_lakebase_pg_client(ref_entity, token=token) as pg:
                            ref_prod_rows = pg.query(
                                f'SELECT * FROM "{pg_schema}"."{pg_table}" '
                                f'WHERE "ref_lakefusion_id" = %s LIMIT 1',
                                (ref_lf_id,),
                            )
                    else:
                        ref_prod_table   = tilde(ref_prod_path)
                        ref_prod_rows    = DataSetSQLService(token, warehouse_id).execute_dataset(
                            f"SELECT * FROM {ref_prod_table} WHERE ref_lakefusion_id = '{safe_ref_id}' LIMIT 1"
                        )
                    if ref_prod_rows:
                        ref_record = ref_prod_rows[0] if isinstance(ref_prod_rows[0], dict) else dict(ref_prod_rows[0])
                        if output_attr:
                            raw_out = ref_record.get(output_attr)
                            ref_output_value = str(raw_out) if raw_out is not None else None
                except Exception as re:
                    app_logger.warning(f"[rdm_resolution] failed to fetch ref_record from _reference_prod for ref_lf_id={ref_lf_id!r}: {re}")

                ref_record["ref_lakefusion_id"] = ref_lf_id

                score_raw = top.get("score")
                result[attr_name] = {
                    "status":           top.get("status"),
                    "mapping_id":       top.get("mapping_id"),
                    "source_value":     seen_sv,
                    "match":            top.get("match"),
                    "ref_record":       ref_record,
                    "ref_output_value": ref_output_value,
                    "method":           top.get("method"),
                    "score":            float(score_raw) if score_raw is not None else None,
                    "ref_entity_name":  ref_entity_name,
                    "ref_entity_id":    ref_entity_id,
                }

            return result

        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Unable to fetch RDM resolution for profile. Reason - {message}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch RDM resolution: {str(e)}")
        finally:
            self.db.close()

    # ── Reference Entity Attribute Options ───────────────────────────────────

    def fetch_reference_entity_attr_option(self, entity_id: int, attr_name: str, warehouse_id: str, token: str) -> dict:
        """
        Returns enriched options for a REFERENCE_ENTITY attribute dropdown.
        Response: {
            ref_entity_name, output_attr, primary_key_attr,
            options: [{ref_lakefusion_id, display_value, primary_key_value}]
        }
        """
        try:
            entity_conn = EntityService(db=self.db)
            entity = entity_conn.get_full_entity_by_id(entity_id)

            target_attr = next(
                (a for a in entity.attributes if a.name == attr_name and a.type == "REFERENCE_ENTITY"),
                None,
            )
            if not target_attr:
                raise HTTPException(
                    status_code=404,
                    detail=f"REFERENCE_ENTITY attribute '{attr_name}' not found on entity {entity_id}",
                )

            tc = target_attr.type_config or {}
            if isinstance(tc, str):
                try:
                    tc = json.loads(tc)
                except (json.JSONDecodeError, TypeError):
                    tc = {}

            ref_entity_id = tc.get("reference_entity_id")
            output_attr   = tc.get("reference_entity_output_attr") or tc.get("reference_output_attribute_name")

            if not ref_entity_id:
                raise HTTPException(status_code=400, detail=f"No reference_entity_id configured for attribute '{attr_name}'")
            if not output_attr:
                raise HTTPException(status_code=400, detail=f"No reference_output_attribute_name configured for attribute '{attr_name}'")

            ref_entity_id = int(ref_entity_id)
            ref_entity = entity_conn.get_full_entity_by_id(ref_entity_id)
            ref_entity_name = ref_entity.name if ref_entity else f"Entity {ref_entity_id}"

            # Find the primary key attribute of the reference entity
            pk_attr = next(
                (a for a in (ref_entity.attributes if ref_entity else []) if a.is_primary_key),
                None,
            )
            pk_col = pk_attr.name if pk_attr else None

            view_path, _  = self.get_reference_view_path(ref_entity_id)

            if self._is_lakebase_entity(ref_entity):
                # Master IS the current state in lakebase — no is_current filter.
                (pg_schema, pg_table), _ = self._ref_pg_paths(ref_entity, view_path, view_path)
                select_cols = f'"ref_lakefusion_id", "{output_attr}"'
                if pk_col and pk_col != output_attr:
                    select_cols += f', "{pk_col}"'
                with self._get_lakebase_pg_client(ref_entity, token=token) as pg:
                    rows = pg.query(
                        f'SELECT {select_cols} '
                        f'FROM "{pg_schema}"."{pg_table}" '
                        f'ORDER BY "{output_attr}"'
                    )
            else:
                tilde         = self._common_utils.apply_tilde
                view_table    = tilde(view_path)
                safe_col      = tilde(output_attr)
                select_cols = f"ref_lakefusion_id, {safe_col}"
                if pk_col and pk_col != output_attr:
                    select_cols += f", {tilde(pk_col)}"
                # Master IS the current state (one row per ref_lakefusion_id) —
                # no is_current filter. The SCD-2 view that had is_current was
                # removed when master/audit split; that column lives only on the
                # audit table now (see get_reference_view_path).
                rows = DataSetSQLService(token, warehouse_id).execute_dataset(
                    f"SELECT {select_cols} "
                    f"FROM {view_table} "
                    f"ORDER BY {safe_col}"
                )

            options = []
            for row in (rows or []):
                row_dict  = row if isinstance(row, dict) else dict(row)
                ref_lf_id = row_dict.get("ref_lakefusion_id")
                display   = row_dict.get(output_attr)
                if ref_lf_id is not None:
                    opt = {
                        "ref_lakefusion_id": str(ref_lf_id),
                        "display_value":     str(display) if display is not None else "",
                    }
                    if pk_col:
                        pk_val = row_dict.get(pk_col)
                        opt["primary_key_value"] = str(pk_val) if pk_val is not None else ""
                    options.append(opt)

            return {
                "ref_entity_name": ref_entity_name,
                "output_attr": output_attr,
                "primary_key_attr": pk_col,
                "options": options,
            }

        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Unable to fetch reference entity attr options. Reason - {message}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch reference entity attr options: {str(e)}")
        finally:
            self.db.close()

lakefusion_databricks_dapi = os.environ.get('LAKEFUSION_DATABRICKS_DAPI', '')
class Monitor_Entity_Search_Databricks_Job:
    def __init__(self, db: Session):
        self.db = db

    def get_experiment_status(self, job_run_data: List[Dict], job_run_id) -> str:
        """
        Update experiment status based on job run tasks states
        """

        # ✅ ALWAYS return a string
        if not job_run_data:
            return StewardshipJobStatus.PENDING.value

        # Convert list to dict (exclude manual testing)
        task_states = {
            task['task_key']: task
            for task in job_run_data
            if task.get('task_key') != 'Entity_Manual_Testing'
        }

        # 1️⃣ Failures first
        if any(
            task.get('result_state') in ('FAILED', 'UPSTREAM_FAILED')
            for task in job_run_data
        ):
            return StewardshipJobStatus.FAILED.value

        # 2️⃣ Cancelled
        if any(
            task.get('result_state') in ('CANCELED', 'UPSTREAM_CANCELED')
            for task in job_run_data
        ):
            return 'match_merge_cancelled'

        # 3️⃣ Success detection (REAL merge tasks)
        merge_task = (
            task_states.get('Process_Entity_Job_Status')
            # or task_states.get('Process_CrossWalk')
            # or task_states.get('Entity_Match_Merge')  # backward compatibility
        )

        if (
            merge_task
            and merge_task.get('state') == 'TERMINATED'
            and merge_task.get('result_state') == 'SUCCESS'
        ):
            return StewardshipJobStatus.COMPLETED.value

        # 4️⃣ Default
        return StewardshipJobStatus.PENDING.value

    
    def get_pending_tasks(self):
        """
        Retrieve all rows where task_status is 'pending' from the Model_Databricks_Job table.

        Args:
            db (Session): SQLAlchemy database session.

        Returns:
            List[Model_Databricks_Job]: List of jobs with task_status as 'pending'.
        """
        try:
            pending_tasks = self.db.query(Model_Databricks_Entity_Search_Job).filter(
                Model_Databricks_Entity_Search_Job.status.in_([StewardshipJobStatus.PENDING.value, StewardshipJobStatus.SUBMITTED.value])
            ).all()
            return pending_tasks
        except Exception as e:
            print(f"Error fetching pending tasks: {e}")
            raise
    


    def update_job_run_status(
        self,
        job_run_id: str,
        new_job_run_status,
        new_status: str
    ):
        try:
            # 🔒 Strong validation (prevents MySQL errors forever)
            if not isinstance(new_status, str):
                raise ValueError(
                    f"Invalid status value: {new_status} (type={type(new_status)})"
                )

            # Get ALL records with this job_run_id (Merge All creates multiple records per job)
            job_entries = (
                self.db.query(Model_Databricks_Entity_Search_Job)
                .filter(
                    Model_Databricks_Entity_Search_Job.job_run_id == job_run_id
                )
                .all()
            )

            if not job_entries:
                raise ValueError(f"No job found with run_id: {job_run_id}")

            # ✅ Update ALL records with this job_run_id
            updated_count = 0
            for job_entry in job_entries:
                job_entry.job_run_status = new_job_run_status
                job_entry.status = new_status
                updated_count += 1

            self.db.commit()
            app_logger.info(f"Updated {updated_count} records for job_run_id={job_run_id} to status={new_status}")

            return job_entries

        except Exception:
            self.db.rollback()
            app_logger.exception(
                f"Failed to update job run status for job_run_id={job_run_id}"
            )
            raise

    
    

def check_entity_search_monitor_status(db: Session):
    """
    Check and update the monitor status of pending profiling tasks.

    Returns:
    - None: This function does not return a value.

    Raises:
    - HTTPException: If there is an issue with the database query or
      fetching monitor information.
    """
    app_logger.info("Starting check_entity_search_monitor_status function execution.")

    try:
        # Initialize the ProfilingTaskService with the database session.
        monitor_model_job_service = Monitor_Entity_Search_Databricks_Job(db)

        # Attempt to fetch tasks that have a pending monitor status.
        try:
            pending_job_run_tasks = monitor_model_job_service.get_pending_tasks()
        except Exception as e:
            # Log any errors that occur while fetching pending tasks.
            app_logger.error(f"Error fetching pending tasks: {str(e)}")
            app_logger.error(f"Traceback: {traceback.format_exc()}")
            return  # Exit the function if an error occurs to prevent further processing.

        # Get unique job_run_ids to avoid redundant Databricks API calls
        # (Merge All creates multiple records with same job_run_id)
        unique_job_run_ids = set()
        job_run_map = {}  # Store first job_run for each job_run_id (for fallback status)
        for job_run in pending_job_run_tasks:
            if job_run.job_run_id not in unique_job_run_ids:
                unique_job_run_ids.add(job_run.job_run_id)
                job_run_map[job_run.job_run_id] = job_run

        app_logger.info(f"Found {len(pending_job_run_tasks)} pending tasks with {len(unique_job_run_ids)} unique job_run_ids")

        # Process each unique job_run_id only once
        for job_run_id in unique_job_run_ids:
            try:
                job_run = job_run_map[job_run_id]

                # Fetch the latest monitor information for the task's dataset.
                job_status = DatabricksJobManager(token=lakefusion_databricks_dapi)
                latest_job_run_info = job_status.get_job_run_status(job_run_id)
                if latest_job_run_info is None:
                    app_logger.warning(f"Using previous job_run_status for job_run_id={job_run_id}")
                    latest_job_run_info = job_run.job_run_status
                new_experiment_status = monitor_model_job_service.get_experiment_status(latest_job_run_info, job_run_id)
                monitor_model_job_service.update_job_run_status(job_run_id, latest_job_run_info, new_experiment_status)

            except Exception as task_error:
                # Log any errors that occur while processing each individual task.
                app_logger.error(f"Error processing job run with ID {job_run_id}: {str(task_error)}")
                app_logger.error(f"Traceback: {traceback.format_exc()}")
                # Optionally, implement retry logic or other error handling here.

    except Exception as function_error:
        # Log any errors that occur at the function level.
        app_logger.error(f"Error in check_monitor_status function: {str(function_error)}")
        app_logger.error(f"Traceback: {traceback.format_exc()}")

    # Log the completion of the function execution.
    app_logger.info("Finished check_entity_search_monitor_status function execution.")


def process_query_completed_stewardship(db: Session):
    """
    Cron job (every 5 min): pick up all QUERY_COMPLETED records from entity_search_databricks_job,
    group by entity_id, and submit a Process_Potential_Match + Process_CrossWalk job per entity.
    The existing check_entity_search_monitor_status cron will track job completion.
    """
    app_logger.info("Starting process_query_completed_stewardship execution.")

    try:
        # Find all QUERY_COMPLETED records grouped by entity_id
        query_completed_records = db.query(Model_Databricks_Entity_Search_Job).filter(
            Model_Databricks_Entity_Search_Job.status == StewardshipJobStatus.QUERY_COMPLETED.value,
            Model_Databricks_Entity_Search_Job.execution_type == 'query'
        ).all()

        if not query_completed_records:
            app_logger.info("No QUERY_COMPLETED records found. Nothing to process.")
            return

        # Group by entity_id
        entity_groups = {}
        for record in query_completed_records:
            if record.entity_id not in entity_groups:
                entity_groups[record.entity_id] = []
            entity_groups[record.entity_id].append(record)

        app_logger.info(f"Found {len(query_completed_records)} QUERY_COMPLETED records across {len(entity_groups)} entities")

        # Get token — prefer App SP, fall back to PAT
        from lakefusion_utility.utils.databricks_util import get_app_sp_token, generate_pat
        token = get_app_sp_token() or generate_pat()
        if not token:
            app_logger.warning("No Databricks token available (SP or PAT) — cannot submit jobs")
            return

        service = EntitySearchService(db)

        for entity_id, records in entity_groups.items():
            try:
                app_logger.info(f"Submitting PM+Crosswalk job for entity_id={entity_id} ({len(records)} records)")

                # Build job parameters — only need entity-level params (no record-specific IDs)
                job_parameters = [
                    {"entity_id": str(entity_id), "experiment_id": "prod", "catalog_name": service.catalog_name},
                    {"catalog_name": service.catalog_name, "experiment_id": "prod"}
                ]

                # Create task list: Parse_Entity_Model_JSON → Process_Potential_Match + Process_CrossWalk → Entity_Job_Status
                tasks_list = service._create_pm_crosswalk_tasks(job_parameters)

                # Submit job
                job_service = DatabricksJobManager(token)
                job_create_response = job_service.create_and_submit_job("Stewardship_PM_Crosswalk", tasks_list)
                run_id = job_create_response.run_id

                app_logger.info(f"Submitted job run_id={run_id} for entity_id={entity_id}")

                # Update all QUERY_COMPLETED records for this entity
                for record in records:
                    record.job_run_id = str(run_id)
                    record.status = StewardshipJobStatus.SUBMITTED.value

                db.commit()
                app_logger.info(f"Updated {len(records)} records to SUBMITTED with job_run_id={run_id}")

            except Exception as e:
                app_logger.error(f"Failed to submit PM+Crosswalk job for entity_id={entity_id}: {e}")
                db.rollback()

    except Exception as e:
        app_logger.error(f"Error in process_query_completed_stewardship: {e}")
        app_logger.error(f"Traceback: {traceback.format_exc()}")

    app_logger.info("Finished process_query_completed_stewardship execution.")