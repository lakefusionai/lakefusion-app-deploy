from typing import Optional
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import HTTPException, Request, status
from lakefusion_utility.utils.logging_utils import get_logger

_logger = get_logger(__name__)


class HTTPBearer401(HTTPBearer):
    async def __call__(self, request: Request) -> Optional[HTTPAuthorizationCredentials]:
        # Check headers in order of priority:
        # 1. X-LakeFusion-Token (custom header that bypasses Databricks Apps proxy stripping)
        # 2. x-forwarded-access-token (Databricks Apps on-behalf-of user auth)
        # 3. Authorization (local development / direct access)
        lakefusion_token = request.headers.get("x-lakefusion-token")
        forwarded_token = request.headers.get("x-forwarded-access-token")
        has_auth = bool(request.headers.get("authorization"))

        _logger.debug(
            f"Auth headers for {request.method} {request.url.path}: "
            f"Authorization={'Y' if has_auth else 'N'}, "
            f"X-LakeFusion-Token={'Y' if lakefusion_token else 'N'}, "
            f"x-forwarded-access-token={'Y' if forwarded_token else 'N'}"
        )

        if lakefusion_token:
            _logger.info(f"Using X-LakeFusion-Token for {request.url.path}")
            return HTTPAuthorizationCredentials(scheme="Bearer", credentials=lakefusion_token)

        if forwarded_token:
            _logger.info(f"Using x-forwarded-access-token for {request.url.path}")
            return HTTPAuthorizationCredentials(scheme="Bearer", credentials=forwarded_token)

        try:
            result = await super().__call__(request)
            _logger.info(f"Using Authorization header for {request.url.path}")
            return result
        except HTTPException as exc:
            _logger.warning(f"No valid auth credential found for {request.url.path}")
            if exc.status_code == status.HTTP_403_FORBIDDEN:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Not authenticated",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            raise

