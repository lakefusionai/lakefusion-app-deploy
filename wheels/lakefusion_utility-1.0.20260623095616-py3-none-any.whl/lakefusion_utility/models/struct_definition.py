from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship

from lakefusion_utility.utils.app_db import Base


class StructDefinition(Base):
    """Reusable struct schema referenced by entity attributes of type=STRUCT
    (or ARRAY+is_array=True with type=STRUCT for ARRAY<STRUCT>)."""

    __tablename__ = "struct_definition"
    __table_args__ = (
        UniqueConstraint("name", name="uq_struct_definition_name"),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(String(1024), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    created_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    fields = relationship(
        "StructField",
        back_populates="struct_definition",
        cascade="all, delete-orphan",
        order_by="StructField.ordinal_position",
    )

    def __init__(
        self,
        name,
        description=None,
        is_active=True,
        created_by=None,
        created_at=None,
        updated_at=None,
    ):
        self.name = name
        self.description = description
        self.is_active = is_active
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.updated_at = updated_at if updated_at else datetime.utcnow()

    def __repr__(self):
        return (
            f"<StructDefinition(id={self.id}, name={self.name}, "
            f"is_active={self.is_active})>"
        )


class StructField(Base):
    """Scalar-typed field within a StructDefinition. Order is significant
    (ordinal_position drives Spark StructType field order)."""

    __tablename__ = "struct_field"
    __table_args__ = (
        UniqueConstraint(
            "struct_definition_id", "name", name="uq_struct_field_def_name"
        ),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    struct_definition_id = Column(
        Integer,
        ForeignKey("struct_definition.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    name = Column(String(255), nullable=False)
    label = Column(String(255), nullable=True)
    data_type = Column(String(64), nullable=False)
    ordinal_position = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    struct_definition = relationship("StructDefinition", back_populates="fields")

    def __init__(
        self,
        struct_definition_id,
        name,
        data_type,
        label=None,
        ordinal_position=0,
        created_at=None,
        updated_at=None,
    ):
        self.struct_definition_id = struct_definition_id
        self.name = name
        self.data_type = data_type
        self.label = label
        self.ordinal_position = ordinal_position
        self.created_at = created_at if created_at else datetime.utcnow()
        self.updated_at = updated_at if updated_at else datetime.utcnow()

    def __repr__(self):
        return (
            f"<StructField(id={self.id}, struct_definition_id={self.struct_definition_id}, "
            f"name={self.name}, data_type={self.data_type}, "
            f"ordinal_position={self.ordinal_position})>"
        )


# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------
# Strict scalar-type enforcement lives in the service layer so
# the type set can evolve without touching schema definitions everywhere.


class StructFieldCreate(BaseModel):
    name: str
    label: Optional[str] = None
    data_type: str
    ordinal_position: Optional[int] = None  # filled in by service if omitted

    @field_validator("name")
    @classmethod
    def _strip_name(cls, v: str) -> str:
        v = (v or "").strip()
        if not v:
            raise ValueError("name is required")
        return v

    @field_validator("data_type")
    @classmethod
    def _strip_data_type(cls, v: str) -> str:
        v = (v or "").strip()
        if not v:
            raise ValueError("data_type is required")
        return v


class StructFieldUpdate(BaseModel):
    name: Optional[str] = None
    label: Optional[str] = None
    data_type: Optional[str] = None
    ordinal_position: Optional[int] = None


class StructFieldResponse(BaseModel):
    id: int
    struct_definition_id: int
    name: str
    label: Optional[str] = None
    data_type: str
    ordinal_position: int
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True
        from_attributes = True


class StructDefinitionCreate(BaseModel):
    name: str
    description: Optional[str] = None
    is_active: Optional[bool] = True
    fields: List[StructFieldCreate] = Field(default_factory=list)
    created_by: Optional[str] = ""

    @field_validator("name")
    @classmethod
    def _strip_name(cls, v: str) -> str:
        v = (v or "").strip()
        if not v:
            raise ValueError("name is required")
        return v

    @field_validator("fields")
    @classmethod
    def _at_least_one_field(cls, v: List[StructFieldCreate]) -> List[StructFieldCreate]:
        if not v:
            raise ValueError("at least one field is required")
        names = [f.name for f in v]
        if len(set(names)) != len(names):
            raise ValueError("duplicate field names within struct")
        return v


class StructDefinitionUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None
    fields: Optional[List[StructFieldCreate]] = None


class StructDefinitionResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    is_active: bool
    created_by: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    fields: List[StructFieldResponse] = Field(default_factory=list)

    class Config:
        orm_mode = True
        from_attributes = True


class StructDefinitionSummary(BaseModel):
    """Compact view of a struct definition for embedding in EntityAttribute
    responses — avoids deep nesting in entity payloads."""

    id: int
    name: str
    fields: List[StructFieldResponse] = Field(default_factory=list)

    class Config:
        orm_mode = True
        from_attributes = True
