import os,json,base64,requests
from lakefusion_utility.utils.logging_utils import get_logger
from databricks.sdk import WorkspaceClient
from lakefusion_utility.utils.constants import Constants
from databricks.sdk.service.compute import ListClustersFilterBy
from databricks import sql
from datetime import datetime, timedelta
from databricks.sql.client import Connection, List
from databricks.sdk.service import jobs
from databricks.sdk.service.dashboards import Dashboard
import traceback
from sqlalchemy.orm import Session
from databricks.sdk.service.catalog import TableType
from io import BytesIO
from databricks.sdk.service.catalog import MonitorInfo, MonitorNotifications, MonitorSnapshot, MonitorDestination, MonitorCronSchedule
from typing import List, Optional, Dict,Union
from databricks.sdk.service.workspace import ObjectInfo
from databricks.sdk.service.jobs import Task, NotebookTask, TaskEmailNotifications, RunIf, Source, CronSchedule, JobParameterDefinition, JobEmailNotifications, CreateResponse, Job, JobSettings,JobRunAs, JobAccessControlRequest,JobPermissionLevel, PauseStatus
from databricks.sdk.service.files import CreateResponse
from lakefusion_utility.models.dbconfig import DBConfigProperties
import base64
from databricks.sdk import useragent
from databricks.sdk.service.iam import AccessControlRequest, PermissionLevel


# Initialize a logger to capture log messages for debugging and monitoring purposes
app_logger = get_logger(__name__)


class MonitorFailedError(RuntimeError):
    """Raised when a Lakehouse quality monitor is in MONITOR_STATUS_FAILED.
    Databricks rejects list_refreshes / run_refresh in this state; the only
    recovery is delete + recreate. Distinct from ValueError (no refreshes
    yet) so callers can branch on it without auto-retrying a doomed refresh."""

# Retrieve Databricks host URL from environment variables, or use a default if not set
DATABRICKS_HOST = os.environ.get('DATABRICKS_HOST', 'https://databricks.com')
if DATABRICKS_HOST and not DATABRICKS_HOST.startswith(("http://", "https://")):
    DATABRICKS_HOST = f"https://{DATABRICKS_HOST}"
# Retrieve SQL Warehouse HTTP path from constants
HTTP_PATH = Constants.sqlwarehouse_path

# Detect if running as a Databricks App (DATABRICKS_APP_URL is only set inside Databricks Apps)
IS_DATABRICKS_APPS = bool(os.environ.get('DATABRICKS_APP_URL'))


def _create_workspace_client(token: str = None) -> WorkspaceClient:
    """
    Create a WorkspaceClient with the appropriate auth method.
    - Token provided (user OIDC / DAPI): use explicit token + host with
      auth_type override to avoid SDK "multiple auth methods" error when
      DATABRICKS_CLIENT_ID/SECRET are also in the environment.
    - No token: SDK auto-auth (App SP in Databricks Apps, ~/.databrickscfg locally)
    """
    if token:
        from databricks.sdk.config import Config
        config = Config(host=DATABRICKS_HOST, token=token, auth_type="pat")
        return WorkspaceClient(config=config)
    return WorkspaceClient()


def _create_oauth_m2m_workspace_client() -> WorkspaceClient:
    """Create a WorkspaceClient authenticated as the service principal via
    OAuth M2M (client credentials).

    Reads DATABRICKS_CLIENT_ID / DATABRICKS_CLIENT_SECRET / DATABRICKS_HOST.
    No PAT / DAPI involved — used by RBAC group provisioning where the SP
    identity (not the end-user token) performs the account SCIM calls.
    """
    from databricks.sdk.config import Config
    client_id = os.environ.get("DATABRICKS_CLIENT_ID")
    client_secret = os.environ.get("DATABRICKS_CLIENT_SECRET")
    if not (client_id and client_secret):
        raise RuntimeError(
            "OAuth M2M auth requires DATABRICKS_CLIENT_ID and "
            "DATABRICKS_CLIENT_SECRET to be set"
        )
    config = Config(
        host=DATABRICKS_HOST,
        client_id=client_id,
        client_secret=client_secret,
        auth_type="oauth-m2m",
    )
    return WorkspaceClient(config=config)


def get_app_sp_token() -> str:
    """Return the DAPI token for K8s/local-dev environments.

    In Databricks Apps, returns empty string — callers should use
    WorkspaceClient() directly for SDK calls, or generate_pat() for
    raw HTTP calls.

    Falls back to LAKEFUSION_DATABRICKS_DAPI for K8s deployments.
    """
    if IS_DATABRICKS_APPS:
        return ""
    return os.environ.get("LAKEFUSION_DATABRICKS_DAPI", "")


def generate_pat() -> str:
    """Mint a short-lived OAuth bearer token from WorkspaceClient.

    Used by raw HTTP callers (SecretScopeService, get_model_optimization_info,
    etc.) that need a token string. In Databricks Apps, uses the auto-injected
    App SP. In K8s/local-dev, uses whatever auth the SDK resolves (PAT, config).

    Returns empty string if token generation fails.
    """
    try:
        w = WorkspaceClient()
        headers = w.config.authenticate() or {}
        auth = headers.get("Authorization", "")
        if auth.lower().startswith("bearer "):
            return auth.split(" ", 1)[1].strip()
        app_logger.warning("generate_pat: no Bearer header returned")
    except Exception as e:
        app_logger.warning(f"generate_pat failed: {e!r}")
    return ""


# Service for interacting with Databricks compute resources (clusters, SQL warehouses)
class ComputeService:
    token: str
    w: WorkspaceClient

    # Constructor method to initialize ComputeService with an authentication token.
    # The token is used to authenticate against the Databricks API.
    # Args:
    #     token (str): The Databricks API authentication token
    def __init__(self, token: str) -> None:
        self.token = token
        # Initialize the WorkspaceClient to interact with Databricks API
        self.w = _create_workspace_client(token)
    
    # Method to list clusters in the Databricks workspace.
    # Optional filtering can be applied based on the criteria provided in `filter_by`.
    # Args:
    #     filter_by (ListClustersFilterBy): Optional filters for listing clusters
    # Returns:
    #     List of clusters in the workspace, as a Python list
    def list_clusters(self, filter_by: ListClustersFilterBy):
        # Fetch the list of clusters and apply any provided filters
        clusters_list_obj = self.w.clusters.list(filter_by=filter_by)
        # Convert the result into a Python list
        clusters_list = list(clusters_list_obj)
        return clusters_list
    
    # Method to list all SQL warehouses in the Databricks workspace.
    # Returns:
    #     List of SQL warehouses, as a Python list
    def list_warehouses(self):
        # Fetch the list of SQL warehouses
        warehouses_list_obj = self.w.warehouses.list()
        # Convert the result into a Python list
        warehouses_list = list(warehouses_list_obj)
        return warehouses_list
    
    # Method to retrieve a specific SQL warehouse by its ID.
    # Args:
    #     warehouse_id (str): The ID of the SQL warehouse to retrieve
    # Returns:
    #     The warehouse object if found, else None
    def get_warehouse(self, warehouse_id: str):
        # Fetch all warehouses and find the one that matches the provided warehouse_id
        warehouses_list = self.list_warehouses()
        for warehouse in warehouses_list:
            if warehouse.id == warehouse_id:
               return warehouse

# Service for executing SQL queries on Databricks using SQL Warehouses
class DataSetSQLService:
    token: str
    warehouse_id: str
    connection: Connection
    """
    # Constructor method to initialize the DataSetSQLService with an authentication token and warehouse ID.
    # Args:
    #     token (str): The Databricks API authentication token
    #     warehouse_id (str): The ID of the SQL warehouse to connect to
    """
    def __init__(self, token: str, warehouse_id: str, timeout: int = 120) -> None:
        self.token = token
        # Establish a connection to the Databricks SQL warehouse using the provided token and warehouse ID
        self.connection = sql.connect(
            server_hostname=DATABRICKS_HOST,
            http_path=f'{HTTP_PATH + warehouse_id}',
            access_token=token,
            _user_agent_entry=get_user_agent_header_sql(),  # Set user agent for the connection
            _socket_timeout=timeout  # Connection timeout in seconds
        )

    """
    # Method to execute an INSERT query and return the number of affected rows.
    # Args:
    #     query (str): The INSERT SQL query to execute
    # Returns:
    #     int: The number of rows affected by the INSERT operation 
    # Raises:
    #     Exception: If there's an error during query execution
    """
    def execute_insert_query(self, query: str, parameters: list = None) -> int:
        # Open a cursor to execute the query
        cursor: sql.client.Cursor = self.connection.cursor()
        try:
            # Execute the provided INSERT query
            cursor.execute(query, parameters)
            # Get the number of affected rows
            affected_rows = cursor.rowcount
            # Commit the transaction
            self.connection.commit()
            app_logger.info(f'Successfully inserted {affected_rows} rows')
            return affected_rows
        except Exception as e:
            # Rollback in case of error
            self.connection.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Exception occurred while executing insert query. Error - {message}')
            raise e
        finally:
            # Ensure cursor is closed
            cursor.close()
    
    def execute_merge_query(self, query: str, parameters: list = None) -> int:
        """
        Executes a MERGE query in Databricks.
        
        Notes:
        - Databricks does NOT support explicit transactions (commit/rollback).
        - MERGE queries are auto-committed.
        - cursor.rowcount may return -1 depending on connector.
        """
        cursor = self.connection.cursor()
        try:
            cursor.execute(query, parameters)

            # Databricks may return -1 for rowcount
            affected_rows = cursor.rowcount if cursor.rowcount != -1 else 0

            app_logger.info(f"MERGE query executed successfully. Affected rows: {affected_rows}")
            return affected_rows

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Exception occurred while executing MERGE query. Error - {message}")
            raise e

        finally:
            cursor.close()

    """
    # Method to execute an UPDATE query and return the number of affected rows.
    # Args:
    #     query (str): The UPDATE SQL query to execute
    #     parameters (list, optional): List of parameters for the query
    # Returns:
    #     int: The number of rows affected by the UPDATE operation
    # Raises:
    #     Exception: If there's an error during query execution
    """
    def execute_update_query(self, query: str, parameters: list = None) -> int:
        # Open a cursor to execute the query
        cursor: sql.client.Cursor = self.connection.cursor()
        try:
            # Execute the provided UPDATE query
            cursor.execute(query, parameters)
            # Get the number of affected rows
            affected_rows = cursor.rowcount
            # Commit the transaction
            self.connection.commit()
            app_logger.info(f'Successfully updated {affected_rows} rows')
            return affected_rows
        except Exception as e:
            # Rollback in case of error
            self.connection.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Exception occurred while executing update query. Error - {message}')
            raise e
        finally:
            # Ensure cursor is closed
            cursor.close()   

   
    """
    # Method to execute a SQL query on the Databricks SQL Warehouse.
    # Args:
    #     query (str): The SQL query to execute
    # Returns:
    #     List of rows retrieved from the query execution
    """
    def execute_dataset(self, query: str):
        # Open a cursor to execute the query
        cursor: sql.client.Cursor = self.connection.cursor()
        try:
            # Execute the provided SQL query
            cursor.execute(query)
            # Fetch all results
            rows = cursor.fetchall()
            # Get column names
            column_names = [desc[0] for desc in cursor.description]

            # Construct a list of dictionaries, normalising Databricks-specific
            # types (e.g. ARRAY columns returned as non-standard iterables) to
            # plain Python types so FastAPI's jsonable_encoder can serialise them.
            def _to_python(v):
                if v is None or isinstance(v, (bool, int, float, str)):
                    return v
                if isinstance(v, list):
                    return v
                # ARRAY / MAP / STRUCT columns from the Databricks connector
                try:
                    return list(v)
                except TypeError:
                    return str(v)

            result = [
                {column_names[i]: _to_python(row[i]) for i in range(len(column_names))}
                for row in rows
            ]
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Exception occurred while execute the query. Error - {message}')
            raise e
        finally:
            # Ensure cursor and connection are closed
            cursor.close()
            self.connection.close()

        # Return the query results as JSON
        return result
    
    """
    # Method to execute a COUNT query and return the count as an integer.
    # Args:
    #     query (str): The COUNT SQL query to execute (should return a single numeric value)
    # Returns:
    #     int: The count value from the query
    """
    def execute_count_query(self, query: str, parameters: list = None) -> int:
        # Open a cursor to execute the query
        cursor: sql.client.Cursor = self.connection.cursor()
        try:
            # Execute the provided COUNT query
            cursor.execute(query, parameters)
            # Fetch the first row and first column (the count value)
            result = cursor.fetchone()
            count = result[0] if result else 0
            return int(count)
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Exception occurred while executing count query. Error - {message}')
            raise e
        finally:
            # Ensure cursor is closed
            cursor.close()
    """
    # Method to execute a DELETE query and return the number of affected rows.
    # Args:
    #     query (str): The DELETE SQL query to execute
    # Returns:
    #     int: The number of rows affected by the DELETE operation
    """
    def execute_delete_query(self, query: str) -> int:
        # Open a cursor to execute the query
        cursor: sql.client.Cursor = self.connection.cursor()
        try:
            # Execute the provided DELETE query
            cursor.execute(query)
            # Get the number of affected rows
            affected_rows = cursor.rowcount
            # Commit the transaction
            self.connection.commit()
            return affected_rows
        except Exception as e:
            # Rollback in case of error
            self.connection.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Exception occurred while executing delete query. Error - {message}')
            raise e
        finally:
            # Ensure cursor is closed
            cursor.close()

    def execute_sql_script(self, script: str) -> dict:
        """
        Execute a SQL script (BEGIN...END compound statement) on the SQL warehouse.
        Returns the query_id and result of the final SELECT statement.

        Args:
            script (str): A SQL compound statement (BEGIN...END block)
        Returns:
            dict: {"query_id": str, "result": list of dicts}
        """
        cursor: sql.client.Cursor = self.connection.cursor()
        try:
            cursor.execute(script)
            query_id = getattr(cursor, 'query_id', None) or str(id(cursor))
            result = []
            if cursor.description:
                rows = cursor.fetchall()
                column_names = [desc[0] for desc in cursor.description]
                result = [
                    {column_names[i]: row[i] for i in range(len(column_names))}
                    for row in rows
                ]
            return {"query_id": query_id, "result": result}
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Exception occurred while executing SQL script. Error - {message}')
            raise e
        finally:
            cursor.close()
            self.connection.close()


# Service for interacting with Databricks catalogs, schemas, and tables
class CatalogService:
    token: str
    w: WorkspaceClient
    db:Session
    

    # Constructor method to initialize the CatalogService with an authentication token.
    # Args:
    #     token (str): The Databricks API authentication token
    def __init__(self, token: str,db:Session) -> None:
        self.token = token
        # Initialize the WorkspaceClient to interact with Databricks API
        self.w = _create_workspace_client(token)
        self.catalog_name=(
        db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == "catalog_name")
        .first().config_value
    )
    
    # Method to list all available catalogs in the Databricks workspace.
    # The `include_browse` parameter is used to include catalogs available for browsing.
    # Returns:
    #     List of catalogs, as a Python list
    def list_catalogs(self):
        # Fetch list of catalogs, including those available for browsing
        catalogs_list_obj = self.w.catalogs.list(include_browse=True)
        # Convert the result into a Python list
        catalogs_list = list(catalogs_list_obj)
        return catalogs_list
    
    # Method to retrieve the schemas within a specific catalog.
    # Args:
    #     catalog_name (str): The name of the catalog to retrieve schemas from
    # Returns:
    #     List of schemas within the catalog, as a Python list
    def get_schemas(self, catalog_name: str):
        # Fetch list of schemas from the specified catalog
        schemas_list_obj = self.w.schemas.list(catalog_name=catalog_name)
        # Convert the result into a Python list
        schemas_list = list(schemas_list_obj)
        return schemas_list
    
    # Method to retrieve tables within a specified catalog and schema.
    # Args:
    #     catalog_name (str): The name of the catalog to retrieve tables from
    #     schema_name (str): The name of the schema to retrieve tables from
    # Returns:
    #     List of tables within the specified catalog and schema, as a Python list
    def get_tables(self, catalog_name: str, schema_name: str):
        tables_list_obj = self.w.tables.list(catalog_name=catalog_name, schema_name=schema_name)
        return list(tables_list_obj)

    # Method to retrieve volumes within a specified catalog and schema.
    # Args:
    #     catalog_name (str): The name of the catalog to retrieve volumes from
    #     schema_name (str): The name of the schema to retrieve volumes from
    # Returns:
    #     List of volumes within the specified catalog and schema, as a Python list
    def get_volumes(self, catalog_name: str, schema_name: str):
        # Fetch the list of volumes for the specified catalog and schema
        volumes_list_obj = self.w.volumes.list(catalog_name=catalog_name, schema_name=schema_name)
        # Convert the result into a Python list
        volumes_list = list(volumes_list_obj)
        return volumes_list

    # Method to retrieve functions within a specified catalog and schema.
    # Args:
    #     catalog_name (str): The name of the catalog to retrieve functions from
    #     schema_name (str): The name of the schema to retrieve functions from
    # Returns:
    #     List of functions within the specified catalog and schema, as a Python list
    def get_functions(self, catalog_name: str, schema_name: str):
        # Fetch the list of functions for the specified catalog and schema
        functions_list_obj = self.w.functions.list(catalog_name=catalog_name, schema_name=schema_name)
        # Convert the result into a Python list
        functions_list = list(functions_list_obj)
        return functions_list

    # Method to retrieve registered models, optionally filtered by catalog and schema.
    # Args:
    #     catalog_name (str, optional): The name of the catalog to retrieve models from
    #     schema_name (str, optional): The name of the schema to retrieve models from
    # Returns:
    #     List of registered models, as a Python list
    def get_models(self, catalog_name: str = None, schema_name: str = None):
        # Fetch the list of registered models, optionally filtered by catalog and schema
        models_list_obj = self.w.registered_models.list(
            catalog_name=catalog_name,
            schema_name=schema_name
        )
        # Convert the result into a Python list
        models_list = list(models_list_obj)
        return models_list

    # Unified method to list any Unity Catalog object type.
    # Args:
    #     object_type (str): Type of UC object ('catalogs', 'schemas', 'tables', 'volumes', 'functions', 'models')
    #     catalog_name (str, optional): Catalog name (required for schemas, tables, volumes, functions; optional for models)
    #     schema_name (str, optional): Schema name (required for tables, volumes, functions; optional for models)
    # Returns:
    #     List of UC objects of the specified type
    # Raises:
    #     ValueError: If object_type is invalid or required parameters are missing
    def list_uc_objects(self, object_type: str, catalog_name: str = None, schema_name: str = None):
        if object_type == 'catalogs':
            return self.list_catalogs()
        elif object_type == 'schemas':
            if not catalog_name:
                raise ValueError("catalog_name is required for listing schemas")
            return self.get_schemas(catalog_name)
        elif object_type == 'tables':
            if not catalog_name or not schema_name:
                raise ValueError("catalog_name and schema_name are required for listing tables")
            return self.get_tables(catalog_name, schema_name)
        elif object_type == 'volumes':
            if not catalog_name or not schema_name:
                raise ValueError("catalog_name and schema_name are required for listing volumes")
            return self.get_volumes(catalog_name, schema_name)
        elif object_type == 'functions':
            if not catalog_name or not schema_name:
                raise ValueError("catalog_name and schema_name are required for listing functions")
            return self.get_functions(catalog_name, schema_name)
        elif object_type == 'models':
            return self.get_models(catalog_name, schema_name)
        else:
            raise ValueError(f"Invalid object_type: {object_type}. Must be one of: catalogs, schemas, tables, volumes, functions, models")

    def check_table_exists(self, table_name: str) -> bool:
        """
        Check if a table exists in Databricks.

        If only a table name is provided, the table is assumed to be in the
        <catalog>.gold schema.
        """

        full_table_name = None  
        try:
            parts = table_name.split(".")

            if len(parts) == 1:
                # Only table provided 
                full_table_name = f"{self.catalog_name}.gold.{table_name}"

            elif len(parts) == 3:
                # catalog.schema.table
                full_table_name = table_name

            else:
                raise ValueError(f"Invalid table name format: {table_name}")

            table = self.w.tables.exists(full_name=full_table_name)
            app_logger.info(f"Table {full_table_name} exists: {table.table_exists}")
            return table.table_exists

        except Exception as e:
            # Re-raise permission errors so callers can distinguish
            # "no access" from "table genuinely doesn't exist"
            from lakefusion_utility.utils.dbx_error_handler import is_dbx_permission_error
            if is_dbx_permission_error(e):
                raise
            app_logger.debug(
                f"Table {full_table_name or table_name} does not exist: {str(e)}"
            )
            return False

    
    def create_volume_folder(self,entity_id:str,model_id:Union[str,int]) -> None:
        """
        Create a folder in Unity Catalog volume using the Databricks SDK.
    
        Args:
         folder_path (str): Path of the folder to create
        """
        try:

            volume_path = f"/Volumes/{self.catalog_name}/metadata/metadata_files"
            model_folder_path=f'experiment_{model_id}' if(isinstance(model_id,int)) else 'prod'
            entity_folder_path=f'entity_{entity_id}'
            full_path_entity = f'{volume_path}/{entity_folder_path}_{model_folder_path}'
            return full_path_entity
        except Exception as e:
            app_logger.exception(f"Error creating folder in volume: {str(e)}")

    def upload_data_as_json(self, folder_path: str, file_name:str, data: dict):
        """
        Uploads a dictionary as a JSON file to a Databricks DBFS path.

        :param file_path: The full DBFS path where the file will be uploaded (e.g., "/mnt/volume/my_file.json").
        :param data: The dictionary to save as a JSON file.
        """
        # Convert the dictionary to a JSON string
        json_data = json.dumps(data, default=str)
        # Convert the JSON string to bytes
        file_content = BytesIO(json_data.encode('utf-8'))
    
        # Build full path
        full_path = f"{folder_path}_{file_name}"
        try:
            # Write the file to DBFS
            self.w.dbfs.upload(full_path, file_content, overwrite=True)
            app_logger.info(f"File uploaded successfully to {full_path}")
        except Exception as e:
            app_logger.exception(f"Failed to upload file to {full_path}: {e}")
            raise e

    def upload_metadata_file_to_volume(self, file_name: str, data: dict):
        """
        Uploads a dictionary as a JSON file to the metadata folder in Databricks Volume.

        :param file_name: The filename to upload (e.g., "pt_models_config.json")
        :param data: The dictionary to save as a JSON file.
        """
        # Convert the dictionary to a JSON string
        json_data = json.dumps(data, default=str, indent=2)
        # Convert the JSON string to bytes
        file_content = BytesIO(json_data.encode('utf-8'))

        volume_file_path = f"/Volumes/{self.catalog_name}/metadata/metadata_files/{file_name}"

        try:
            # Write the file to Databricks Volume
            self.w.files.upload(volume_file_path, file_content, overwrite=True)
            app_logger.info(f"JSON file uploaded successfully to Volume: {volume_file_path}")
        except Exception as e:
            app_logger.exception(f"Failed to upload JSON file to Volume {volume_file_path}: {e}")
            raise e


    def upload_data_as_xlsx(self,file_path):
        file_name = os.path.basename(file_path)
        volume_file_path = f"/Volumes/demo_source/ajay_schema/volume/{file_name}"
        with open(file_path, 'rb') as file:
            contents = file.read()
        self.w.files.upload(file_path=volume_file_path, contents=contents, overwrite=True)
        return "File uploaded to volume",volume_file_path

class MonitoringService:
    def __init__(self, token: str):
        self.token = token
        self.w = _create_workspace_client(token)

    def get_monitor_for_table(self, table_name: str) -> Optional[MonitorInfo]:
        """
        Check if a monitoring task already exists for a given table.
        
        Args:
            table_name (str): The full path of the table to check
            
        Returns:
            MonitorInfo or None: The existing monitor info if found, None otherwise
        """
        try:
            # Try to get the monitor directly by table_name
            monitor = self.w.quality_monitors.get(table_name=table_name)
            return monitor
        except Exception as e:
            app_logger.debug(f"No existing monitor found for table {table_name}: {str(e)}")
            return None

    def create_snapshot_monitor(
        self,
        table_name: str,
        output_schema_name: Optional[str] = None,
        failure_notifications: Optional[List[str]] = None,
        quartz_cron_expression: Optional[str] = None,
        timezone_id: Optional[str] = None,
        warehouse_id: Optional[str] = None
    ) -> MonitorInfo:
        """
        Create a snapshot monitor for the specified table.

        Args:
            table_name (str): Full name of the table.
            output_schema_name (Optional[str]): Schema where output metric tables are created.
            failure_notifications (Optional[List[str]]): List of email addresses for notifications.
            quartz_cron_expression (Optional[str]): Quartz cron expression for scheduling.
            timezone_id (Optional[str]): Timezone ID for the schedule.
            warehouse_id (Optional[str]): Warehouse ID for dashboard creation.

        Returns:
            MonitorInfo: Information about the created monitor.
        """
        # Check if monitor already exists for this table
        existing_monitor = self.get_monitor_for_table(table_name)
        if existing_monitor:
            app_logger.info(f"Monitor already exists for table {table_name}, reusing existing monitor")
            return existing_monitor
            
        # Create MonitorSnapshot instance
        snapshot_config = MonitorSnapshot()
        monitor_notifications = None
        schedule = None
        
        table_path = table_name.split(".")
        if (len(table_path) >= 3):
            table_path = table_path[:2]
        default_output_schema = ".".join(table_path)
        
        # Prepare notifications
        if failure_notifications:
            monitor_notifications = MonitorNotifications(
                on_failure=MonitorDestination(failure_notifications or [])
            )

        if quartz_cron_expression and timezone_id:
            schedule = MonitorCronSchedule(quartz_cron_expression=quartz_cron_expression, timezone_id=timezone_id)

        # Create the monitor using the WorkspaceClient
        if schedule:
            monitor_info = self.w.quality_monitors.create(
                table_name=table_name,
                assets_dir="/LakeFusion/databricks_lakehouse_monitoring",
                output_schema_name=output_schema_name or default_output_schema,
                notifications=monitor_notifications,
                schedule=schedule,
                snapshot=snapshot_config,
                warehouse_id=warehouse_id
            )
        else:
            monitor_info = self.w.quality_monitors.create(
                table_name=table_name,
                assets_dir="/LakeFusion/databricks_lakehouse_monitoring",
                output_schema_name=output_schema_name or default_output_schema,
                notifications=monitor_notifications,
                snapshot=snapshot_config,
                warehouse_id=warehouse_id
            )

        return monitor_info
    
    def refresh_manually(self, table_name: str) -> MonitorInfo:
        """
        Manually refresh a monitor for the specified table.

        Args:
            table_name (str): Full name of the table. 
        Returns:
            MonitorInfo: Information about the refreshed monitor.
        """
        monitor_info = self.w.quality_monitors.run_refresh(table_name=table_name)
        return monitor_info
    
    def list_monitors(self) -> List[MonitorInfo]:
        """
        List all monitors in the Databricks workspace.

        Returns:
            List[MonitorInfo]: A list of all monitoring information.
        """
        monitors_list = self.w.quality_monitors.list()
        return list(monitors_list)

    def get_monitor(self, table_name: str) -> MonitorInfo:
        """
        Get details of a specific monitor by its ID.

        Args:
            monitor_id (str): The ID of the monitor to retrieve.

        Returns:
            MonitorInfo: Information about the specified monitor.
        """
        return self.w.quality_monitors.get(table_name=table_name)

    def delete_monitor(self, table_name: str) -> None:
        """
        Delete a monitor by its ID.

        Args:
            monitor_id (str): The ID of the monitor to delete.
        """
        self.w.quality_monitors.delete(table_name=table_name)

    def get_refresh_status(self, table_name: str) -> MonitorSnapshot:
        """
        Get the latest refresh status of a monitor by its table name.

        Args:
            table_name (str): The table name of the monitor.

        Returns:
            MonitorSnapshot: The latest snapshot information of the monitor.

        Raises:
            MonitorFailedError: monitor exists but is in MONITOR_STATUS_FAILED.
                Recovery requires delete + recreate (Databricks rejects
                refresh / list_refreshes / run_refresh in this state).
            ValueError: monitor doesn't exist OR exists but has no refreshes
                yet. Callers (e.g. profiling_tasks) treat this as "trigger a
                first refresh"; that path is safe for these two cases but
                NOT for the failed-state case above.
        """
        # Check monitor status FIRST. Databricks rejects list_refreshes with
        # an opaque BadRequest when the monitor is in MONITOR_STATUS_FAILED,
        # so probe via get() and short-circuit with a clear error type that
        # callers can distinguish from "no refreshes yet".
        try:
            monitor = self.w.quality_monitors.get(table_name=table_name)
        except Exception as e:
            raise ValueError(
                f"No monitor found for table '{table_name}': {e}"
            ) from None

        status = str(getattr(monitor, "status", "") or "")
        if status.endswith("MONITOR_STATUS_FAILED") or status == "FAILED":
            raise MonitorFailedError(
                f"Monitor on '{table_name}' is in MONITOR_STATUS_FAILED — "
                f"list_refreshes / run_refresh are not supported in this state. "
                f"Delete and recreate the monitor (Catalog Explorer → Quality "
                f"→ Monitoring, or call quality_monitors.delete + .create) to recover."
            )

        refreshes = self.w.quality_monitors.list_refreshes(table_name=table_name)

        if refreshes.refreshes:
            # Sort by start_time to ensure latest
            latest_refresh = max(
                refreshes.refreshes,
                key=lambda r: r.start_time_ms or 0
            )
            return latest_refresh
        else:
            raise ValueError(f"No refreshes found for monitor with table name: {table_name}")

from databricks.sdk.service import workspace as ws
from lakefusion_utility.utils.databricks_host import get_databricks_host
DATABRICKS_HOST = get_databricks_host()
 
class NotebookService:
    token: str
    w: WorkspaceClient

    def __init__(self, token: str) -> None:
        self.token = token
        # Initialize the WorkspaceClient to interact with Databricks API
        self.w = _create_workspace_client(token)

    def list_workspace_contents(
        self,
        path: str,
        notebooks_modified_after: Optional[int] = None,
        recursive: Optional[bool] = False
    ) -> List[ws.ObjectInfo]:
        """Retrieve directory structure in the Databricks workspace for a given path."""
        workspace_objects = self.w.workspace.list(
            path=path,
            notebooks_modified_after=notebooks_modified_after,
            recursive=recursive
        )
        return list(workspace_objects)

    def import_single_file(
        self,
        source_file_path: str,
        target_path: str,
        language: ws.Language = None,
        fmt: ws.ImportFormat = ws.ImportFormat.AUTO,
        overwrite: bool = True,
    ) -> None:
        """
        Imports a single file into Databricks workspace at the given target path.

        :param source_file_path: Local file path
        :param target_path: Destination workspace path
        :param language: Workspace language (default: Python)
        :param fmt: Import format (SOURCE, JUPYTER, etc.)
        :param overwrite: Overwrite existing workspace file
        """
        if not os.path.exists(source_file_path) or not os.path.isfile(source_file_path):
            raise FileNotFoundError(f"File does not exist: {source_file_path}")

        print(f"[{datetime.now()}] Importing file: {source_file_path} -> {target_path}")

        # ✅ Read file as bytes
        with open(source_file_path, "rb") as f:
            encoded_content = base64.b64encode(f.read()).decode("utf-8")

        self.w.workspace.import_(
            path=target_path,
            content=encoded_content,
            format=fmt,
            language=language,
            overwrite=overwrite,
        )

        print(f"[{datetime.now()}] ✅ Successfully imported to {target_path}")

    def recursive_import_files(
        self,
        artifacts_dir: str,
        target_path: str,
        language: ws.Language = ws.Language.PYTHON,
        fmt: ws.ImportFormat = ws.ImportFormat.SOURCE,
        overwrite: bool = True,
    ) -> None:
        """
        Imports all files from a local artifacts directory into the Databricks Workspace.

        Args:
            artifacts_dir (str): Local path of artifacts directory.
            target_path (str): Target workspace path in Databricks.
            language (ws.Language): Language for the notebooks (default: PYTHON).
            fmt (ws.ImportFormat): Import format (default: SOURCE).
            overwrite (bool): Whether to overwrite existing notebooks.
        """
        for root, _, files in os.walk(artifacts_dir):
            # Map local dir → workspace dir
            relative_path = os.path.relpath(root, artifacts_dir)
            ws_subdir = (
                target_path if relative_path == "." 
                else os.path.join(target_path, relative_path).replace("\\", "/")
            )

            # Ensure the folder exists in Databricks
            self.w.workspace.mkdirs(ws_subdir)

            for file in files:
                local_path = os.path.join(root, file)
                
                # Remove the file extension for the workspace path
                file_name_without_ext = os.path.splitext(file)[0]
                ws_path = os.path.join(ws_subdir, file_name_without_ext).replace("\\", "/")

                # Read file content
                with open(local_path, "rb") as f:
                    content = base64.b64encode(f.read()).decode("utf-8")

                # Guess language and format from file extension
                ext = os.path.splitext(file)[1].lower()
                if ext == ".py":
                    lang = ws.Language.PYTHON
                    import_format = fmt
                elif ext == ".scala":
                    lang = ws.Language.SCALA
                    import_format = fmt
                elif ext == ".sql":
                    lang = ws.Language.SQL
                    import_format = fmt
                elif ext == ".r":
                    lang = ws.Language.R
                    import_format = fmt
                elif ext == ".ipynb":
                    lang = ws.Language.PYTHON
                    import_format = ws.ImportFormat.JUPYTER
                else:
                    lang = language  # fallback to default
                    import_format = fmt

                app_logger.info(f"📤 Uploading {local_path} → {ws_path} as {lang.name} (format: {import_format.name})")

                self.w.workspace.import_(
                    path=ws_path,
                    content=content,
                    format=import_format,
                    language=lang,
                    overwrite=overwrite,
                )

        app_logger.info(f"🚀 Imported all files from {artifacts_dir} into {target_path}")

    def get_object_info(self, target_path: str) -> ObjectInfo:
        """
        Fetch workspace object info given a target path.
        """
        try:
            info = self.w.workspace.get_status(target_path)
            app_logger.info(f"ℹ️ Retrieved object info for {target_path}: {info}")
            return info
        except Exception as e:
            app_logger.error(
                f"❌ Failed to fetch object info for {target_path}. Error: {str(e)}",
                exc_info=True,
            )
            raise

    def set_permissions(
        self,
        workspace_object: ObjectInfo,
        principal_id: str,
        permission: PermissionLevel,
        is_service_principal: bool = False,
    ) -> None:
        """
        Set IAM permissions on a workspace object given its path.

        Args:
            target_path (str): Databricks workspace object path.
            principal_id (str): User email or Service Principal UUID.
            permission (PermissionLevel): Permission to grant (e.g., CAN_MANAGE, CAN_READ).
            is_service_principal (bool): If True, treats principal_id as SPN ID.
        """
        try:
            if not workspace_object or not workspace_object.object_id:
                raise ValueError(f"No valid object found")

            # Build ACL entry
            if is_service_principal:
                ac_entry = AccessControlRequest(
                    service_principal_name=principal_id,
                    permission_level=permission,
                )
            else:
                ac_entry = AccessControlRequest(
                    user_name=principal_id,
                    permission_level=permission,
                )

            OBJECT_TYPE_MAP = {
                "DIRECTORY": "directories",
                "NOTEBOOK": "notebooks",
                "FILE": "files",
                "REPO": "repos"
            }

            # Map object_type enum → request string
            obj_type_key = workspace_object.object_type.name
            request_object_type = OBJECT_TYPE_MAP.get(obj_type_key)

            if not request_object_type:
                request_object_type = workspace_object.object_type.value
            
            # Apply permission
            self.w.permissions.set(
                request_object_type=request_object_type,
                request_object_id=workspace_object.object_id,
                access_control_list=[ac_entry],
            )

            app_logger.info(
                f"✅ Granted {permission.name} on {workspace_object.object_id} "
                f"to {'SPN' if is_service_principal else 'User'}: {principal_id}"
            )
        except Exception as e:
            app_logger.error(
                f"❌ Failed to set {permission} on {workspace_object.object_id} for {principal_id}. Error: {str(e)}",
                exc_info=True,
            )
            raise
    
    def export_notebook(self, notebook_path: str, fmt: ws.ExportFormat = ws.ExportFormat.DBC) -> bytes:
        """
        Export a Databricks notebook from the workspace as a DBC (or other supported format).
        Args:
            notebook_path (str): Full path in Databricks workspace (e.g., "/Users/xxx/Notebook").
            fmt (ws.ExportFormat): Export format (default: DBC).
        Returns:
            bytes: The raw content of the notebook archive.
        """
        try:
            # Call the WorkspaceClient export method
            obj = self.w.workspace.export(path=notebook_path, format=fmt)
            if not obj or not obj.content:
                raise ValueError(f"No content returned for notebook: {notebook_path}")

            # Decode the Base64 content
            dbc_bytes = base64.b64decode(obj.content)
            app_logger.info(f"✅ Successfully exported notebook {notebook_path}")
            return dbc_bytes

        except Exception as e:
            app_logger.error(
                f"❌ Failed to export notebook {notebook_path}. Error: {str(e)}",
                exc_info=True
            )
            raise

    def ensure_workspace_folder(self, folder_path: str) -> None:
        """
        Ensure that a workspace folder exists. Creates it if it does not exist.
        Args:
            folder_path (str): Target folder path in Databricks workspace
        """
        try:
            self.w.workspace.mkdirs(folder_path)
            app_logger.info(f"✅ Ensured workspace folder exists: {folder_path}")
        except Exception as e:
            app_logger.warning(f"⚠️ Could not create workspace folder {folder_path}: {e}")


    def import_dbc_notebook(self, local_path: str, target_path: str) -> None:
        """
        Import a DBC notebook into Databricks workspace.
        Args:
            local_path (str): Local path to the DBC file
            target_path (str): Target notebook path in Databricks workspace
        """
        # Read and encode DBC content
        with open(local_path, "rb") as f:
            dbc_content = f.read()
            dbc_b64 = base64.b64encode(dbc_content).decode("utf-8")

        # Ensure target folder exists
        folder_path = os.path.dirname(target_path)
        self.ensure_workspace_folder(folder_path)

        # Import notebook
        self.w.workspace.import_(
            path=target_path,
            content=dbc_b64,
            format=ws.ImportFormat.DBC,
            language=None
        )
        app_logger.info(f"✅ Imported notebook {local_path} → {target_path}")
    
class JobService:
    token: str
    w: WorkspaceClient

    def __init__(self, token: str) -> None:
        self.token = token
        self.w = _create_workspace_client(token)

    def get_single_task_job(self, job_id: int):
        """
        Retrieves information about a specific single-task job.

        Args:
            job_id (int): The unique identifier of the job.

        Returns:
            JobInfo: Information about the specified job.
        """
        job = self.w.jobs.get(job_id=job_id)
        return job

    def create_single_task_job(self, 
                               job_name: str, 
                               notebook_path: str, 
                               job_parameters: Dict[str, str], 
                               failure_notification_emails: List[str], 
                               quartz_cron_expression: Optional[str] = None, 
                               timezone_id: Optional[str] = None) -> CreateResponse:
        """
        Creates a single-task Databricks job with the given parameters, including optional cron-based scheduling.

        Args:
            job_name (str): The name of the job.
            notebook_path (str): Path to the notebook in the workspace.
            job_parameters (Dict[str, str]): Dictionary of parameters for the job.
            failure_notification_emails (List[str]): List of emails to notify on failure.
            quartz_cron_expression (Optional[str], optional): Quartz Cron expression for job scheduling. Defaults to None.
            timezone_id (Optional[str], optional): Timezone ID for the cron schedule. Defaults to None.

        Returns:
            CreateResponse: Details of the created job.
        """

        # Feature: RESOURCE TAGGING – Automatically tag all Cloud and Databricks resources provisioned by LakeFusion with metadata 
        # for cost tracking, version visibility, and governance/audit compliance.
        tags = get_resource_tags()
        if tags is None:
            tags = {}

        task = Task(
            task_key=f"{job_name.replace(' ', '_')}_task",
            run_if=RunIf.ALL_SUCCESS,
            notebook_task=NotebookTask(
                notebook_path=notebook_path,
                source=Source.WORKSPACE
            ),
            email_notifications=TaskEmailNotifications(
                on_failure=failure_notification_emails
            )
        )

        job_parameters_list = [
            JobParameterDefinition(name=k, default=v) 
            for k,v in job_parameters.items()
        ]

        create_params = {
            "name": job_name,
            "tasks": [task],
            "parameters": job_parameters_list,
            "tags": tags
        }

        if quartz_cron_expression and timezone_id:
            create_params["schedule"] = CronSchedule(
                quartz_cron_expression=quartz_cron_expression,
                timezone_id=timezone_id
            )

        created_job = self.w.jobs.create(**create_params)
        job: Job = self.w.jobs.get(job_id=created_job.job_id)

        return job

    def update_single_task_job(self, 
                        job_id: int, 
                        job_name: str,
                        notebook_path: str, 
                        job_parameters: Dict[str, str], 
                        failure_notification_emails: List[str], 
                        quartz_cron_expression: Optional[str] = None, 
                        timezone_id: Optional[str] = None):
        """
        Updates an existing single-task Databricks job with the provided parameters,
        including optional cron-based scheduling.

        Args:
            job_id (int): The unique identifier of the job to update.
            job_name (str): The updated name for the job.
            notebook_path (str): Path to the notebook in the workspace.
            job_parameters (Dict[str, str]): Dictionary of parameters to set for the job.
            failure_notification_emails (List[str]): List of emails to notify on job failure.
            quartz_cron_expression (Optional[str], optional): Quartz Cron expression for job scheduling. Defaults to None.
            timezone_id (Optional[str], optional): Timezone ID for the cron schedule. Defaults to None.

        Returns:
            CreateResponse: Details of the updated job, or an error if the update fails.
        """

        # Feature: RESOURCE TAGGING – Automatically tag all Cloud and Databricks resources provisioned by LakeFusion with metadata 
        # for cost tracking, version visibility, and governance/audit compliance.
        tags = get_resource_tags()
        if tags is None:
            tags = {}

        # Retrieve the current settings for the job
        try:
            job: Job = self.w.jobs.get(job_id=job_id)
        except Exception as e:
            raise Exception(f"Failed to retrieve job with ID {job_id}: {e}")

        # Define the updated task and schedule settings
        updated_task = Task(
            task_key=f"{job_name.replace(' ', '_')}_task",
            run_if=RunIf.ALL_SUCCESS,
            notebook_task=NotebookTask(
                notebook_path=notebook_path,
                source=Source.WORKSPACE
            ),
            email_notifications=TaskEmailNotifications(
                on_failure=failure_notification_emails
            )
        )

        # Convert job parameters to the expected format
        job_parameters_list = [
            JobParameterDefinition(name=k, default=v) 
            for k, v in job_parameters.items()
        ]

        # Update the current job settings with new values
        new_settings: JobSettings = job.settings
        new_settings.tasks = [updated_task]
        new_settings.name = job_name
        new_settings.parameters = job_parameters_list
        new_settings.tags = tags

        # Update the schedule only if both parameters are provided
        if quartz_cron_expression and timezone_id:
            new_settings.schedule = CronSchedule(
                quartz_cron_expression=quartz_cron_expression,
                timezone_id=timezone_id
            )
        else:
            # Remove schedule if it exists and we're not setting a new one
            if hasattr(new_settings, "schedule"):
                new_settings.schedule = None

        # Apply the updates to the job in Databricks
        self.w.jobs.reset(job_id=job_id, new_settings=new_settings)
        
        # Fetch the updated job details after the reset
        updated_job = self.w.jobs.get(job_id=job_id)
        return updated_job  # Return the updated job details

    def delete_job(self, job_id: int) -> None:
        """
        Delete a job by its ID.

        Args:
            job_id (int): The ID of the job to delete.
        """
        self.w.jobs.delete(job_id=job_id)
        
    def run_job(self,job_id):
        job_run=self.w.jobs.run_now(job_id=job_id)
        return job_run.response
    
    def cancel_run(self, run_id: int) -> None:
        """Cancels a running job."""
        self.w.jobs.cancel_run(run_id=run_id)

    def get_job_runs(
        self, 
        job_id: int, 
        start_time: Optional[datetime] = None,
        limit: int = 25,
        expand_tasks: bool = True,
        active_only: bool = False
    ):
        """Gets recent runs of a specific job."""
        if not start_time:
            start_time = datetime.now() - timedelta(days=30)  # Last 30 days by default

        return self.w.jobs.list_runs(
            job_id=job_id,
            start_time=int(start_time.timestamp()) * 1000,  # Convert to milliseconds
            limit=limit,
            expand_tasks=expand_tasks,
            active_only=active_only
        )

class FoundationModelService:
    def __init__(self, token: str):
        self.token = token
        self.w = _create_workspace_client(token)
    def list_foundation_models(self):
        """
        List all foundation models in the Databricks workspace.
        """
        models_list=[]
        for endpoint in self.w.serving_endpoints.list():
            if endpoint.config is not None:
               for served_entity in endpoint.config.served_entities:
                   if(served_entity.foundation_model is not None):
                      models_list.append(endpoint)
        return models_list

class VectorSearchService:
    def __init__(self, token: str):
        self.token = token or generate_pat()
        self.w = _create_workspace_client(self.token)
        #self.vsc=VectorSearchEndpointsAPI(api_client=self.w)
    def list_vectorsearch_endpoint(self):
        """
        List all foundation models in the Databricks workspace.
        """
        try:
            url = f"{DATABRICKS_HOST}/api/2.0/vector-search/endpoints/"

            headers = {
              'Authorization': f'Bearer {self.token}'
            }
            response = requests.request("GET", url, headers=headers)
            vs_endpoint_list=[]
            data = response.json()

            # Check if "endpoints" key exists and is a list
            if "endpoints" in data and isinstance(data["endpoints"], list):
                for endpoint in data["endpoints"]:
                    vs_endpoint_list.append(endpoint.get("name"))
            else:
                app_logger.info("No endpoints found in response.")

            return vs_endpoint_list
        except Exception as e:
            app_logger.exception(f"No Endpoint found. Reason - {str(e)}")

    def delete_index(self, index_name: str):
        """
        Delete a Vector Search index by its full Unity Catalog name (e.g.
        "catalog.schema.entity_master_prod_index"). 404 on the index already
        being absent is treated as success — the goal is "make sure it's gone".

        Args:
            index_name: Fully-qualified index name.

        Returns:
            dict: {"status": "deleted" | "not_found" | "failed", "detail": ...}
        """
        try:
            url = f"{DATABRICKS_HOST}/api/2.0/vector-search/indexes/{index_name}"
            headers = {"Authorization": f"Bearer {self.token}"}
            response = requests.request("DELETE", url, headers=headers)
            if response.status_code in (200, 204):
                app_logger.info(f"Vector Search index deleted: {index_name}")
                return {"status": "deleted", "index_name": index_name}
            if response.status_code == 404:
                app_logger.info(f"Vector Search index not found (already gone): {index_name}")
                return {"status": "not_found", "index_name": index_name}
            detail = (response.text or "")[:500]
            app_logger.warning(
                f"Vector Search index delete returned {response.status_code} "
                f"for {index_name}: {detail}"
            )
            return {"status": "failed", "index_name": index_name, "detail": detail}
        except Exception as e:
            app_logger.exception(
                f"Failed to delete Vector Search index {index_name}. Reason - {str(e)}"
            )
            return {"status": "failed", "index_name": index_name, "detail": str(e)}
        

class DatabricksJobManager:
    token: str
    w: WorkspaceClient
    def __init__(self, token: str)-> None:
        """
        Initialize the DatabricksJobRunner.

        Args:
            access_token (str): The Databricks personal access token.
            databricks_host (str): Databricks workspace URL (e.g., "https://<databricks-instance>.cloud.databricks.com").
        """
        self.token = token
        self.w = _create_workspace_client(token)

    def create_and_submit_job(self,run_name:str,tasks_list:list,service_principal:Optional[str]):
        """
        Create and run a Databricks job.
        """
        # Grant the service principal CAN_MANAGE on the run via the submit call.
        # NOTE: "runs" is NOT a valid object type for the permissions API
        # (w.permissions.set), so run-level access must be passed inline to
        # jobs.submit via access_control_list (JobAccessControlRequest).
        access_control_list = None
        if service_principal:
            access_control_list = [
                JobAccessControlRequest(
                    service_principal_name=service_principal,
                    permission_level=JobPermissionLevel.CAN_MANAGE,
                )
            ]

        job_submit = self.w.jobs.submit(
            run_name=f"{run_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            tasks=tasks_list,
            access_control_list=access_control_list,
        )
        job_run_response = job_submit.response
        return job_run_response
    
    def get_job_info(self,job_id:str):
        job_details = self.w.jobs.get(job_id=job_id)
        return job_details
    
    def create_job(self,run_name:str,job_clusters:Optional[list]=None,tasks_list:Optional[list]=None,job_parameters:Optional[str]=None,schedule:Optional[str]=None,email_notifcations:Optional[str]=None,RunAs:Optional[str]=None):
        """
        Create and run a Databricks job.
        """
        
        # Feature: RESOURCE TAGGING – Automatically tag all Cloud and Databricks resources provisioned by LakeFusion with metadata 
        # for cost tracking, version visibility, and governance/audit compliance.
        tags = get_resource_tags()
        if tags is None:
            tags = {}

        permissions = [
        JobAccessControlRequest(
            permission_level=JobPermissionLevel.CAN_MANAGE, 
            group_name="users"
        )]
      
        if(RunAs is None):
           job_run = self.w.jobs.create(
                name=f"{run_name}",
                tasks=tasks_list,schedule=schedule,parameters=job_parameters,email_notifications=email_notifcations,max_concurrent_runs=3,access_control_list=permissions,
                tags=tags
            )
        else:
           job_run = self.w.jobs.create(
                name=f"{run_name}",
                tasks=tasks_list,schedule=schedule,parameters=job_parameters,email_notifications=email_notifcations,run_as=JobRunAs(service_principal_name=RunAs),max_concurrent_runs=3,access_control_list=permissions,
                tags=tags
            )
        return job_run.job_id
    
    def update_job(self,job_id:str,new_quartz_cron_expression:Optional[str],new_status=Optional[str]):
        """
        Create and run a Databricks job.
        """
        
        # Feature: RESOURCE TAGGING – Automatically tag all Cloud and Databricks resources provisioned by LakeFusion with metadata 
        # for cost tracking, version visibility, and governance/audit compliance.
       

        cronschedule=CronSchedule(quartz_cron_expression=new_quartz_cron_expression,timezone_id='UTC',pause_status=new_status)
        new_job_settings=JobSettings(schedule=cronschedule)
        self.w.jobs.update(job_id=job_id,new_settings=new_job_settings)
        
    
    def create_job_without_schedule(self,file_path:str,notebook_path:str,job_name:str):
        # Feature: RESOURCE TAGGING – Automatically tag all Cloud and Databricks resources provisioned by LakeFusion with metadata 
        # for cost tracking, version visibility, and governance/audit compliance.
        tags = get_resource_tags()
        if tags is None:
            tags = {}

        job_task = [jobs.Task(notebook_task=jobs.NotebookTask(notebook_path=notebook_path),task_key=f"{job_name}_task")]
        job_parameter = [jobs.JobParameterDefinition(name="file_path", default=file_path)]
        jobs_list = self.w.jobs.list(name=job_name)
        job_id_list = [job.job_id for job in jobs_list]
        if len(job_id_list) == 0:
            created_job = self.w.jobs.create(name=job_name,
                                tasks=job_task,
                                parameters=job_parameter, tags=tags)
            job_id = created_job.job_id
        else:
            job_id = job_id_list[0]
            created_job = self.w.jobs.reset(job_id=job_id,new_settings=jobs.JobSettings(name=job_name,
                                tasks=job_task,
                                parameters=job_parameter, tags=tags))
        return job_id

    def run_job(self,job_id):
        job_run=self.w.jobs.run_now(job_id=job_id)
        return job_run.response
    
    def reset_job(self,job_id,name,job_clusters:Optional[list]=None,tasks_list:Optional[list]=None,job_parameters:Optional[dict]=None,RunAs:Optional[str]=None):
        # Feature: RESOURCE TAGGING – Automatically tag all Cloud and Databricks resources provisioned by LakeFusion with metadata 
        # for cost tracking, version visibility, and governance/audit compliance.
        tags = get_resource_tags()
        if tags is None:
            tags = {}

        if(job_clusters is None):
            new_settings = jobs.JobSettings(name=name,tasks=tasks_list,parameters=job_parameters,run_as=JobRunAs(service_principal_name=RunAs) if RunAs else None,max_concurrent_runs=3)
        else:
            new_settings = jobs.JobSettings(name=name,tasks=tasks_list,parameters=job_parameters,run_as=JobRunAs(service_principal_name=RunAs) if RunAs else None,max_concurrent_runs=3)
      
        new_settings.tags = tags
        self.w.jobs.reset(job_id=job_id,new_settings=new_settings)

        self.w.jobs.reset(job_id=job_id, new_settings=new_settings)


        permissions = [
        JobAccessControlRequest(
            permission_level=JobPermissionLevel.CAN_MANAGE, 
            group_name="users"
        )]

        # Ensure permissions is a list before passing to update_permissions
        if not isinstance(permissions, list):
           permissions = [permissions]  # Wrap in a list if it's not already one

        # Update job permissions
        self.w.jobs.update_permissions(
        job_id=job_id,
        access_control_list=permissions
    )
        
    def filter_max_attempts(self,data):
        # Create a dictionary to store the max attempt_number for each task_key
        max_attempts = {}
        for row in data:
            task_key = row['task_key']
            attempt_number = row['attempt_number']
            if task_key not in max_attempts or attempt_number > max_attempts[task_key]['attempt_number']:
               max_attempts[task_key] = row

        # Return the filtered list of rows
        return list(max_attempts.values())
       

    def get_job_run_status(self, job_run_id):
        try:
            job_run_id = f"{job_run_id}"
            run_details = self.w.jobs.get_run(run_id=job_run_id)
            task_statuses = []
            for task in run_details.tasks:
                task_status = {
                "task_key": task.task_key,
                "attempt_number":task.attempt_number,
                "state": str(task.state.life_cycle_state).split('.')[1],
                "result_state": str(task.state.result_state).split('.')[1] if task.state.result_state else None }
                task_statuses.append(task_status)
            latest_task_statuses=self.filter_max_attempts(task_statuses)
            return latest_task_statuses

        except Exception as e:
            app_logger.exception(f"Unable to get status of job run. Reason - {str(e)}")


    def stop_running_pipeline(self,job_run_id):
        """
        Stop a currently running Databricks job pipeline
    
        Args:
        run_id (int): Specific run ID to be cancelled
    
        Returns:
        dict: Cancellation response
        """
        try:
           # Cancel the specific job run
           cancel_response = self.w.jobs.cancel_run(run_id=job_run_id)
           return cancel_response.response
        except Exception as e:
            app_logger.exception(f"Unable to cancel the job . Reason - {str(e)}")

    def repair_and_run_job(self, job_run_id,latest_repair_id=None):
        """
        Repair a Databricks job run
    
        Args:
           run_id (int): Specific run ID to be repaired
    
        Returns:
             dict: Repair run response
        """
        try:
            # Repair the specific job run
            repair_response = self.w.jobs.repair_run(run_id=job_run_id,latest_repair_id=latest_repair_id,rerun_all_failed_tasks=True)
            return repair_response.response.repair_id
        except Exception as e:
            app_logger.exception(f"Unable to repair job . Reason - {str(e)}")
            return {
                "status": "error",
                "run_id": job_run_id,
                "error": str(e)
            }
        
    def delete_job(self, job_id: int) -> dict:
        """
        Delete a job by its ID.

        The Databricks SDK's jobs.delete() returns None on success (the API
        returns HTTP 200 with no body). We return a structured success dict
        so callers can rely on a consistent shape.

        Args:
            job_id (int): The ID of the job to delete.

        Returns:
            dict: {"status": "ok", "job_id": ...} on success, or
                  {"status": "error", "job_id": ..., "error": ...} on failure.
        """
        try:
            self.w.jobs.delete(job_id=job_id)
            return {"status": "ok", "job_id": job_id}
        except Exception as e:
            app_logger.exception(f"Unable to delete the job . Reason - {str(e)}")
            return {
                "status": "error",
                "job_id": job_id,
                "error": str(e),
            }

    def pause_job_schedule(self, job_id: str):
        """
        Pause a job's schedule.
        
        Args:
            job_id: The ID of the job to pause
        """
        try:
            job_details = self.w.jobs.get(job_id=job_id)
            if job_details.settings and job_details.settings.schedule:
                cron_schedule = CronSchedule(
                    quartz_cron_expression=job_details.settings.schedule.quartz_cron_expression,
                    timezone_id=job_details.settings.schedule.timezone_id or 'UTC',
                    pause_status=PauseStatus.PAUSED
                )
                new_job_settings = JobSettings(schedule=cron_schedule)
                self.w.jobs.update(job_id=job_id, new_settings=new_job_settings)
                app_logger.info(f"Paused job schedule for job_id: {job_id}")
            else:
                app_logger.warning(f"Job {job_id} has no schedule to pause")
        except Exception as e:
            app_logger.exception(f"Unable to pause job schedule. Reason - {str(e)}")
            raise

    def unpause_job_schedule(self, job_id: str):
        """
        Unpause/resume a job's schedule.
        
        Args:
            job_id: The ID of the job to unpause
        """
        try:
            job_details = self.w.jobs.get(job_id=job_id)
            if job_details.settings and job_details.settings.schedule:
                cron_schedule = CronSchedule(
                    quartz_cron_expression=job_details.settings.schedule.quartz_cron_expression,
                    timezone_id=job_details.settings.schedule.timezone_id or 'UTC',
                    pause_status=PauseStatus.UNPAUSED
                )
                new_job_settings = JobSettings(schedule=cron_schedule)
                self.w.jobs.update(job_id=job_id, new_settings=new_job_settings)
                app_logger.info(f"Unpaused job schedule for job_id: {job_id}")
            else:
                app_logger.warning(f"Job {job_id} has no schedule to unpause")
        except Exception as e:
            app_logger.exception(f"Unable to unpause job schedule. Reason - {str(e)}")
            raise

    def update_job_with_new_tasks(self, job_id: str, name: str, tasks_list: list, 
                                job_parameters: list, schedule: CronSchedule,
                                email_notifications: JobEmailNotifications = None,
                                RunAs: str = None):
        """
        Update a job with completely new tasks and settings.
        Used when transitioning between pipeline modes (separate <-> merged).
        
        This is a wrapper around reset_job that also handles schedule updates.
        
        Args:
            job_id: The ID of the job to update
            name: Job name
            tasks_list: New list of Task objects
            job_parameters: New list of JobParameter objects
            schedule: New CronSchedule object
            email_notifications: JobEmailNotifications object (optional)
            RunAs: Service principal name (optional)
        """
        try:
            tags = get_resource_tags()
            if tags is None:
                tags = {}

            new_settings = JobSettings(
                name=name,
                tasks=tasks_list,
                parameters=job_parameters,
                schedule=schedule,
                email_notifications=email_notifications,
                run_as=JobRunAs(service_principal_name=RunAs) if RunAs else None,
                max_concurrent_runs=3,
                tags=tags
            )
            
            self.w.jobs.reset(job_id=job_id, new_settings=new_settings)

            # Update permissions
            permissions = [
                JobAccessControlRequest(
                    permission_level=JobPermissionLevel.CAN_MANAGE, 
                    group_name="users"
                )
            ]
            self.w.jobs.update_permissions(job_id=job_id, access_control_list=permissions)
            
            app_logger.info(f"Updated job {job_id} with new tasks and settings")
            
        except Exception as e:
            app_logger.exception(f"Unable to update job with new tasks. Reason - {str(e)}")
            raise


class DatabricksDashboard:
    token: str
    w: WorkspaceClient

    def __init__(self, token: str) -> None:
        self.token = token
        self.w = _create_workspace_client(token)

    def create_dashboard(self, entity_name: str, warehouse_id: str, dashboard_json: str):
        """
        Recreate a Databricks Lakeview dashboard:
        - If dashboard exists → delete it
        - Create a new dashboard with the same name
        - Publish it
        """
        try:
            dashboard_name = f"{entity_name} LakeFusion Dashboard"

            # 1️⃣ Check if dashboard already exists
            existing_dashboard = next(
                (
                    d for d in self.w.lakeview.list()
                    if d.display_name == dashboard_name
                ),
                None
            )

            # 2️⃣ Delete existing dashboard (if present)
            if existing_dashboard:
                app_logger.info(
                    f"Dashboard '{dashboard_name}' exists "
                    f"(id={existing_dashboard.dashboard_id}). Deleting it."
                )

                self.w.lakeview.trash(
                    dashboard_id=existing_dashboard.dashboard_id
                )

            # 3️⃣ Ensure the parent workspace folder exists — lakeview.create
            # fails with "Path (...) doesn't exist" if it's missing. mkdirs is
            # idempotent and creates intermediate folders. Then grant the
            # workspace `users` group access so everyone can open the dashboards.
            parent_path = "/LakeFusion/Entity_Analytics_Dashboard"
            try:
                self.w.workspace.mkdirs(parent_path)
                try:
                    from databricks.sdk.service.workspace import (
                        WorkspaceObjectAccessControlRequest,
                        WorkspaceObjectPermissionLevel,
                    )
                    obj = self.w.workspace.get_status(parent_path)
                    self.w.workspace.set_permissions(
                        workspace_object_type="directories",
                        workspace_object_id=str(obj.object_id),
                        access_control_list=[
                            WorkspaceObjectAccessControlRequest(
                                group_name="users",
                                permission_level=WorkspaceObjectPermissionLevel.CAN_MANAGE,
                            )
                        ],
                    )
                    app_logger.info(f"Granted users CAN_MANAGE on '{parent_path}'.")
                except Exception as perm_e:
                    app_logger.warning(
                        f"Could not set permissions on '{parent_path}' (continuing): {perm_e}"
                    )
            except Exception as mk_e:
                app_logger.warning(f"mkdirs('{parent_path}') failed (continuing): {mk_e}")

            # 4️⃣ Create new dashboard
            dashboard = Dashboard(
                display_name=dashboard_name,
                warehouse_id=warehouse_id,
                parent_path=parent_path,
                serialized_dashboard=dashboard_json,
            )

            created_dashboard = self.w.lakeview.create(dashboard=dashboard)

            # 5️⃣ Publish dashboard
            self.w.lakeview.publish(
                dashboard_id=created_dashboard.dashboard_id
            )

            dashboard_url = (
                f"{self.w.config.host}/dashboardsv3/"
                f"{created_dashboard.dashboard_id}/published#"
            )

            app_logger.info(
                f"Dashboard '{dashboard_name}' recreated successfully."
            )

            return dashboard_url

        except Exception as e:
            # Re-raise so the caller (and the UI) sees the real reason instead of
            # a silent null. Previously this returned None, which hid the error.
            app_logger.exception(
                f"Unable to recreate or publish dashboard. Reason: {str(e)}"
            )
            raise


           

class DBFSService:

    def __init__(self, token: str):
        """
        Initialize the DBFSService.

        Args:
            access_token (str): The Databricks personal access token.
            databricks_host (str): Databricks workspace URL (e.g., "https://<databricks-instance>.cloud.databricks.com").
        """
        self.token = token
        self.w = _create_workspace_client(token)

    def upload_to_dbfs_stream(self, file_path, content):
        """
            Upload data to DBFS Stream using Databricks SDK.
        """
        content_bytes = content.encode('utf-8')
        base64_content = base64.b64encode(content_bytes).decode('utf-8')

        handle: CreateResponse = self.w.dbfs.create(path=file_path, overwrite=True)
        self.w.dbfs.add_block(handle=handle.handle, data=base64_content)
        self.w.dbfs.close(handle=handle.handle)

        return f"Uploaded data to {file_path}"


class CommonUtilities:

    def apply_tilde(self, input_string):
        """
        Converts a dot-separated string to a format where each part is wrapped in ^ symbols.
        
        Args:
            input_string (str): Input string in format "part1.part2.part3"
            
        Returns:
            str: Converted string in format "^part1^.^part2^.^part3^"
        
        Example:
            >>> convert_string_format("customer_demo.qa_customer_data.qa_crm")
            "^customer_demo^.^qa_customer_data^.^qa_crm^"
        """
        # Split the string by dots
        parts = input_string.split('.')
        
        # Wrap each part with ^ symbols
        wrapped_parts = [f"`{part}`" for part in parts]
        
        # Join them back with dots
        return '.'.join(wrapped_parts)
    

def set_user_agent_header():
    """
    Set the user agent header for the Databricks API requests.

    This function configures the user agent to include product and version information,
    as well as optional partner attribution.
    """

    from lakefusion_utility.utils.lf_utils import get_version_info

    # Set product name and version (Semantic Versioning required)
    version = get_version_info()
    product_name = version.get("productName", "LakeFusion")
    product_version = version.get("productVersion", "1.0.0")

    app_logger.info(f"Setting user agent with product name: {product_name} & product version: {product_version}")

    useragent.with_product(product_name, product_version)

    # Optional: Partner attribution
    useragent.with_partner(product_name)
    

def get_resource_tags():
    """
    Build resource tags for Databricks API requests.

    - Always includes default LakeFusion tags
    - If feature flag ENABLE_LAKEFUSION_TAG_USAGE is active:
        → fetch resource_tagging config
        → merge custom tags
    - Handles missing or invalid JSON safely
    """

    from lakefusion_utility.utils.lf_utils import get_version_info
    from lakefusion_utility.services.feature_flags_service import FeatureFlagService
    from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
    import lakefusion_utility.utils.database as db_module

    # ✅ Base system tags
    version = get_version_info()
    tags_dict = {
        "product": version.get("productName", "LakeFusion"),
        "version": version.get("productVersion", "1.0.0"),
        "partner": version.get("partner", version.get("productName", "LakeFusion")),
        "environment": version.get("environment", "production"),
    }

    # ✅ Open DB session internally
    try:
        with db_module.SessionLocal() as db:
            # ✅ Check feature flag
            if FeatureFlagService._is_feature_flag_enabled(db=db, name="ENABLE_LAKEFUSION_TAG_USAGE"):
                app_logger.info("✅ Feature flag ENABLE_LAKEFUSION_TAG_USAGE is ACTIVE — merging custom resource tags")

                db_config_properties_service = DBConfigPropertiesService(db=db)

                # ✅ Pull JSON string from DB
                lakefusion_custom_tags = db_config_properties_service.getDBConfigProperties(
                    "resource_tagging", required=True
                )

                # ✅ Parse JSON safely
                try:
                    custom_tag_dict = json.loads(lakefusion_custom_tags)
                except Exception:
                    app_logger.error("❌ Invalid JSON in DB config: 'resource_tagging'")
                    return tags_dict

                if isinstance(custom_tag_dict, dict):
                    tags_dict.update(custom_tag_dict)
                    app_logger.info(f"✅ Custom resource tags applied: {custom_tag_dict}")
                else:
                    app_logger.error("❌ 'resource_tagging' must be a JSON object")

    except Exception as ex:
        app_logger.error(f"❌ Failed to apply custom resource tags: {ex}")

    return tags_dict


def get_user_agent_header_sql():
    """
    Get the user agent header for the Databricks SQL API requests.

    This function retrieves the user agent string that includes product and version information.
    """
    from lakefusion_utility.utils.lf_utils import get_version_info

    # Set product name and version (Semantic Versioning required)
    version = get_version_info()
    product_name = version.get("productName", "LakeFusion")
    product_version = version.get("productVersion", "1.0.0")

    app_logger.info(f"Setting user agent with product name: {product_name} & product version: {product_version}")

    return f"{product_name}/{product_version}"


class SecretScopeService:
    def __init__(self, token: str, scope_name: str):
        """
        Initializes the SecretScopeService with authentication and scope details.
        :param token: Databricks token. If empty, auto-generates via generate_pat().
        :param scope_name: The name of the secret scope to manage.
        """
        self.token = token or generate_pat()
        self.host = DATABRICKS_HOST
        self.scope_name = scope_name
        self.logger = get_logger(__name__)
        self.headers = {
            "Authorization": f"Bearer {self.token}"
        }

    # Check if scope exists
    def scope_exists(self) -> bool:
        """Checks if the secret scope already exists in Databricks."""

        url = f"{self.host}/api/2.0/secrets/scopes/list"
        resp = requests.get(url, headers=self.headers)

        if resp.status_code != 200:
            self.logger.error(f"Failed to fetch scopes: {resp.text}")
            raise Exception("Unable to fetch scopes")

        scopes = resp.json().get("scopes", [])

        return any(s["name"] == self.scope_name for s in scopes)

    # Create scope if missing
    def create_scope(self):
        """Creates the secret scope in Databricks."""

        url = f"{self.host}/api/2.0/secrets/scopes/create"
        payload = {"scope": self.scope_name}

        self.logger.info(f"Creating secret scope: {self.scope_name}")
        resp = requests.post(url, headers=self.headers, json=payload)

        if resp.status_code not in [200, 201]:
            self.logger.error(f"Failed to create scope: {resp.text}")
            raise Exception("Unable to create secret scope")

    # Put secret key-value
    def put_secret(self, key: str, value: str):
        """Stores or updates a secret key-value pair in the specified scope."""

        url = f"{self.host}/api/2.0/secrets/put"
        payload = {
            "scope": self.scope_name,
            "key": key,
            "string_value": value
        }

        self.logger.info(f"Writing secret '{key}' to scope '{self.scope_name}'")
        resp = requests.post(url, headers=self.headers, json=payload)

        if resp.status_code not in [200, 201]:
            self.logger.error(f"Failed to write secret: {resp.text}")
            raise Exception("Unable to write secret")
    
    def delete_secret(self, key: str):
        """Deletes a secret key from the specified scope."""

        url = f"{self.host}/api/2.0/secrets/delete"
        payload = {
            "scope": self.scope_name,
            "key": key
        }

        self.logger.info(f"Deleting secret '{key}' from scope '{self.scope_name}'")
        resp = requests.post(url, headers=self.headers, json=payload)

        if resp.status_code not in [200, 201]:
            self.logger.error(f"Failed to delete secret: {resp.text}")
            raise Exception("Unable to delete secret")

    # MAIN ENTRY: Upsert secret
    def upsert_secret(self, key: str, value: str):
        """Upserts a secret key-value pair in the specified scope."""
        
        try:
            
            # Ensure scope exists
            if not self.scope_exists():
                self.create_scope()

            # Handle delete case
            if(value == ""):
                self.delete_secret(key)
                return {
                    "status": "success",
                    "message": f"Secret '{key}' deleted successfully from scope '{self.scope_name}'"
                }

            # Write or overwrite secret
            self.put_secret(key, value)
            
            return {
                "status": "success",
                "message": f"Secret '{key}' stored successfully in scope '{self.scope_name}'"
            }

        except Exception as e:
            self.logger.exception("Error storing secret")
            raise e

    def grant_read_acl(self, principal: str = None):
        """Grants READ permission on the scope to the specified principal.
        If no principal specified, reads lakefusion_spn from DB config,
        then falls back to DATABRICKS_CLIENT_ID env var.
        Never grant READ to 'users' — that exposes secrets to all workspace users.
        """
        if principal is None:
            # Try DB config first (lakefusion_spn)
            try:
                from lakefusion_utility.utils.database import SessionLocal
                from lakefusion_utility.utils.db_config_utility import DBConfigPropertiesService
                if SessionLocal is not None:
                    with SessionLocal() as session:
                        db_config_service = DBConfigPropertiesService(db=session)
                        spn_value = db_config_service.getDBConfigProperties('lakefusion_spn')
                        if spn_value:
                            principal = spn_value
            except Exception:
                pass
            # Fallback to env var
            if not principal:
                principal = os.environ.get("DATABRICKS_CLIENT_ID", "")
        if not principal:
            self.logger.warning("Skipping grant_read_acl: no principal resolved (check lakefusion_spn config or DATABRICKS_CLIENT_ID env)")
            return
        if principal == "users":
            self.logger.warning("Skipping grant_read_acl: refusing to grant READ to 'users' group")
            return
        url = f"{self.host}/api/2.0/secrets/acls/put"
        payload = {"scope": self.scope_name, "principal": principal, "permission": "READ"}
        resp = requests.post(url, headers=self.headers, json=payload)
        if resp.status_code not in [200, 201]:
            self.logger.error(f"Failed to set ACL: {resp.text}")
            raise Exception("Unable to set secret scope ACL")

    def copy_secrets(self, source_scope: str, target_scope: str):
        """Copy all secrets from source scope to target scope.

        Creates the target scope if it doesn't exist, then iterates all
        secrets in the source scope and writes them to the target.

        Args:
            source_scope: Name of the scope to copy from.
            target_scope: Name of the scope to copy to.
        """
        import base64

        w = _create_workspace_client(self.token)

        # Create target scope if needed
        try:
            w.secrets.create_scope(scope=target_scope)
            self.logger.info(f"Created secret scope: {target_scope}")
        except Exception:
            self.logger.info(f"Secret scope {target_scope} already exists")

        # Copy each secret
        copied = 0
        for secret in w.secrets.list_secrets(scope=source_scope):
            try:
                resp = w.secrets.get_secret(scope=source_scope, key=secret.key)
                w.secrets.put_secret(
                    scope=target_scope,
                    key=secret.key,
                    string_value=base64.b64decode(resp.value).decode('utf-8')
                )
                self.logger.info(f"Copied secret: {secret.key} from {source_scope} → {target_scope}")
                copied += 1
            except Exception as e:
                self.logger.warning(f"Failed to copy secret {secret.key}: {e}")

        # Grant read ACL on new scope
        try:
            target_service = SecretScopeService(token=self.token, scope_name=target_scope)
            target_service.grant_read_acl()
        except Exception as e:
            self.logger.warning(f"Failed to set ACL on {target_scope}: {e}")

        self.logger.info(f"Copied {copied} secrets from {source_scope} → {target_scope}")


def get_model_optimization_info(token: str, entity_name: str, version: int = 1, max_retries: int = 3) -> dict:
    """
    Call Databricks optimization API to check PT (Provisioned Throughput) eligibility.

    This API endpoint returns information about whether a model supports provisioned throughput
    and what type of PT configuration it requires.

    Args:
        token (str): Databricks API authentication token
        entity_name (str): The model entity name (e.g., "system.ai.gpt-oss-120b")
        version (int): The model version (default: 1)
        max_retries (int): Maximum number of retry attempts for transient failures (default: 3)

    Returns:
        dict: Response containing:
            - optimizable (bool): Whether the model supports PT
            - model_unit_chunk_size (int | None): Chunk size for model_units PT type
            - throughput_chunk_size (int | None): Chunk size for legacy PT type
            - task (str | None): Task type ("llm/v1/chat" or "llm/v1/embeddings")

    Raises:
        requests.HTTPError: If the API call fails after all retries

    Example:
        >>> result = get_model_optimization_info(token, "system.ai.gpt-oss-120b", 1)
        >>> if result["optimizable"]:
        >>>     if result.get("model_unit_chunk_size"):
        >>>         print(f"Model Units PT with chunk size: {result['model_unit_chunk_size']}")
        >>>     elif result.get("throughput_chunk_size"):
        >>>         print(f"Legacy PT with chunk size: {result['throughput_chunk_size']}")
    """
    import time

    token = token or generate_pat()
    url = f"{DATABRICKS_HOST}/api/2.0/serving-endpoints/get-model-optimization-info/{entity_name}/{version}"
    headers = {"Authorization": f"Bearer {token}"}

    app_logger.info(f"Fetching model optimization info for {entity_name} version {version}")

    last_exception = None
    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers, timeout=30)

            # Databricks API sometimes returns 500 for non-optimizable models
            # but still includes valid JSON with {"optimizable": False}
            # So we try to parse JSON even for error status codes
            try:
                result = response.json()
            except ValueError as json_err:
                # If JSON parsing fails, log the response text for debugging
                app_logger.error(
                    f"Failed to parse JSON response for {entity_name}. Status: {response.status_code}, "
                    f"Response text: {response.text[:500]}, Error: {json_err}"
                )
                # If JSON parsing fails AND status is not OK, then it's a real error
                if not response.ok:
                    response.raise_for_status()
                raise

            # If we got valid JSON with optimizable field, return it regardless of status code
            # This handles the case where Databricks returns 500 with {"optimizable": False}
            if "optimizable" in result:
                if response.status_code != 200:
                    app_logger.warning(
                        f"Model optimization API returned {response.status_code} but included valid response for {entity_name}: {result}"
                    )
                # Success - return the result even if status code was not 200
                app_logger.info(f"Model optimization info retrieved for {entity_name}: optimizable={result.get('optimizable')}")
                return result

            # If JSON doesn't contain expected fields AND status is not OK, treat as error
            if not response.ok:
                app_logger.error(
                    f"Unexpected response format for {entity_name}. Status: {response.status_code}, "
                    f"Response: {result}"
                )
                response.raise_for_status()

            # If status was OK but no optimizable field, still return what we got
            app_logger.info(f"Model optimization info retrieved successfully for {entity_name}")
            return result

        except requests.exceptions.HTTPError as e:
            last_exception = e
            # Retry on 500/502/503/504 errors (transient server errors)
            if response.status_code in [500, 502, 503, 504] and attempt < max_retries - 1:
                wait_time = 2 ** attempt  # Exponential backoff: 1s, 2s, 4s
                app_logger.warning(
                    f"Transient error ({response.status_code}) fetching model optimization info for {entity_name}. "
                    f"Retrying in {wait_time}s... (attempt {attempt + 1}/{max_retries})"
                )
                time.sleep(wait_time)
                continue
            app_logger.error(f"HTTP error fetching model optimization info for {entity_name}: {e}")
            raise
        except requests.exceptions.RequestException as e:
            last_exception = e
            # Retry on connection/timeout errors
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                app_logger.warning(
                    f"Request error fetching model optimization info for {entity_name}: {e}. "
                    f"Retrying in {wait_time}s... (attempt {attempt + 1}/{max_retries})"
                )
                time.sleep(wait_time)
                continue
            app_logger.error(f"Request error fetching model optimization info for {entity_name}: {e}")
            raise
        except Exception as e:
            app_logger.error(f"Unexpected error fetching model optimization info for {entity_name}: {e}")
            raise

    # If all retries failed, raise the last exception
    if last_exception:
        raise last_exception


class User_Management:
    """Service for managing Databricks workspace users and groups via SCIM."""

    def __init__(self, token: str) -> None:
        self.token = token
        self.w = WorkspaceClient(host=DATABRICKS_HOST, token=token)

    def list_users(self):
        return list(self.w.users.list(sort_by="userName"))

    def list_groups(self):
        return list(self.w.groups.list())

