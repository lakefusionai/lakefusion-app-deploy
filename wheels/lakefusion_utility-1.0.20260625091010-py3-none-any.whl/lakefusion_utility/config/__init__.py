"""RBAC configuration package — flat-row grant config and loader.

This package is the **source of truth** for RBAC configuration across the
LakeFusion stack. Both backend services (databricks-service, middlelayer,
cron-service) and the pipeline / notebook code (lakefusion_core_engine) read
from here. The pipeline-side ``lakefusion_core_engine.config.rbac_config_loader``
is a thin re-export shim — there is one config, in one place.
"""
