"""
RBAC config loader — re-export shim.

The source of truth lives in ``lakefusion_core_engine.config.rbac_config_loader``
(see that module's docstring for usage and rationale). This module exists only
so that existing backend imports of the form

    from lakefusion_utility.config.rbac_config_loader import load_grants

continue to work. New code should import directly from
``lakefusion_core_engine.config.rbac_config_loader``.

Architectural rule: shared code lives in ``lakefusion_core_engine`` so that
notebooks (which install only the core wheel) do not need ``lakefusion_utility``.
"""

from lakefusion_core_engine.config.rbac_config_loader import (  # noqa: F401
    JOB_SENTINEL,
    MODEL_ENDPOINT_SENTINEL,
    VECTOR_ENDPOINT_SENTINEL,
    GrantRow,
    build_params,
    entity_group_names,
    load_config,
    load_grants,
    resolve_group_name,
)
