from sqlalchemy import Column, Integer, String, DateTime, Boolean
import os
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
from pydantic import BaseModel
from typing import Optional
from sqlalchemy.orm import relationship
from lakefusion_utility.models.entity import EntityDatasetMapping

class Dataset(Base):
    __tablename__ = 'datasets'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    path = Column(String(255), nullable=False)
    description = Column(String(255))
    primary_field = Column(String(255))
    color_code = Column(String(20))
    created_by = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    
    entity_mappings = relationship(
        "EntityDatasetMapping", 
        back_populates="dataset", 
        overlaps="entities,datasets"
    )
    entities = relationship(
        "Entity",
        secondary="entitydatasetmapping",
        back_populates="datasets",
        overlaps="entity_mappings,dataset_mappings,datasets"
    )
    
    # Relationship to QualityTask
    quality_tasks = relationship(
        "QualityTask",
        back_populates="dataset",
        lazy="dynamic"
    )
    
    def __init__(self, name, path, description, primary_field, created_by, created_at=None, is_active=True, color_code=None):
        self.name = name
        self.path = path
        self.description = description
        self.primary_field = primary_field
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.is_active = is_active
        self.color_code = color_code
    
    @property
    def quality_task_enabled(self):
        """
        Property to check if any quality task is enabled for the dataset.
        Returns True if there is at least one related quality task, otherwise False.
        """
        return self.quality_tasks.count() > 0
    
    def __repr__(self):
        return f"<Dataset(id={self.id}, name={self.name}, created_at={self.created_at}, path={self.path}, description={self.description}, primary_field={self.primary_field}, created_by={self.created_by}, is_active={self.is_active}, color_code={self.color_code})>"

# Pydantic model for request and response
class DatasetCreate(BaseModel):
    name: str
    path: str
    description: Optional[str] = None
    primary_field: Optional[str] = None
    color_code: str
    created_by: Optional[str] = ''

class DatasetResponse(BaseModel):
    id: int
    name: str
    created_at: datetime
    path: str
    description: Optional[str]
    primary_field: Optional[str]
    color_code: str
    created_by: str
    is_active: bool
    databricks_host: Optional[str] = os.getenv("DATABRICKS_HOST", "")

    class Config:
        orm_mode = True