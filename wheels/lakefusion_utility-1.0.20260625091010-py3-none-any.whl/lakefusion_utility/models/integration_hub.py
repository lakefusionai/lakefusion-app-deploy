from sqlalchemy import Column, Integer, String, DateTime, Boolean,JSON,ForeignKey,Float,Text
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
from pydantic import BaseModel,ConfigDict, field_validator
from typing import Optional, Any
from sqlalchemy.orm import relationship
from typing import List,Dict
from lakefusion_utility.models.entity import EntityResponse
from lakefusion_utility.models.match_maven import Model_ExperimentResponse
from sqlalchemy import UniqueConstraint
from enum import Enum
from lakefusion_utility.utils.lf_utils import get_version_info
from sqlalchemy import func

class IntegrationType(Enum):
    Traditional_Flow = "Traditional_Flow"
    Golden_Deduplication = "Golden_Deduplication"

class PipelineMode(str, Enum):
    """Enum for pipeline execution modes"""
    SEPARATE = "separate"  # Traditional and Golden Dedup run as separate jobs
    MERGED = "merged"      # Both pipelines run in a single job sequentially

class Integration_Hub(Base):
    __tablename__ = 'integration_hub'

    __table_args__ = (
        UniqueConstraint('modelid', 'entity_id', name='uix_modelid_entityid'),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    task_name = Column(String(255), nullable=False)
    entity_id  = Column(Integer, ForeignKey('entity.id'), nullable=False)
    task_type = Column(String(50), default="mdm", nullable=False)  # 'mdm' | 'pim' | 'ref_sync'
    modelid  = Column(Integer, ForeignKey('model_experiments.id'), nullable=False)  # 0 = PIM_PLACEHOLDER sentinel
    to_emails = Column(JSON, nullable=False)  # [] for PIM tasks
    is_traditional_pipeline = Column(Boolean, default=True, nullable=False)
    is_golden_deduplication_pipeline = Column(Boolean, default=False, nullable=False)
    traditional_quartz_cron_expression = Column(String(45), default="0 0 0 * * ?", nullable=True)
    golden_deduplication_quartz_cron_expression = Column(String(45), default="0 0 0 * * ?", nullable=True)
    timezone_id = Column(String(255), default='UTC', nullable=True)
    created_by = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    job_id_1 = Column(String(255), nullable=True)  # Normal pipeline job (or Merged pipeline job)
    job_id_2 = Column(String(255), nullable=True)  # Golden deduplication job (paused when merged)
    version = Column(String(255), nullable=True)
    pipeline_mode = Column(String(50), default="separate", nullable=True)

    entity = relationship("Entity")
    model_experiment = relationship("Model_Experiment")

    def __init__(self, task_name, entity_id, modelid, to_emails, is_traditional_pipeline,
                 is_golden_deduplication_pipeline, traditional_quartz_cron_expression,
                 golden_deduplication_quartz_cron_expression, timezone_id, created_by,
                 task_type="mdm", pipeline_mode="separate", created_at=None,
                 is_active=True, version=None):
        self.task_name = task_name
        self.entity_id = entity_id
        self.task_type = task_type
        self.modelid = modelid
        self.to_emails = to_emails
        self.is_traditional_pipeline = is_traditional_pipeline
        self.is_golden_deduplication_pipeline = is_golden_deduplication_pipeline
        self.traditional_quartz_cron_expression = traditional_quartz_cron_expression
        self.golden_deduplication_quartz_cron_expression = golden_deduplication_quartz_cron_expression
        self.timezone_id = timezone_id
        self.created_by = created_by
        self.created_at = created_at if created_at else datetime.utcnow()
        self.is_active = is_active
        self.version = get_version_info()["productVersion"]
        self.pipeline_mode = pipeline_mode

    def __repr__(self):
        try:
            return (
                f"<Integration_Hub("
                f"id={self.id}, "
                f"task_name={self.task_name}, "
                f"entity_id={self.entity_id}, "
                f"task_type={self.task_type}, "
                f"modelid={self.modelid}, "
                f"to_emails={self.to_emails}, "
                f"is_traditional_pipeline={self.is_traditional_pipeline}, "
                f"is_golden_deduplication_pipeline={self.is_golden_deduplication_pipeline}, "
                f"traditional_quartz_cron_expression={self.traditional_quartz_cron_expression}, "
                f"golden_deduplication_quartz_cron_expression={self.golden_deduplication_quartz_cron_expression}, "
                f"timezone_id={self.timezone_id}, "
                f"created_at={self.created_at}, "
                f"created_by={self.created_by}, "
                f"is_active={self.is_active}, "
                f"job_id_1={self.job_id_1}, "
                f"job_id_2={self.job_id_2}, "
                f"version={self.version}, "
                f"pipeline_mode={self.pipeline_mode}"
                f")>"
            )
        except Exception:
            return f"<Integration_Hub(detached)>"


class IntegrationHub_Backup(Base):
    __tablename__ = "integration_hub_backup"

    id = Column(Integer, primary_key=True, index=True)
    integration_hub_id = Column(Integer)
    job_id_1 = Column(String(255), nullable=True)
    job_id_2 = Column(String(255), nullable=True)
    version = Column(String(255), nullable=True)
    status_sync = Column(String(30), default="BACKUP_CREATED")   # e.g. BACKUP_CREATED, SYNCED, FAILED
    created_at = Column(DateTime, default=datetime.utcnow)
    pipeline_mode = Column(String(50), nullable=True)  # Track which mode was active

    def __init__(self, integration_hub_id, job_id_1, job_id_2, version, status_sync, 
                 pipeline_mode="separate", created_at=None):
        self.integration_hub_id = integration_hub_id
        self.job_id_1 = job_id_1
        self.job_id_2 = job_id_2
        self.version = version
        self.status_sync = status_sync
        self.pipeline_mode = pipeline_mode


class Integration_HubCreate(BaseModel):
    task_name: str
    entity_id: int
    task_type: Optional[str] = "mdm"  # 'mdm' | 'pim' | 'ref_sync'
    modelid: Optional[str] = None  # "-1" for PIM tasks (PIM_PLACEHOLDER sentinel)
    to_emails: Optional[List[str]] = []
    is_traditional_pipeline: Optional[bool] = True
    is_golden_deduplication_pipeline: Optional[bool] = False
    traditional_quartz_cron_expression: Optional[str] = "0 0 0 * * ?"
    golden_deduplication_quartz_cron_expression: Optional[str] = "0 0 0 * * ?"
    timezone_id: Optional[str] = "UTC"
    created_by: Optional[str] = ''
    version: Optional[str] = get_version_info()["productVersion"]
    # Pipeline mode
    pipeline_mode: Optional[str] = "separate"
    merged_quartz_cron_expression: Optional[str] = None  # For frontend convenience

    class Config:
        orm_mode = True


class Integration_HubUpdate(BaseModel):
    modelid: Optional[str] = None
    to_emails: Optional[List[str]] = None
    traditional_quartz_cron_expression: Optional[str] = None
    golden_deduplication_quartz_cron_expression: Optional[str] = None
    is_traditional_pipeline: Optional[bool] = None
    is_golden_deduplication_pipeline: Optional[bool] = None
    timezone_id: Optional[str] = "UTC"
    updated_by: Optional[str] = ""
    version: Optional[str] = "1.0.0"
    # Pipeline mode
    pipeline_mode: Optional[str] = None
    merged_quartz_cron_expression: Optional[str] = None  # For frontend convenience

    class Config:
        orm_mode = True


class Integration_HubResponse(BaseModel):
    id: int
    task_name: str
    entity_id: int
    task_type: Optional[str] = "mdm"
    modelid: Optional[int] = None
    to_emails: Optional[List[str]] = None
    is_traditional_pipeline: bool
    is_golden_deduplication_pipeline: bool
    traditional_quartz_cron_expression: Optional[str] = "0 0 0 * * ?"
    golden_deduplication_quartz_cron_expression: Optional[str] = "0 0 0 * * ?"
    timezone_id: Optional[str] = "UTC"
    created_at: datetime
    created_by: str
    is_active: bool
    job_id_1: Optional[str]
    job_id_2: Optional[str]
    version: Optional[str]
    entity: Optional[EntityResponse] = None
    model_experiment: Optional[Model_ExperimentResponse] = None
    sync_required: Optional[bool] = False
    # Pipeline mode
    pipeline_mode: Optional[str] = "separate"

    class Config:
        orm_mode = True


# ──────────────────────────────────────────────────────────────────────────────
# Reference Entity Sync Pipeline
# ──────────────────────────────────────────────────────────────────────────────

class IntegrationHubRefEntitySyncPipeline(Base):
    """Stores ongoing sync pipeline configurations for Reference Entities (RDM)."""

    __tablename__ = "integration_hub_ref_entity"

    id = Column(Integer, primary_key=True, autoincrement=True)
    task_name = Column(String(255), nullable=False, unique=True)
    entity_id = Column(Integer, ForeignKey("entity.id", ondelete="RESTRICT"), nullable=False, unique=True)
    # MERGE behaviour — single JSON column with keys: on_match, on_new_record, on_no_match
    merge_config = Column(JSON, nullable=False, default=lambda: {
        "on_match": "source_wins",
        "on_new_record": "auto_insert",
        "on_no_match": "keep_in_rdm",
    })
    sync_quartz_cron_expression = Column(String(100), nullable=False, default="0 0 2 * * ?")
    job_id= Column(String(50),nullable=True)
    created_by = Column(String(255), nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=True, onupdate=datetime.utcnow)
    is_active = Column(Boolean, nullable=False, default=True)

    entity = relationship("Entity")

    def __init__(
        self,
        task_name: str,
        entity_id: int,
        merge_config: dict,
        sync_quartz_cron_expression: str,
        created_by: str,
        job_id: str = None,
    ):
        self.task_name = task_name
        self.entity_id = entity_id
        self.merge_config = merge_config
        self.sync_quartz_cron_expression = sync_quartz_cron_expression
        self.job_id = job_id
        self.created_by = created_by


class RefEntitySyncPipelineCreate(BaseModel):
    task_name: str
    entity_id: int
    merge_config: Dict[str, str] = {
        "on_match": "source_wins",
        "on_new_record": "auto_insert",
        "on_no_match": "keep_in_rdm",
    }
    sync_quartz_cron_expression: str = "0 0 2 * * ?"
    created_by: Optional[str] = ""

    class Config:
        orm_mode = True


class RefEntitySyncPipelineUpdate(BaseModel):
    entity_id: int = None
    merge_config: Optional[Dict[str, str]] = None
    sync_quartz_cron_expression: Optional[str] = None

    class Config:
        orm_mode = True


class RefEntitySyncPipelineResponse(BaseModel):
    id: int
    task_name: str
    entity_id: int
    merge_config: Dict[str, str]
    sync_quartz_cron_expression: str
    job_id: Optional[str] = None
    created_by: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    is_active: bool
    entity: Optional[EntityResponse] = None

    class Config:
        orm_mode = True

# ─────────────────────────────────────────────────────────────────────────────
# Relationship Sync Pipeline (Story 2)
# ─────────────────────────────────────────────────────────────────────────────

class IntegrationHubRelationshipSyncPipeline(Base):
    """Stores ongoing sync pipeline configurations for first-class Relationships.

    A single Integration Hub task drives all configured dataset mappings on the
    referenced relationships through the Story 2 pipeline (Resolve endpoints →
    Cardinality/Survivorship → MERGE into ``{rel}_edges``).
    """

    __tablename__ = "integration_hub_relationship"
    __table_args__ = (
        UniqueConstraint("task_name", name="uix_inthubrel_task_name"),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    task_name = Column(String(255), nullable=False)
    # Driving entity for the task. Every selected relationship must reference
    # this entity as either source or target (validated at create-time).
    entity_id = Column(Integer, ForeignKey("entity.id"), nullable=False)

    # [{ "relationship_id": int, "mapping_ids": [int, ...] }, ...]
    # `mapping_ids` may be empty to mean "all active mappings for this relationship".
    relationship_ids = Column(JSON, nullable=False)

    cron_expression = Column(String(45), nullable=False, default="0 0 2 * * ?")
    timezone_id = Column(String(255), default="UTC", nullable=True)
    to_emails = Column(JSON, nullable=False, default=list)

    job_id = Column(String(255), nullable=True)
    version = Column(String(255), nullable=True)

    created_by = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

    entity = relationship("Entity")

    def __init__(
        self,
        task_name: str,
        entity_id: int,
        relationship_ids,
        cron_expression: str,
        to_emails,
        created_by: str,
        timezone_id: str = "UTC",
        job_id: str = None,
        version: str = None,
    ):
        self.task_name = task_name
        self.entity_id = entity_id
        self.relationship_ids = relationship_ids
        self.cron_expression = cron_expression
        self.timezone_id = timezone_id
        self.to_emails = to_emails
        self.created_by = created_by
        self.job_id = job_id
        self.version = version or get_version_info().get("productVersion")


class RelationshipMappingSelection(BaseModel):
    relationship_id: int
    mapping_ids: List[int] = []


class RelationshipSyncPipelineCreate(BaseModel):
    task_name: str
    entity_id: int
    relationship_ids: List[RelationshipMappingSelection]
    cron_expression: str = ""
    timezone_id: Optional[str] = "UTC"
    to_emails: List[str] = []
    created_by: Optional[str] = ""

    @field_validator("relationship_ids")
    @classmethod
    def _non_empty(cls, v):
        if not v:
            raise ValueError("relationship_ids must contain at least one relationship.")
        return v


class RelationshipSyncPipelineUpdate(BaseModel):
    relationship_ids: Optional[List[RelationshipMappingSelection]] = None
    cron_expression: Optional[str] = None
    timezone_id: Optional[str] = None
    to_emails: Optional[List[str]] = None


class RelationshipSyncPipelineResponse(BaseModel):
    id: int
    task_name: str
    entity_id: int
    relationship_ids: List[Dict[str, Any]] = []
    cron_expression: str
    timezone_id: Optional[str] = "UTC"
    to_emails: List[str] = []
    job_id: Optional[str] = None
    version: Optional[str] = None
    created_by: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    is_active: bool
    entity: Optional[EntityResponse] = None
    # UI helpers — populated by the service layer for the list view.
    relationship_count: int = 0
    mapping_count: int = 0

    class Config:
        orm_mode = True


# ──────────────────────────────────────────────────────────────────────────────
# Product Entity Integration Tasks
# ──────────────────────────────────────────────────────────────────────────────

# IntegrationHubProductEntity removed — PIM tasks unified into Integration_Hub with task_type='pim'
