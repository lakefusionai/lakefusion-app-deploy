import uuid
from datetime import datetime, timezone
from typing import Optional, List, Any

from sqlalchemy import Column, String, Integer, Text, JSON, DateTime, Index
from pydantic import BaseModel

from lakefusion_utility.utils.app_db import Base


def _uuid() -> str:
    return str(uuid.uuid4())


# ===========================================================================
# LAKEBASE -> DELTA REVERSE-SYNC LOG
# ===========================================================================
# Durable record of every reverse-sync attempt (a UI write on a lakebase
# reference entity being replayed back into the Delta source-of-truth).
#
# A row is inserted as PENDING the moment the Postgres write commits, then
# flipped to SUCCESS / FAILED by the background replay thread. This is the
# answer to "which Lakebase changes have NOT made it back to Delta yet?":
#
#     SELECT * FROM lakebase_delta_sync_log WHERE status != 'SUCCESS';
#
# A reconciliation job can later retry FAILED / stuck PENDING rows.
# ===========================================================================

class LakebaseDeltaSyncLog(Base):
    __tablename__ = 'lakebase_delta_sync_log'
    __table_args__ = (
        Index('idx_ldsl_entity', 'entity_id'),
        Index('idx_ldsl_status', 'status'),
        Index('idx_ldsl_created', 'created_at'),
        {'extend_existing': True},
    )

    id = Column(String(36), primary_key=True, default=_uuid)
    entity_id = Column(Integer, nullable=False)
    # CREATE / UPDATE / DELETE / IMPORT — the UI operation being reverse-synced.
    operation = Column(String(20), nullable=False)
    # The ref_lakefusion_id(s) touched by this op.
    ref_lakefusion_ids = Column(JSON, nullable=True)
    record_count = Column(Integer, nullable=True)
    # PENDING (queued) -> SUCCESS (replayed to Delta) | FAILED (replay errored).
    status = Column(String(20), nullable=False, default='PENDING')
    attempts = Column(Integer, nullable=False, default=0)
    last_error = Column(Text, nullable=True)
    created_at = Column(
        DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    def __repr__(self):
        return (
            f"<LakebaseDeltaSyncLog(id={self.id}, entity_id={self.entity_id}, "
            f"op={self.operation}, status={self.status})>"
        )


# ===========================================================================
# PYDANTIC SCHEMA
# ===========================================================================

class LakebaseDeltaSyncLogResponse(BaseModel):
    id: str
    entity_id: int
    operation: str
    ref_lakefusion_ids: Optional[List[Any]] = None
    record_count: Optional[int] = None
    status: str
    attempts: int
    last_error: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
