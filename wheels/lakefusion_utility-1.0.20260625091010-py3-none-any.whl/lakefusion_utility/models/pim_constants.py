"""Shared PIM seed/reference constants — single source of truth.

Imported by BOTH the PIM bridge service (lakefusion-pim-service) and the
pipeline seed notebook (dbx_pipeline_artifacts/.../entity_product/
Seed_PIM_Reference_Data). Pure data with zero app/FastAPI/Spark dependencies so
it imports cleanly in a Databricks notebook (which cannot import the service
module). Do NOT add imports that pull in app config, the web framework, or the
SQLAlchemy engine here — keep it dependency-free.
"""

# Hierarchy tier templates derived from entity_subtype.
TIER_TEMPLATES = {
    "one-tiered": [
        {"code": "PRODUCT", "label": "Product", "level": 0, "is_leaf": True},
    ],
    "two-tiered": [
        {"code": "PRODUCT", "label": "Product", "level": 0, "is_leaf": False},
        {"code": "ITEM", "label": "Item", "level": 1, "is_leaf": True},
    ],
    "three-tiered": [
        {"code": "PRODUCT", "label": "Product", "level": 0, "is_leaf": False},
        {"code": "VARIANT", "label": "Variant", "level": 1, "is_leaf": False},
        {"code": "ITEM", "label": "Item", "level": 2, "is_leaf": True},
    ],
    "four-tiered": [
        {"code": "PRODUCT", "label": "Product", "level": 0, "is_leaf": False},
        {"code": "VARIANT", "label": "Variant", "level": 1, "is_leaf": False},
        {"code": "ITEM", "label": "Item", "level": 2, "is_leaf": False},
        {"code": "PACK", "label": "Pack", "level": 3, "is_leaf": True},
    ],
    "five-tiered": [
        {"code": "LEVEL_0", "label": "Level 0", "level": 0, "is_leaf": False},
        {"code": "LEVEL_1", "label": "Level 1", "level": 1, "is_leaf": False},
        {"code": "LEVEL_2", "label": "Level 2", "level": 2, "is_leaf": False},
        {"code": "LEVEL_3", "label": "Level 3", "level": 3, "is_leaf": False},
        {"code": "ITEM", "label": "Item", "level": 4, "is_leaf": True},
    ],
    "six-tiered": [
        {"code": "LEVEL_0", "label": "Level 0", "level": 0, "is_leaf": False},
        {"code": "LEVEL_1", "label": "Level 1", "level": 1, "is_leaf": False},
        {"code": "LEVEL_2", "label": "Level 2", "level": 2, "is_leaf": False},
        {"code": "LEVEL_3", "label": "Level 3", "level": 3, "is_leaf": False},
        {"code": "LEVEL_4", "label": "Level 4", "level": 4, "is_leaf": False},
        {"code": "ITEM", "label": "Item", "level": 5, "is_leaf": True},
    ],
}

# MySQL attribute type → PIM attribute data_type.
TYPE_MAPPING = {
    "STRING": "TEXT",
    "INT": "NUMBER",
    "BIGINT": "NUMBER",
    "FLOAT": "NUMBER",
    "DOUBLE": "NUMBER",
    "BOOLEAN": "BOOLEAN",
    "DATE": "DATE",
    "TIMESTAMP": "DATE",
    "SELECT": "SELECT",
    "MULTISELECT": "MULTISELECT",
    "REFERENCE_ENTITY": "REFERENCE",
}

# Default languages seeded into pim_language_ref.
DEFAULT_LANGS = [
    {"id": "en", "language_name": "English"},
    {"id": "fr", "language_name": "French"},
    {"id": "de", "language_name": "German"},
    {"id": "es", "language_name": "Spanish"},
    {"id": "it", "language_name": "Italian"},
    {"id": "pt", "language_name": "Portuguese"},
    {"id": "ja", "language_name": "Japanese"},
    {"id": "zh", "language_name": "Chinese"},
]

# Default measurement units seeded into pim_unit_ref.
DEFAULT_UNITS = [
    # Weight
    {"name": "kg", "category": "weight", "description": "Kilogram", "base_unit": "kg", "to_base_factor": 1.0},
    {"name": "g", "category": "weight", "description": "Gram", "base_unit": "kg", "to_base_factor": 0.001},
    {"name": "lbs", "category": "weight", "description": "Pound", "base_unit": "kg", "to_base_factor": 0.453592},
    {"name": "oz", "category": "weight", "description": "Ounce", "base_unit": "kg", "to_base_factor": 0.0283495},
    # Length
    {"name": "m", "category": "length", "description": "Meter", "base_unit": "m", "to_base_factor": 1.0},
    {"name": "cm", "category": "length", "description": "Centimeter", "base_unit": "m", "to_base_factor": 0.01},
    {"name": "mm", "category": "length", "description": "Millimeter", "base_unit": "m", "to_base_factor": 0.001},
    {"name": "in", "category": "length", "description": "Inch", "base_unit": "m", "to_base_factor": 0.0254},
    {"name": "ft", "category": "length", "description": "Foot", "base_unit": "m", "to_base_factor": 0.3048},
    # Volume
    {"name": "L", "category": "volume", "description": "Liter", "base_unit": "L", "to_base_factor": 1.0},
    {"name": "mL", "category": "volume", "description": "Milliliter", "base_unit": "L", "to_base_factor": 0.001},
    {"name": "gal", "category": "volume", "description": "US Gallon", "base_unit": "L", "to_base_factor": 3.78541},
    {"name": "fl oz", "category": "volume", "description": "US Fluid Ounce", "base_unit": "L", "to_base_factor": 0.0295735},
]
