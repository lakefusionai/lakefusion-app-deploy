from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, JSON
from lakefusion_utility.utils.app_db import Base
from datetime import datetime
from sqlalchemy.orm import relationship
from lakefusion_utility.models.dataset import Dataset
from lakefusion_utility.models.entity import Entity
import os

class ProfilingTask(Base):
    __tablename__ = 'profiling_tasks'
    
    # Primary key for the profiling task
    id = Column(Integer, primary_key=True, autoincrement=True)
    
    # Name of the profiling task
    name = Column(String(255), nullable=False)
    
    # Optional description of the profiling task
    description = Column(String(255))
    
    # Timestamp of when the task was created
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # User who created the task
    created_by = Column(String(255), nullable=False)
    
    # Cron expression for scheduling the task
    quartz_cron_expression = Column(String(255), nullable=True)
    
    # Timezone for the scheduled task
    timezone_id = Column(String(255), nullable=True)
    
    # Store monitor details in JSON format
    monitor_info = Column(JSON, nullable=True)
    
    # Foreign keys to either Dataset or Entity, one can be null
    dataset_id = Column(Integer, ForeignKey('datasets.id'), nullable=True)
    entity_id = Column(Integer, ForeignKey('entity.id'), nullable=True)
    
    # Relationships
    dataset = relationship("Dataset")
    entity = relationship("Entity")

    # Field to indicate refresh type
    refresh_type = Column(String(255), nullable=True)  # e.g., 'onSchedule', 'manually'
    refresh_info = Column(JSON, nullable=True)  # To store latest refresh info

    def __init__(self, name, created_by, dataset_id=None, entity_id=None, description=None, 
                 created_at=None, quartz_cron_expression=None, timezone_id=None, refresh_type=None):
        # Ensure either dataset_id or entity_id is provided
        if not dataset_id and not entity_id:
            raise ValueError("Either dataset_id or entity_id must be provided.")
        if dataset_id and entity_id:
            raise ValueError("Only one of dataset_id or entity_id can be provided.")
        
        self.name = name
        self.created_by = created_by
        self.dataset_id = dataset_id
        self.entity_id = entity_id
        self.description = description
        self.created_at = created_at if created_at else datetime.utcnow()
        self.quartz_cron_expression = quartz_cron_expression
        self.timezone_id = timezone_id
        self.refresh_type = refresh_type

    def __repr__(self):
        # Representation of the ProfilingTask instance
        return f"<ProfilingTask(id={self.id}, name={self.name}, created_by={self.created_by}, dataset_id={self.dataset_id}, entity_id={self.entity_id}, refresh_type={self.refresh_type})>"
    
    @property
    def dashboard_url(self):
        """
        Property to construct the dashboard URL if monitor_info contains a dashboard_id.
        The base URL is fetched from the DATABRICKS_HOST environment variable.
        If monitor_info or dashboard_id is not present, returns None.
        """
        try:
            dashboard_id = self.monitor_info.get('dashboard_id')
            if dashboard_id:
                # Shared helper handles the https:// prefix uniformly.
                from lakefusion_utility.utils.databricks_host import get_databricks_host
                base_url = get_databricks_host() or 'https://databricks.com'
                return f"{base_url}/sql/dashboardsv3/{dashboard_id}"
            return None
        except (TypeError, AttributeError):
            # If monitor_info is None or doesn't contain the expected structure
            return None
        
    def as_dict(self):
        """
        Convert the ProfilingTask instance to a dictionary suitable for JSON serialization.
        Converts datetime fields to ISO strings.
        """
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "created_by": self.created_by,
            "quartz_cron_expression": self.quartz_cron_expression,
            "timezone_id": self.timezone_id,
            "monitor_info": self.monitor_info,
            "dataset_id": self.dataset_id,
            "entity_id": self.entity_id,
            "dashboard_url": self.dashboard_url,
            "refresh_type": self.refresh_type,
            "refresh_info": self.refresh_info 
        }