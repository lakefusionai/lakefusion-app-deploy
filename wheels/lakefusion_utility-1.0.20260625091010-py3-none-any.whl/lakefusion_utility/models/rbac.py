from sqlalchemy import (
    Boolean,
    Column,
    Integer,
    String,
    DateTime,
    ForeignKey,
    UniqueConstraint,
    Index,
    Text,
    JSON,
)
from sqlalchemy.orm import relationship
from lakefusion_utility.utils.app_db import Base
from lakefusion_utility.utils.app_db import MYSQL_CHARSET, MYSQL_COLLATION
from datetime import datetime, timezone
from pydantic import BaseModel, Field, ConfigDict, field_validator
from typing import Optional, List, Dict, Any
from enum import Enum
import json

_MYSQL_TABLE_OPTS = {
    "mysql_charset": MYSQL_CHARSET,
    "mysql_collate": MYSQL_COLLATION,
}


class MemberType(str, Enum):
    USER = "user"
    GROUP = "group"


class UCSyncStatus(str, Enum):
    NOT_SYNCED = "not_synced"
    SYNCING = "syncing"
    SYNCED = "synced"
    SYNC_FAILED = "sync_failed"
    REVOKED = "revoked"
    NOT_APPLICABLE = "not_applicable"



class Role(Base):
    __tablename__ = "roles"
    __table_args__ = {"extend_existing": True, **_MYSQL_TABLE_OPTS}

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, unique=True)
    description = Column(String(255), nullable=True)
    permissions_definition = Column(JSON, nullable=True)
    dbx_group_id = Column(String(255), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc), nullable=True)

    def __init__(
        self, name, description=None, permissions_definition=None, created_at=None
    ):
        self.name = name
        self.description = description
        self.permissions_definition = permissions_definition
        self.created_at = created_at if created_at else datetime.now(timezone.utc)

    def __repr__(self):
        return f"<Role(id={self.id}, name={self.name}, description={self.description})>"


# =============================================================================
# Group-Based RBAC Models
# =============================================================================

class RBACGroup(Base):
    """
    RBAC group container for entity-role permission pairs.

    Groups are containers that hold multiple entity-role permission pairs.
    Users are added to groups and inherit ALL permissions in the group.

    Key Feature: One group can have DIFFERENT roles for DIFFERENT entities!
    Example: "Sales Team" can have Developer on some entities AND Data Steward on others.

    Global Groups (is_global=True):
    - Have permissions with entity_id=NULL (meaning ALL entities, existing + future)
    - Best for Admin roles

    Non-Global Groups (is_global=False):
    - Have specific entity-role pairs in group_permissions table
    - New entities require explicit permission addition
    """
    __tablename__ = "rbac_groups"
    __table_args__ = (
        UniqueConstraint("name", name="uq_rbac_groups_name"),
        Index("idx_rbac_groups_name", "name"),
        Index("idx_rbac_groups_is_global", "is_global"),
        {"extend_existing": True, **_MYSQL_TABLE_OPTS},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    description = Column(String(500), nullable=True)
    is_global = Column("is_global", Boolean, nullable=False, default=False, server_default="0")
    managed_by = Column(String(20), nullable=False, default="lakefusion", server_default="lakefusion")
    databricks_group_id = Column(String(255), nullable=True)
    dbx_display_name = Column(String(255), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc), nullable=True)
    created_by = Column(String(255), nullable=True)

    # Relationships
    permissions = relationship("GroupPermission", back_populates="group", cascade="all, delete-orphan")
    members = relationship("GroupMember", back_populates="group", cascade="all, delete-orphan")

    def __init__(
        self,
        name: str,
        description: str = None,
        is_global: bool = False,
        managed_by: str = "lakefusion",
        databricks_group_id: str = None,
        dbx_display_name: str = None,
        created_by: str = None,
    ):
        self.name = name
        self.description = description
        self.is_global = bool(is_global)
        self.managed_by = managed_by or "lakefusion"
        self.databricks_group_id = databricks_group_id
        self.dbx_display_name = dbx_display_name
        self.created_by = created_by
        self.created_at = datetime.now(timezone.utc)

    @property
    def is_global_access(self) -> bool:
        """Returns True if this group has global access to all entities."""
        return bool(self.is_global)

    def __repr__(self):
        return f"<RBACGroup(id={self.id}, name={self.name}, is_global={self.is_global})>"


class GroupPermission(Base):
    """
    Entity-role permission pair for an RBAC group.

    Each row represents one permission: a specific role on a specific entity.
    A group can have multiple permissions, allowing different roles for different entities.

    Global permissions (entity_id=NULL):
    - Means this role applies to ALL entities (existing and future)

    Specific permissions (entity_id=some_id):
    - Means this role applies only to that specific entity
    """
    __tablename__ = "group_permissions"
    __table_args__ = (
        UniqueConstraint("group_id", "entity_id", "role_id", name="uq_group_permissions"),
        Index("idx_group_permissions_group_id", "group_id"),
        Index("idx_group_permissions_entity_id", "entity_id"),
        Index("idx_group_permissions_role_id", "role_id"),
        Index("idx_group_permissions_group_role", "group_id", "role_id"),
        Index("idx_group_permissions_uc_sync_status", "uc_sync_status"),
        {"extend_existing": True, **_MYSQL_TABLE_OPTS},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    group_id = Column(Integer, ForeignKey("rbac_groups.id", ondelete="CASCADE"), nullable=False)
    entity_id = Column(Integer, ForeignKey("entity.id", ondelete="CASCADE"), nullable=True)  # NULL = all entities
    role_id = Column(Integer, ForeignKey("roles.id", ondelete="CASCADE"), nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    created_by = Column(String(255), nullable=True)

    # UC Sync tracking columns
    uc_sync_status = Column(String(30), nullable=False, default=UCSyncStatus.NOT_SYNCED.value, server_default="not_synced")
    uc_sync_error = Column(Text, nullable=True)
    last_sync_at = Column(DateTime(timezone=True), nullable=True)
    retry_count = Column(Integer, nullable=False, default=0, server_default="0")

    # Relationships
    group = relationship("RBACGroup", back_populates="permissions")
    entity = relationship("Entity", foreign_keys=[entity_id])
    role = relationship("Role", foreign_keys=[role_id])
    def __init__(self, group_id: int, role_id: int, entity_id: int = None, created_by: str = None):
        self.group_id = group_id
        self.role_id = role_id
        self.entity_id = entity_id
        self.created_by = created_by
        self.created_at = datetime.now(timezone.utc)
        self.uc_sync_status = UCSyncStatus.NOT_SYNCED.value
        self.retry_count = 0

    @property
    def is_global_permission(self) -> bool:
        """Returns True if this permission applies to all entities."""
        return self.entity_id is None

    def __repr__(self):
        return f"<GroupPermission(id={self.id}, group_id={self.group_id}, entity_id={self.entity_id}, role_id={self.role_id})>"


class GroupMember(Base):
    """
    Tracks membership in RBAC groups.

    Members can be users (member_type='user') or other RBAC groups
    (member_type='group').  For group-type members, ``user_id`` stores the
    child group's ID as a string.

    Users (and users inside nested child groups) inherit the parent
    group's roles for all entities in the group.
    """
    __tablename__ = "group_members"
    __table_args__ = (
        UniqueConstraint("user_id", "group_id", "member_type", name="uq_group_members"),
        Index("idx_group_members_user_id", "user_id"),
        Index("idx_group_members_group_id", "group_id"),
        Index("idx_group_members_member_type", "member_type"),
        {"extend_existing": True, **_MYSQL_TABLE_OPTS},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(255), nullable=False)
    group_id = Column(Integer, ForeignKey("rbac_groups.id", ondelete="CASCADE"), nullable=False)
    member_type = Column(String(10), nullable=False, default=MemberType.USER.value, server_default="user")
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc), nullable=True)
    created_by = Column(String(255), nullable=True)

    # Relationships
    group = relationship("RBACGroup", back_populates="members")

    def __init__(
        self,
        user_id: str,
        group_id: int,
        created_by: str = None,
        member_type: str = MemberType.USER.value,
    ):
        self.user_id = user_id
        self.group_id = group_id
        self.created_by = created_by
        self.member_type = member_type
        self.created_at = datetime.now(timezone.utc)

    def __repr__(self):
        return f"<GroupMember(id={self.id}, user_id={self.user_id}, group_id={self.group_id}, member_type={self.member_type})>"


# =============================================================================
# Pydantic Models
# =============================================================================

class RoleResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    permissions_definition: Optional[Dict[str, Any]] = None

    model_config = ConfigDict(from_attributes=True)

    @field_validator("permissions_definition", mode="before")
    @classmethod
    def _parse_permissions_definition(cls, value):
        if isinstance(value, str):
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return None
        return value


class RoleCreate(BaseModel):
    name: str
    description: Optional[str] = None


# =============================================================================
# Group-Based RBAC Pydantic Models
# =============================================================================

class RBACGroupResponse(BaseModel):
    """Response model for RBAC groups."""
    id: int
    name: str
    description: Optional[str] = None
    is_global: bool = False
    managed_by: str = "lakefusion"
    databricks_group_id: Optional[str] = None
    dbx_display_name: Optional[str] = None
    permission_count: Optional[int] = None
    member_count: Optional[int] = None
    permissions: List["GroupPermissionResponse"] = []
    created_at: datetime
    updated_at: Optional[datetime] = None
    created_by: Optional[str] = None
    source: str = "lakefusion"  # "lakefusion" (DB-managed) or "databricks" (imported)

    model_config = ConfigDict(from_attributes=True)


class RBACGroupCreateRequest(BaseModel):
    """Request to create a new RBAC group."""
    name: str
    description: Optional[str] = None
    is_global: bool = False
    permissions: List["GroupPermissionCreateRequest"] = []


class RBACGroupUpdateRequest(BaseModel):
    """Request to update an RBAC group."""
    name: Optional[str] = None
    description: Optional[str] = None
    permissions_to_add: List["GroupPermissionCreateRequest"] = []
    permission_ids_to_remove: List[int] = []


class GroupPermissionCreateRequest(BaseModel):
    """Request to create a permission (entity-role pair) for a group."""
    entity_id: Optional[int] = None
    role_id: int


class GroupPermissionResponse(BaseModel):
    """Response model for group permissions (entity-role pairs)."""
    id: int
    group_id: int
    entity_id: Optional[int] = None
    entity_name: Optional[str] = None
    role_id: int
    role_name: Optional[str] = None
    is_global_permission: bool = False
    created_at: datetime
    created_by: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)

    @field_validator("is_global_permission", mode="before")
    @classmethod
    def _compute_is_global(cls, value, info):
        if hasattr(info, 'data') and info.data:
            return info.data.get('entity_id') is None
        return value is None or value is True


class GroupMemberResponse(BaseModel):
    """Response model for group membership."""
    id: int
    user_id: str
    group_id: int
    group_name: Optional[str] = None
    is_global_group: bool = False
    permission_count: Optional[int] = None
    member_type: str = "user"
    member_group_name: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    created_by: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class GroupMemberCreateRequest(BaseModel):
    """Request to add a user to a group."""
    user_id: str
    group_id: int


class GroupMemberBulkRequest(BaseModel):
    """Request to add/remove multiple users to/from groups."""
    user_ids: List[str]
    group_ids: List[int]


class EffectiveRoleResponse(BaseModel):
    """
    Effective permissions for a user, derived from group memberships.

    Users can be members of RBACGroups (rbac_groups table).
    Each group has multiple entity-role permission pairs (group_permissions table).
    User inherits ALL permissions from ALL their groups.
    Global permissions (entity_id=NULL) give access to ALL entities.
    """
    user_id: str
    inherited_permissions: List[GroupPermissionResponse] = []
    rbac_groups: List[GroupMemberResponse] = []

    @property
    def all_permissions(self) -> List[GroupPermissionResponse]:
        """Get all inherited permissions (deduped by role_id + entity_id)."""
        seen = set()
        combined = []
        for perm in self.inherited_permissions:
            key = (perm.role_id, perm.entity_id)
            if key not in seen:
                seen.add(key)
                combined.append(perm)
        return combined

    @property
    def role_names(self) -> List[str]:
        """Get unique role names from all permissions."""
        return list(set(p.role_name for p in self.all_permissions if p.role_name))

    def has_permission(self, role_name: str, entity_id: Optional[int] = None) -> bool:
        """Check if user has a specific permission."""
        for perm in self.all_permissions:
            if perm.role_name and perm.role_name.lower() == role_name.lower():
                if (
                    entity_id is None
                    or perm.entity_id == entity_id
                    or perm.entity_id is None  # Global permission covers all entities
                ):
                    return True
        return False

    def has_any_role(self, role_names: List[str]) -> bool:
        """Check if user has any of the specified roles."""
        return any(self.has_permission(name) for name in role_names)

    def is_global_admin(self) -> bool:
        """Check if user has global admin access (Admin role with entity_id=NULL)."""
        for perm in self.all_permissions:
            if perm.entity_id is None and perm.role_name and perm.role_name.lower() == "admin":
                return True
        return False


class GroupDerivedAssignment(BaseModel):
    """Flattened user→role assignment derived from group memberships."""
    user_id: str
    role_id: int
    role_name: str
    entity_id: Optional[int] = None
    entity_name: Optional[str] = None
    group_id: int
    group_name: str
    is_global: bool = False
    uc_sync_status: str = UCSyncStatus.NOT_SYNCED.value

    model_config = ConfigDict(from_attributes=True)


# Update forward references for Pydantic models
RBACGroupResponse.model_rebuild()
RBACGroupCreateRequest.model_rebuild()
RBACGroupUpdateRequest.model_rebuild()
