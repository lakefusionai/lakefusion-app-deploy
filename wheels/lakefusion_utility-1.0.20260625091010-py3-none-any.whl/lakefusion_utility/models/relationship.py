"""
Relationship configuration models (Story 1: configuration foundation).

Defines a Relationship as a first-class object between two Master entities, with
its own attribute schema and per-dataset source mappings. Pipeline/Steward/LakeGraph
layers are handled in Story 2 / Story 3.

Database-agnostic: all SQLAlchemy generic types. No mysql.* imports. Booleans
via True/False (not 1/0). JSON via sa.JSON.
"""

from sqlalchemy import (
    Column,
    Integer,
    BigInteger,
    String,
    Text,
    DateTime,
    Boolean,
    JSON,
    ForeignKey,
    SmallInteger,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship as orm_relationship, validates
from datetime import datetime
from pydantic import BaseModel, field_validator, ConfigDict
from typing import Optional, List, Dict, Any, Literal
import enum
import re

from lakefusion_utility.utils.app_db import Base


# ---------------------------------------------------------------------------
# Enums (mirror values used by validators; not stored as Enum column type so
# behaviour is portable across MySQL/Postgres/Lakebase).
# ---------------------------------------------------------------------------

class Cardinality(str, enum.Enum):
    ONE_TO_ONE = "1:1"
    ONE_TO_MANY = "1:N"
    MANY_TO_ONE = "N:1"
    MANY_TO_MANY = "N:N"


class RelationshipStatus(str, enum.Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    INACTIVE = "inactive"


ALLOWED_DATA_TYPES = {
    "STRING", "BIGINT", "INT", "SMALLINT", "TINYINT",
    "DOUBLE", "FLOAT", "BOOLEAN", "DATE", "TIMESTAMP",
}

# Reserved column names on the future {rel}_edges Delta table (Story 2). Designer
# cannot create an attribute that collides with these.
RESERVED_ATTRIBUTE_NAMES = {
    "src_node_id", "dst_node_id", "src_node_type", "dst_node_type", "edge_type",
    "start_date", "end_date", "status", "contributing_sources", "origin",
    "created_at", "updated_at", "created_by", "updated_by",
}

NAME_PATTERN = re.compile(r"^[a-z][a-z0-9_]{1,62}$")


# ---------------------------------------------------------------------------
# ORM
# ---------------------------------------------------------------------------

class Relationship(Base):
    __tablename__ = "relationship"
    __table_args__ = (
        UniqueConstraint("name", name="uix_relationship_name"),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(64), nullable=False)
    label_forward = Column(String(100), nullable=False)
    label_reverse = Column(String(100), nullable=True)

    source_entity_id = Column(Integer, ForeignKey("entity.id"), nullable=False)
    target_entity_id = Column(Integer, ForeignKey("entity.id"), nullable=False)

    cardinality = Column(String(8), nullable=False)
    is_bidirectional = Column(Boolean, default=False, nullable=False)

    description = Column(Text, nullable=True)
    status = Column(String(20), default=RelationshipStatus.DRAFT.value, nullable=False)

    developer_group_id = Column(String(255), nullable=True)
    steward_group_id = Column(String(255), nullable=True)

    created_by = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

    source_entity = orm_relationship("Entity", foreign_keys=[source_entity_id])
    target_entity = orm_relationship("Entity", foreign_keys=[target_entity_id])
    attributes = orm_relationship(
        "RelationshipAttribute",
        back_populates="relationship_def",
        cascade="all, delete-orphan",
        order_by="RelationshipAttribute.ordinal",
    )
    dataset_mappings = orm_relationship(
        "RelationshipDatasetMapping",
        back_populates="relationship_def",
        cascade="all, delete-orphan",
    )

    @validates("cardinality")
    def _validate_cardinality(self, key, value):
        allowed = [c.value for c in Cardinality]
        if value not in allowed:
            raise ValueError(f"Invalid cardinality '{value}'. Must be one of: {allowed}")
        return value

    @validates("status")
    def _validate_status(self, key, value):
        allowed = [s.value for s in RelationshipStatus]
        if value not in allowed:
            raise ValueError(f"Invalid status '{value}'. Must be one of: {allowed}")
        return value

    @validates("name")
    def _validate_name(self, key, value):
        if not value or not NAME_PATTERN.match(value):
            raise ValueError(
                f"Invalid relationship name '{value}'. Must start with a lowercase "
                "letter and contain only lowercase letters, digits and underscores (3-63 chars)."
            )
        return value

    def __repr__(self) -> str:
        return (
            f"<Relationship(id={self.id}, name={self.name}, "
            f"source_entity_id={self.source_entity_id}, target_entity_id={self.target_entity_id}, "
            f"cardinality={self.cardinality}, is_bidirectional={self.is_bidirectional}, "
            f"status={self.status}, is_active={self.is_active})>"
        )


class RelationshipAttribute(Base):
    __tablename__ = "relationship_attribute"
    __table_args__ = (
        UniqueConstraint("relationship_id", "name", name="uix_relattr_rel_name"),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    relationship_id = Column(
        Integer, ForeignKey("relationship.id", ondelete="CASCADE"), nullable=False
    )
    name = Column(String(64), nullable=False)
    label = Column(String(100), nullable=False)
    data_type = Column(String(20), nullable=False)
    description = Column(Text, nullable=True)
    ordinal = Column(SmallInteger, default=0, nullable=False)

    relationship_def = orm_relationship("Relationship", back_populates="attributes")

    @validates("data_type")
    def _validate_data_type(self, key, value):
        if value not in ALLOWED_DATA_TYPES:
            raise ValueError(
                f"Invalid data_type '{value}'. Must be one of: {sorted(ALLOWED_DATA_TYPES)}"
            )
        return value

    @validates("name")
    def _validate_name(self, key, value):
        if not value or not NAME_PATTERN.match(value):
            raise ValueError(
                f"Invalid attribute name '{value}'. Must start with a lowercase letter "
                "and contain only lowercase letters, digits and underscores (3-63 chars)."
            )
        if value in RESERVED_ATTRIBUTE_NAMES:
            raise ValueError(
                f"Attribute name '{value}' is reserved (clashes with built-in edge column)."
            )
        return value


class RelationshipDatasetMapping(Base):
    __tablename__ = "relationship_dataset_mapping"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, autoincrement=True)
    relationship_id = Column(
        Integer, ForeignKey("relationship.id", ondelete="CASCADE"), nullable=False
    )
    dataset_id = Column(Integer, ForeignKey("datasets.id"), nullable=False)

    source_pk_column = Column(String(255), nullable=False)
    target_pk_column = Column(String(255), nullable=False)
    start_date_column = Column(String(255), nullable=True)
    end_date_column = Column(String(255), nullable=True)
    status_column = Column(String(255), nullable=True)

    source_system_tag = Column(String(50), nullable=False)
    # 1 = highest priority. Used by Story 2 pipeline to break cardinality conflicts.
    priority = Column(SmallInteger, default=100, nullable=False)

    # [{ "attribute_id": int, "column_name": str }]
    attribute_mappings = Column(JSON, nullable=False)

    created_by = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

    relationship_def = orm_relationship("Relationship", back_populates="dataset_mappings")
    # Eager link to the Dataset row so the service layer can read
    # dataset.name / dataset.path without a manual lookup. Read-only access
    # (no back_populates on Dataset side to avoid touching that model).
    dataset = orm_relationship("Dataset", foreign_keys=[dataset_id], lazy="joined")


# ---------------------------------------------------------------------------
# Pydantic schemas (request / response)
# ---------------------------------------------------------------------------

class RelationshipAttributeCreate(BaseModel):
    name: str
    label: str
    data_type: Literal[
        "STRING", "BIGINT", "INT", "SMALLINT", "TINYINT",
        "DOUBLE", "FLOAT", "BOOLEAN", "DATE", "TIMESTAMP",
    ]
    description: Optional[str] = None
    ordinal: Optional[int] = 0

    @field_validator("name")
    @classmethod
    def _name_format(cls, v: str) -> str:
        if not NAME_PATTERN.match(v):
            raise ValueError(
                "Attribute name must start with a lowercase letter and contain only "
                "lowercase letters, digits and underscores (3-63 chars)."
            )
        if v in RESERVED_ATTRIBUTE_NAMES:
            raise ValueError(f"Attribute name '{v}' is reserved.")
        return v

    @field_validator("label")
    @classmethod
    def _label_nonempty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Label is required.")
        if len(v) > 100:
            raise ValueError("Label must be 100 characters or fewer.")
        return v


class RelationshipAttributeResponse(BaseModel):
    id: int
    relationship_id: int
    name: str
    label: str
    data_type: str
    description: Optional[str] = None
    ordinal: int = 0

    model_config = ConfigDict(from_attributes=True)


class RelationshipAttributeMapping(BaseModel):
    """One entry inside `attribute_mappings`."""
    attribute_id: int
    column_name: str


class RelationshipDatasetMappingCreate(BaseModel):
    dataset_id: int
    source_pk_column: str
    target_pk_column: str
    start_date_column: Optional[str] = None
    end_date_column: Optional[str] = None
    status_column: Optional[str] = None
    # source_system_tag + priority are server-managed.
    # tag      ← derived from dataset.name on save
    # priority ← position in the mappings list (server appends new ones at the
    # bottom; designer reorders via the /reorder endpoint). Accepted in the
    # payload for backwards compatibility but ignored by the service.
    source_system_tag: Optional[str] = None
    priority: Optional[int] = None
    attribute_mappings: List[RelationshipAttributeMapping] = []
    created_by: Optional[str] = ""

    @field_validator("target_pk_column")
    @classmethod
    def _src_tgt_pk_differ(cls, v: str, info):
        src = info.data.get("source_pk_column")
        if src is not None and src == v:
            raise ValueError("source_pk_column and target_pk_column must differ.")
        return v


class RelationshipDatasetMappingResponse(BaseModel):
    id: int
    relationship_id: int
    dataset_id: int
    source_pk_column: str
    target_pk_column: str
    start_date_column: Optional[str] = None
    end_date_column: Optional[str] = None
    status_column: Optional[str] = None
    source_system_tag: str
    priority: int = 100
    attribute_mappings: List[Dict[str, Any]] = []
    created_by: str
    created_at: datetime
    updated_at: datetime
    is_active: bool
    dataset_name: Optional[str] = None
    dataset_path: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class RelationshipCreate(BaseModel):
    name: str
    label_forward: str
    label_reverse: Optional[str] = None
    source_entity_id: int
    target_entity_id: int
    cardinality: Literal["1:1", "1:N", "N:1", "N:N"]
    is_bidirectional: bool = False
    description: Optional[str] = None
    developer_group_id: Optional[str] = None
    steward_group_id: Optional[str] = None
    created_by: Optional[str] = ""
    confirm_self_reference: Optional[bool] = False

    @field_validator("name")
    @classmethod
    def _name_format(cls, v: str) -> str:
        if not NAME_PATTERN.match(v):
            raise ValueError(
                "Name must start with a lowercase letter and contain only lowercase "
                "letters, digits and underscores (3-63 chars)."
            )
        return v

    @field_validator("label_forward")
    @classmethod
    def _label_forward_nonempty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("label_forward is required.")
        if len(v) > 100:
            raise ValueError("label_forward must be 100 characters or fewer.")
        return v

    @field_validator("label_reverse")
    @classmethod
    def _label_reverse_len(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and len(v) > 100:
            raise ValueError("label_reverse must be 100 characters or fewer.")
        return v


class RelationshipUpdate(BaseModel):
    """Editable fields after creation. endpoints/cardinality/name are immutable."""
    label_forward: Optional[str] = None
    label_reverse: Optional[str] = None
    is_bidirectional: Optional[bool] = None
    description: Optional[str] = None
    status: Optional[Literal["draft", "active", "inactive"]] = None
    developer_group_id: Optional[str] = None
    steward_group_id: Optional[str] = None


class EligibleEntity(BaseModel):
    id: int
    name: str
    entity_type: str
    path: str
    has_active_integration_hub: bool
    has_master_prod_table: bool
    eligible: bool
    reason: Optional[str] = None
    color_code: Optional[str] = None


class RelationshipResponse(BaseModel):
    id: int
    name: str
    label_forward: str
    label_reverse: Optional[str] = None
    source_entity_id: int
    target_entity_id: int
    source_entity_name: Optional[str] = None
    target_entity_name: Optional[str] = None
    source_entity_color_code: Optional[str] = None
    target_entity_color_code: Optional[str] = None
    cardinality: str
    is_bidirectional: bool
    description: Optional[str] = None
    status: str
    developer_group_id: Optional[str] = None
    steward_group_id: Optional[str] = None
    created_by: str
    created_at: datetime
    updated_at: datetime
    is_active: bool

    attributes: List[RelationshipAttributeResponse] = []
    dataset_mappings: List[RelationshipDatasetMappingResponse] = []

    model_config = ConfigDict(from_attributes=True)


# ─────────────────────────────────────────────────────────────────────────────
# Story 3 — Steward overrides + LakeGraph deployment state
# ─────────────────────────────────────────────────────────────────────────────

class RelationshipStewardOverride(Base):
    """Audit trail + sticky overlay for steward overrides on relationship edges.

    Per-attribute or whole-edge overrides. ``attribute_name='__row__'`` is the
    sentinel for whole-edge actions (``unlink``, ``relink``, ``reactivate``).

    The pipeline reads active overrides at materialize-time and re-applies them
    after the source MERGE, so an override survives across pipeline runs.
    """

    __tablename__ = "relationship_steward_override"
    __table_args__ = (
        UniqueConstraint(
            "relationship_id",
            "src_node_id",
            "dst_node_id",
            "attribute_name",
            name="uix_relovr_full",
        ),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    relationship_id = Column(Integer, ForeignKey("relationship.id"), nullable=False)
    src_node_id = Column(String(255), nullable=False)
    dst_node_id = Column(String(255), nullable=False)
    attribute_name = Column(String(64), nullable=False)
    override_action = Column(String(20), nullable=False)
    override_value = Column(Text, nullable=True)
    reason = Column(Text, nullable=False)
    steward_id = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)


class StewardOverrideCreate(BaseModel):
    src_node_id: str
    dst_node_id: str
    attribute_name: str = "__row__"
    override_action: str  # value|unlink|relink|reactivate
    override_value: Optional[str] = None
    reason: str
    steward_id: Optional[str] = ""

    @field_validator("override_action")
    @classmethod
    def _v_action(cls, v):
        allowed = {"value", "unlink", "relink", "reactivate"}
        if v not in allowed:
            raise ValueError(f"override_action must be one of {sorted(allowed)}")
        return v

    @field_validator("reason")
    @classmethod
    def _v_reason(cls, v):
        if not v or not v.strip():
            raise ValueError("reason is required")
        return v


class StewardOverrideResponse(BaseModel):
    id: int
    relationship_id: int
    src_node_id: str
    dst_node_id: str
    attribute_name: str
    override_action: str
    override_value: Optional[str] = None
    reason: str
    steward_id: str
    created_at: datetime
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class RelationshipInstance(BaseModel):
    """A single materialized edge row read from ``{rel}_edges``."""
    relationship_id: int
    relationship_name: str
    label_forward: str
    label_reverse: Optional[str] = None
    is_bidirectional: bool = False
    cardinality: str
    src_node_id: str
    dst_node_id: str
    src_node_type: str
    dst_node_type: str
    # Entity ids of the endpoints. Surfaced so the steward UI can deep-link to
    # the related record (`/entity-search/profile?entity={id}&profileId={node_id}`)
    # without an extra lookup.
    src_entity_id: Optional[int] = None
    dst_entity_id: Optional[int] = None
    # Display names resolved from the endpoint entity's master_prod label
    # column. Filled by the service when a SQL warehouse is available so the
    # UI can show "CVS Health" instead of just the lakefusion_id hex.
    src_display_name: Optional[str] = None
    dst_display_name: Optional[str] = None
    edge_type: str
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    status: Optional[str] = None
    contributing_sources: List[str] = []
    origin: Optional[str] = None
    attributes: Dict[str, Any] = {}
    is_overridden: bool = False


class LineageRow(BaseModel):
    """One per-source claim for a single edge instance."""
    source_system: str
    src_source_pk: Optional[str] = None
    dst_source_pk: Optional[str] = None
    raw_payload: Optional[str] = None
    ingested_at: Optional[str] = None
    failure_reason: Optional[str] = None
    failure_detail: Optional[str] = None


class LakeGraphDeployment(Base):
    """Tracks LakeGraph deployment state per LakeFusion source-system id."""

    __tablename__ = "lakegraph_deployment"
    __table_args__ = (
        UniqueConstraint("source_system_id", name="uix_lgdep_ssid"),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    source_system_id = Column(String(255), nullable=False)
    # Graph this deployment belongs to. Nullable for backward-compat with the
    # earlier tenant-wide single-graph rows; new rows are always graph-scoped.
    graph_id = Column(Integer, ForeignKey("relationship_graph.id"), nullable=True)
    graph_config_id = Column(BigInteger, nullable=True)
    graph_name = Column(String(255), nullable=True)
    deploy_count = Column(Integer, default=0, nullable=False)
    last_status = Column(String(20), nullable=True)
    deployment_hash = Column(String(64), nullable=True)
    last_deployed_at = Column(DateTime, nullable=True)
    redirect_url = Column(Text, nullable=True)
    run_id = Column(String(255), nullable=True)
    run_url = Column(Text, nullable=True)
    created_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class LakeGraphDeploymentResponse(BaseModel):
    id: int
    source_system_id: str
    graph_id: Optional[int] = None
    graph_config_id: Optional[int] = None
    graph_name: Optional[str] = None
    deploy_count: int
    last_status: Optional[str] = None
    deployment_hash: Optional[str] = None
    last_deployed_at: Optional[datetime] = None
    redirect_url: Optional[str] = None
    run_id: Optional[str] = None
    run_url: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class LakeGraphDeployRequest(BaseModel):
    """LakeFusion-side request; the route builds the LakeGraph payload from
    current config + active sync pipelines."""
    graph_name: Optional[str] = None
    warehouse_id: str
    description: Optional[str] = None


# ---------------------------------------------------------------------------
# Relationship Graph — a named bundle of relationships. Nodes are auto-derived
# from the endpoints of the selected relationships. One LakeGraph graph per row.
# ---------------------------------------------------------------------------

class RelationshipGraph(Base):
    __tablename__ = "relationship_graph"
    __table_args__ = (
        UniqueConstraint("slug", name="uix_relgraph_slug"),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(255), nullable=False)
    slug = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    # Target UC catalog.schema for the deployed graph tables (user-selected).
    output_schema = Column(String(255), nullable=True)
    created_by = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    members = orm_relationship(
        "RelationshipGraphMember",
        cascade="all, delete-orphan",
        back_populates="graph",
        lazy="joined",
    )


class RelationshipGraphMember(Base):
    __tablename__ = "relationship_graph_member"
    __table_args__ = (
        UniqueConstraint("graph_id", "relationship_id", name="uix_relgraphmem_g_r"),
        {"extend_existing": True},
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    graph_id = Column(
        Integer, ForeignKey("relationship_graph.id", ondelete="CASCADE"), nullable=False
    )
    relationship_id = Column(
        Integer, ForeignKey("relationship.id", ondelete="CASCADE"), nullable=False
    )

    graph = orm_relationship("RelationshipGraph", back_populates="members")
    relationship = orm_relationship("Relationship", lazy="joined")


class RelationshipGraphCreate(BaseModel):
    name: str
    description: Optional[str] = None
    output_schema: Optional[str] = None  # catalog.schema for the deployed graph tables
    relationship_ids: List[int] = []
    created_by: Optional[str] = ""

    @field_validator("name")
    @classmethod
    def _name_required(cls, v):
        s = (v or "").strip()
        if not s:
            raise ValueError("Graph name is required.")
        if any(c.isspace() for c in s):
            raise ValueError("Graph name cannot contain spaces.")
        return s

    @field_validator("relationship_ids")
    @classmethod
    def _at_least_one(cls, v):
        if not v:
            raise ValueError("A graph must include at least one relationship.")
        return v


class RelationshipGraphUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    output_schema: Optional[str] = None
    relationship_ids: Optional[List[int]] = None
    is_active: Optional[bool] = None


class GraphRelationshipSummary(BaseModel):
    id: int
    name: str
    label_forward: Optional[str] = None
    cardinality: Optional[str] = None
    source_entity_id: Optional[int] = None
    target_entity_id: Optional[int] = None
    source_entity_name: Optional[str] = None
    target_entity_name: Optional[str] = None


class GraphNodeSummary(BaseModel):
    entity_id: int
    entity_name: str


class RelationshipGraphResponse(BaseModel):
    id: int
    name: str
    slug: str
    description: Optional[str] = None
    output_schema: Optional[str] = None
    is_active: bool
    created_by: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    relationship_ids: List[int] = []
    relationships: List[GraphRelationshipSummary] = []
    nodes: List[GraphNodeSummary] = []
    node_count: int = 0
    edge_count: int = 0
    deployment: Optional[LakeGraphDeploymentResponse] = None

    model_config = ConfigDict(from_attributes=True)
