"""
Audit Log Service

Provides comprehensive audit logging functionality including:
- CRUD operations for audit logs
- Querying and filtering
- Automatic purging of old records
- Statistics and reporting
- FastAPI middleware for automatic request/response logging
- Sensitive data masking
"""

import json
import traceback
import asyncio
import time
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Callable, Set

from sqlalchemy.orm import Session
from sqlalchemy import text, desc, asc, and_, or_
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.sensitive_data_masker import (
    mask_sensitive_data,
    truncate_string,
)
from lakefusion_utility.models.auditlog import AuditLog

logger = get_logger(__name__)

# Default retention period in days
DEFAULT_RETENTION_DAYS = 30

# Default pagination
DEFAULT_PAGE_SIZE = 50
MAX_PAGE_SIZE = 500


class AuditLogService:
    """Service class for audit log operations."""

    def __init__(self, db: Session):
        self.db = db

    def create(
        self,
        username: str,
        api_path: str,
        request_method: str = None,
        request_payload: str = None,
        response_payload: str = None,
        response_status: int = None,
        client_ip: str = None,
        user_agent: str = None,
        execution_time_ms: float = None
    ) -> AuditLog:
        """
        Create a new audit log entry.

        Args:
            username: The authenticated user's username
            api_path: The API path that was called
            request_method: HTTP method (GET, POST, etc.)
            request_payload: The request payload (should be pre-masked)
            response_payload: The response payload (should be pre-masked)
            response_status: HTTP response status code
            client_ip: Client IP address
            user_agent: Client user agent string
            execution_time_ms: Request execution time in milliseconds

        Returns:
            Created AuditLog instance
        """
        audit_log = AuditLog(
            username=username,
            api_path=api_path,
            request_method=request_method,
            request_payload=request_payload,
            response_payload=response_payload,
            response_status=response_status,
            client_ip=client_ip,
            user_agent=user_agent,
            execution_time_ms=execution_time_ms
        )
        self.db.add(audit_log)
        self.db.commit()
        self.db.refresh(audit_log)
        return audit_log

    def get_by_id(self, audit_log_id: int) -> Optional[AuditLog]:
        """
        Get an audit log entry by ID.

        Args:
            audit_log_id: The audit log ID

        Returns:
            AuditLog instance or None if not found
        """
        return self.db.query(AuditLog).filter(AuditLog.id == audit_log_id).first()

    def get_all(
        self,
        page: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE,
        sort_by: str = "created_date",
        sort_order: str = "desc"
    ) -> Dict[str, Any]:
        """
        Get all audit logs with pagination.

        Args:
            page: Page number (1-indexed)
            page_size: Number of records per page
            sort_by: Field to sort by
            sort_order: Sort order ('asc' or 'desc')

        Returns:
            Dictionary with 'data', 'total', 'page', 'page_size', 'total_pages'
        """
        page_size = min(page_size, MAX_PAGE_SIZE)
        offset = (page - 1) * page_size

        query = self.db.query(AuditLog)

        # Apply sorting
        sort_column = getattr(AuditLog, sort_by, AuditLog.created_date)
        if sort_order.lower() == "asc":
            query = query.order_by(asc(sort_column))
        else:
            query = query.order_by(desc(sort_column))

        total = query.count()
        data = query.offset(offset).limit(page_size).all()

        return {
            "data": [log.as_dict() for log in data],
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size
        }

    def get_by_username(
        self,
        username: str,
        page: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE
    ) -> Dict[str, Any]:
        """
        Get audit logs for a specific user.

        Args:
            username: The username to filter by
            page: Page number
            page_size: Number of records per page

        Returns:
            Paginated results dictionary
        """
        page_size = min(page_size, MAX_PAGE_SIZE)
        offset = (page - 1) * page_size

        query = self.db.query(AuditLog).filter(
            AuditLog.username == username
        ).order_by(desc(AuditLog.created_date))

        total = query.count()
        data = query.offset(offset).limit(page_size).all()

        return {
            "data": [log.as_dict() for log in data],
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size
        }

    def get_by_status_range(
        self,
        status_min: int,
        status_max: int,
        page: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE
    ) -> Dict[str, Any]:
        """
        Get audit logs by status code range.

        Args:
            status_min: Minimum status code (inclusive)
            status_max: Maximum status code (inclusive)
            page: Page number
            page_size: Number of records per page

        Returns:
            Paginated results dictionary
        """
        page_size = min(page_size, MAX_PAGE_SIZE)
        offset = (page - 1) * page_size

        query = self.db.query(AuditLog).filter(
            and_(
                AuditLog.response_status >= status_min,
                AuditLog.response_status <= status_max
            )
        ).order_by(desc(AuditLog.created_date))

        total = query.count()
        data = query.offset(offset).limit(page_size).all()

        return {
            "data": [log.as_dict() for log in data],
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size
        }

    def get_errors(self, page: int = 1, page_size: int = DEFAULT_PAGE_SIZE) -> Dict[str, Any]:
        """
        Get audit logs with error status codes (4xx and 5xx).

        Args:
            page: Page number
            page_size: Number of records per page

        Returns:
            Paginated results dictionary
        """
        return self.get_by_status_range(400, 599, page, page_size)

    def get_by_date_range(
        self,
        start_date: datetime,
        end_date: datetime,
        page: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE
    ) -> Dict[str, Any]:
        """
        Get audit logs within a date range.

        Args:
            start_date: Start date (inclusive)
            end_date: End date (inclusive)
            page: Page number
            page_size: Number of records per page

        Returns:
            Paginated results dictionary
        """
        page_size = min(page_size, MAX_PAGE_SIZE)
        offset = (page - 1) * page_size

        query = self.db.query(AuditLog).filter(
            and_(
                AuditLog.created_date >= start_date,
                AuditLog.created_date <= end_date
            )
        ).order_by(desc(AuditLog.created_date))

        total = query.count()
        data = query.offset(offset).limit(page_size).all()

        return {
            "data": [log.as_dict() for log in data],
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size
        }

    def get_by_api_path(
        self,
        api_path: str,
        exact_match: bool = False,
        page: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE
    ) -> Dict[str, Any]:
        """
        Get audit logs by API path.

        Args:
            api_path: The API path to filter by
            exact_match: If True, exact match; if False, contains match
            page: Page number
            page_size: Number of records per page

        Returns:
            Paginated results dictionary
        """
        page_size = min(page_size, MAX_PAGE_SIZE)
        offset = (page - 1) * page_size

        if exact_match:
            query = self.db.query(AuditLog).filter(AuditLog.api_path == api_path)
        else:
            query = self.db.query(AuditLog).filter(AuditLog.api_path.contains(api_path))

        query = query.order_by(desc(AuditLog.created_date))

        total = query.count()
        data = query.offset(offset).limit(page_size).all()

        return {
            "data": [log.as_dict() for log in data],
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size
        }

    def search(
        self,
        username: str = None,
        api_path: str = None,
        request_method: str = None,
        status_min: int = None,
        status_max: int = None,
        start_date: datetime = None,
        end_date: datetime = None,
        client_ip: str = None,
        page: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE,
        sort_by: str = "created_date",
        sort_order: str = "desc"
    ) -> Dict[str, Any]:
        """
        Search audit logs with multiple filters.

        Args:
            username: Filter by username (exact match)
            api_path: Filter by API path (contains match)
            request_method: Filter by HTTP method
            status_min: Minimum status code
            status_max: Maximum status code
            start_date: Start date filter
            end_date: End date filter
            client_ip: Filter by client IP
            page: Page number
            page_size: Number of records per page
            sort_by: Field to sort by
            sort_order: Sort order ('asc' or 'desc')

        Returns:
            Paginated results dictionary
        """
        page_size = min(page_size, MAX_PAGE_SIZE)
        offset = (page - 1) * page_size

        query = self.db.query(AuditLog)

        # Apply filters
        filters = []
        if username:
            filters.append(AuditLog.username == username)
        if api_path:
            filters.append(AuditLog.api_path.contains(api_path))
        if request_method:
            filters.append(AuditLog.request_method == request_method.upper())
        if status_min is not None:
            filters.append(AuditLog.response_status >= status_min)
        if status_max is not None:
            filters.append(AuditLog.response_status <= status_max)
        if start_date:
            filters.append(AuditLog.created_date >= start_date)
        if end_date:
            filters.append(AuditLog.created_date <= end_date)
        if client_ip:
            filters.append(AuditLog.client_ip == client_ip)

        if filters:
            query = query.filter(and_(*filters))

        # Apply sorting
        sort_column = getattr(AuditLog, sort_by, AuditLog.created_date)
        if sort_order.lower() == "asc":
            query = query.order_by(asc(sort_column))
        else:
            query = query.order_by(desc(sort_column))

        total = query.count()
        data = query.offset(offset).limit(page_size).all()

        return {
            "data": [log.as_dict() for log in data],
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size,
            "filters_applied": {
                "username": username,
                "api_path": api_path,
                "request_method": request_method,
                "status_min": status_min,
                "status_max": status_max,
                "start_date": str(start_date) if start_date else None,
                "end_date": str(end_date) if end_date else None,
                "client_ip": client_ip
            }
        }

    def get_stats(self) -> Dict[str, Any]:
        """
        Get statistics about audit logs.

        Returns:
            Dictionary with audit log statistics
        """
        try:
            # Get total count
            total_count = self.db.query(AuditLog).count()

            # Get count by status code ranges
            status_2xx = self.db.query(AuditLog).filter(
                and_(AuditLog.response_status >= 200, AuditLog.response_status < 300)
            ).count()
            status_3xx = self.db.query(AuditLog).filter(
                and_(AuditLog.response_status >= 300, AuditLog.response_status < 400)
            ).count()
            status_4xx = self.db.query(AuditLog).filter(
                and_(AuditLog.response_status >= 400, AuditLog.response_status < 500)
            ).count()
            status_5xx = self.db.query(AuditLog).filter(
                AuditLog.response_status >= 500
            ).count()

            # Get count by HTTP method
            method_counts = {}
            methods = self.db.query(AuditLog.request_method).distinct().all()
            for (method,) in methods:
                if method:
                    method_counts[method] = self.db.query(AuditLog).filter(
                        AuditLog.request_method == method
                    ).count()

            # Get top users
            top_users_query = self.db.execute(text("""
                SELECT username, COUNT(*) as count
                FROM audit_logs
                GROUP BY username
                ORDER BY count DESC
                LIMIT 10
            """))
            top_users = [{"username": row[0], "count": row[1]} for row in top_users_query]

            # Get top endpoints
            top_endpoints_query = self.db.execute(text("""
                SELECT api_path, COUNT(*) as count
                FROM audit_logs
                GROUP BY api_path
                ORDER BY count DESC
                LIMIT 10
            """))
            top_endpoints = [{"api_path": row[0], "count": row[1]} for row in top_endpoints_query]

            # Get average execution time
            avg_time_result = self.db.execute(text(
                "SELECT AVG(execution_time_ms) FROM audit_logs WHERE execution_time_ms IS NOT NULL"
            ))
            avg_execution_time = avg_time_result.scalar()

            # Get oldest and newest record dates
            oldest = self.db.query(AuditLog).order_by(asc(AuditLog.created_date)).first()
            newest = self.db.query(AuditLog).order_by(desc(AuditLog.created_date)).first()

            return {
                "total_records": total_count,
                "status_breakdown": {
                    "2xx": status_2xx,
                    "3xx": status_3xx,
                    "4xx": status_4xx,
                    "5xx": status_5xx
                },
                "method_breakdown": method_counts,
                "top_users": top_users,
                "top_endpoints": top_endpoints,
                "avg_execution_time_ms": round(avg_execution_time, 2) if avg_execution_time else None,
                "oldest_record": str(oldest.created_date) if oldest else None,
                "newest_record": str(newest.created_date) if newest else None,
            }

        except Exception as e:
            logger.error(f"Failed to get audit log stats: {e}")
            return {"error": str(e)}

    def purge_old(self, retention_days: int = DEFAULT_RETENTION_DAYS) -> int:
        """
        Purge audit log records older than the specified retention period.

        Args:
            retention_days: Number of days to retain audit logs (default: 30)

        Returns:
            Number of records deleted
        """
        cutoff_date = datetime.utcnow() - timedelta(days=retention_days)

        logger.info(f"Purging audit logs older than {retention_days} days (before {cutoff_date})")

        # Count records to be deleted
        records_to_delete = self.db.query(AuditLog).filter(
            AuditLog.created_date < cutoff_date
        ).count()

        if records_to_delete == 0:
            logger.info("No audit logs to purge.")
            return 0

        # Delete old records
        self.db.query(AuditLog).filter(
            AuditLog.created_date < cutoff_date
        ).delete(synchronize_session=False)

        self.db.commit()

        logger.info(f"Successfully purged {records_to_delete} audit log records")

        return records_to_delete

    def delete_by_id(self, audit_log_id: int) -> bool:
        """
        Delete a specific audit log entry.

        Args:
            audit_log_id: The audit log ID to delete

        Returns:
            True if deleted, False if not found
        """
        audit_log = self.get_by_id(audit_log_id)
        if audit_log:
            self.db.delete(audit_log)
            self.db.commit()
            return True
        return False

    def export_to_dict(
        self,
        start_date: datetime = None,
        end_date: datetime = None,
        limit: int = 10000
    ) -> List[Dict[str, Any]]:
        """
        Export audit logs to a list of dictionaries.

        Args:
            start_date: Start date filter
            end_date: End date filter
            limit: Maximum number of records to export

        Returns:
            List of audit log dictionaries
        """
        query = self.db.query(AuditLog)

        if start_date:
            query = query.filter(AuditLog.created_date >= start_date)
        if end_date:
            query = query.filter(AuditLog.created_date <= end_date)

        query = query.order_by(desc(AuditLog.created_date)).limit(limit)

        return [log.as_dict() for log in query.all()]


# Standalone functions for backward compatibility and cron job usage

def purge_old_audit_logs(db: Session, retention_days: int = DEFAULT_RETENTION_DAYS) -> int:
    """
    Purge audit log records older than the specified retention period.

    Args:
        db: Database session
        retention_days: Number of days to retain audit logs (default: 30)

    Returns:
        Number of records deleted
    """
    try:
        # Calculate cutoff date
        cutoff_date = datetime.utcnow() - timedelta(days=retention_days)

        logger.info(f"Purging audit logs older than {retention_days} days (before {cutoff_date})")

        # Check if audit_logs table exists
        result = db.execute(text(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'audit_logs'"
        ))
        table_exists = result.scalar() > 0

        if not table_exists:
            logger.warning("audit_logs table does not exist. Skipping purge.")
            return 0

        # Count records to be deleted (for logging)
        count_result = db.execute(text(
            "SELECT COUNT(*) FROM audit_logs WHERE created_date < :cutoff_date"
        ), {"cutoff_date": cutoff_date})
        records_to_delete = count_result.scalar()

        if records_to_delete == 0:
            logger.info("No audit logs to purge.")
            return 0

        # Delete old records
        db.execute(text(
            "DELETE FROM audit_logs WHERE created_date < :cutoff_date"
        ), {"cutoff_date": cutoff_date})

        db.commit()

        logger.info(f"Successfully purged {records_to_delete} audit log records older than {retention_days} days")

        return records_to_delete

    except Exception as e:
        logger.error(f"Failed to purge audit logs: {e}")
        db.rollback()
        raise


def get_audit_log_stats(db: Session) -> dict:
    """
    Get statistics about audit logs.

    Args:
        db: Database session

    Returns:
        Dictionary with audit log statistics
    """
    try:
        # Check if audit_logs table exists
        result = db.execute(text(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = 'audit_logs'"
        ))
        table_exists = result.scalar() > 0

        if not table_exists:
            return {"error": "audit_logs table does not exist"}

        # Get total count
        total_result = db.execute(text("SELECT COUNT(*) FROM audit_logs"))
        total_count = total_result.scalar()

        # Get count by status code ranges
        status_result = db.execute(text("""
            SELECT
                CASE
                    WHEN response_status >= 200 AND response_status < 300 THEN '2xx'
                    WHEN response_status >= 300 AND response_status < 400 THEN '3xx'
                    WHEN response_status >= 400 AND response_status < 500 THEN '4xx'
                    WHEN response_status >= 500 THEN '5xx'
                    ELSE 'unknown'
                END as status_range,
                COUNT(*) as count
            FROM audit_logs
            GROUP BY status_range
        """))
        status_counts = {row[0]: row[1] for row in status_result}

        # Get oldest and newest record dates
        date_result = db.execute(text("""
            SELECT MIN(created_date), MAX(created_date) FROM audit_logs
        """))
        date_row = date_result.fetchone()
        oldest_date = date_row[0] if date_row else None
        newest_date = date_row[1] if date_row else None

        return {
            "total_records": total_count,
            "status_breakdown": status_counts,
            "oldest_record": str(oldest_date) if oldest_date else None,
            "newest_record": str(newest_date) if newest_date else None,
        }

    except Exception as e:
        logger.error(f"Failed to get audit log stats: {e}")
        return {"error": str(e)}


# =============================================================================
# Middleware Configuration
# =============================================================================

# Maximum payload size to log (10KB)
MAX_PAYLOAD_SIZE = 10240

# Maximum response/error size to log (5KB)
MAX_RESPONSE_SIZE = 5120

# Content types that indicate file uploads (skip body logging)
FILE_UPLOAD_CONTENT_TYPES = {
    "multipart/form-data",
    "application/octet-stream",
    "image/",
    "video/",
    "audio/",
}

# Paths to exclude from audit logging
EXCLUDED_PATHS: Set[str] = {
    "/health",
    "/ping",
    "/docs",
    "/redoc",
    "/openapi.json",
    "/favicon.ico",
}

# Path prefixes to exclude
EXCLUDED_PATH_PREFIXES = (
    "/docs",
    "/redoc",
    "/openapi",
)

# API path prefixes where payload should be fully masked (contains sensitive third-party data)
# Add path prefixes here for routes that handle sensitive external API data
SENSITIVE_PAYLOAD_PATH_PREFIXES = (
    "/api/middle-layer/dnb/",  # D&B integration - contains sensitive business data
)


# =============================================================================
# Middleware Helper Functions
# =============================================================================

def _is_excluded_path(path: str) -> bool:
    """Check if path should be excluded from audit logging."""
    if path in EXCLUDED_PATHS:
        return True
    if path.startswith(EXCLUDED_PATH_PREFIXES):
        return True
    if path.endswith("/health") or path.endswith("/ping"):
        return True
    return False


def _is_sensitive_payload_path(path: str) -> bool:
    """
    Check if path requires full payload masking.

    Routes in SENSITIVE_PAYLOAD_PATH_PREFIXES handle sensitive third-party data
    that should be fully masked in audit logs rather than just masking specific fields.
    """
    if not path:
        return False
    return path.startswith(SENSITIVE_PAYLOAD_PATH_PREFIXES)


def _is_file_upload(content_type: str) -> bool:
    """Check if the content type indicates a file upload."""
    if not content_type:
        return False
    content_type_lower = content_type.lower()
    for file_type in FILE_UPLOAD_CONTENT_TYPES:
        if file_type in content_type_lower:
            return True
    return False


async def _get_request_body(request: Request) -> Optional[str]:
    """Safely get the request body. Returns None for file uploads."""
    content_type = request.headers.get("content-type", "")
    if _is_file_upload(content_type):
        return "[FILE_UPLOAD - Body not logged]"
    try:
        body = await request.body()
        if not body:
            return None
        body_str = body.decode("utf-8", errors="replace")
        if len(body_str) > MAX_PAYLOAD_SIZE:
            return body_str[:MAX_PAYLOAD_SIZE] + "...[TRUNCATED]"
        return body_str
    except Exception as e:
        logger.warning(f"Failed to read request body: {e}")
        return None


def _mask_request_body(body: Optional[str], api_path: str = None) -> Optional[str]:
    """
    Mask sensitive data in request body.

    Args:
        body: The request body string
        api_path: The API path (used to check if full masking is required)

    Returns:
        Masked body string
    """
    if not body:
        return body
    if body.startswith("["):
        return body

    # Check if this path requires full payload masking
    if api_path and _is_sensitive_payload_path(api_path):
        return "[SENSITIVE_API_PAYLOAD - Body masked]"

    try:
        data = json.loads(body)
        masked_data = mask_sensitive_data(data)
        result = json.dumps(masked_data)
        if len(result) > MAX_PAYLOAD_SIZE:
            return result[:MAX_PAYLOAD_SIZE] + "...[TRUNCATED]"
        return result
    except json.JSONDecodeError:
        return truncate_string(body, MAX_PAYLOAD_SIZE)


def _format_response_info(
    response: Response,
    response_body: Optional[bytes] = None,
    error: Optional[Exception] = None,
    api_path: str = None
) -> Optional[str]:
    """
    Format response information for logging.

    Args:
        response: The HTTP response object
        response_body: The response body bytes
        error: Any exception that occurred
        api_path: The API path (used to check if full masking is required)

    Returns:
        Formatted response info as JSON string
    """
    info = {}
    if response:
        info["status_code"] = response.status_code
    if error:
        info["error"] = str(error)
        info["error_type"] = type(error).__name__
        tb = traceback.format_exc()
        info["traceback"] = truncate_string(tb, 1000)
    if response_body:
        # Check if this path requires full payload masking
        if api_path and _is_sensitive_payload_path(api_path):
            info["response_body"] = "[SENSITIVE_API_PAYLOAD - Body masked]"
        else:
            try:
                body_str = response_body.decode("utf-8", errors="replace")
                if len(body_str) > MAX_RESPONSE_SIZE:
                    body_str = body_str[:MAX_RESPONSE_SIZE] + "...[TRUNCATED]"
                try:
                    body_data = json.loads(body_str)
                    masked_body = mask_sensitive_data(body_data)
                    info["response_body"] = masked_body
                except json.JSONDecodeError:
                    info["response_body"] = body_str
            except Exception as e:
                info["response_body_error"] = str(e)
    if not info:
        return None
    try:
        result = json.dumps(info)
        return truncate_string(result, MAX_RESPONSE_SIZE)
    except Exception:
        return str(info)[:MAX_RESPONSE_SIZE]


def _get_client_ip(request: Request) -> Optional[str]:
    """Extract client IP from request, handling proxies."""
    forwarded_for = request.headers.get("x-forwarded-for")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    real_ip = request.headers.get("x-real-ip")
    if real_ip:
        return real_ip
    if request.client:
        return request.client.host
    return None


def _create_audit_log_entry(
    username: str,
    api_path: str,
    request_method: str,
    request_payload: Optional[str],
    response_payload: Optional[str],
    response_status: int,
    client_ip: Optional[str],
    user_agent: Optional[str],
    execution_time_ms: float,
    session_factory: Callable = None,
):
    """Background task to create an audit log entry."""
    db = None
    try:
        if session_factory is not None:
            produced = session_factory()
            # `db_session_factory` may be a true session factory (SessionLocal →
            # returns a Session) OR a FastAPI `get_db` dependency (a generator
            # that yields the Session). Resolve all three shapes to a Session;
            # otherwise `db.bind` raises "'async_generator' object has no
            # attribute 'bind'".
            import types as _types
            if isinstance(produced, _types.GeneratorType):
                db = next(produced)
            elif isinstance(produced, _types.AsyncGeneratorType):
                # We're in a worker thread (asyncio.to_thread) with no running
                # loop — drive the async generator's first yield on a private loop.
                import asyncio as _asyncio
                _loop = _asyncio.new_event_loop()
                try:
                    db = _loop.run_until_complete(produced.__anext__())
                finally:
                    _loop.close()
            else:
                db = produced
        else:
            from lakefusion_utility.utils.database import SessionLocal
            if SessionLocal is None:
                logger.warning("Database not initialized. Skipping audit logging.")
                return
            db = SessionLocal()

        from sqlalchemy import inspect
        inspector = inspect(db.bind)
        if not inspector.has_table('audit_logs'):
            logger.warning(
                "audit_logs table does not exist. Run alembic migrations to enable audit logging. "
                f"Skipping audit for: {request_method} {api_path}"
            )
            return

        request_payload = truncate_string(request_payload, MAX_PAYLOAD_SIZE) if request_payload else None
        response_payload = truncate_string(response_payload, MAX_RESPONSE_SIZE) if response_payload else None
        user_agent = truncate_string(user_agent, 512) if user_agent else None

        audit_log = AuditLog(
            username=username or "anonymous",
            api_path=api_path,
            request_method=request_method,
            request_payload=request_payload,
            response_payload=response_payload,
            response_status=response_status,
            client_ip=client_ip,
            user_agent=user_agent,
            execution_time_ms=execution_time_ms
        )
        db.add(audit_log)
        db.commit()
        logger.debug(f"Audit log created for {request_method} {api_path} by {username}")

    except Exception as e:
        logger.error(f"Failed to create audit log entry: {e}")
        if db:
            try:
                db.rollback()
            except Exception:
                pass
    finally:
        if db:
            try:
                db.close()
            except Exception:
                pass


# =============================================================================
# Audit Log Middleware
# =============================================================================

class AuditLogMiddleware(BaseHTTPMiddleware):
    """
    FastAPI middleware that logs all API requests to the audit_logs table.

    Features:
    - Captures request body (masked for sensitive data)
    - Captures response status and body (masked)
    - Captures errors/exceptions with truncated stack traces
    - Uses background tasks for non-blocking logging
    - Skips health checks, docs, and file uploads

    Usage:
        from lakefusion_utility.services.audit_log_service import AuditLogMiddleware

        app.add_middleware(AuditLogMiddleware)
    """

    def __init__(self, app, db_session_factory: Callable = None):
        """
        Initialize the middleware.

        Args:
            app: The FastAPI application
            db_session_factory: Optional SQLAlchemy session factory for audit log writes.
                                When provided, audit logs are written using this session
                                instead of the default primary DB SessionLocal. Useful for
                                services like PIM where the primary DB is LAKEBASE but
                                audit logs should go to MySQL.
        """
        super().__init__(app)
        self._audit_session_factory = db_session_factory

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process the request and log to audit."""
        if _is_excluded_path(request.url.path):
            return await call_next(request)

        start_time = time.time()
        request_body = await _get_request_body(request)
        client_ip = _get_client_ip(request)
        user_agent = request.headers.get("user-agent")
        request_method = request.method
        base_path = request.url.path  # Path without query string (for sensitive path check)
        api_path = base_path
        if request.url.query:
            api_path = f"{api_path}?{request.url.query}"

        response = None
        response_body = None
        error = None
        status_code = 500

        try:
            response = await call_next(request)
            status_code = response.status_code

            if status_code >= 400:
                body_parts = []
                async for chunk in response.body_iterator:
                    body_parts.append(chunk)
                response_body = b"".join(body_parts)
                response = Response(
                    content=response_body,
                    status_code=response.status_code,
                    headers=dict(response.headers),
                    media_type=response.media_type
                )

        except Exception as e:
            error = e
            status_code = 500
            logger.error(f"Error during request processing: {e}")
            raise

        finally:
            execution_time_ms = (time.time() - start_time) * 1000
            username = getattr(request.state, "user", None)
            masked_request_payload = _mask_request_body(request_body, base_path)
            response_info = _format_response_info(response, response_body, error, base_path)

            asyncio.create_task(
                asyncio.to_thread(
                    _create_audit_log_entry,
                    username,
                    api_path,
                    request_method,
                    masked_request_payload,
                    response_info,
                    status_code,
                    client_ip,
                    user_agent,
                    execution_time_ms,
                    self._audit_session_factory,
                )
            )

        return response


# Public alias for backwards compatibility
create_audit_log_entry = _create_audit_log_entry
