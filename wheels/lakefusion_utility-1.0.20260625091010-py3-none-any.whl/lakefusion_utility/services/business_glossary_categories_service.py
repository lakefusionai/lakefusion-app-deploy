import traceback
import ast,re,json
import numpy as np
import pandas as pd
from collections import defaultdict
from sqlalchemy.orm import Session
from lakefusion_utility.utils.databricks_util import DataSetSQLService
from lakefusion_utility.models.business_glossary_categories import BusinessGlossaryCategories
from fastapi import HTTPException
from lakefusion_utility.utils.app_db import db_commit_auto_rollback  # Import the db_commit_auto_rollback function
from lakefusion_utility.utils.logging_utils import get_logger

# Set up logging
app_logger = get_logger(__name__)

class BusinessGlossaryCategoriesService:
    def __init__(self, db: Session):
        """Initializes the BusinessGlossaryCategoriesService with a database session.
        
        Args:
            db: SQLAlchemy session object.
        """
        self.db = db

    def create_business_glossary_categories(self, business_glossary_categories_create):
        """Creates a new business glossary categories and saves it to the database.
        
        Args:
            business_Glossary_create: Pydantic model containing business glossary categories details.
            
        Returns:
            The created business glossary categories object.
        
        Raises:
            HTTPException: If there's an error during creation.
        """
        def parse_glossary_string(glossary_str):
            pattern = re.search(r"id=(\d+), name=([^,]+), .*?table_name=(\[.*?\])", glossary_str)
            id_value = int(pattern.group(1))
            name_value = pattern.group(2)
            table_name_list = ast.literal_eval(pattern.group(3))  # Convert string list to actual list
            return {
                "id": id_value,
                "name": name_value,
                "table_count": len(table_name_list)
            }
          
        try:
            # Create a new business glossary categories instance
            db_business_glossary = BusinessGlossaryCategories(**business_glossary_categories_create.dict())
            self.db.add(db_business_glossary)  # Add the business glossary categories to the session
            db_commit_auto_rollback(db=self.db)  # Commit changes and handle rollback on failure
            self.db.refresh(db_business_glossary)  # Refresh the instance to get the new data
            data = str(db_business_glossary)
            return parse_glossary_string(data)  # Return the created business glossary categories
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create business glossary categories. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to create business glossary categories: {str(e)}") 

    def read_business_glossary_categories(self):
        """Retrieves business glossary categories from the database .
            
        Returns:
            A list of business glossary categories .
        """
        try:
            dataset_q = self.db.query(BusinessGlossaryCategories)
            datasets = dataset_q.all()
            result = []
            for dataset in datasets:
                table_names = ast.literal_eval(dataset.table_name)  # Convert string to list
                result.append({
                    "id": dataset.id,
                    "name": dataset.name,
                    "table_count": len(table_names)
                })
            
            return result
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch business glossary categories. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch business glossary categories: {str(e)}") 

    def delete_business_glossary_categories(self, business_glossary_categories_id: str):
        """Deletes a business glossary categories by id permanently.
        
        Args:
            business glossary: The id of the business glossary categories to delete.
            
        Returns:
            A confirmation message or the deleted business glossary categories object.
            
        Raises:
            HTTPException: If the business glossary categories is not found or an error occurs during deletion.
        """
        try:
            # Fetch the business glossary categories by id
            db_business_glossary = self.db.query(BusinessGlossaryCategories).filter(BusinessGlossaryCategories.id == business_glossary_categories_id).first()
            if db_business_glossary is None:
                return {"detail": "business glossary categories not found"}
            
            self.db.delete(db_business_glossary)  # Permanently delete the business glossary categories
            db_commit_auto_rollback(db=self.db)  # Commit changes and handle rollback on failure
            return {"detail": "business glossary categories successfully deleted"}
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete business glossary categories. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to delete business glossary categories: {str(e)}") 

    def get_tables_by_business_glossary_categories(self, business_glossary_categories_id: str):
        """Retrieves a business glossary categories object by its id.
        
        Args:
            business glossary: The id of the business glossary categories to retrieve.
            
        Returns:
            The business glossary categories object.
        
        Raises:
            HTTPException: If the business glossary categories is not found.
        """
        try:
            # Fetch the tables details by categories id
            db_business_glossary = self.db.query(BusinessGlossaryCategories).filter(BusinessGlossaryCategories.id == business_glossary_categories_id).first()

            if db_business_glossary is None:
                return None
            table_names = ast.literal_eval(db_business_glossary.table_name)
            result = {
                    "id": db_business_glossary.id,
                    "name": db_business_glossary.name,
                    "description" : db_business_glossary.description,
                    "table_names": table_names,
                    "created_by": db_business_glossary.created_by,
                    "created_at": db_business_glossary.created_at,
                }
            return result  # Return the found tables
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch tables by business glossary categories. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch tables by business glossary categories: {str(e)}") 
        
    def get_all_tags_info(self,token, warehouse_id):
        try:
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            query="""select
                    catalog_name,schema_name,table_name,null as volume_name,column_name,collect_list(named_struct('tag_name', tag_name)) as tags
                    from system.information_schema.column_tags
                    group by catalog_name, schema_name, table_name, column_name
                    union all
                    select catalog_name, null as schema_name, null as table_name, null as volume_name, null as column_name, collect_list(named_struct('tag_name', tag_name)) as tags
                    from system.information_schema.catalog_tags
                    group by catalog_name
                    union all
                    select catalog_name, schema_name, null as table_name, null as volume_name, null as column_name, collect_list(named_struct('tag_name', tag_name)) as tags
                    from system.information_schema.schema_tags
                    group by catalog_name, schema_name
                    union all
                    select catalog_name, schema_name, table_name, null as volume_name, null as column_name, collect_list(named_struct('tag_name', tag_name)) as tags
                    from system.information_schema.table_tags
                    group by catalog_name, schema_name, table_name
                    union all
                    select catalog_name, schema_name, null as table_name, volume_name, null as column_name, collect_list(named_struct('tag_name', tag_name)) as tags
                    from system.information_schema.volume_tags
                    group by catalog_name, schema_name, volume_name;"""
            data=sqlservice_conn.execute_dataset(query=query)
            def convert_to_regular_lists(data):
                for entry in data:
                    if isinstance(entry['tags'], np.ndarray):
                        entry['tags'] = entry['tags'].tolist()  # Convert numpy array to list
                return data

            # Convert numpy arrays in the data to Python lists
            data = convert_to_regular_lists(data)
            return data
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch all tags information. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch all tags information: {str(e)}")
    
    def get_tags_info_by_table_name(self,token, warehouse_id,category_details):
        try:
            sqlservice_conn = DataSetSQLService(token, warehouse_id)
            table_names_tuple = tuple(category_details['table_names'])
            table_name = str(table_names_tuple)
            query=f"""SELECT
                    table_name,
                    collect_list(
                        named_struct(
                        'column_name',
                        column_name,
                        'comment',
                        comment,
                        'key',
                        column_tags.tag_name,
                        'value',
                        column_tags.tag_value
                        )
                    ) AS table_tags
                    FROM
                    (
                        select
                        coalesce(comments.table_name,tags.table_name) as table_name,
                        comments.column_name,
                        tags.column_tags,
                        comments.comment
                        from
                        (
                            SELECT
                            concat(catalog_name, ".", schema_name, ".", table_name) as table_name,
                            NULL AS column_name,
                            named_struct('tag_name', tag_name, 'tag_value', tag_value) AS column_tags
                            FROM
                            system.information_schema.table_tags
                            WHERE
                            concat(catalog_name, '.', schema_name, '.', table_name) in {table_name}
                            UNION ALL
                            SELECT
                            concat(catalog_name, ".", schema_name, ".", table_name) as table_name,
                            column_name,
                            named_struct('tag_name', tag_name, 'tag_value', tag_value) AS column_tags
                            FROM
                            system.information_schema.column_tags
                            WHERE
                            concat(catalog_name, '.', schema_name, '.', table_name) in {table_name}
                        ) as tags
                        full join (
                            SELECT
                            concat(table_catalog, ".", table_schema, ".", table_name) as table_name,
                            column_name,
                            comment
                            FROM
                            system.information_schema.columns
                            where
                            concat(table_catalog, ".", table_schema, ".", table_name) in {table_name}
                        ) as comments on tags.table_name = comments.table_name
                        and tags.column_name = comments.column_name
                    ) AS subquery
                    GROUP BY
                    table_name;"""
            data=sqlservice_conn.execute_dataset(query=query)
            
            # Extract table name and tags
            def transform_data(input_data):
                result = []
                
                for table in input_data:
                    table_name = f"{table['table_name']}"
                    table_tags = []
                    columns_dict = defaultdict(lambda: {"tags": []})
                    
                    for tag in table['table_tags']:
                        column_name = tag.get('column_name')
                        key = tag['key']
                        value = tag['value']
                        comment = tag.get('comment')
                        
                        if column_name:
                            columns_dict[column_name]['column_name'] = column_name
                            if comment:
                                columns_dict[column_name]['comment'] = comment
                            if key is not None and value is not None:
                                columns_dict[column_name]['tags'].append({"key": key, "value": value})
                        else:
                            table_tags.append({"key": key, "value": value})

                    for column in columns_dict.values():
                        if column["tags"] == [{"key": None, "value": None}]:
                            column["tags"] = []
                    
                    result.append({
                        "table_name": table_name,
                        "table_tags": table_tags,
                        "columns": list(columns_dict.values())
                    })
                final_result = {"id":category_details['id'],
                                "name":category_details['name'],
                                "description":category_details['description'],
                                "created_by":category_details['created_by'],
                                "created_at":category_details['created_at'],
                                "tables":result}
                return final_result
            return transform_data(data)
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch tags information by table name. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch tags information by table name: {str(e)}")