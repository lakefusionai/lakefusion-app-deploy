"""Save-time validation for dataset mapping payloads with complex-type
targets.

This module enforces only what we *can* know at mapping save time without
sampling the dataset:

- Block invalid combinations the target shape already rules out:
    * STRUCT/ARRAY targets cannot be mapped to a scalar `dataset_attribute`
      using the legacy code path (caller must pick mode + payload).
    * mode="subfield_assembly" requires sub_field_map covering all target
      struct fields (missing fields are allowed -> nulled at runtime, but
      reject unknown sub-field names).
    * mode="direct_column" must carry a dataset_attribute.
- Reject mode being set when the target is plain scalar / ARRAY<scalar>.

Struct schema-match validation (source struct vs target definition) is a
*runtime* check executed in the pipeline (see
`dbx_pipeline_artifacts/src/utils/complex_type_mapping.py`). It cannot run
here because the source schema is not introspected at mapping save time.
"""
from typing import Any, Iterable, List, Mapping

from fastapi import HTTPException, status

from lakefusion_utility.models.entity import EntityAttributes
from lakefusion_utility.models.struct_definition import StructDefinition


def _err(message: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail={"status": "error", "message": message, "data": None},
    )


def _is_complex_target(attr: EntityAttributes) -> bool:
    return bool(attr.is_array) or (attr.type or "").strip().upper() == "STRUCT"


def _struct_field_names(sd: StructDefinition) -> List[str]:
    return [f.name for f in (sd.fields or [])]


def validate_mapping_attributes(
    entity_attributes: Iterable[EntityAttributes],
    mapping_records: Iterable[Mapping[str, Any]],
) -> None:
    """Validate the `attributes` list of a dataset mapping payload.

    Args:
        entity_attributes: ORM EntityAttributes rows for the entity being
            mapped. Provides the target type / is_array / struct_definition
            for each entity_attribute name in the payload.
        mapping_records: payload list — each item carries entity_attribute,
            dataset_attribute, mode, sub_field_map, etc. Accepts either
            Pydantic dicts or model_dump output.

    Raises HTTPException(400) on the first violation.
    """
    attr_by_name = {a.name: a for a in entity_attributes if a.is_active}

    for rec in mapping_records:
        if not isinstance(rec, Mapping):
            rec = rec.dict() if hasattr(rec, "dict") else rec.__dict__

        entity_attr_name = rec.get("entity_attribute")
        if not entity_attr_name:
            # leave other validators (e.g. EntityDatasetMappingCreate) to
            # catch missing entity_attribute — not our concern.
            continue

        target = attr_by_name.get(entity_attr_name)
        if target is None:
            # Unknown attribute names are caught by other layers; skip here.
            continue

        target_is_struct = (target.type or "").strip().upper() == "STRUCT"
        target_is_array = bool(target.is_array)
        target_is_complex = _is_complex_target(target)

        mode = rec.get("mode")
        sub_field_map = rec.get("sub_field_map") or {}
        dataset_attribute = rec.get("dataset_attribute")

        # Mode is only meaningful for STRUCT / ARRAY<STRUCT> targets. Reject
        # mode on scalar AND ARRAY<scalar> targets — those always use the
        # plain column picker (scalar -> array auto-wrap is automatic).
        if mode and not target_is_struct:
            raise _err(
                f"Mapping mode '{mode}' is only valid for STRUCT or ARRAY<STRUCT> "
                f"target attributes. '{entity_attr_name}' is "
                f"{('ARRAY<' if target_is_array else '') + (target.type or 'UNKNOWN')}"
                f"{'>' if target_is_array else ''}."
            )

        # Sub-field map only meaningful with subfield_assembly.
        if sub_field_map and mode != "subfield_assembly":
            raise _err(
                f"sub_field_map is only valid with mode='subfield_assembly'. "
                f"Got mode='{mode}' for '{entity_attr_name}'."
            )

        # Struct / ARRAY<STRUCT> targets require an explicit mode.
        if target_is_struct:
            if not mode:
                raise _err(
                    f"Mapping mode is required for STRUCT target "
                    f"'{entity_attr_name}'. Choose 'direct_column' or 'subfield_assembly'."
                )
            sd: StructDefinition = target.struct_definition
            if sd is None:
                raise _err(
                    f"Target attribute '{entity_attr_name}' is STRUCT but has no "
                    f"struct_definition. This should have been caught earlier — "
                    f"please re-save the attribute."
                )
            target_field_names = _struct_field_names(sd)

            if mode == "direct_column":
                if not dataset_attribute:
                    raise _err(
                        f"Mapping for '{entity_attr_name}' uses mode='direct_column' "
                        f"but no source dataset_attribute is specified."
                    )
            elif mode == "subfield_assembly":
                if not sub_field_map:
                    raise _err(
                        f"Mapping for '{entity_attr_name}' uses mode='subfield_assembly' "
                        f"but no sub_field_map is provided."
                    )
                # Unknown sub-field names = caller bug; reject early so we
                # don't silently drop columns at pipeline runtime.
                unknown = [k for k in sub_field_map.keys() if k not in target_field_names]
                if unknown:
                    raise _err(
                        f"Mapping for '{entity_attr_name}': sub_field_map references "
                        f"fields not in struct definition '{sd.name}': {unknown}. "
                        f"Allowed: {target_field_names}."
                    )
                # Empty source column strings are also invalid.
                blank = [k for k, v in sub_field_map.items() if not (v or "").strip()]
                if blank:
                    raise _err(
                        f"Mapping for '{entity_attr_name}': sub_field_map values "
                        f"cannot be blank for fields {blank}."
                    )

        # ARRAY<scalar> target — scalar-to-array auto-wrap is allowed; just
        # ensure dataset_attribute is set when no mode override is provided.
        elif target_is_array and not mode:
            # No additional save-time check — scalar promotion is handled at
            # pipeline runtime regardless of source type. We only require a
            # dataset_attribute to be present (matched by the existing
            # EntityDatasetMappingCreate validator).
            pass
