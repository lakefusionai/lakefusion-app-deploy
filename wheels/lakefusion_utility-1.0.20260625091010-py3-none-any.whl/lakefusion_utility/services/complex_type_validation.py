"""Backend validation for complex (STRUCT / ARRAY) entity attributes.

Centralized so create, update, and PK-toggle flows share one rule set.

Rules enforced
--------------
1. ENABLE_COMPLEX_DATA_TYPES feature flag must be ACTIVE before any
   STRUCT or is_array=True attribute can be created or updated.
2. type=STRUCT requires struct_definition_id pointing to an ACTIVE
   struct definition.
3. is_array=True is valid for any scalar type and for STRUCT
   (giving ARRAY<STRUCT>). Combination with STRUCT still requires
   struct_definition_id.
4. struct_definition_id must be NULL when type != STRUCT (no orphaned
   references for scalar/array-of-scalar attributes).
5. Primary keys cannot be STRUCT or ARRAY types — reject explicit
   is_primary_key=True on a complex attribute. (Auto-PK assignment in
   the service must also honour this — see helper below.)
6. `type` must be either a known scalar or STRUCT. Unknown type strings
   are rejected at validation time, not at runtime.

Boundaries
----------
- This module performs DATA validation only. Existence of the parent
  entity, name uniqueness within entity, and similar service-level
  checks remain in EntityAttributeService.
- REFERENCE_ENTITY is handled by existing service code; this module
  treats it as a known scalar (not a complex type) and lets that flow
  run unchanged.
"""
from typing import Any, Mapping, Optional

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from lakefusion_utility.models.struct_definition import StructDefinition
from lakefusion_utility.services.feature_flags_service import FeatureFlagService

COMPLEX_TYPES_FLAG = "ENABLE_COMPLEX_DATA_TYPES"

# Scalar set kept aligned with struct_definition_service.SCALAR_FIELD_TYPES
# plus the pseudo-scalar types (REFERENCE_ENTITY, SELECT, MULTISELECT) that
# carry their config in type_config rather than being plain scalars. These are
# intentionally NOT part of SCALAR_FIELD_TYPES (they are not allowed inside a
# struct field) but are valid top-level attribute types.
# SMALLINT / TINYINT are likewise valid top-level attribute types (offered by
# the UI) but not struct field types, so they are not in SCALAR_FIELD_TYPES.
KNOWN_SCALAR_TYPES = {
    "STRING",
    "INT",
    "SMALLINT",
    "TINYINT",
    "BIGINT",
    "DOUBLE",
    "FLOAT",
    "DECIMAL",
    "BOOLEAN",
    "DATE",
    "TIMESTAMP",
    "REFERENCE_ENTITY",
    "SELECT",
    "MULTISELECT",
}
STRUCT_TYPE = "STRUCT"

# Types that carry their config in type_config rather than being plain scalars.
# They are valid attribute types but cannot serve as a product identifier or
# display name (controlled vocabularies / references aren't stable text keys).
PSEUDO_SCALAR_TYPES = {"REFERENCE_ENTITY", "SELECT", "MULTISELECT"}


def _err(message: str, code: int = status.HTTP_400_BAD_REQUEST) -> HTTPException:
    return HTTPException(
        status_code=code,
        detail={"status": "error", "message": message, "data": None},
    )


def _normalize_type(raw: Any) -> str:
    if raw is None:
        return ""
    return str(raw).strip().upper()


def _is_complex(attr_type: str, is_array: bool) -> bool:
    return is_array or attr_type == STRUCT_TYPE


def validate_complex_type_payload(
    db: Session,
    payload: Mapping[str, Any],
    existing_type: Optional[str] = None,
    existing_is_array: Optional[bool] = None,
    existing_struct_definition_id: Optional[int] = None,
) -> None:
    """Validate a create/update payload for complex-type rules.

    Args:
        db: active DB session (needed for flag + struct lookup)
        payload: dict of incoming fields (post-Pydantic). For updates,
            only the fields actually being changed should be present so
            the function falls back to existing_* defaults.
        existing_*: current persisted values, used only for update flow
            so that omitted fields are evaluated against current state.

    Raises HTTPException(400) on any violation. Returns None on success.
    """
    # Resolve effective values (use payload value if present, else fall back
    # to existing values — relevant for partial updates).
    effective_type = _normalize_type(payload["type"]) if "type" in payload else _normalize_type(existing_type)
    effective_is_array = (
        bool(payload["is_array"]) if "is_array" in payload else bool(existing_is_array)
    )
    if "struct_definition_id" in payload:
        effective_struct_id = payload["struct_definition_id"]
    else:
        effective_struct_id = existing_struct_definition_id

    is_pk = bool(payload.get("is_primary_key", False))
    is_complex = _is_complex(effective_type, effective_is_array)

    # --- Type vocabulary check ---------------------------------------
    if effective_type and effective_type not in KNOWN_SCALAR_TYPES and effective_type != STRUCT_TYPE:
        raise _err(
            f"Unknown attribute type '{effective_type}'. "
            f"Allowed: {sorted(KNOWN_SCALAR_TYPES)} or STRUCT (with optional is_array)."
        )

    # --- Feature flag gate (only when payload introduces complex shape) -
    #
    # We gate on the *effective* shape so that an update that leaves a
    # complex attribute complex (e.g. just toggling is_active) is allowed
    # even after the flag is flipped off, but creating new complex
    # attributes or converting scalar→complex is blocked.
    is_new_complex_intent = (
        payload.get("type") == STRUCT_TYPE
        or payload.get("is_array") is True
    )
    if is_new_complex_intent and not FeatureFlagService._is_feature_flag_enabled(
        db, COMPLEX_TYPES_FLAG
    ):
        raise _err(
            "Complex data types are not enabled. "
            f"Enable the '{COMPLEX_TYPES_FLAG}' feature flag to use STRUCT or ARRAY attributes."
        )

    # --- Primary key rule --------------------------------------------
    if is_pk and is_complex:
        raise _err("Primary keys cannot be STRUCT or ARRAY types")

    # --- struct_definition_id consistency ----------------------------
    if effective_type == STRUCT_TYPE:
        if not effective_struct_id:
            raise _err(
                "struct_definition_id is required when type is STRUCT "
                "(including ARRAY<STRUCT>)"
            )
        sd = (
            db.query(StructDefinition)
            .filter(
                StructDefinition.id == effective_struct_id,
                StructDefinition.is_active == True,  # noqa: E712
            )
            .first()
        )
        if not sd:
            raise _err(
                f"struct_definition_id={effective_struct_id} does not reference an active struct definition"
            )
    else:
        # Non-STRUCT attribute must not carry a struct_definition_id —
        # would leave an orphaned reference that later confuses the
        # pipeline schema builder.
        if effective_struct_id is not None:
            raise _err(
                "struct_definition_id can only be set when type=STRUCT"
            )


def is_complex_attribute(attr_type: Any, is_array: Any) -> bool:
    """Helper for the existing service to skip auto-PK assignment on
    complex attributes. Public so other services (schema evolution,
    auto-PK toggle endpoints) can reuse it."""
    return _is_complex(_normalize_type(attr_type), bool(is_array))


def can_be_identifier_or_label(attr_type: Any, is_array: Any) -> bool:
    """True only for plain scalar attributes. Complex (STRUCT/ARRAY) and
    pseudo-scalar (REFERENCE_ENTITY/SELECT/MULTISELECT) types cannot be the
    product identifier or display name. Used by create auto-assignment and by
    the PK/label toggle endpoints so the rule is enforced in one place."""
    normalized = _normalize_type(attr_type)
    if _is_complex(normalized, bool(is_array)):
        return False
    return normalized not in PSEUDO_SCALAR_TYPES
