"""
LakeGraph integration service (Story 3).

Builds the LakeGraph external-API payload from the current LakeFusion
configuration and proxies POST/GET to LakeGraph. The user's Databricks JWT
is forwarded as the bearer token; LakeGraph validates it against the same
workspace OIDC provider, so there are no service-to-service secrets to manage.

State is persisted in the ``lakegraph_deployment`` Postgres table so the
"Create" button on the Relationships page can flip to "Regenerate" / "View"
based on the stored hash + status.
"""

import hashlib
import json
from typing import Any, Dict, List, Optional

import requests
from fastapi import HTTPException, status
from sqlalchemy.orm import Session, joinedload

from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.models.entity import Entity, EntityType
from lakefusion_utility.models.integration_hub import (
    Integration_Hub,
    IntegrationHubRelationshipSyncPipeline,
)
from lakefusion_utility.models.relationship import (
    LakeGraphDeployment,
    LakeGraphDeployRequest,
    LakeGraphDeploymentResponse,
    Relationship,
    RelationshipStatus,
    RelationshipGraph,
)
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from lakefusion_utility.utils.logging_utils import get_logger


app_logger = get_logger(__name__)

FEATURE_FLAG_NAME = "ENABLE_RELATIONSHIPS"
LAKEGRAPH_URL_KEY = "lakegraph_url"  # db_config_properties key (Settings → LakeGraph)


def _assert_feature_enabled(db: Session) -> None:
    if not FeatureFlagService._is_feature_flag_enabled(db, FEATURE_FLAG_NAME):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                f"Feature flag '{FEATURE_FLAG_NAME}' is not active. LakeGraph "
                "integration is disabled."
            ),
        )


def _lakegraph_url_value(db: Session) -> str:
    """Configured LakeGraph base URL from db_config_properties (Settings →
    LakeGraph), normalised (https:// prefix, no trailing slash). '' if unset."""
    row = (
        db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == LAKEGRAPH_URL_KEY)
        .first()
    )
    url = (row.config_value or "").strip() if row else ""
    if not url:
        return ""
    if not url.startswith(("http://", "https://")):
        url = f"https://{url}"
    return url.rstrip("/")


def _lakegraph_url(db: Session) -> str:
    url = _lakegraph_url_value(db)
    if not url:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "LakeGraph URL is not configured. Set it in Settings → LakeGraph "
                "before deploying."
            ),
        )
    return url


def _catalog_name(db: Session) -> str:
    row = (
        db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == "catalog_name")
        .first()
    )
    if not row:
        raise HTTPException(status_code=500, detail="catalog_name not configured.")
    return row.config_value


def _source_system_id(db: Session) -> str:
    """Tenant identifier used by LakeGraph for idempotency + redeploy lookups."""
    row = (
        db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == "tenant_id")
        .first()
    )
    if row and row.config_value:
        return f"lakefusion-{row.config_value}"
    # Fallback: catalog name. Stable per tenant in practice.
    return f"lakefusion-{_catalog_name(db)}"


def _slug(s: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in s.lower()).strip("_")


class LakeGraphService:
    def __init__(self, db: Session):
        self.db = db

    # ------------------------------------------------------------------
    # Payload assembly
    # ------------------------------------------------------------------

    def _get_graph(self, graph_id: int) -> RelationshipGraph:
        g = (
            self.db.query(RelationshipGraph)
            .filter(RelationshipGraph.id == graph_id)
            .first()
        )
        if not g or not g.is_active:
            raise HTTPException(status_code=404, detail=f"Graph {graph_id} not found.")
        return g

    @staticmethod
    def _headers(token: str, user_email: str = "", json_body: bool = True) -> Dict[str, str]:
        h = {"Authorization": f"Bearer {token}"}
        if user_email:
            # Informational identity for LakeGraph's audit trail (PRD §Auth).
            h["X-Lakefusion-User-Id"] = user_email
        if json_body:
            h["Content-Type"] = "application/json"
        return h

    def _source_system_id_for_graph(self, graph: RelationshipGraph) -> str:
        """Per-graph idempotency key: <tenant base>-<graph slug>."""
        return f"{_source_system_id(self.db)}-{graph.slug}"

    def _graph_relationships(self, graph: RelationshipGraph) -> List[Relationship]:
        rel_ids = [m.relationship_id for m in (graph.members or [])]
        if not rel_ids:
            return []
        return (
            self.db.query(Relationship)
            .options(
                joinedload(Relationship.source_entity),
                joinedload(Relationship.target_entity),
            )
            .filter(
                Relationship.id.in_(rel_ids),
                Relationship.is_active == True,  # noqa: E712
            )
            .all()
        )

    def _entities_for(self, relationships: List[Relationship]) -> List[Entity]:
        """Every endpoint entity of the graph's relationships must be an active
        master entity with an active Integration Hub job (so ``_master_prod``
        exists). Otherwise the graph isn't deployable — raise a clear 400 listing
        what's not ready. This also guarantees every edge's source/target
        vertex_type has a matching node table."""
        required_ids = set()
        for r in relationships:
            required_ids.add(r.source_entity_id)
            required_ids.add(r.target_entity_id)
        if not required_ids:
            return []
        entities = (
            self.db.query(Entity)
            .filter(
                Entity.id.in_(required_ids),
                Entity.is_active == True,  # noqa: E712
                Entity.entity_type == EntityType.MASTER.value,
            )
            .all()
        )
        active_inthub_ids = {
            row.entity_id
            for row in self.db.query(Integration_Hub)
            .filter(Integration_Hub.is_active == True)  # noqa: E712
            .all()
        }
        ready = [e for e in entities if e.id in active_inthub_ids]
        ready_ids = {e.id for e in ready}
        missing = required_ids - ready_ids
        if missing:
            names = {
                e.id: e.name
                for e in self.db.query(Entity).filter(Entity.id.in_(missing)).all()
            }
            label = ", ".join(names.get(i, f"#{i}") for i in sorted(missing))
            raise HTTPException(
                status_code=400,
                detail=(
                    "These endpoint entities are not ready to deploy (need a master "
                    f"entity with an active Integration Hub job): {label}."
                ),
            )
        return ready

    def _build_payload(
        self, graph: RelationshipGraph, request: LakeGraphDeployRequest
    ) -> Dict[str, Any]:
        relationships = self._graph_relationships(graph)
        if not relationships:
            raise HTTPException(
                status_code=400,
                detail=(
                    "This graph has no active relationships. Add at least one loaded "
                    "relationship to the graph before deploying."
                ),
            )
        entities = self._entities_for(relationships)

        catalog = _catalog_name(self.db)
        source_system_id = self._source_system_id_for_graph(graph)
        graph_name = request.graph_name or graph.name
        # User-selected target catalog.schema. LakeGraph requires it to already
        # exist (it does not create catalogs/schemas), so the graph must carry one.
        output_schema = (graph.output_schema or "").strip()
        if not output_schema or len(output_schema.split(".")) < 2:
            raise HTTPException(
                status_code=400,
                detail=(
                    "This graph has no target output schema. Edit the graph and pick a "
                    "catalog + schema (catalog.schema) before deploying."
                ),
            )

        # LakeGraph introspects the tables. Node tables point at the CDF-enabled
        # {entity}_master_prod table directly (no view): LakeGraph falls back to
        # lakefusion_id as node_id and the config's vertex_type as node_type when
        # node_id/node_type columns are absent. {rel}_edges_prod carries
        # src/dst_node_id + src/dst_node_type. So payload needs uc_path + type only.
        node_tables = []
        for e in entities:
            normalized = (e.name or "").lower().replace(" ", "_")
            node_tables.append(
                {
                    "uc_path": f"{catalog}.gold.{normalized}_master_prod",
                    "vertex_type": e.name,
                }
            )

        edge_tables = []
        for r in relationships:
            edge_tables.append(
                {
                    "uc_path": f"{catalog}.gold.{r.name}_edges_prod",
                    "relationship_type": r.name,
                }
            )

        return {
            # LakeGraph validates lakefusion_id as an integer; send the graph's
            # numeric id. The string idempotency key goes in source_system_id.
            "lakefusion_id": graph.id,
            "graph_name": graph_name,
            "graph_description": request.description
            or graph.description
            or f"MDM graph from LakeFusion ({graph.name})",
            "source_system": "lakefusion",
            "source_system_id": source_system_id,
            "node_tables": node_tables,
            "edge_tables": edge_tables,
            "deployment": {
                "warehouse_id": request.warehouse_id,
                "output_schema": output_schema,
            },
        }

    @staticmethod
    def _hash_payload(payload: Dict[str, Any]) -> str:
        canon = json.dumps(payload, sort_keys=True, default=str)
        return hashlib.sha256(canon.encode("utf-8")).hexdigest()[:32]

    # ------------------------------------------------------------------
    # State (Postgres)
    # ------------------------------------------------------------------

    def _get_or_create_deployment(
        self, source_system_id: str, graph_id: int
    ) -> LakeGraphDeployment:
        row = (
            self.db.query(LakeGraphDeployment)
            .filter(LakeGraphDeployment.graph_id == graph_id)
            .first()
        )
        if row:
            return row
        row = LakeGraphDeployment(
            source_system_id=source_system_id, graph_id=graph_id, deploy_count=0
        )
        self.db.add(row)
        db_commit_auto_rollback(self.db)
        self.db.refresh(row)
        return row

    def get_state(self, graph_id: int) -> Optional[LakeGraphDeploymentResponse]:
        """Read the deployment state for one graph. Defensive: any internal
        failure is treated as "no deployment" so the UI renders the Create state."""
        try:
            if not FeatureFlagService._is_feature_flag_enabled(self.db, FEATURE_FLAG_NAME):
                return None
            row = (
                self.db.query(LakeGraphDeployment)
                .filter(LakeGraphDeployment.graph_id == graph_id)
                .first()
            )
            if not row:
                return None
            return LakeGraphDeploymentResponse.model_validate(row)
        except Exception as e:  # noqa: BLE001
            app_logger.warning(
                f"get_state suppressed error: {type(e).__name__}: {e}"
            )
            return None

    def get_live_hash(self, graph_id: int, warehouse_id: str) -> str:
        """Hash the payload that *would* be sent for this graph right now."""
        _assert_feature_enabled(self.db)
        graph = self._get_graph(graph_id)
        request = LakeGraphDeployRequest(warehouse_id=warehouse_id)
        payload = self._build_payload(graph, request)
        return self._hash_payload(payload)

    # ------------------------------------------------------------------
    # Deploy / Redeploy / Status
    # ------------------------------------------------------------------

    def _validate_tables(
        self, graph: RelationshipGraph, request: LakeGraphDeployRequest, token: str
    ) -> None:
        """Fail fast with a clear message if any node master / edge table is
        missing, instead of forwarding LakeGraph's opaque 422. Best-effort: if the
        existence check itself errors, skip and let LakeGraph validate."""
        if not request.warehouse_id:
            return
        from lakefusion_utility.utils.databricks_util import DataSetSQLService

        relationships = self._graph_relationships(graph)
        entities = self._entities_for(relationships)
        catalog = _catalog_name(self.db)
        sql = DataSetSQLService(token, request.warehouse_id)
        missing = []
        for e in entities:
            normalized = (e.name or "").lower().replace(" ", "_")
            t = f"{catalog}.gold.{normalized}_master_prod"
            try:
                if not sql.check_table_exists(t):
                    missing.append(t)
            except Exception:  # noqa: BLE001
                pass
        for r in relationships:
            t = f"{catalog}.gold.{r.name}_edges_prod"
            try:
                if not sql.check_table_exists(t):
                    missing.append(t)
            except Exception:  # noqa: BLE001
                pass
        if missing:
            raise HTTPException(
                status_code=400,
                detail=(
                    "These tables don't exist yet — run the entity master pipelines and "
                    "the relationship Integration Hub jobs first: " + ", ".join(missing)
                ),
            )

    def deploy(
        self,
        graph_id: int,
        request: LakeGraphDeployRequest,
        token: str,
        steward_id: str = "",
        user_email: str = "",
    ) -> Dict[str, Any]:
        _assert_feature_enabled(self.db)
        lg_url = _lakegraph_url(self.db)
        graph = self._get_graph(graph_id)
        # Fail fast with a clear message if the underlying tables aren't there yet.
        self._validate_tables(graph, request, token)
        payload = self._build_payload(graph, request)
        source_system_id = payload["source_system_id"]
        payload_hash = self._hash_payload(payload)

        existing = self._get_or_create_deployment(source_system_id, graph_id)
        if existing.graph_config_id:
            # Redeploy path. LakeGraph's redeploy endpoint expects
            # graph_config_id + source_system_id but a similar payload shape.
            return self._redeploy(
                existing, payload, token, steward_id, payload_hash, user_email
            )

        # DEBUG: payload sent to LakeGraph — remove later.
        app_logger.info(
            f"[lakegraph][debug] POST {lg_url}/api/external/graph-deploy\n"
            f"{json.dumps(payload, indent=2, default=str)}"
        )
        try:
            resp = requests.post(
                f"{lg_url}/api/external/graph-deploy",
                headers=self._headers(token, user_email),
                json=payload,
                timeout=60,
            )
        except requests.RequestException as e:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"LakeGraph unreachable: {type(e).__name__}: {e}",
            )

        if resp.status_code >= 400:
            try:
                body = resp.json()
            except Exception:  # noqa: BLE001
                body = {"message": resp.text}
            raise HTTPException(
                status_code=resp.status_code,
                detail={
                    "status": "error",
                    "message": body.get("message") or "LakeGraph rejected the request.",
                    "data": body,
                },
            )

        data = resp.json().get("data", {}) or {}
        dep = data.get("deployment", {}) or {}
        existing.graph_config_id = data.get("graph_config_id")
        existing.graph_name = payload["graph_name"]
        existing.deploy_count = (existing.deploy_count or 0) + 1
        existing.last_status = dep.get("status") or data.get("pipeline_status") or "pending"
        existing.deployment_hash = payload_hash
        existing.last_deployed_at = None  # set on first status poll
        existing.redirect_url = data.get("redirect_url")
        existing.run_id = dep.get("run_id") or data.get("run_id")
        existing.run_url = dep.get("run_url") or data.get("run_url")
        existing.created_by = steward_id or existing.created_by
        db_commit_auto_rollback(self.db)
        self.db.refresh(existing)
        return {
            "status": "success",
            "message": "GraphDB deployment initiated",
            "data": {
                "graph_id": graph_id,
                "graph_config_id": existing.graph_config_id,
                "deploy_count": existing.deploy_count,
                "deployment": data.get("deployment", {}),
                "redirect_url": existing.redirect_url,
                "source_system_id": source_system_id,
            },
        }

    def _redeploy(
        self,
        existing: LakeGraphDeployment,
        payload: Dict[str, Any],
        token: str,
        steward_id: str,
        payload_hash: str,
        user_email: str = "",
    ) -> Dict[str, Any]:
        lg_url = _lakegraph_url(self.db)
        # Redeploy payload is the same shape, with graph_config_id added.
        redeploy_payload = dict(payload)
        redeploy_payload["graph_config_id"] = existing.graph_config_id

        # DEBUG: payload sent to LakeGraph — remove later.
        app_logger.info(
            f"[lakegraph][debug] POST {lg_url}/api/external/graph-redeploy\n"
            f"{json.dumps(redeploy_payload, indent=2, default=str)}"
        )
        try:
            resp = requests.post(
                f"{lg_url}/api/external/graph-redeploy",
                headers=self._headers(token, user_email),
                json=redeploy_payload,
                timeout=60,
            )
        except requests.RequestException as e:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"LakeGraph unreachable: {type(e).__name__}: {e}",
            )

        if resp.status_code >= 400:
            try:
                body = resp.json()
            except Exception:  # noqa: BLE001
                body = {"message": resp.text}
            raise HTTPException(
                status_code=resp.status_code,
                detail={
                    "status": "error",
                    "message": body.get("message") or "LakeGraph rejected the redeploy.",
                    "data": body,
                },
            )

        data = resp.json().get("data", {}) or {}
        dep = data.get("deployment", {}) or {}
        existing.deploy_count = (existing.deploy_count or 0) + 1
        existing.last_status = dep.get("status") or data.get("pipeline_status") or "pending"
        existing.deployment_hash = payload_hash
        existing.redirect_url = data.get("redirect_url") or existing.redirect_url
        existing.run_id = dep.get("run_id") or data.get("run_id") or existing.run_id
        existing.run_url = dep.get("run_url") or data.get("run_url") or existing.run_url
        if steward_id:
            existing.created_by = steward_id
        db_commit_auto_rollback(self.db)
        self.db.refresh(existing)
        return {
            "status": "success",
            "message": "GraphDB redeployment initiated",
            "data": {
                "graph_id": existing.graph_id,
                "graph_config_id": existing.graph_config_id,
                "deploy_count": existing.deploy_count,
                "deployment": data.get("deployment", {}),
                "redirect_url": existing.redirect_url,
                "source_system_id": existing.source_system_id,
            },
        }

    def status(self, graph_id: int, token: str, user_email: str = "") -> Dict[str, Any]:
        _assert_feature_enabled(self.db)
        lg_url = _lakegraph_url(self.db)
        row = (
            self.db.query(LakeGraphDeployment)
            .filter(LakeGraphDeployment.graph_id == graph_id)
            .first()
        )
        if not row or not row.graph_config_id:
            return {"status": "not_deployed"}

        try:
            resp = requests.get(
                f"{lg_url}/api/external/graph-status/{row.graph_config_id}",
                headers=self._headers(token, user_email, json_body=False),
                timeout=30,
            )
        except requests.RequestException as e:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail=f"LakeGraph unreachable: {type(e).__name__}: {e}",
            )
        if resp.status_code >= 400:
            return {"status": "error", "code": resp.status_code, "body": resp.text}

        body = resp.json() if resp.content else {}
        # The status payload is flat (no "data" wrapper) and uses pipeline_status;
        # deploy used a nested "deployment.status". Handle both shapes.
        data = body.get("data", body) if isinstance(body, dict) else {}
        dep = data.get("deployment", {}) or {}

        last_status = data.get("pipeline_status") or dep.get("status")
        run_url = data.get("run_url") or dep.get("run_url")
        run_id = data.get("run_id") or dep.get("run_id")
        redirect_url = data.get("redirect_url")

        changed = False
        if last_status and last_status != row.last_status:
            row.last_status = last_status
            changed = True
        if run_url and run_url != row.run_url:
            row.run_url = run_url
            changed = True
        if run_id and run_id != row.run_id:
            row.run_id = run_id
            changed = True
        if redirect_url and redirect_url != row.redirect_url:
            row.redirect_url = redirect_url
            changed = True
        if changed:
            db_commit_auto_rollback(self.db)
        return data
