import traceback
from sqlalchemy.orm import Session
from lakefusion_utility.schemas.profiling_tasks import ProfilingTaskCreate, ProfilingTaskResponse, ProfilingTaskRefreshInfo
from lakefusion_utility.utils.databricks_util import MonitoringService, MonitorFailedError  # Import the MonitoringService
from lakefusion_utility.models.profiling_tasks import ProfilingTask
from lakefusion_utility.utils.databricks_util import DataSetSQLService, CatalogService
from typing import Dict, List, Optional
from lakefusion_utility.utils.logging_utils import get_logger
from fastapi import HTTPException
from databricks.sdk.errors import PermissionDenied
import os
from sqlalchemy import or_, and_, func, JSON
from datetime import datetime
from lakefusion_utility.utils.db_compat import json_field

# Set up logging
app_logger = get_logger(__name__)

# Internal dapi token
lakefusion_databricks_dapi = os.environ.get('LAKEFUSION_DATABRICKS_DAPI', '')

class ProfilingTaskService:
    def __init__(self, db: Session):
        """
        Initializes the ProfilingTaskService with a database session.

        Parameters:
        - db: The database session to be used for operations
        """
        self.db = db

    def create_profiling_task(self, profiling_task: ProfilingTaskCreate, created_by: str, token: str) -> ProfilingTaskResponse:
        """
        Create a new profiling task in the database.

        Parameters:
        - profiling_task: Data model containing task details
        - created_by: Username of the creator
        - token: Auth token for monitoring services

        Returns:
        - ProfilingTaskResponse: The created profiling task object
        """
        try:
            # Check if dataset already has a profiling task
            existing_task = self.db.query(ProfilingTask).filter(
                ProfilingTask.dataset_id == profiling_task.dataset_id,
            ).first()
            
            if existing_task:
                raise HTTPException(
                    status_code=409,
                    detail=f"Dataset with ID {profiling_task.dataset_id} already has a profiling task."
                )
            
            # Create a new ProfilingTask object, add to the database session
            db_task = ProfilingTask(**profiling_task.model_dump(exclude={'warehouse_id'}), created_by=created_by)
            self.db.add(db_task)
            self.db.flush()  # Flush the transaction

            # Check if entity_id is None to trigger monitoring
            if db_task.entity_id is None:
                # Initialize the MonitoringService
                monitoring_service = MonitoringService(token=token)
                
                # Check if a monitoring task already exists for this dataset
                existing_monitor = monitoring_service.get_monitor_for_table(db_task.dataset.path)
                
                if existing_monitor:
                    monitor_dict = {
                        "status": str(existing_monitor.status.value) if hasattr(existing_monitor.status, 'value') else str(existing_monitor.status),
                        "table_name": existing_monitor.table_name,
                        "monitor_version": existing_monitor.monitor_version,
                        "assets_dir": existing_monitor.assets_dir,
                        "output_schema_name": existing_monitor.output_schema_name,
                        "profile_metrics_table_name": existing_monitor.profile_metrics_table_name,
                        "drift_metrics_table_name": existing_monitor.drift_metrics_table_name,
                        "dashboard_id": existing_monitor.dashboard_id
                    }
                    
                    if hasattr(existing_monitor, 'schedule') and existing_monitor.schedule:
                        monitor_dict["schedule"] = {
                            "timezone_id": existing_monitor.schedule.timezone_id,
                            "pause_status": str(existing_monitor.schedule.pause_status.value) if hasattr(existing_monitor.schedule.pause_status, 'value') else str(existing_monitor.schedule.pause_status),
                            "quartz_cron_expression": existing_monitor.schedule.quartz_cron_expression
                        }
                    
                    if hasattr(existing_monitor, 'notifications') and existing_monitor.notifications and hasattr(existing_monitor.notifications, 'on_failure'):
                        monitor_dict["notifications"] = {
                            "on_failure": {
                                "email_addresses": existing_monitor.notifications.on_failure.email_addresses
                            }
                        }
                    
                    if hasattr(existing_monitor, 'snapshot'):
                        monitor_dict["snapshot"] = {}
                    
                    db_task.monitor_info = monitor_dict

                    # Fetch the latest refresh status separately
                    try:
                        latest_refresh_info = monitoring_service.get_refresh_status(db_task.dataset.path)
                        refresh_info = {
                            "refresh_id": latest_refresh_info.refresh_id,
                            "status": latest_refresh_info.state.value if hasattr(latest_refresh_info.state, 'value') else str(latest_refresh_info.state),
                            "started_at": datetime.fromtimestamp(latest_refresh_info.start_time_ms / 1000).isoformat() if latest_refresh_info.start_time_ms else None,
                            "completed_at": datetime.fromtimestamp(latest_refresh_info.end_time_ms / 1000).isoformat() if latest_refresh_info.end_time_ms else None,
                            "message": latest_refresh_info.message
                        }
                        
                        if refresh_info["status"] in ['PENDING', 'RUNNING', 'QUEUED']:
                            db_task.refresh_info = refresh_info
                        else:
                            refresh_response = monitoring_service.refresh_manually(db_task.dataset.path)
                            db_task.refresh_info = {
                                "refresh_id": refresh_response.refresh_id if refresh_response and hasattr(refresh_response, 'refresh_id') else None,
                                "status": "PENDING",
                                "started_at": datetime.utcnow().isoformat(),
                                "completed_at": None,
                                "message": "Refresh triggered during task creation"
                            }
                    except MonitorFailedError as e:
                        # Monitor exists but Databricks marked it FAILED.
                        # Triggering a refresh would also be rejected — surface
                        # the state in refresh_info and let the steward fix it
                        # (delete + recreate) rather than spinning on a no-op.
                        app_logger.warning(f"Monitor for {db_task.dataset.path} is FAILED: {e}")
                        db_task.refresh_info = {
                            "refresh_id": None,
                            "status": "FAILED",
                            "started_at": None,
                            "completed_at": None,
                            "message": str(e),
                        }
                    except ValueError:
                        # No refreshes exist yet for this monitor, trigger one
                        refresh_response = monitoring_service.refresh_manually(db_task.dataset.path)
                        db_task.refresh_info = {
                            "refresh_id": refresh_response.refresh_id if refresh_response and hasattr(refresh_response, 'refresh_id') else None,
                            "status": "PENDING",
                            "started_at": datetime.utcnow().isoformat(),
                            "completed_at": None,
                            "message": "Refresh triggered during task creation"
                        }
                else:
                    if profiling_task.refresh_type == 'onSchedule':
                        monitor_info = monitoring_service.create_snapshot_monitor(
                            table_name=db_task.dataset.path,
                            failure_notifications=[created_by],
                            quartz_cron_expression=profiling_task.quartz_cron_expression,
                            timezone_id=profiling_task.timezone_id,
                            warehouse_id=profiling_task.warehouse_id
                        )
                    else:
                        monitor_info = monitoring_service.create_snapshot_monitor(
                            table_name=db_task.dataset.path,
                            failure_notifications=[created_by],
                            warehouse_id=profiling_task.warehouse_id
                        )
                    
                    # Create a compatible dictionary structure
                    monitor_dict = {
                        "status": str(monitor_info.status.value) if hasattr(monitor_info.status, 'value') else str(monitor_info.status),
                        "table_name": monitor_info.table_name,
                        "monitor_version": monitor_info.monitor_version,
                        "assets_dir": monitor_info.assets_dir,
                        "output_schema_name": monitor_info.output_schema_name,
                        "profile_metrics_table_name": monitor_info.profile_metrics_table_name,
                        "drift_metrics_table_name": monitor_info.drift_metrics_table_name,
                        "dashboard_id": monitor_info.dashboard_id
                    }
                    
                    # Add schedule if it exists
                    if hasattr(monitor_info, 'schedule') and monitor_info.schedule:
                        monitor_dict["schedule"] = {
                            "timezone_id": monitor_info.schedule.timezone_id,
                            "pause_status": str(monitor_info.schedule.pause_status.value) if hasattr(monitor_info.schedule.pause_status, 'value') else str(monitor_info.schedule.pause_status),
                            "quartz_cron_expression": monitor_info.schedule.quartz_cron_expression
                        }
                    
                    # Add notifications if they exist
                    if hasattr(monitor_info, 'notifications') and monitor_info.notifications and hasattr(monitor_info.notifications, 'on_failure'):
                        monitor_dict["notifications"] = {
                            "on_failure": {
                                "email_addresses": monitor_info.notifications.on_failure.email_addresses
                            }
                        }
                    
                    # Add snapshot if it exists
                    if hasattr(monitor_info, 'snapshot'):
                        monitor_dict["snapshot"] = {}
                    
                    db_task.monitor_info = monitor_dict

            self.db.commit()
            self.db.refresh(db_task)

            return db_task  # Return the created profiling task
        except HTTPException as he:
            self.db.rollback()
            raise he
        except PermissionDenied as e:
            # Log the exception and raise HTTPException with a 403 status code
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create profiling task. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=403, detail=f"You do not have permission to create profiling on this dataset / entity")
        except Exception as e:
            # Log the exception and raise HTTPException with a 500 status code
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create profiling task. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to create profiling task: {str(e)}")
        
    # Refresh profiling task manually
    def refresh_profiling_task(self, profiling_task_id: int, token: str) -> ProfilingTaskResponse:
        """
        Refresh an existing profiling task manually.

        Parameters:
        - profiling_task_id: ID of the profiling task to refresh
        - token: Auth token for monitoring services

        Returns:
        - ProfilingTaskResponse: The refreshed profiling task object
        """
        try:
            task = self.get_profiling_task(profiling_task_id)
            if not task:
                raise HTTPException(status_code=404, detail="Profiling task not found.")
            
            monitoring_service = MonitoringService(token=token)
            refresh_response = monitoring_service.refresh_manually(task.dataset.path)
            
            # Update refresh_info in the profiling task
            task.refresh_info = {
                "refresh_id": refresh_response.refresh_id if refresh_response else None,
                "status": "PENDING",  # Initial status when triggered
                "started_at": datetime.utcnow().isoformat(),
                "completed_at": None,
                "message": "Manual refresh triggered"
            }
            
            self.db.commit()
            self.db.refresh(task)

            app_logger.info(f"Successfully triggered manual refresh for profiling task ID {profiling_task_id}")
            return task
        except HTTPException as he:
            raise he
        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to refresh profiling task. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to refresh profiling task: {str(e)}")
    
    def update_refresh_info(self, task: ProfilingTask, refresh_info: dict) -> ProfilingTaskResponse:

        """
        Update the refresh info of a profiling task in the database.
        Parameters:
        - task: The ProfilingTask instance to update.
        - refresh_info: The new refresh info to set.
        Returns:
        - ProfilingTaskResponse: The updated profiling task object.
        """
        try:
            task.refresh_info = refresh_info  # Update the refresh info
            self.db.commit()  # Save changes to the database
            self.db.refresh(task)  # Refresh to get the latest data
            return task  # Return the updated task
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Failed to update refresh info. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to update refresh info: {str(e)}")

    def get_all_profiling_tasks(
        self, 
        sort_by: str = "created_at", 
        sort_order: str = "desc", 
        limit: Optional[int] = None, 
        offset: int = 0,
        status_filter: Optional[str] = None
    ) -> List[ProfilingTaskResponse]:
        """
        Retrieve profiling tasks from the database with filtering, sorting, and pagination options.
        
        Args:
            sort_by: Field to sort by (e.g., 'id', 'name', 'created_at', 'updated_at'). Default is 'created_at'.
            sort_order: Sort order, either 'asc' or 'desc'. Default is 'desc'.
            limit: Maximum number of records to return. If None, returns all matching records.
            offset: Number of records to skip for pagination. Default is 0.
            status_filter: Filter by monitor status (e.g., 'MONITOR_STATUS_ACTIVE', 'MONITOR_STATUS_PENDING').
            
        Returns:
            List[ProfilingTaskResponse]: A list of profiling task objects based on filters and sorting.
            
        Raises:
            HTTPException: If there's an error during retrieval or invalid parameters.
        """
        try:
            # Validate sort_order parameter
            if sort_order.lower() not in ['asc', 'desc']:
                raise HTTPException(status_code=400, detail="sort_order must be either 'asc' or 'desc'")
            
            # Validate sort_by field exists on the ProfilingTask model
            if not hasattr(ProfilingTask, sort_by):
                raise HTTPException(status_code=400, detail=f"Invalid sort field: {sort_by}")
            
            # Start building the query
            task_query = self.db.query(ProfilingTask)
            
            # Apply status filter if specified
            if status_filter is not None:
                # Filter by monitor status in JSON field
                task_query = task_query.filter(
                    ProfilingTask.monitor_info['status'].as_string() == status_filter
                )
            
            # Apply sorting
            sort_field = getattr(ProfilingTask, sort_by)
            if sort_order.lower() == 'desc':
                task_query = task_query.order_by(sort_field.desc())
            else:
                task_query = task_query.order_by(sort_field.asc())
            
            # Apply pagination if specified
            if offset > 0:
                task_query = task_query.offset(offset)
            
            if limit is not None and limit > 0:
                task_query = task_query.limit(limit)
            
            # Execute query and return results
            tasks = task_query.all()
            
            app_logger.info(
                f"Successfully retrieved {len(tasks)} profiling tasks with filters: "
                f"sort_by={sort_by}, sort_order={sort_order}, status_filter={status_filter}"
            )
            return tasks
            
        except HTTPException:
            # Re-raise HTTP exceptions (validation errors)
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch profiling tasks. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch profiling tasks: {str(e)}")
    
    def get_profiling_task(self, profiling_task_id: int) -> ProfilingTaskResponse:
        """
        Retrieve a single profiling task by its ID.

        Parameters:
        - profiling_task_id: ID of the profiling task to retrieve

        Returns:
        - ProfilingTaskResponse: The retrieved profiling task object
        """
        try:
            return self.db.query(ProfilingTask).filter(ProfilingTask.id == profiling_task_id).first()  # Query by ID
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch profiling task with ID {profiling_task_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch profiling task: {str(e)}")
        
    def update_monitor_info(self, task: ProfilingTask, monitor_info: dict) -> ProfilingTaskResponse:
        """
        Update the monitor status of a profiling task in the database.

        Parameters:
        - task: The ProfilingTask instance to update.
        - monitor_info: The new monitor info to set.

        Returns:
        - ProfilingTaskResponse: The updated profiling task object.
        """
        try:
            task.monitor_info = monitor_info  # Update the monitor info
            self.db.commit()  # Save changes to the database
            self.db.refresh(task)  # Refresh to get the latest data
            return task  # Return the updated task
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Failed to update monitor status. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to update monitor status: {str(e)}")

    def delete_profiling_task(self, profiling_task_id: int, token: str) -> ProfilingTaskResponse:
        """
        Delete a profiling task from the database.

        Parameters:
        - profiling_task_id: ID of the profiling task to delete

        Returns:
        - ProfilingTaskResponse: The deleted profiling task object
        """
        try:
            db_task = self.get_profiling_task(profiling_task_id)  # Fetch the task by ID
            if db_task:
                # Load the dataset relationship before deleting to avoid DetachedInstanceError
                # This forces SQLAlchemy to load the relationship while the session is still active
                dataset_data = db_task.dataset
                
                self.db.delete(db_task)  # Delete the task
                self.db.flush()  # Flush the transaction

                monitoring_service = MonitoringService(token=token)  # Initialize the MonitoringService
                # monitoring_service.delete_monitor(db_task.dataset.path)

                self.db.commit()
                return db_task  # Return the deleted task
            else:
                raise HTTPException(status_code=404, detail="Profiling task not found.")
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete profiling task. Reason - {message}')
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Failed to delete profiling task: {str(e)}")
        
    def fetch_tasks_with_pending_status(self) -> List[ProfilingTask]:
        """
        Fetch all profiling tasks that have monitor_info with status 'MONITOR_STATUS_PENDING'
        or 'MONITOR_STATUS_DELETE_PENDING'.
        
        Returns:
        - List[ProfilingTask]: A list of profiling tasks matching the criteria.
        
        Raises:
        - HTTPException: If there is an issue with the database query.
        """
        try:
            # Query tasks where monitor_info's status is either 'MONITOR_STATUS_PENDING' or 'MONITOR_STATUS_DELETE_PENDING'
            pending_tasks = (
                self.db.query(ProfilingTask)
                .filter(
                    or_(
                        ProfilingTask.monitor_info['status'].as_string() == "MONITOR_STATUS_PENDING",
                        ProfilingTask.monitor_info['status'].as_string() == "MONITOR_STATUS_DELETE_PENDING"
                    )
                )
                .all()
            )

            if not pending_tasks:
                return []

            return pending_tasks

        except Exception as e:
            # Log the error and raise an HTTPException for the client
            message = traceback.format_exc()
            app_logger.exception(f"Failed to fetch pending profiling tasks. Reason - {message}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch pending profiling tasks: {str(e)}")
        
    def fetch_tasks_with_pending_refresh(self) -> List[ProfilingTask]:
        """
        Fetch all profiling tasks that have refresh_info with status 'PENDING'.
        
        Returns:
        - List[ProfilingTask]: A list of profiling tasks matching the criteria.
        
        Raises:
        - HTTPException: If there is an issue with the database query.
        """
        try:
            # Query tasks where refresh_info's status is 'PENDING'
            pending_tasks = (
                self.db.query(ProfilingTask)
                .filter(
                    or_(
                        ProfilingTask.refresh_info['status'].as_string() == "PENDING",
                        ProfilingTask.refresh_info['status'].as_string() == "RUNNING",
                        ProfilingTask.refresh_info['status'].as_string() == "QUEUED",
                        ProfilingTask.refresh_info['status'].as_string() == None
                    )
                )
                .all()
            )

            if not pending_tasks:
                return []

            return pending_tasks

        except Exception as e:
            # Log the error and raise an HTTPException for the client
            message = traceback.format_exc()
            app_logger.exception(f"Failed to fetch profiling tasks with pending refresh. Reason - {message}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch profiling tasks with pending refresh: {str(e)}")
            
    def get_attribute_frequency(self, profiling_task_id: int, attribute_name: str, warehouse_id: str, token: str):
        try:
            task = self.get_profiling_task(profiling_task_id)
            if not task:
                raise HTTPException(status_code=404, detail="Profiling task not found")
            
            if not task.monitor_info:
                raise HTTPException(status_code=400, detail="Monitor info not available for this task")
            
            profile_table = task.monitor_info.get('profile_metrics_table_name')
            
            if not profile_table:
                raise HTTPException(status_code=400, detail="Profile metrics table not found")

            sql_service = DataSetSQLService(token, warehouse_id)
            
            query = f"""
            WITH latest_snapshot AS (
                SELECT MAX(window.start) as latest_time
                FROM {profile_table}
                WHERE log_type = 'INPUT'
                AND column_name = '{attribute_name}'
            )
            SELECT 
                window.start as snapshot_time,
                column_name,
                data_type,
                count as total_rows,
                frequent_items,
                num_nulls,
                distinct_count,
                min_length,
                max_length,
                avg_length
            FROM {profile_table}
            WHERE log_type = 'INPUT'
            AND column_name = '{attribute_name}'
            AND window.start = (SELECT latest_time FROM latest_snapshot)
            """

            results = sql_service.execute_dataset(query=query)
            
            if not results:
                raise HTTPException(
                    status_code=404,
                    detail=f"No frequency metrics found for attribute: {attribute_name}"
                )
                
            result = dict(results[0])
            
            # Process frequent items
            frequent_items = []
            length_distribution = {}
            total_rows = int(result['total_rows']) if result['total_rows'] is not None else 0
            
            try:
                items = result.get('frequent_items')
                if items is not None and total_rows > 0:
                    # Handle string representation
                    if isinstance(items, str):
                        import json
                        items = json.loads(items)
                    # Handle numpy array or list
                    elif hasattr(items, 'tolist'):
                        items = items.tolist()
                    
                    # Ensure items is iterable
                    if isinstance(items, (list, tuple)):
                        for item in items:
                            if isinstance(item, dict):
                                value = str(item.get('item', 'N/A'))
                                count = int(item.get('count', 0))
                                
                                # Calculate length for the value
                                value_length = len(str(value)) if value != 'None' else 0
                                
                                # Add to frequent items
                                freq_item = {
                                    'value': value,
                                    'count': count,
                                    'percentage': round((count * 100) / total_rows, 2) if total_rows > 0 else 0,
                                    'length': value_length
                                }
                                frequent_items.append(freq_item)
                                
                                # Add to length distribution
                                if value_length in length_distribution:
                                    length_distribution[value_length] += count
                                else:
                                    length_distribution[value_length] = count

            except Exception as e:
                app_logger.warning(f"Error processing frequent items: {str(e)}")
                frequent_items = []
                length_distribution = {}

            # Convert length distribution to sorted list
            length_stats = [
                {
                    'length': length,
                    'count': count,
                    'percentage': round((count * 100) / total_rows, 2) if total_rows > 0 else 0
                }
                for length, count in sorted(length_distribution.items())
            ]

            response = {
                'attribute_metrics': {
                    'attribute_name': str(result['column_name']),
                    'data_type': str(result['data_type']),
                    'total_rows': total_rows,
                    'distinct_values': int(result['distinct_count']) if result['distinct_count'] is not None else 0,
                    'null_count': int(result['num_nulls']) if result['num_nulls'] is not None else 0,
                    'null_percentage': round((int(result['num_nulls']) * 100) / total_rows, 2) if total_rows > 0 else 0,
                    'last_refresh': result['snapshot_time']
                },
                'frequency_distribution': {
                    'top_values': frequent_items,
                    'value_counts': len(frequent_items),
                    'min_frequency': min([item['count'] for item in frequent_items], default=0),
                    'max_frequency': max([item['count'] for item in frequent_items], default=0),
                },
                'length_metrics': {
                    'min_length': float(result['min_length']) if result['min_length'] is not None else None,
                    'max_length': float(result['max_length']) if result['max_length'] is not None else None,
                    'avg_length': float(result['avg_length']) if result['avg_length'] is not None else None,
                    'distribution': length_stats,
                    'distribution_count': len(length_stats)
                },
                'metadata': {
                    'profile_table': profile_table,
                    'task_id': task.id,
                    'task_name': task.name
                }
            }

            return response

        except HTTPException as he:
            raise he
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch attribute frequency metrics. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch attribute frequency metrics: {str(e)}"
            )
            
    def get_numerical_distribution(self, profiling_task_id: int, attribute_name: str, warehouse_id: str, token: str):
        """
        Get numerical distribution analysis for a numeric attribute.
        """
        try:
            task = self.get_profiling_task(profiling_task_id)
            if not task:
                raise HTTPException(status_code=404, detail="Profiling task not found")
            
            if not task.monitor_info:
                raise HTTPException(status_code=400, detail="Monitor info not available for this task")
            
            profile_table = task.monitor_info.get('profile_metrics_table_name')
            
            if not profile_table:
                raise HTTPException(status_code=400, detail="Profile metrics table not found")

            sql_service = DataSetSQLService(token, warehouse_id)
            
            query = f"""
            WITH latest_snapshot AS (
                SELECT MAX(window.start) as latest_time
                FROM {profile_table}
                WHERE log_type = 'INPUT'
                AND column_name = '{attribute_name}'
            )
            SELECT 
                window.start as snapshot_time,
                column_name,
                data_type,
                count as total_rows,
                num_nulls,
                num_zeros,
                min,
                max,
                avg,
                stddev,
                median,
                distinct_count,
                percent_null,
                percent_zeros
            FROM {profile_table}
            WHERE log_type = 'INPUT'
            AND column_name = '{attribute_name}'
            AND window.start = (SELECT latest_time FROM latest_snapshot)
            """

            results = sql_service.execute_dataset(query=query)
            
            if not results:
                raise HTTPException(
                    status_code=404,
                    detail=f"No numerical distribution metrics found for attribute: {attribute_name}"
                )
                
            result = dict(results[0])

            # Calculate additional statistical measures
            response = {
                'attribute_metrics': {
                    'attribute_name': str(result['column_name']),
                    'data_type': str(result['data_type']),
                    'total_rows': int(result['total_rows']) if result['total_rows'] is not None else 0,
                    'last_refresh': result['snapshot_time']
                },
                'statistical_metrics': {
                    'min': float(result['min']) if result['min'] is not None else None,
                    'max': float(result['max']) if result['max'] is not None else None,
                    'mean': float(result['avg']) if result['avg'] is not None else None,
                    'median': float(result['median']) if result['median'] is not None else None,
                    'standard_deviation': float(result['stddev']) if result['stddev'] is not None else None,
                    'distinct_values': int(result['distinct_count']) if result['distinct_count'] is not None else 0,
                    'null_count': int(result['num_nulls']) if result['num_nulls'] is not None else 0,
                    'zero_count': int(result['num_zeros']) if result['num_zeros'] is not None else 0,
                    'null_percentage': float(result['percent_null']) if result['percent_null'] is not None else 0,
                    'zero_percentage': float(result['percent_zeros']) if result['percent_zeros'] is not None else 0
                },
                'metadata': {
                    'profile_table': profile_table,
                    'task_id': task.id,
                    'task_name': task.name
                }
            }

            return response

        except HTTPException as he:
            raise he
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch numerical distribution metrics. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch numerical distribution metrics: {str(e)}"
            )

    def get_current_metrics(
        self, 
        profiling_task_id: int, 
        warehouse_id: str, 
        token: str
    ):
        """
        Get current metrics including table metrics and per-attribute metrics.
        """
        try:
            task = self.get_profiling_task(profiling_task_id)
            if not task or not task.monitor_info:
                raise HTTPException(status_code=404, detail="Profiling task not found or no monitor info available")
            
            profile_table = task.monitor_info.get('profile_metrics_table_name')
            if not profile_table:
                raise HTTPException(status_code=400, detail="Profile metrics table not found")

            sql_service = DataSetSQLService(token, warehouse_id)
            
            query = f"""
            WITH latest_snapshot AS (
                SELECT MAX(window.start) as latest_time
                FROM {profile_table}
                WHERE log_type = 'INPUT'
            )
            SELECT 
                window.start as snapshot_time,
                column_name,
                data_type,
                count,
                num_nulls,
                distinct_count,
                CASE 
                    WHEN count = 0 THEN 0 
                    ELSE ROUND((count) * 100.0 / (count + num_nulls), 2)
                END as completion_percentage,
                CASE 
                    WHEN count = 0 THEN 0
                    ELSE ROUND(CAST(distinct_count AS FLOAT) * 100 / count, 2)
                END as unique_percentage,
                CASE 
                    WHEN count = 0 THEN 0
                    ELSE ROUND((1 - CAST(distinct_count AS FLOAT) / count) * 100, 2)
                END as duplicate_percentage
            FROM {profile_table}
            WHERE log_type = 'INPUT'
            AND window.start = (SELECT latest_time FROM latest_snapshot)
            ORDER BY column_name
            """

            results = sql_service.execute_dataset(query=query)
            if not results:
                raise HTTPException(status_code=404, detail="No profile metrics data found")
                
            attributes_metrics = {}
            total_row_count = 0
            snapshot_time = None
            
            for row in results:
                if not snapshot_time:
                    snapshot_time = row['snapshot_time']
                
                col_name = row['column_name']
                if col_name == ':table':
                    total_row_count = row['count']
                    continue
                    
                attributes_metrics[col_name] = {
                    'name': col_name,
                    'data_type': row['data_type'],
                    'completeness': {
                        'total_rows': row['count'] + row['num_nulls'],
                        'missing_rows': row['num_nulls'],
                        'existing_rows': row['count'],
                        'completion_percentage': row['completion_percentage']
                    },
                    'uniqueness': {
                        'total_rows': row['count'],
                        'distinct_count': row['distinct_count'],
                        'duplicate_count': row['count'] - row['distinct_count'],
                        'unique_percentage': row['unique_percentage'],
                        'duplicate_percentage': row['duplicate_percentage']
                    }
                }

            response = {
                'table_metrics': {
                    'total_row_count': total_row_count,
                    'total_attributes': len(attributes_metrics),
                    'last_refresh_time': snapshot_time
                },
                'attributes': attributes_metrics,
                'metadata': {
                    'profile_table': profile_table,
                    'task_id': task.id,
                    'task_name': task.name
                }
            }

            return response

        except HTTPException as he:
            raise he
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch current metrics. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch current metrics: {str(e)}"
            )

    def get_historical_metrics(
        self, 
        profiling_task_id: int, 
        attribute_name: str,
        warehouse_id: str, 
        token: str,
    ):
        """
        Get historical metrics for a specific attribute.
        """
        try:
            task = self.get_profiling_task(profiling_task_id)
            if not task or not task.monitor_info:
                raise HTTPException(status_code=404, detail="Profiling task not found or no monitor info available")
            
            profile_table = task.monitor_info.get('profile_metrics_table_name')
            if not profile_table:
                raise HTTPException(status_code=400, detail="Profile metrics table not found")

            sql_service = DataSetSQLService(token, warehouse_id)
            
            query = f"""
            WITH latest_snapshot AS (
                SELECT MAX(window.start) as latest_time
                FROM {profile_table}
                WHERE log_type = 'INPUT'
            )
            SELECT 
                window.start as snapshot_time,
                count,
                num_nulls,
                distinct_count,
                CASE 
                    WHEN count = 0 THEN 0 
                    ELSE ROUND((count) * 100.0 / (count + num_nulls), 2)
                END as completion_percentage,
                CASE 
                    WHEN count = 0 THEN 0
                    ELSE ROUND(CAST(distinct_count AS FLOAT) * 100 / count, 2)
                END as unique_percentage,
                CASE 
                    WHEN count = 0 THEN 0
                    ELSE ROUND((1 - CAST(distinct_count AS FLOAT) / count) * 100, 2)
                END as duplicate_percentage
            FROM {profile_table}
            WHERE log_type = 'INPUT'
            AND column_name = '{attribute_name}'
            ORDER BY window.start DESC
            """

            results = sql_service.execute_dataset(query=query)
            if not results:
                raise HTTPException(
                    status_code=404, 
                    detail=f"No historical metrics found for attribute: {attribute_name}"
                )
            
            metrics_over_time = []
            current_metrics = None
            
            for idx, row in enumerate(results):
                metric = {
                    'timestamp': row['snapshot_time'],
                    'completeness': {
                        'total_rows': row['count'] + row['num_nulls'],
                        'missing_rows': row['num_nulls'],
                        'existing_rows': row['count'],
                        'completion_percentage': row['completion_percentage']
                    },
                    'uniqueness': {
                        'total_rows': row['count'],
                        'distinct_count': row['distinct_count'],
                        'duplicate_count': row['count'] - row['distinct_count'],
                        'unique_percentage': row['unique_percentage'],
                        'duplicate_percentage': row['duplicate_percentage']
                    }
                }
                
                if idx == 0:
                    current_metrics = metric
                metrics_over_time.append(metric)

            response = {
                'attribute_name': attribute_name,
                'current_metrics': current_metrics,
                'historical_data': metrics_over_time,
                'metadata': {
                    'profile_table': profile_table,
                    'task_id': task.id,
                    'task_name': task.name,
                }
            }

            return response

        except HTTPException as he:
            raise he
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch historical metrics. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch historical metrics: {str(e)}"
            )
        
    def get_profiling_tasks_by_dataset_ids(
        self,
        dataset_ids: List[int],
        sort_by: str = "created_at",
        sort_order: str = "desc",
        limit: Optional[int] = None,
        offset: int = 0,
        status_filter: Optional[str] = None
    ) -> List[ProfilingTaskResponse]:
        """
        Retrieve profiling tasks filtered by a list of dataset IDs.
        
        Args:
            dataset_ids (List[int]): List of dataset IDs to filter profiling tasks.
            sort_by (str): Field to sort by (default 'created_at').
            sort_order (str): 'asc' or 'desc' sort order (default 'desc').
            limit (Optional[int]): Max number of records to return.
            offset (int): Number of records to skip for pagination.
            status_filter (Optional[str]): Filter by monitor status.
        Returns:
            List[ProfilingTaskResponse]: List of profiling tasks for the given dataset IDs.
            
        Raises:
            HTTPException: On invalid parameters or query failure.
        """
        if not dataset_ids:
            raise HTTPException(status_code=400, detail="dataset_ids list cannot be empty")

        try:
            # Validate sort_order
            if sort_order.lower() not in ['asc', 'desc']:
                raise HTTPException(status_code=400, detail="sort_order must be either 'asc' or 'desc'")

            # Validate sort_by field exists on ProfilingTask model
            if not hasattr(ProfilingTask, sort_by):
                raise HTTPException(status_code=400, detail=f"Invalid sort field: {sort_by}")

            # Start building the query
            query = self.db.query(ProfilingTask).filter(ProfilingTask.dataset_id.in_(dataset_ids))

            # Apply status filter if provided
            if status_filter:
                query = query.filter(ProfilingTask.monitor_info['status'].as_string() == status_filter)

            # Apply sorting
            sort_field = getattr(ProfilingTask, sort_by)
            query = query.order_by(sort_field.desc() if sort_order.lower() == 'desc' else sort_field.asc())

            # Apply pagination
            if offset > 0:
                query = query.offset(offset)
            if limit is not None and limit > 0:
                query = query.limit(limit)

            tasks = query.all()

            app_logger.info(
                f"Retrieved {len(tasks)} profiling tasks for dataset_ids={dataset_ids} "
                f"with sort_by={sort_by}, sort_order={sort_order}, status_filter={status_filter}"
            )

            return tasks

        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to fetch profiling tasks by dataset_ids. Reason - {message}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch profiling tasks: {str(e)}")
        
    def check_profile_metrics_table_exists(self, profiling_task_id: int, token: str):
        """
        Check if the profile metrics table exists for a profiling task.

        This method is intended to be called from the API layer as:
            service.check_profile_metrics_table_exists(profiling_task_id, token)

        Parameters:
        - profiling_task_id: ID of the profiling task to check
        - token: Databricks/DAPI token to use when querying the catalog

        Returns a dict with keys: profiling_task_id, profile_table_name, table_exists (bool)
        """
        try:
            task = self.get_profiling_task(profiling_task_id)
            if not task:
                raise HTTPException(status_code=404, detail=f"Profiling task with ID {profiling_task_id} not found.")

            if not task.monitor_info:
                # If monitor_info isn't present we can't determine the table; treat as not found
                return {
                    "profiling_task_id": profiling_task_id,
                    "profile_table_name": None,
                    "table_exists": False,
                }

            profile_table_name = task.monitor_info.get('profile_metrics_table_name')
            if not profile_table_name:
                return {
                    "profiling_task_id": profiling_task_id,
                    "profile_table_name": None,
                    "table_exists": False,
                }

            # Use the provided token to query the catalog
            catalog_service = CatalogService(token=token, db=self.db)
            table_exists = catalog_service.check_table_exists(profile_table_name)

            return {
                "profiling_task_id": profiling_task_id,
                "profile_table_name": profile_table_name,
                "table_exists": table_exists,
            }
        except HTTPException:
            raise
        except Exception as e:
            app_logger.exception(f"Error checking profile metrics table existence for task {profiling_task_id}: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error checking profile metrics table existence: {str(e)}")
            

def check_monitor_status(db: Session):
    """
    Check and update the monitor status of pending profiling tasks.

    This function fetches all profiling tasks that have monitor_info with status 
    'MONITOR_STATUS_PENDING' or 'MONITOR_STATUS_DELETE_PENDING'. For each pending 
    task, it retrieves the latest monitor information and updates the task's 
    monitor_info in the database.

    Logging is performed to track the start and end of the function, as well as 
    any errors that may occur during execution.

    Returns:
    - None: This function does not return a value.

    Raises:
    - HTTPException: If there is an issue with the database query or 
      fetching monitor information.
    """
    app_logger.info("Starting check_monitor_status function execution.")
    
    try:
        # Initialize the ProfilingTaskService with the database session.
        task_service = ProfilingTaskService(db)
        
        # Attempt to fetch tasks that have a pending monitor status.
        try:
            pending_tasks = task_service.fetch_tasks_with_pending_status()
        except Exception as e:
            # Log any errors that occur while fetching pending tasks.
            app_logger.error(f"Error fetching pending tasks: {str(e)}")
            app_logger.error(f"Traceback: {traceback.format_exc()}")
            return  # Exit the function if an error occurs to prevent further processing.
        
        # Iterate over each pending task to check its monitor status.
        for task in pending_tasks:
            try:
                # Create an instance of MonitoringService using the appropriate token.
                monitoring_service = MonitoringService(token=lakefusion_databricks_dapi)
                
                # Fetch the latest monitor information for the task's dataset.
                latest_monitor_info = monitoring_service.get_monitor(task.dataset.path)
                
                # Update the task's monitor_info in the database with the latest information.
                task_service.update_monitor_info(task, latest_monitor_info.as_dict())

            except Exception as task_error:
                # Log any errors that occur while processing each individual task.
                app_logger.error(f"Error processing task with ID {task.id}: {str(task_error)}")
                app_logger.error(f"Traceback: {traceback.format_exc()}")
                # Optionally, implement retry logic or other error handling here.

    except Exception as function_error:
        # Log any errors that occur at the function level.
        app_logger.error(f"Error in check_monitor_status function: {str(function_error)}")
        app_logger.error(f"Traceback: {traceback.format_exc()}")
    
    # Log the completion of the function execution.
    app_logger.info("Finished check_monitor_status function execution.")

def check_refresh_status(db: Session):
    """
    Check and update the refresh status of profiling tasks.
    This function fetches all profiling tasks that have refresh_info with status
    'PENDING'. For each pending task, it retrieves the latest refresh information
    and updates the task's refresh_info in the database.
    """
    app_logger.info("Starting check_refresh_status function execution.")
    try:
        # Initialize the ProfilingTaskService with the database session.
        task_service = ProfilingTaskService(db)

        try:
            # Fetch tasks that have a pending refresh status.
            pending_refresh_tasks = task_service.fetch_tasks_with_pending_refresh()
        except Exception as e:
            app_logger.error(f"Error fetching tasks with pending refresh: {str(e)}")
            app_logger.error(f"Traceback: {traceback.format_exc()}")
            return
        for task in pending_refresh_tasks:
            try:
                # Create an instance of MonitoringService using the appropriate token.
                monitoring_service = MonitoringService(token=lakefusion_databricks_dapi)
                # Fetch the latest refresh information for the task's dataset.
                latest_refresh_info = monitoring_service.get_refresh_status(task.dataset.path)

                # Convert to dict for storing in JSON column
                refresh_info = {
                    "refresh_id": latest_refresh_info.refresh_id,
                    "status": latest_refresh_info.state.value if hasattr(latest_refresh_info.state, 'value') else str(latest_refresh_info.state),
                    "started_at": datetime.fromtimestamp(latest_refresh_info.start_time_ms / 1000).isoformat() if latest_refresh_info.start_time_ms else None,
                    "completed_at": datetime.fromtimestamp(latest_refresh_info.end_time_ms / 1000).isoformat() if latest_refresh_info.end_time_ms else None,
                    "message": latest_refresh_info.message
                }

                # Update the task's refresh_info in the database with the latest information.
                task_service.update_refresh_info(task, refresh_info)

            except Exception as task_error:
                app_logger.error(f"Error processing task with ID {task.id}: {str(task_error)}")
                app_logger.error(f"Traceback: {traceback.format_exc()}")
    except Exception as function_error:
        app_logger.error(f"Error in check_refresh_status function: {str(function_error)}")
        app_logger.error(f"Traceback: {traceback.format_exc()}")
    # Log the completion of the function execution.
    app_logger.info("Finished check_refresh_status function execution.")

