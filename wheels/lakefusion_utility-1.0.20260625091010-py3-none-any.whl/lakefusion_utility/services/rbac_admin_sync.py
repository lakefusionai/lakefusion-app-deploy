"""
Cron job: Sync Databricks workspace admin users into the RBAC tables.

Runs hourly. Fetches all workspace users, identifies those in the "admins"
group, and ensures they have Admin role (global) in the RBAC system.

Also manages the account-level ``LAKEFUSION_ADMINS_<WORKSPACE_ID>`` group
via the workspace-proxied account SCIM API (``/api/2.0/account/scim/v2/``).
This requires only a workspace-admin DAPI token — no Account Console access
or account-admin SPN needed.
"""
import os
import re
import traceback
from datetime import datetime, timezone
from databricks.sdk import WorkspaceClient
from sqlalchemy.orm import Session

from lakefusion_utility.models.rbac import (
    Role,
    RBACGroup,
    GroupPermission,
    GroupMember,
    MemberType,
)
from lakefusion_utility.utils.logging_utils import get_logger

app_logger = get_logger(__name__)

# Shared helper guarantees the https:// prefix is present.
from lakefusion_utility.utils.databricks_host import get_databricks_host
DATABRICKS_HOST = get_databricks_host()
LAKEFUSION_DATABRICKS_DAPI = os.environ.get("LAKEFUSION_DATABRICKS_DAPI", "")

ADMIN_GROUP_NAME = "LakeFusion Admins (Auto-Synced)"
CRON_ACTOR = "system:rbac_admin_sync"


def _extract_workspace_id(host: str) -> str:
    """Extract numeric workspace ID from DATABRICKS_HOST URL.

    Azure example:
        https://adb-xxxx.x.azuredatabricks.net -> xxxx
    """
    match = re.search(r"adb-(\d+)", host)
    return match.group(1) if match else ""


def ensure_workspace_admin_group(w: WorkspaceClient, workspace_id: str, db: Session = None):
    """Create LAKEFUSION_ADMINS_<WORKSPACE_ID> as an account-level group
    via the workspace-proxied account SCIM API, assign it to the workspace,
    and sync the workspace admin users into it.

    Uses only the workspace-admin DAPI token — no Account Console access
    or account-admin SPN needed.
    Idempotent — safe to call on every cron run.

    If ``db`` is provided, updates the RBAC group's ``databricks_group_id``
    and ``dbx_display_name`` columns.
    """
    if not workspace_id:
        raise RuntimeError("workspace_id is required for admin group setup")

    api = w.api_client
    group_name = f"LAKEFUSION_ADMINS_{workspace_id}"

    # ── Step 1: Create or find the account-level group ────────────────
    resp = api.do(
        "GET",
        "/api/2.0/account/scim/v2/Groups",
        query={"filter": f'displayName eq "{group_name}"'},
    )
    resources = resp.get("Resources", [])

    if resources:
        group_id = resources[0]["id"]
        app_logger.info(
            f"Account group '{group_name}' already exists (id={group_id})"
        )
    else:
        created = api.do(
            "POST",
            "/api/2.0/account/scim/v2/Groups",
            body={"displayName": group_name},
        )
        group_id = created["id"]
        app_logger.info(
            f"Created account group '{group_name}' (id={group_id})"
        )

    # ── Step 1b: Update RBAC group with Databricks group info ─────────
    if db:
        rbac_group = db.query(RBACGroup).filter(RBACGroup.name == ADMIN_GROUP_NAME).first()
        if rbac_group:
            rbac_group.databricks_group_id = str(group_id)
            rbac_group.dbx_display_name = group_name
            db.flush()
            app_logger.info(
                f"Updated RBAC group with databricks_group_id={group_id}, "
                f"dbx_display_name={group_name}"
            )

    # ── Step 2: Assign the account group to the workspace ─────────────
    api.do(
        "PUT",
        f"/api/2.0/preview/permissionassignments/principals/{group_id}",
        body={"permissions": ["USER"]},
    )
    app_logger.info(f"Assigned '{group_name}' to workspace {workspace_id}")

    # ── Step 3: Sync admin users into the account group ───────────────
    # "admins" is a workspace-local system group and cannot be nested into
    # an account-level group. Instead, sync individual admin users.
    ws_admins = list(w.groups.list(filter='displayName eq "admins"'))
    if not ws_admins:
        raise RuntimeError("'admins' group not found in workspace")

    admin_member_ids = {m.value for m in (ws_admins[0].members or []) if m.value}
    if not admin_member_ids:
        app_logger.info("'admins' group has no members, skipping membership sync")
        return

    # Get current members of the account group (re-fetch for accurate state)
    fresh = api.do(
        "GET",
        "/api/2.0/account/scim/v2/Groups",
        query={"filter": f'displayName eq "{group_name}"'},
    )
    fresh_resources = fresh.get("Resources", [])
    existing_member_ids = {
        str(m.get("value"))
        for m in (fresh_resources[0].get("members", []) if fresh_resources else [])
    }

    # Add new admin users
    to_add = admin_member_ids - existing_member_ids
    if to_add:
        api.do(
            "PATCH",
            f"/api/2.0/account/scim/v2/Groups/{group_id}",
            body={
                "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
                "Operations": [
                    {
                        "op": "add",
                        "path": "members",
                        "value": [{"value": uid} for uid in to_add],
                    }
                ],
            },
        )
        app_logger.info(f"Added {len(to_add)} admin users to '{group_name}'")

    # Remove stale users no longer in the admins group
    to_remove = existing_member_ids - admin_member_ids
    if to_remove:
        api.do(
            "PATCH",
            f"/api/2.0/account/scim/v2/Groups/{group_id}",
            body={
                "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
                "Operations": [
                    {
                        "op": "remove",
                        "path": "members",
                        "value": [{"value": uid} for uid in to_remove],
                    }
                ],
            },
        )
        app_logger.info(f"Removed {len(to_remove)} stale users from '{group_name}'")

    if not to_add and not to_remove:
        app_logger.info(f"Account group '{group_name}' membership is up to date")


def sync_admin_users(db: Session):
    """Pull admin users from Databricks workspace and sync to RBAC tables.

    Steps:
    1. List all workspace users via Databricks SDK
    2. List members of the workspace "admins" group
    3. Ensure an RBAC group exists for admins
    4. Ensure the Admin role + global permission exists on that group
    5. Add/remove members to match Databricks admin membership
    6. Ensure the account-level LAKEFUSION_ADMINS_<WS_ID> group exists
    """
    app_logger.info("Starting sync_admin_users cron job.")

    if not DATABRICKS_HOST or not LAKEFUSION_DATABRICKS_DAPI:
        app_logger.warning(
            "DATABRICKS_HOST or LAKEFUSION_DATABRICKS_DAPI not set, skipping admin sync."
        )
        return

    try:
        # 1. Connect to Databricks and fetch admin group members
        w = WorkspaceClient(host=DATABRICKS_HOST, token=LAKEFUSION_DATABRICKS_DAPI)

        admin_emails = _get_workspace_admin_emails(w)
        app_logger.info(f"Found {len(admin_emails)} admin users in Databricks workspace.")

        if not admin_emails:
            app_logger.info("No admin users found. Skipping sync.")
            return

        # 2. Ensure the Admin role exists
        admin_role = db.query(Role).filter(Role.name == "Admin").first()
        if not admin_role:
            app_logger.error("Admin role not found in DB. Run seed migration first.")
            return

        # 3. Ensure the RBAC group for auto-synced admins exists
        admin_group = _ensure_admin_group(db, admin_role)

        # 4. Sync members
        _sync_group_members(db, admin_group, admin_emails)

        # 5. Ensure workspace-local LAKEFUSION_ADMINS_<WS_ID> group
        workspace_id = _extract_workspace_id(DATABRICKS_HOST)
        if workspace_id:
            ensure_workspace_admin_group(w, workspace_id, db=db)

        db.commit()
        app_logger.info("Finished sync_admin_users cron job successfully.")

    except Exception as e:
        db.rollback()
        app_logger.exception(
            f"Error in sync_admin_users: {traceback.format_exc()}"
        )


def _get_workspace_admin_emails(w: WorkspaceClient) -> set:
    """Fetch email addresses of users in the workspace 'admins' group."""
    admin_emails = set()
    try:
        # List members of the "admins" group via SCIM
        groups = list(w.groups.list(filter='displayName eq "admins"'))
        if not groups:
            app_logger.warning("No 'admins' group found in Databricks workspace.")
            return admin_emails

        admins_group = groups[0]
        if admins_group.members:
            # Get user details for each member
            member_ids = {m.value for m in admins_group.members if m.value}
            for user in w.users.list():
                if user.id in member_ids and user.user_name:
                    admin_emails.add(user.user_name.lower())
        else:
            app_logger.info("Databricks admins group has no members.")

    except Exception as e:
        app_logger.exception(f"Failed to fetch admin users from Databricks: {e}")

    return admin_emails


def _ensure_admin_group(db: Session, admin_role: Role) -> RBACGroup:
    """Ensure the auto-synced admin RBAC group exists with global Admin permission."""
    group = db.query(RBACGroup).filter(RBACGroup.name == ADMIN_GROUP_NAME).first()

    if not group:
        group = RBACGroup(
            name=ADMIN_GROUP_NAME,
            description="Auto-synced from Databricks workspace admins group",
            is_global=True,
            managed_by="databricks",
            created_by=CRON_ACTOR,
        )
        db.add(group)
        db.flush()  # Get the group ID
        app_logger.info(f"Created RBAC group: {ADMIN_GROUP_NAME} (id={group.id})")

    # Ensure global Admin permission exists on this group
    existing_perm = (
        db.query(GroupPermission)
        .filter(
            GroupPermission.group_id == group.id,
            GroupPermission.role_id == admin_role.id,
            GroupPermission.entity_id.is_(None),  # Global
        )
        .first()
    )

    if not existing_perm:
        perm = GroupPermission(
            group_id=group.id,
            role_id=admin_role.id,
            entity_id=None,  # Global — applies to all entities
            created_by=CRON_ACTOR,
        )
        db.add(perm)
        db.flush()
        app_logger.info(f"Added global Admin permission to group {ADMIN_GROUP_NAME}")

    return group


def _sync_group_members(db: Session, group: RBACGroup, admin_emails: set):
    """Add new admins and remove stale ones from the RBAC group."""
    # Get current members
    current_members = (
        db.query(GroupMember)
        .filter(
            GroupMember.group_id == group.id,
            GroupMember.member_type == MemberType.USER.value,
        )
        .all()
    )
    current_emails = {m.user_id.lower() for m in current_members}

    # Add new admin users
    to_add = admin_emails - current_emails
    for email in to_add:
        member = GroupMember(
            user_id=email,
            group_id=group.id,
            created_by=CRON_ACTOR,
            member_type=MemberType.USER.value,
        )
        db.add(member)
        app_logger.info(f"Added admin user to RBAC: {email}")

    # Remove users no longer in the Databricks admins group
    to_remove = current_emails - admin_emails
    for member in current_members:
        if member.user_id.lower() in to_remove:
            db.delete(member)
            app_logger.info(f"Removed admin user from RBAC: {member.user_id}")

    if to_add or to_remove:
        app_logger.info(
            f"Admin sync: +{len(to_add)} added, -{len(to_remove)} removed. "
            f"Total: {len(admin_emails)} admins."
        )
    else:
        app_logger.info("Admin sync: no changes needed.")
