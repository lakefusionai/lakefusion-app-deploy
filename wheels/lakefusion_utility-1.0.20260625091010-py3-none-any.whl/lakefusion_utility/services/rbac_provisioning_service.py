"""
RBAC Provisioning Service — called at entity-create time.

Creates the per-entity Databricks SCIM groups, wires them to the workspace,
stores the group IDs on the entity row, adds the creator as a member, and
applies grants that can be applied immediately (schemas, shared volumes,
metadata tables — anything whose resource already exists at entity-create
time). Table-level grants are deferred to pipeline execution via
``RBACPermissionsExecutor``.

This service is **backend-safe**: it depends only on ``lakefusion_utility``
(no Spark, no ``lakefusion_core_engine``), so it runs in the
databricks-service / middlelayer / cron-service environments. The flat-row
RBAC config and the SCIM/UC-grants helpers live under
``lakefusion_utility.config`` and ``lakefusion_utility.utils.databricks_groups``
— the pipeline-side ``lakefusion_core_engine`` re-exports the same symbols
for backwards compatibility.
"""

from __future__ import annotations

from typing import Iterable, Optional

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import catalog
from sqlalchemy.orm import Session

from lakefusion_utility.config.rbac_config_loader import (
    entity_group_names,
    load_grants,
)
from lakefusion_utility.models.entity import Entity
from lakefusion_utility.utils.databricks_groups import (
    add_group_members_by_email,
    ensure_account_group,
    grant_uc_object_permissions,
)
from lakefusion_utility.utils.databricks_util import (
    _create_oauth_m2m_workspace_client,
    _create_workspace_client,
)
from lakefusion_utility.utils.logging_utils import get_logger

app_logger = get_logger(__name__)


class RBACProvisioningService:
    """Entity-create-time RBAC provisioning.

    Usage:
        service = RBACProvisioningService(db=session, token=pat)
        service.provision_entity(entity, creator_email="user@example.com")
    """

    def __init__(self, db: Session, token: Optional[str] = None, catalog_name: Optional[str] = None):
        self.db = db
        # Group creation hits the account SCIM API. Default to the service
        # principal via OAuth M2M (no DAPI/PAT). An explicit token (e.g. a
        # caller forwarding the end-user's OIDC token) still wins when passed.
        self.w = _create_workspace_client(token) if token else _create_oauth_m2m_workspace_client()
        self.api = self.w.api_client
        self.catalog_name = catalog_name or self._resolve_catalog_name()

    def _resolve_catalog_name(self) -> str:
        from lakefusion_utility.models.dbconfig import DBConfigProperties
        row = (
            self.db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first()
        )
        if not row:
            raise RuntimeError("catalog_name not configured in db_config_properties")
        return row.config_value

    def provision_entity(
        self,
        entity: Entity,
        creator_email: Optional[str] = None,
        applies_to: Iterable[str] = ("always",),
        pipeline_type: Optional[str] = None,
    ) -> dict:
        """Create entity groups, write IDs back, add creator, and apply UC grants.

        Idempotent — safe to call on pre-existing entities to backfill.

        Scope control:
          * ``applies_to`` — which scopes from the flat config to apply. Defaults
            to ``("always",)`` for entity-create-time use (catalog/schema/volume
            grants only — the prod tables don't exist yet). For one-time backfill
            of existing entities whose prod tables already exist, pass
            ``("always", "prod")`` together with ``pipeline_type="integration"``
            to also stamp ``SELECT/MODIFY`` on those tables. Rows for missing
            tables are skipped via ``NotFound`` inside ``grant_uc_object_permissions``.
          * ``pipeline_type`` — restrict to ``"integration"`` or ``"match_maven"``.
            ``None`` means "all rows that don't pin a pipeline_type".

        Job / model-endpoint / vector-endpoint / uc_model grants are intentionally
        skipped here — they need runtime resolution (current job_id, dynamic
        endpoint name, parsed model names) that only the pipeline-side
        ``RBACPermissionsExecutor`` has. Those still get applied during pipeline
        runs.
        """
        groups = entity_group_names(entity.name)
        dev_group_name = groups["developer"]
        steward_group_name = groups["data_steward"]

        dev_group_id = ensure_account_group(self.api, dev_group_name)
        steward_group_id = ensure_account_group(self.api, steward_group_name)

        entity.developer_group_id = str(dev_group_id)
        entity.steward_group_id = str(steward_group_id)
        self.db.flush()

        if creator_email:
            for grp in (dev_group_name, steward_group_name):
                try:
                    add_group_members_by_email(self.api, self.w, grp, [creator_email])
                except Exception as e:
                    app_logger.warning(
                        f"Could not add creator '{creator_email}' to '{grp}': {e}"
                    )

        rows = load_grants(
            entity=entity.name,
            experiment_id="prod",
            catalog=self.catalog_name,
            pipeline_type=pipeline_type,
            applies_to=set(applies_to),
        )

        securable_map = {
            "catalog": catalog.SecurableType.CATALOG,
            "schema": catalog.SecurableType.SCHEMA,
            "volume": catalog.SecurableType.VOLUME,
            "table": catalog.SecurableType.TABLE,
        }
        granted, skipped = [], []
        for row in rows:
            securable = securable_map.get(row.resource_type)
            if securable is None:
                # job / endpoint / vector_endpoint / uc_model / index — runtime-only
                continue
            result = grant_uc_object_permissions(
                self.w, row.full_name, securable,
                {row.group_name: row.privileges},
            )
            granted.extend(result["results"])
            skipped.extend(result["skipped"])

        app_logger.info(
            f"RBAC provisioned entity='{entity.name}' "
            f"dev_group_id={dev_group_id} steward_group_id={steward_group_id} "
            f"applies_to={sorted(applies_to)} pipeline_type={pipeline_type} "
            f"grants_applied={len(granted)} skipped={len(skipped)}"
        )

        return {
            "developer_group_id": str(dev_group_id),
            "steward_group_id": str(steward_group_id),
            "grants_applied": len(granted),
            "grants_skipped": len(skipped),
        }
