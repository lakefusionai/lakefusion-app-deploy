import json
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any, Set
from cachetools import TTLCache

from sqlalchemy.orm import Session, joinedload

from lakefusion_utility.models.rbac import (
    Role,
    GroupPermission,
    GroupMember,
    EffectiveRoleResponse,
    GroupPermissionResponse,
    GroupMemberResponse,
    MemberType,
)
from lakefusion_utility.utils.role_validation import canonical_role_key
from lakefusion_utility.utils.logging_utils import get_logger

app_logger = get_logger(__name__)

# =============================================================================
# RBAC Cache Configuration
# =============================================================================
_roles_cache = TTLCache(maxsize=8, ttl=600)
_access_cache = TTLCache(maxsize=50000, ttl=15)

# Authorization policy: role name → permitted actions (hardcoded fallback).
# Admin uses an explicit action set instead of a wildcard ("*") so that the
# policy is auditable and new action types require a conscious decision to
# grant.  The book (p. 294) recommends restricting destructive capabilities
# to service principals; the "delete" action is included but logged when
# performed by human callers (see check_access).
_DEFAULT_ROLE_ACTIONS = {
    "admin": {"read", "create", "update", "delete"},
    "developer": {"read", "create", "update"},
    "data steward": {"read"},
}

# Backward compatibility: if a DB policy still uses the coarse "write" action,
# it should match the fine-grained "create" and "update" actions.  This lets
# old permissions_definition rows keep working after the vocabulary expansion.
_WRITE_EXPANSION = frozenset({"create", "update"})


def _load_role_actions_policy(db: Session) -> Dict[str, set]:
    """Load role→actions policy from the database, with hardcoded fallback.

    Uses the existing _roles_cache (600s TTL) to avoid querying on every request.
    """
    cache_key = "role_actions_policy"
    cached = _roles_cache.get(cache_key)
    if cached is not None:
        return cached

    policy = dict(_DEFAULT_ROLE_ACTIONS)  # start with defaults
    try:
        roles = db.query(Role.name, Role.permissions_definition).all()
        for name, perms_def in roles:
            key = canonical_role_key(name)
            if not key:
                continue
            if isinstance(perms_def, dict) and "actions" in perms_def:
                actions = perms_def["actions"]
                if isinstance(actions, list):
                    policy[key] = set(actions)
            # else: keep the default if present, or no entry if unknown role
    except Exception:
        app_logger.warning("Failed to load role policy from DB, using defaults")

    _roles_cache[cache_key] = policy
    return policy

# Actions that should ideally be performed only by service principals
# (machine-to-machine tokens).  Human callers are allowed but a warning
# is emitted so operators can tighten policy over time.
_SERVICE_PRINCIPAL_ACTIONS = frozenset({"delete"})

def _invalidate_rbac_caches():
    """Invalidate all RBAC caches when data changes."""
    _roles_cache.clear()
    _access_cache.clear()
    app_logger.debug("RBAC caches invalidated")


def _log_rbac_error(
    operation: str, context: Dict[str, Any], error: Exception
) -> None:
    error_log = {
        "operation": operation,
        "context": context,
        "error_type": type(error).__name__,
        "error_message": str(error),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    app_logger.exception(f"RBAC_ERROR: {json.dumps(error_log)}")


class RBACService:
    def __init__(
        self, db: Session, token: Optional[str] = None, actor_ip: Optional[str] = None
    ):
        self.db = db
        self.token = token
        self.actor_ip = actor_ip

    # -------------------------------------------------------------------------
    # Nested group resolution
    # -------------------------------------------------------------------------
    def _get_all_group_ids_for_user(self, user_id: str) -> Set[int]:
        """Get all group IDs a user belongs to, including via nested group memberships.

        Walks at most one level up: direct user memberships → parent groups
        (group-type members).
        """
        # 1. Direct group memberships (user is a direct member)
        direct_ids = {
            row[0]
            for row in self.db.query(GroupMember.group_id)
            .filter(
                GroupMember.user_id == user_id,
                GroupMember.member_type == MemberType.USER.value,
            )
            .all()
        }
        if not direct_ids:
            return set()

        # 2. Walk one level up: find parent groups where any of the user's
        #    direct groups are nested as group-type members.
        parent_ids = {
            row[0]
            for row in self.db.query(GroupMember.group_id)
            .filter(
                GroupMember.user_id.in_([str(gid) for gid in direct_ids]),
                GroupMember.member_type == MemberType.GROUP.value,
            )
            .all()
        }

        return direct_ids | parent_ids

    # -------------------------------------------------------------------------
    # check_access — centralized authorization via group-based RBAC
    # -------------------------------------------------------------------------
    def check_access(
        self,
        user_id: str,
        action: str,
        entity_id: Optional[int] = None,
        explain: bool = False,
        **_kwargs,
    ) -> Dict[str, Any]:
        """Centralized authorization decision (SpiceDB-style check).

        Derives effective role names from group memberships (including nested
        groups) and checks them against the role→actions policy map.
        """
        if not user_id or not user_id.strip():
            raise ValueError("user_id is required")
        if not action or not action.strip():
            raise ValueError("action is required")

        action_norm = action.strip().lower()
        cache_key = f"{user_id}:{action_norm}:{entity_id if entity_id is not None else 'global'}"
        cached = _access_cache.get(cache_key)
        if cached is not None:
            return {**cached, "cached": True}

        # Expand group IDs via nested group walk
        all_group_ids = self._get_all_group_ids_for_user(user_id)

        # Derive roles from expanded groups → GroupPermission → Role
        role_names = set()
        if not all_group_ids:
            permissions = []
        else:
            permissions_query = (
                self.db.query(Role.name, GroupPermission.entity_id)
                .join(GroupPermission, GroupPermission.role_id == Role.id)
                .filter(GroupPermission.group_id.in_(all_group_ids))
            )
            if entity_id is None:
                # Global-only check when no entity scope is provided.
                permissions_query = permissions_query.filter(GroupPermission.entity_id.is_(None))
            else:
                # Entity-scoped check includes both entity and global permissions.
                permissions_query = permissions_query.filter(
                    (GroupPermission.entity_id == entity_id)
                    | (GroupPermission.entity_id.is_(None))
                )
            permissions = permissions_query.distinct().all()

        for role_name, perm_entity_id in permissions:
            if role_name:
                role_names.add(role_name)

        allowed = False
        matched_roles = []
        matched_by = []

        role_policy = _load_role_actions_policy(self.db)
        for role_name in sorted(role_names):
            actions = role_policy.get(canonical_role_key(role_name), set())
            if action_norm in actions or (action_norm in _WRITE_EXPANSION and "write" in actions) or (action_norm == "write" and _WRITE_EXPANSION & actions):
                allowed = True
                matched_roles.append(role_name)
                matched_by.append({"role": role_name, "rule": action_norm})

        # Service-principal awareness (flaw #13): warn when a human caller
        # performs a destructive action so operators can tighten policy.
        is_service_principal = False
        if action_norm in _SERVICE_PRINCIPAL_ACTIONS and allowed:
            # Heuristic: service principals (M2M / client_credentials) typically
            # lack an "email" claim.  This is checked only when available via
            # _kwargs so we don't require signature-verified claims here.
            caller_email = _kwargs.get("caller_email")
            if caller_email:
                # Human caller performing a destructive action — log warning.
                app_logger.warning(
                    "DESTRUCTIVE_ACTION_BY_HUMAN: user=%s action=%s entity=%s roles=%s",
                    user_id, action_norm, entity_id, sorted(role_names),
                )
            else:
                is_service_principal = True

        result: Dict[str, Any] = {
            "allowed": allowed,
            "user_id": user_id,
            "action": action_norm,
            "entity_id": entity_id,
            "roles": sorted(role_names),
            "is_service_principal": is_service_principal,
            "matched_roles": matched_roles,
            "matched_by": matched_by,
            "reason": "allowed" if allowed else "no_matching_role_action_rule",
            "cached": False,
        }

        _access_cache[cache_key] = result
        return result

    # -------------------------------------------------------------------------
    # check_role — centralized role-membership check
    # -------------------------------------------------------------------------
    def check_role(
        self,
        user_id: str,
        required_roles: List[str],
        entity_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Check whether user holds at least one of the required roles.

        Shares the same group expansion, role resolution, caching, and
        result format as check_access(), but makes a role-membership
        decision instead of an action-permission decision.
        """
        if not user_id or not user_id.strip():
            raise ValueError("user_id is required")
        if not required_roles:
            raise ValueError("required_roles must not be empty")

        req_key = ",".join(sorted(canonical_role_key(r) for r in required_roles))
        cache_key = f"{user_id}:role:{req_key}:{entity_id if entity_id is not None else 'global'}"
        cached = _access_cache.get(cache_key)
        if cached is not None:
            return {**cached, "cached": True}

        all_group_ids = self._get_all_group_ids_for_user(user_id)

        role_names: set = set()
        if all_group_ids:
            q = (
                self.db.query(Role.name, GroupPermission.entity_id)
                .join(GroupPermission, GroupPermission.role_id == Role.id)
                .filter(GroupPermission.group_id.in_(all_group_ids))
            )
            if entity_id is None:
                q = q.filter(GroupPermission.entity_id.is_(None))
            else:
                q = q.filter(
                    (GroupPermission.entity_id == entity_id)
                    | (GroupPermission.entity_id.is_(None))
                )
            for name, _ in q.distinct().all():
                if name:
                    role_names.add(name)

        required_norm = {canonical_role_key(r) for r in required_roles}
        user_norm = {canonical_role_key(r) for r in role_names}
        matched = required_norm & user_norm
        allowed = bool(matched)

        result: Dict[str, Any] = {
            "allowed": allowed,
            "user_id": user_id,
            "entity_id": entity_id,
            "roles": sorted(role_names),
            "required_roles": sorted(required_roles),
            "matched_roles": [r for r in sorted(role_names)
                              if canonical_role_key(r) in matched],
            "reason": "role_match" if allowed else "no_matching_role",
            "cached": False,
        }
        _access_cache[cache_key] = result
        return result

    # -------------------------------------------------------------------------
    # Role CRUD
    # -------------------------------------------------------------------------
    def list_roles(self) -> List[Role]:
        try:
            cache_key = "all_roles"
            if cache_key in _roles_cache:
                return _roles_cache[cache_key]
            roles = self.db.query(Role).all()
            _roles_cache[cache_key] = roles
            return roles
        except Exception as e:
            app_logger.exception("Unable to fetch roles")
            raise RuntimeError("Failed to fetch roles") from e

    def get_role_by_id(self, role_id: int) -> Optional[Role]:
        return self.db.query(Role).filter(Role.id == role_id).first()

    def list_roles_paginated(
        self, limit: int = 100, cursor: Optional[str] = None
    ) -> Dict[str, Any]:
        """List all available roles with cursor-based pagination."""
        all_roles = self.list_roles()

        start_index = 0
        if cursor:
            try:
                cursor_id = int(cursor)
                for i, role in enumerate(all_roles):
                    if role.id > cursor_id:
                        start_index = i
                        break
                else:
                    start_index = len(all_roles)
            except (ValueError, AttributeError):
                start_index = 0

        page_roles = all_roles[start_index : start_index + limit]

        next_cursor = None
        if len(page_roles) == limit and start_index + limit < len(all_roles):
            next_cursor = str(page_roles[-1].id)

        return {
            "data": page_roles,
            "next_cursor": next_cursor,
            "has_more": next_cursor is not None,
        }

    # -------------------------------------------------------------------------
    # Effective roles — group-based only
    # -------------------------------------------------------------------------
    def get_effective_user_roles(
        self,
        user_id: str,
        **_kwargs,
    ) -> EffectiveRoleResponse:
        """Compute effective permissions from group memberships (including nested groups)."""
        try:
            # Expand group IDs via nested group walk
            all_group_ids = self._get_all_group_ids_for_user(user_id)

            # Get direct user memberships for the rbac_groups response
            memberships = (
                self.db.query(GroupMember)
                .options(joinedload(GroupMember.group))
                .filter(
                    GroupMember.user_id == user_id,
                    GroupMember.member_type == MemberType.USER.value,
                )
                .all()
            )

            rbac_groups = []
            for membership in memberships:
                group = membership.group
                rbac_groups.append(GroupMemberResponse(
                    id=membership.id,
                    user_id=membership.user_id,
                    group_id=membership.group_id,
                    group_name=group.name if group else None,
                    is_global_group=group.is_global if group else False,
                    created_at=membership.created_at,
                    updated_at=membership.updated_at,
                    created_by=membership.created_by,
                ))

            # Get permissions from ALL groups (direct + inherited via nesting)
            inherited_permissions = []
            if all_group_ids:
                perms = (
                    self.db.query(GroupPermission)
                    .options(
                        joinedload(GroupPermission.role),
                        joinedload(GroupPermission.entity),
                    )
                    .filter(GroupPermission.group_id.in_(all_group_ids))
                    .all()
                )

                for perm in perms:
                    inherited_permissions.append(GroupPermissionResponse(
                        id=perm.id,
                        group_id=perm.group_id,
                        entity_id=perm.entity_id,
                        entity_name=perm.entity.name if perm.entity else None,
                        role_id=perm.role_id,
                        role_name=perm.role.name if perm.role else None,
                        is_global_permission=perm.entity_id is None,
                        created_at=perm.created_at,
                        created_by=perm.created_by,
                    ))

            return EffectiveRoleResponse(
                user_id=user_id,
                inherited_permissions=inherited_permissions,
                rbac_groups=rbac_groups,
            )
        except Exception as e:
            _log_rbac_error("get_effective_user_roles", {"user_id": user_id}, e)
            raise RuntimeError("Failed to get effective roles") from e
