"""
Relationship Graph service.

A graph is a named bundle of relationships. Nodes are auto-derived from the
endpoints of the selected relationships. Each graph deploys to its own LakeGraph
graph_config (see LakeGraphService, keyed by graph_id).
"""

from typing import List, Optional

from fastapi import HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from lakefusion_utility.models.relationship import (
    Relationship,
    RelationshipGraph,
    RelationshipGraphMember,
    RelationshipGraphCreate,
    RelationshipGraphUpdate,
    RelationshipGraphResponse,
    GraphRelationshipSummary,
    GraphNodeSummary,
    LakeGraphDeployment,
    LakeGraphDeploymentResponse,
)
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from lakefusion_utility.utils.logging_utils import get_logger


app_logger = get_logger(__name__)
FEATURE_FLAG_NAME = "ENABLE_RELATIONSHIPS"


def _assert_feature_enabled(db: Session) -> None:
    if not FeatureFlagService._is_feature_flag_enabled(db, FEATURE_FLAG_NAME):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Feature flag '{FEATURE_FLAG_NAME}' is not active.",
        )


def _slug(s: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in (s or "").lower()).strip("_")


class RelationshipGraphService:
    def __init__(self, db: Session):
        self.db = db

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _unique_slug(self, name: str, exclude_id: Optional[int] = None) -> str:
        base = _slug(name) or "graph"
        candidate = base
        n = 1
        while True:
            q = self.db.query(RelationshipGraph).filter(
                RelationshipGraph.slug == candidate
            )
            if exclude_id is not None:
                q = q.filter(RelationshipGraph.id != exclude_id)
            if not q.first():
                return candidate
            n += 1
            candidate = f"{base}_{n}"

    def _validate_relationship_ids(self, rel_ids: List[int]) -> None:
        if not rel_ids:
            return
        found = {
            r.id
            for r in self.db.query(Relationship.id)
            .filter(Relationship.id.in_(rel_ids))
            .all()
        }
        missing = set(rel_ids) - found
        if missing:
            raise HTTPException(
                status_code=400,
                detail=f"Relationship(s) not found: {sorted(missing)}",
            )

    def _set_members(self, graph: RelationshipGraph, rel_ids: List[int]) -> None:
        # Replace the member set. De-dup while preserving intent.
        seen = set()
        graph.members = []
        for rid in rel_ids:
            if rid in seen:
                continue
            seen.add(rid)
            graph.members.append(RelationshipGraphMember(relationship_id=rid))

    def _to_response(self, graph: RelationshipGraph) -> RelationshipGraphResponse:
        rel_ids = [m.relationship_id for m in (graph.members or [])]
        rels: List[Relationship] = []
        if rel_ids:
            rels = (
                self.db.query(Relationship)
                .options(
                    joinedload(Relationship.source_entity),
                    joinedload(Relationship.target_entity),
                )
                .filter(Relationship.id.in_(rel_ids))
                .all()
            )

        rel_summaries: List[GraphRelationshipSummary] = []
        node_map = {}  # entity_id -> name
        for r in rels:
            src_name = r.source_entity.name if r.source_entity else None
            dst_name = r.target_entity.name if r.target_entity else None
            rel_summaries.append(
                GraphRelationshipSummary(
                    id=r.id,
                    name=r.name,
                    label_forward=r.label_forward,
                    cardinality=r.cardinality,
                    source_entity_id=r.source_entity_id,
                    target_entity_id=r.target_entity_id,
                    source_entity_name=src_name,
                    target_entity_name=dst_name,
                )
            )
            if r.source_entity_id is not None:
                node_map[r.source_entity_id] = src_name or f"#{r.source_entity_id}"
            if r.target_entity_id is not None:
                node_map[r.target_entity_id] = dst_name or f"#{r.target_entity_id}"

        nodes = [
            GraphNodeSummary(entity_id=eid, entity_name=name)
            for eid, name in sorted(node_map.items(), key=lambda kv: kv[1] or "")
        ]

        deployment = None
        dep_row = (
            self.db.query(LakeGraphDeployment)
            .filter(LakeGraphDeployment.graph_id == graph.id)
            .first()
        )
        if dep_row:
            deployment = LakeGraphDeploymentResponse.model_validate(dep_row)

        return RelationshipGraphResponse(
            id=graph.id,
            name=graph.name,
            slug=graph.slug,
            description=graph.description,
            output_schema=graph.output_schema,
            is_active=graph.is_active,
            created_by=graph.created_by,
            created_at=graph.created_at,
            updated_at=graph.updated_at,
            relationship_ids=rel_ids,
            relationships=rel_summaries,
            nodes=nodes,
            node_count=len(nodes),
            edge_count=len(rel_summaries),
            deployment=deployment,
        )

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def create(self, payload: RelationshipGraphCreate) -> RelationshipGraphResponse:
        _assert_feature_enabled(self.db)
        self._validate_relationship_ids(payload.relationship_ids)
        try:
            graph = RelationshipGraph(
                name=payload.name.strip(),
                slug=self._unique_slug(payload.name),
                description=payload.description,
                output_schema=payload.output_schema,
                created_by=payload.created_by or "",
                is_active=True,
            )
            self._set_members(graph, payload.relationship_ids)
            self.db.add(graph)
            db_commit_auto_rollback(self.db)
            self.db.refresh(graph)
            return self._to_response(graph)
        except IntegrityError:
            self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"A graph named '{payload.name}' already exists.",
            )

    def read_all(self, is_active: bool = True) -> List[RelationshipGraphResponse]:
        _assert_feature_enabled(self.db)
        rows = (
            self.db.query(RelationshipGraph)
            .filter(RelationshipGraph.is_active == is_active)
            .order_by(RelationshipGraph.created_at.desc())
            .all()
        )
        return [self._to_response(g) for g in rows]

    def read_by_id(self, graph_id: int) -> RelationshipGraph:
        g = (
            self.db.query(RelationshipGraph)
            .filter(RelationshipGraph.id == graph_id)
            .first()
        )
        if not g:
            raise HTTPException(status_code=404, detail=f"Graph {graph_id} not found.")
        return g

    def get(self, graph_id: int) -> RelationshipGraphResponse:
        _assert_feature_enabled(self.db)
        return self._to_response(self.read_by_id(graph_id))

    def update(
        self, graph_id: int, payload: RelationshipGraphUpdate
    ) -> RelationshipGraphResponse:
        _assert_feature_enabled(self.db)
        graph = self.read_by_id(graph_id)
        data = payload.dict(exclude_unset=True)
        if "name" in data and data["name"] is not None:
            graph.name = data["name"].strip()
            graph.slug = self._unique_slug(graph.name, exclude_id=graph.id)
        if "description" in data:
            graph.description = data["description"]
        if "output_schema" in data:
            graph.output_schema = data["output_schema"]
        if "is_active" in data and data["is_active"] is not None:
            graph.is_active = data["is_active"]
        if "relationship_ids" in data and data["relationship_ids"] is not None:
            self._validate_relationship_ids(data["relationship_ids"])
            self._set_members(graph, data["relationship_ids"])
        db_commit_auto_rollback(self.db)
        self.db.refresh(graph)
        return self._to_response(graph)

    def delete(self, graph_id: int) -> dict:
        _assert_feature_enabled(self.db)
        graph = self.read_by_id(graph_id)
        # Drop the deployment-state row too (members cascade via the relationship).
        self.db.query(LakeGraphDeployment).filter(
            LakeGraphDeployment.graph_id == graph_id
        ).delete(synchronize_session=False)
        self.db.delete(graph)
        db_commit_auto_rollback(self.db)
        return {"status": "success", "message": f"Graph {graph_id} deleted."}
