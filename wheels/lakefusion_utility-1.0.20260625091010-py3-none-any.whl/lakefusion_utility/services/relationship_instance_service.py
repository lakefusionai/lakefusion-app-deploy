"""
Relationship Instance service (Story 3 — Steward surface).

Reads materialized rows from ``{rel}_edges`` Delta tables via the Databricks
SQL warehouse and exposes:

- list edges for an entity record (Relationships tab on entity profile)
- per-source lineage for a single edge (lineage drawer)
- write steward overrides (Postgres audit + immediate MERGE on the edge)

Everything is gated by ``ENABLE_RELATIONSHIPS``.
"""

from typing import Any, Dict, List, Optional

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.models.entity import Entity, EntityType
from lakefusion_utility.models.relationship import (
    LineageRow,
    Relationship,
    RelationshipInstance,
    RelationshipStatus,
    RelationshipStewardOverride,
    StewardOverrideCreate,
    StewardOverrideResponse,
)
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from lakefusion_utility.utils.databricks_util import DataSetSQLService
from lakefusion_utility.utils.logging_utils import get_logger


app_logger = get_logger(__name__)

FEATURE_FLAG_NAME = "ENABLE_RELATIONSHIPS"

# Mandatory + built-in columns we always select from {rel}_edges.
_BUILTIN_COLUMNS = [
    "src_node_id",
    "dst_node_id",
    "src_node_type",
    "dst_node_type",
    "edge_type",
    "start_date",
    "end_date",
    "status",
    "contributing_sources",
    "origin",
]


def _assert_feature_enabled(db: Session) -> None:
    if not FeatureFlagService._is_feature_flag_enabled(db, FEATURE_FLAG_NAME):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                f"Feature flag '{FEATURE_FLAG_NAME}' is not active. Relationships are disabled."
            ),
        )


def _catalog_name(db: Session) -> str:
    row = (
        db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == "catalog_name")
        .first()
    )
    if not row:
        raise HTTPException(status_code=500, detail="catalog_name not configured.")
    return row.config_value


def _edges_table(catalog: str, relationship_name: str, experiment_id: str = "prod") -> str:
    base = f"{catalog}.gold.{relationship_name}_edges"
    if experiment_id:
        base += f"_{experiment_id}"
    return base


class RelationshipInstanceService:
    def __init__(self, db: Session):
        self.db = db

    # ------------------------------------------------------------------
    # Read APIs
    # ------------------------------------------------------------------

    def _query(self, token: str, warehouse_id: str, sql: str) -> List[Dict[str, Any]]:
        """Run a SELECT and return list-of-dicts. ``DataSetSQLService.execute_dataset``
        closes its underlying connection in a finally block, so we instantiate
        a fresh service per call instead of reusing one across queries."""
        svc = DataSetSQLService(token, warehouse_id)
        return svc.execute_dataset(sql)

    def _resolve_display_names(
        self,
        out: List[RelationshipInstance],
        token: str,
        warehouse_id: str,
    ) -> None:
        """For every distinct (entity_id, lakefusion_id) pair in `out`, bulk-fetch
        a human-readable display name from `{entity_name}_master_prod`.

        Uses the `is_label`-flagged attribute as the name column. Falls back to
        the first active attribute if no label is set. Failures are swallowed —
        display name stays None and the UI just shows the lakefusion_id.
        """
        if not out:
            return

        catalog = _catalog_name(self.db)

        # Group ids by entity_id.
        ids_by_entity: Dict[int, set] = {}
        for inst in out:
            if inst.src_entity_id and inst.src_node_id:
                ids_by_entity.setdefault(inst.src_entity_id, set()).add(inst.src_node_id)
            if inst.dst_entity_id and inst.dst_node_id:
                ids_by_entity.setdefault(inst.dst_entity_id, set()).add(inst.dst_node_id)

        # entity_id -> dict(lakefusion_id -> display_name)
        name_lookup: Dict[int, Dict[str, str]] = {}

        for entity_id, id_set in ids_by_entity.items():
            entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
            if not entity:
                continue
            # Pick label attribute. Fall back to first active attribute.
            label_attr = next(
                (a for a in (entity.attributes or []) if a.is_active and a.is_label),
                None,
            )
            if not label_attr:
                label_attr = next(
                    (a for a in (entity.attributes or []) if a.is_active),
                    None,
                )
            if not label_attr:
                continue

            entity_slug = (entity.name or "").lower().replace(" ", "_")
            table = f"{catalog}.gold.{entity_slug}_master_prod"

            # IN clause; escape single quotes defensively.
            escaped = [f"'{i.replace(chr(39), chr(39)*2)}'" for i in id_set]
            id_list = ", ".join(escaped)
            sql = (
                f"SELECT lakefusion_id, `{label_attr.name}` AS display_name "
                f"FROM {table} WHERE lakefusion_id IN ({id_list})"
            )
            try:
                rows = self._query(token, warehouse_id, sql)
            except Exception as e:  # noqa: BLE001
                app_logger.warning(
                    f"display-name lookup failed for entity {entity.name}: "
                    f"{type(e).__name__}: {e}"
                )
                continue
            name_lookup[entity_id] = {
                str(r.get("lakefusion_id")): (
                    str(r.get("display_name")) if r.get("display_name") is not None else None
                )
                for r in rows
            }

        # Patch each instance.
        for inst in out:
            if inst.src_entity_id and inst.src_entity_id in name_lookup:
                inst.src_display_name = name_lookup[inst.src_entity_id].get(inst.src_node_id)
            if inst.dst_entity_id and inst.dst_entity_id in name_lookup:
                inst.dst_display_name = name_lookup[inst.dst_entity_id].get(inst.dst_node_id)

    def list_instances_for_entity(
        self,
        entity_id: int,
        master_id: str,
        token: str,
        warehouse_id: str,
    ) -> List[RelationshipInstance]:
        """Return every active edge where this master_id appears as src or dst,
        across every relationship that references this entity."""
        _assert_feature_enabled(self.db)

        entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
        if not entity:
            raise HTTPException(status_code=404, detail="Entity not found")

        # Single gate: `is_active`. The legacy `status` column is kept in the
        # schema for back-compat but no longer filters reads.
        relationships = (
            self.db.query(Relationship)
            .filter(
                Relationship.is_active == True,  # noqa: E712
                (Relationship.source_entity_id == entity_id)
                | (Relationship.target_entity_id == entity_id),
            )
            .all()
        )
        if not relationships:
            return []

        catalog = _catalog_name(self.db)

        out: List[RelationshipInstance] = []
        for rel in relationships:
            table = _edges_table(catalog, rel.name)
            attr_cols = [f"`{a.name}`" for a in (rel.attributes or [])]
            select_cols = ", ".join(_BUILTIN_COLUMNS + attr_cols)

            # Safe interpolation: master_id is sourced from path; we still
            # escape single quotes to defend against malformed input.
            safe_master = master_id.replace("'", "''")
            query = f"""
                SELECT {select_cols}
                FROM {table}
                WHERE (src_node_id = '{safe_master}' OR dst_node_id = '{safe_master}')
                  AND (status IS NULL OR status != 'inactive')
                LIMIT 500
            """
            try:
                # Fresh service per query — execute_dataset closes the
                # underlying connection internally.
                rows = self._query(token, warehouse_id, query)
            except Exception as e:  # noqa: BLE001
                # Table may not exist yet (no Story 2 run has occurred).
                app_logger.warning(
                    f"Skipping {table}: {type(e).__name__}: {e}"
                )
                continue

            # Active steward overrides for this (rel, master_id).
            overrides = (
                self.db.query(RelationshipStewardOverride)
                .filter(
                    RelationshipStewardOverride.relationship_id == rel.id,
                    RelationshipStewardOverride.is_active == True,  # noqa: E712
                    (RelationshipStewardOverride.src_node_id == master_id)
                    | (RelationshipStewardOverride.dst_node_id == master_id),
                )
                .all()
            )
            override_keys = {
                (o.src_node_id, o.dst_node_id) for o in overrides
            }

            for row in rows:
                attrs = {
                    k: v
                    for k, v in row.items()
                    if k not in _BUILTIN_COLUMNS
                }
                out.append(
                    RelationshipInstance(
                        relationship_id=rel.id,
                        relationship_name=rel.name,
                        label_forward=rel.label_forward,
                        label_reverse=rel.label_reverse,
                        is_bidirectional=rel.is_bidirectional,
                        cardinality=rel.cardinality,
                        src_node_id=str(row.get("src_node_id") or ""),
                        dst_node_id=str(row.get("dst_node_id") or ""),
                        src_node_type=str(row.get("src_node_type") or ""),
                        dst_node_type=str(row.get("dst_node_type") or ""),
                        src_entity_id=rel.source_entity_id,
                        dst_entity_id=rel.target_entity_id,
                        edge_type=str(row.get("edge_type") or rel.name),
                        start_date=(
                            str(row.get("start_date")) if row.get("start_date") else None
                        ),
                        end_date=(
                            str(row.get("end_date")) if row.get("end_date") else None
                        ),
                        status=row.get("status"),
                        contributing_sources=list(
                            row.get("contributing_sources") or []
                        ),
                        origin=row.get("origin"),
                        attributes=attrs,
                        is_overridden=(
                            row.get("origin") == "manual"
                            or (
                                str(row.get("src_node_id") or ""),
                                str(row.get("dst_node_id") or ""),
                            )
                            in override_keys
                        ),
                    )
                )

        # Bulk-resolve display names for every endpoint involved. One query
        # per participating entity.
        self._resolve_display_names(out, token, warehouse_id)

        return out

    def get_lineage(
        self,
        relationship_id: int,
        src_node_id: str,
        dst_node_id: str,
        token: str,
        warehouse_id: str,
    ) -> List[LineageRow]:
        """Return per-source claims plus any DLQ rows for a single edge.

        Currently this reads only the DLQ. Per-source successful claims are
        encoded in ``contributing_sources``; we'll surface them later by
        querying the underlying source datasets directly. For now the DLQ is
        the actionable per-source view (failures + cardinality losers).
        """
        _assert_feature_enabled(self.db)
        rel = self.db.query(Relationship).filter(Relationship.id == relationship_id).first()
        if not rel:
            raise HTTPException(status_code=404, detail="Relationship not found")

        catalog = _catalog_name(self.db)
        dlq_table = f"{catalog}.gold.{rel.name}_edges_dlq_prod"
        # Production uses experiment_id "prod" by convention.

        safe_src = src_node_id.replace("'", "''")
        safe_dst = dst_node_id.replace("'", "''")

        sql_service = DataSetSQLService(token, warehouse_id)
        try:
            query = f"""
                SELECT source_system, src_source_pk, dst_source_pk,
                       raw_payload, ingested_at, failure_reason, failure_detail
                FROM {dlq_table}
                WHERE src_node_id = '{safe_src}'
                  AND dst_node_id = '{safe_dst}'
                  AND edge_type = '{rel.name}'
                ORDER BY ingested_at DESC
                LIMIT 100
            """
            try:
                rows = sql_service.execute_dataset(query)
            except Exception as e:  # noqa: BLE001
                app_logger.warning(
                    f"DLQ table {dlq_table} unavailable: {type(e).__name__}: {e}"
                )
                rows = []
        finally:
            try:
                sql_service.connection.close()
            except Exception:
                pass

        return [
            LineageRow(
                source_system=str(r.get("source_system") or ""),
                src_source_pk=r.get("src_source_pk"),
                dst_source_pk=r.get("dst_source_pk"),
                raw_payload=r.get("raw_payload"),
                ingested_at=str(r.get("ingested_at")) if r.get("ingested_at") else None,
                failure_reason=r.get("failure_reason"),
                failure_detail=r.get("failure_detail"),
            )
            for r in rows
        ]

    # ------------------------------------------------------------------
    # Override (write)
    # ------------------------------------------------------------------

    def create_override(
        self,
        relationship_id: int,
        payload: StewardOverrideCreate,
        token: str,
        warehouse_id: str,
        steward_id: str,
    ) -> StewardOverrideResponse:
        _assert_feature_enabled(self.db)
        rel = self.db.query(Relationship).filter(Relationship.id == relationship_id).first()
        if not rel:
            raise HTTPException(status_code=404, detail="Relationship not found")

        if payload.attribute_name != "__row__":
            attr_names = {a.name for a in (rel.attributes or [])}
            if payload.attribute_name not in attr_names:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"attribute_name '{payload.attribute_name}' is not defined on "
                        f"relationship '{rel.name}'."
                    ),
                )

        # Soft-delete any prior active override on the same key (audit history).
        prior = (
            self.db.query(RelationshipStewardOverride)
            .filter(
                RelationshipStewardOverride.relationship_id == relationship_id,
                RelationshipStewardOverride.src_node_id == payload.src_node_id,
                RelationshipStewardOverride.dst_node_id == payload.dst_node_id,
                RelationshipStewardOverride.attribute_name == payload.attribute_name,
                RelationshipStewardOverride.is_active == True,  # noqa: E712
            )
            .all()
        )
        for p in prior:
            p.is_active = False

        record = RelationshipStewardOverride(
            relationship_id=relationship_id,
            src_node_id=payload.src_node_id,
            dst_node_id=payload.dst_node_id,
            attribute_name=payload.attribute_name,
            override_action=payload.override_action,
            override_value=payload.override_value,
            reason=payload.reason,
            steward_id=steward_id or payload.steward_id or "",
        )
        self.db.add(record)
        db_commit_auto_rollback(self.db)
        self.db.refresh(record)

        # Apply to {rel}_edges immediately via MERGE so steward sees change now.
        try:
            self._apply_override_to_edges(rel, record, token, warehouse_id)
        except Exception as e:  # noqa: BLE001
            # Override row is persisted; pipeline will reconcile on next run.
            app_logger.warning(
                f"Could not apply override immediately ({type(e).__name__}: {e}). "
                "Pipeline will reconcile on the next sync."
            )

        return StewardOverrideResponse.model_validate(record)

    def _apply_override_to_edges(
        self,
        rel: Relationship,
        override: RelationshipStewardOverride,
        token: str,
        warehouse_id: str,
    ) -> None:
        """MERGE the override into the production edges Delta table now."""
        catalog = _catalog_name(self.db)
        table = _edges_table(catalog, rel.name)

        safe_src = override.src_node_id.replace("'", "''")
        safe_dst = override.dst_node_id.replace("'", "''")
        # Entity names are user-created and may contain single quotes (e.g.
        # "O'Brien Corp"). Escape before interpolating into the MERGE literals.
        safe_src_type = str(rel.source_entity_name or rel.source_entity_id).replace("'", "''")
        safe_dst_type = str(rel.target_entity_name or rel.target_entity_id).replace("'", "''")

        sql_service = DataSetSQLService(token, warehouse_id)
        try:
            if override.attribute_name == "__row__":
                if override.override_action == "unlink":
                    query = (
                        f"UPDATE {table} SET status = 'inactive', origin = 'manual', "
                        "updated_at = current_timestamp() "
                        f"WHERE src_node_id = '{safe_src}' AND dst_node_id = '{safe_dst}' "
                        f"AND edge_type = '{rel.name}'"
                    )
                elif override.override_action == "reactivate":
                    query = (
                        f"UPDATE {table} SET status = 'active', origin = 'manual', "
                        "updated_at = current_timestamp() "
                        f"WHERE src_node_id = '{safe_src}' AND dst_node_id = '{safe_dst}' "
                        f"AND edge_type = '{rel.name}'"
                    )
                elif override.override_action == "relink":
                    # Insert a new active edge. Caller handles the case where
                    # one doesn't exist (UPSERT semantics).
                    query = (
                        f"MERGE INTO {table} t USING ("
                        f"SELECT '{safe_src}' AS src_node_id, '{safe_dst}' AS dst_node_id, "
                        f"'{safe_src_type}' AS src_node_type, "
                        f"'{safe_dst_type}' AS dst_node_type, "
                        f"'{rel.name}' AS edge_type"
                        ") s ON t.src_node_id = s.src_node_id AND t.dst_node_id = s.dst_node_id "
                        "AND t.edge_type = s.edge_type "
                        "WHEN MATCHED THEN UPDATE SET t.status = 'active', t.origin = 'manual', "
                        "t.updated_at = current_timestamp() "
                        "WHEN NOT MATCHED THEN INSERT (src_node_id, dst_node_id, src_node_type, "
                        "dst_node_type, edge_type, status, origin, created_at, updated_at, "
                        "created_by, updated_by) VALUES (s.src_node_id, s.dst_node_id, "
                        "s.src_node_type, s.dst_node_type, s.edge_type, 'active', 'manual', "
                        "current_timestamp(), current_timestamp(), 'steward', 'steward')"
                    )
                else:
                    return
            else:
                # Per-attribute override on free-text user input.
                # Databricks SQL string literals don't process backslash escapes
                # (escapedStringLiterals defaults to false) and the connector runs
                # a single statement, so doubling single quotes fully neutralises
                # literal-breakout for the value. Positional bind markers aren't
                # reliably supported for UPDATE/MERGE on the SQL-warehouse
                # connector, so we escape + bound length + sanitise the column
                # identifier as defense-in-depth.
                val = override.override_value
                if val is not None and len(str(val)) > 100_000:
                    raise HTTPException(
                        status_code=400,
                        detail="override_value exceeds the 100000-character limit.",
                    )
                if val is None:
                    val_sql = "NULL"
                else:
                    val_sql = "'" + str(val).replace("'", "''") + "'"
                # Backtick-quoted identifier — strip backticks so it can't be
                # broken out of.
                col = str(override.attribute_name).replace("`", "")
                query = (
                    f"UPDATE {table} "
                    f"SET `{col}` = {val_sql}, origin = 'manual', "
                    "updated_at = current_timestamp() "
                    f"WHERE src_node_id = '{safe_src}' AND dst_node_id = '{safe_dst}' "
                    f"AND edge_type = '{rel.name}'"
                )
            sql_service.execute_merge_query(query)
        finally:
            try:
                sql_service.connection.close()
            except Exception:
                pass

    def list_overrides(
        self, relationship_id: int, master_id: Optional[str] = None
    ) -> List[StewardOverrideResponse]:
        _assert_feature_enabled(self.db)
        q = self.db.query(RelationshipStewardOverride).filter(
            RelationshipStewardOverride.relationship_id == relationship_id,
            RelationshipStewardOverride.is_active == True,  # noqa: E712
        )
        if master_id:
            q = q.filter(
                (RelationshipStewardOverride.src_node_id == master_id)
                | (RelationshipStewardOverride.dst_node_id == master_id)
            )
        rows = q.order_by(RelationshipStewardOverride.created_at.desc()).all()
        return [StewardOverrideResponse.model_validate(r) for r in rows]
