"""
Relationship service (Story 1 — configuration foundation).

Implements CRUD for Relationship definitions, their attribute schema, and their
per-dataset source mappings. Enforces the eligibility gate: both endpoints must
be Master entities with an active Integration Hub job and an existing
{entity_name}_master_prod table in Unity Catalog.

All persistence goes through SQLAlchemy generic types so the code runs on
MySQL, PostgreSQL, and Databricks Lakebase identically.
"""

from typing import List, Optional, Tuple

from sqlalchemy import and_, or_, func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload
from fastapi import HTTPException, status

from lakefusion_utility.models.entity import Entity, EntityType
from lakefusion_utility.models.dataset import Dataset
from lakefusion_utility.models.integration_hub import Integration_Hub
from lakefusion_utility.models.relationship import (
    Relationship,
    RelationshipAttribute,
    RelationshipDatasetMapping,
    RelationshipCreate,
    RelationshipUpdate,
    RelationshipAttributeCreate,
    RelationshipAttributeResponse,
    RelationshipDatasetMappingCreate,
    RelationshipDatasetMappingResponse,
    RelationshipResponse,
    EligibleEntity,
    Cardinality,
    RelationshipStatus,
    ALLOWED_DATA_TYPES,
)
from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.utils.app_db import db_commit_auto_rollback
from lakefusion_utility.utils.databricks_util import CatalogService
from lakefusion_utility.utils.logging_utils import get_logger


app_logger = get_logger(__name__)

FEATURE_FLAG_NAME = "ENABLE_RELATIONSHIPS"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _assert_feature_enabled(db: Session) -> None:
    if not FeatureFlagService._is_feature_flag_enabled(db, FEATURE_FLAG_NAME):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                f"Feature flag '{FEATURE_FLAG_NAME}' is not active. "
                "Relationships are disabled."
            ),
        )


def _normalize_entity_name(name: str) -> str:
    return (name or "").lower().replace(" ", "_")


def _entity_has_active_integration_hub(db: Session, entity_id: int) -> bool:
    row = (
        db.query(Integration_Hub)
        .filter(
            Integration_Hub.entity_id == entity_id,
            Integration_Hub.is_active == True,  # noqa: E712 (portable boolean)
        )
        .first()
    )
    if not row:
        return False
    # We require at least one Databricks job id to be present.
    return bool(row.job_id_1) or bool(row.job_id_2)


def _master_prod_table_exists(catalog: CatalogService, entity_name: str) -> bool:
    normalized = _normalize_entity_name(entity_name)
    try:
        return bool(catalog.check_table_exists(f"{normalized}_master_prod"))
    except Exception as e:  # pragma: no cover — surfaced upstream
        app_logger.warning(
            f"check_table_exists failed for {normalized}_master_prod: {type(e).__name__}: {e}"
        )
        return False


def _to_response(rel: Relationship) -> RelationshipResponse:
    attrs = [
        RelationshipAttributeResponse.model_validate(a) for a in (rel.attributes or [])
    ]
    mappings: List[RelationshipDatasetMappingResponse] = []
    for m in rel.dataset_mappings or []:
        ds_name = m.dataset.name if getattr(m, "dataset", None) else None
        ds_path = m.dataset.path if getattr(m, "dataset", None) else None
        mappings.append(
            RelationshipDatasetMappingResponse(
                id=m.id,
                relationship_id=m.relationship_id,
                dataset_id=m.dataset_id,
                source_pk_column=m.source_pk_column,
                target_pk_column=m.target_pk_column,
                start_date_column=m.start_date_column,
                end_date_column=m.end_date_column,
                status_column=m.status_column,
                source_system_tag=m.source_system_tag,
                priority=m.priority,
                attribute_mappings=m.attribute_mappings or [],
                created_by=m.created_by,
                created_at=m.created_at,
                updated_at=m.updated_at,
                is_active=m.is_active,
                dataset_name=ds_name,
                dataset_path=ds_path,
            )
        )
    return RelationshipResponse(
        id=rel.id,
        name=rel.name,
        label_forward=rel.label_forward,
        label_reverse=rel.label_reverse,
        source_entity_id=rel.source_entity_id,
        target_entity_id=rel.target_entity_id,
        source_entity_name=rel.source_entity.name if rel.source_entity else None,
        target_entity_name=rel.target_entity.name if rel.target_entity else None,
        source_entity_color_code=rel.source_entity.color_code if rel.source_entity else None,
        target_entity_color_code=rel.target_entity.color_code if rel.target_entity else None,
        cardinality=rel.cardinality,
        is_bidirectional=rel.is_bidirectional,
        description=rel.description,
        status=rel.status,
        developer_group_id=rel.developer_group_id,
        steward_group_id=rel.steward_group_id,
        created_by=rel.created_by,
        created_at=rel.created_at,
        updated_at=rel.updated_at,
        is_active=rel.is_active,
        attributes=attrs,
        dataset_mappings=mappings,
    )


# ---------------------------------------------------------------------------
# RelationshipService
# ---------------------------------------------------------------------------

class RelationshipService:
    """Backbone CRUD for the Relationship entity itself."""

    def __init__(self, db: Session):
        self.db = db

    # ---- eligibility ---------------------------------------------------

    def list_eligible_entities(self, token: str) -> List[EligibleEntity]:
        """Return Master entities annotated with eligibility flags.

        The dropdown on the Designer surface uses this so the user always sees the
        full master list but ineligible rows render disabled with a reason.
        """
        _assert_feature_enabled(self.db)
        catalog = CatalogService(token, self.db)

        results: List[EligibleEntity] = []
        rows = (
            self.db.query(Entity)
            .filter(
                Entity.is_active == True,  # noqa: E712
                Entity.entity_type == EntityType.MASTER.value,
            )
            .order_by(Entity.name.asc())
            .all()
        )
        for e in rows:
            has_inthub = _entity_has_active_integration_hub(self.db, e.id)
            has_table = _master_prod_table_exists(catalog, e.name) if has_inthub else False
            eligible = has_inthub and has_table
            reason: Optional[str] = None
            if not has_inthub:
                reason = "No active Integration Hub job"
            elif not has_table:
                reason = f"Master table '{_normalize_entity_name(e.name)}_master_prod' not found"
            results.append(
                EligibleEntity(
                    id=e.id,
                    name=e.name,
                    entity_type=e.entity_type,
                    path=e.path,
                    has_active_integration_hub=has_inthub,
                    has_master_prod_table=has_table,
                    eligible=eligible,
                    reason=reason,
                    color_code=e.color_code,
                )
            )
        return results

    def _assert_endpoint_eligible(
        self, token: str, entity_id: int, role: str
    ) -> Entity:
        """Re-run the gate at write time so the UI can't bypass via stale state."""
        e = self.db.query(Entity).filter(Entity.id == entity_id).first()
        if not e or not e.is_active:
            raise HTTPException(
                status_code=400,
                detail=f"{role} entity {entity_id} not found or inactive.",
            )
        if e.entity_type != EntityType.MASTER.value:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"{role} entity '{e.name}' is not a Master entity. Only Master "
                    "entities can be relationship endpoints."
                ),
            )
        if not _entity_has_active_integration_hub(self.db, e.id):
            raise HTTPException(
                status_code=400,
                detail=(
                    f"{role} entity '{e.name}' has no active Integration Hub job. "
                    "Create one first."
                ),
            )
        catalog = CatalogService(token, self.db)
        if not _master_prod_table_exists(catalog, e.name):
            raise HTTPException(
                status_code=400,
                detail=(
                    f"{role} entity '{e.name}' is missing its "
                    f"'{_normalize_entity_name(e.name)}_master_prod' table. Run the "
                    "Integration Hub job at least once before creating relationships."
                ),
            )
        return e

    def _assert_no_duplicate_pair(self, payload: RelationshipCreate) -> None:
        """Reject duplicates on (src, tgt, name) and reject bidirectional reverse dupes."""
        s, t = payload.source_entity_id, payload.target_entity_id
        if payload.is_bidirectional:
            low, high = min(s, t), max(s, t)
            existing = (
                self.db.query(Relationship)
                .filter(
                    Relationship.is_active == True,  # noqa: E712
                    Relationship.name == payload.name,
                    Relationship.is_bidirectional == True,  # noqa: E712
                    or_(
                        and_(
                            Relationship.source_entity_id == low,
                            Relationship.target_entity_id == high,
                        ),
                        and_(
                            Relationship.source_entity_id == high,
                            Relationship.target_entity_id == low,
                        ),
                    ),
                )
                .first()
            )
        else:
            existing = (
                self.db.query(Relationship)
                .filter(
                    Relationship.is_active == True,  # noqa: E712
                    Relationship.name == payload.name,
                    Relationship.source_entity_id == s,
                    Relationship.target_entity_id == t,
                )
                .first()
            )
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    f"A relationship with name '{payload.name}' already exists between "
                    "these entities."
                ),
            )

    # ---- CRUD ----------------------------------------------------------

    def create_relationship(
        self, payload: RelationshipCreate, token: str
    ) -> RelationshipResponse:
        _assert_feature_enabled(self.db)

        # Field-level validations the Pydantic layer can't enforce together.
        if payload.is_bidirectional:
            if not payload.label_reverse or not payload.label_reverse.strip():
                raise HTTPException(
                    status_code=400,
                    detail="label_reverse is required when is_bidirectional is true.",
                )
            if payload.label_reverse.strip().lower() == payload.label_forward.strip().lower():
                raise HTTPException(
                    status_code=400,
                    detail="label_reverse must differ from label_forward.",
                )

        if payload.source_entity_id == payload.target_entity_id:
            if payload.cardinality not in (
                Cardinality.ONE_TO_MANY.value,
                Cardinality.MANY_TO_ONE.value,
                Cardinality.MANY_TO_MANY.value,
            ):
                raise HTTPException(
                    status_code=400,
                    detail=(
                        "Self-referential relationships are only allowed with "
                        "cardinality 1:N, N:1 or N:N."
                    ),
                )
            if not payload.confirm_self_reference:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        "Self-referential relationship requires explicit "
                        "confirm_self_reference=true."
                    ),
                )

        self._assert_endpoint_eligible(token, payload.source_entity_id, "Source")
        self._assert_endpoint_eligible(token, payload.target_entity_id, "Target")
        self._assert_no_duplicate_pair(payload)

        try:
            # Lifecycle `status` is internal — we always seed new relationships
            # as ACTIVE so the single `is_active` toggle in the UI maps 1:1 to
            # what the pipeline gates on.
            rel = Relationship(
                name=payload.name,
                label_forward=payload.label_forward.strip(),
                label_reverse=(payload.label_reverse.strip() if payload.label_reverse else None),
                source_entity_id=payload.source_entity_id,
                target_entity_id=payload.target_entity_id,
                cardinality=payload.cardinality,
                is_bidirectional=bool(payload.is_bidirectional),
                description=payload.description,
                developer_group_id=payload.developer_group_id,
                steward_group_id=payload.steward_group_id,
                created_by=payload.created_by or "",
                status=RelationshipStatus.ACTIVE.value,
            )
            self.db.add(rel)
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(rel)
            return _to_response(rel)
        except IntegrityError as e:
            self.db.rollback()
            app_logger.exception("Integrity error creating relationship")
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Relationship name already exists.",
            )
        except HTTPException:
            raise
        except Exception:
            self.db.rollback()
            app_logger.exception("Unable to create relationship")
            raise HTTPException(status_code=500, detail="Failed to create relationship")

    def list_relationships(
        self,
        is_active: Optional[bool] = None,
        status_filter: Optional[str] = None,
        entity_id: Optional[int] = None,
        q: Optional[str] = None,
    ) -> List[RelationshipResponse]:
        _assert_feature_enabled(self.db)
        query = self.db.query(Relationship).options(
            joinedload(Relationship.attributes),
            joinedload(Relationship.dataset_mappings).joinedload(
                RelationshipDatasetMapping.relationship_def
            ),
            joinedload(Relationship.source_entity),
            joinedload(Relationship.target_entity),
        )
        if is_active is not None:
            query = query.filter(Relationship.is_active == is_active)
        if status_filter:
            query = query.filter(Relationship.status == status_filter)
        if entity_id is not None:
            query = query.filter(
                or_(
                    Relationship.source_entity_id == entity_id,
                    Relationship.target_entity_id == entity_id,
                )
            )
        if q:
            like = f"%{q.lower()}%"
            query = query.filter(
                or_(
                    func.lower(Relationship.name).like(like),
                    func.lower(Relationship.label_forward).like(like),
                    func.lower(func.coalesce(Relationship.label_reverse, "")).like(like),
                )
            )
        # Eager-load dataset rows for response.
        rels = query.order_by(Relationship.created_at.desc()).all()
        # Re-fetch dataset_mappings.dataset relationship cheaply.
        for r in rels:
            _ = [m.dataset for m in (r.dataset_mappings or [])]
        return [_to_response(r) for r in rels]

    def get_relationship(self, relationship_id: int) -> RelationshipResponse:
        _assert_feature_enabled(self.db)
        rel = (
            self.db.query(Relationship)
            .options(
                joinedload(Relationship.attributes),
                joinedload(Relationship.dataset_mappings),
                joinedload(Relationship.source_entity),
                joinedload(Relationship.target_entity),
            )
            .filter(Relationship.id == relationship_id)
            .first()
        )
        if not rel:
            raise HTTPException(status_code=404, detail="Relationship not found")
        # Resolve dataset display fields.
        for m in rel.dataset_mappings or []:
            _ = m.dataset
        return _to_response(rel)

    def update_relationship(
        self, relationship_id: int, payload: RelationshipUpdate
    ) -> RelationshipResponse:
        _assert_feature_enabled(self.db)
        rel = self.db.query(Relationship).filter(Relationship.id == relationship_id).first()
        if not rel:
            raise HTTPException(status_code=404, detail="Relationship not found")

        # Apply mutable fields only.
        if payload.label_forward is not None:
            v = payload.label_forward.strip()
            if not v:
                raise HTTPException(status_code=400, detail="label_forward cannot be empty.")
            rel.label_forward = v

        # If is_bidirectional toggled, validate label_reverse consistency.
        new_is_bidi = (
            payload.is_bidirectional if payload.is_bidirectional is not None else rel.is_bidirectional
        )
        new_label_reverse = (
            payload.label_reverse if payload.label_reverse is not None else rel.label_reverse
        )
        if new_is_bidi:
            if not new_label_reverse or not new_label_reverse.strip():
                raise HTTPException(
                    status_code=400,
                    detail="label_reverse is required when is_bidirectional is true.",
                )
            if new_label_reverse.strip().lower() == (rel.label_forward or "").strip().lower():
                raise HTTPException(
                    status_code=400,
                    detail="label_reverse must differ from label_forward.",
                )
            rel.label_reverse = new_label_reverse.strip()
        else:
            rel.label_reverse = None
        rel.is_bidirectional = bool(new_is_bidi)

        if payload.description is not None:
            rel.description = payload.description
        if payload.developer_group_id is not None:
            rel.developer_group_id = payload.developer_group_id
        if payload.steward_group_id is not None:
            rel.steward_group_id = payload.steward_group_id

        if payload.status is not None:
            # Block illegal transitions: active -> draft is not allowed.
            if rel.status == RelationshipStatus.ACTIVE.value and payload.status == RelationshipStatus.DRAFT.value:
                raise HTTPException(
                    status_code=400,
                    detail="Cannot transition status from 'active' back to 'draft'.",
                )
            rel.status = payload.status

        try:
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(rel)
            return _to_response(rel)
        except Exception:
            self.db.rollback()
            app_logger.exception("Unable to update relationship")
            raise HTTPException(status_code=500, detail="Failed to update relationship")

    def toggle_relationship_active(self, relationship_id: int) -> RelationshipResponse:
        _assert_feature_enabled(self.db)
        rel = self.db.query(Relationship).filter(Relationship.id == relationship_id).first()
        if not rel:
            raise HTTPException(status_code=404, detail="Relationship not found")
        rel.is_active = not bool(rel.is_active)
        if not rel.is_active and rel.status == RelationshipStatus.ACTIVE.value:
            rel.status = RelationshipStatus.INACTIVE.value
        db_commit_auto_rollback(db=self.db)
        self.db.refresh(rel)
        return _to_response(rel)

    def delete_relationship(self, relationship_id: int) -> dict:
        _assert_feature_enabled(self.db)
        rel = self.db.query(Relationship).filter(Relationship.id == relationship_id).first()
        if not rel:
            raise HTTPException(status_code=404, detail="Relationship not found")
        # Hard delete (attributes + mappings cascade). UI must confirm.
        self.db.delete(rel)
        db_commit_auto_rollback(db=self.db)
        return {"status": "success", "message": "Relationship deleted"}


# ---------------------------------------------------------------------------
# Attribute service
# ---------------------------------------------------------------------------

class RelationshipAttributeService:
    def __init__(self, db: Session):
        self.db = db

    def _get_relationship_or_404(self, relationship_id: int) -> Relationship:
        rel = self.db.query(Relationship).filter(Relationship.id == relationship_id).first()
        if not rel:
            raise HTTPException(status_code=404, detail="Relationship not found")
        return rel

    def list_attributes(self, relationship_id: int) -> List[RelationshipAttributeResponse]:
        _assert_feature_enabled(self.db)
        self._get_relationship_or_404(relationship_id)
        rows = (
            self.db.query(RelationshipAttribute)
            .filter(RelationshipAttribute.relationship_id == relationship_id)
            .order_by(RelationshipAttribute.ordinal.asc(), RelationshipAttribute.id.asc())
            .all()
        )
        return [RelationshipAttributeResponse.model_validate(r) for r in rows]

    def create_attribute(
        self, relationship_id: int, payload: RelationshipAttributeCreate, created_by: str
    ) -> RelationshipAttributeResponse:
        _assert_feature_enabled(self.db)
        self._get_relationship_or_404(relationship_id)

        if payload.data_type not in ALLOWED_DATA_TYPES:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid data_type '{payload.data_type}'.",
            )

        existing = (
            self.db.query(RelationshipAttribute)
            .filter(
                RelationshipAttribute.relationship_id == relationship_id,
                RelationshipAttribute.name == payload.name,
            )
            .first()
        )
        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Attribute '{payload.name}' already exists on this relationship.",
            )

        try:
            attr = RelationshipAttribute(
                relationship_id=relationship_id,
                name=payload.name,
                label=payload.label,
                data_type=payload.data_type,
                description=payload.description,
                ordinal=int(payload.ordinal or 0),
            )
            self.db.add(attr)
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(attr)
            return RelationshipAttributeResponse.model_validate(attr)
        except IntegrityError:
            self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Attribute name already exists on this relationship.",
            )

    def update_attribute(
        self,
        relationship_id: int,
        attribute_id: int,
        payload: RelationshipAttributeCreate,
    ) -> RelationshipAttributeResponse:
        _assert_feature_enabled(self.db)
        attr = (
            self.db.query(RelationshipAttribute)
            .filter(
                RelationshipAttribute.id == attribute_id,
                RelationshipAttribute.relationship_id == relationship_id,
            )
            .first()
        )
        if not attr:
            raise HTTPException(status_code=404, detail="Attribute not found")

        if payload.name != attr.name:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Attribute name is immutable in v1. Delete and recreate the attribute "
                    "if you need to rename it."
                ),
            )
        if payload.data_type != attr.data_type:
            # Rejection because Story 2 materializes _edges Delta columns from these types;
            # changing the type mid-life is a schema migration we don't support yet.
            raise HTTPException(
                status_code=400,
                detail=(
                    "Attribute data_type is immutable in v1. Delete and recreate the "
                    "attribute if you need to change its type."
                ),
            )
        attr.label = payload.label
        attr.description = payload.description
        if payload.ordinal is not None:
            attr.ordinal = int(payload.ordinal)
        db_commit_auto_rollback(db=self.db)
        self.db.refresh(attr)
        return RelationshipAttributeResponse.model_validate(attr)

    def delete_attribute(self, relationship_id: int, attribute_id: int) -> dict:
        _assert_feature_enabled(self.db)
        attr = (
            self.db.query(RelationshipAttribute)
            .filter(
                RelationshipAttribute.id == attribute_id,
                RelationshipAttribute.relationship_id == relationship_id,
            )
            .first()
        )
        if not attr:
            raise HTTPException(status_code=404, detail="Attribute not found")

        # Block deletion if any active dataset mapping references this attribute_id.
        referencing = (
            self.db.query(RelationshipDatasetMapping)
            .filter(
                RelationshipDatasetMapping.relationship_id == relationship_id,
                RelationshipDatasetMapping.is_active == True,  # noqa: E712
            )
            .all()
        )
        referencing_mapping_ids: List[int] = []
        for m in referencing:
            for entry in (m.attribute_mappings or []):
                aid = entry.get("attribute_id") if isinstance(entry, dict) else None
                if aid == attribute_id:
                    referencing_mapping_ids.append(m.id)
                    break
        if referencing_mapping_ids:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    "Attribute is referenced by active dataset mappings: "
                    f"{referencing_mapping_ids}. Remove the references first."
                ),
            )

        self.db.delete(attr)
        db_commit_auto_rollback(db=self.db)
        return {"status": "success", "message": "Attribute deleted"}


# ---------------------------------------------------------------------------
# Dataset-mapping service
# ---------------------------------------------------------------------------

class RelationshipDatasetMappingService:
    def __init__(self, db: Session):
        self.db = db

    def _get_relationship_or_404(self, relationship_id: int) -> Relationship:
        rel = self.db.query(Relationship).filter(Relationship.id == relationship_id).first()
        if not rel:
            raise HTTPException(status_code=404, detail="Relationship not found")
        return rel

    def _get_dataset_or_400(self, dataset_id: int) -> Dataset:
        ds = self.db.query(Dataset).filter(Dataset.id == dataset_id).first()
        if not ds:
            raise HTTPException(status_code=400, detail=f"Dataset {dataset_id} not found.")
        if not ds.is_active:
            raise HTTPException(status_code=400, detail=f"Dataset '{ds.name}' is inactive.")
        return ds

    def _derive_source_system_tag(self, dataset: Dataset) -> str:
        """Derive a source-system tag from the dataset's name.

        Uppercased, only ASCII letters/digits/underscores, capped at 50 chars.
        Falls back to the dataset id if the name yields an empty slug.
        """
        raw = (dataset.name or "").strip()
        cleaned = "".join(
            ch if ch.isalnum() or ch == "_" else "_" for ch in raw
        ).upper()
        # Collapse runs of underscores.
        while "__" in cleaned:
            cleaned = cleaned.replace("__", "_")
        cleaned = cleaned.strip("_")[:50]
        return cleaned or f"DATASET_{dataset.id}"

    def reorder_mappings(
        self, relationship_id: int, ordered_mapping_ids: List[int]
    ) -> List[RelationshipDatasetMappingResponse]:
        """Rewrite priority values to reflect the supplied order.

        Frontend provides the mapping ids top-to-bottom (top = highest
        priority). Backend stores priority = (idx + 1) * 10 so future
        single-row reorders have gaps to slot into.
        """
        _assert_feature_enabled(self.db)
        self._get_relationship_or_404(relationship_id)

        existing = (
            self.db.query(RelationshipDatasetMapping)
            .filter(RelationshipDatasetMapping.relationship_id == relationship_id)
            .all()
        )
        existing_ids = {m.id for m in existing}
        provided = list(ordered_mapping_ids or [])
        if set(provided) != existing_ids:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Provided ordering must contain every mapping id for this "
                    f"relationship exactly once. Expected {sorted(existing_ids)}, "
                    f"got {provided}."
                ),
            )
        # Apply new priorities.
        id_to_priority = {mid: (idx + 1) * 10 for idx, mid in enumerate(provided)}
        for m in existing:
            m.priority = id_to_priority[m.id]
        db_commit_auto_rollback(db=self.db)
        return self.list_mappings(relationship_id)

    def _validate_attribute_mappings(
        self, relationship_id: int, payload_mappings: list
    ) -> List[dict]:
        # Resolve attribute ids — must belong to this relationship.
        attrs = (
            self.db.query(RelationshipAttribute)
            .filter(RelationshipAttribute.relationship_id == relationship_id)
            .all()
        )
        valid_ids = {a.id for a in attrs}
        out: List[dict] = []
        seen_ids = set()
        seen_cols = set()
        for entry in payload_mappings or []:
            aid = entry.attribute_id if hasattr(entry, "attribute_id") else entry.get("attribute_id")
            col = entry.column_name if hasattr(entry, "column_name") else entry.get("column_name")
            if aid not in valid_ids:
                raise HTTPException(
                    status_code=400,
                    detail=f"attribute_id {aid} does not belong to relationship {relationship_id}.",
                )
            if not col or not str(col).strip():
                raise HTTPException(
                    status_code=400,
                    detail=f"column_name is required for attribute_id {aid}.",
                )
            if aid in seen_ids:
                raise HTTPException(
                    status_code=400,
                    detail=f"Duplicate attribute_id {aid} in attribute_mappings.",
                )
            if col in seen_cols:
                raise HTTPException(
                    status_code=400,
                    detail=f"Duplicate column_name '{col}' in attribute_mappings.",
                )
            seen_ids.add(aid)
            seen_cols.add(col)
            out.append({"attribute_id": int(aid), "column_name": str(col)})
        return out

    def list_mappings(
        self, relationship_id: int
    ) -> List[RelationshipDatasetMappingResponse]:
        _assert_feature_enabled(self.db)
        self._get_relationship_or_404(relationship_id)
        rows = (
            self.db.query(RelationshipDatasetMapping)
            .options(joinedload(RelationshipDatasetMapping.relationship_def))
            .filter(RelationshipDatasetMapping.relationship_id == relationship_id)
            .order_by(RelationshipDatasetMapping.priority.asc(), RelationshipDatasetMapping.id.asc())
            .all()
        )
        out: List[RelationshipDatasetMappingResponse] = []
        for m in rows:
            ds = self.db.query(Dataset).filter(Dataset.id == m.dataset_id).first()
            out.append(
                RelationshipDatasetMappingResponse(
                    id=m.id,
                    relationship_id=m.relationship_id,
                    dataset_id=m.dataset_id,
                    source_pk_column=m.source_pk_column,
                    target_pk_column=m.target_pk_column,
                    start_date_column=m.start_date_column,
                    end_date_column=m.end_date_column,
                    status_column=m.status_column,
                    source_system_tag=m.source_system_tag,
                    priority=m.priority,
                    attribute_mappings=m.attribute_mappings or [],
                    created_by=m.created_by,
                    created_at=m.created_at,
                    updated_at=m.updated_at,
                    is_active=m.is_active,
                    dataset_name=ds.name if ds else None,
                    dataset_path=ds.path if ds else None,
                )
            )
        return out

    def create_mapping(
        self,
        relationship_id: int,
        payload: RelationshipDatasetMappingCreate,
        created_by: str,
    ) -> RelationshipDatasetMappingResponse:
        _assert_feature_enabled(self.db)
        rel = self._get_relationship_or_404(relationship_id)
        ds = self._get_dataset_or_400(payload.dataset_id)

        if payload.source_pk_column == payload.target_pk_column:
            raise HTTPException(
                status_code=400,
                detail="source_pk_column and target_pk_column must differ.",
            )

        # Prevent duplicate mapping for same (rel, dataset, src_pk, tgt_pk).
        dup = (
            self.db.query(RelationshipDatasetMapping)
            .filter(
                RelationshipDatasetMapping.relationship_id == relationship_id,
                RelationshipDatasetMapping.dataset_id == payload.dataset_id,
                RelationshipDatasetMapping.source_pk_column == payload.source_pk_column,
                RelationshipDatasetMapping.target_pk_column == payload.target_pk_column,
                RelationshipDatasetMapping.is_active == True,  # noqa: E712
            )
            .first()
        )
        if dup:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    "An active mapping with this dataset and PK columns already exists "
                    f"(mapping id {dup.id})."
                ),
            )

        validated_attr_maps = self._validate_attribute_mappings(
            relationship_id, payload.attribute_mappings
        )

        # source_system_tag is auto-derived from the dataset's name (kept in
        # sync with the dataset rather than entered by the designer). Any
        # value sent on the payload is ignored.
        derived_tag = self._derive_source_system_tag(ds)

        # priority is server-managed: new mappings land at the bottom of the
        # priority list (highest numeric value, lowest precedence) so existing
        # ordering is preserved. Designer reorders explicitly via the
        # reorder_mappings endpoint.
        max_priority = (
            self.db.query(RelationshipDatasetMapping)
            .filter(RelationshipDatasetMapping.relationship_id == relationship_id)
            .with_entities(func.coalesce(func.max(RelationshipDatasetMapping.priority), 0))
            .scalar()
            or 0
        )
        next_priority = int(max_priority) + 10

        try:
            row = RelationshipDatasetMapping(
                relationship_id=relationship_id,
                dataset_id=payload.dataset_id,
                source_pk_column=payload.source_pk_column,
                target_pk_column=payload.target_pk_column,
                start_date_column=payload.start_date_column,
                end_date_column=payload.end_date_column,
                status_column=payload.status_column,
                source_system_tag=derived_tag,
                priority=next_priority,
                attribute_mappings=validated_attr_maps,
                created_by=created_by or "",
            )
            self.db.add(row)
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(row)
            return RelationshipDatasetMappingResponse(
                id=row.id,
                relationship_id=row.relationship_id,
                dataset_id=row.dataset_id,
                source_pk_column=row.source_pk_column,
                target_pk_column=row.target_pk_column,
                start_date_column=row.start_date_column,
                end_date_column=row.end_date_column,
                status_column=row.status_column,
                source_system_tag=row.source_system_tag,
                priority=row.priority,
                attribute_mappings=row.attribute_mappings or [],
                created_by=row.created_by,
                created_at=row.created_at,
                updated_at=row.updated_at,
                is_active=row.is_active,
                dataset_name=ds.name,
                dataset_path=ds.path,
            )
        except IntegrityError:
            self.db.rollback()
            raise HTTPException(status_code=400, detail="Failed to create mapping (integrity).")

    def update_mapping(
        self,
        relationship_id: int,
        mapping_id: int,
        payload: RelationshipDatasetMappingCreate,
    ) -> RelationshipDatasetMappingResponse:
        _assert_feature_enabled(self.db)
        m = (
            self.db.query(RelationshipDatasetMapping)
            .filter(
                RelationshipDatasetMapping.id == mapping_id,
                RelationshipDatasetMapping.relationship_id == relationship_id,
            )
            .first()
        )
        if not m:
            raise HTTPException(status_code=404, detail="Mapping not found")

        if payload.source_pk_column == payload.target_pk_column:
            raise HTTPException(
                status_code=400,
                detail="source_pk_column and target_pk_column must differ.",
            )

        if payload.dataset_id != m.dataset_id:
            self._get_dataset_or_400(payload.dataset_id)

        validated_attr_maps = self._validate_attribute_mappings(
            relationship_id, payload.attribute_mappings
        )

        m.dataset_id = payload.dataset_id
        m.source_pk_column = payload.source_pk_column
        m.target_pk_column = payload.target_pk_column
        m.start_date_column = payload.start_date_column
        m.end_date_column = payload.end_date_column
        m.status_column = payload.status_column
        # source_system_tag stays in sync with the underlying dataset. Designer
        # cannot override it.
        ds_for_tag = self.db.query(Dataset).filter(Dataset.id == m.dataset_id).first()
        if ds_for_tag:
            m.source_system_tag = self._derive_source_system_tag(ds_for_tag)
        # priority is owned by reorder_mappings — preserved on update.
        m.attribute_mappings = validated_attr_maps

        db_commit_auto_rollback(db=self.db)
        self.db.refresh(m)
        ds = self.db.query(Dataset).filter(Dataset.id == m.dataset_id).first()
        return RelationshipDatasetMappingResponse(
            id=m.id,
            relationship_id=m.relationship_id,
            dataset_id=m.dataset_id,
            source_pk_column=m.source_pk_column,
            target_pk_column=m.target_pk_column,
            start_date_column=m.start_date_column,
            end_date_column=m.end_date_column,
            status_column=m.status_column,
            source_system_tag=m.source_system_tag,
            priority=m.priority,
            attribute_mappings=m.attribute_mappings or [],
            created_by=m.created_by,
            created_at=m.created_at,
            updated_at=m.updated_at,
            is_active=m.is_active,
            dataset_name=ds.name if ds else None,
            dataset_path=ds.path if ds else None,
        )

    def delete_mapping(self, relationship_id: int, mapping_id: int) -> dict:
        _assert_feature_enabled(self.db)
        m = (
            self.db.query(RelationshipDatasetMapping)
            .filter(
                RelationshipDatasetMapping.id == mapping_id,
                RelationshipDatasetMapping.relationship_id == relationship_id,
            )
            .first()
        )
        if not m:
            raise HTTPException(status_code=404, detail="Mapping not found")
        self.db.delete(m)
        db_commit_auto_rollback(db=self.db)
        return {"status": "success", "message": "Mapping deleted"}

    def toggle_mapping_active(
        self, relationship_id: int, mapping_id: int
    ) -> RelationshipDatasetMappingResponse:
        _assert_feature_enabled(self.db)
        m = (
            self.db.query(RelationshipDatasetMapping)
            .filter(
                RelationshipDatasetMapping.id == mapping_id,
                RelationshipDatasetMapping.relationship_id == relationship_id,
            )
            .first()
        )
        if not m:
            raise HTTPException(status_code=404, detail="Mapping not found")
        m.is_active = not bool(m.is_active)
        db_commit_auto_rollback(db=self.db)
        self.db.refresh(m)
        ds = self.db.query(Dataset).filter(Dataset.id == m.dataset_id).first()
        return RelationshipDatasetMappingResponse(
            id=m.id,
            relationship_id=m.relationship_id,
            dataset_id=m.dataset_id,
            source_pk_column=m.source_pk_column,
            target_pk_column=m.target_pk_column,
            start_date_column=m.start_date_column,
            end_date_column=m.end_date_column,
            status_column=m.status_column,
            source_system_tag=m.source_system_tag,
            priority=m.priority,
            attribute_mappings=m.attribute_mappings or [],
            created_by=m.created_by,
            created_at=m.created_at,
            updated_at=m.updated_at,
            is_active=m.is_active,
            dataset_name=ds.name if ds else None,
            dataset_path=ds.path if ds else None,
        )
