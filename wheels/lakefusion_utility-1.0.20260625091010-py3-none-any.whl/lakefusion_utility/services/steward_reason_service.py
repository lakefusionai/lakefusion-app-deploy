import json

from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc

from lakefusion_utility.models.databricks_model import Model_Databricks_Entity_Search_Job
from lakefusion_utility.models.entity import Entity
from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.databricks_util import DataSetSQLService

app_logger = get_logger(__name__)

STEWARD_OPERATION_TYPES = [
    'MERGE', 'MERGE_ALL', 'NOT_A_MATCH',
    'MANUAL_MERGE', 'MANUAL_NOT_A_MATCH', 'MANUAL_UNMERGE', 'MANUAL_FORCE_MERGE',
    'MASTER_MANUAL_MERGE', 'MASTER_MANUAL_NOT_A_MATCH',
    'FORCE_MERGE', 'UNMERGE', 'MANUAL_UPDATE',
]


class StewardReasonService:
    def __init__(self, db: Session):
        self.db = db
        self.catalog_name = (
            db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "catalog_name")
            .first().config_value
        )

    def add_reason(self, entity_id: int, job_id: int, reason: str, reason_category: str = None,
                   updated_by: str = None, token: str = None, warehouse_id: str = None):
        job = (
            self.db.query(Model_Databricks_Entity_Search_Job)
            .filter(
                Model_Databricks_Entity_Search_Job.id == job_id,
                Model_Databricks_Entity_Search_Job.entity_id == entity_id,
            )
            .first()
        )
        if not job:
            raise HTTPException(status_code=404, detail=f"Stewardship job {job_id} not found for entity {entity_id}")

        job.steward_reason = reason
        if reason_category:
            job.steward_reason_category = reason_category

        self.db.commit()
        self.db.refresh(job)
        app_logger.info(f"Steward reason added for job {job_id} by {updated_by}: [{reason_category}] {(reason or '')[:100]}")

        # Sync reason to steward_decisions Delta table
        if token and warehouse_id:
            try:
                entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
                if entity:
                    entity_name = entity.name.lower().replace(' ', '_')
                    decisions_table = f"{self.catalog_name}.silver.{entity_name}_steward_decisions"
                    escaped_reason = (reason or "").replace("'", "''")
                    escaped_category = (reason_category or "").replace("'", "''")
                    sql_service = DataSetSQLService(token, warehouse_id)
                    sql_service.execute_sql_script(
                        f"BEGIN MERGE INTO {decisions_table} AS t "
                        f"USING (SELECT '{job.master_id}' AS master_id, '{job.profile_id}' AS match_id, "
                        f"'{job.operation_type}' AS action_type) AS s "
                        f"ON t.master_id = s.master_id AND t.match_id = s.match_id AND t.action_type = s.action_type "
                        f"WHEN MATCHED THEN UPDATE SET t.reason = '{escaped_reason}', "
                        f"t.reason_category = '{escaped_category}'; END"
                    )
                    app_logger.info(f"Steward reason synced to Delta table for job {job_id}")
            except Exception as e:
                app_logger.warning(f"Could not sync reason to steward_decisions Delta table: {e}")

        return {
            "status": "ok",
            "job_id": job.id,
            "steward_reason": job.steward_reason,
            "steward_reason_category": job.steward_reason_category,
        }

    def get_stewardship_history(self, entity_id: int, token: str = None, warehouse_id: str = None,
                                 action_type: str = None, has_reason: bool = None, page: int = 1, page_size: int = 20):
        query = (
            self.db.query(Model_Databricks_Entity_Search_Job)
            .filter(Model_Databricks_Entity_Search_Job.entity_id == entity_id)
            .filter(Model_Databricks_Entity_Search_Job.operation_type.in_(STEWARD_OPERATION_TYPES))
        )

        if action_type:
            query = query.filter(Model_Databricks_Entity_Search_Job.operation_type == action_type)
        if has_reason is True:
            query = query.filter(Model_Databricks_Entity_Search_Job.steward_reason.isnot(None))
        elif has_reason is False:
            query = query.filter(Model_Databricks_Entity_Search_Job.steward_reason.is_(None))

        total = query.count()
        jobs = (
            query.order_by(desc(Model_Databricks_Entity_Search_Job.created_at))
            .offset((page - 1) * page_size).limit(page_size).all()
        )

        with_reason = (
            self.db.query(Model_Databricks_Entity_Search_Job)
            .filter(Model_Databricks_Entity_Search_Job.entity_id == entity_id)
            .filter(Model_Databricks_Entity_Search_Job.operation_type.in_(STEWARD_OPERATION_TYPES))
            .filter(Model_Databricks_Entity_Search_Job.steward_reason.isnot(None))
            .count()
        )

        items = []
        for job in jobs:
            items.append({
                "id": job.id,
                "entity_id": job.entity_id,
                "master_id": job.master_id,
                "profile_id": job.profile_id,
                "operation_type": job.operation_type,
                "job_run_id": job.job_run_id,
                "status": job.status,
                "created_at": job.created_at.isoformat() if job.created_at else None,
                "created_by": job.created_by,
                "steward_reason": job.steward_reason,
                "steward_reason_category": job.steward_reason_category,
                "master_record": None,
                "match_record": None,
            })

        # Enrich with record attributes from catalog tables if warehouse available
        if token and warehouse_id and items:
            try:
                self._enrich_with_record_attributes(entity_id, items, token, warehouse_id)
            except Exception as e:
                app_logger.warning(f"Could not enrich stewardship history with record attributes: {e}")

        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "reason_stats": {
                "total_decisions": total,
                "with_reason": with_reason,
                "without_reason": total - with_reason,
                "capture_rate": round(with_reason / total * 100, 1) if total > 0 else 0,
            },
            "items": items,
        }

    def _enrich_with_record_attributes(self, entity_id: int, items: list, token: str, warehouse_id: str):
        entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
        if not entity:
            return

        entity_name = entity.name.lower().replace(' ', '_')
        decisions_table = f"{self.catalog_name}.silver.{entity_name}_steward_decisions"
        master_table = f"{self.catalog_name}.gold.{entity_name}_master_prod"
        unified_table = f"{self.catalog_name}.silver.{entity_name}_unified_prod"

        sql_service = DataSetSQLService(token, warehouse_id)

        # Step 1: Try to enrich from steward_decisions Delta table (frozen snapshots)
        try:
            master_ids = set()
            match_ids = set()
            for item in items:
                if item["master_id"]:
                    master_ids.add(item["master_id"])
                if item["profile_id"]:
                    match_ids.add(item["profile_id"])

            if master_ids and match_ids:
                master_ids_str = ",".join([f"'{mid}'" for mid in master_ids])
                match_ids_str = ",".join([f"'{mid}'" for mid in match_ids])
                decisions_script = (
                    f"BEGIN SELECT master_id, match_id, master_record_attributes, match_record_attributes "
                    f"FROM {decisions_table} "
                    f"WHERE master_id IN ({master_ids_str}) AND match_id IN ({match_ids_str}); END"
                )
                decisions_result = sql_service.execute_sql_script(decisions_script)
                decisions_lookup = {}
                for row in (decisions_result.get("result") or []):
                    key = (row.get("master_id"), row.get("match_id"))
                    decisions_lookup[key] = row

                for item in items:
                    decision = decisions_lookup.get((item["master_id"], item["profile_id"]))
                    if decision:
                        master_attrs_raw = decision.get("master_record_attributes")
                        match_attrs_raw = decision.get("match_record_attributes")
                        item["master_record"] = json.loads(master_attrs_raw) if master_attrs_raw else None
                        item["match_record"] = json.loads(match_attrs_raw) if match_attrs_raw else None
        except Exception as e:
            app_logger.warning(f"Could not fetch from steward_decisions table: {e}")

        # Step 2: Fall back to live tables for items still missing records
        items_needing_fallback = [item for item in items if not item["master_record"] or not item["match_record"]]
        if not items_needing_fallback:
            return

        fallback_master_ids = set()
        fallback_profile_ids = set()
        for item in items_needing_fallback:
            if not item["master_record"] and item["master_id"]:
                fallback_master_ids.add(item["master_id"])
            if not item["match_record"] and item["profile_id"]:
                fallback_profile_ids.add(item["profile_id"])

        if not fallback_master_ids and not fallback_profile_ids:
            return

        attr_cols = [a.name for a in (entity.attributes or [])] if entity.attributes else []
        if not attr_cols:
            return

        cols_sql = ", ".join(attr_cols)
        master_ids_str = ",".join([f"'{mid}'" for mid in fallback_master_ids]) if fallback_master_ids else None
        profile_ids_str = ",".join([f"'{pid}'" for pid in fallback_profile_ids]) if fallback_profile_ids else None

        parts = []
        if master_ids_str:
            parts.append(
                f"SELECT lakefusion_id AS _lookup_key, 'master' AS _record_type, {cols_sql} "
                f"FROM {master_table} WHERE lakefusion_id IN ({master_ids_str})"
            )
        if profile_ids_str:
            parts.append(
                f"SELECT surrogate_key AS _lookup_key, 'unified' AS _record_type, {cols_sql} "
                f"FROM {unified_table} WHERE surrogate_key IN ({profile_ids_str})"
            )

        if not parts:
            return

        combined_query = " UNION ALL ".join(parts)
        script = f"BEGIN SELECT * FROM ({combined_query}); END"

        master_lookup = {}
        unified_lookup = {}
        try:
            result = sql_service.execute_sql_script(script)
            for row in (result.get("result") or []):
                record_type = row.pop("_record_type", None)
                lookup_key = row.pop("_lookup_key", None)
                if record_type == "master" and lookup_key:
                    master_lookup[lookup_key] = row
                elif record_type == "unified" and lookup_key:
                    unified_lookup[lookup_key] = row
        except Exception as e:
            app_logger.warning(f"Could not fetch records from live tables: {e}")

        for item in items_needing_fallback:
            if not item["master_record"]:
                item["master_record"] = master_lookup.get(item["master_id"])
            if not item["match_record"]:
                item["match_record"] = unified_lookup.get(item["profile_id"])
