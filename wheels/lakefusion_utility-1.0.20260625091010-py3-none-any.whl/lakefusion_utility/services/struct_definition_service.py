"""CRUD service for StructDefinition + StructField.

Struct definitions are reusable struct schemas referenced by entity attributes
of type=STRUCT. Their fields must be scalar (no nested struct/array). Deletion
is blocked when any active entity attribute references the definition.
"""
import logging
from typing import List, Optional

from fastapi import HTTPException
from sqlalchemy.orm import Session, joinedload

from lakefusion_utility.models.entity import EntityAttributes
from lakefusion_utility.models.struct_definition import (
    StructDefinition,
    StructField,
    StructDefinitionCreate,
    StructDefinitionUpdate,
    StructFieldCreate,
)
from lakefusion_utility.utils.app_db import db_commit_auto_rollback

app_logger = logging.getLogger(__name__)


# Scalar types allowed on struct fields. Anything outside this set is rejected.
# Keep aligned with EntityAttributes scalar type set used by the UI.
SCALAR_FIELD_TYPES = {
    "STRING",
    "INT",
    "BIGINT",
    "DOUBLE",
    "FLOAT",
    "DECIMAL",
    "BOOLEAN",
    "DATE",
    "TIMESTAMP",
}

# Types explicitly forbidden inside a struct field (no nested structs/arrays).
FORBIDDEN_FIELD_TYPES = {"STRUCT", "ARRAY"}


class StructDefinitionService:
    def __init__(self, db: Session):
        self.db = db

    # ---------- helpers ----------

    @staticmethod
    def _validate_field_type(data_type: str) -> str:
        normalized = (data_type or "").strip().upper()
        if not normalized:
            raise HTTPException(status_code=400, detail="data_type is required")
        if normalized in FORBIDDEN_FIELD_TYPES:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Struct fields cannot be of type '{normalized}'. "
                    f"Only scalar types allowed: {sorted(SCALAR_FIELD_TYPES)}"
                ),
            )
        if normalized not in SCALAR_FIELD_TYPES:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Invalid struct field data_type '{data_type}'. "
                    f"Allowed: {sorted(SCALAR_FIELD_TYPES)}"
                ),
            )
        return normalized

    def _get_referencing_attributes(self, struct_definition_id: int) -> List[EntityAttributes]:
        """All ACTIVE entity attributes referencing this struct definition."""
        return (
            self.db.query(EntityAttributes)
            .filter(
                EntityAttributes.struct_definition_id == struct_definition_id,
                EntityAttributes.is_active == True,  # noqa: E712
            )
            .all()
        )

    def _load_with_fields(self, struct_definition_id: int) -> StructDefinition:
        sd = (
            self.db.query(StructDefinition)
            .options(joinedload(StructDefinition.fields))
            .filter(StructDefinition.id == struct_definition_id)
            .first()
        )
        if not sd:
            raise HTTPException(
                status_code=404,
                detail=f"Struct definition id={struct_definition_id} not found",
            )
        return sd

    def _replace_fields(
        self, sd: StructDefinition, field_payloads: List[StructFieldCreate]
    ) -> None:
        """Drop existing fields and create new ones from payload.

        Field replacement is destructive — used by update. Caller is expected
        to have verified that no active attribute references this struct (or
        that the schema change is intentional).
        """
        # Remove old fields. cascade='all, delete-orphan' on the relationship
        # ensures the rows are deleted when the list is cleared.
        sd.fields.clear()
        self.db.flush()

        for idx, payload in enumerate(field_payloads):
            normalized_type = self._validate_field_type(payload.data_type)
            sd.fields.append(
                StructField(
                    struct_definition_id=sd.id,
                    name=payload.name.strip(),
                    label=(payload.label or None),
                    data_type=normalized_type,
                    ordinal_position=(
                        payload.ordinal_position
                        if payload.ordinal_position is not None
                        else idx
                    ),
                )
            )

    # ---------- public CRUD ----------

    def create(self, payload: StructDefinitionCreate) -> StructDefinition:
        # Names are unique within an entity, not globally.
        existing = (
            self.db.query(StructDefinition)
            .filter(
                StructDefinition.name == payload.name,
                StructDefinition.entity_id == payload.entity_id,
            )
            .first()
        )
        if existing:
            raise HTTPException(
                status_code=409,
                detail=f"Struct definition with name '{payload.name}' already exists",
            )

        # Validate field types up-front so a bad type doesn't leave a half-built
        # struct in the session.
        normalized_fields: List[StructField] = []
        for idx, fld in enumerate(payload.fields):
            normalized_type = self._validate_field_type(fld.data_type)
            normalized_fields.append(
                StructField(
                    struct_definition_id=None,  # set after parent flush
                    name=fld.name.strip(),
                    label=(fld.label or None),
                    data_type=normalized_type,
                    ordinal_position=(
                        fld.ordinal_position if fld.ordinal_position is not None else idx
                    ),
                )
            )

        sd = StructDefinition(
            name=payload.name,
            entity_id=payload.entity_id,
            description=payload.description,
            is_active=payload.is_active if payload.is_active is not None else True,
            created_by=payload.created_by or None,
        )
        sd.fields = normalized_fields
        self.db.add(sd)
        db_commit_auto_rollback(db=self.db)
        self.db.refresh(sd)
        return sd

    def list_all(
        self,
        is_active: Optional[bool] = None,
        entity_id: Optional[int] = None,
    ) -> List[StructDefinition]:
        q = self.db.query(StructDefinition).options(joinedload(StructDefinition.fields))
        if is_active is not None:
            q = q.filter(StructDefinition.is_active == is_active)
        # Scope to the owning entity — a struct is exclusive to one entity.
        if entity_id is not None:
            q = q.filter(StructDefinition.entity_id == entity_id)
        return q.order_by(StructDefinition.name.asc()).all()

    def get_by_id(self, struct_definition_id: int) -> StructDefinition:
        return self._load_with_fields(struct_definition_id)

    def update(
        self, struct_definition_id: int, payload: StructDefinitionUpdate
    ) -> StructDefinition:
        sd = self._load_with_fields(struct_definition_id)

        if payload.name is not None:
            new_name = payload.name.strip()
            if not new_name:
                raise HTTPException(status_code=400, detail="name cannot be blank")
            if new_name != sd.name:
                clash = (
                    self.db.query(StructDefinition)
                    .filter(
                        StructDefinition.name == new_name,
                        StructDefinition.entity_id == sd.entity_id,
                        StructDefinition.id != struct_definition_id,
                    )
                    .first()
                )
                if clash:
                    raise HTTPException(
                        status_code=409,
                        detail=f"Struct definition with name '{new_name}' already exists",
                    )
                sd.name = new_name

        if payload.description is not None:
            sd.description = payload.description
        if payload.is_active is not None:
            sd.is_active = payload.is_active

        # Field edits are locked once any active entity attribute references
        # the struct definition. Schema drift between definition and downstream
        # Delta tables is treated as a schema-evolution concern. Detach
        # (deactivate or delete) referrers first.
        if payload.fields is not None:
            refs = self._get_referencing_attributes(struct_definition_id)
            if refs:
                raise HTTPException(
                    status_code=409,
                    detail={
                        "message": (
                            f"Struct definition '{sd.name}' fields cannot be edited "
                            f"while referenced by {len(refs)} active entity attribute(s). "
                            f"Deactivate or remove those attributes first, or use the "
                            f"schema evolution flow to migrate."
                        ),
                        "referencing_attributes": [
                            {
                                "id": r.id,
                                "entity_id": r.entity_id,
                                "name": r.name,
                                "type": r.type,
                                "is_array": bool(r.is_array),
                            }
                            for r in refs
                        ],
                    },
                )
            self._replace_fields(sd, payload.fields)

        db_commit_auto_rollback(db=self.db)
        self.db.refresh(sd)
        return sd

    def get_usage(self, struct_definition_id: int) -> dict:
        """Return active entity attributes referencing this struct definition.

        Lightweight read-only endpoint the UI uses to render usage badges and
        decide whether to lock the field editor.
        """
        sd = self._load_with_fields(struct_definition_id)
        refs = self._get_referencing_attributes(struct_definition_id)
        return {
            "struct_definition_id": sd.id,
            "name": sd.name,
            "usage_count": len(refs),
            "referencing_attributes": [
                {
                    "id": r.id,
                    "entity_id": r.entity_id,
                    "name": r.name,
                    "type": r.type,
                    "is_array": bool(r.is_array),
                }
                for r in refs
            ],
        }

    def delete(self, struct_definition_id: int) -> dict:
        sd = self._load_with_fields(struct_definition_id)

        refs = self._get_referencing_attributes(struct_definition_id)
        if refs:
            raise HTTPException(
                status_code=409,
                detail={
                    "message": (
                        f"Struct definition '{sd.name}' is referenced by "
                        f"{len(refs)} active entity attribute(s). Remove or "
                        f"deactivate those attributes before deleting."
                    ),
                    "referencing_attributes": [
                        {
                            "id": r.id,
                            "entity_id": r.entity_id,
                            "name": r.name,
                            "type": r.type,
                            "is_array": bool(r.is_array),
                        }
                        for r in refs
                    ],
                },
            )

        self.db.delete(sd)
        db_commit_auto_rollback(db=self.db)
        return {"id": struct_definition_id, "deleted": True}
