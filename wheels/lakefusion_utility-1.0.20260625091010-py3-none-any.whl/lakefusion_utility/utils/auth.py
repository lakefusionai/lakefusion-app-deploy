import os,json
from fastapi import Depends, HTTPException,Request
from sqlalchemy.orm import Session
from fastapi.security import HTTPAuthorizationCredentials
from lakefusion_utility.utils.http_bearer import HTTPBearer401
from sqlalchemy.orm import Session
from lakefusion_utility.models.dbconfig import DBConfigProperties

import jwt
from jwt import ExpiredSignatureError, InvalidTokenError
from lakefusion_utility.utils.lf_utils import verify_and_decode_jwt
from lakefusion_utility.utils.logging_utils import get_logger
# NOTE: ComputeService is imported lazily inside the function that uses it
# (see token validation below). Importing at module level here creates a
# circular import — databricks_util.py imports models/__init__.py which
# auto-loads feature_flags.py → utils/database.py → utils/auth.py → back to
# databricks_util.ComputeService before that name has been defined. Keeping
# the import function-local breaks the cycle for every consumer.
from databricks.sdk.service.compute import ListClustersFilterBy, ClusterSource
from cachetools.keys import hashkey
from cachetools import TTLCache, cached

# Initialize security scheme and logger
token_auth_scheme = HTTPBearer401()  # HTTPBearer security for token-based authentication
app_logger = get_logger(__name__)  # Logger instance for logging errors and information

# Fetch environment variables for Databricks host, validation token, and OIDC client ID
DATABRICKS_HOST = os.environ.get('DATABRICKS_HOST', 'https://databricks.com')
if DATABRICKS_HOST and not DATABRICKS_HOST.startswith(("http://", "https://")):
    DATABRICKS_HOST = f"https://{DATABRICKS_HOST}"
RUN_DATABRICKS_VALIDATION_TOKEN = os.environ.get('RUN_DATABRICKS_VALIDATION_TOKEN', 'True')  # Whether to validate via Databricks clusters
DATABRICKS_OIDC_CLIENT_ID = os.environ.get('DATABRICKS_OIDC_CLIENT_ID', '')  # OIDC client ID for token verification

# Auth provider switch: "databricks" (default) or "azuread"
AUTH_PROVIDER = os.environ.get('AUTH_PROVIDER', 'databricks')
AZURE_TENANT_ID = os.environ.get('AZURE_TENANT_ID', '')
AZURE_AD_CLIENT_ID = os.environ.get('AZURE_AD_CLIENT_ID', '')


# Create a cache for token validity with a TTL of 1 hour
token_cache = TTLCache(maxsize=100, ttl=3600)

# Function to validate the token
@cached(cache=token_cache, key=hashkey)
def token_valid(token: str):
    """
    Validates the provided token either by making Databricks API call using the passed access token or by decoding JWT.
    Supports both Databricks OIDC and Azure AD (Entra ID) tokens based on AUTH_PROVIDER.
    """
    valid_token = False
    message = ""
    data = []
    decoded = {}

    try:
        # Step 1: Decode with JWKS signature verification (falls back to unverified)
        unverified_claims = verify_and_decode_jwt(token)
        issuer = unverified_claims.get("iss", "")
        token_sub = unverified_claims.get("sub", "")
        token_client_id = unverified_claims.get("client_id", unverified_claims.get("appid", ""))
        token_scope = unverified_claims.get("scope", "")

        app_logger.info(
            f"Token validation: sub={token_sub}, client_id={token_client_id}, "
            f"iss={issuer}, scope={token_scope}"
        )

        # Step 2: Check issuer
        if AUTH_PROVIDER == "azuread":
            expected_issuer = f"https://sts.windows.net/{AZURE_TENANT_ID}/"
        else:
            expected_issuer = f"{DATABRICKS_HOST}/oidc"
        if issuer != expected_issuer:
            message = f"Issuer mismatch: expected {expected_issuer}, got {issuer}"
            app_logger.error(message)
            raise HTTPException(status_code=401, detail=message)

        # Step 3: Decode with JWKS signature verification (falls back to unverified)
        decoded = verify_and_decode_jwt(token)

        # Step 4: Validate client_id — allow both interactive OIDC tokens and M2M
        # service-principal tokens (where client_id == sub).
        if AUTH_PROVIDER == "azuread":
            token_appid = decoded.get('appid', '')
            token_sub = decoded.get('sub', '')
            if not (token_appid == AZURE_AD_CLIENT_ID or token_appid == token_sub):
                raise InvalidTokenError(f"Invalid client ID (appid={token_appid})")
            # Normalize sub claim for downstream compatibility — all endpoints use decoded['sub']
            decoded['sub'] = decoded.get('upn', decoded.get('unique_name', decoded.get('sub', '')))
        else:
            decoded_client_id = decoded.get('client_id', '')
            decoded_sub = decoded.get('sub', '')
            if not (decoded_client_id == DATABRICKS_OIDC_CLIENT_ID or decoded_client_id == decoded_sub):
                raise InvalidTokenError(
                    f"Invalid client ID: {decoded_client_id} (expected OIDC={DATABRICKS_OIDC_CLIENT_ID} or M2M sub={decoded_sub})"
                )

        app_logger.info(f"Token JWT verified: sub={decoded.get('sub')}, provider={AUTH_PROVIDER}")

        # Step 5: Optional Databricks clusters validation
        if RUN_DATABRICKS_VALIDATION_TOKEN.lower() == 'true':
            # Lazy import — see note at top of file about the auth ↔ databricks_util cycle.
            from lakefusion_utility.utils.databricks_util import ComputeService
            cs = ComputeService(token)
            data = cs.list_clusters(filter_by=ListClustersFilterBy(is_pinned=True, cluster_sources=[ClusterSource.UI]))
            app_logger.info(f"Clusters validation passed ({len(data) if data else 0} pinned clusters)")
        else:
            app_logger.info("Clusters validation skipped (RUN_DATABRICKS_VALIDATION_TOKEN=False)")

        valid_token = True

    except ExpiredSignatureError:
        message = "Token has expired"
        app_logger.error(message)
    except InvalidTokenError as e:
        message = f"Invalid token: {str(e)}"
        app_logger.error(message)
    except Exception as err:
        message = f"Exception occurred during token validation: {err}"
        app_logger.exception(message)

    if not valid_token:
        app_logger.warning(f"Token validation failed: {message}")

    return valid_token, message, data, decoded

# Dependency function to require a valid token


def token_required(
    token: HTTPAuthorizationCredentials = Depends(token_auth_scheme),
    request: Request = None,
    db: Session = None
):
    """
    Dependency that ensures a valid token is provided in the request.
    Enforces 'read-only' mode if specified in the DB config properties.
    Restricts all write operations (POST, PUT, PATCH, DELETE) in read-only mode
    unless explicitly whitelisted.
    """
    if db is None:
        raise HTTPException(status_code=500, detail="Database session is required")

    # Extract the token string from the HTTPBearer scheme
    token_str = token.credentials
    valid, message, data, decoded = token_valid(token_str)  # Validate the token
    
    if not valid:
        raise HTTPException(
            status_code=401,
            detail="Invalid access token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # Extract username from decoded token and set on request state for audit logging
    username = decoded.get('sub', '') if decoded else ''
    if request and hasattr(request, 'state'):
        request.state.user = username

    # Define write operations that should be restricted in read-only mode
    WRITE_OPERATIONS = {"POST", "PUT", "PATCH", "DELETE"}

    # Fetch 'enable_read_only' from DB config
    enable_read_only = (
        db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == "enable_read_only")
        .first()
    )
    enable_read_only = enable_read_only.config_value.lower() == "true" if enable_read_only else False

    if enable_read_only and request.method in WRITE_OPERATIONS:
        # Fetch the whitelisted endpoints
        whitelisted_endpoints = (
            db.query(DBConfigProperties)
            .filter(DBConfigProperties.config_key == "whitelisted_readonly_routes")
            .first()
        )
        
        # Parse whitelisted endpoints with error handling
        try:
            whitelisted_endpoints = (
                json.loads(whitelisted_endpoints.config_value)
                if whitelisted_endpoints and whitelisted_endpoints.config_value
                else {}
            )
        except json.JSONDecodeError as e:
            app_logger.error(f"Invalid JSON in whitelisted_readonly_routes config: {e}")
            app_logger.error(f"Raw config value: {whitelisted_endpoints.config_value if whitelisted_endpoints else 'None'}")
            # Fallback to empty whitelist if JSON is invalid
            whitelisted_endpoints = {}

        # Check if the current method and endpoint are whitelisted
        current_method = request.method
        current_route = request.url.path
        allowed_routes = whitelisted_endpoints.get(current_method, [])

        # Special case: Allow config updates only for enable_read_only
        # This prevents users from getting locked out of their system
        if current_route == "/api/middle-layer/db-config-properties/" and current_method == "PUT":
            # Only allow updates to enable_read_only configuration key
            try:
                body = request._body if hasattr(request, '_body') else None
                if body:
                    payload = json.loads(body.decode('utf-8') if isinstance(body, bytes) else body)
                    config_key = payload.get('config_key', '')
                    
                    if config_key != 'enable_read_only':
                        raise HTTPException(
                            status_code=403,
                            detail=f"Configuration updates for '{config_key}' are not allowed in read-only mode.",
                        )
                    
                    app_logger.info("Allowing enable_read_only config update to prevent read-only lockout")
                else:
                    # If we can't read the body, block the request in read-only mode
                    raise HTTPException(
                        status_code=403,
                        detail="Configuration updates are not allowed in read-only mode.",
                    )
            except (json.JSONDecodeError, AttributeError):
                # If we can't parse the body, block the request in read-only mode
                raise HTTPException(
                    status_code=403,
                    detail="Invalid configuration update request in read-only mode.",
                )
        elif current_route not in allowed_routes:
            raise HTTPException(
                status_code=403,
                detail=f"{current_method} operations are not allowed in read-only mode for this endpoint.",
            )

    return {
        "valid": valid,
        "message": message,
        "data": data,
        "token": token_str,
        "decoded": decoded
    }