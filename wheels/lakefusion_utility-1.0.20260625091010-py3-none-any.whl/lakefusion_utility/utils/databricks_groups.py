"""
Databricks group / UC-grant helpers — re-export shim.

The source of truth lives in ``lakefusion_core_engine.utils.databricks_groups``.
This module exists only so that existing backend imports of the form

    from lakefusion_utility.utils.databricks_groups import ensure_account_group

continue to work. New code should import directly from
``lakefusion_core_engine.utils.databricks_groups``.

Architectural rule: shared code lives in ``lakefusion_core_engine`` so that
notebooks (which install only the core wheel) do not need ``lakefusion_utility``.
"""

from lakefusion_core_engine.utils.databricks_groups import (  # noqa: F401
    ensure_account_group,
    grant_uc_object_permissions,
    add_group_members_by_email,
)
