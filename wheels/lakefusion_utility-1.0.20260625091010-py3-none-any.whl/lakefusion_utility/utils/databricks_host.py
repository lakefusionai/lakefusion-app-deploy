"""Single source of truth for the Databricks host URL.

Databricks Apps inject `DATABRICKS_HOST` *without* the `https://` scheme
(e.g. `adb-xxxx.x.azuredatabricks.net`). The UI and the SDK
both need a full URL with scheme, so a single helper normalises the env
read across every backend service and avoids ten near-identical lines
of `os.environ.get('DATABRICKS_HOST', '')`-then-prepend logic drifting
out of sync.

Backward compatibility:
- If the env value already includes `http://` or `https://`, returned as-is.
- If the env is unset, returns empty string (existing fallback semantics
  every caller already handles).
- If the env value is bare host, returns `https://<host>`.
"""

import os
import re


def get_workspace_id() -> str:
    """Extract the numeric workspace ID from DATABRICKS_HOST.
    Returns empty string if not found."""
    host = os.environ.get("DATABRICKS_HOST", "")
    match = re.search(r'adb-(\d+)', host)
    return match.group(1) if match else ""


def get_databricks_host() -> str:
    """Return the Databricks workspace URL with an `https://` scheme guaranteed."""
    host = os.environ.get("DATABRICKS_HOST", "").strip().rstrip("/")

    if not host:
        return ""

    # Strip any existing scheme before re-applying, so double-calls are idempotent
    if host.startswith("https://"):
        host = host[len("https://"):]
    elif host.startswith("http://"):
        host = host[len("http://"):]

    return f"https://{host}"
