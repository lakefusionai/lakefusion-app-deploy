"""
Utility to detect Databricks permission-related errors and convert them
to HTTP 403 responses.

When RBAC is enforced by Databricks (via Unity Catalog grants, job ACLs,
endpoint permissions, etc.), any user who lacks the required permissions
will receive an error from Databricks.  This module detects those errors
and raises an HTTP 403 so that the frontend can show a proper
Access Denied page instead of a generic toast error.

Usage in service-layer except blocks:
    from lakefusion_utility.utils.dbx_error_handler import raise_on_dbx_permission_error

    try:
        data = sqlservice_conn.execute_dataset(query)
    except HTTPException:
        raise
    except Exception as e:
        raise_on_dbx_permission_error(e)          # raises 403 if permission error
        raise HTTPException(status_code=500, ...)  # fallback for other errors
"""

import re
from typing import Optional
from fastapi import HTTPException
from lakefusion_utility.utils.logging_utils import get_logger

app_logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Permission-error detection
# ---------------------------------------------------------------------------

# Patterns that indicate a Databricks permission / access-denied error.
# Checked against str(exception) with re.IGNORECASE.
_PERMISSION_PATTERNS = [
    r"PERMISSION_DENIED",
    r"INSUFFICIENT_PRIVILEGES",
    r"User does not have .+ on",
    r"does not have .+ privilege",
    r"not authorized to perform",
    r"DENIED_PERMISSION",
    r"permission denied",
    r"insufficient privileges",
    r"does not have permission",
    r"ACCESS_DENIED",
]

_COMPILED_PATTERNS = [re.compile(p, re.IGNORECASE) for p in _PERMISSION_PATTERNS]


def is_dbx_permission_error(exc: Exception) -> bool:
    """Return True if *exc* looks like a Databricks permission / access-denied error."""
    # 1. Direct SDK PermissionDenied (databricks.sdk.errors.PermissionDenied)
    try:
        from databricks.sdk.errors import PermissionDenied
        if isinstance(exc, PermissionDenied):
            return True
    except ImportError:
        pass

    # 2. Check the error message for known permission patterns
    error_msg = str(exc)
    for pattern in _COMPILED_PATTERNS:
        if pattern.search(error_msg):
            return True

    # 3. HTTP 403 from the requests library
    response = getattr(exc, "response", None)
    if response is not None and getattr(response, "status_code", None) == 403:
        return True

    return False


def raise_on_dbx_permission_error(
    exc: Exception,
    context: Optional[str] = None,
    entity_name: Optional[str] = None,
    owner_email: Optional[str] = None,
) -> None:
    """If *exc* is a Databricks permission error, raise ``HTTPException(403)``.

    Call this at the TOP of a generic ``except Exception`` block, before
    the fallback 500 handler.  If the exception is *not* a permission
    error this function returns normally (does nothing).

    Args:
        exc: The caught exception.
        context: Optional human-readable context string for logging
                 (e.g. "fetch entity profile").
        entity_name: Optional entity name for the permission denied page.
        owner_email: Optional entity owner email for the permission denied page.
    """
    if not is_dbx_permission_error(exc):
        return

    ctx = f" while attempting to {context}" if context else ""
    app_logger.warning(
        "Databricks permission error detected%s: %s", ctx, exc
    )

    owner_hint = f" Please contact the entity owner ({owner_email}) to request access." if owner_email else " Please contact your administrator to request access."

    detail: dict = {
        "message": (
            f"You do not have the necessary permissions to access this resource.{owner_hint}"
        ),
        "context": context,
    }
    if entity_name:
        detail["entity_name"] = entity_name
    if owner_email:
        detail["owner_email"] = owner_email

    raise HTTPException(
        status_code=403,
        detail=detail,
    )
