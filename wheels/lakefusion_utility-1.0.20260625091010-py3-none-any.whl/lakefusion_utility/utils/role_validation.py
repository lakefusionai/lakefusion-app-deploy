import re
from typing import Optional, Set


ROLE_NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _-]*$")
ROLE_KEY_SEPARATORS = re.compile(r"[_\-\s]+")

# Privilege levels for role assignment hierarchy enforcement.
# Higher number = more privileged. An actor can only assign roles
# whose level is <= the actor's own highest role level.
_ROLE_PRIVILEGE_LEVEL = {
    "data steward": 10,
    "developer": 20,
    "admin": 30,
}


def normalize_role_name(role_name: Optional[str]) -> str:
    return (role_name or "").strip()


def canonical_role_key(role_name: Optional[str]) -> str:
    """Normalize a role into a stable comparison key for authorization checks."""
    normalized = normalize_role_name(role_name).lower()
    if not normalized:
        return ""
    return ROLE_KEY_SEPARATORS.sub(" ", normalized).strip()


def role_privilege_level(role_name: Optional[str]) -> int:
    """Return the privilege level for a role (0 for unknown roles)."""
    return _ROLE_PRIVILEGE_LEVEL.get(canonical_role_key(role_name), 0)


def max_privilege_level(role_names: Set[str]) -> int:
    """Return the highest privilege level among a set of role names."""
    if not role_names:
        return 0
    return max(role_privilege_level(r) for r in role_names)


def can_assign_role(actor_roles: Set[str], target_role_name: str) -> bool:
    """Check whether an actor with *actor_roles* may assign *target_role_name*.

    Enforces a strict privilege hierarchy: an actor can only assign roles
    whose privilege level is at or below the actor's highest role level.
    This prevents, for example, a Data Steward from assigning Developer
    or Admin, and a Developer from assigning Admin.
    """
    actor_level = max_privilege_level(actor_roles)
    target_level = role_privilege_level(target_role_name)
    # Unknown target roles (level 0) require Admin (level 30) to assign,
    # preventing privilege escalation via custom/unrecognized role names.
    if target_level == 0:
        return actor_level >= _ROLE_PRIVILEGE_LEVEL["admin"]
    return actor_level >= target_level


def validate_role_name(role_name: Optional[str]) -> str:
    normalized = normalize_role_name(role_name)
    if not normalized:
        raise ValueError("Role name is required")
    if not ROLE_NAME_PATTERN.fullmatch(normalized):
        raise ValueError(
            "Invalid role name. Use letters, numbers, spaces, hyphens, and underscores only."
        )
    return normalized
