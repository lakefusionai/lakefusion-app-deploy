import traceback
from datetime import datetime
from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload
from sqlalchemy.orm import Session
from lakefusion_utility.models.entity import Entity, EntityDnB, EntityAttributes, EntityDatasetMapping, EntityDatasetMappingCreate, \
    DatasetDetails, EntityDatasetMappingResponse, SurvivorshipRulesCreate, SurvivorshipRule, EntityDnBCreate, EntitySchema, ValidationFunction, \
    EntityCreate, EntityAttributeCreate, SurvivorshipRulesAttributes, ValidationFunctionCreate, DatasetSchema, ReferenceDatasetSchema
from lakefusion_utility.models.dataset import Dataset
from lakefusion_utility.models.integration_hub import Integration_Hub
from lakefusion_utility.services.feature_flags_service import FeatureFlagService
from lakefusion_utility.services.complex_type_validation import (
    is_complex_attribute,
    can_be_identifier_or_label,
    validate_complex_type_payload,
)
from lakefusion_utility.models.databricks_model import Model_Databricks_Job, Model_Experiment, Model_Databricks_Entity_Search_Job
from lakefusion_utility.models.profiling_tasks import ProfilingTask
from lakefusion_utility.models.quality_tasks import QualityTask
from lakefusion_utility.models.base_prompt import BasePromptCreate,BasePrompt
from fastapi import HTTPException, status
from lakefusion_utility.utils.app_db import db_commit_auto_rollback  # Import the db_commit_auto_rollback function
from lakefusion_utility.utils.logging_utils import get_logger
from sqlalchemy import and_
from lakefusion_utility.utils.databricks_util import DataSetSQLService, CatalogService, NotebookService
from lakefusion_utility.models.dbconfig import DBConfigProperties
from lakefusion_utility.models.httpresponse import HttpResponse
from typing import Optional
from lakefusion_utility.models.dataset import DatasetCreate
from lakefusion_utility.models.dataset import Dataset
from lakefusion_utility.models.profiling_tasks import ProfilingTask
from lakefusion_utility.models.quality_tasks import (
    QualityTask,
    TaskCreate, NotebookConfigUpdate
)
from lakefusion_utility.models.match_maven import Model_ExperimentCreate, LLM_Model, Embedding_Model, Config_Threshold, EntityAttributes as MatchMavenEntityAttributes, Model_ExperimentUpdateRequest
import tempfile
import zipfile
import os
import json
from fastapi.responses import FileResponse
import shutil
from typing import List
import numpy as np
from sqlalchemy.orm import joinedload
# Set up logging
app_logger = get_logger(__name__)

def normalize_response(data):
    normalized = []
    for item in data:
        obj = dict(item)

        # Handle columns field - can be numpy array, JSON string, or already a list
        columns = obj.get("columns")
        if isinstance(columns, np.ndarray):
            obj["columns"] = columns.tolist()
        elif isinstance(columns, str):
            # Databricks SQL connector returns complex types as JSON strings
            try:
                obj["columns"] = json.loads(columns)
            except json.JSONDecodeError:
                obj["columns"] = []

        normalized.append(obj)
    return normalized

class EntityService:
    def __init__(self,db: Session):
        """Initializes the entityService with a database session.
        
        Args:
            db: SQLAlchemy session object.
        """
        self.db = db
        self.catalog_name = (
        self.db.query(DBConfigProperties)
        .filter(DBConfigProperties.config_key == "catalog_name")
        .first().config_value
    )

    def create_entity(self, entity_create):
        """Creates a new entity and saves it to the database.
        
        Args:
            entity_create: Pydantic model containing entity details.
            
        Returns:
            The created entity object.
        
        Raises:
            HTTPException: If there's an error during creation.
        """
        try:
            existing_entity = (self.db.query(Entity).filter(Entity.name == entity_create.name).first())
            if existing_entity:
                raise HTTPException(
                    status_code=409,
                    detail=f"Entity with name '{entity_create.name}' already exists."
                )
            
            # Validate entity_type
            entity_data = entity_create.dict()
            valid_entity_types = {'master', 'product', 'reference'}
            entity_type = entity_data.get('entity_type', 'master')

            # Multi-entity support: multiple product entities allowed.
            # Each gets its own Lakebase database, selected via the PIM portal entity selector.

            if entity_type not in valid_entity_types:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid entity_type '{entity_type}'. Must be one of: {sorted(valid_entity_types)}."
                )

            # Validate entity_subtype
            entity_subtype = entity_data.get('entity_subtype')
            if entity_subtype is not None:
                if entity_type == 'reference':
                    if entity_subtype not in ('flat', 'hierarchical'):
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail=f"Invalid entity_subtype '{entity_subtype}'. Must be 'flat' or 'hierarchical'."
                        )
                elif entity_type == 'product':
                    valid_product_subtypes = ('one-tiered', 'two-tiered', 'three-tiered', 'four-tiered', 'five-tiered', 'six-tiered')
                    if entity_subtype not in valid_product_subtypes:
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail=f"Invalid entity_subtype '{entity_subtype}'. Must be one of: {valid_product_subtypes}."
                        )
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="entity_subtype is only applicable for reference or product entities."
                    )

            # Product entities require entity_subtype and always use lakebase
            if entity_type == 'product':
                if not entity_subtype:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Product entities require entity_subtype (e.g. 'one-tiered', 'two-tiered', up to 'six-tiered')."
                    )
                entity_data['storage_type'] = 'lakebase'

            # Validate storage_type
            valid_storage_types = {'delta', 'lakebase'}
            storage_type = entity_data.get('storage_type', 'delta')
            if storage_type not in valid_storage_types:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid storage_type '{storage_type}'. Must be one of: {sorted(valid_storage_types)}."
                )

            # Create a new entity instance
            db_entity = Entity(**entity_data)
            self.db.add(db_entity)
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(db_entity)

            # Provision Databricks RBAC groups (LAKEFUSION_DEVELOPER_<NAME> +
            # LAKEFUSION_DATA_STEWARD_<NAME>), persist their SCIM ids on the
            # entity, add the creator to both, and apply schema/volume grants.
            # Failures are logged but do not roll back the entity — a backfill
            # pass (or the pipeline-time RBACPermissionsExecutor) will retry.
            try:
                if not FeatureFlagService._is_feature_flag_enabled(
                    self.db, "ENABLE_USER_MANAGEMENT"
                ):
                    app_logger.info(
                        f"RBAC provisioning skipped for entity '{db_entity.name}' "
                        f"— ENABLE_USER_MANAGEMENT is disabled"
                    )
                    return db_entity

                from lakefusion_utility.services.rbac_provisioning_service import (
                    RBACProvisioningService,
                )
                provisioner = RBACProvisioningService(
                    db=self.db, catalog_name=self.catalog_name
                )
                provisioner.provision_entity(
                    db_entity, creator_email=db_entity.created_by
                )
                db_commit_auto_rollback(db=self.db)
                self.db.refresh(db_entity)
            except (RuntimeError, FileNotFoundError, KeyError, ModuleNotFoundError) as rbac_config_err:
                # Config/code error — entity is created but provisioning cannot proceed
                # until ops fixes the underlying issue. Surface as ERROR so it pages
                # operators rather than being buried in warnings.
                app_logger.error(
                    f"RBAC provisioning config error for entity '{db_entity.name}' "
                    f"({type(rbac_config_err).__name__}): {rbac_config_err}"
                )
            except Exception as rbac_err:
                # Transient Databricks API / network error — backfill pass or the
                # pipeline-time RBACPermissionsExecutor will reconcile idempotently.
                app_logger.warning(
                    f"RBAC provisioning failed (transient) for entity '{db_entity.name}' "
                    f"({type(rbac_err).__name__}): {rbac_err}"
                )

            return db_entity

        except IntegrityError:
            self.db.rollback()
            # Handles race condition (two requests at same time)
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Entity name already exists"
            )

        except HTTPException:
            raise  # rethrow clean HTTP errors

        except Exception as e:
            self.db.rollback()
            app_logger.exception("Unable to create entity")
            raise HTTPException(
                status_code=500,
                detail="Failed to create entity"
            )

    def read_entity_tags(self,is_active: bool = True):
        """Retrieves entities from the database with all related data.
        
        Args:
            is_active: Filter entities by their active status.
            
        Returns:
            A list of entities with all related data.
        """
        try:
            entity_query = (
                self.db.query(Entity)
                .outerjoin(Entity.attributes)
                .outerjoin(Entity.dataset_mappings)
                .outerjoin(Entity.survivorship)
                .outerjoin(Entity.validation_functions)
                .outerjoin(Entity.dnb_integration)
            )

            if is_active:
                entity_query = entity_query.filter(Entity.is_active == is_active)
            # Get distinct entities
            entities = entity_query.all()
            for entity in entities:
                entity.tags=[]
                if entity.integration_hub and entity.entity_type == "master":
                    entity.is_traditional_pipeline = entity.integration_hub.is_traditional_pipeline
                    entity.is_golden_deduplication_pipeline = entity.integration_hub.is_golden_deduplication_pipeline
                    entity.job_id_1 = entity.integration_hub.job_id_1
                    entity.job_id_2 = entity.integration_hub.job_id_2
                    entity.pipeline_mode = entity.integration_hub.pipeline_mode or "separate"
                elif entity.integration_hub and entity.entity_type == "reference":
                    entity.is_sync_pipeline = True if entity.integration_hub.job_id else False
                    entity.job_id = entity.integration_hub.job_id
                elif entity.entity_type == "master":
                    entity.is_traditional_pipeline = None
                    entity.is_golden_deduplication_pipeline = None
                    entity.job_id_1 = None
                    entity.job_id_2 = None
                    entity.pipeline_mode = None
                else:
                    entity.is_sync_pipeline = False
                    entity.job_id = None
            is_reference_management_enabled = FeatureFlagService._is_feature_flag_enabled(
                self.db, "ENABLE_REFERENCE_DATA_MANAGEMENT"
            )

            if is_reference_management_enabled:
                valid_entities = [
                    entity for entity in entities
                    if entity.integration_hub or entity.entity_type == "reference"
                ]
            else:
                valid_entities = [entity for entity in entities if entity.integration_hub]

            return valid_entities
    
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entities. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entities: {str(e)}"
            )
        
    def read_entity(
        self,
        is_active: Optional[bool] = None,
        entity_type: Optional[str] = None,
        sort_by: str = "created_at",
        sort_order: str = "desc",
        limit: Optional[int] = None,
        offset: int = 0
    ):
        """Retrieves entities from the database with filtering, sorting, and pagination options."""
        try:
            # Validate sort_order parameter
            if sort_order.lower() not in ['asc', 'desc']:
                raise HTTPException(status_code=400, detail="sort_order must be either 'asc' or 'desc'")
            
            # Validate sort_by field exists on the Entity model
            if not hasattr(Entity, sort_by):
                raise HTTPException(status_code=400, detail=f"Invalid sort field: {sort_by}")
            
            # Validate limit and offset parameters
            if limit is not None and limit < 0:
                raise HTTPException(status_code=400, detail="limit must be non-negative")
            
            if offset < 0:
                raise HTTPException(status_code=400, detail="offset must be non-negative")
            
            # Determine effective entity_type (treat empty string as None)
            effective_type = entity_type if entity_type else None

            # Build query with eager loading to prevent DetachedInstanceError
            entity_query = (
                self.db.query(Entity)
                .options(
                    joinedload(Entity.attributes),
                    joinedload(Entity.dataset_mappings),
                    joinedload(Entity.dnb_integration),
                )
            )

            rdm_enabled = FeatureFlagService._is_feature_flag_enabled(
                self.db, "ENABLE_REFERENCE_DATA_MANAGEMENT"
            )

            if effective_type == "reference":
                if not rdm_enabled:
                    return []
                entity_query = entity_query.filter(Entity.entity_type == "reference")
            elif effective_type == "master":
                entity_query = (
                    entity_query
                    .options(
                        joinedload(Entity.survivorship),
                        joinedload(Entity.validation_functions),
                    )
                    .filter(Entity.entity_type == "master")
                )
            else:
                entity_query = entity_query.options(
                    joinedload(Entity.survivorship),
                    joinedload(Entity.validation_functions),
                )
                if not rdm_enabled:
                    entity_query = entity_query.filter(Entity.entity_type != "reference")

            if is_active is not None:
                entity_query = entity_query.filter(Entity.is_active == is_active)
    
            # Apply sorting
            sort_field = getattr(Entity, sort_by)
            if sort_order.lower() == 'desc':
                entity_query = entity_query.order_by(sort_field.desc())
            else:
                entity_query = entity_query.order_by(sort_field.asc())

            if offset > 0:
                entity_query = entity_query.offset(offset)

            if limit is not None and limit > 0:
                entity_query = entity_query.limit(limit)

            entities = entity_query.all()
            # Deduplicate entities caused by joinedload producing multiple rows
            seen_ids = set()
            unique_entities = []
            for e in entities:
                if e.id not in seen_ids:
                    seen_ids.add(e.id)
                    unique_entities.append(e)
            entities = unique_entities

            # Force-compute @property values while session is still open
            # This prevents DetachedInstanceError during FastAPI serialization
            for entity in entities:
                # Access these properties now so they're evaluated with an active session
                _ = entity.integration_task
                _ = entity.attributes_mapped
                _ = entity.missing_mappings

            # Cache the computed values on each entity so they survive session close
            results = []
            for entity in entities:
                # Store computed property values as regular attributes
                entity._cached_integration_task = entity.integration_task
                entity._cached_attributes_mapped = entity.attributes_mapped
                entity._cached_missing_mappings = entity.missing_mappings
                results.append(entity)

            app_logger.info(
                f"Successfully retrieved {len(entities)} entities with filters: "
                f"is_active={is_active}, entity_type={effective_type}, "
                f"sort_by={sort_by}, sort_order={sort_order}, "
                f"limit={limit}, offset={offset}"
            )
            return results
    
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entities. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entities: {str(e)}"
            )


    def delete_entity(self, entity_id: int,entity_type: Optional[str]=""):
        """Deletes an entity by ID permanently along with all related records.
        
        Args:
            entity_id: The ID of the entity to delete.
            
        Returns:
            A confirmation message or the deleted entity object.
            
        Raises:
            HTTPException:
                - 404 if the entity is not found
                - 400 if the entity is a reference entity still mapped to attributes in other entities
                - 500 for system errors
        """
        try:
            # Start a transaction to ensure all deletes succeed or none do
            # with self.db.begin():
                # First, check if the entity exists
            db_entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
            if db_entity is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail={
                        "status": "error",
                        "message": "Entity not found",
                        "data": None
                    }
                )
            # Block deletion if this is a reference entity that is still mapped
            # to attributes in other entities (via type_config.reference_entity_id).
            if getattr(db_entity, 'entity_type', None) == 'reference':
                referencing_attrs = (
                    self.db.query(EntityAttributes)
                    .filter(
                        EntityAttributes.is_active == True,
                        EntityAttributes.type == 'REFERENCE_ENTITY',
                        EntityAttributes.entity_id != entity_id,
                    )
                    .all()
                )
                mapped_attrs = [
                    a for a in referencing_attrs
                    if a.type_config and a.type_config.get('reference_entity_id') == entity_id
                ]
                if mapped_attrs:
                    referencing_entity_ids = list({a.entity_id for a in mapped_attrs})
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": (
                                f"Cannot delete reference entity {entity_id} because it is still mapped "
                                f"in {len(mapped_attrs)} attribute(s) across entities (IDs: {referencing_entity_ids}). "
                                "Remove those mappings first."
                            ),
                            "data": {
                                "referencing_attribute_ids": [a.id for a in mapped_attrs],
                                "referencing_entity_ids": referencing_entity_ids,
                            }
                        }
                    )

            # Delete related records in the correct order (children first)
            # 1. Delete from integration_hub (references model_experiments)
            self.db.query(Integration_Hub).filter(Integration_Hub.entity_id == entity_id).delete(synchronize_session=False)
            
            # 2. Delete from match_maven_job (references model_experiments)
            self.db.query(Model_Databricks_Job).filter(Model_Databricks_Job.entity_id == entity_id).delete(synchronize_session=False)
            
            # 3. Delete from model_experiments
            self.db.query(Model_Experiment).filter(Model_Experiment.entity_id == entity_id).delete(synchronize_session=False)
            
            # 4. Delete from entity_search_databricks_job
            self.db.query(Model_Databricks_Entity_Search_Job).filter(Model_Databricks_Entity_Search_Job.entity_id == entity_id).delete(synchronize_session=False)
            
            # 5. Delete from validation functions
            self.db.query(ValidationFunction).filter(ValidationFunction.entity_id == entity_id).delete(synchronize_session=False)
            
            # 6. Delete from survivorship rules
            self.db.query(SurvivorshipRule).filter(SurvivorshipRule.entity_id == entity_id).delete(synchronize_session=False)
            
            # 7. Delete from entity dataset mappings
            self.db.query(EntityDatasetMapping).filter(EntityDatasetMapping.entity_id == entity_id).delete(synchronize_session=False)
            
            # 8. Delete from entity attributes
            self.db.query(EntityAttributes).filter(EntityAttributes.entity_id == entity_id).delete(synchronize_session=False)
            
            # 9. Delete from entity dnb
            self.db.query(EntityDnB).filter(EntityDnB.entity_id == entity_id).delete()
            
            # 10. Delete from profiling_tasks (if exists)
            self.db.query(ProfilingTask).filter(ProfilingTask.entity_id == entity_id).delete(synchronize_session=False)
            
            # 11. Delete from quality_tasks (if exists)
            self.db.query(QualityTask).filter(QualityTask.entity_id == entity_id).delete(synchronize_session=False)
            
            # Finally, delete the entity itself
            self.db.delete(db_entity)
            
            # Commit all changes
            self.db.commit()
            
            return HttpResponse(
                status="success",
                message=f"Entity {entity_id} and all related records deleted successfully",
                data=None
            )
        # Handle specific HTTP exceptions
        except HTTPException as http_exc:
            app_logger.warning(f"HTTPException while creating record: {http_exc.status_code} - {http_exc.detail}")
            raise http_exc

        except Exception as e:
            # Rollback will happen automatically due to the transaction context
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete entity {entity_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail={
                "status": "error",
                "message": f"Failed to delete entity: {str(e)}",
                "data": None
            })

    def update_entity_metadata_file_for_integration_job(self, token: str, entity_id: int):
        """
        Run only when an entity is part of an integration job.
        Updates the metadata file for an entity's integration job in the volume folder.

        Args:
            token (str): Authentication token.
            entity_id (int): The ID of the entity.

        Raises:
            HTTPException: If the entity is not found or an error occurs.
        """
        try:
            entity_service = EntityService(self.db)
            entity = entity_service.get_full_entity_by_id(entity_id).dict()

            if not entity:
                app_logger.error(f"Entity not found for ID {entity_id}")
                raise HTTPException(status_code=404, detail="Entity not found")
            
            volume_id = "prod"
            create_volume_folder = CatalogService(token, self.db)
            folder_path = create_volume_folder.create_volume_folder(entity_id, volume_id)
            if folder_path:
                create_volume_folder.upload_data_as_json(folder_path, 'entity.json', entity)
                app_logger.info(f"Metadata file updated for entity {entity_id} in volume {volume_id}")
            else:
                app_logger.error(f"Failed to create volume folder for entity {entity_id} and volume_id {volume_id}")
                raise HTTPException(status_code=500, detail="Failed to create volume folder")
            
        except HTTPException as http_exc:
            raise http_exc
        except Exception as e:
            app_logger.exception(f'Unable to update metadata file for entity {entity_id}. Reason - {str(e)}')
            raise HTTPException(status_code=500, detail={
                "status": "error",
                "message": f"Failed to update metadata file: {str(e)}",
                "data": None
            })

    def get_entity_by_id(self, entity_id: int):
        """Retrieves a entity object by its ID.
        
        Args:
            entity_id: The ID of the entity to retrieve.
            
        Returns:
            The entity object.
        
        Raises:
            HTTPException: If the entity is not found.
        """
        try:
            # Fetch the entity by ID
            db_entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
            if db_entity is None or not db_entity.is_active:
                return None
            
            if db_entity.integration_hub and db_entity.entity_type == "master":
                db_entity.is_traditional_pipeline = db_entity.integration_hub.is_traditional_pipeline
                db_entity.is_golden_deduplication_pipeline = db_entity.integration_hub.is_golden_deduplication_pipeline
                db_entity.job_id_1 = db_entity.integration_hub.job_id_1
                db_entity.job_id_2 = db_entity.integration_hub.job_id_2
                db_entity.pipeline_mode = db_entity.integration_hub.pipeline_mode or "separate"
            elif db_entity.integration_hub and db_entity.entity_type == "reference":
                db_entity.is_sync_pipeline = True if db_entity.integration_hub.job_id else False
                db_entity.job_id = db_entity.integration_hub.job_id
            elif db_entity.entity_type == "master":
                db_entity.is_traditional_pipeline = None
                db_entity.is_golden_deduplication_pipeline = None
                db_entity.job_id_1 = None
                db_entity.job_id_2 = None
                db_entity.pipeline_mode = None
            else:
                db_entity.is_sync_pipeline = False
                db_entity.job_id = None
            
            return db_entity  # Return the found entity
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity with ID {entity_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch entity: {str(e)}")

    def get_full_entity_by_id(self, entity_id: int)->EntitySchema:
        """Retrieves a entity object by its ID.
        
        Args:
            entity_id: The ID of the entity to retrieve.
            
        Returns:
            The entity object.
        
        Raises:
            HTTPException: If the entity is not found.
        """
        try:
            # Fetch the entity by ID
            db_entity = (
                self.db.query(Entity).filter(Entity.id == entity_id)
                .outerjoin(Entity.attributes)
                .outerjoin(Entity.dataset_mappings)
                .outerjoin(Entity.survivorship)
                .outerjoin(Entity.validation_functions)
                .outerjoin(Entity.dnb_integration)
            ).first()

            # Check if entity exists BEFORE processing
            if db_entity is None:
                raise HTTPException(
                    status_code=404, 
                    detail=f"Entity with ID {entity_id} not found"
                )

            # check cleaned table existence for datasets mapped to entity
            use_cleaned_tables = self.db.query(EntityDatasetMapping).filter(EntityDatasetMapping.entity_id == entity_id, EntityDatasetMapping.use_cleaned_table == True).all()
            # Get dataset IDs with use_cleaned_table = True
            dataset_ids_with_cleaned_table = [dtm.dataset_id for dtm in use_cleaned_tables]

            # Convert to Pydantic model for response and adjust dataset paths if cleaned tables are used
            entity_response = EntitySchema.from_orm(db_entity)
            for mapping in entity_response.dataset_mappings:
                if mapping.dataset:
                    if mapping.dataset.id in dataset_ids_with_cleaned_table:
                        mapping.dataset.path = f"{mapping.dataset.path}_cleaned"

            # Populate reference_dataset for master entities only (requires RDM flag)
            rdm_enabled = FeatureFlagService._is_feature_flag_enabled(
                self.db, "ENABLE_REFERENCE_DATA_MANAGEMENT"
            )
            if rdm_enabled and entity_response.entity_type == "master":
                ref_attrs = (
                    self.db.query(EntityAttributes)
                    .filter(
                        EntityAttributes.entity_id == entity_id,
                        EntityAttributes.type == "REFERENCE_ENTITY",
                        EntityAttributes.is_active == True,
                    )
                    .all()
                )
                seen_ids: set = set()
                ref_datasets = []
                for attr in ref_attrs:
                    if not attr.type_config:
                        continue
                    ref_id = attr.type_config.get("reference_entity_id")
                    if ref_id is None or ref_id in seen_ids:
                        continue
                    seen_ids.add(ref_id)
                    ref_entity = self.db.query(Entity).filter(Entity.id == ref_id).first()
                    if not ref_entity:
                        continue
                    name_snake = ref_entity.name.lower().replace(" ", "_")
                    ref_datasets.append(ReferenceDatasetSchema(
                        reference_entity_id=ref_id,
                        reference_entity_name=name_snake,
                        # Master table IS the current state — one row per
                        # ref_lakefusion_id, business columns only. The old
                        # _reference_full_vw (is_current=TRUE view over the
                        # consolidated SCD-2 table) was removed when master/
                        # audit split, so point readers/joins at the master
                        # directly. No is_current filter needed (master has
                        # no such column); SCD-2 history lives in
                        # _reference_audit_prod.
                        reference_entity_table_path=f"{self.catalog_name}.gold.{name_snake}_reference_prod",
                        reference_entity_view_path=f"{self.catalog_name}.gold.{name_snake}_reference_prod",
                        reference_entity_storage_type=ref_entity.storage_type or "delta",
                    ))
                entity_response.reference_dataset = ref_datasets

            return entity_response
        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity with ID {entity_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch entity: {str(e)}")
    
    def toggle_entity_active(self, entity_id: int):
        """Toggles the `is_active` flag of a entity.
        
        Args:
            entity_id: The ID of the entity to update.
            is_active: The new `is_active` status.
            
        Returns:
            The updated entity object.
        """
        try:
            db_entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
            if db_entity is None:
                return None
            

            # If deactivating a reference entity, block if it is still mapped to other entities
            is_deactivating = db_entity.is_active  # currently active → about to become inactive
            if is_deactivating and getattr(db_entity, 'entity_type', None) == 'reference':
                referencing_attrs = (
                    self.db.query(EntityAttributes)
                    .filter(
                        EntityAttributes.is_active == True,
                        EntityAttributes.type == 'REFERENCE_ENTITY',
                        EntityAttributes.entity_id != entity_id,
                    )
                    .all()
                )
                mapped_attrs = [
                    a for a in referencing_attrs
                    if a.type_config and a.type_config.get('reference_entity_id') == entity_id
                ]
                if mapped_attrs:
                    referencing_entity_ids = list({a.entity_id for a in mapped_attrs})
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": (
                                f"Cannot deactivate reference entity {entity_id} because it is still mapped "
                                f"in {len(mapped_attrs)} attribute(s) across entities (IDs: {referencing_entity_ids}). "
                                "Remove those mappings first."
                            ),
                            "data": {
                                "referencing_attribute_ids": [a.id for a in mapped_attrs],
                                "referencing_entity_ids": referencing_entity_ids,
                            }
                        }
                    )

            db_entity.is_active = not db_entity.is_active
            db_commit_auto_rollback(db=self.db)
            return db_entity
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update entity active status. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to update entity active status: {str(e)}")
        
    def export_entity(self, entity_id: int, check: dict):
        """
        Export an entity with profiling tasks, quality tasks, approved/published models,
        and DBC archives of quality task notebooks.
        
        Args:
            entity_id: The ID of the entity to export.

        Returns:
            A zip file containing the entity details and related artifacts.
            The ZIP includes:
            - entity.json
            - profiling_tasks.json
            - quality_tasks.json
            - model_experiments.json
            - dq_notebooks/<quality_task_id>.dbc for each notebook
        """ 

        from lakefusion_utility.services.model_experiment_service import ExperimentService
        from lakefusion_utility.services.profiling_tasks import ProfilingTaskService
        from lakefusion_utility.services.quality_tasks import QualityTaskService
        from lakefusion_utility.models.match_maven import Model_GetExperimentResponse

        # Initialize services
        profiling_service = ProfilingTaskService(self.db)
        quality_service = QualityTaskService(self.db)
        experiment_service = ExperimentService(self.db)
        notebook_service = NotebookService(token=check["token"])

        # 1️⃣ Entity
        entity_data = self.get_full_entity_by_id(entity_id)
        if not entity_data:
            raise HTTPException(status_code=404, detail="Entity not found")
        entity_dict = entity_data.model_dump()

        # 2️⃣ Dataset IDs
        dataset_mappings = entity_dict.get("dataset_mappings", [])
        dataset_ids = [
            mapping["dataset"]["id"]
            for mapping in dataset_mappings
            if "dataset" in mapping and "id" in mapping["dataset"]
        ]

        # 3️⃣ Profiling tasks
        profiling_tasks = profiling_service.get_profiling_tasks_by_dataset_ids(dataset_ids)
        profiling_dicts = [task.as_dict() for task in profiling_tasks]

        # 4️⃣ Quality tasks
        quality_dataset_ids = [
            mapping["dataset"]["id"]
            for mapping in dataset_mappings
            if mapping.get("dataset", {}).get("quality_task_enabled")
        ]
        quality_tasks = []
        if quality_dataset_ids:
            quality_tasks = quality_service.get_quality_tasks_by_dataset_ids(quality_dataset_ids)
        quality_dicts = [task.as_dict() for task in quality_tasks]

        # 5️⃣ Models (approved/published)
        m: Model_GetExperimentResponse
        models = experiment_service.list_models(entity_id)
        filtered_models = [m for m in models if m.status in ["approved", "published"] and m.is_outdated is False]
        model_dicts = [m.model_dump() for m in filtered_models]

        # 6️⃣ Temporary JSON files
        tmp_entity_file = tempfile.NamedTemporaryFile(delete=False, suffix=".json")
        tmp_profiling_file = tempfile.NamedTemporaryFile(delete=False, suffix=".json")
        tmp_quality_file = tempfile.NamedTemporaryFile(delete=False, suffix=".json")
        tmp_models_file = tempfile.NamedTemporaryFile(delete=False, suffix=".json")

        with open(tmp_entity_file.name, "w", encoding="utf-8") as f:
            json.dump(entity_dict, f, indent=2, default=str)
        with open(tmp_profiling_file.name, "w", encoding="utf-8") as f:
            json.dump(profiling_dicts, f, indent=2, default=str)
        with open(tmp_quality_file.name, "w", encoding="utf-8") as f:
            json.dump(quality_dicts, f, indent=2, default=str)
        with open(tmp_models_file.name, "w", encoding="utf-8") as f:
            json.dump(model_dicts, f, indent=2, default=str)

        # 7️⃣ Create ZIP file
        tmp_zip_file = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
        with zipfile.ZipFile(tmp_zip_file.name, "w") as zipf:
            # Add JSON files
            zipf.write(tmp_entity_file.name, arcname=f"entity.json")
            zipf.write(tmp_profiling_file.name, arcname="profiling_tasks.json")
            zipf.write(tmp_quality_file.name, arcname="quality_tasks.json")
            zipf.write(tmp_models_file.name, arcname="model_experiments.json")

            # Add DBC notebooks under dq_notebooks/
            for task in quality_dicts:
                notebook_path = task.get("notebook_path")
                qt_id = task.get("id")
                if notebook_path and qt_id:
                    try:
                        dbc_bytes = notebook_service.export_notebook(notebook_path)
                        tmp_dbc_file = tempfile.NamedTemporaryFile(delete=False, suffix=".dbc")
                        with open(tmp_dbc_file.name, "wb") as f:
                            f.write(dbc_bytes)
                        zipf.write(tmp_dbc_file.name, arcname=f"dq_notebooks/{qt_id}.dbc")
                        os.unlink(tmp_dbc_file.name)
                    except Exception as e:
                        app_logger.warning(f"Skipping notebook {notebook_path} due to error: {e}")

        # 8️⃣ Cleanup temp JSON files
        os.unlink(tmp_entity_file.name)
        os.unlink(tmp_profiling_file.name)
        os.unlink(tmp_quality_file.name)
        os.unlink(tmp_models_file.name)

        # 9️⃣ Return ZIP
        return FileResponse(
            tmp_zip_file.name,
            media_type="application/zip",
            filename=f"entity_{entity_id}_export.zip",
        )
    
    def _restore_struct_definitions(self, attributes: list, entity_id: int, created_by: str) -> dict:
        """Recreate struct definitions embedded in imported attributes under the
        target entity and return an {old_struct_id: new_struct_id} map.

        Each STRUCT / ARRAY<STRUCT> attribute in the export carries the full
        struct schema under "struct_definition" ({id, name, fields[]}). The
        source-workspace id is meaningless here, so we recreate the struct scoped
        to the target entity (reusing an existing one of the same name when a
        re-import lands on an already-existing entity) and map the old id to the
        new one. Attributes are then remapped to the restored ids by the caller.
        """
        from lakefusion_utility.models.struct_definition import (
            StructDefinition,
            StructDefinitionCreate,
            StructFieldCreate,
        )
        from lakefusion_utility.services.struct_definition_service import (
            StructDefinitionService,
        )

        struct_service = StructDefinitionService(self.db)
        id_map: dict = {}

        for attr in attributes:
            sd = attr.get("struct_definition")
            old_id = attr.get("struct_definition_id")
            # Only STRUCT/ARRAY<STRUCT> attributes carry an embedded definition.
            if not sd or old_id is None or old_id in id_map:
                continue

            name = sd.get("name")
            if not name:
                continue

            # Reuse an existing struct of the same name in this entity (idempotent
            # re-import); names are unique per entity.
            existing = (
                self.db.query(StructDefinition)
                .filter(
                    StructDefinition.entity_id == entity_id,
                    StructDefinition.name == name,
                )
                .first()
            )
            if existing:
                id_map[old_id] = existing.id
                continue

            fields = [
                StructFieldCreate(
                    name=f.get("name"),
                    label=f.get("label"),
                    data_type=f.get("data_type"),
                    ordinal_position=f.get("ordinal_position"),
                )
                for f in (sd.get("fields") or [])
            ]
            try:
                new_sd = struct_service.create(
                    StructDefinitionCreate(
                        name=name,
                        entity_id=entity_id,
                        fields=fields,
                        created_by=created_by,
                    )
                )
                id_map[old_id] = new_sd.id
                app_logger.info(
                    f"✅ Restored struct definition '{name}' (old id={old_id} → new id={new_sd.id})"
                )
            except Exception as e:
                app_logger.warning(
                    f"⚠️ Failed to restore struct definition '{name}' (old id={old_id}): {e}"
                )

        return id_map

    async def import_entity_from_zip(self, file, check: dict):
        """
        Import an entity and its associated components (datasets, profiling tasks, etc.)
        from an uploaded ZIP file.

        Steps:
            1️⃣ Extract and parse entity.json
            2️⃣ Create datasets (skip if dataset with same path exists)
            3️⃣ Create profiling tasks (skip if task with same name exists)
            4️⃣ Create quality tasks & notebooks
            5️⃣ Create models (approved/published only)
            6️⃣ Create base prompts

        Args:
            file: Uploaded ZIP file
            check: Token validation dictionary (contains 'token' and 'decoded')

        Returns:
            dict: Parsed entity payload
        """

        from lakefusion_utility.services.dataset_service import DatasetService
        from lakefusion_utility.services.profiling_tasks import ProfilingTaskService
        from lakefusion_utility.schemas.profiling_tasks import ProfilingTaskCreate
        from lakefusion_utility.services.quality_tasks import QualityTaskService
        from lakefusion_utility.services.validation_functions_service import ValidationFunctionsService
        from lakefusion_utility.services.model_experiment_service import ExperimentService, Model_Databricks_Job_Service
        from lakefusion_utility.services.base_prompt_service import BasePromptService

        entity_payload = {}
        created_by = check.get("decoded", {}).get("sub", "")
        token = check.get("token", "")
        db_entity_id = None

        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp_zip:
            content = await file.read()
            tmp_zip.write(content)
            tmp_zip_path = tmp_zip.name

        experiment_service = ExperimentService(self.db)
        model_databricks_job_service = Model_Databricks_Job_Service(self.db)

        try:
            # Initialize Databricks notebook service
            notebook_service = NotebookService(token)

            with zipfile.ZipFile(tmp_zip_path, "r") as zipf:
                if "entity.json" not in zipf.namelist():
                    raise HTTPException(status_code=400, detail="entity.json not found in ZIP")

                with zipf.open("entity.json") as entity_file:
                    entity_payload = json.load(entity_file)

                app_logger.info("✅ Entity payload loaded successfully for import")

                # --- STEP 2: Create datasets ---
                dataset_service = DatasetService(self.db)
                dataset_mappings = entity_payload.get("dataset_mappings", [])
                dataset_fields = set(DatasetCreate.model_fields.keys())

                created_datasets = []
                skipped_datasets = []
                old_new_dataset_id_map = {}

                for mapping in dataset_mappings:
                    dataset_data = mapping.get("dataset", {})
                    if not dataset_data:
                        continue

                    try:
                        dataset_path = dataset_data.get("path")
                        if not dataset_path:
                            app_logger.warning(f"⚠️ Skipping dataset with missing 'path': {dataset_data}")
                            continue

                        # ✅ Check if dataset already exists by path
                        existing_dataset = dataset_service.get_dataset_by_path(dataset_path)
                        if existing_dataset:
                            app_logger.info(f"🔹 Dataset '{dataset_path}' already exists — skipping creation.")
                            skipped_datasets.append(existing_dataset)
                            # Map dataset in mapping to existing dataset ID
                            old_new_dataset_id_map[mapping["dataset_id"]] = existing_dataset.id
                            mapping["dataset_id"] = existing_dataset.id
                            mapping["dataset"] = DatasetSchema.from_orm(existing_dataset).model_dump()
                            continue

                        payload_dict = {k: v for k, v in dataset_data.items() if k in dataset_fields}
                        payload_dict["created_by"] = created_by

                        dataset_obj = DatasetCreate(**payload_dict)
                        created_dataset_obj: HttpResponse
                        created_dataset_obj = dataset_service.create_dataset(dataset_obj)
                        created_dataset: Dataset = created_dataset_obj.data
                        # Map dataset in mapping to existing dataset ID
                        old_new_dataset_id_map[mapping["dataset_id"]] = created_dataset.id
                        mapping["dataset_id"] = created_dataset.id
                        mapping["dataset"] = DatasetSchema.from_orm(created_dataset).model_dump()
                        created_datasets.append(created_dataset)

                    except Exception as e:
                        app_logger.warning(f"⚠️ Skipping dataset '{dataset_data.get('name')}' due to error: {e}")
                        continue

                app_logger.info(f"✅ Created {len(created_datasets)} datasets")
                app_logger.info(f"✅ Skipped {len(skipped_datasets)} datasets")

                # --- STEP 3: Import Profiling Tasks ---
                if "profiling_tasks.json" in zipf.namelist():
                    with zipf.open("profiling_tasks.json") as f:
                        profiling_tasks_data = json.load(f)

                    profiling_service = ProfilingTaskService(self.db)
                    profiling_fields = set(ProfilingTaskCreate.model_fields.keys())

                    created_profiling_tasks = []
                    for task_data in profiling_tasks_data:
                        try:
                            payload_dict = {k: v for k, v in task_data.items() if k in profiling_fields}
                            payload_dict["created_by"] = created_by

                            # Map dataset_id to the newly created dataset if exists
                            new_dataset_id = old_dataset_id = payload_dict.get("dataset_id")
                            if old_dataset_id:
                                new_dataset_id = old_new_dataset_id_map.get(old_dataset_id)

                            if new_dataset_id:
                                payload_dict["dataset_id"] = new_dataset_id

                                profiling_obj = ProfilingTaskCreate(**payload_dict)
                                created_task = profiling_service.create_profiling_task(
                                    profiling_task=profiling_obj,
                                    created_by=created_by,
                                    token=token,
                                )
                                created_profiling_tasks.append(created_task)

                        except Exception as e:
                            app_logger.warning(f"⚠️ Skipping profiling task '{task_data.get('name')}' due to error: {e}")
                            created_profiling_tasks.append(task_data)

                    app_logger.info(f"✅ Created or skipped {len(created_profiling_tasks)} profiling tasks")
                else:
                    app_logger.warning("⚠️ profiling_tasks.json not found in ZIP; skipping profiling import")

                # --- STEP 4: Import DQ Notebooks & Create/Execute Quality Tasks ---
                if "quality_tasks.json" in zipf.namelist():
                    try:
                        with zipf.open("quality_tasks.json") as f:
                            quality_tasks_data = json.load(f)

                        app_logger.info(f"✅ Found {len(quality_tasks_data)} quality tasks — preparing notebook import")

                        # Create temp folder for dq_notebooks
                        dq_notebooks_dir = tempfile.mkdtemp(prefix="dq_notebooks_")

                        # Extract all dq_notebooks/*.dbc files
                        dq_files = [f for f in zipf.namelist() if f.startswith("dq_notebooks/") and f.endswith(".dbc")]
                        if not dq_files:
                            app_logger.warning("⚠️ No dq_notebooks/*.dbc files found in ZIP")
                        else:
                            # Extract files to temp folder
                            for dq_file in dq_files:
                                zipf.extract(dq_file, dq_notebooks_dir)

                            # Build mapping of task_id -> notebook_path
                            task_path_map = {
                                str(task.get("id")): task.get("notebook_path")
                                for task in quality_tasks_data if task.get("id") and task.get("notebook_path")
                            }

                            # Initialize services
                            notebook_service = NotebookService(token)
                            quality_task_service = QualityTaskService(self.db)

                            # Iterate through extracted DBC files
                            for dq_file in dq_files:
                                file_name = os.path.basename(dq_file)  # e.g., "83.dbc"
                                task_id = os.path.splitext(file_name)[0]  # "83"
                                target_path = task_path_map.get(task_id)

                                if not target_path:
                                    app_logger.warning(f"⚠️ Skipping notebook {file_name} — no matching quality task found")
                                    continue

                                local_path = os.path.join(dq_notebooks_dir, dq_file)

                                # --- Notebook Import (optional, errors ignored) ---
                                try:
                                    app_logger.info(f"📥 Importing notebook {file_name} → {target_path}")
                                    notebook_service.import_dbc_notebook(local_path=local_path, target_path=target_path)
                                    app_logger.info(f"✅ Imported DQ notebook for task {task_id} → {target_path}")
                                except Exception as e:
                                    app_logger.warning(f"⚠️ Notebook import failed for {file_name}: {e} — continuing with task creation")

                                # --- Create Quality Task only if it doesn't exist for the dataset ---
                                task_data = next((t for t in quality_tasks_data if str(t.get("id")) == task_id), None)
                                if not task_data:
                                    app_logger.warning(f"⚠️ No quality task data found for task_id {task_id}")
                                    continue

                                try:
                                    # Map dataset_id to the newly created dataset if exists
                                    old_dataset_id = task_data.get("dataset_id")
                                    if old_dataset_id:
                                        new_dataset_id = old_new_dataset_id_map.get(old_dataset_id)

                                    # Skip creation if a QualityTask already exists for this dataset
                                    existing_tasks = quality_task_service.get_quality_tasks_by_dataset_ids([new_dataset_id])
                                    if existing_tasks:
                                        app_logger.info(f"ℹ️ Skipping creation — QualityTask already exists for dataset_id {new_dataset_id}")
                                        continue

                                    # Dynamically populate TaskCreate fields from JSON
                                    task_fields = set(TaskCreate.model_fields.keys())
                                    task_payload_dict = {k: v for k, v in task_data.items() if k in task_fields}
                                    task_payload_dict["dataset_id"] = new_dataset_id
                                    task_payload_dict["task_type"] = task_data.get("task_type")
                                    task_payload_dict["created_by"] = created_by

                                    task_create_obj = TaskCreate(**task_payload_dict)
                                    quality_task_obj = quality_task_service.create_task(task_create_obj, created_by)
                                    app_logger.info(f"✅ Created Quality Task {quality_task_obj.id} → {task_create_obj.name}")

                                    # --- Update Notebook Config & Create/Update Job ---
                                    params_list = task_data.get("job_info", {}).get("settings", {}).get("parameters", [])
                                    # Convert list of dicts to a single dict
                                    params_dict = {param["name"]: param.get("default") for param in params_list}
                                    notebook_config = NotebookConfigUpdate(
                                        notebook_path=target_path,
                                        config_parameters=params_dict
                                    )
                                    updated_task = quality_task_service.update_notebook_config(
                                        task_id=quality_task_obj.id,
                                        config=notebook_config,
                                        created_by=created_by,
                                        token=token
                                    )
                                    app_logger.info(f"✅ Updated notebook config and job for task {quality_task_obj.id}")

                                    # --- Execute Task ---
                                    execution_response = quality_task_service.execute_task(
                                        task_id=quality_task_obj.id,
                                        created_by=created_by,
                                        token=token
                                    )
                                    app_logger.info(f"🚀 Executed task {quality_task_obj.id} → run_id: {execution_response.get('run_id')}")

                                except Exception as e:
                                    app_logger.warning(f"⚠️ Failed to create/update/execute task {task_id}: {e}")
                                    continue

                        # Cleanup extracted notebooks
                        shutil.rmtree(dq_notebooks_dir, ignore_errors=True)

                    except Exception as e:
                        app_logger.error(f"❌ Failed to import DQ notebooks / create tasks: {e}")
                else:
                    app_logger.info("ℹ️ quality_tasks.json not found — skipping DQ notebook import & task creation")

                # --- STEP 5: Import Entity, Attributes, and Dataset Mappings ---
                try:
                    # --- STEP 5a: Create or get Entity ---
                    # Only carry keys actually present in the export. Using
                    # entity_payload.get(f) for ALL fields would pass None for any
                    # missing key, which OVERRIDES the pydantic defaults (e.g.
                    # entity_type='master', storage_type='delta') and makes
                    # create_entity reject entity_type=None ("Invalid entity_type 'None'").
                    entity_create_data = {
                        f: entity_payload[f]
                        for f in EntityCreate.model_fields.keys()
                        if f in entity_payload
                    }
                    entity_create = EntityCreate(**entity_create_data)
                    entity_create.created_by = created_by
                    
                    # Check if entity already exists
                    existing_entity = self.get_entity_by_name(entity_create.name)
                    if existing_entity:
                        db_entity = existing_entity
                        app_logger.info(f"Entity '{entity_create.name}' already exists, skipping creation.")
                    else:
                        # Create new entity
                        db_entity = self.create_entity(entity_create)
                        app_logger.info(f"✅ Created new entity '{db_entity.name}' (ID: {db_entity.id})")

                    db_entity_id = db_entity.id  # Store for potential return value

                    # --- STEP 5b (pre): Restore Struct Definitions ---
                    # STRUCT / ARRAY<STRUCT> attributes carry struct_definition_id
                    # values from the SOURCE workspace. Those ids are meaningless in
                    # the target DB — passing them through makes the attribute point at
                    # whatever struct happens to own that id here (validation only checks
                    # the id exists + is_active, not ownership), producing the wrong
                    # schema. Recreate each exported struct under the target entity and
                    # build an old_id -> new_id map to remap attributes below.
                    attributes = entity_payload.get("attributes", [])
                    old_new_struct_id_map = self._restore_struct_definitions(
                        attributes, db_entity_id, created_by
                    )

                    # --- STEP 5b: Create Entity Attributes ---
                    attribute_service = EntityAttributeService(self.db)

                    for attr in attributes:
                        # Dynamically populate EntityAttributeCreate
                        pydantic_fields = {f: attr.get(f) for f in EntityAttributeCreate.model_fields.keys()}
                        pydantic_fields["created_by"] = created_by
                        # Remap struct_definition_id from the source id to the
                        # newly-restored target id.
                        old_struct_id = pydantic_fields.get("struct_definition_id")
                        if old_struct_id is not None:
                            pydantic_fields["struct_definition_id"] = old_new_struct_id_map.get(
                                old_struct_id, old_struct_id
                            )
                        entity_attribute_create = EntityAttributeCreate(**pydantic_fields)

                        try:
                            attribute_service.create_entity_attribute(entity_attribute_create, db_entity_id, created_by=created_by)
                            app_logger.info(f"✅ Created attribute '{entity_attribute_create.name}' for entity '{db_entity.name}'")
                        except Exception as e:
                            app_logger.warning(f"⚠️ Failed to create attribute '{entity_attribute_create.name}': {e}")
                            continue

                    # --- STEP 5c: Create Dataset Mappings ---
                    dataset_mappings = entity_payload.get("dataset_mappings", [])
                    dataset_service = EntityDatasetMappingService(self.db)
                    
                    for mapping in dataset_mappings:
                        dataset_id = mapping.get("dataset_id")
                        mapping_attrs = mapping.get("attributes", [])

                        # Prepare MappingAttribute list
                        mapping_attributes_list = []
                        for ma in mapping_attrs:
                            mapping_attributes_list.append(ma)

                        # Dynamically populate Pydantic model fields
                        pydantic_fields = {f: mapping.get(f) for f in EntityDatasetMappingCreate.model_fields.keys()}
                        pydantic_fields["attributes"] = mapping_attributes_list  # ensure attributes are included
                        pydantic_fields["created_by"] = created_by
                        entity_dataset_mapping_create = EntityDatasetMappingCreate(**pydantic_fields)

                        try:
                            dataset_service.create_entity_dataset_mapping(
                                entity_dataset_mapping_create,
                                db_entity_id,
                                dataset_id,
                                token=None,  # is_integration_job = False
                                is_integration_job=False,
                                created_by=created_by
                            )
                            app_logger.info(f"✅ Created dataset mapping for entity '{db_entity.name}' → dataset {dataset_id}")
                        except Exception as e:
                            app_logger.warning(f"⚠️ Failed to create dataset mapping for dataset {dataset_id}: {e}")
                            continue

                    # --- STEP 5d: Create Survivorship Rules ---
                    if survivorship_list := entity_payload.get("survivorship", []):
                        survivorship_service = SurvivorshipRuleService(self.db)
                        for survivorship in survivorship_list:
                            try:
                                # Dynamically populate SurvivorshipRulesAttributes list
                                rules_list = []
                                for rule in survivorship.get("rules", []):
                                    try:
                                        rule_obj = SurvivorshipRulesAttributes(
                                            **{
                                                field: rule.get(field)
                                                for field in SurvivorshipRulesAttributes.model_fields.keys()
                                            }
                                        )

                                        strategy_rule = rule_obj.strategyRule
                                        strategy = rule_obj.strategy
                                        if strategy == "Source System" and isinstance(strategy_rule, list):
                                            updated_rule_ids = [
                                                old_new_dataset_id_map.get(dataset_id, dataset_id)
                                                for dataset_id in strategy_rule
                                            ]
                                            rule_obj.strategyRule = updated_rule_ids

                                        rules_list.append(rule_obj)
                                    except Exception as e:
                                        app_logger.exception(f"❌ Failed to create SurvivorshipRulesAttributes for {rule}. Reason: {e}")
                                        continue  # Skip this rule, move on to the next one

                                # Populate SurvivorshipRulesCreate using schema fields
                                survivorship_create = SurvivorshipRulesCreate(
                                    **{
                                        field: survivorship.get(field)
                                        for field in SurvivorshipRulesCreate.model_fields.keys()
                                        if field != "rules"
                                    },
                                    rules=rules_list
                                )
                                survivorship_create.created_by = created_by

                                # --- Check if survivorship rule already exists ---
                                existing_rule = survivorship_service.get_by_group_and_entity(
                                    entity_id=db_entity_id,
                                    group_name=survivorship_create.group_name
                                )

                                if existing_rule:
                                    app_logger.info(
                                        f"⚠️ Survivorship rule group '{survivorship_create.group_name}' already exists for entity '{db_entity.name}', skipping creation."
                                    )
                                    continue

                                # Create new survivorship rule
                                survivorship_service.create_survivorship_rule(
                                    survivorship_create,
                                    db_entity_id,
                                    token
                                )
                                app_logger.info(f"✅ Created survivorship rule group '{survivorship_create.group_name}' for entity '{db_entity.name}'")

                            except Exception as e:
                                message = traceback.format_exc()
                                app_logger.exception(f"❌ Failed to create survivorship rule for entity '{db_entity.name}'. Reason: {message}")
                                continue  # Skip this survivorship group and continue

                    # --- STEP 5e: Create Validation Functions ---
                    if validation_list := entity_payload.get("validation_functions", []):
                        service = ValidationFunctionsService(self.db)
                        for validation in validation_list:
                            try:
                                # Dynamically populate ValidationFunctionCreate using schema fields
                                validation_create = ValidationFunctionCreate(
                                    **{
                                        field: validation.get(field)
                                        for field in ValidationFunctionCreate.model_fields.keys()
                                    }
                                )
                                # Override created_by & token dynamically
                                validation_create.created_by = created_by

                                service.create_validation_function_entry(
                                    validation_create,
                                    db_entity_id,
                                    token
                                )
                                app_logger.info(f"✅ Created validation function '{validation_create.function_name}' for entity '{db_entity.name}'")

                            except Exception as e:
                                message = traceback.format_exc()
                                app_logger.exception(f"❌ Failed to create validation function '{validation.get('function_name')}' for entity '{db_entity.name}'. Reason: {message}")
                                continue  # Skip this validation entry and continue

                    # --- STEP 5f: Create D&B Integration Settings ---
                    if dnb_data := entity_payload.get("dnb_integration"):
                        try:
                            dnb_service = EntityDnBService(self.db)
                            # Dynamically populate EntityDnBCreate using schema fields
                            pydantic_fields = {f: dnb_data.get(f) for f in EntityDnBCreate.model_fields.keys()}
                            pydantic_fields["created_by"] = created_by
                            dnb_create = EntityDnBCreate(**pydantic_fields)

                            dnb_service.create_or_update_entity_dnb(
                                entity_id=db_entity_id,
                                entity_create_dnb=dnb_create,
                                token=token,
                            )
                            app_logger.info(f"✅ Created D&B integration settings for entity '{db_entity.name}'")
                        except Exception as e:
                            message = traceback.format_exc()
                            app_logger.exception(f"❌ Failed to create D&B integration for entity '{db_entity.name}'. Reason: {message}")

                except Exception as e:
                    app_logger.error(f"❌ Failed to import entity and mappings: {e}")

                # --- STEP 6a: Create Model Experiments ---
                created_experiments = []
                if "model_experiments.json" in zipf.namelist():
                    try:
                        with zipf.open("model_experiments.json") as f:
                            experiments_list = json.load(f)
                        
                        # Initialize services
                        base_prompt_service = BasePromptService(self.db)
                        experiment_service = ExperimentService(self.db)
                        
                        # Fetch existing active base prompts
                        base_prompts: List[BasePrompt] = base_prompt_service.read_base_prompts(is_active=True)
                        base_prompt_name_map = {bp.prompt_name: bp for bp in base_prompts}
                        
                        # Track base prompts processed in this import session
                        processed_prompts = {}  # {prompt_name: base_prompt_id}
                        
                        # ---------------------------------------------------------
                        # STEP A: Process BasePrompts for each experiment
                        # ---------------------------------------------------------
                        for exp in experiments_list:
                            base_prompt_data = exp.get("base_prompt")
                            
                            if not base_prompt_data:
                                continue
                            
                            prompt_name = base_prompt_data.get("prompt_name")
                            
                            # Check if already processed in this import session
                            if prompt_name in processed_prompts:
                                exp["base_prompt_id"] = processed_prompts[prompt_name]
                                app_logger.info(f"ℹ️ Reusing BasePrompt '{prompt_name}' (ID: {processed_prompts[prompt_name]}) from this import session")
                                continue
                            
                            # Check if exists in database
                            if prompt_name in base_prompt_name_map:
                                existing_bp = base_prompt_name_map[prompt_name]
                                processed_prompts[prompt_name] = existing_bp.id
                                exp["base_prompt_id"] = existing_bp.id
                                app_logger.info(f"ℹ️ Using existing BasePrompt '{prompt_name}' (ID: {existing_bp.id})")
                                continue
                            
                            # Create new BasePrompt
                            try:
                                bp_payload = BasePromptCreate(
                                    **{
                                        field: base_prompt_data.get(field)
                                        for field in BasePromptCreate.model_fields.keys()
                                        if field not in ["created_by"]
                                    },
                                    created_by=created_by
                                )
                                
                                created_bp_resp: HttpResponse = base_prompt_service.create_base_prompt(bp_payload)
                                created_bp = created_bp_resp.data
                                new_bp_id = created_bp.id
                                
                                # Store in tracking maps
                                processed_prompts[prompt_name] = new_bp_id
                                base_prompt_name_map[prompt_name] = created_bp
                                exp["base_prompt_id"] = new_bp_id
                                
                                app_logger.info(f"🟢 Created new BasePrompt '{prompt_name}' (ID: {new_bp_id})")
                                
                            except Exception as e:
                                app_logger.exception(f"❌ Failed creating BasePrompt '{prompt_name}': {e}")
                                continue
                        
                        # ---------------------------------------------------------
                        # STEP B: Create Model Experiments
                        # ---------------------------------------------------------
                        for experiment_payload in experiments_list:
                            try:
                                # Get the base_prompt_id we stored earlier (or None if failed to create)
                                new_bp_id = experiment_payload.get("base_prompt_id")
                                
                                # Skip if base prompt was required but failed to create
                                if experiment_payload.get("base_prompt") and not new_bp_id:
                                    prompt_name = experiment_payload.get("base_prompt", {}).get("prompt_name", "unknown")
                                    modelname = experiment_payload.get("modelname", "unknown")
                                    app_logger.info(
                                        f"⚠️ Skipping experiment '{modelname}' - "
                                        f"BasePrompt '{prompt_name}' failed to create"
                                    )
                                    continue
                                
                                # Extract nested model data
                                llm_model_data = experiment_payload.get("llm_model", {})
                                embedding_model_data = experiment_payload.get("embedding_model", {})
                                config_threshold_data = experiment_payload.get("config_thresold", {})
                                attributes_data = experiment_payload.get("attributes", [])
                                
                                # Build experiment create object
                                experiment_create = Model_ExperimentCreate(
                                    **{
                                        field: experiment_payload.get(field)
                                        for field in Model_ExperimentCreate.model_fields.keys()
                                        if field not in [
                                            "llm_model", "embedding_model", "config_thresold", 
                                            "attributes", "base_prompt_id", "created_by", 
                                            "entity_id", "status"
                                        ]
                                    },
                                    llm_model=LLM_Model(
                                        **{
                                            field: llm_model_data.get(field)
                                            for field in LLM_Model.model_fields.keys()
                                            if llm_model_data.get(field) is not None
                                        }
                                    ) if llm_model_data else None,
                                    embedding_model=Embedding_Model(
                                        **{
                                            field: embedding_model_data.get(field)
                                            for field in Embedding_Model.model_fields.keys()
                                            if embedding_model_data.get(field) is not None
                                        }
                                    ) if embedding_model_data else None,
                                    config_thresold=Config_Threshold(
                                        **{
                                            field: config_threshold_data.get(field)
                                            for field in Config_Threshold.model_fields.keys()
                                            if config_threshold_data.get(field) is not None
                                        }
                                    ) if config_threshold_data else None,
                                    attributes=[
                                        MatchMavenEntityAttributes(
                                            **{
                                                field: attr.get(field)
                                                for field in MatchMavenEntityAttributes.model_fields.keys()
                                                if attr.get(field) is not None
                                            }
                                        )
                                        for attr in attributes_data
                                    ],
                                    base_prompt_id=new_bp_id,
                                    created_by=created_by,
                                    entity_id=db_entity_id,
                                    status="prepare"
                                )
                                
                                # Create experiment
                                created_experiment = experiment_service.create_experiment(experiment_create)
                                created_experiments.append(created_experiment)
                                
                                app_logger.info(
                                    f"✅ Created Model Experiment '{created_experiment.modelname}' "
                                    f"(ID: {created_experiment.id}) for entity ID: {created_experiment.entity_id}"
                                )
                                
                            except Exception as e:
                                modelname = experiment_payload.get("modelname", "unknown")
                                app_logger.exception(f"❌ Failed to create Model Experiment '{modelname}': {str(e)}")
                                continue
                        
                    except json.JSONDecodeError as e:
                        app_logger.exception(f"❌ Failed to parse model_experiments.json: {e}")
                    except Exception as e:
                        app_logger.exception(f"❌ Failed to load model_experiments.json: {e}")
                else:
                    app_logger.info("ℹ️ model_experiments.json not found in package. Skipping model creation.")

                # --- STEP 6b: Start Experiments ---
                for exp in created_experiments:
                    try:
                        app_logger.info(f"🚀 Starting experiment '{exp.modelname}' (ID: {exp.id})...")
                        model_databricks_job_service.start_experiment(
                            entity_id=str(exp.entity_id),
                            model_id=exp.id,
                            is_more_records=False,
                            created_by=created_by,
                            token=token
                        )
                        
                        app_logger.info(f"✅ Successfully started experiment '{exp.modelname}' for entity ID: {exp.entity_id}")
                        # --- Update status to 'experiment' ---
                        update_request = Model_ExperimentUpdateRequest(status="experiment")
                        updated_exp = experiment_service.update_model(model_id=exp.id, model_update=update_request)
                        app_logger.info(f"✅ Updated experiment '{exp.modelname}' status to '{updated_exp.status}'")

                    except Exception as e:
                        message = traceback.format_exc()
                        app_logger.exception(f"❌ Failed to start or update experiment '{exp.modelname}' (ID: {exp.id}): {message}")

            # --- FINAL STEP: Return the imported entity payload ---
            entity_response = self.get_full_entity_by_id(db_entity_id).model_dump() if db_entity else {}

            return entity_response

        except Exception as e:
            app_logger.error(f"❌ Import failed: {e}")
            raise HTTPException(status_code=500, detail=f"Import failed: {str(e)}")

        finally:
            if os.path.exists(tmp_zip_path):
                os.unlink(tmp_zip_path)

    def get_entity_by_name(self, name: str) -> Entity:
        """
        Lookup an entity by its name.
        Args:
            name (str): The entity name to search for.
        Returns:
            Entity object if found, else None.
        """
        try:
            entity = self.db.query(Entity).filter(Entity.name == name).one_or_none()
            return entity
        except Exception as e:
            app_logger.exception(f"Failed to fetch entity by name '{name}': {e}")
            raise HTTPException(status_code=500, detail=f"Error fetching entity: {str(e)}")
        
    def check_entity_tables_existence(self, token: str, entity_name: str) -> dict:
        """
        Check if all related tables exist for the given entity.

        Args:
            token (str): Authentication token
            entity_name (str): The base name of the entity
        Returns:
            dict: Dictionary with existence status for each table type
        """    
        try:
            catalog_service = CatalogService(token, self.db)
            
            # Normalize entity name
            normalized_name = entity_name.lower().replace(' ', '_')
            
            # Check all tables
            master_table = f"{normalized_name}_master_prod"
            potential_match_table = f"{normalized_name}_master_potential_match_prod"
            golden_dedup_table = f"{normalized_name}_master_potential_match_deduplicate_prod"
            dnb_table = f"{normalized_name}_master_prod_dnb_duns"
            warning_table = f"{normalized_name}_master_warning_prod"
            error_table = f"{normalized_name}_unified_error_prod"

            return {
                "master_table_exists": catalog_service.check_table_exists(master_table),
                "potential_match_table_exists": catalog_service.check_table_exists(potential_match_table),
                "golden_dedup_table_exists": catalog_service.check_table_exists(golden_dedup_table),
                "dnb_table_exists": catalog_service.check_table_exists(dnb_table),
                "warning_table_exists": catalog_service.check_table_exists(warning_table),
                "error_table_exists": catalog_service.check_table_exists(error_table),
                "entity_name": entity_name,
                "normalized_name": normalized_name
            }
        except Exception as e:
            # If a permission error bubbled up from check_table_exists, return 403
            # with entity name and owner info so the frontend can show a helpful message
            from lakefusion_utility.utils.dbx_error_handler import raise_on_dbx_permission_error
            owner_email = None
            try:
                entity_record = self.db.query(Entity).filter(
                    Entity.name.ilike(entity_name)
                ).first()
                if entity_record:
                    owner_email = entity_record.created_by
            except Exception:
                pass  # Don't let owner lookup failure mask the original error
            raise_on_dbx_permission_error(
                e,
                context="access entity tables",
                entity_name=entity_name,
                owner_email=owner_email,
            )
            app_logger.exception(f"Failed to check tables for entity {entity_name}: {e}")
            raise HTTPException(
                status_code=500,
                detail=f"Error checking table existence: {str(e)}"
            )

class EntityDnBService:
    def __init__(self, db: Session):
        """
        Initializes the EntityDnBService with a database session.

        Args:
            db: SQLAlchemy session object.
        """
        self.db = db

    def create_or_update_entity_dnb(self, entity_id: int, entity_create_dnb: EntityDnBCreate, token: str = '', is_integration_job: bool = False):
        """
        Creates or updates an EntityDnB record linked to an existing Entity.

        Args:
            entity_id: The ID of the parent Entity.
            entity_create_dnb: Pydantic model containing DnB details.
            token: Authentication token for Databricks API calls.
            is_integration_job: If True, updates the entity.json metadata file in the Databricks volume.

        Returns:
            The created or updated EntityDnB object.

        Raises:
            HTTPException: If the parent Entity does not exist or operation fails.
        """
        try:
            # Check if the parent entity exists
            db_entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
            if not db_entity:
                raise HTTPException(status_code=404, detail="Entity not found.")

            # Check if EntityDnB already exists for this entity_id
            db_entity_dnb = self.db.query(EntityDnB).filter(EntityDnB.entity_id == entity_id).first()

            if db_entity_dnb:
                # Update existing EntityDnB
                db_entity_dnb.threshold = entity_create_dnb.threshold
                db_entity_dnb.attributesmapping=entity_create_dnb.attributesmapping
                db_entity_dnb.minimumconfidence=entity_create_dnb.minimumconfidence
                db_entity_dnb.candidatemaximumquantity=entity_create_dnb.candidatemaximumquantity
                db_entity_dnb.created_by = entity_create_dnb.created_by
                db_entity_dnb.is_active = entity_create_dnb.is_active
                db_entity_dnb.enrichment_policies = entity_create_dnb.enrichment_policies
                db_entity_dnb.created_at = datetime.utcnow()  # optional: update timestamp
            else:
                # Create a new EntityDnB
                db_entity_dnb = EntityDnB(
                    entity_id=entity_id,
                    created_by=entity_create_dnb.created_by,
                    is_active = True,
                    threshold=entity_create_dnb.threshold,
                    minimumconfidence=entity_create_dnb.minimumconfidence,
                    candidatemaximumquantity=entity_create_dnb.candidatemaximumquantity,
                    attributesmapping=entity_create_dnb.attributesmapping,
                    enrichment_policies=entity_create_dnb.enrichment_policies
                )
                self.db.add(db_entity_dnb)

            # Flush to ensure DB changes are visible before metadata sync
            self.db.flush()

            # If this is part of an integration job, update the entity.json in Databricks volume
            if is_integration_job:
                app_logger.debug("Integration job detected - updating entity metadata file")
                EntityService(self.db).update_entity_metadata_file_for_integration_job(token, entity_id)

            db_commit_auto_rollback(db=self.db)
            self.db.refresh(db_entity_dnb)
            return db_entity_dnb

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Unable to create or update EntityDnB. Reason - {message}")
            raise HTTPException(status_code=500, detail=f"Failed to create or update EntityDnB: {str(e)}")

class EntityAttributeService:
    def __init__(self, db: Session):
        """Initializes the entityAttributeService with a database session.        
        Args:
            db: SQLAlchemy session object.
        """
        self.db = db

    def reorder_attributes(self, entity_id: int, attribute_ids: list):
        """Bulk-update display_order for entity attributes based on the provided ID order."""
        try:
            # Validate all IDs belong to this entity
            attrs = self.db.query(EntityAttributes).filter(
                EntityAttributes.entity_id == entity_id,
                EntityAttributes.is_active == True,
            ).all()
            attr_map = {a.id: a for a in attrs}
            if len(attribute_ids) != len(attr_map):
                raise HTTPException(status_code=400, detail=f"Expected {len(attr_map)} attribute IDs, got {len(attribute_ids)}. All active attributes must be included.")
            if len(set(attribute_ids)) != len(attribute_ids):
                raise HTTPException(status_code=400, detail="Duplicate attribute IDs are not allowed")
            for aid in attribute_ids:
                if aid not in attr_map:
                    raise HTTPException(status_code=400, detail=f"Attribute ID {aid} does not belong to entity {entity_id}")
            # Update display_order
            for order, aid in enumerate(attribute_ids):
                attr_map[aid].display_order = order
            self.db.commit()
            return HttpResponse(status="success", message="Attributes reordered successfully", data=True)
        except HTTPException:
            raise
        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Failed to reorder attributes for entity {entity_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to reorder attributes: {str(e)}")

    def create_entity_attribute(self, entity_attribute_create, entity_id: int, created_by: str = ""):
        """
        Create a new entity attribute and associate it with an entity.
        
        This method handles:
        1. Validating entity existence and state
        2. Creating a new attribute with validated data
        3. Handling unique name constraints within entity
        4. Managing primary key and label statuses
        5. Validating reference entity fields when type is 'Reference Entity'
        6. Ensuring atomic transactions and proper error handling
        
        Args:
            entity_attribute_create: Pydantic model containing the attribute data
            entity_id: ID of the entity to attach this attribute to
            
        Returns:
            HttpResponse with:
                - status: Success status
                - message: Detailed success message
                - data: Created EntityAttributes object with metadata
                
        Raises:
            HTTPException: 
                - 404 if entity not found or inactive
                - 409 if attribute name exists
                - 400 for invalid data
                - 500 for system errors
        """
        try:
            app_logger.info(f"Starting attribute creation for entity {entity_id}")
            
            # Validate entity exists and is active
            entity = self.db.query(Entity).filter(
                Entity.id == entity_id,
                Entity.is_active == True
            ).first()
            
            if not entity:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail={
                        "status": "error",
                        "message": f"Active entity with ID {entity_id} not found",
                        "data": None
                    }
                )

            # Start a nested transaction for atomicity
            with self.db.begin_nested():
                # Validate and prepare attribute data
                attribute_data = entity_attribute_create.dict()
                attribute_data['entity_id'] = entity_id
                if created_by:
                    attribute_data['created_by'] = created_by
                
                # Validate required fields
                for field in ['name', 'type']:
                    if not attribute_data.get(field):
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": f"Missing required field: {field}",
                                "data": None
                            }
                        )

                # Validate complex-type rules (STRUCT / ARRAY / feature flag / PK).
                # Runs before REFERENCE_ENTITY validation so the type vocabulary
                # check happens once at the top of the pipeline.
                validate_complex_type_payload(self.db, attribute_data)

                # Validate reference entity fields when type is 'REFERENCE_ENTITY'
                if attribute_data.get('type') == 'REFERENCE_ENTITY':
                    type_config = attribute_data.get('type_config') or {}

                    if not type_config.get('reference_entity_id'):
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": "reference_entity_id is required in type_config when type is REFERENCE_ENTITY",
                                "data": None
                            }
                        )
                    # Validate that the referenced entity exists, is active, and is a reference entity
                    ref_entity = self.db.query(Entity).filter(
                        Entity.id == type_config['reference_entity_id'],
                        Entity.is_active == True
                    ).first()
                    if not ref_entity:
                        raise HTTPException(
                            status_code=status.HTTP_404_NOT_FOUND,
                            detail={
                                "status": "error",
                                "message": f"Referenced entity with ID {type_config['reference_entity_id']} not found or inactive",
                                "data": None
                            }
                        )
                    if ref_entity.entity_type != 'reference':
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": f"Entity with ID {type_config['reference_entity_id']} is not a reference entity",
                                "data": None
                            }
                        )
                else:
                    # Clear reference-specific fields but preserve PIM config (group, display_order, is_localizable)
                    tc = attribute_data.get('type_config') or {}
                    tc.pop('reference_entity_id', None)
                    tc.pop('reference_entity_output_attr', None)
                    attribute_data['type_config'] = tc if tc else None

                # Check for existing attribute with same name
                existing_attribute = self.db.query(EntityAttributes).filter(
                    EntityAttributes.entity_id == entity_id,
                    EntityAttributes.name == attribute_data['name'],
                    EntityAttributes.is_active == True
                ).first()
    
                if existing_attribute:
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail={
                            "status": "error",
                            "message": f"Attribute '{attribute_data['name']}' already exists for entity {entity_id}",
                            "data": existing_attribute.__dict__ if existing_attribute else None
                        }
                    )

                # Set display_order to append at end
                max_order = self.db.query(func.coalesce(func.max(EntityAttributes.display_order), 0)).filter(
                    EntityAttributes.entity_id == entity_id,
                    EntityAttributes.is_active == True,
                ).scalar()
                attribute_data['display_order'] = max_order + 1

                # Create new attribute instance
                new_attribute = EntityAttributes(**attribute_data)
                app_logger.debug(f"Created attribute instance: {attribute_data['name']}")

                # Get active attributes for this entity
                entity_attributes = self.db.query(EntityAttributes).filter(
                    EntityAttributes.entity_id == entity_id,
                    EntityAttributes.is_active == True
                ).all()
                
                # Only plain scalar attributes may be the identifier or display
                # name — STRUCT/ARRAY and pseudo-scalars (REFERENCE_ENTITY,
                # SELECT, MULTISELECT) are ineligible for both.
                eligible_id_label = can_be_identifier_or_label(
                    attribute_data.get('type'),
                    attribute_data.get('is_array', False),
                )

                # Reject an explicit identifier/label flag on an ineligible type
                # rather than silently dropping it.
                if attribute_data.get('is_primary_key') and not eligible_id_label:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": f"Attribute type '{attribute_data.get('type')}' cannot be a product identifier",
                            "data": None,
                        },
                    )
                if attribute_data.get('is_label') and not eligible_id_label:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": f"Attribute type '{attribute_data.get('type')}' cannot be a display name",
                            "data": None,
                        },
                    )

                # Product entities allow zero identifier/display-name — a steward
                # can create products without either, so the first attribute is
                # NOT auto-assigned. Other MDM entities keep auto-PK/label for
                # record matching.
                is_product_entity = entity.entity_type == "product"

                # Handle primary key status
                if attribute_data.get('is_primary_key'):
                    # Update existing primary keys if any
                    pk_query = self.db.query(EntityAttributes).filter_by(
                        entity_id=entity_id,
                        is_primary_key=True
                    )
                    pk_updates = pk_query.update({'is_primary_key': False}, synchronize_session=False)
                    app_logger.debug(f"Updated {pk_updates} existing primary key attributes")
                elif not is_product_entity:
                    # Check if any existing attribute has primary key set
                    existing_pk = self.db.query(EntityAttributes).filter_by(
                        entity_id=entity_id,
                        is_primary_key=True
                    ).first()

                    if not existing_pk and eligible_id_label:
                        # No primary key exists, set this eligible attribute as primary
                        new_attribute.is_primary_key = True
                        app_logger.debug("Setting as primary key (no existing primary key found)")

                # Handle label status
                if attribute_data.get('is_label'):
                    # Update existing labels if any
                    label_updates = self.db.query(EntityAttributes).filter(
                        EntityAttributes.entity_id == entity_id,
                        EntityAttributes.is_label == True
                    ).update({'is_label': False}, synchronize_session=False)
                    app_logger.debug(f"Updated {label_updates} existing label attributes")
                elif not is_product_entity and not entity_attributes and eligible_id_label and not new_attribute.is_primary_key:
                    # First eligible attribute becomes label by default (only if not the identifier)
                    new_attribute.is_label = True
                    app_logger.debug("Setting as label (first attribute)")

                # Add and flush
                self.db.add(new_attribute)
                self.db.flush()

                # Verify ID generation
                if not new_attribute.id:
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail={
                            "status": "error",
                            "message": "Failed to generate attribute ID",
                            "data": None
                        }
                    )

            # Commit changes
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(new_attribute)
            
            app_logger.info(f"Successfully created attribute {new_attribute.id} for entity {entity_id}")
            
            # Prepare response with metadata
            return HttpResponse(
                status="success",
                message=f"Entity attribute '{new_attribute.name}' created successfully",
                data=new_attribute
            )

        except HTTPException as he:
            app_logger.warning(f"HTTP error during attribute creation: {he.detail}")
            raise he
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to create entity attribute: {message}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "status": "error",
                    "message": f"Failed to create entity attribute: {str(e)}",
                    "data": None
                }
            )

    def update_entity_attribute(self, entity_id: int, attribute_id: int, entity_attribute_update, created_by: str = ""):
        """
        Updates an existing entity attribute with the provided data.
        
        This method handles:
        1. Validating the existence and state of the attribute
        2. Name and type field validation (cannot be changed)
        3. Managing primary key and label status updates
        
        Args:
            entity_id: ID of the entity to which the attribute belongs
            attribute_id: ID of the attribute to update
            entity_attribute_update: Pydantic model containing the updated attribute data
            
        Returns:
            HttpResponse with:
                - status: Success status
                - message: Detailed success message
                - data: Updated EntityAttributes object with related updates info
                
        Raises:
            HTTPException: 
                - 404 if attribute not found or inactive
                - 400 for invalid updates (name/type mismatch)
                - 409 for constraint violations
                - 500 for database or system errors
        """
        try:
            # Validate database session
            if not self.db.is_active:
                app_logger.error("Database session is not active")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail={"status": "error", "message": "Database session is not active", "data": None}
                )

            app_logger.info(f"Starting entity attribute update - Entity: {entity_id}, Attribute: {attribute_id}")
                
            # Start a nested transaction for atomicity
            with self.db.begin_nested():
                # Fetch and validate the existing attribute
                db_attribute = self.db.query(EntityAttributes).filter(
                    EntityAttributes.is_active == True,
                    EntityAttributes.id == attribute_id,
                    EntityAttributes.entity_id == entity_id
                ).first()
                
                if not db_attribute:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail={
                            "status": "error",
                            "message": f"Active entity attribute with ID {attribute_id} not found for entity {entity_id}.",
                            "data": None
                        }
                    )

                # Extract and validate update data
                update_dict = entity_attribute_update.dict(exclude_unset=True)
                if created_by:
                    update_dict['created_by'] = created_by
                app_logger.debug(f"Update fields requested: {list(update_dict.keys())}")
                
                # Check name field - always blocked
                if 'name' in update_dict:
                    current_value = getattr(db_attribute, 'name')
                    new_value = update_dict['name']
                    if current_value != new_value:
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": "Modifying name is not allowed. Create a new attribute if you need a different name.",
                                "data": {
                                    "current": {"name": current_value},
                                    "attempted": {"name": new_value}
                                }
                            }
                        )
                    else:
                        del update_dict['name']
                        app_logger.debug("name matches existing value - skipping update")

                # Check type field - blocked only if entity has a published integration hub job
                if 'type' in update_dict:
                    current_value = getattr(db_attribute, 'type')
                    new_value = update_dict['type']
                    if current_value != new_value:
                        has_published_int_hub = self.db.query(Integration_Hub).filter(
                            Integration_Hub.entity_id == entity_id,
                            Integration_Hub.is_active == True
                        ).first()
                        if has_published_int_hub:
                            raise HTTPException(
                                status_code=status.HTTP_400_BAD_REQUEST,
                                detail={
                                    "status": "error",
                                    "message": "Modifying type is not allowed when entity has a published integration hub job.",
                                    "data": {
                                        "current": {"type": current_value},
                                        "attempted": {"type": new_value}
                                    }
                                }
                            )
                    else:
                        del update_dict['type']
                        app_logger.debug("type matches existing value - skipping update")
                
                if not update_dict:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": "No valid fields to update",
                            "data": None
                        }
                    )
                
                # Validate complex-type rules against the resulting state
                # (merge of incoming update_dict + current persisted values).
                # also catches PK toggles on complex attrs.
                validate_complex_type_payload(
                    self.db,
                    update_dict,
                    existing_type=db_attribute.type,
                    existing_is_array=db_attribute.is_array,
                    existing_struct_definition_id=db_attribute.struct_definition_id,
                )

                # Validate type_config for REFERENCE_ENTITY
                # effective_type: use the incoming type if changing, otherwise keep current
                effective_type = update_dict.get('type', db_attribute.type)

                if effective_type == 'REFERENCE_ENTITY':
                    # Use incoming type_config if provided, otherwise fall back to existing
                    type_config = update_dict.get('type_config') or (db_attribute.type_config or {})

                    if not type_config.get('reference_entity_id'):
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": "reference_entity_id is required in type_config when type is REFERENCE_ENTITY",
                                "data": None
                            }
                        )
                    # Validate that the referenced entity exists, is active, and is a reference entity
                    ref_entity = self.db.query(Entity).filter(
                        Entity.id == type_config['reference_entity_id'],
                        Entity.is_active == True
                    ).first()
                    if not ref_entity:
                        raise HTTPException(
                            status_code=status.HTTP_404_NOT_FOUND,
                            detail={
                                "status": "error",
                                "message": f"Referenced entity with ID {type_config['reference_entity_id']} not found or inactive",
                                "data": None
                            }
                        )
                    if ref_entity.entity_type != 'reference':
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": f"Entity with ID {type_config['reference_entity_id']} is not a reference entity",
                                "data": None
                            }
                        )

                elif 'type' in update_dict and db_attribute.type == 'REFERENCE_ENTITY':
                    # Type is changing away from REFERENCE_ENTITY — clear type_config
                    update_dict['type_config'] = None
                
                app_logger.debug("Field validation passed - proceeding with updates")

                # Track changes for response
                changes = {"updated_fields": [], "related_updates": {}}
                
                # Update attribute fields
                for field, value in update_dict.items():
                    if hasattr(db_attribute, field) and getattr(db_attribute, field) != value:
                        setattr(db_attribute, field, value)
                        changes["updated_fields"].append(field)

                # Handle primary key updates
                if update_dict.get('is_primary_key'):
                    pk_updates = self.db.query(EntityAttributes).filter(
                        EntityAttributes.entity_id == entity_id,
                        EntityAttributes.id != attribute_id,
                        EntityAttributes.is_primary_key == True
                    ).update({'is_primary_key': False}, synchronize_session=False)
                    changes["related_updates"]["primary_key_updates"] = pk_updates

                # Handle label updates
                if update_dict.get('is_label'):
                    label_updates = self.db.query(EntityAttributes).filter(
                        EntityAttributes.entity_id == entity_id,
                        EntityAttributes.id != attribute_id,
                        EntityAttributes.is_label == True
                    ).update({'is_label': False}, synchronize_session=False)
                    changes["related_updates"]["label_updates"] = label_updates

                # If type was changed, update relation_updated_at to trigger model outdating
                if 'type' in changes["updated_fields"]:
                    entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
                    if entity:
                        entity.relation_updated_at = datetime.utcnow()
                        app_logger.info(f"Updated relation_updated_at for entity {entity_id} due to attribute type change")

                # Merge and flush changes
                self.db.merge(db_attribute)
                self.db.flush()

            # Commit the transaction
            db_commit_auto_rollback(db=self.db)

            # Refresh to get final state
            self.db.refresh(db_attribute)

            # Prepare detailed response
            app_logger.info(f"Successfully updated attribute {attribute_id} - Fields: {changes['updated_fields']}")
            return HttpResponse(
                status="success",
                message=f"Entity attribute '{db_attribute.name}' updated successfully.",
                data=db_attribute
            )

        except HTTPException as he:
            app_logger.warning(f"HTTP error during attribute update: {he.detail}")
            raise he
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to update entity attribute {attribute_id}: {message}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "status": "error",
                    "message": f"Failed to update entity attribute: {str(e)}",
                    "data": None
                }
            )

    def delete_entity_attribute(self, entity_id: int, attribute_id: int):
        """
        Deletes an entity attribute and cleans up all related references.
        
        This method handles:
        1. Validating attribute existence and status
        2. Checking primary key constraints
        3. Updating dataset mappings to remove references
        4. Updating survivorship rules to remove references
        5. Deleting validation functions that reference the attribute
        6. Cleaning up model_experiments attributes array
        7. Updating entity.relation_updated_at if attribute had dataset mappings
        8. Ensuring atomic transaction with proper rollback
        
        Args:
            entity_id: ID of the entity to which the attribute belongs
            entity_id: ID of the entity to which the attribute belongs
            attribute_id: ID of the attribute to delete
            
        Returns:
            HttpResponse with:
                - status: Success status
                - message: Detailed success message
                - data: Operation details including counts of affected records
                
            HttpResponse with:
                - status: Success status
                - message: Detailed success message
                - data: Operation details including counts of affected records
                
        Raises:
            HTTPException:
                - 404 if attribute not found
                - 400 if trying to delete the only primary key
                - 400 if attribute is used as a reference output in another entity's REFERENCE_ENTITY attribute
                - 500 for system errors
        """
        try:
            app_logger.info(f"Starting deletion process for attribute ID: {attribute_id}")
            
            # Start a nested transaction for atomicity
            with self.db.begin_nested():
                # Get attribute with active status check
                attribute = (self.db.query(EntityAttributes)
                        .filter_by(id=attribute_id)
                        .first())
                
                if not attribute:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail={
                            "status": "error",
                            "message": f"Attribute with ID {attribute_id} not found",
                            "data": None
                        }
                    )
                
                entity_id = attribute.entity_id
                attribute_name = attribute.name
                is_primary = attribute.is_primary_key

                # Get entity type — product entities skip primary key/label checks
                entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
                is_product_entity = entity and entity.entity_type == "product"

                # Check if this is the only primary key
                if is_primary and not is_product_entity:
                    other_primary_keys = (self.db.query(EntityAttributes)
                                        .filter_by(entity_id=entity_id, is_primary_key=True)
                                        .filter(EntityAttributes.id != attribute_id)
                                        .count())
                    
                    if other_primary_keys == 0:
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": "Cannot delete the only primary key attribute. Please set another attribute as primary key first.",
                                "data": None
                            }
                        )
                # Check if this is the only is_label
                if attribute.is_label and not is_product_entity:
                    other_labels = (self.db.query(EntityAttributes)
                                    .filter_by(entity_id=entity_id, is_label=True)
                                    .filter(EntityAttributes.id != attribute_id)
                                    .count())
                    
                    if other_labels == 0:
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": "Cannot delete the only primary display field attribute. Please set another attribute as primary display field first.",
                                "data": None
                            }
                        )
                
                app_logger.info(f"Deleting attribute '{attribute_name}' (ID: {attribute_id}) from entity {entity_id}")
                
                # Flag to track if attribute had dataset mappings
                attribute_had_dataset_mappings = False
                
                # Update dataset mappings
                dataset_mappings = (self.db.query(EntityDatasetMapping)
                                .filter_by(entity_id=entity_id)
                                .all())
                
                for mapping in dataset_mappings:
                    if mapping.attributes:
                        original_count = len(mapping.attributes)
                        updated_attributes = [
                                attr for attr in mapping.attributes 
                                if attr.get('entity_attribute') != attribute_name
                        ]
                        
                        if len(updated_attributes) != original_count:
                            # Attribute had mappings in this dataset
                            attribute_had_dataset_mappings = True
                            mapping.attributes = updated_attributes
                            self.db.merge(mapping)
                
                # Update survivorship rules by removing attribute from rules
                survivorship_rules = (self.db.query(SurvivorshipRule)
                                        .filter_by(entity_id=entity_id)
                                        .all())
                for rule in survivorship_rules:
                    if rule.rules:
                        original_count = len(rule.rules)
                        updated_attributes = [
                                attr for attr in rule.rules
                                if attr.get('attribute') != attribute_name
                        ]

                        if len(updated_attributes) != original_count:
                            rule.rules = updated_attributes
                            self.db.merge(rule)
                
                # Delete validation functions that reference this attribute
                validation_functions = (self.db.query(ValidationFunction)
                                    .filter_by(entity_id=entity_id, attribute_name=attribute_name)
                                    .all())
                
                for vf in validation_functions:
                    self.db.delete(vf)
                    app_logger.info(f"Deleted validation function {vf.id} that referenced attribute '{attribute_name}'")
                
                # Clean up model_experiments attributes array
                cleanup_statuses = ['prepare', 'experiment_failed', 'experiment_cancelled']
                model_experiments = (self.db.query(Model_Experiment)
                                    .filter_by(entity_id=entity_id)
                                    .filter(Model_Experiment.status.in_(cleanup_statuses))
                                    .all())
                
                experiments_updated = 0
                for experiment in model_experiments:
                    if experiment.attributes:
                        original_count = len(experiment.attributes)
                        # Filter out the attribute with matching id
                        updated_attributes = [
                            attr for attr in experiment.attributes 
                            if attr.get('id') != attribute_id
                        ]
                        
                        if len(updated_attributes) != original_count:
                            experiment.attributes = updated_attributes
                            self.db.merge(experiment)
                            experiments_updated += 1
                            app_logger.info(f"Removed attribute {attribute_id} from model experiment {experiment.id}")
                
                # Update entity.relation_updated_at if attribute had dataset mappings
                # This ensures model experiments are marked as outdated
                if attribute_had_dataset_mappings:
                    entity = self.db.query(Entity).filter_by(id=entity_id).first()
                    if entity:
                        entity.relation_updated_at = datetime.utcnow()
                        self.db.merge(entity)
                        app_logger.info(f"Updated relation_updated_at for entity {entity_id} due to attribute dataset mapping deletion")
                
                # Delete the attribute
                self.db.delete(attribute)
                self.db.flush()
                
            # Commit the transaction
            db_commit_auto_rollback(db=self.db)
            
            app_logger.info(f"Successfully deleted attribute {attribute_id} with all related cleanup. Updated {experiments_updated} model experiments.")
            return HttpResponse(
                status="success",
                message=f"Entity attribute '{attribute_name}' deleted successfully with all related references",
                data={
                    "attribute_id": attribute_id,
                    "attribute_name": attribute_name,
                    "experiments_updated": experiments_updated
                }
            )
            
        except HTTPException as he:
            app_logger.warning(f"HTTP error during attribute deletion: {he.detail}")
            raise he
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to delete attribute {attribute_id}: {message}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "status": "error",
                    "message": f"Failed to delete attribute: {str(e)}",
                    "data": None
                }
            )
    
    def read_entityattributes(self, entity_id: int):
        try:
            attributes = self.db.query(EntityAttributes).filter(EntityAttributes.entity_id == entity_id).all()
            return attributes
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Failed to read attributes. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to read attributes: {str(e)}")
        
    def get_attributelabel_by_attributename(self, entity_id: int, attribute_name: str):
        try:
            attribute = self.db.query(EntityAttributes).filter(
                EntityAttributes.entity_id == entity_id,
                EntityAttributes.name == attribute_name
            ).first()
            if not attribute:
                return attribute_name
            return attribute.label or attribute.name
        
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Failed to read attribute labels. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to read attribute labels: {str(e)}")    

    def toggle_attribute_active(self, attribute_id: int):
        try:
            attribute = self.db.query(EntityAttributes).filter(EntityAttributes.id == attribute_id).first()
            if not attribute:
                raise HTTPException(status_code=404, detail="Attribute not found.")
            attribute.is_active = not attribute.is_active
            db_commit_auto_rollback(db=self.db)
            return attribute
        except HTTPException:
            raise
        except Exception as e:
            message = traceback.format_exc()
            app_logger.error(f'Failed to toggle attribute active status: {message}')
            raise HTTPException(status_code=500, detail=f"Failed to toggle attribute active status: {str(e)}")

    def update_entity_attribute_primary_key(self, entity_id: int, attribute_id: int):
        """
        Updates the primary key status of an entity attribute and ensures only one attribute
        is marked as the primary key per entity.

        Args:
            entity_id: ID of the entity
            attribute_id: ID of the attribute to make primary key

        Returns:
            Updated entity attribute object

        Raises:
            HTTPException: If attribute not found or error occurs during update
        """
        try:
            # Begin transaction
            with self.db.begin_nested():
                # Check if the target attribute exists and is active
                target_attribute = self.db.query(EntityAttributes).filter(
                    EntityAttributes.entity_id == entity_id,
                    EntityAttributes.id == attribute_id,
                    EntityAttributes.is_active == True
                ).first()

                if not target_attribute:
                    raise HTTPException(
                        status_code=404,
                        detail=f"Entity attribute with entity ID {entity_id} and attribute ID {attribute_id} not found or inactive"
                    )

                # Get all active attributes for this entity
                entity_attributes = self.db.query(EntityAttributes).filter(
                    EntityAttributes.entity_id == entity_id,
                    EntityAttributes.is_active == True
                ).all()

                # Toggle: clicking the current identifier clears it (identifier
                # is optional). Otherwise set this one and clear all others.
                if target_attribute.is_primary_key:
                    target_attribute.is_primary_key = False
                    self.db.merge(target_attribute)
                else:
                    # Only plain scalar attributes can become identifiers —
                    # STRUCT/ARRAY and pseudo-scalars (REFERENCE_ENTITY/SELECT/
                    # MULTISELECT) cannot. (Clearing above is always allowed.)
                    if not can_be_identifier_or_label(target_attribute.type, target_attribute.is_array):
                        raise HTTPException(
                            status_code=400,
                            detail=f"Attribute type '{target_attribute.type}' cannot be a product identifier",
                        )
                    for attribute in entity_attributes:
                        attribute.is_primary_key = (attribute.id == attribute_id)
                        self.db.merge(attribute)

                # Flush to ensure all updates are processed
                self.db.flush()

            # Commit the transaction
            self.db.commit()

            # Refresh the target attribute to get the latest state
            self.db.refresh(target_attribute)

            return target_attribute

        except HTTPException:
            # Validation errors (e.g. PK on complex) — propagate unchanged
            # so the caller sees the original 400, not a 500 wrapper.
            self.db.rollback()
            raise
        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update entity attribute primary key status. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update entity attribute primary key status: {str(e)}"
            )

            
    def update_entity_attribute_label(self, entity_id: int, attribute_id: int):
        """
        Updates the label status of an entity attribute and ensures only one attribute
        is marked as the label (display name) per entity.

        Args:
            entity_id: ID of the entity
            attribute_id: ID of the attribute to make label

        Returns:
            Updated entity attribute object

        Raises:
            HTTPException: If attribute not found or error occurs during update
        """
        try:
            # Begin transaction
            with self.db.begin_nested():
                # Check if the target attribute exists and is active
                target_attribute = self.db.query(EntityAttributes).filter(
                    EntityAttributes.entity_id == entity_id,
                    EntityAttributes.id == attribute_id,
                    EntityAttributes.is_active == True
                ).first()

                if not target_attribute:
                    raise HTTPException(
                        status_code=404,
                        detail=f"Entity attribute with entity ID {entity_id} and attribute ID {attribute_id} not found or inactive"
                    )

                # Get all active attributes for this entity
                entity_attributes = self.db.query(EntityAttributes).filter(
                    EntityAttributes.entity_id == entity_id,
                    EntityAttributes.is_active == True
                ).all()

                # Toggle: clicking the current display name clears it (display
                # name is optional). Otherwise set this one and clear all others.
                if target_attribute.is_label:
                    target_attribute.is_label = False
                    self.db.merge(target_attribute)
                else:
                    # Only plain scalar attributes can become the display name —
                    # STRUCT/ARRAY and pseudo-scalars (REFERENCE_ENTITY/SELECT/
                    # MULTISELECT) cannot. (Clearing above is always allowed.)
                    if not can_be_identifier_or_label(target_attribute.type, target_attribute.is_array):
                        raise HTTPException(
                            status_code=400,
                            detail=f"Attribute type '{target_attribute.type}' cannot be a display name",
                        )
                    for attribute in entity_attributes:
                        attribute.is_label = (attribute.id == attribute_id)
                        self.db.merge(attribute)

                # Flush to ensure all updates are processed
                self.db.flush()

            # Commit the transaction
            self.db.commit()

            # Refresh the target attribute to get the latest state
            self.db.refresh(target_attribute)

            return target_attribute

        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update entity attribute label status. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update entity attribute label status: {str(e)}"
            )
            
    def toggle_attribute_show_in_ui(self, attribute_id: int):
        try:
            attribute = self.db.query(EntityAttributes).filter(EntityAttributes.id == attribute_id).first()
            if not attribute:
                raise HTTPException(status_code=404, detail="Attribute not found.")
            attribute.show_in_ui = not attribute.show_in_ui
            db_commit_auto_rollback(db=self.db)
            return attribute
        except Exception as e:
            message = traceback.format_exc()
            app_logger.error(f'Failed to toggle attribute label status: {message}')
            raise HTTPException(status_code=500, detail=f"Failed to toggle attribute label status: {str(e)}")
    
class EntityDatasetMappingService:
    def __init__(self, db: Session):
        """Initializes the entityService with a database session.
        
        Args:
            db: SQLAlchemy session object.
        """
        self.db = db


    def read_entity_dataset_mapping(self, entity_id: int, is_active: bool = True):
        """
        Retrieves all dataset mappings and their details for a specific entity.
        """
        try:
            mappings = (
                self.db.query(EntityDatasetMapping, Dataset)
                .join(Dataset, EntityDatasetMapping.dataset_id == Dataset.id)
                .filter(EntityDatasetMapping.entity_id == entity_id)
            )

            if is_active:
                mappings = mappings.filter(
                    EntityDatasetMapping.is_active == is_active,
                    Dataset.is_active == is_active
                )

            results = mappings.all()

            response_data = []
            for mapping, dataset in results:
                response_data.append(
                    EntityDatasetMappingResponse(
                        entity_id=mapping.entity_id,
                        dataset_id=mapping.dataset_id,
                        attributes=mapping.attributes,  # Assuming this is already in the correct format
                        is_primary=mapping.is_primary,
                        created_at=mapping.created_at,
                        created_by=mapping.created_by,
                        is_active=mapping.is_active,
                        dataset=DatasetDetails(
                            id=dataset.id,
                            name=dataset.name,
                            path=dataset.path,
                            description=dataset.description,
                            created_at=dataset.created_at,
                            created_by=dataset.created_by,
                            is_active=dataset.is_active,
                            color_code=dataset.color_code,
                            quality_task_enabled=dataset.quality_task_enabled
                        ),
                        use_cleaned_table=mapping.use_cleaned_table,
                    )
                )

            return response_data

        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity dataset mappings. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to fetch entity dataset mappings: {str(e)}"
            )

    def delete_entity_dataset_mapping(self, entity_id: int, dataset_id: int, token: str, is_integration_job: bool = False):
        """Deletes an entity dataset mapping permanently and updates entity.relation_updated_at.
        
        This method handles:
        1. Validating mapping existence and active status
        2. Checking if mapping is primary (cannot delete primary mapping)
        3. Updating entity.relation_updated_at to track changes
        4. Ensuring atomic transaction with proper rollback
        
        Args:
            entity_id: The ID of the entity
            dataset_id: The ID of the dataset
            
        Returns:
            HttpResponse with:
                - status: Success status
                - message: Detailed success message
                - data: None
                
        Raises:
            HTTPException: 
                - 404 if mapping not found
                - 400 if trying to delete primary mapping
                - 500 for system errors
        """
        try:
            app_logger.info(f"Starting deletion process for entity dataset mapping - Entity: {entity_id}, Dataset: {dataset_id}")
            
            # Start a nested transaction for atomicity
            with self.db.begin_nested():
                # Fetch the entity dataset mapping with active status check
                db_entity_dataset = self.db.query(EntityDatasetMapping).filter(
                    and_(
                        EntityDatasetMapping.entity_id == entity_id,
                        EntityDatasetMapping.dataset_id == dataset_id,
                        EntityDatasetMapping.is_active == True
                    )
                ).first()
                
                if db_entity_dataset is None:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail={
                            "status": "error",
                            "message": f"Active entity dataset mapping not found for entity {entity_id} and dataset {dataset_id}",
                            "data": None
                        }
                    )

                # Check if this is a primary mapping — skip for reference entities
                # (reference entities always have is_primary=False but we guard by entity_type too)
                entity = self.db.query(Entity).filter(Entity.id == entity_id).first()
                if db_entity_dataset.is_primary and (entity is None or entity.entity_type != "reference"):
                    app_logger.warning(f"Attempted to delete primary mapping for entity {entity_id}")
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": "Cannot delete a primary dataset mapping. Please set another mapping as primary first.",
                            "data": None
                        }
                    )
                
                # Update entity.relation_updated_at since mapping is being deleted
                entity = self.db.query(Entity).filter(
                    Entity.id == entity_id,
                    Entity.is_active == True
                ).first()
                
                if not entity:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail={
                            "status": "error",
                            "message": f"Active entity not found with ID {entity_id}",
                            "data": None
                        }
                    )
                
                entity.relation_updated_at = datetime.utcnow()
                self.db.merge(entity)
                app_logger.debug(f"Updated relation_updated_at for entity {entity_id}")
                
                # Delete the entity dataset mapping
                self.db.delete(db_entity_dataset)
                app_logger.debug(f"Marked mapping for deletion between entity {entity_id} and dataset {dataset_id}")
                
                # Flush changes to ensure all operations succeeded
                self.db.flush()

                # If this mapping is part of an integration job, update its metadata file
                if is_integration_job:
                    app_logger.debug("Integration job detected - updating entity metadata file")
                    EntityService(self.db).update_entity_metadata_file_for_integration_job(token, entity_id)

            # Commit the transaction
            db_commit_auto_rollback(db=self.db)
            
            app_logger.info(f"Successfully deleted dataset mapping between entity {entity_id} and dataset {dataset_id}")
            return HttpResponse(
                status="success",
                message=f"Entity dataset mapping for entity {entity_id} and dataset {dataset_id} deleted successfully.",
                data=None
            )
        except HTTPException as he:
            app_logger.warning(f"HTTP error during entity dataset mapping deletion: {he.detail}")
            raise he

        except Exception as e:
            # Exception handling with logging
            message = traceback.format_exc()
            app_logger.exception(f'Unable to delete entity dataset mapping. Reason - {message}')
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail={
                "status": "error",
                "message": f"Failed to delete entity dataset mapping: {str(e)}",
                "data": None
            })

    def create_entity_dataset_mapping(self, entity_attribute_create: EntityDatasetMappingCreate, entity_id: int, dataset_id: int, token: str, is_integration_job: bool = False, use_cleaned_table: Optional[bool] = False, created_by: str = ""):
        """Creates a new entity dataset mapping and saves it to the database.
        
        This method handles:
        1. Validating entity and dataset existence and active status
        2. Checking for duplicate mappings
        3. Creating a new mapping with validated attribute data
        4. Managing primary status according to business rules:
           - If mapping is set as primary, reset other mappings to non-primary
           - If mapping is not primary but no primary exists, make it primary
        5. Updating entity.relation_updated_at to track changes
        6. Ensuring atomic transactions with proper error handling
        
        Args:
            entity_attribute_create: Pydantic model containing mapping details
            entity_id: ID of the entity
            dataset_id: ID of the dataset
            
        Returns:
            HttpResponse with:
                - status: Success status
                - message: Detailed success message
                - data: Created EntityDatasetMapping object
                
        Raises:
            HTTPException: 
                - 404 if entity or dataset not found or inactive
                - 409 if mapping already exists
                - 400 for invalid data
                - 500 for system errors
        """
        try:
            app_logger.info(f"Starting dataset mapping creation for entity {entity_id} and dataset {dataset_id}")
            
            # Start a nested transaction for atomicity
            with self.db.begin_nested():
                # Validate entity exists and is active
                entity = self.db.query(Entity).filter(
                    Entity.id == entity_id,
                    Entity.is_active == True
                ).first()
                
                if not entity:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail={
                            "status": "error",
                            "message": f"Active entity with ID {entity_id} not found",
                            "data": None
                        }
                    )

                # Validate dataset exists and is active
                dataset = self.db.query(Dataset).filter(
                    Dataset.id == dataset_id,
                    Dataset.is_active == True
                ).first()
                
                if not dataset:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail={
                            "status": "error",
                            "message": f"Active dataset with ID {dataset_id} not found",
                            "data": None
                        }
                    )

                # Check for existing mapping
                existing_mapping = self.db.query(EntityDatasetMapping).filter(
                    EntityDatasetMapping.entity_id == entity_id,
                    EntityDatasetMapping.dataset_id == dataset_id,
                    EntityDatasetMapping.is_active == True
                ).first()

                if existing_mapping:
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail={
                            "status": "error",
                            "message": f"Mapping already exists between entity {entity_id} and dataset {dataset_id}",
                            "data": None
                        }
                    )

                # Validate and prepare attributes data
                try:
                    attributes_data = [attribute.dict() for attribute in entity_attribute_create.attributes]
                except Exception as e:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": f"Invalid attribute data format: {str(e)}",
                            "data": None
                        }
                    )

                # enforce complex-type mapping rules. Blocks
                # struct/array targets without a mode, scalar targets with a
                # mode set, and obviously malformed sub_field_maps.
                from lakefusion_utility.services.complex_mapping_validation import (
                    validate_mapping_attributes,
                )
                entity_attr_rows = (
                    self.db.query(EntityAttributes)
                    .filter(EntityAttributes.entity_id == entity_id)
                    .all()
                )
                validate_mapping_attributes(entity_attr_rows, attributes_data)

                # Create new mapping instance
                new_dataset_mapping = EntityDatasetMapping(
                    entity_id=entity_id,
                    dataset_id=dataset_id,
                    attributes=attributes_data,
                    is_primary=entity_attribute_create.is_primary,
                    created_by=created_by if created_by else entity_attribute_create.created_by,
                    is_active=True,
                    created_at=datetime.utcnow(),
                    use_cleaned_table=use_cleaned_table if use_cleaned_table is not None else False
                )

                # Handle primary key status with aliases for clarity
                EDM = EntityDatasetMapping
                base_query = self.db.query(EDM).filter(
                    EDM.entity_id == entity_id,
                    EDM.is_active == True
                )
                
                if entity.entity_type == "reference":
                    # Reference entities always have is_primary=False; they support only one mapping
                    # and deletion must always be allowed
                    new_dataset_mapping.is_primary = False
                    app_logger.debug(f"Reference entity {entity_id}: is_primary forced to False")
                elif entity_attribute_create.is_primary:
                    # Reset any existing primary mappings
                    pk_updates = base_query.filter(
                        EDM.is_primary == True
                    ).update({'is_primary': False}, synchronize_session=False)
                    
                    if pk_updates:
                        app_logger.debug(f"Reset {pk_updates} existing primary mapping(s) for entity {entity_id}")
                else:
                    # Check if this should be made primary (no other primary exists)
                    existing_primary = base_query.filter(
                        EDM.is_primary == True
                    ).first()
                    
                    if not existing_primary:
                        new_dataset_mapping.is_primary = True
                        app_logger.debug(f"Setting as primary mapping (no existing primary found)")

                # Update entity's relation timestamp
                entity.relation_updated_at = datetime.utcnow()
                self.db.merge(entity)
                app_logger.debug(f"Updated relation_updated_at for entity {entity_id}")
                
                # Add and flush new mapping
                self.db.add(new_dataset_mapping)
                self.db.flush()
                
                # If this mapping is part of an integration job, update its metadata file
                if is_integration_job:
                    app_logger.info("Integration job detected, updating entity metadata file.")
                    EntityService(self.db).update_entity_metadata_file_for_integration_job(token, entity_id)

            # Commit the transaction
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(new_dataset_mapping)
            
            app_logger.info(f"Successfully created dataset mapping for entity {entity_id} and dataset {dataset_id}")
            
            return HttpResponse(
                status="success",
                message=(
                    f"Entity dataset mapping created successfully between entity {entity_id} "
                    f"and dataset {dataset_id}" + 
                    (" (set as primary)" if new_dataset_mapping.is_primary else "")
                ),
                data=new_dataset_mapping
            )
            
        except HTTPException as he:
            app_logger.warning(f"HTTP error during dataset mapping creation: {he.detail}")
            raise he
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to create dataset mapping: {message}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "status": "error",
                    "message": f"Failed to create dataset mapping: {str(e)}",
                    "data": None
                }
            )
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to create dataset mapping. Reason - {message}')
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail={
                "status": "error",
                "message": f"Failed to create dataset mapping: {str(e)}",
                "data": None
            })


    def update_entity_dataset_mapping(self, entity_attribute: EntityDatasetMappingCreate, entity_id: int, dataset_id: int, token: str, is_integration_job: bool = False, use_cleaned_table: Optional[bool] = False, created_by: str = ""):
        """Updates an existing entity dataset mapping and handles all related updates.
        
        This method handles:
        1. Validating mapping existence and active status
        2. Managing primary status changes:
           - If setting as primary, reset other mappings
           - Ensure at least one primary mapping exists
        3. Validating and updating attributes data
        4. Updating entity.relation_updated_at to track changes
        5. Ensuring atomic transaction with proper rollback
        
        Args:
            entity_attribute: Pydantic model containing updated mapping details
            entity_id: ID of the entity
            dataset_id: ID of the dataset
            
        Returns:
            HttpResponse with:
                - status: Success status
                - message: Detailed success message
                - data: Updated EntityDatasetMapping object
                
        Raises:
            HTTPException: 
                - 404 if mapping or entity not found
                - 400 for invalid data
                - 500 for system errors
        """
        try:
            app_logger.info(f"Starting dataset mapping update for entity {entity_id} and dataset {dataset_id}")
            
            # Start a nested transaction for atomicity
            with self.db.begin_nested():
                # Fetch the existing mapping with active status check
                existing_mapping = self.db.query(EntityDatasetMapping).filter(
                    and_(
                        EntityDatasetMapping.entity_id == entity_id,
                        EntityDatasetMapping.dataset_id == dataset_id,
                        EntityDatasetMapping.is_active == True
                    )
                ).first()
                
                if existing_mapping is None:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND, 
                        detail={
                            "status": "error", 
                            "message": f"Active entity dataset mapping not found for entity {entity_id} and dataset {dataset_id}", 
                            "data": None
                        }
                    )

                # Always handle primary status to ensure consistency
                if entity_attribute.is_primary:
                    app_logger.debug(f"Setting mapping as primary for entity {entity_id} and dataset {dataset_id}")
                    
                    # Reset all other mappings' primary status
                    pk_updates = self.db.query(EntityDatasetMapping).filter(
                        and_(
                            EntityDatasetMapping.entity_id == entity_id,
                            EntityDatasetMapping.is_active == True,
                            EntityDatasetMapping.dataset_id != dataset_id
                        )
                    ).update({'is_primary': False}, synchronize_session=False)
                    
                    if pk_updates:
                        app_logger.debug(f"Reset primary flag for {pk_updates} other mapping(s)")
                elif existing_mapping.is_primary:
                    # If removing primary status, ensure another primary exists
                    other_primary = self.db.query(EntityDatasetMapping).filter(
                        and_(
                            EntityDatasetMapping.entity_id == entity_id,
                            EntityDatasetMapping.is_active == True,
                            EntityDatasetMapping.dataset_id != dataset_id,
                            EntityDatasetMapping.is_primary == True
                        )
                    ).first()
                    
                    if not other_primary:
                        app_logger.warning("Attempted to remove primary status from only primary mapping")
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": "Cannot remove primary status from the only primary mapping. Set another mapping as primary first.",
                                "data": None
                            }
                        )
                
                # Replace attributes completely with the new set
                try:
                    # Convert all incoming attributes to dicts
                    new_attributes = [attribute.dict() for attribute in entity_attribute.attributes]
                except Exception as e:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": f"Invalid attribute data format: {str(e)}",
                            "data": None,
                        },
                    )

                # validate complex-type mapping rules on update too.
                from lakefusion_utility.services.complex_mapping_validation import (
                    validate_mapping_attributes,
                )
                entity_attr_rows = (
                    self.db.query(EntityAttributes)
                    .filter(EntityAttributes.entity_id == entity_id)
                    .all()
                )
                validate_mapping_attributes(entity_attr_rows, new_attributes)

                # Update mapping with new attributes and other fields
                existing_mapping.attributes = new_attributes
                existing_mapping.is_primary = entity_attribute.is_primary
                existing_mapping.created_by = created_by or entity_attribute.created_by
                if use_cleaned_table is not None:
                    existing_mapping.use_cleaned_table = use_cleaned_table
                self.db.merge(existing_mapping)

                # Update entity.relation_updated_at
                entity = self.db.query(Entity).filter(
                    Entity.id == entity_id,
                    Entity.is_active == True
                ).first()
                
                if not entity:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail={
                            "status": "error",
                            "message": f"Active entity not found with ID {entity_id}",
                            "data": None
                        }
                    )
                
                entity.relation_updated_at = datetime.utcnow()
                self.db.merge(entity)
                app_logger.debug(f"Updated relation_updated_at for entity {entity_id}")
                
                # Flush changes to ensure all operations succeeded
                self.db.flush()

                # If this mapping is part of an integration job, update its metadata file
                if is_integration_job:
                    app_logger.debug(f"Updating metadata file for integration job due to mapping update for entity {entity_id}")
                    EntityService(self.db).update_entity_metadata_file_for_integration_job(token, entity_id)
            
            # Commit the transaction
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(existing_mapping)

            app_logger.info(f"Successfully updated dataset mapping between entity {entity_id} and dataset {dataset_id}")
            
            return HttpResponse(
                status="success",
                message=f"Entity dataset mapping for entity {entity_id} and dataset {dataset_id} updated successfully.",
                data=existing_mapping
            )

        except HTTPException as he:
            app_logger.warning(f"HTTP error during entity dataset mapping update")
            raise he
        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update entity dataset mapping. Reason - {message}')
            raise HTTPException(status_code=500, detail={
                "status": "error",
                "message": f"Failed to update entity dataset mapping: {str(e)}",
                "data": None
            })

    def update_entity_dataset_mapping_primary(self, entity_id: int, dataset_id: int):
        """
        Updates the primary status of a dataset mapping and ensures only one mapping
        is marked as primary per entity.

        Args:
            entity_id: ID of the entity
            dataset_id: ID of the dataset mapping to make primary

        Returns:
            Updated entity dataset mapping object

        Raises:
            HTTPException: If mapping not found or error occurs during update
        """
        try:
            # Begin transaction
            with self.db.begin_nested():
                # Check if the target mapping exists and is active
                target_mapping = self.db.query(EntityDatasetMapping).filter(
                    EntityDatasetMapping.entity_id == entity_id,
                    EntityDatasetMapping.dataset_id == dataset_id,
                    EntityDatasetMapping.is_active == True
                ).first()

                if not target_mapping:
                    raise HTTPException(
                        status_code=404,
                        detail=f"Entity dataset mapping with entity ID {entity_id} and dataset ID {dataset_id} not found or inactive"
                    )

                # Get all active mappings for this entity
                entity_mappings = self.db.query(EntityDatasetMapping).filter(
                    EntityDatasetMapping.entity_id == entity_id,
                    EntityDatasetMapping.is_active == True
                ).all()

                # If this is the only mapping, it must be primary
                if len(entity_mappings) == 1:
                    if not target_mapping.is_primary:
                        target_mapping.is_primary = True
                        self.db.merge(target_mapping)
                    return target_mapping

                # Update all mappings' primary status
                for mapping in entity_mappings:
                    # Set the target mapping to primary and all others to non-primary
                    mapping.is_primary = (mapping.dataset_id == dataset_id)
                    self.db.merge(mapping)

                # Flush to ensure all updates are processed
                self.db.flush()

            # Commit the transaction
            self.db.commit()

            # Refresh the target mapping to get the latest state
            self.db.refresh(target_mapping)

            return target_mapping

        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update entity dataset mapping primary status. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update entity dataset mapping primary status: {str(e)}"
            )
        
class SurvivorshipRuleService:
    def __init__(self, db: Session):
        """Initializes the entityService with a database session.
        
        Args:
            db: SQLAlchemy session object.
        """
        self.db = db

    def get_by_group_and_entity(self, entity_id: int, group_name: str):
        """Fetch a survivorship rule by group_name and entity_id.

        Args:
            entity_id: The entity ID.
            group_name: The group name for the survivorship rule.

        Returns:
            SurvivorshipRule instance if found, else None.
        """
        return (
            self.db.query(SurvivorshipRule)
            .filter(SurvivorshipRule.entity_id == entity_id)
            .filter(SurvivorshipRule.group_name == group_name)
            .first()
        )

    def read_survivorship_rule(self, entity_id:int,is_active: bool = True):
        """Retrieves entitys from the database based on the `is_active` flag.
        
        Args:
            is_active: Filter entitys by their active status.
            
        Returns:
            A list of entitys based on the `is_active` flag.
        """
        try:
            db_entity = self.db.query(Entity).filter(Entity.id == entity_id).first()

            # Raise an HTTPException with 404 status code if entity not found
            if db_entity is None:
              raise HTTPException(status_code=404, detail="Entity not found")
            entity_q = self.db.query(SurvivorshipRule).filter(SurvivorshipRule.entity_id == entity_id)
            if is_active:
                entity_q = entity_q.filter_by(is_active=is_active)
            entitys = entity_q.all()
            return entitys
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch survivorship rules: {str(e)}")

    def delete_survivorship_rule(self, entity_id: int, survivorship_id: int, token: str, is_integration_job: bool = False):
        """Deletes a survivorship rule permanently after validating constraints.
        
        This method handles:
        1. Validating entity and rule existence and active status
        2. Checking if the rule is default (cannot delete default rule if it's the only one)
        3. Ensuring atomic transaction with proper rollback
        
        Args:
            entity_id: ID of the entity that owns the rule
            survivorship_id: ID of the survivorship rule to delete
            
        Returns:
            HttpResponse with:
                - status: Success status
                - message: Detailed success message
                - data: None
                
        Raises:
            HTTPException: 
                - 404 if rule or entity not found
                - 400 if trying to delete the only default rule
                - 500 for system errors
        """
        try:
            app_logger.info(f"Starting deletion process for survivorship rule - Entity: {entity_id}, Rule: {survivorship_id}")
            
            # Start a nested transaction for atomicity
            with self.db.begin_nested():
                # First check if entity exists and is active
                entity = self.db.query(Entity).filter(
                    Entity.id == entity_id,
                    Entity.is_active == True
                ).first()
                
                if not entity:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail={
                            "status": "error",
                            "message": f"Active entity not found with ID {entity_id}",
                            "data": None
                        }
                    )

                # Fetch the survivorship rule with active status check
                db_survivorship = self.db.query(SurvivorshipRule).filter(
                    and_(
                        SurvivorshipRule.entity_id == entity_id,
                        SurvivorshipRule.survivorship_id == survivorship_id,
                        SurvivorshipRule.is_active == True
                    )
                ).first()
                
                if not db_survivorship:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail={
                            "status": "error",
                            "message": f"Active survivorship rule not found with ID {survivorship_id} for entity {entity_id}",
                            "data": None
                        }
                    )

                # Check if this is the only active rule
                other_rules = self.db.query(SurvivorshipRule).filter(
                    and_(
                        SurvivorshipRule.entity_id == entity_id,
                        SurvivorshipRule.survivorship_id != survivorship_id,
                        SurvivorshipRule.is_active == True
                    )
                ).first()
                
                if not other_rules:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": "Cannot delete the only survivorship rule. At least one rule must exist for the entity.",
                            "data": None
                        }
                    )

                # Prevent deletion of default rule
                if db_survivorship.is_default:
                    app_logger.warning(f"Attempted to delete default survivorship rule {survivorship_id}")
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": "Cannot delete a default survivorship rule. Please set another rule as default first.",
                            "data": None
                        }
                    )
                
                # All validations passed, proceed with deletion
                self.db.delete(db_survivorship)
                app_logger.debug(f"Marked survivorship rule {survivorship_id} for deletion")
                
                # Flush changes to ensure all operations succeeded
                self.db.flush()

                # If this mapping is part of an integration job, update its metadata file
                if is_integration_job:
                    app_logger.debug("Integration job detected - updating entity metadata file")
                    EntityService(self.db).update_entity_metadata_file_for_integration_job(token, entity_id)
            
            # Commit the transaction
            db_commit_auto_rollback(db=self.db)
            
            app_logger.info(f"Successfully deleted survivorship rule {survivorship_id} for entity {entity_id}")
            return HttpResponse(
                status="success",
                message=f"Survivorship rule deleted successfully.",
                data=None
            )
            
        except HTTPException as he:
            app_logger.warning(f"HTTP error during survivorship rule deletion: {he.detail}")
            raise he
            
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f"Failed to delete survivorship rule: {message}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "status": "error",
                    "message": f"Failed to delete survivorship rule: {str(e)}",
                    "data": None
                }
            )

    def get_survivorship_rule_by_id(self, entity_id: int,survivorship_id:int):
        """Retrieves a entity object by its ID.
        
        Args:
            entity_id: The ID of the entity to retrieve.
            
        Returns:
            The entity object.
        
        Raises:
            HTTPException: If the entity is not found.
        """
        try:
            # Fetch the entity by ID
            db_entity = self.db.query(SurvivorshipRule).filter(SurvivorshipRule.entity_id == entity_id).filter(SurvivorshipRule.survivorship_id == survivorship_id).first()
            if db_entity is None or not db_entity.is_active:
                return None
            return db_entity  # Return the found entity
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to fetch entity with ID {entity_id}. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to fetch survivorship rule: {str(e)}")

    def toggle_survivorship_rule_active(self, entity_id: int,survivorship_id:int):
        """Toggles the `is_active` flag of a entity.
        
        Args:
            entity_id: The ID of the entity to update.
            is_active: The new `is_active` status.
            
        Returns:
            The updated entity object.
        """
        try:
            db_entity = self.db.query(SurvivorshipRule).filter(SurvivorshipRule.entity_id == entity_id).filter(SurvivorshipRule.survivorship_id == survivorship_id).first()
            if db_entity is None:
                return None
            
            db_entity.is_active = not db_entity.is_active
            db_commit_auto_rollback(db=self.db)
            return db_entity
        except Exception as e:
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update entity active status. Reason - {message}')
            raise HTTPException(status_code=500, detail=f"Failed to update survivorship rule active status: {str(e)}")

    def create_survivorship_rule(self, survivorship_create: SurvivorshipRule, entity_id: int, token: str, is_integration_job: bool = False):
        """Creates a new survivorship rule and saves it to the database.
        
        This method handles:
        1. Validating entity existence and active status
        2. Managing default status according to business rules:
           - If first rule, must be default
           - If setting as default, update other rules
           - Ensure at least one default rule exists
        3. Validating attributes data
        4. Ensuring atomic transaction with proper rollback
        
        Args:
            survivorship_create: Pydantic model containing survivorship rule details.
            entity_id: ID of the entity to associate with.
                
        Returns:
            The created survivorship rule object.
        
        Raises:
            HTTPException: 
                - 404 if entity not found or inactive
                - 400 for invalid rule data
                - 500 for system errors
        """
        try:
            app_logger.info(f"Starting creation of survivorship rule for entity {entity_id}")
            
            # Begin transaction
            with self.db.begin_nested():
                # First check if entity exists and is active
                entity = self.db.query(Entity).filter(
                    Entity.id == entity_id,
                    Entity.is_active == True
                ).first()
                
                if not entity:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail={
                            "status": "error",
                            "message": f"Active entity not found with ID {entity_id}",
                            "data": None
                        }
                    )

                # Get all existing active rules for this entity
                existing_rules = self.db.query(SurvivorshipRule).filter(
                    and_(
                        SurvivorshipRule.entity_id == entity_id,
                        SurvivorshipRule.is_active == True
                    )
                ).all()
                
                # Validate rules array
                if not survivorship_create.rules:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": "At least one rule is required",
                            "data": None
                        }
                    )

                # Handle default rule logic
                if len(existing_rules) == 0:
                    # First rule must be default
                    if not survivorship_create.is_default:
                        app_logger.debug("First rule for entity - forcing default status")
                        survivorship_create.is_default = True
                elif survivorship_create.is_default:
                    # Update existing default rules
                    app_logger.debug("Setting new rule as default - updating existing defaults")
                    for rule in existing_rules:
                        if rule.is_default:
                            rule.is_default = False
                            self.db.merge(rule)

                try:
                    attributes_data = []
                    for attribute in survivorship_create.rules:
                        rule_dict = attribute.dict()
                        
                        rule_dict.setdefault('ignoreNull', False)
                        
                        # Handle aggregation-specific properties
                        if rule_dict['strategy'] == 'Aggregation':
                            rule_dict.setdefault('aggregateUniqueOnly', False)
                        else:
                            rule_dict.pop('aggregateUniqueOnly', None)

                        if rule_dict['strategy'] == 'Source System':
                            raw_tb = str(rule_dict.get('tieBreaker') or 'latest').lower()
                            rule_dict['tieBreaker'] = raw_tb if raw_tb in {'latest', 'earliest'} else 'latest'
                        else:
                            rule_dict.pop('tieBreaker', None)

                        attributes_data.append(rule_dict)
                        
                except Exception as e:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": f"Invalid rule attributes format: {str(e)}",
                            "data": None
                        }
                    )

                # Create new survivorship rule
                new_rule = SurvivorshipRule(
                    entity_id=entity_id,
                    group_name=survivorship_create.group_name,
                    description=survivorship_create.description,
                    is_default=survivorship_create.is_default,
                    rules=attributes_data,
                    created_by=survivorship_create.created_by
                )

                self.db.add(new_rule)
                app_logger.debug(f"Added new survivorship rule for entity {entity_id}")
                
                # Flush changes to ensure all operations succeeded
                self.db.flush()

                if is_integration_job or survivorship_create.is_default:
                    app_logger.debug(
                        "Regenerating entity metadata file "
                        f"(is_integration_job={is_integration_job}, "
                        f"is_default={survivorship_create.is_default})"
                    )
                    EntityService(self.db).update_entity_metadata_file_for_integration_job(token, entity_id)
            
            # Commit the transaction
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(new_rule)

            
            app_logger.info(f"Successfully created survivorship rule for entity {entity_id}")
            return HttpResponse(
                status="success",
                message="Survivorship rule created successfully",
                data=new_rule
            )

        except HTTPException as he:
            app_logger.warning(f"HTTP error during survivorship rule creation: {he.detail}")
            raise he
            
        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f"Failed to create survivorship rule: {message}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "status": "error",
                    "message": f"Failed to create survivorship rule: {str(e)}",
                    "data": None
                }
            )

    def update_survivorship_rule(self, survivorship_update: SurvivorshipRulesCreate, entity_id: int, survivorship_id: int, token: str, is_integration_job: bool = False):
        """Updates an existing survivorship rule and handles all related updates.
        
        This method handles:
        1. Validating rule existence and active status
        2. Managing default status changes:
           - If setting as default, reset other rules 
           - If removing default status, ensure another default exists
           - Maintain exactly one default rule per entity
        3. Validating and updating rules data
        4. Ensuring atomic transaction with proper rollback
        
        HTTP Method: PUT
        Endpoint Format: /survivorship-rules/{survivorship_id}
        
        Args:
            survivorship_update: Pydantic model containing updated rule details
            survivorship_id: ID of the survivorship rule to update
            
        Returns:
            HttpResponse with:
                - status: Success status
                - message: Detailed success message
                - data: Updated SurvivorshipRule object
                
        Raises:
            HTTPException: 
                - 404 if rule not found or inactive
                - 400 for invalid data or default status conflicts
                - 500 for system errors
        """
        try:
            app_logger.info(f"Starting survivorship rule update for rule {survivorship_id}")
            
            # Start a nested transaction for atomicity
            with self.db.begin_nested():
                # Fetch and validate the existing rule with active status check
                SR = SurvivorshipRule
                existing_rule = (
                    self.db.query(SR).filter(
                        and_(
                            SR.survivorship_id == survivorship_id,
                            SR.is_active == True
                        )
                    ).first()
                )
                
                if not existing_rule:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND, 
                        detail={
                            "status": "error", 
                            "message": f"Active survivorship rule not found with ID {survivorship_id}", 
                            "data": None
                        }
                    )

                entity_id = existing_rule.entity_id

                # Validate rules array
                if not survivorship_update.rules:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": "At least one rule is required",
                            "data": None
                        }
                    )

                # Handle default status changes
                if survivorship_update.is_default:
                    app_logger.debug(f"Setting rule {survivorship_id} as default")
                    
                    # Reset all other rules' default status
                    default_updates = (
                        self.db.query(SR).filter(
                            and_(
                                SR.entity_id == entity_id,
                                SR.is_active == True,
                                SR.survivorship_id != survivorship_id,
                                SR.is_default == True
                            )
                        ).update({'is_default': False}, synchronize_session=False)
                    )
                    
                    if default_updates:
                        app_logger.debug(f"Reset default flag for {default_updates} other rule(s)")
                elif existing_rule.is_default:
                    # If removing default status, ensure another default exists or can be set
                    other_rules = (
                        self.db.query(SR).filter(
                            and_(
                                SR.entity_id == entity_id,
                                SR.is_active == True,
                                SR.survivorship_id != survivorship_id
                            )
                        ).all()
                    )
                    
                    if not other_rules:
                        app_logger.warning("Attempted to remove default status from only rule")
                        raise HTTPException(
                            status_code=status.HTTP_400_BAD_REQUEST,
                            detail={
                                "status": "error",
                                "message": "Cannot remove default status from the only rule",
                                "data": None
                            }
                        )
                    
                    # Set the first other rule as default
                    other_rules[0].is_default = True
                    self.db.merge(other_rules[0])
                    app_logger.debug(f"Set rule {other_rules[0].survivorship_id} as new default")

                try:
                    attributes_data = []
                    for attribute in survivorship_update.rules:
                        rule_dict = attribute.dict()
                        
                        # Ensure ignoreNull exists for all strategies
                        rule_dict.setdefault('ignoreNull', False)
                        
                        if rule_dict['strategy'] == 'Aggregation':
                            rule_dict.setdefault('aggregateUniqueOnly', False)
                        else:
                            rule_dict.pop('aggregateUniqueOnly', None)
                        
                        if rule_dict['strategy'] == 'Source System':
                            raw_tb = str(rule_dict.get('tieBreaker') or 'latest').lower()
                            rule_dict['tieBreaker'] = raw_tb if raw_tb in {'latest', 'earliest'} else 'latest'
                        else:
                            rule_dict.pop('tieBreaker', None)
                        
                        attributes_data.append(rule_dict)
                        
                except Exception as e:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail={
                            "status": "error",
                            "message": f"Invalid rule data format: {str(e)}",
                            "data": None
                        }
                    )

                # Update the existing rule
                existing_rule.group_name = survivorship_update.group_name
                existing_rule.description = survivorship_update.description
                existing_rule.is_default = survivorship_update.is_default
                existing_rule.rules = attributes_data
                existing_rule.created_by = survivorship_update.created_by

                self.db.merge(existing_rule)
                app_logger.debug(f"Updated survivorship rule {survivorship_id}")
                
                # Flush changes to ensure all operations succeeded
                self.db.flush()
                
                default_touched = survivorship_update.is_default or existing_rule.is_default
                if is_integration_job or default_touched:
                    app_logger.debug(
                        "Regenerating entity metadata file "
                        f"(is_integration_job={is_integration_job}, "
                        f"default_touched={default_touched})"
                    )
                    EntityService(self.db).update_entity_metadata_file_for_integration_job(token, entity_id)

            # Commit the transaction
            db_commit_auto_rollback(db=self.db)
            self.db.refresh(existing_rule)

            
            app_logger.info(f"Successfully updated survivorship rule {survivorship_id}")
            return HttpResponse(
                status="success",
                message="Survivorship rule updated successfully",
                data=existing_rule
            )

        except HTTPException as he:
            app_logger.warning(f"HTTP error during survivorship rule update: {he.detail}")
            raise he
            
        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f"Failed to update survivorship rule: {message}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "status": "error",
                    "message": f"Failed to update survivorship rule: {str(e)}",
                    "data": None
                }
            )
        
    def update_survivorship_default(self, entity_id: int, survivorship_id: int):
        """
        Updates the default status of a survivorship rule and ensures only one rule
        is default per entity.
        
        Args:
            entity_id: ID of the entity
            survivorship_id: ID of the survivorship rule to make default
            
        Returns:
            Updated survivorship rule object
            
        Raises:
            HTTPException: If rule not found or error occurs during update
        """
        try:
            # Begin transaction
            with self.db.begin_nested():
                # Check if the target rule exists and is active
                target_rule = self.db.query(SurvivorshipRule).filter(
                    SurvivorshipRule.entity_id == entity_id,
                    SurvivorshipRule.survivorship_id == survivorship_id,
                    SurvivorshipRule.is_active == True
                ).first()
                
                if not target_rule:
                    raise HTTPException(
                        status_code=404,
                        detail=f"Survivorship rule with ID {survivorship_id} not found or inactive"
                    )
                
                # Get all active rules for this entity
                entity_rules = self.db.query(SurvivorshipRule).filter(
                    SurvivorshipRule.entity_id == entity_id,
                    SurvivorshipRule.is_active == True
                ).all()
                
                # If this is the only rule, it must be default
                if len(entity_rules) == 1:
                    if not target_rule.is_default:
                        target_rule.is_default = True
                        self.db.merge(target_rule)
                    return target_rule
                
                # Update all rules' default status
                for rule in entity_rules:
                    # Set the target rule to default and all others to non-default
                    rule.is_default = (rule.survivorship_id == survivorship_id)
                    self.db.merge(rule)
                    
                # Flush to ensure all updates are processed
                self.db.flush()
                
            # Commit the transaction
            self.db.commit()
            
            # Refresh the target rule to get the latest state
            self.db.refresh(target_rule)
            
            return target_rule
            
        except Exception as e:
            self.db.rollback()
            message = traceback.format_exc()
            app_logger.exception(f'Unable to update survivorship rule default status. Reason - {message}')
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update survivorship rule default status: {str(e)}"
            )
