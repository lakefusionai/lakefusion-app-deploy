"""Shared SQL predicate builder for Entity Search / Potential-Match filters.

Both ``EntitySearchService.build_filter_clauses`` and
``ExperimentService.build_filter_clauses`` feed the SAME filter payload
(built by the Entity Search "Filter Records" drawer). They used to apply
``UPPER(col)`` to every column unconditionally, which fails on complex
columns:

    [DATATYPE_MISMATCH.UNEXPECTED_INPUT_TYPE] Cannot resolve
    "upper(insurance_policies)" ... "insurance_policies" has the type
    ARRAY<STRUCT<...>>

This module centralizes per-filter SQL generation so the two callers stay
in sync. It understands three shapes, driven by the payload fields
``isArray`` / ``subField`` / ``subFieldType`` the UI now sends:

* scalar column            -> predicate on the column directly
* STRUCT column + subField -> predicate on ``col.`field` ``
* ARRAY column (of scalars or structs) -> ``EXISTS(col, x -> <predicate>)``
  so "matches if ANY element satisfies the condition".

``UPPER`` is only ever applied to the scalar *leaf*; non-string leaves are
``CAST(... AS STRING)`` first, so text operators never hit a complex type.
"""

import re

_IDENT_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')

_STRING_TYPES = {'string', 'text', 'varchar', 'char'}
_DATE_TYPES = {'date', 'datetime', 'timestamp'}
_NUMERIC_TYPES = {
    'integer', 'numeric', 'number', 'decimal', 'float', 'int', 'bigint',
    'long', 'smallint', 'tinyint', 'double', 'double precision', 'real',
}

_STRING_OPS = {'eq', 'neq', 'contains', 'not_contains', 'starts_with', 'ends_with'}
_NUMERIC_OPS = {'gt', 'lt', 'gte', 'lte'}
# Operators that, inside an array, mean "no element matches" — built as the
# positive predicate then wrapped in NOT EXISTS.
_NEGATIVE_OPS = {'neq', 'not_contains'}
ALLOWED_OPERATORS = (
    _STRING_OPS | _NUMERIC_OPS | {'is_null', 'is_not_null', 'eq_true', 'eq_false'}
)


def _esc(value):
    """Escape single quotes to keep string literals from breaking the SQL."""
    return str(value).replace("'", "''")


def _string_target(expr, leaf_type):
    """STRING leaves are UPPER-ed directly; everything else is cast first so
    text operators never run UPPER() against a non-string type."""
    return expr if leaf_type.lower() in _STRING_TYPES else f"CAST({expr} AS STRING)"


def _scalar_predicate(expr, operator, value, leaf_type, positive_only=False):
    """Build the SQL predicate for one scalar leaf expression.

    ``positive_only`` (used for array EXISTS wrapping) maps the negative
    operators to their positive form; the caller adds the surrounding NOT.
    Returns "" for an unsupported operator.
    """
    op = operator
    if positive_only:
        if op == 'neq':
            op = 'eq'
        elif op == 'not_contains':
            op = 'contains'

    if op in _STRING_OPS:
        target = _string_target(expr, leaf_type)
        v = _esc(value)
        if op == 'eq':
            return f"UPPER({target}) = UPPER('{v}')"
        if op == 'neq':
            return f"UPPER({target}) != UPPER('{v}')"
        if op == 'contains':
            return f"UPPER({target}) LIKE UPPER('%{v}%')"
        if op == 'not_contains':
            return f"UPPER({target}) NOT LIKE UPPER('%{v}%')"
        if op == 'starts_with':
            return f"UPPER({target}) LIKE UPPER('{v}%')"
        if op == 'ends_with':
            return f"UPPER({target}) LIKE UPPER('%{v}')"

    if op in _NUMERIC_OPS:
        # Dates compare as quoted literals; numerics are emitted bare.
        val = f"'{_esc(value)}'" if leaf_type.lower() in _DATE_TYPES else value
        sym = {'gt': '>', 'lt': '<', 'gte': '>=', 'lte': '<='}[op]
        return f"{expr} {sym} {val}"

    if op == 'eq_true':
        return f"{expr} = TRUE"
    if op == 'eq_false':
        return f"{expr} = FALSE"

    return ""


def build_single_filter_sql(filter_item, table_prefix=None):
    """Return the SQL fragment for one filter item, or "" to skip it.

    Recognised payload keys: attributeName/attributeId, operator, value,
    attributeType (base column type), subField (struct field name),
    subFieldType (leaf type for the field / array element), isArray.
    """
    attribute_name = filter_item.get('attributeName') or filter_item.get('attributeId')
    operator = filter_item.get('operator')
    value = filter_item.get('value')
    sub_field = filter_item.get('subField') or None
    is_array = bool(filter_item.get('isArray'))
    leaf_type = (
        filter_item.get('subFieldType')
        or filter_item.get('attributeType')
        or 'string'
    )

    if not attribute_name or operator not in ALLOWED_OPERATORS:
        return ""

    # Guard against SQL injection via identifiers (values are quoted/escaped).
    if not _IDENT_RE.match(str(attribute_name)):
        return ""
    if sub_field is not None and not _IDENT_RE.match(str(sub_field)):
        return ""

    # Numeric comparison values are interpolated bare (unquoted) for every
    # non-date leaf, so they MUST parse as a float — otherwise a crafted
    # payload like value="0 OR 1=1" would inject SQL. Dates are quoted+escaped
    # in _scalar_predicate instead, so they are exempt here.
    if operator in _NUMERIC_OPS and leaf_type.lower() not in _DATE_TYPES:
        try:
            float(value)
        except (ValueError, TypeError):
            return ""

    base = f"{table_prefix}.`{attribute_name}`" if table_prefix else f"`{attribute_name}`"

    if is_array:
        # Null checks apply to the array column as a whole.
        if operator == 'is_null':
            return f"({base} IS NULL OR SIZE({base}) = 0)"
        if operator == 'is_not_null':
            return f"({base} IS NOT NULL AND SIZE({base}) > 0)"

        element = f"x.`{sub_field}`" if sub_field else "x"
        inner = _scalar_predicate(element, operator, value, leaf_type, positive_only=True)
        if not inner:
            return ""
        exists = f"EXISTS({base}, x -> {inner})"
        return f"NOT {exists}" if operator in _NEGATIVE_OPS else exists

    # Scalar column or a single (non-array) struct field.
    leaf = f"{base}.`{sub_field}`" if sub_field else base
    if operator == 'is_null':
        return f"{leaf} IS NULL"
    if operator == 'is_not_null':
        return f"{leaf} IS NOT NULL"
    return _scalar_predicate(leaf, operator, value, leaf_type)
