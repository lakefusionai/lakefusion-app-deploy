"""
Service for catalog-level resource provisioning.
Individual methods called directly from alembic migrations, settings API, etc.
"""

from sqlalchemy.orm import Session
from lakefusion_utility.utils.logging_utils import get_logger
from lakefusion_utility.utils.databricks_util import DataSetSQLService

logger = get_logger(__name__)


class CatalogSetupService:

    def __init__(self, token: str, warehouse_id: str, catalog_name: str, db: Session = None):
        self.token = token
        self.warehouse_id = warehouse_id
        self.catalog_name = catalog_name
        self.db = db

    def register_survivorship_udf(self) -> bool:
        """Register survivorship_apply UC Python UDF. Safe to call multiple times (CREATE OR REPLACE)."""
        logger.info(f"Registering survivorship UDF on {self.catalog_name}.metadata.survivorship_apply ...")
        try:
            sql_service = DataSetSQLService(self.token, self.warehouse_id)
            sql_service.execute_sql_script(self._build_survivorship_udf_sql())
            logger.info(f"Successfully registered survivorship UDF: {self.catalog_name}.metadata.survivorship_apply")
            return True
        except Exception as e:
            logger.exception(f"Failed to register survivorship UDF on {self.catalog_name}: {e}")
            return False

    def _build_survivorship_udf_sql(self) -> str:
        """Dynamically build the survivorship UDF SQL from the installed lakefusion_core_engine package."""
        catalog = self.catalog_name
        udf_body = self._build_udf_body_from_sdk()
        # Escape curly braces for f-string (UDF body contains dict literals)
        return f"""CREATE OR REPLACE FUNCTION {catalog}.metadata.survivorship_apply(
  unified_records_json STRING,
  survivorship_rules_json STRING,
  entity_attributes_json STRING,
  entity_attributes_datatype_json STRING,
  id_key STRING
)
RETURNS STRING
LANGUAGE PYTHON
DETERMINISTIC
COMMENT 'Applies survivorship rules to unified records. Auto-generated from lakefusion_core_engine SDK.'
AS $$
{udf_body}
$$
"""

    def _build_udf_body_from_sdk(self) -> str:
        """Read survivorship SDK source files and flatten into a single UDF body."""
        import re
        import inspect

        try:
            from lakefusion_core_engine.survivorship import engine as engine_mod
            from lakefusion_core_engine.survivorship.utils import helpers as helpers_mod
            from lakefusion_core_engine.survivorship.models import config as config_mod
            from lakefusion_core_engine.survivorship.models import result as result_mod
            from lakefusion_core_engine.survivorship.strategies import base as base_mod
            from lakefusion_core_engine.survivorship.strategies import recency_strategy as recency_mod
            from lakefusion_core_engine.survivorship.strategies import source_system_strategy as source_mod
            from lakefusion_core_engine.survivorship.strategies import aggregation_strategy as agg_mod
            from lakefusion_core_engine.survivorship.strategies import frequency_strategy as freq_mod
            from lakefusion_core_engine.survivorship.strategies import struct_merge_strategy as struct_mod
        except ImportError as e:
            logger.warning(f"Could not import lakefusion_core_engine survivorship modules: {e}")
            logger.warning("Falling back to hardcoded UDF body")
            return self._hardcoded_udf_body()

        # Read sources in dependency order
        modules = [
            helpers_mod, config_mod, result_mod, base_mod,
            recency_mod, source_mod, agg_mod, freq_mod, struct_mod, engine_mod
        ]

        combined_parts = []
        seen_imports = set()

        for mod in modules:
            source = inspect.getsource(mod)
            cleaned = self._strip_internal_imports(source)
            # Deduplicate stdlib imports
            lines = cleaned.split('\n')
            deduped = []
            for line in lines:
                stripped = line.strip()
                if stripped.startswith(('from ', 'import ')) and stripped not in seen_imports:
                    seen_imports.add(stripped)
                    deduped.append(line)
                elif not stripped.startswith(('from ', 'import ')):
                    deduped.append(line)
            combined_parts.append('\n'.join(deduped))

        body = '\n\n'.join(combined_parts)

        # Add the UDF handler
        handler = """

# === UDF Handler ===
def _udf_handler(unified_records_json, survivorship_rules_json, entity_attributes_json, entity_attributes_datatype_json, id_key):
    import json as _json
    unified_records = _json.loads(unified_records_json)
    survivorship_rules = _json.loads(survivorship_rules_json)
    entity_attributes = _json.loads(entity_attributes_json)
    entity_attributes_datatype = _json.loads(entity_attributes_datatype_json)

    engine = SurvivorshipEngine(
        survivorship_config=survivorship_rules,
        entity_attributes=entity_attributes,
        entity_attributes_datatype=entity_attributes_datatype,
        id_key=id_key
    )
    result = engine.apply_survivorship(unified_records=unified_records)
    return _json.dumps(result.to_dict())

return _udf_handler(unified_records_json, survivorship_rules_json, entity_attributes_json, entity_attributes_datatype_json, id_key)
"""
        body += handler
        logger.info(f"Built dynamic UDF body: {len(body.split(chr(10)))} lines, {len(body)} chars")
        return body

    @staticmethod
    def _strip_internal_imports(source: str) -> str:
        """Remove relative imports and lakefusion_core_engine imports, including multi-line."""
        import re
        lines = source.split('\n')
        result = []
        in_import_block = False

        for line in lines:
            if re.match(r'^\s*from\s+\.', line) or 'lakefusion_core_engine' in line:
                if '(' in line and ')' not in line:
                    in_import_block = True
                continue
            if in_import_block:
                if ')' in line:
                    in_import_block = False
                continue
            result.append(line)

        return '\n'.join(result)

    @staticmethod
    def _hardcoded_udf_body() -> str:
        """Fallback hardcoded UDF body if SDK import fails."""
        logger.warning("Using hardcoded survivorship UDF body — SDK not available")
        return """
import json
from datetime import datetime, date
from collections import Counter
# FALLBACK: SDK not available. This is a minimal survivorship implementation.
# Install lakefusion_core_engine wheel to enable dynamic UDF generation.
def _udf_handler(unified_records_json, survivorship_rules_json, entity_attributes_json, entity_attributes_datatype_json, id_key):
    return json.dumps({"resultant_record": {}, "resultant_master_attribute_source_mapping": []})
return _udf_handler(unified_records_json, survivorship_rules_json, entity_attributes_json, entity_attributes_datatype_json, id_key)
"""


