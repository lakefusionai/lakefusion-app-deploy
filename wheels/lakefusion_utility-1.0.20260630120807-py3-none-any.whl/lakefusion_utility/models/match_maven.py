from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, ForeignKey, JSON
from datetime import datetime
from lakefusion_utility.utils.app_db import Base
from pydantic import BaseModel
from typing import Optional, Any, Dict, Union, List, Literal
from sqlalchemy.orm import relationship, Session
from lakefusion_utility.models.quality_tasks import QualityTask
from lakefusion_utility.models.dataset import Dataset
from lakefusion_utility.models.entity import Entity
from lakefusion_utility.models.dataset import Dataset
from lakefusion_utility.models.entity import Entity
from lakefusion_utility.models.base_prompt import BasePromptResponse
from lakefusion_utility.utils.lf_utils import get_version_info
from enum import Enum

# Base Pydantic models for LLM
#
# The three LLM-param fields (temperature, max_tokens, reasoning_effort) use
# `null` to mean "off" — the field is omitted from the actual LLM API call
# downstream. Pydantic's default `exclude_none=True` would strip explicit
# nulls on the way to storage, so each Model_LLM_* class overrides .dict()
# to keep the three keys present even when their value is None. This is the
# signal the parse notebook reads to skip the param in the LLM call.
#
# Legacy `*_enabled` fields (temperature_enabled, max_tokens_enabled,
# reasoning_effort_enabled) are no longer part of the schema — the parse
# notebook's _resolve_llm_param still accepts them on read for backward
# compatibility with already-persisted JSONs.

_LLM_PARAM_KEYS = ("temperature", "max_tokens", "reasoning_effort")

class _PreserveParamNullsMixin:
    """
    Pydantic mixin: render the model to a dict, then re-insert the three
    LLM-param keys explicitly so an explicit `None` ("off") survives
    `exclude_none=True` filtering at the parent LLM_Model level. This is
    what tells the parse notebook to skip the field in the downstream
    LLM API call instead of forcing it on at a default value.
    """

    def dict(self, *args, **kwargs):
        base = BaseModel.dict(self, *args, **kwargs)
        for key in _LLM_PARAM_KEYS:
            if key in self.__fields__:
                base[key] = getattr(self, key)
        return base

class Model_LLM_Databricks_Foundation(_PreserveParamNullsMixin, BaseModel):
    foundation_model_name: str
    provisionless: bool = False
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    reasoning_effort: Optional[str] = None

class Model_LLM_External_API(_PreserveParamNullsMixin, BaseModel):
    end_point_url: str
    password: str
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    reasoning_effort: Optional[str] = None

class Model_LLM_Databricks_Custom(_PreserveParamNullsMixin, BaseModel):
    modeltype: str
    modelname: str
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    reasoning_effort: Optional[str] = None

class LLM_Model(BaseModel):
    databricks_foundation: Optional[Model_LLM_Databricks_Foundation] = None
    databricks_custom: Optional[Model_LLM_Databricks_Custom] = None
    external_model_api: Optional[Model_LLM_External_API] = None

    def dict(self, *args, **kwargs):
        # Pydantic v1's super().dict() recursively serializes nested models
        # using internal logic, which BYPASSES the _PreserveParamNullsMixin
        # override on the source classes — so explicit `None` ("off") values
        # for temperature / max_tokens / reasoning_effort would be stripped
        # by Pydantic's default rendering and `exclude_none=True` filtering.
        # Instead, call each non-None source's .dict() explicitly so the
        # mixin runs and re-inserts the three null params.
        result = {}
        if self.databricks_foundation is not None:
            result['databricks_foundation'] = self.databricks_foundation.dict()
        if self.databricks_custom is not None:
            result['databricks_custom'] = self.databricks_custom.dict()
        if self.external_model_api is not None:
            result['external_model_api'] = self.external_model_api.dict()
        return result

# Base Pydantic models for Embedding
class Embedding_Model_LLM_Databricks_Foundation(BaseModel):
    foundation_model_name: str
    provisionless: bool = False  # Provisionless: use provision-less endpoint if True

    def dict(self, *args, **kwargs):
        return super().dict(*args, **kwargs)

class Embedding_Model_LLM_External_API(BaseModel):
    end_point_url: str
    password: str

    def dict(self, *args, **kwargs):
        return super().dict(*args, **kwargs)

class Embedding_Model_LLM_Databricks_Custom(BaseModel):
    modeltype: str
    modelname: str

    def dict(self, *args, **kwargs):
        return super().dict(*args, **kwargs)

class Embedding_Model(BaseModel):
    databricks_foundation: Optional[Embedding_Model_LLM_Databricks_Foundation] = None
    databricks_custom: Optional[Embedding_Model_LLM_Databricks_Custom] = None
    external_model_api: Optional[Embedding_Model_LLM_External_API] = None

    def dict(self, *args, **kwargs):
        base_dict = super().dict(*args, exclude_none=True, **kwargs)
        return {k: v.dict() if hasattr(v, 'dict') else v 
                for k, v in base_dict.items() if v is not None}

class Config_Threshold(BaseModel):
    matches: List[float]
    merge: List[float]
    not_match: List[float]

    def dict(self, *args, **kwargs):
        return super().dict(*args, **kwargs)
    
class EntityAttributes(BaseModel):
    id: int
    entity_id: int
    name: str
    description: Optional[str]
    type: str
    label: str
    created_at: datetime
    created_by: str
    is_active: bool
    is_primary_key: bool
    show_in_ui: bool
    is_label: bool
    type_config: Optional[Dict[str, Any]] = None
    # SCRUM (sub-field selection): for STRUCT / ARRAY<STRUCT> attributes,
    # users may opt to narrow the LLM prompt + AI matching focus to a subset
    # of struct sub-fields. None / empty list = use all fields.
    selected_sub_fields: Optional[List[str]] = None
    # Convenience fields surfaced from the entity attribute response so the
    # frontend doesn't need a second lookup to render the sub-field selector.
    is_array: Optional[bool] = None
    struct_definition_id: Optional[int] = None
    struct_definition: Optional[Dict[str, Any]] = None

    def dict(self, *args, **kwargs):
        d = super().dict(*args, **kwargs)
        # Convert datetime to ISO format string
        if isinstance(d.get('created_at'), datetime):
            d['created_at'] = d['created_at'].isoformat()
        return d

class DeterministicCondition(BaseModel):
    attribute: str
    # Dot-notation path to a nested field within a STRUCT attribute.
    # e.g. "city", "address.city". None = compare full attribute value.
    sub_field: Optional[str] = None
    match_type: str  # "exact" | "fuzzy"
    # exact  (all types): "equality"
    # fuzzy  (scalar/struct): "levenshtein_normalized" | "levenshtein_standard" | "jaro_winkler" | "soundex"
    # fuzzy  (array): "intersect" | "disjoint" | "subset" | "superset"
    function: Optional[str] = None
    operator: Optional[str] = None  # "<=", "<", ">=", ">", "=", "!=" — null for array fuzzy
    threshold: Optional[float] = None  # null for exact and array fuzzy
    allow_nulls: bool = False
    case_insensitive: bool = False
    logical_operator: Optional[Literal["AND", "OR"]] = None

    def dict(self, *args, **kwargs):
        return super().dict(*args, **kwargs)

class DeterministicRule(BaseModel):
    name: Optional[str] = None
    logical_operator: str = "AND"  # "AND" | "OR"
    action_on_match: str = "auto-merge"
    conditions: List[DeterministicCondition] = []

    def dict(self, *args, **kwargs):
        base_dict = super().dict(*args, **kwargs)
        base_dict['conditions'] = [c.dict() for c in self.conditions]
        return base_dict

class DeterministicRules(BaseModel):
    enabled: bool = True
    rules: List[DeterministicRule] = []

    def dict(self, *args, **kwargs):
        base_dict = super().dict(*args, **kwargs)
        base_dict['rules'] = [r.dict() for r in self.rules]
        return base_dict

class Model_ExperimentCreate(BaseModel):
    entity_id: int
    base_prompt_id:Optional[int]=None
    status: str
    modelname: str
    description: Optional[str] = None
    llm_model_source: str
    llm_model: 'LLM_Model'
    embedding_model_source: str
    embedding_model: 'Embedding_Model'
    attributes: List[EntityAttributes]
    vs_endpoint: str
    additional_instructions: str
    max_potential_matches: int
    processed_record: int
    config_thresold: Optional['Config_Threshold'] = None
    deterministic_rules: Optional['DeterministicRules'] = None
    embedding_mode: Optional[str] = "managed"
    created_by: Optional[str] = ''
    created_at: datetime = datetime.now()
    version: Optional[str] = None

    class Config:
        arbitrary_types_allowed = True

    def dict(self, *args, **kwargs):
        base_dict = super().dict(*args, exclude_none=True, **kwargs)
        # Convert nested models to dict
        base_dict['llm_model'] = self.llm_model.dict()
        base_dict['embedding_model'] = self.embedding_model.dict()
        if self.config_thresold:
            base_dict['config_thresold'] = self.config_thresold.dict()
        if self.deterministic_rules:
            base_dict['deterministic_rules'] = self.deterministic_rules.dict()
        # Convert attributes list
        base_dict['attributes'] = [attr.dict() for attr in self.attributes]
        # Convert datetime to ISO format string
        if isinstance(base_dict.get('created_at'), datetime):
            base_dict['created_at'] = base_dict['created_at'].isoformat()
        return base_dict

# SQLAlchemy Model
class Model_Experiment(Base):
    __tablename__ = 'model_experiments'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(Integer, ForeignKey('entity.id'), nullable=False) 
    base_prompt_id = Column(Integer,ForeignKey('base_prompts.id'), nullable=True)
    status = Column(String(255), nullable=False)
    modelname = Column(String(255), nullable=False)
    description = Column(String(255), nullable=True)
    llm_model_source = Column(String(255), nullable=False)
    llm_model = Column(JSON, nullable=False)
    embedding_model_source = Column(String(255), nullable=False)
    embedding_model = Column(JSON, nullable=False)
    config_thresold = Column(JSON, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)    
    created_by = Column(String(255), nullable=False)
    vs_endpoint = Column(String(255),nullable=False)
    additional_instructions = Column(Text, nullable=True)
    attributes = Column(JSON, nullable=False)
    processed_record=Column(Integer, nullable=True)
    max_potential_matches=Column(Integer, nullable=False, server_default="3")
    version = Column(String(255), nullable=True)
    deterministic_rules = Column(JSON, nullable=True)
    embedding_mode = Column(String(20), nullable=True, server_default="managed")
    entity = relationship("Entity")
    base_prompt = relationship("BasePrompt", back_populates="model_experiments")

    def __init__(self, entity_id, status, modelname, description, llm_model_source, llm_model,
                 embedding_model_source, embedding_model, attributes,vs_endpoint, additional_instructions, processed_record, max_potential_matches,base_prompt_id, config_thresold, created_by, version=None, deterministic_rules=None, embedding_mode="managed"):
        self.entity_id = entity_id
        self.status = status
        self.modelname = modelname
        self.description = description
        self.llm_model_source = llm_model_source
        self.llm_model = llm_model.dict() if hasattr(llm_model, 'dict') else llm_model
        self.embedding_model_source = embedding_model_source
        self.embedding_model = embedding_model.dict() if hasattr(embedding_model, 'dict') else embedding_model
        self.attributes = attributes
        self.vs_endpoint = vs_endpoint
        self.additional_instructions = additional_instructions
        self.processed_record = processed_record
        self.max_potential_matches = max_potential_matches
        self.base_prompt_id = base_prompt_id
        self.config_thresold = config_thresold.dict() if hasattr(config_thresold, 'dict') else config_thresold
        self.created_by = created_by
        self.version = version if version else get_version_info()["productVersion"]
        self.deterministic_rules = deterministic_rules.dict() if hasattr(deterministic_rules, 'dict') else deterministic_rules
        self.embedding_mode = embedding_mode


class Model_ExperimentResponse(BaseModel):
    id: int
    entity_id: int
    base_prompt_id:Optional[int]=None
    base_prompt: Optional[BasePromptResponse] = None
    status: str
    modelname: str
    description: Optional[str] = None
    llm_model_source: str
    llm_model: Dict[str, Any]  # Dictionary to hold the serialized LLM model
    embedding_model_source: str
    embedding_model: Dict[str, Any]  # Dictionary to hold the serialized embedding model
    attributes: Optional[List[EntityAttributes]] = None
    vs_endpoint: str
    additional_instructions: Optional[str] = None
    processed_record: int
    max_potential_matches: int
    config_thresold: Optional[Config_Threshold] = None
    deterministic_rules: Optional[Dict[str, Any]] = None
    embedding_mode: Optional[str] = "managed"
    created_at: datetime
    created_by: str
    is_outdated: Optional[bool] = False
    version: Optional[str] = None

    class Config:
        from_attributes = True  # This replaces the old orm_mode=True
        arbitrary_types_allowed = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

    @classmethod
    def from_orm(cls, db_instance: Model_Experiment, is_outdated: bool = False):
        """Custom from_orm method to handle complex JSON fields and is_outdated calculation"""
        # Create a dict of the database instance
        db_dict = {
            'id': db_instance.id,
            'entity_id': db_instance.entity_id,
            'base_prompt_id': db_instance.base_prompt_id,
            'base_prompt': (BasePromptResponse.from_orm(db_instance.base_prompt) if db_instance.base_prompt else None),
            'status': db_instance.status,
            'modelname': db_instance.modelname,
            'description': db_instance.description,
            'llm_model_source': db_instance.llm_model_source,
            'llm_model': db_instance.llm_model,  # Already a dict from JSON column
            'embedding_model_source': db_instance.embedding_model_source,
            'embedding_model': db_instance.embedding_model,  # Already a dict from JSON column
            'attributes': db_instance.attributes,
            'vs_endpoint': db_instance.vs_endpoint,
            'additional_instructions': db_instance.additional_instructions,
            'processed_record' : db_instance.processed_record,
            'max_potential_matches': db_instance.max_potential_matches,
            'config_thresold': db_instance.config_thresold,  # Already a dict from JSON column
            'deterministic_rules': db_instance.deterministic_rules,  # Already a dict from JSON column
            'embedding_mode': db_instance.embedding_mode or "managed",
            'created_at': db_instance.created_at,
            'created_by': db_instance.created_by,
            'is_outdated': is_outdated,  # Use the calculated value passed as parameter
            'version': db_instance.version,
        }
        return cls(**db_dict)

class Model_GetExperimentResponse(BaseModel):
    id: int
    entity_id: int
    base_prompt_id:Optional[int]=None
    base_prompt: Optional[BasePromptResponse] = None
    status: str
    modelname: str
    description: Optional[str] = None
    llm_model_source: str
    llm_model: Dict[str, Any]  # Dictionary to hold the serialized LLM model
    embedding_model_source: str
    embedding_model: Dict[str, Any]  # Dictionary to hold the serialized embedding model
    attributes: Optional[List[EntityAttributes]] = None
    vs_endpoint: str
    additional_instructions: Optional[str] = None
    processed_record: int
    max_potential_matches: int
    config_thresold: Optional[Config_Threshold] = None
    deterministic_rules: Optional[Dict[str, Any]] = None
    embedding_mode: Optional[str] = "managed"
    created_at: datetime
    created_by: str
    is_outdated: Optional[bool] = False
    effective_job_link:Optional[str]
    version: Optional[str] = None
    class Config:
        from_attributes = True  # This replaces the old orm_mode=True
        arbitrary_types_allowed = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
    @classmethod
    def from_orm(cls, db_instance: Model_Experiment, effective_job_link:str, is_outdated: bool = False):
        """Custom from_orm method to handle complex JSON fields and is_outdated calculation"""
        # Create a dict of the database instance
        db_dict = {
            'id': db_instance.id,
            'entity_id': db_instance.entity_id,
            'base_prompt_id':db_instance.base_prompt_id,
            'base_prompt':db_instance.base_prompt,
            'status': db_instance.status,
            'modelname': db_instance.modelname,
            'description': db_instance.description,
            'llm_model_source': db_instance.llm_model_source,
            'llm_model': db_instance.llm_model,  # Already a dict from JSON column
            'embedding_model_source': db_instance.embedding_model_source,
            'embedding_model': db_instance.embedding_model,  # Already a dict from JSON column
            'attributes': db_instance.attributes,
            'vs_endpoint': db_instance.vs_endpoint,
            'additional_instructions': db_instance.additional_instructions,
            'processed_record' : db_instance.processed_record,
            'max_potential_matches': db_instance.max_potential_matches,
            'config_thresold': db_instance.config_thresold,  # Already a dict from JSON column
            'deterministic_rules': db_instance.deterministic_rules,  # Already a dict from JSON column
            'embedding_mode': db_instance.embedding_mode or "managed",
            'created_at': db_instance.created_at,
            'created_by': db_instance.created_by,
            'is_outdated': is_outdated,  # Use the calculated value passed as parameter
            'effective_job_link':effective_job_link,
            'version': db_instance.version,
        }
        return cls(**db_dict)


class Model_ExperimentUpdateRequest(BaseModel):
    modelname: Optional[str] = None
    base_prompt_id:Optional[int]= None
    status: Optional[str] = None
    description: Optional[str] = None
    llm_model_source: Optional[str] = None
    llm_model: Optional[LLM_Model] = None
    embedding_model_source: Optional[str] = None
    embedding_model: Optional[Embedding_Model] = None
    attributes: Optional[List[EntityAttributes]] = None
    vs_endpoint: Optional[str] = None
    additional_instructions: Optional[str] = None
    config_thresold: Optional[Config_Threshold] = None
    deterministic_rules: Optional[DeterministicRules] = None
    embedding_mode: Optional[str] = None
    max_potential_matches: Optional[int] = None

    class Config:
        from_attributes = True
        arbitrary_types_allowed = True

    def dict(self, *args, **kwargs):
        base_dict = super().dict(*args, exclude_none=True, **kwargs)
        set_fields = list(self.model_fields_set)
        # Convert nested models to dict
        if "base_prompt_id" in set_fields:
            base_dict['base_prompt_id'] = self.base_prompt_id
        if self.llm_model:
            base_dict['llm_model'] = self.llm_model.dict()
        if self.embedding_model:
            base_dict['embedding_model'] = self.embedding_model.dict()
        if self.config_thresold:
            base_dict['config_thresold'] = self.config_thresold.dict()
        # Handle deterministic_rules explicitly set to None
        if "deterministic_rules" in set_fields:
            base_dict['deterministic_rules'] = self.deterministic_rules.dict() if self.deterministic_rules else None
        elif self.deterministic_rules:
            base_dict['deterministic_rules'] = self.deterministic_rules.dict()
        # Convert attributes list
        if self.attributes:
            base_dict['attributes'] = [attr.dict() for attr in self.attributes]
        # Convert datetime to ISO format string
        if isinstance(base_dict.get('created_at'), datetime):
            base_dict['created_at'] = base_dict['created_at'].isoformat()
        return base_dict

class ActionType(str, Enum):
    AUTO_MERGE = "MATCH"
    POTENTIAL_MATCH = "POTENTIAL_MATCH"
    NOT_A_MERGE = "NO_MATCH"
    
class Model_ExperimentRun_Response(BaseModel):
    id: int
    entity_id: int
    base_prompt_id:Optional[int]=None
    status: str
    modelname: str
    description: Optional[str] = None
    llm_model_source: str
    llm_model: Dict[str, Any]  # Dictionary to hold the serialized LLM model
    embedding_model_source: str
    embedding_model: Dict[str, Any]  # Dictionary to hold the serialized embedding model
    attributes: Optional[List[EntityAttributes]] = None
    vs_endpoint: str
    additional_instructions: Optional[str] = None
    processed_record: int
    max_potential_matches: int
    embedding_mode: Optional[str] = "managed"

    class Config:
        from_attributes = True  # This replaces the old orm_mode=True
        arbitrary_types_allowed = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

    @classmethod
    def from_orm(cls, db_instance: Model_Experiment):
        """Custom from_orm method to handle complex JSON fields"""
        # Create a dict of the database instance
        db_dict = {
            'id': db_instance.id,
            'entity_id': db_instance.entity_id,
            'base_prompt_id':db_instance.base_prompt_id,
            'status': db_instance.status,
            'modelname': db_instance.modelname,
            'description': db_instance.description,
            'llm_model_source': db_instance.llm_model_source,
            'llm_model': db_instance.llm_model,  # Already a dict from JSON column
            'embedding_model_source': db_instance.embedding_model_source,
            'embedding_model': db_instance.embedding_model,  # Already a dict from JSON column
            'attributes': db_instance.attributes,
            'vs_endpoint': db_instance.vs_endpoint,
            'additional_instructions': db_instance.additional_instructions,
            'processed_record': db_instance.processed_record,
            'max_potential_matches': db_instance.max_potential_matches,
            'embedding_mode': db_instance.embedding_mode or "managed",
        }
        return cls(**db_dict)
class Potential_Matches_Parameters(BaseModel):
    id: str
    dataset_id: Union[str, int]

    def dict(self, *args, **kwargs):
        return super().dict(*args, **kwargs)
    
class PotentialMatchesResponse(BaseModel):
    master_id:Union[str, int]
    operation_type: Optional[str] = None
    unified_dataset_ids: List[Potential_Matches_Parameters]

class PotentialMatchDeduplicationRecord(BaseModel):
    master_id:Union[str, int]
    operation_type: Optional[str] = None
    match_record_id: Union[str, int]