"""
Shared builder for the LLM-scoring task(s) in entity-matching job DAGs (REFACTOR 1).

Parallelism for the LLM ai_query step comes from the JOB DAG, not driver threads:
each shard is its own task run (its own batch-inference session), so shard_count
parallel sessions consume up to the org Model-Unit grant instead of a single session.

`build_llm_tasks` returns the task(s) to splice into a job's task list IN PLACE OF the
original single LLM Task. shard_count is decided at job-generation time (a per-run
param, default 1):

  shard_count <= 1
      -> a single LLM task with `task_key` — today's behavior, byte-for-byte unchanged.

  shard_count  > 1
      -> {task_key}_Shards : a for_each task that fans the worker notebook into
                             `shard_count` parallel iterations over disjoint hash slices
                             (each iteration is shard_index = {{input}}), then
         {task_key}         : an Assemble task that KEEPS the original task_key and does
                             the single merge into the unified table. Because the Assemble
                             task keeps `task_key`, every downstream task that depends on
                             `task_key` needs NO change, and no ConditionTask / planner is
                             required.

Usage (inside a task-list literal, using list unpacking):

    tasks = [
        ...,
        *build_llm_tasks(
            task_key="Entity_Matching_LLM",
            upstream_keys=["Entity_Matching_Detereministic"],
            worker_notebook=f"{base}/normal_deduplication/Entity_Matching_LLM",            # single-shard
            split_notebook=f"{base}/normal_deduplication/Entity_Matching_LLM_Split",       # multi-shard
            shard_notebook=f"{base}/normal_deduplication/Entity_Matching_LLM_Shard",       # multi-shard
            assemble_notebook=f"{base}/normal_deduplication/Entity_Matching_LLM_Assemble", # multi-shard
            parameters=parameters,
            shard_count=llm_shard_count,
        ),
        Task(task_key="Process_Auto_Merge",
             depends_on=[TaskDependency(task_key="Entity_Matching_LLM")], ...),  # unchanged
        ...,
    ]
"""
import json

from databricks.sdk.service.jobs import (
    Task,
    NotebookTask,
    ForEachTask,
    TaskDependency,
    RunIf,
    Source,
)


def build_llm_tasks(
    *,
    task_key,
    upstream_keys,
    worker_notebook,
    assemble_notebook,
    parameters,
    split_notebook=None,
    shard_notebook=None,
    shard_count=1,
    shard_concurrency=None,
    shard_chunk_retries=1,
    shard_min_records=50000,
    timeout_seconds=0,
    existing_cluster_id=None,
):
    """Build the LLM scoring task(s) for one pipeline flow.

    Args:
        task_key: terminal task key downstream tasks depend on (e.g. "Entity_Matching_LLM").
        upstream_keys: list of task_keys the LLM step depends on.
        worker_notebook: full workspace path of the single-shard Entity_Matching_LLM notebook
            (used only when shard_count <= 1 — the clean monolithic notebook).
        assemble_notebook: full workspace path of the Entity_Matching_LLM_Assemble notebook.
        parameters: base_parameters dict shared by the flow's tasks.
        split_notebook: full workspace path of the Entity_Matching_LLM_Split notebook. Required
            when shard_count > 1 (the splitter scans + deterministic-filters + hash-partitions the
            source ONCE into {source}_llm_input so each shard reads only its own partition).
        shard_notebook: full workspace path of the lean Entity_Matching_LLM_Shard notebook (the
            for_each body — ONLY LLM scoring). Required when shard_count > 1.
        shard_count: number of parallel shards (<=1 disables sharding).
        shard_concurrency: max concurrent shard iterations (defaults to shard_count;
            keep shard_concurrency * per-session-MU <= org MU).
        shard_chunk_retries: per-chunk retries inside each shard worker for transient ai_query
            failures (default 1). Ignored when shard_count <= 1.
        shard_min_records: minimum eligible-record floor for sharding (default 50000). Passed to
            the Split, which collapses ALL rows into a single shard (single process) when the
            eligible count is below this, regardless of shard_count; at or above it the configured
            shards are used. Only the Split needs it. Ignored when shard_count <= 1.
        timeout_seconds: per-task timeout (0 = none), matching the surrounding tasks.

    Returns:
        list[Task] to splice into the job's task list in place of the single LLM Task.
        shard_count > 1 yields THREE tasks: {task_key}_Split -> {task_key}_Shards (for_each) ->
        {task_key} (assemble, keeps the original key so downstream deps are unchanged).
    """
    depends_on = [TaskDependency(task_key=k) for k in upstream_keys]

    # shard_count <= 1 -> unchanged single-task flow.
    if not shard_count or int(shard_count) <= 1:
        return [
            Task(
                task_key=task_key,
                depends_on=depends_on,
                run_if=RunIf.ALL_SUCCESS,
                existing_cluster_id=existing_cluster_id,
                notebook_task=NotebookTask(
                    notebook_path=worker_notebook,
                    base_parameters=parameters,
                    source=Source.WORKSPACE,
                ),
                timeout_seconds=timeout_seconds,
            )
        ]

    if not split_notebook or not shard_notebook:
        raise ValueError("build_llm_tasks: split_notebook and shard_notebook are required when shard_count > 1")

    shard_count = int(shard_count)
    concurrency = int(shard_concurrency or shard_count)
    split_key = f"{task_key}_Split"
    shards_key = f"{task_key}_Shards"

    split_params = {
        **parameters,
        "shard_count": str(shard_count),
        "shard_min_records": str(shard_min_records),
    }
    shard_params = {
        **parameters,
        "shard_index": "{{input}}",
        "shard_count": str(shard_count),
        "shard_chunk_retries": str(shard_chunk_retries),
    }
    assemble_params = {**parameters, "shard_count": str(shard_count)}

    return [
        # Split: scan + _det_filter + eligibility filter ONCE, hash-partition the source into
        # {source}_llm_input PARTITIONED BY (shard_index). Runs once before the shards so each
        # shard reads only its own partition instead of re-scanning the whole source table.
        Task(
            task_key=split_key,
            depends_on=depends_on,
            run_if=RunIf.ALL_SUCCESS,
            existing_cluster_id=existing_cluster_id,
            notebook_task=NotebookTask(
                notebook_path=split_notebook,
                base_parameters=split_params,
                source=Source.WORKSPACE,
            ),
            timeout_seconds=timeout_seconds,
        ),
        # Fan-out: one worker task run per shard (each its own ai_query batch session). Each reads
        # its {source}_llm_input partition, does ONLY chunked scoring (+ per-chunk retry), and
        # writes its own _llm_temp_v1_shard_<i> table + _done marker. No validation/merge/error
        # logging here — that's the assembler's job (single writer).
        Task(
            task_key=shards_key,
            depends_on=[TaskDependency(task_key=split_key)],
            run_if=RunIf.ALL_SUCCESS,
            for_each_task=ForEachTask(
                inputs=json.dumps(list(range(shard_count))),
                concurrency=concurrency,
                task=Task(
                    task_key=f"{task_key}_Shard",
                    existing_cluster_id=existing_cluster_id,
                    notebook_task=NotebookTask(
                        notebook_path=shard_notebook,
                        base_parameters=shard_params,
                        source=Source.WORKSPACE,
                    ),
                    timeout_seconds=timeout_seconds,
                ),
            ),
            timeout_seconds=timeout_seconds,
        ),
        # Fan-in: single writer. Unions the shard outputs, runs the bad-result retry + the ONLY
        # unified-error-table write + explode/merge/rebuild. Keeps the original task_key so
        # downstream deps are unchanged.
        Task(
            task_key=task_key,
            depends_on=[TaskDependency(task_key=shards_key)],
            run_if=RunIf.ALL_SUCCESS,
            existing_cluster_id=existing_cluster_id,
            notebook_task=NotebookTask(
                notebook_path=assemble_notebook,
                base_parameters=assemble_params,
                source=Source.WORKSPACE,
            ),
            timeout_seconds=timeout_seconds,
        ),
    ]
